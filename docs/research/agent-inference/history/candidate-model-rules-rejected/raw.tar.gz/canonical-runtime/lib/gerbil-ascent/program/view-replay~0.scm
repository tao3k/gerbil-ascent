(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/view-replay::timestamp 1791687860)
  (begin
    (define gerbil-ascent/program/view-replay#replay-node::t
      (let ((__tmp33809 (list)) (__tmp33808 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/view-replay#replay-node::t
         'replay-node
         __tmp33809
         '(parent members size)
         __tmp33808
         '#f)))
    (define gerbil-ascent/program/view-replay#replay-node?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/view-replay#replay-node::t)))
    (define gerbil-ascent/program/view-replay#make-replay-node
      (lambda _%$args18277%_
        (apply make-instance
               gerbil-ascent/program/view-replay#replay-node::t
               _%$args18277%_)))
    (define gerbil-ascent/program/view-replay#replay-node-parent
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-replay#replay-node::t
         'parent)))
    (define gerbil-ascent/program/view-replay#replay-node-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-replay#replay-node::t
         'members)))
    (define gerbil-ascent/program/view-replay#replay-node-size
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-replay#replay-node::t
         'size)))
    (define gerbil-ascent/program/view-replay#replay-node-parent-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-replay#replay-node::t
         'parent)))
    (define gerbil-ascent/program/view-replay#replay-node-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-replay#replay-node::t
         'members)))
    (define gerbil-ascent/program/view-replay#replay-node-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-replay#replay-node::t
         'size)))
    (define gerbil-ascent/program/view-replay#&replay-node-parent
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-replay#replay-node::t
         'parent)))
    (define gerbil-ascent/program/view-replay#&replay-node-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-replay#replay-node::t
         'members)))
    (define gerbil-ascent/program/view-replay#&replay-node-size
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-replay#replay-node::t
         'size)))
    (define gerbil-ascent/program/view-replay#&replay-node-parent-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-replay#replay-node::t
         'parent)))
    (define gerbil-ascent/program/view-replay#&replay-node-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-replay#replay-node::t
         'members)))
    (define gerbil-ascent/program/view-replay#&replay-node-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-replay#replay-node::t
         'size)))
    (define gerbil-ascent/program/view-replay#replay-group::t
      (let ((__tmp33811 (list)) (__tmp33810 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/view-replay#replay-group::t
         'replay-group
         __tmp33811
         '(nodes roots values used width bits)
         __tmp33810
         '#f)))
    (define gerbil-ascent/program/view-replay#replay-group?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/view-replay#replay-group::t)))
    (define gerbil-ascent/program/view-replay#make-replay-group
      (lambda _%$args18274%_
        (apply make-instance
               gerbil-ascent/program/view-replay#replay-group::t
               _%$args18274%_)))
    (define gerbil-ascent/program/view-replay#replay-group-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'nodes)))
    (define gerbil-ascent/program/view-replay#replay-group-roots
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'roots)))
    (define gerbil-ascent/program/view-replay#replay-group-values
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'values)))
    (define gerbil-ascent/program/view-replay#replay-group-used
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'used)))
    (define gerbil-ascent/program/view-replay#replay-group-width
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'width)))
    (define gerbil-ascent/program/view-replay#replay-group-bits
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'bits)))
    (define gerbil-ascent/program/view-replay#replay-group-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'nodes)))
    (define gerbil-ascent/program/view-replay#replay-group-roots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'roots)))
    (define gerbil-ascent/program/view-replay#replay-group-values-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'values)))
    (define gerbil-ascent/program/view-replay#replay-group-used-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'used)))
    (define gerbil-ascent/program/view-replay#replay-group-width-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'width)))
    (define gerbil-ascent/program/view-replay#replay-group-bits-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'bits)))
    (define gerbil-ascent/program/view-replay#&replay-group-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'nodes)))
    (define gerbil-ascent/program/view-replay#&replay-group-roots
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'roots)))
    (define gerbil-ascent/program/view-replay#&replay-group-values
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'values)))
    (define gerbil-ascent/program/view-replay#&replay-group-used
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'used)))
    (define gerbil-ascent/program/view-replay#&replay-group-width
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'width)))
    (define gerbil-ascent/program/view-replay#&replay-group-bits
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'bits)))
    (define gerbil-ascent/program/view-replay#&replay-group-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'nodes)))
    (define gerbil-ascent/program/view-replay#&replay-group-roots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'roots)))
    (define gerbil-ascent/program/view-replay#&replay-group-values-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'values)))
    (define gerbil-ascent/program/view-replay#&replay-group-used-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'used)))
    (define gerbil-ascent/program/view-replay#&replay-group-width-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'width)))
    (define gerbil-ascent/program/view-replay#&replay-group-bits-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'bits)))
    (define gerbil-ascent/program/view-replay#root
      (lambda (_%n18272%_)
        (if (##structure-ref
             _%n18272%_
             '1
             gerbil-ascent/program/view-replay#replay-node::t
             '#f)
            (gerbil-ascent/program/view-replay#root
             (##structure-ref
              _%n18272%_
              '1
              gerbil-ascent/program/view-replay#replay-node::t
              '#f))
            _%n18272%_)))
    (define gerbil-ascent/program/view-replay#position
      (lambda (_%group18268%_ _%a18269%_ _%b18270%_)
        (let ((__tmp33812
               (let ((__tmp33813
                      (##structure-ref
                       _%group18268%_
                       '5
                       gerbil-ascent/program/view-replay#replay-group::t
                       '#f)))
                 (declare (not safe))
                 (##fx* _%a18269%_ __tmp33813))))
          (declare (not safe))
          (##fx+ __tmp33812 _%b18270%_))))
    (define gerbil-ascent/program/view-replay#reaches?
      (lambda (_%group18262%_ _%a18263%_ _%b18264%_)
        (let ((_%p18266%_
               (gerbil-ascent/program/view-replay#position
                _%group18262%_
                (car (##structure-ref
                      _%a18263%_
                      '2
                      gerbil-ascent/program/view-replay#replay-node::t
                      '#f))
                (car (##structure-ref
                      _%b18264%_
                      '2
                      gerbil-ascent/program/view-replay#replay-node::t
                      '#f)))))
          (not (let ((__tmp33814
                      (let ((__tmp33817
                             (u16vector-ref
                              (##structure-ref
                               _%group18262%_
                               '6
                               gerbil-ascent/program/view-replay#replay-group::t
                               '#f)
                              (let ()
                                (declare (not safe))
                                (##fxarithmetic-shift-right _%p18266%_ '4))))
                            (__tmp33815
                             (let ((__tmp33816
                                    (let ()
                                      (declare (not safe))
                                      (##fxand _%p18266%_ '15))))
                               (declare (not safe))
                               (##fxarithmetic-shift-left '1 __tmp33816))))
                        (declare (not safe))
                        (##fxand __tmp33817 __tmp33815))))
                 (declare (not safe))
                 (##fxzero? __tmp33814))))))
    (define gerbil-ascent/program/view-replay#mark!
      (lambda (_%group18249%_ _%a18250%_ _%b18251%_)
        (let* ((_%p18253%_
                (gerbil-ascent/program/view-replay#position
                 _%group18249%_
                 _%a18250%_
                 _%b18251%_))
               (_%word18255%_
                (let ()
                  (declare (not safe))
                  (##fxarithmetic-shift-right _%p18253%_ '4)))
               (_%mask18257%_
                (let ((__tmp33818
                       (let () (declare (not safe)) (##fxand _%p18253%_ '15))))
                  (declare (not safe))
                  (##fxarithmetic-shift-left '1 __tmp33818)))
               (_%bits18259%_
                (##structure-ref
                 _%group18249%_
                 '6
                 gerbil-ascent/program/view-replay#replay-group::t
                 '#f)))
          (u16vector-set!
           _%bits18259%_
           _%word18255%_
           (let ((__tmp33819 (u16vector-ref _%bits18259%_ _%word18255%_)))
             (declare (not safe))
             (##fxior __tmp33819 _%mask18257%_))))))
    (define gerbil-ascent/program/view-replay#fresh!
      (lambda (_%group18241%_ _%value18242%_)
        (let* ((_%id18244%_
                (##structure-ref
                 _%group18241%_
                 '4
                 gerbil-ascent/program/view-replay#replay-group::t
                 '#f))
               (_%n18246%_
                (let ((__tmp33820 (list _%id18244%_)))
                  (declare (not safe))
                  (##structure
                   gerbil-ascent/program/view-replay#replay-node::t
                   '#f
                   __tmp33820
                   '1))))
          (vector-set!
           (##structure-ref
            _%group18241%_
            '3
            gerbil-ascent/program/view-replay#replay-group::t
            '#f)
           _%id18244%_
           _%value18242%_)
          (##structure-set!
           _%group18241%_
           (+ _%id18244%_ '1)
           '4
           gerbil-ascent/program/view-replay#replay-group::t
           '#f)
          (let ((__tmp33821
                 (##structure-ref
                  _%group18241%_
                  '1
                  gerbil-ascent/program/view-replay#replay-group::t
                  '#f)))
            (declare (not safe))
            (hash-put! __tmp33821 _%value18242%_ _%n18246%_))
          (gerbil-ascent/program/view-replay#mark!
           _%group18241%_
           _%id18244%_
           _%id18244%_)
          _%n18246%_)))
    (define gerbil-ascent/program/view-replay#group-key
      (lambda (_%row18239%_)
        (list (length _%row18239%_)
              (if (= (length _%row18239%_) '3) (car _%row18239%_) '#f))))
    (define gerbil-ascent/program/view-replay#prepare
      (lambda (_%events18216%_ _%rows-of18217%_)
        (let ((_%sizes18219%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (for-each
           (lambda (_%event18221%_)
             (for-each
              (lambda (_%row18223%_)
                (let* ((_%key18225%_
                        (gerbil-ascent/program/view-replay#group-key
                         _%row18223%_))
                       (__tmp33822
                        (+ '1
                           (let ((_%$e18227%_
                                  (let ()
                                    (declare (not safe))
                                    (__hash-get _%sizes18219%_ _%key18225%_))))
                             (if _%$e18227%_ _%$e18227%_ '0)))))
                  (declare (not safe))
                  (__hash-put! _%sizes18219%_ _%key18225%_ __tmp33822)))
              (_%rows-of18217%_ _%event18221%_)))
           _%events18216%_)
          (if (let ((__tmp33824
                     (lambda (_%entry18230%_)
                       (and (let ((__tmp33825 (caar _%entry18230%_)))
                              (declare (not safe))
                              (##memq __tmp33825 '(2 3)))
                            (<= (cdr _%entry18230%_) '256))))
                    (__tmp33823
                     (let ()
                       (declare (not safe))
                       (__hash->list _%sizes18219%_))))
                (declare (not safe))
                (andmap__0 __tmp33824 __tmp33823))
              (let ((_%groups18232%_
                     (let ()
                       (declare (not safe))
                       (make-hash-table__%
                        '#f
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value))))
                (let ((__tmp33826
                       (lambda (_%key18234%_ _%size18235%_)
                         (let* ((_%width18237%_ (* '2 _%size18235%_))
                                (__tmp33827
                                 (let ((__tmp33830
                                        (let ()
                                          (declare (not safe))
                                          (make-hash-table__%
                                           '#f
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value)))
                                       (__tmp33829
                                        (make-vector _%width18237%_ '#f))
                                       (__tmp33828
                                        (make-u16vector
                                         (quotient
                                          (+ (* _%width18237%_ _%width18237%_)
                                             '15)
                                          '16)
                                         '0)))
                                   (declare (not safe))
                                   (##structure
                                    gerbil-ascent/program/view-replay#replay-group::t
                                    __tmp33830
                                    '()
                                    __tmp33829
                                    '0
                                    _%width18237%_
                                    __tmp33828))))
                           (declare (not safe))
                           (__hash-put!
                            _%groups18232%_
                            _%key18234%_
                            __tmp33827)))))
                  (declare (not safe))
                  (__hash-for-each __tmp33826 _%sizes18219%_))
                _%groups18232%_)
              '#f))))
    (define gerbil-ascent/program/view-replay#merge!
      (lambda (_%group18198%_ _%roots18199%_ _%cycle18200%_)
        (let* ((_%winner18205%_
                (let ((__tmp33833
                       (lambda (_%n18202%_ _%best18203%_)
                         (if (> (##structure-ref
                                 _%n18202%_
                                 '3
                                 gerbil-ascent/program/view-replay#replay-node::t
                                 '#f)
                                (##structure-ref
                                 _%best18203%_
                                 '3
                                 gerbil-ascent/program/view-replay#replay-node::t
                                 '#f))
                             _%n18202%_
                             _%best18203%_)))
                      (__tmp33832 (car _%cycle18200%_))
                      (__tmp33831 (cdr _%cycle18200%_)))
                  (declare (not safe))
                  (foldl__0 __tmp33833 __tmp33832 __tmp33831)))
               (_%members18207%_
                (##structure-ref
                 _%winner18205%_
                 '2
                 gerbil-ascent/program/view-replay#replay-node::t
                 '#f))
               (_%size18209%_
                (##structure-ref
                 _%winner18205%_
                 '3
                 gerbil-ascent/program/view-replay#replay-node::t
                 '#f)))
          (for-each
           (lambda (_%n18212%_)
             (if (eq? _%n18212%_ _%winner18205%_)
                 '#!void
                 (begin
                   (set! _%members18207%_
                         (append (##structure-ref
                                  _%n18212%_
                                  '2
                                  gerbil-ascent/program/view-replay#replay-node::t
                                  '#f)
                                 _%members18207%_))
                   (set! _%size18209%_
                         (+ _%size18209%_
                            (##structure-ref
                             _%n18212%_
                             '3
                             gerbil-ascent/program/view-replay#replay-node::t
                             '#f)))
                   (##structure-set!
                    _%n18212%_
                    _%winner18205%_
                    '1
                    gerbil-ascent/program/view-replay#replay-node::t
                    '#f))))
           _%cycle18200%_)
          (##structure-set!
           _%winner18205%_
           _%members18207%_
           '2
           gerbil-ascent/program/view-replay#replay-node::t
           '#f)
          (##structure-set!
           _%winner18205%_
           _%size18209%_
           '3
           gerbil-ascent/program/view-replay#replay-node::t
           '#f)
          (##structure-set!
           _%group18198%_
           (filter (lambda (_%n18214%_)
                     (not (##structure-ref
                           _%n18214%_
                           '1
                           gerbil-ascent/program/view-replay#replay-node::t
                           '#f)))
                   _%roots18199%_)
           '2
           gerbil-ascent/program/view-replay#replay-group::t
           '#f))))
    (define gerbil-ascent/program/view-replay#write-rights!
      (lambda (_%group18190%_
               _%prefix18191%_
               _%emit18192%_
               _%left18193%_
               _%rights18194%_)
        (if (null? _%rights18194%_)
            '#!void
            (begin
              (let ((_%right18196%_ (car _%rights18194%_)))
                (gerbil-ascent/program/view-replay#mark!
                 _%group18190%_
                 _%left18193%_
                 _%right18196%_)
                (if _%emit18192%_
                    (_%emit18192%_
                     (let ((__tmp33834
                            (list (vector-ref
                                   (##structure-ref
                                    _%group18190%_
                                    '3
                                    gerbil-ascent/program/view-replay#replay-group::t
                                    '#f)
                                   _%left18193%_)
                                  (vector-ref
                                   (##structure-ref
                                    _%group18190%_
                                    '3
                                    gerbil-ascent/program/view-replay#replay-group::t
                                    '#f)
                                   _%right18196%_))))
                       (declare (not safe))
                       (##append _%prefix18191%_ __tmp33834)))
                    '#!void))
              (gerbil-ascent/program/view-replay#write-rights!
               _%group18190%_
               _%prefix18191%_
               _%emit18192%_
               _%left18193%_
               (cdr _%rights18194%_))))))
    (define gerbil-ascent/program/view-replay#write-block!
      (lambda (_%group18184%_
               _%prefix18185%_
               _%emit18186%_
               _%lefts18187%_
               _%rights18188%_)
        (if (null? _%lefts18187%_)
            '#!void
            (begin
              (gerbil-ascent/program/view-replay#write-rights!
               _%group18184%_
               _%prefix18185%_
               _%emit18186%_
               (car _%lefts18187%_)
               _%rights18188%_)
              (gerbil-ascent/program/view-replay#write-block!
               _%group18184%_
               _%prefix18185%_
               _%emit18186%_
               (cdr _%lefts18187%_)
               _%rights18188%_)))))
    (define gerbil-ascent/program/view-replay#count-targets
      (lambda (_%group18177%_ _%p18178%_ _%succs18179%_ _%count18180%_)
        (if (null? _%succs18179%_)
            _%count18180%_
            (let ((_%s18182%_ (car _%succs18179%_)))
              (gerbil-ascent/program/view-replay#count-targets
               _%group18177%_
               _%p18178%_
               (cdr _%succs18179%_)
               (if (gerbil-ascent/program/view-replay#reaches?
                    _%group18177%_
                    _%p18178%_
                    _%s18182%_)
                   _%count18180%_
                   (let ((__tmp33835
                          (let ((__tmp33837
                                 (##structure-ref
                                  _%p18178%_
                                  '3
                                  gerbil-ascent/program/view-replay#replay-node::t
                                  '#f))
                                (__tmp33836
                                 (##structure-ref
                                  _%s18182%_
                                  '3
                                  gerbil-ascent/program/view-replay#replay-node::t
                                  '#f)))
                            (declare (not safe))
                            (##fx* __tmp33837 __tmp33836))))
                     (declare (not safe))
                     (##fx+ _%count18180%_ __tmp33835))))))))
    (define gerbil-ascent/program/view-replay#count-sources
      (lambda (_%group18172%_ _%preds18173%_ _%succs18174%_ _%count18175%_)
        (if (null? _%preds18173%_)
            _%count18175%_
            (gerbil-ascent/program/view-replay#count-sources
             _%group18172%_
             (cdr _%preds18173%_)
             _%succs18174%_
             (gerbil-ascent/program/view-replay#count-targets
              _%group18172%_
              (car _%preds18173%_)
              _%succs18174%_
              _%count18175%_)))))
    (define gerbil-ascent/program/view-replay#write-targets!
      (lambda (_%group18164%_
               _%p18165%_
               _%succs18166%_
               _%prefix18167%_
               _%emit18168%_)
        (if (null? _%succs18166%_)
            '#!void
            (begin
              (let ((_%s18170%_ (car _%succs18166%_)))
                (if (gerbil-ascent/program/view-replay#reaches?
                     _%group18164%_
                     _%p18165%_
                     _%s18170%_)
                    '#!void
                    (gerbil-ascent/program/view-replay#write-block!
                     _%group18164%_
                     _%prefix18167%_
                     _%emit18168%_
                     (##structure-ref
                      _%p18165%_
                      '2
                      gerbil-ascent/program/view-replay#replay-node::t
                      '#f)
                     (##structure-ref
                      _%s18170%_
                      '2
                      gerbil-ascent/program/view-replay#replay-node::t
                      '#f))))
              (gerbil-ascent/program/view-replay#write-targets!
               _%group18164%_
               _%p18165%_
               (cdr _%succs18166%_)
               _%prefix18167%_
               _%emit18168%_)))))
    (define gerbil-ascent/program/view-replay#write-sources!
      (lambda (_%group18158%_
               _%preds18159%_
               _%succs18160%_
               _%prefix18161%_
               _%emit18162%_)
        (if (null? _%preds18159%_)
            '#!void
            (begin
              (gerbil-ascent/program/view-replay#write-targets!
               _%group18158%_
               (car _%preds18159%_)
               _%succs18160%_
               _%prefix18161%_
               _%emit18162%_)
              (gerbil-ascent/program/view-replay#write-sources!
               _%group18158%_
               (cdr _%preds18159%_)
               _%succs18160%_
               _%prefix18161%_
               _%emit18162%_)))))
    (define gerbil-ascent/program/view-replay#collect-roots
      (lambda (_%roots18154%_ _%selected?18155%_ _%out18156%_)
        (if (null? _%roots18154%_)
            _%out18156%_
            (gerbil-ascent/program/view-replay#collect-roots
             (cdr _%roots18154%_)
             _%selected?18155%_
             (if (_%selected?18155%_ (car _%roots18154%_))
                 (cons (car _%roots18154%_) _%out18156%_)
                 _%out18156%_)))))
    (define gerbil-ascent/program/view-replay#insert!
      (lambda (_%group18105%_ _%row18106%_ _%budget18107%_ _%consume18108%_)
        (let* ((_%pair18110%_
                (if (= (length _%row18106%_) '3)
                    (cdr _%row18106%_)
                    _%row18106%_))
               (_%nodes18112%_
                (##structure-ref
                 _%group18105%_
                 '1
                 gerbil-ascent/program/view-replay#replay-group::t
                 '#f))
               (_%known-left18114%_
                (let ((__tmp33838 (car _%pair18110%_)))
                  (declare (not safe))
                  (hash-get _%nodes18112%_ __tmp33838)))
               (_%known-right18116%_
                (let ((__tmp33839 (cadr _%pair18110%_)))
                  (declare (not safe))
                  (hash-get _%nodes18112%_ __tmp33839)))
               (_%a18118%_
                (if _%known-left18114%_
                    (gerbil-ascent/program/view-replay#root
                     _%known-left18114%_)
                    (gerbil-ascent/program/view-replay#fresh!
                     _%group18105%_
                     (car _%pair18110%_))))
               (_%b18120%_
                (if (equal? (car _%pair18110%_) (cadr _%pair18110%_))
                    _%a18118%_
                    (if _%known-right18116%_
                        (gerbil-ascent/program/view-replay#root
                         _%known-right18116%_)
                        (gerbil-ascent/program/view-replay#fresh!
                         _%group18105%_
                         (cadr _%pair18110%_)))))
               (_%new18125%_
                (let ((__tmp33841
                       (if _%known-left18114%_ '() (list _%a18118%_)))
                      (__tmp33840
                       (if (or _%known-right18116%_
                               (eq? _%a18118%_ _%b18120%_))
                           '()
                           (list _%b18120%_))))
                  (declare (not safe))
                  (##append __tmp33841 __tmp33840)))
               (_%roots18127%_
                (append _%new18125%_
                        (##structure-ref
                         _%group18105%_
                         '2
                         gerbil-ascent/program/view-replay#replay-group::t
                         '#f)))
               (_%preds18131%_
                (gerbil-ascent/program/view-replay#collect-roots
                 _%roots18127%_
                 (lambda (_%p18129%_)
                   (gerbil-ascent/program/view-replay#reaches?
                    _%group18105%_
                    _%p18129%_
                    _%a18118%_))
                 '()))
               (_%succs18135%_
                (gerbil-ascent/program/view-replay#collect-roots
                 _%roots18127%_
                 (lambda (_%s18133%_)
                   (gerbil-ascent/program/view-replay#reaches?
                    _%group18105%_
                    _%b18120%_
                    _%s18133%_))
                 '()))
               (_%cycle18139%_
                (if (eq? _%a18118%_ _%b18120%_)
                    '#f
                    (if (gerbil-ascent/program/view-replay#reaches?
                         _%group18105%_
                         _%b18120%_
                         _%a18118%_)
                        (let ((__tmp33843
                               (lambda (_%p18137%_)
                                 (gerbil-ascent/program/view-replay#reaches?
                                  _%group18105%_
                                  _%b18120%_
                                  _%p18137%_)))
                              (__tmp33842 (reverse _%preds18131%_)))
                          (declare (not safe))
                          (##filter __tmp33843 __tmp33842))
                        '#f)))
               (_%needed18141%_
                (gerbil-ascent/program/view-replay#count-sources
                 _%group18105%_
                 _%preds18131%_
                 _%succs18135%_
                 (let () (declare (not safe)) (##length _%new18125%_))))
               (_%prefix18143%_
                (if (= (length _%row18106%_) '3)
                    (list (car _%row18106%_))
                    '()))
               (_%values18145%_
                (##structure-ref
                 _%group18105%_
                 '3
                 gerbil-ascent/program/view-replay#replay-group::t
                 '#f)))
          (if (> _%needed18141%_ _%budget18107%_)
              (let ()
                (declare (not safe))
                (error '"ASCENT trrel output fact budget exceeded"))
              '#!void)
          (let ((_%emit18148%_ (_%consume18108%_ _%needed18141%_)))
            (let ((__tmp33844
                   (lambda (_%n18150%_)
                     (if _%emit18148%_
                         (let ((_%v18152%_
                                (vector-ref
                                 _%values18145%_
                                 (car (##structure-ref
                                       _%n18150%_
                                       '2
                                       gerbil-ascent/program/view-replay#replay-node::t
                                       '#f)))))
                           (_%emit18148%_
                            (let ((__tmp33845 (list _%v18152%_ _%v18152%_)))
                              (declare (not safe))
                              (##append _%prefix18143%_ __tmp33845))))
                         '#!void))))
              (declare (not safe))
              (##for-each __tmp33844 _%new18125%_))
            (gerbil-ascent/program/view-replay#write-sources!
             _%group18105%_
             _%preds18131%_
             _%succs18135%_
             _%prefix18143%_
             _%emit18148%_))
          (##structure-set!
           _%group18105%_
           _%roots18127%_
           '2
           gerbil-ascent/program/view-replay#replay-group::t
           '#f)
          (if _%cycle18139%_
              (gerbil-ascent/program/view-replay#merge!
               _%group18105%_
               _%roots18127%_
               _%cycle18139%_)
              '#!void))))
    (define gerbil-ascent/program/view-replay#gerbil-ascent-small-journal-export
      (lambda (_%events18075%_
               _%kind-of18076%_
               _%rows-of18077%_
               _%budget18078%_
               _%skip18079%_
               _%delta?18080%_)
        (let ((_%groups18082%_
               (gerbil-ascent/program/view-replay#prepare
                _%events18075%_
                _%rows-of18077%_)))
          (if _%groups18082%_
              (let ((_%output18084%_ '()) (_%admitted18085%_ '0))
                (let ((__tmp33847
                       (lambda (_%event18087%_)
                         (let ((_%batch18089%_ '())
                               (_%derived?18090%_
                                (if _%delta?18080%_
                                    '#f
                                    (eq? (_%kind-of18076%_ _%event18087%_)
                                         'derived))))
                           (for-each
                            (lambda (_%row18092%_)
                              (gerbil-ascent/program/view-replay#insert!
                               (let ((__tmp33848
                                      (gerbil-ascent/program/view-replay#group-key
                                       _%row18092%_)))
                                 (declare (not safe))
                                 (__hash-get _%groups18082%_ __tmp33848))
                               _%row18092%_
                               _%budget18078%_
                               (lambda (_%needed18094%_)
                                 (let* ((_%next18096%_
                                         (+ _%admitted18085%_ _%needed18094%_))
                                        (_%$r18102%_
                                         (if (> _%next18096%_ _%skip18079%_)
                                             (begin
                                               (if (> _%skip18079%_
                                                      _%admitted18085%_)
                                                   (let ()
                                                     (declare (not safe))
                                                     (error '"ASCENT ordered delta splits an injection frontier"))
                                                   '#!void)
                                               (if _%derived?18090%_
                                                   (lambda (_%stored18098%_)
                                                     (set! _%batch18089%_
                                                           (cons _%stored18098%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%batch18089%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (lambda (_%stored18100%_)
                                                     (set! _%output18084%_
                                                           (cons _%stored18100%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%output18084%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             '#f)))
                                   (set! _%admitted18085%_ _%next18096%_)
                                   _%$r18102%_))))
                            (_%rows-of18077%_ _%event18087%_))
                           (if _%derived?18090%_
                               (set! _%output18084%_
                                     (append! (reverse! _%batch18089%_)
                                              _%output18084%_))
                               '#!void))))
                      (__tmp33846 (reverse _%events18075%_)))
                  (declare (not safe))
                  (##for-each __tmp33847 __tmp33846))
                (reverse! _%output18084%_))
              '#f))))))
