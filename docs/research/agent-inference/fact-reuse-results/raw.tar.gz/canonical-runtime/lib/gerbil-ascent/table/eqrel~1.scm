(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/eqrel[1]#_g34763_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34765_|
    (##structure
     gx#syntax-quote::t
     'make-eqrel-component
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34767_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34769_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34770_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34772_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34773_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34775_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-component-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34776_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-component-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34778_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-component-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34779_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-component-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34781_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34783_|
    (##structure
     gx#syntax-quote::t
     'make-eqrel-cut
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34785_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34787_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34788_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34790_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34791_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut-view-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34793_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-cut-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34794_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-cut-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34796_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-cut-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34797_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-cut-view-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34799_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34801_|
    (##structure
     gx#syntax-quote::t
     'make-eqrel-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34803_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34805_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-components
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34806_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34807_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-published
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34808_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-origin
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34810_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-components-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34811_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34812_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-published-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34813_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-origin-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34815_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-components
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34816_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34817_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-published
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34818_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-origin
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34820_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-components-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34821_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34822_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-published-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34823_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-origin-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34825_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34827_|
    (##structure
     gx#syntax-quote::t
     'make-coordinate-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34829_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34831_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-bound?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34832_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34833_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-coherent?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34835_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-bound?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34836_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34837_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-coherent?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34839_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-bound?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34840_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34841_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-coherent?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34843_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-bound?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34844_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34845_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-coherent?-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/table/eqrel[:0:]#eqrel-component|
      (let ((__obj34584
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34584
           'gerbil-ascent/table/eqrel#eqrel-component::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34584 'eqrel-component '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34584 '(members size) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34584 '(members size) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34584 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34584 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34584 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34584 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34584 '#f '13 '#f '#f))
        (let ((__tmp34762 |gerbil-ascent/table/eqrel[1]#_g34763_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34584 __tmp34762 '4 '#f '#f))
        (let ((__tmp34764 |gerbil-ascent/table/eqrel[1]#_g34765_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34584 __tmp34764 '14 '#f '#f))
        (let ((__tmp34766 |gerbil-ascent/table/eqrel[1]#_g34767_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34584 __tmp34766 '15 '#f '#f))
        (let ((__tmp34768
               (cons (cons 'members |gerbil-ascent/table/eqrel[1]#_g34769_|)
                     (cons (cons 'size |gerbil-ascent/table/eqrel[1]#_g34770_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34584 __tmp34768 '16 '#f '#f))
        (let ((__tmp34771
               (cons (cons 'members |gerbil-ascent/table/eqrel[1]#_g34772_|)
                     (cons (cons 'size |gerbil-ascent/table/eqrel[1]#_g34773_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34584 __tmp34771 '17 '#f '#f))
        (let ((__tmp34774
               (cons (cons 'members |gerbil-ascent/table/eqrel[1]#_g34775_|)
                     (cons (cons 'size |gerbil-ascent/table/eqrel[1]#_g34776_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34584 __tmp34774 '18 '#f '#f))
        (let ((__tmp34777
               (cons (cons 'members |gerbil-ascent/table/eqrel[1]#_g34778_|)
                     (cons (cons 'size |gerbil-ascent/table/eqrel[1]#_g34779_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34584 __tmp34777 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34584 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34584 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34584 '() '21 '#f '#f))
        __obj34584))
    (define |gerbil-ascent/table/eqrel[:0:]#eqrel-cut|
      (let ((__obj34585
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34585
           'gerbil-ascent/table/eqrel#eqrel-cut::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34585 'eqrel-cut '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34585 '(count view) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34585 '(count view) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34585 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34585 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34585 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34585 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34585 '#f '13 '#f '#f))
        (let ((__tmp34780 |gerbil-ascent/table/eqrel[1]#_g34781_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34585 __tmp34780 '4 '#f '#f))
        (let ((__tmp34782 |gerbil-ascent/table/eqrel[1]#_g34783_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34585 __tmp34782 '14 '#f '#f))
        (let ((__tmp34784 |gerbil-ascent/table/eqrel[1]#_g34785_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34585 __tmp34784 '15 '#f '#f))
        (let ((__tmp34786
               (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g34787_|)
                     (cons (cons 'view |gerbil-ascent/table/eqrel[1]#_g34788_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34585 __tmp34786 '16 '#f '#f))
        (let ((__tmp34789
               (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g34790_|)
                     (cons (cons 'view |gerbil-ascent/table/eqrel[1]#_g34791_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34585 __tmp34789 '17 '#f '#f))
        (let ((__tmp34792
               (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g34793_|)
                     (cons (cons 'view |gerbil-ascent/table/eqrel[1]#_g34794_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34585 __tmp34792 '18 '#f '#f))
        (let ((__tmp34795
               (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g34796_|)
                     (cons (cons 'view |gerbil-ascent/table/eqrel[1]#_g34797_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34585 __tmp34795 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34585 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34585 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34585 '() '21 '#f '#f))
        __obj34585))
    (define |gerbil-ascent/table/eqrel[:0:]#eqrel-state|
      (let ((__obj34586
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34586
           'gerbil-ascent/table/eqrel#eqrel-state::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34586 'eqrel-state '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34586
           '(components count published origin)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34586
           '(components count published origin)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34586 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34586 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34586 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34586 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34586 '#f '13 '#f '#f))
        (let ((__tmp34798 |gerbil-ascent/table/eqrel[1]#_g34799_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34586 __tmp34798 '4 '#f '#f))
        (let ((__tmp34800 |gerbil-ascent/table/eqrel[1]#_g34801_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34586 __tmp34800 '14 '#f '#f))
        (let ((__tmp34802 |gerbil-ascent/table/eqrel[1]#_g34803_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34586 __tmp34802 '15 '#f '#f))
        (let ((__tmp34804
               (cons (cons 'components |gerbil-ascent/table/eqrel[1]#_g34805_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/eqrel[1]#_g34806_|)
                           (cons (cons 'published
                                       |gerbil-ascent/table/eqrel[1]#_g34807_|)
                                 (cons (cons 'origin
                                             |gerbil-ascent/table/eqrel[1]#_g34808_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34586 __tmp34804 '16 '#f '#f))
        (let ((__tmp34809
               (cons (cons 'components |gerbil-ascent/table/eqrel[1]#_g34810_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/eqrel[1]#_g34811_|)
                           (cons (cons 'published
                                       |gerbil-ascent/table/eqrel[1]#_g34812_|)
                                 (cons (cons 'origin
                                             |gerbil-ascent/table/eqrel[1]#_g34813_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34586 __tmp34809 '17 '#f '#f))
        (let ((__tmp34814
               (cons (cons 'components |gerbil-ascent/table/eqrel[1]#_g34815_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/eqrel[1]#_g34816_|)
                           (cons (cons 'published
                                       |gerbil-ascent/table/eqrel[1]#_g34817_|)
                                 (cons (cons 'origin
                                             |gerbil-ascent/table/eqrel[1]#_g34818_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34586 __tmp34814 '18 '#f '#f))
        (let ((__tmp34819
               (cons (cons 'components |gerbil-ascent/table/eqrel[1]#_g34820_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/eqrel[1]#_g34821_|)
                           (cons (cons 'published
                                       |gerbil-ascent/table/eqrel[1]#_g34822_|)
                                 (cons (cons 'origin
                                             |gerbil-ascent/table/eqrel[1]#_g34823_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34586 __tmp34819 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34586 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34586 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34586 '() '21 '#f '#f))
        __obj34586))
    (define |gerbil-ascent/table/eqrel[:0:]#coordinate-key|
      (let ((__obj34587
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34587
           'gerbil-ascent/table/eqrel#coordinate-key::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34587 'coordinate-key '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34587
           '(bound? value coherent?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34587
           '(bound? value coherent?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34587 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34587 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34587 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34587 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34587 '#f '13 '#f '#f))
        (let ((__tmp34824 |gerbil-ascent/table/eqrel[1]#_g34825_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34587 __tmp34824 '4 '#f '#f))
        (let ((__tmp34826 |gerbil-ascent/table/eqrel[1]#_g34827_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34587 __tmp34826 '14 '#f '#f))
        (let ((__tmp34828 |gerbil-ascent/table/eqrel[1]#_g34829_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34587 __tmp34828 '15 '#f '#f))
        (let ((__tmp34830
               (cons (cons 'bound? |gerbil-ascent/table/eqrel[1]#_g34831_|)
                     (cons (cons 'value
                                 |gerbil-ascent/table/eqrel[1]#_g34832_|)
                           (cons (cons 'coherent?
                                       |gerbil-ascent/table/eqrel[1]#_g34833_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34587 __tmp34830 '16 '#f '#f))
        (let ((__tmp34834
               (cons (cons 'bound? |gerbil-ascent/table/eqrel[1]#_g34835_|)
                     (cons (cons 'value
                                 |gerbil-ascent/table/eqrel[1]#_g34836_|)
                           (cons (cons 'coherent?
                                       |gerbil-ascent/table/eqrel[1]#_g34837_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34587 __tmp34834 '17 '#f '#f))
        (let ((__tmp34838
               (cons (cons 'bound? |gerbil-ascent/table/eqrel[1]#_g34839_|)
                     (cons (cons 'value
                                 |gerbil-ascent/table/eqrel[1]#_g34840_|)
                           (cons (cons 'coherent?
                                       |gerbil-ascent/table/eqrel[1]#_g34841_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34587 __tmp34838 '18 '#f '#f))
        (let ((__tmp34842
               (cons (cons 'bound? |gerbil-ascent/table/eqrel[1]#_g34843_|)
                     (cons (cons 'value
                                 |gerbil-ascent/table/eqrel[1]#_g34844_|)
                           (cons (cons 'coherent?
                                       |gerbil-ascent/table/eqrel[1]#_g34845_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34587 __tmp34842 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34587 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34587 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34587 '() '21 '#f '#f))
        __obj34587))))
