(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/initialization[1]#_g35677_|
    (##structure
     gx#syntax-quote::t
     'pure
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35679_|
    (##structure
     gx#syntax-quote::t
     'callbacks
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35681_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35683_|
    (##structure
     gx#syntax-quote::t
     'make-initial-source-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35685_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35687_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-all
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35688_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-delta
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35689_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-all-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35690_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-delta-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35691_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-storage-states
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35692_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-seen
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35693_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-lattice-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35695_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-all-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35696_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-delta-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35697_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-all-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35698_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-delta-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35699_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-storage-states-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35700_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-seen-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35701_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-lattice-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35703_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-all
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35704_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-delta
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35705_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-all-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35706_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-delta-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35707_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-storage-states
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35708_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-seen
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35709_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-lattice-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35711_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-all-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35712_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-delta-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35713_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-all-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35714_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-delta-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35715_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-storage-states-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35716_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-seen-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35717_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-lattice-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/initialization[:0:]#source-admission-loop|
      (lambda (_%$stx16324%_)
        (let* ((_%__stx3549735498%_ _%$stx16324%_)
               (_%$%g1632916414%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3549735498%_)))))
          (let ((_%__kont3550035501%_
                 (lambda (_%$%g1633116685%_
                          _%$%g1633216687%_
                          _%$%g1633316688%_
                          _%$%g1633416689%_
                          _%$%g1633516690%_
                          _%$%g1633616691%_
                          _%$%g1633716692%_
                          _%$%g1633816693%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'foldl))
                         (cons (cons (let ()
                                       (declare (not safe))
                                       (gx#datum->syntax__0 '#f 'lambda))
                                     (cons (cons _%$%g1633716692%_
                                                 (cons _%$%g1633416689%_ '()))
                                           (cons (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'unless))
                                                       (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'and))
                           (cons (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'list?))
                                       (cons _%$%g1633716692%_ '()))
                                 (cons (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f '=))
                                             (cons (cons (let ()
                                                           (declare (not safe))
                                                           (gx#datum->syntax__0
                                                            '#f
                                                            'length))
                                                         (cons _%$%g1633716692%_
                                                               '()))
                                                   (cons _%$%g1633516690%_
                                                         '())))
                                       '())))
                     (cons (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'error))
                                 (cons '"invalid ASCENT relation row"
                                       (cons _%$%g1633616691%_
                                             (cons _%$%g1633716692%_ '()))))
                           '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'let))
                     (cons (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'next-count))
                                 (cons (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f '+))
                                             (cons _%$%g1633416689%_
                                                   (cons '1 '())))
                                       '()))
                           (cons (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'when))
                                       (cons (cons (let ()
                                                     (declare (not safe))
                                                     (gx#datum->syntax__0
                                                      '#f
                                                      'or))
                                                   (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#datum->syntax__0 '#f '>))
                       (cons (let ()
                               (declare (not safe))
                               (gx#datum->syntax__0 '#f 'next-count))
                             (cons _%$%g1633316688%_ '())))
                 (cons (cons (let ()
                               (declare (not safe))
                               (gx#datum->syntax__0 '#f '>))
                             (cons (let ()
                                     (declare (not safe))
                                     (gx#datum->syntax__0 '#f 'next-count))
                                   (cons _%$%g1633216687%_ '())))
                       '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (cons (cons (let ()
                                                           (declare (not safe))
                                                           (gx#datum->syntax__0
                                                            '#f
                                                            'error))
                                                         (cons '"ASCENT source fact budget exceeded"
                                                               '()))
                                                   '())))
                                 (let ((__tmp35674
                                        (lambda (_%$%g1673116734%_
                                                 _%$%g1673216737%_)
                                          (cons _%$%g1673116734%_
                                                _%$%g1673216737%_)))
                                       (__tmp35673
                                        (cons (let ()
                                                (declare (not safe))
                                                (gx#datum->syntax__0
                                                 '#f
                                                 'next-count))
                                              '())))
                                   (declare (not safe))
                                   (foldr__0
                                    __tmp35674
                                    __tmp35673
                                    _%$%g1633116685%_)))))
               '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                               (cons _%$%g1633416689%_
                                     (cons _%$%g1633816693%_ '()))))))
                (_%__kont3550435505%_
                 (lambda (_%$%g1637816509%_
                          _%$%g1637916511%_
                          _%$%g1638016512%_
                          _%$%g1638116513%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'for-each))
                         (cons (cons (let ()
                                       (declare (not safe))
                                       (gx#datum->syntax__0 '#f 'lambda))
                                     (cons (cons _%$%g1638016512%_ '())
                                           (cons (cons _%$%g1637916511%_
                                                       (cons _%$%g1638016512%_
                                                             '()))
                                                 (let ((__tmp35675
                                                        (lambda (_%$%g1654116544%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%$%g1654216547%_)
                  (cons _%$%g1654116544%_ _%$%g1654216547%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (declare (not safe))
                                                   (foldr__0
                                                    __tmp35675
                                                    '()
                                                    _%$%g1637816509%_)))))
                               (cons _%$%g1638116513%_ '()))))))
            (let* ((_%__match3563235633%_
                    (lambda (_%$%e1638216421%_
                             _%$%hd1638316425%_
                             _%$%tl1638416428%_
                             _%$%e1638516431%_
                             _%$%hd1638616435%_
                             _%$%tl1638716438%_
                             _%$%e1638816441%_
                             _%$%hd1638916445%_
                             _%$%tl1639016448%_
                             _%$%e1639116451%_
                             _%$%hd1639216455%_
                             _%$%tl1639316458%_
                             _%$%e1639416461%_
                             _%$%hd1639516465%_
                             _%$%tl1639616468%_
                             _%$%e1639716471%_
                             _%$%hd1639816475%_
                             _%$%tl1639916478%_
                             _%__splice3550635507%_
                             _%$%target1640016481%_
                             _%$%tl1640216484%_)
                      (letrec ((_%$%loop1640316487%_
                                (lambda (_%$%hd1640116491%_
                                         _%$%body1640716494%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1640116491%_))
                                      (let ((_%$%e1640416496%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1640116491%_))))
                                        (let ((_%$%lp-tl1640616503%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1640416496%_)))
                                              (_%$%lp-hd1640516500%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1640416496%_))))
                                          (_%$%loop1640316487%_
                                           _%$%lp-tl1640616503%_
                                           (cons _%$%lp-hd1640516500%_
                                                 _%$%body1640716494%_))))
                                      (let ((_%$%body1640816506%_
                                             (reverse _%$%body1640716494%_)))
                                        (_%__kont3550435505%_
                                         _%$%body1640816506%_
                                         _%$%hd1639816475%_
                                         _%$%hd1639516465%_
                                         _%$%hd1638916445%_))))))
                        (_%$%loop1640316487%_ _%$%target1640016481%_ '()))))
                   (_%__match3558235583%_
                    (lambda (_%$%e1633916557%_
                             _%$%hd1634016561%_
                             _%$%tl1634116564%_
                             _%$%e1634216567%_
                             _%$%hd1634316571%_
                             _%$%tl1634416574%_
                             _%$%e1634516577%_
                             _%$%hd1634616581%_
                             _%$%tl1634716584%_
                             _%$%e1634816587%_
                             _%$%hd1634916591%_
                             _%$%tl1635016594%_
                             _%$%e1635116597%_
                             _%$%hd1635216601%_
                             _%$%tl1635316604%_
                             _%$%e1635416607%_
                             _%$%hd1635516611%_
                             _%$%tl1635616614%_
                             _%$%e1635716617%_
                             _%$%hd1635816621%_
                             _%$%tl1635916624%_
                             _%$%e1636016627%_
                             _%$%hd1636116631%_
                             _%$%tl1636216634%_
                             _%$%e1636316637%_
                             _%$%hd1636416641%_
                             _%$%tl1636516644%_
                             _%$%e1636616647%_
                             _%$%hd1636716651%_
                             _%$%tl1636816654%_
                             _%__splice3550235503%_
                             _%$%target1636916657%_
                             _%$%tl1637116660%_)
                      (letrec ((_%$%loop1637216663%_
                                (lambda (_%$%hd1637016667%_
                                         _%$%body1637616670%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1637016667%_))
                                      (let ((_%$%e1637316672%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1637016667%_))))
                                        (let ((_%$%lp-tl1637516679%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1637316672%_)))
                                              (_%$%lp-hd1637416676%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1637316672%_))))
                                          (_%$%loop1637216663%_
                                           _%$%lp-tl1637516679%_
                                           (cons _%$%lp-hd1637416676%_
                                                 _%$%body1637616670%_))))
                                      (let ((_%$%body1637716682%_
                                             (reverse _%$%body1637616670%_)))
                                        (_%__kont3550035501%_
                                         _%$%body1637716682%_
                                         _%$%hd1636716651%_
                                         _%$%hd1636416641%_
                                         _%$%hd1636116631%_
                                         _%$%hd1635816621%_
                                         _%$%hd1635516611%_
                                         _%$%hd1635216601%_
                                         _%$%hd1634616581%_))))))
                        (_%$%loop1637216663%_ _%$%target1636916657%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3549735498%_))
                  (let ((_%$%e1633916557%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3549735498%_))))
                    (let ((_%$%tl1634116564%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1633916557%_)))
                          (_%$%hd1634016561%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1633916557%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl1634116564%_))
                          (let ((_%$%e1634216567%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl1634116564%_))))
                            (let ((_%$%tl1634416574%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e1634216567%_)))
                                  (_%$%hd1634316571%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e1634216567%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#identifier? _%$%hd1634316571%_))
                                  (if (let ((__tmp35676
                                             |gerbil-ascent/program/initialization[1]#_g35677_|))
                                        (declare (not safe))
                                        (gx#free-identifier=?
                                         __tmp35676
                                         _%$%hd1634316571%_))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl1634416574%_))
                                          (let ((_%$%e1634516577%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl1634416574%_))))
                                            (let ((_%$%tl1634716584%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e1634516577%_)))
                                                  (_%$%hd1634616581%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e1634516577%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%tl1634716584%_))
                                                  (let ((_%$%e1634816587%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%tl1634716584%_))))
                                                    (let ((_%$%tl1635016594%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e1634816587%_)))
                                                          (_%$%hd1634916591%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e1634816587%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-pair?
                                                             _%$%hd1634916591%_))
                                                          (let ((_%$%e1635116597%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%$%hd1634916591%_))))
                    (let ((_%$%tl1635316604%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1635116597%_)))
                          (_%$%hd1635216601%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1635116597%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl1635316604%_))
                          (let ((_%$%e1635416607%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl1635316604%_))))
                            (let ((_%$%tl1635616614%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e1635416607%_)))
                                  (_%$%hd1635516611%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e1635416607%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%tl1635616614%_))
                                  (let ((_%$%e1635716617%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%tl1635616614%_))))
                                    (let ((_%$%tl1635916624%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e1635716617%_)))
                                          (_%$%hd1635816621%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e1635716617%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl1635916624%_))
                                          (let ((_%$%e1636016627%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl1635916624%_))))
                                            (let ((_%$%tl1636216634%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e1636016627%_)))
                                                  (_%$%hd1636116631%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e1636016627%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%tl1636216634%_))
                                                  (let ((_%$%e1636316637%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%tl1636216634%_))))
                                                    (let ((_%$%tl1636516644%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e1636316637%_)))
                                                          (_%$%hd1636416641%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e1636316637%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-pair?
                                                             _%$%tl1636516644%_))
                                                          (let ((_%$%e1636616647%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%$%tl1636516644%_))))
                    (let ((_%$%tl1636816654%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1636616647%_)))
                          (_%$%hd1636716651%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1636616647%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-null? _%$%tl1636816654%_))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair/null? _%$%tl1635016594%_))
                              (let ((_%__splice3550235503%_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-split-splice->vector
                                        _%$%tl1635016594%_
                                        '0))))
                                (let ((_%$%tl1637116660%_
                                       (let ()
                                         (declare (not safe))
                                         (##vector-ref
                                          _%__splice3550235503%_
                                          '1)))
                                      (_%$%target1636916657%_
                                       (let ()
                                         (declare (not safe))
                                         (##vector-ref
                                          _%__splice3550235503%_
                                          '0))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl1637116660%_))
                                      (_%__match3558235583%_
                                       _%$%e1633916557%_
                                       _%$%hd1634016561%_
                                       _%$%tl1634116564%_
                                       _%$%e1634216567%_
                                       _%$%hd1634316571%_
                                       _%$%tl1634416574%_
                                       _%$%e1634516577%_
                                       _%$%hd1634616581%_
                                       _%$%tl1634716584%_
                                       _%$%e1634816587%_
                                       _%$%hd1634916591%_
                                       _%$%tl1635016594%_
                                       _%$%e1635116597%_
                                       _%$%hd1635216601%_
                                       _%$%tl1635316604%_
                                       _%$%e1635416607%_
                                       _%$%hd1635516611%_
                                       _%$%tl1635616614%_
                                       _%$%e1635716617%_
                                       _%$%hd1635816621%_
                                       _%$%tl1635916624%_
                                       _%$%e1636016627%_
                                       _%$%hd1636116631%_
                                       _%$%tl1636216634%_
                                       _%$%e1636316637%_
                                       _%$%hd1636416641%_
                                       _%$%tl1636516644%_
                                       _%$%e1636616647%_
                                       _%$%hd1636716651%_
                                       _%$%tl1636816654%_
                                       _%__splice3550235503%_
                                       _%$%target1636916657%_
                                       _%$%tl1637116660%_)
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g1632916414%_)))))
                              (let ()
                                (declare (not safe))
                                (_%$%g1632916414%_)))
                          (let () (declare (not safe)) (_%$%g1632916414%_)))))
                  (let () (declare (not safe)) (_%$%g1632916414%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (let ()
                                                    (declare (not safe))
                                                    (_%$%g1632916414%_)))))
                                          (let ()
                                            (declare (not safe))
                                            (_%$%g1632916414%_)))))
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1632916414%_)))))
                          (let () (declare (not safe)) (_%$%g1632916414%_)))))
                  (let () (declare (not safe)) (_%$%g1632916414%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (let ()
                                                    (declare (not safe))
                                                    (_%$%g1632916414%_)))))
                                          (let ()
                                            (declare (not safe))
                                            (_%$%g1632916414%_)))
                                      (if (let ((__tmp35678
                                                 |gerbil-ascent/program/initialization[1]#_g35679_|))
                                            (declare (not safe))
                                            (gx#free-identifier=?
                                             __tmp35678
                                             _%$%hd1634316571%_))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair?
                                                 _%$%tl1634416574%_))
                                              (let ((_%$%e1638816441%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-e
                                                        _%$%tl1634416574%_))))
                                                (let ((_%$%tl1639016448%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##cdr _%$%e1638816441%_)))
                                                      (_%$%hd1638916445%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##car _%$%e1638816441%_))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair?
                                                         _%$%tl1639016448%_))
                                                      (let ((_%$%e1639116451%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-e _%$%tl1639016448%_))))
                (let ((_%$%tl1639316458%_
                       (let () (declare (not safe)) (##cdr _%$%e1639116451%_)))
                      (_%$%hd1639216455%_
                       (let ()
                         (declare (not safe))
                         (##car _%$%e1639116451%_))))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-pair? _%$%hd1639216455%_))
                      (let ((_%$%e1639416461%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-e _%$%hd1639216455%_))))
                        (let ((_%$%tl1639616468%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%$%e1639416461%_)))
                              (_%$%hd1639516465%_
                               (let ()
                                 (declare (not safe))
                                 (##car _%$%e1639416461%_))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair? _%$%tl1639616468%_))
                              (let ((_%$%e1639716471%_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-e _%$%tl1639616468%_))))
                                (let ((_%$%tl1639916478%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%e1639716471%_)))
                                      (_%$%hd1639816475%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%$%e1639716471%_))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl1639916478%_))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair/null?
                                             _%$%tl1639316458%_))
                                          (let ((_%__splice3550635507%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-split-splice->vector
                                                    _%$%tl1639316458%_
                                                    '0))))
                                            (let ((_%$%tl1640216484%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3550635507%_
                                                      '1)))
                                                  (_%$%target1640016481%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3550635507%_
                                                      '0))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl1640216484%_))
                                                  (_%__match3563235633%_
                                                   _%$%e1633916557%_
                                                   _%$%hd1634016561%_
                                                   _%$%tl1634116564%_
                                                   _%$%e1634216567%_
                                                   _%$%hd1634316571%_
                                                   _%$%tl1634416574%_
                                                   _%$%e1638816441%_
                                                   _%$%hd1638916445%_
                                                   _%$%tl1639016448%_
                                                   _%$%e1639116451%_
                                                   _%$%hd1639216455%_
                                                   _%$%tl1639316458%_
                                                   _%$%e1639416461%_
                                                   _%$%hd1639516465%_
                                                   _%$%tl1639616468%_
                                                   _%$%e1639716471%_
                                                   _%$%hd1639816475%_
                                                   _%$%tl1639916478%_
                                                   _%__splice3550635507%_
                                                   _%$%target1640016481%_
                                                   _%$%tl1640216484%_)
                                                  (let ()
                                                    (declare (not safe))
                                                    (_%$%g1632916414%_)))))
                                          (let ()
                                            (declare (not safe))
                                            (_%$%g1632916414%_)))
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g1632916414%_)))))
                              (let ()
                                (declare (not safe))
                                (_%$%g1632916414%_)))))
                      (let () (declare (not safe)) (_%$%g1632916414%_)))))
              (let () (declare (not safe)) (_%$%g1632916414%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g1632916414%_)))
                                          (let ()
                                            (declare (not safe))
                                            (_%$%g1632916414%_))))
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1632916414%_)))))
                          (let () (declare (not safe)) (_%$%g1632916414%_)))))
                  (let () (declare (not safe)) (_%$%g1632916414%_))))))))
    (define |gerbil-ascent/program/initialization[:0:]#initial-source-state|
      (let ((__obj35634
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35634
           'gerbil-ascent/program/initialization#initial-source-state::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35634
           'initial-source-state
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35634
           '(all delta all-size delta-size storage-states seen lattice-rows)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35634
           '(all delta all-size delta-size storage-states seen lattice-rows)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 '#f '13 '#f '#f))
        (let ((__tmp35680 |gerbil-ascent/program/initialization[1]#_g35681_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 __tmp35680 '4 '#f '#f))
        (let ((__tmp35682 |gerbil-ascent/program/initialization[1]#_g35683_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 __tmp35682 '14 '#f '#f))
        (let ((__tmp35684 |gerbil-ascent/program/initialization[1]#_g35685_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 __tmp35684 '15 '#f '#f))
        (let ((__tmp35686
               (cons (cons 'all
                           |gerbil-ascent/program/initialization[1]#_g35687_|)
                     (cons (cons 'delta
                                 |gerbil-ascent/program/initialization[1]#_g35688_|)
                           (cons (cons 'all-size
                                       |gerbil-ascent/program/initialization[1]#_g35689_|)
                                 (cons (cons 'delta-size
                                             |gerbil-ascent/program/initialization[1]#_g35690_|)
                                       (cons (cons 'storage-states
                                                   |gerbil-ascent/program/initialization[1]#_g35691_|)
                                             (cons (cons 'seen
                                                         |gerbil-ascent/program/initialization[1]#_g35692_|)
                                                   (cons (cons 'lattice-rows
                                                               |gerbil-ascent/program/initialization[1]#_g35693_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 __tmp35686 '16 '#f '#f))
        (let ((__tmp35694
               (cons (cons 'all
                           |gerbil-ascent/program/initialization[1]#_g35695_|)
                     (cons (cons 'delta
                                 |gerbil-ascent/program/initialization[1]#_g35696_|)
                           (cons (cons 'all-size
                                       |gerbil-ascent/program/initialization[1]#_g35697_|)
                                 (cons (cons 'delta-size
                                             |gerbil-ascent/program/initialization[1]#_g35698_|)
                                       (cons (cons 'storage-states
                                                   |gerbil-ascent/program/initialization[1]#_g35699_|)
                                             (cons (cons 'seen
                                                         |gerbil-ascent/program/initialization[1]#_g35700_|)
                                                   (cons (cons 'lattice-rows
                                                               |gerbil-ascent/program/initialization[1]#_g35701_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 __tmp35694 '17 '#f '#f))
        (let ((__tmp35702
               (cons (cons 'all
                           |gerbil-ascent/program/initialization[1]#_g35703_|)
                     (cons (cons 'delta
                                 |gerbil-ascent/program/initialization[1]#_g35704_|)
                           (cons (cons 'all-size
                                       |gerbil-ascent/program/initialization[1]#_g35705_|)
                                 (cons (cons 'delta-size
                                             |gerbil-ascent/program/initialization[1]#_g35706_|)
                                       (cons (cons 'storage-states
                                                   |gerbil-ascent/program/initialization[1]#_g35707_|)
                                             (cons (cons 'seen
                                                         |gerbil-ascent/program/initialization[1]#_g35708_|)
                                                   (cons (cons 'lattice-rows
                                                               |gerbil-ascent/program/initialization[1]#_g35709_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 __tmp35702 '18 '#f '#f))
        (let ((__tmp35710
               (cons (cons 'all
                           |gerbil-ascent/program/initialization[1]#_g35711_|)
                     (cons (cons 'delta
                                 |gerbil-ascent/program/initialization[1]#_g35712_|)
                           (cons (cons 'all-size
                                       |gerbil-ascent/program/initialization[1]#_g35713_|)
                                 (cons (cons 'delta-size
                                             |gerbil-ascent/program/initialization[1]#_g35714_|)
                                       (cons (cons 'storage-states
                                                   |gerbil-ascent/program/initialization[1]#_g35715_|)
                                             (cons (cons 'seen
                                                         |gerbil-ascent/program/initialization[1]#_g35716_|)
                                                   (cons (cons 'lattice-rows
                                                               |gerbil-ascent/program/initialization[1]#_g35717_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 __tmp35710 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 '() '21 '#f '#f))
        __obj35634))))
