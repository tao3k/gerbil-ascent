(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/tools/research/candidate-interaction::timestamp
    1791693101)
  (begin
    (define gerbil-ascent/tools/research/candidate-interaction#edges
      '((0 1) (0 2) (1 0) (1 2) (2 0) (2 1)))
    (define gerbil-ascent/tools/research/candidate-interaction#ordinals
      (lambda (_%n2542%_)
        (let _%loop2544%_ ((_%i2546%_ '0))
          (if (= _%i2546%_ _%n2542%_)
              '()
              (cons _%i2546%_ (_%loop2544%_ (+ _%i2546%_ '1)))))))
    (define gerbil-ascent/tools/research/candidate-interaction#graph
      (lambda (_%mask2537%_)
        (let ((__tmp5370
               (lambda (_%edge2539%_ _%index2540%_)
                 (if (zero? (bitwise-and
                             _%mask2537%_
                             (arithmetic-shift '1 _%index2540%_)))
                     '#f
                     _%edge2539%_)))
              (__tmp5369
               (gerbil-ascent/tools/research/candidate-interaction#ordinals
                '6)))
          (declare (not safe))
          (filter-map__1
           __tmp5370
           gerbil-ascent/tools/research/candidate-interaction#edges
           __tmp5369))))
    (define gerbil-ascent/tools/research/candidate-interaction#walk
      (lambda (_%pairs2511%_ _%origin2512%_ _%even?2513%_)
        (let _%loop2515%_ ((_%pending2517%_
                            (let ((__tmp5378
                                   (lambda (_%e2533%_)
                                     (list (cadr _%e2533%_) '1)))
                                  (__tmp5377
                                   (filter (lambda (_%e2535%_)
                                             (= _%origin2512%_
                                                (car _%e2535%_)))
                                           _%pairs2511%_)))
                              (declare (not safe))
                              (##map __tmp5378 __tmp5377)))
                           (_%seen2518%_ '()))
          (if (null? _%pending2517%_)
              (let ((__tmp5371
                     (lambda (_%v2520%_)
                       (if (let ((__tmp5372
                                  (lambda (_%s2522%_)
                                    (and (= _%v2520%_ (car _%s2522%_))
                                         (or (not _%even?2513%_)
                                             (= '0 (cadr _%s2522%_)))))))
                             (declare (not safe))
                             (ormap__0 __tmp5372 _%seen2518%_))
                           _%v2520%_
                           '#f))))
                (declare (not safe))
                (filter-map__0 __tmp5371 '(0 1 2)))
              (let ((_%s2527%_ (car _%pending2517%_)))
                (if (member _%s2527%_ _%seen2518%_)
                    (_%loop2515%_ (cdr _%pending2517%_) _%seen2518%_)
                    (_%loop2515%_
                     (let ((__tmp5376 (cdr _%pending2517%_))
                           (__tmp5373
                            (let ((__tmp5375
                                   (lambda (_%e2529%_)
                                     (list (cadr _%e2529%_)
                                           (- '1 (cadr _%s2527%_)))))
                                  (__tmp5374
                                   (filter (lambda (_%e2531%_)
                                             (= (car _%s2527%_)
                                                (car _%e2531%_)))
                                           _%pairs2511%_)))
                              (declare (not safe))
                              (##map __tmp5375 __tmp5374))))
                       (declare (not safe))
                       (##append __tmp5376 __tmp5373))
                     (cons _%s2527%_ _%seen2518%_))))))))
    (define gerbil-ascent/tools/research/candidate-interaction#expected
      (lambda (_%case-id2502%_ _%pairs2503%_)
        (if (= _%case-id2502%_ '2)
            (let ((__tmp5379
                   (filter (lambda (_%v2505%_)
                             (member _%v2505%_
                                     (gerbil-ascent/tools/research/candidate-interaction#walk
                                      _%pairs2503%_
                                      '1
                                      '#f)))
                           (gerbil-ascent/tools/research/candidate-interaction#walk
                            _%pairs2503%_
                            '0
                            '#f))))
              (declare (not safe))
              (##map list __tmp5379))
            (let ((__tmp5380
                   (let ((__tmp5381
                          (lambda (_%u2507%_)
                            (map (lambda (_%v2509%_)
                                   (list _%u2507%_ _%v2509%_))
                                 (gerbil-ascent/tools/research/candidate-interaction#walk
                                  _%pairs2503%_
                                  _%u2507%_
                                  (= _%case-id2502%_ '1))))))
                     (declare (not safe))
                     (##map __tmp5381 '(0 1 2)))))
              (declare (not safe))
              (##apply append __tmp5380)))))
    (define gerbil-ascent/tools/research/candidate-interaction#proposal__%
      (lambda (_%case-id2484%_ _%rules2485%_ _%row-budget2486%_)
        (let ((__tmp5384 (if (= _%case-id2484%_ '2) '((relation both 1)) '()))
              (__tmp5383
               (map (lambda (_%r2488%_) (cons 'rule _%r2488%_)) _%rules2485%_))
              (__tmp5382
               (list (if (= _%case-id2484%_ '2)
                         '(query both ?z)
                         '(query path ?x ?y))
                     (list 'limits '16 _%row-budget2486%_ '128))))
          (declare (not safe))
          (##append
           '(candidate (relation path 2))
           __tmp5384
           __tmp5383
           __tmp5382))))
    (define gerbil-ascent/tools/research/candidate-interaction#proposal__0
      (lambda (_%case-id2493%_ _%rules2494%_)
        (let ((_%row-budget2496%_ '64))
          (gerbil-ascent/tools/research/candidate-interaction#proposal__%
           _%case-id2493%_
           _%rules2494%_
           _%row-budget2496%_))))
    (define gerbil-ascent/tools/research/candidate-interaction#proposal
      (lambda _g5385_
        (let ((_g5386_ (let () (declare (not safe)) (##length _g5385_))))
          (cond ((let () (declare (not safe)) (##fx= _g5386_ 2))
                 (apply gerbil-ascent/tools/research/candidate-interaction#proposal__0
                        _g5385_))
                ((let () (declare (not safe)) (##fx= _g5386_ 3))
                 (apply gerbil-ascent/tools/research/candidate-interaction#proposal__%
                        _g5385_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/tools/research/candidate-interaction#proposal
                  _g5385_))))))
    (define gerbil-ascent/tools/research/candidate-interaction#source
      (lambda (_%case-id2479%_ _%generation2480%_ _%pairs2481%_)
        (let ((__tmp5390
               (let ((__tmp5391 (number->string _%case-id2479%_)))
                 (declare (not safe))
                 (##string-append '"library-candidate-" __tmp5391)))
              (__tmp5387
               (let ((__tmp5389 (list (list 'edge '2 _%pairs2481%_)))
                     (__tmp5388
                      (if (= _%case-id2479%_ '2)
                          '((left 1 ((0))) (right 1 ((1))))
                          '())))
                 (declare (not safe))
                 (##append __tmp5389 __tmp5388))))
          (declare (not safe))
          (gerbil-ascent/candidate/reasoning#reasoning-source-snapshot
           __tmp5390
           _%generation2480%_
           __tmp5387))))
    (define gerbil-ascent/tools/research/candidate-interaction#wire
      (lambda (_%x2474%_)
        (if (symbol? _%x2474%_)
            (let () (declare (not safe)) (##symbol->string _%x2474%_))
            (if (pair? _%x2474%_)
                (let ()
                  (declare (not safe))
                  (##map gerbil-ascent/tools/research/candidate-interaction#wire
                         _%x2474%_))
                _%x2474%_))))
    (define gerbil-ascent/tools/research/candidate-interaction#symbols
      (lambda (_%x2468%_)
        (if (string? _%x2468%_)
            (let () (declare (not safe)) (##string->symbol _%x2468%_))
            (if (list? _%x2468%_)
                (let ()
                  (declare (not safe))
                  (##map gerbil-ascent/tools/research/candidate-interaction#symbols
                         _%x2468%_))
                (if (and (integer? _%x2468%_) (exact? _%x2468%_))
                    _%x2468%_
                    (let ()
                      (declare (not safe))
                      (error '"invalid rule datum")))))))
    (define gerbil-ascent/tools/research/candidate-interaction#observe
      (lambda (_%case-id2444%_ _%generation2445%_ _%pairs2446%_ _%rules2447%_)
        (let* ((_%s2449%_
                (gerbil-ascent/tools/research/candidate-interaction#source
                 _%case-id2444%_
                 _%generation2445%_
                 _%pairs2446%_))
               (_%p2451%_
                (gerbil-ascent/tools/research/candidate-interaction#proposal__0
                 _%case-id2444%_
                 _%rules2447%_))
               (_%r2453%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                   _%s2449%_
                   _%p2451%_
                   '#f)))
               (_%wanted2455%_
                (gerbil-ascent/tools/research/candidate-interaction#expected
                 _%case-id2444%_
                 _%pairs2446%_))
               (_%f2457%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                   _%s2449%_
                   _%p2451%_
                   _%r2453%_
                   _%wanted2455%_)))
               (_%ht2460%_
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   '10
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value))))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht2460%_ '"generation" _%generation2445%_))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht2460%_ '"edges" _%pairs2446%_))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht2460%_ '"expected" _%wanted2455%_))
          (let ((__tmp5392
                 (gerbil-ascent/tools/research/candidate-interaction#wire
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%r2453%_ '1 '#f '#f)))))
            (declare (not safe))
            (__hash-put! _%ht2460%_ '"nativeStatus" __tmp5392))
          (let ((__tmp5393
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%r2453%_ '7 '#f '#f))))
            (declare (not safe))
            (__hash-put! _%ht2460%_ '"actual" __tmp5393))
          (let ((__tmp5394
                 (gerbil-ascent/tools/research/candidate-interaction#wire
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%f2457%_ '1 '#f '#f)))))
            (declare (not safe))
            (__hash-put! _%ht2460%_ '"status" __tmp5394))
          (let ((__tmp5395
                 (map (lambda (_%d2463%_)
                        (let ((_%ht2465%_
                               (let ()
                                 (declare (not safe))
                                 (make-hash-table__%
                                  '#f
                                  '2
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value))))
                          (let ((__tmp5396
                                 (gerbil-ascent/tools/research/candidate-interaction#wire
                                  (##structure-ref
                                   _%d2463%_
                                   '1
                                   gerbil-ascent/candidate/types#reasoning-diagnostic::t
                                   '#f))))
                            (declare (not safe))
                            (__hash-put! _%ht2465%_ '"code" __tmp5396))
                          (let ((__tmp5397
                                 (##structure-ref
                                  _%d2463%_
                                  '3
                                  gerbil-ascent/candidate/types#reasoning-diagnostic::t
                                  '#f)))
                            (declare (not safe))
                            (__hash-put! _%ht2465%_ '"detail" __tmp5397))
                          _%ht2465%_))
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref _%r2453%_ '8 '#f '#f)))))
            (declare (not safe))
            (__hash-put! _%ht2460%_ '"diagnostics" __tmp5395))
          (let ((__tmp5398
                 (gerbil-ascent/tools/research/candidate-interaction#wire
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%f2457%_ '2 '#f '#f)))))
            (declare (not safe))
            (__hash-put! _%ht2460%_ '"reason" __tmp5398))
          (let ((__tmp5399
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%f2457%_ '3 '#f '#f))))
            (declare (not safe))
            (__hash-put! _%ht2460%_ '"missing" __tmp5399))
          (let ((__tmp5400
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%f2457%_ '4 '#f '#f))))
            (declare (not safe))
            (__hash-put! _%ht2460%_ '"extra" __tmp5400))
          _%ht2460%_)))
    (define gerbil-ascent/tools/research/candidate-interaction#correct
      '(((path ?x ?y) (edge ?x ?y)) ((path ?x ?z) (path ?x ?y) (edge ?y ?z))))
    (define gerbil-ascent/tools/research/candidate-interaction#even-rules
      '(((path ?x ?z) (edge ?x ?y) (edge ?y ?z))
        ((path ?x ?w) (path ?x ?y) (edge ?y ?z) (edge ?z ?w))))
    (define gerbil-ascent/tools/research/candidate-interaction#both-rules
      (let ()
        (declare (not safe))
        (##append
         gerbil-ascent/tools/research/candidate-interaction#correct
         '(((both ?z) (left ?x) (right ?y) (path ?x ?z) (path ?y ?z))))))
    (define gerbil-ascent/tools/research/candidate-interaction#grade
      (lambda (_%case-id2437%_ _%rules2438%_)
        (let ((__tmp5404
               (lambda (_%mask2440%_)
                 (gerbil-ascent/tools/research/candidate-interaction#observe
                  _%case-id2437%_
                  _%mask2440%_
                  (gerbil-ascent/tools/research/candidate-interaction#graph
                   _%mask2440%_)
                  _%rules2438%_)))
              (__tmp5401
               (let ((__tmp5403
                      (lambda (_%mask2442%_)
                        (not (let ()
                               (declare (not safe))
                               (##member _%mask2442%_ '(0 1 3 9))))))
                     (__tmp5402
                      (gerbil-ascent/tools/research/candidate-interaction#ordinals
                       '64)))
                 (declare (not safe))
                 (##filter __tmp5403 __tmp5402))))
          (declare (not safe))
          (##map __tmp5404 __tmp5401))))
    (define gerbil-ascent/tools/research/candidate-interaction#qualification
      (lambda (_%group2319%_)
        (let ((_%checks2321%_ '0)
              (_%mutants2322%_
               (list gerbil-ascent/tools/research/candidate-interaction#correct
                     (let ()
                       (declare (not safe))
                       (##cdr gerbil-ascent/tools/research/candidate-interaction#correct))
                     (list (let ()
                             (declare (not safe))
                             (##car gerbil-ascent/tools/research/candidate-interaction#correct)))
                     '(((path ?x ?y) (edge ?x ?y))
                       ((path ?x ?z) (path ?x ?y) (edge ?x ?z)))
                     '(((path ?x ?y) (edge ?y ?x))
                       ((path ?x ?z) (path ?x ?y) (edge ?y ?z))))))
          (let ((__tmp5406
                 (lambda (_%rules2324%_ _%index2325%_)
                   (if (= _%group2319%_ _%index2325%_)
                       (let ((_%mismatches2327%_ '0))
                         (let ((__tmp5408
                                (lambda (_%mask2329%_)
                                  (let ((_%r2331%_
                                         (gerbil-ascent/tools/research/candidate-interaction#observe
                                          '0
                                          _%mask2329%_
                                          (gerbil-ascent/tools/research/candidate-interaction#graph
                                           _%mask2329%_)
                                          _%rules2324%_)))
                                    (if (string=?
                                         (let* ((_%h2333%_ _%r2331%_)
                                                (_%key2336%_ '"nativeStatus")
                                                (_%default2339%_ absent-obj)
                                                (_%h2343%_ _%h2333%_)
                                                (_%h2345%_ _%h2343%_))
                                           (declare (not safe))
                                           (__hash-ref__%
                                            _%h2345%_
                                            _%key2336%_
                                            _%default2339%_))
                                         '"complete")
                                        '#!void
                                        (let ()
                                          (declare (not safe))
                                          (error '"incomplete control"
                                                 _%r2331%_)))
                                    (if (string=?
                                         (let* ((_%h2363%_ _%r2331%_)
                                                (_%key2366%_ '"status")
                                                (_%default2369%_ absent-obj)
                                                (_%h2373%_ _%h2363%_)
                                                (_%h2375%_ _%h2373%_))
                                           (declare (not safe))
                                           (__hash-ref__%
                                            _%h2375%_
                                            _%key2366%_
                                            _%default2369%_))
                                         '"match")
                                        '#!void
                                        (set! _%mismatches2327%_
                                              (+ _%mismatches2327%_ '1)))
                                    (set! _%checks2321%_
                                          (+ _%checks2321%_ '1)))))
                               (__tmp5407
                                (gerbil-ascent/tools/research/candidate-interaction#ordinals
                                 '64)))
                           (declare (not safe))
                           (##for-each __tmp5408 __tmp5407))
                         (if (if (= _%index2325%_ '0)
                                 (= _%mismatches2327%_ '0)
                                 (> _%mismatches2327%_ '0))
                             '#!void
                             (let ()
                               (declare (not safe))
                               (error '"mutant control failed"))))
                       '#!void)))
                (__tmp5405
                 (gerbil-ascent/tools/research/candidate-interaction#ordinals
                  '5)))
            (declare (not safe))
            (##for-each __tmp5406 _%mutants2322%_ __tmp5405))
          (let ((__tmp5410
                 (lambda (_%id2387%_ _%rules2388%_)
                   (if (= _%group2319%_ (+ _%id2387%_ '4))
                       (let ((__tmp5412
                              (lambda (_%mask2390%_)
                                (if (string=?
                                     (let* ((_%h2392%_
                                             (gerbil-ascent/tools/research/candidate-interaction#observe
                                              _%id2387%_
                                              _%mask2390%_
                                              (gerbil-ascent/tools/research/candidate-interaction#graph
                                               _%mask2390%_)
                                              _%rules2388%_))
                                            (_%key2395%_ '"status")
                                            (_%default2398%_ absent-obj)
                                            (_%h2402%_ _%h2392%_)
                                            (_%h2404%_ _%h2402%_))
                                       (declare (not safe))
                                       (__hash-ref__%
                                        _%h2404%_
                                        _%key2395%_
                                        _%default2398%_))
                                     '"match")
                                    '#!void
                                    (let ()
                                      (declare (not safe))
                                      (error '"independent walk disagrees")))
                                (set! _%checks2321%_ (+ _%checks2321%_ '1))))
                             (__tmp5411
                              (gerbil-ascent/tools/research/candidate-interaction#ordinals
                               '64)))
                         (declare (not safe))
                         (##for-each __tmp5412 __tmp5411))
                       '#!void)))
                (__tmp5409
                 (list gerbil-ascent/tools/research/candidate-interaction#even-rules
                       gerbil-ascent/tools/research/candidate-interaction#both-rules)))
            (declare (not safe))
            (##for-each __tmp5410 '(1 2) __tmp5409))
          (if (= _%group2319%_ '7)
              (begin
                (let* ((_%s2418%_
                        (gerbil-ascent/tools/research/candidate-interaction#source
                         '0
                         '0
                         (gerbil-ascent/tools/research/candidate-interaction#graph
                          '8)))
                       (_%p2420%_
                        (gerbil-ascent/tools/research/candidate-interaction#proposal__0
                         '0
                         gerbil-ascent/tools/research/candidate-interaction#correct))
                       (_%r2422%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                           _%s2418%_
                           _%p2420%_
                           '#f))))
                  (if (eq? (let ((__tmp5413
                                  (let ((__tmp5415
                                         (gerbil-ascent/tools/research/candidate-interaction#source
                                          '0
                                          '1
                                          (gerbil-ascent/tools/research/candidate-interaction#graph
                                           '8)))
                                        (__tmp5414
                                         (gerbil-ascent/tools/research/candidate-interaction#expected
                                          '0
                                          (gerbil-ascent/tools/research/candidate-interaction#graph
                                           '8))))
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                                     __tmp5415
                                     _%p2420%_
                                     _%r2422%_
                                     __tmp5414))))
                             (declare (not safe))
                             (##unchecked-structure-ref __tmp5413 '2 '#f '#f))
                           'unbound)
                      '#!void
                      (let ()
                        (declare (not safe))
                        (error '"stale receipt accepted"))))
                (let* ((_%s2425%_
                        (gerbil-ascent/tools/research/candidate-interaction#source
                         '0
                         '0
                         (gerbil-ascent/tools/research/candidate-interaction#graph
                          '9)))
                       (_%p2427%_
                        (gerbil-ascent/tools/research/candidate-interaction#proposal__%
                         '0
                         gerbil-ascent/tools/research/candidate-interaction#correct
                         '1))
                       (_%r2429%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                           _%s2425%_
                           _%p2427%_
                           '#f)))
                       (_%f2431%_
                        (let ((__tmp5416
                               (gerbil-ascent/tools/research/candidate-interaction#expected
                                '0
                                (gerbil-ascent/tools/research/candidate-interaction#graph
                                 '9))))
                          (declare (not safe))
                          (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                           _%s2425%_
                           _%p2427%_
                           _%r2429%_
                           __tmp5416))))
                  (if (eq? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref _%f2431%_ '1 '#f '#f))
                           'match)
                      (let ()
                        (declare (not safe))
                        (error '"bounded failure became match"))
                      '#!void)))
              '#!void)
          (let ((_%ht2434%_
                 (let ()
                   (declare (not safe))
                   (make-hash-table__%
                    '#f
                    '3
                    absent-value
                    absent-value
                    absent-value
                    absent-value
                    absent-value
                    absent-value
                    absent-value))))
            (let ()
              (declare (not safe))
              (__hash-put! _%ht2434%_ '"checks" _%checks2321%_))
            (let ((__tmp5417 (= _%group2319%_ '7)))
              (declare (not safe))
              (__hash-put! _%ht2434%_ '"staleRejected" __tmp5417))
            (let ((__tmp5418 (= _%group2319%_ '7)))
              (declare (not safe))
              (__hash-put! _%ht2434%_ '"boundedNotMatch" __tmp5418))
            _%ht2434%_))))
    (define gerbil-ascent/tools/research/candidate-interaction#dispatch
      (lambda (_%request2199%_)
        (let ((_%op2226%_
               (let* ((_%h2201%_ _%request2199%_)
                      (_%key2204%_ '"op")
                      (_%default2207%_ absent-obj)
                      (_%h2211%_
                       (let ()
                         (declare (not safe))
                         (cast HashTable::interface _%h2201%_)))
                      (_%h2213%_ _%h2211%_))
                 (declare (not safe))
                 (__hash-ref__% _%h2213%_ _%key2204%_ _%default2207%_))))
          (if (string=? _%op2226%_ '"reuse-init")
              (gerbil-ascent/tools/research/candidate-interaction#reuse-init
               _%request2199%_)
              (if (string=? _%op2226%_ '"reuse-packet")
                  (gerbil-ascent/tools/research/candidate-interaction#reuse-packet
                   _%request2199%_)
                  (if (string=? _%op2226%_ '"reuse-episode")
                      (gerbil-ascent/tools/research/candidate-interaction#reuse-episode
                       _%request2199%_)
                      (if (string=? _%op2226%_ '"qualify")
                          (gerbil-ascent/tools/research/candidate-interaction#qualification
                           (let* ((_%h2232%_ _%request2199%_)
                                  (_%key2235%_ '"group")
                                  (_%default2238%_ absent-obj)
                                  (_%h2242%_
                                   (let ()
                                     (declare (not safe))
                                     (cast HashTable::interface _%h2232%_)))
                                  (_%h2244%_ _%h2242%_))
                             (declare (not safe))
                             (__hash-ref__%
                              _%h2244%_
                              _%key2235%_
                              _%default2238%_)))
                          (let* ((_%id2284%_
                                  (let* ((_%h2259%_ _%request2199%_)
                                         (_%key2262%_ '"case")
                                         (_%default2265%_ absent-obj)
                                         (_%h2269%_
                                          (let ()
                                            (declare (not safe))
                                            (cast HashTable::interface
                                                  _%h2259%_)))
                                         (_%h2271%_ _%h2269%_))
                                    (declare (not safe))
                                    (__hash-ref__%
                                     _%h2271%_
                                     _%key2262%_
                                     _%default2265%_)))
                                 (_%rules2311%_
                                  (gerbil-ascent/tools/research/candidate-interaction#symbols
                                   (let* ((_%h2286%_ _%request2199%_)
                                          (_%key2289%_ '"rules")
                                          (_%default2292%_ absent-obj)
                                          (_%h2296%_
                                           (let ()
                                             (declare (not safe))
                                             (cast HashTable::interface
                                                   _%h2286%_)))
                                          (_%h2298%_ _%h2296%_))
                                     (declare (not safe))
                                     (__hash-ref__%
                                      _%h2298%_
                                      _%key2289%_
                                      _%default2292%_)))))
                            (if (let ()
                                  (declare (not safe))
                                  (##member _%id2284%_ '(0 1 2)))
                                '#!void
                                (let ()
                                  (declare (not safe))
                                  (error '"invalid case")))
                            (if (string=? _%op2226%_ '"grade")
                                (gerbil-ascent/tools/research/candidate-interaction#grade
                                 _%id2284%_
                                 _%rules2311%_)
                                (if (string=? _%op2226%_ '"feedback")
                                    (let ((__tmp5419
                                           (lambda (_%mask2316%_)
                                             (gerbil-ascent/tools/research/candidate-interaction#observe
                                              _%id2284%_
                                              _%mask2316%_
                                              (gerbil-ascent/tools/research/candidate-interaction#graph
                                               _%mask2316%_)
                                              _%rules2311%_))))
                                      (declare (not safe))
                                      (##map __tmp5419 '(0 1 3 9)))
                                    (let ()
                                      (declare (not safe))
                                      (error '"invalid operation"))))))))))))
    (define gerbil-ascent/tools/research/candidate-interaction#reuse-store '#f)
    (define gerbil-ascent/tools/research/candidate-interaction#reuse-source
      '#f)
    (define gerbil-ascent/tools/research/candidate-interaction#reuse-handle
      '#f)
    (define gerbil-ascent/tools/research/candidate-interaction#reuse-needs '())
    (define gerbil-ascent/tools/research/candidate-interaction#reuse-candidate
      '(candidate
        (relation path 2)
        (relation ready 1)
        (rule (path ?x ?y) (edge ?x ?y))
        (rule (path ?x ?z) (path ?x ?y) (edge ?y ?z))
        (rule (ready ?f) (need ?f ?u ?v ?x ?y) (path ?u ?v) (path ?x ?y))
        (query ready ?f)
        (limits 256 1024 1024)))
    (define gerbil-ascent/tools/research/candidate-interaction#field
      (lambda (_%key2196%_ _%pairs2197%_)
        (cadr (assq _%key2196%_ _%pairs2197%_))))
    (define gerbil-ascent/tools/research/candidate-interaction#reuse-init
      (lambda (_%request2116%_)
        (set! gerbil-ascent/tools/research/candidate-interaction#reuse-store
              (let ()
                (declare (not safe))
                (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__0)))
        (set! gerbil-ascent/tools/research/candidate-interaction#reuse-needs
              (let* ((_%h2118%_ _%request2116%_)
                     (_%key2121%_ '"needs")
                     (_%default2124%_ absent-obj)
                     (_%h2128%_
                      (let ()
                        (declare (not safe))
                        (cast HashTable::interface _%h2118%_)))
                     (_%h2130%_ _%h2128%_))
                (declare (not safe))
                (__hash-ref__% _%h2130%_ _%key2121%_ _%default2124%_)))
        (set! gerbil-ascent/tools/research/candidate-interaction#reuse-source
              (let ((__tmp5421
                     (let* ((_%h2143%_ _%request2116%_)
                            (_%key2146%_ '"identity")
                            (_%default2149%_ absent-obj)
                            (_%h2153%_
                             (let ()
                               (declare (not safe))
                               (cast HashTable::interface _%h2143%_)))
                            (_%h2155%_ _%h2153%_))
                       (declare (not safe))
                       (__hash-ref__% _%h2155%_ _%key2146%_ _%default2149%_)))
                    (__tmp5420
                     (list (list 'edge
                                 '2
                                 (let* ((_%h2167%_ _%request2116%_)
                                        (_%key2170%_ '"edges")
                                        (_%default2173%_ absent-obj)
                                        (_%h2177%_
                                         (let ()
                                           (declare (not safe))
                                           (cast HashTable::interface
                                                 _%h2167%_)))
                                        (_%h2179%_ _%h2177%_))
                                   (declare (not safe))
                                   (__hash-ref__%
                                    _%h2179%_
                                    _%key2170%_
                                    _%default2173%_)))
                           (list 'need
                                 '5
                                 gerbil-ascent/tools/research/candidate-interaction#reuse-needs))))
                (declare (not safe))
                (gerbil-ascent/candidate/reasoning#reasoning-source-snapshot
                 __tmp5421
                 '0
                 __tmp5420)))
        (let ((_%answer2191%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                  gerbil-ascent/tools/research/candidate-interaction#reuse-store
                  gerbil-ascent/tools/research/candidate-interaction#reuse-source
                  gerbil-ascent/tools/research/candidate-interaction#reuse-candidate))))
          (if (eq? (gerbil-ascent/tools/research/candidate-interaction#field
                    'status
                    _%answer2191%_)
                   'verified)
              '#!void
              (let ()
                (declare (not safe))
                (error '"unverified source" _%answer2191%_)))
          (set! gerbil-ascent/tools/research/candidate-interaction#reuse-handle
                (gerbil-ascent/tools/research/candidate-interaction#field
                 'handle
                 _%answer2191%_))
          (let ((_%ht2193%_
                 (let ()
                   (declare (not safe))
                   (make-hash-table__%
                    '#f
                    '2
                    absent-value
                    absent-value
                    absent-value
                    absent-value
                    absent-value
                    absent-value
                    absent-value))))
            (let ((__tmp5422
                   (gerbil-ascent/tools/research/candidate-interaction#field
                    'rows
                    _%answer2191%_)))
              (declare (not safe))
              (__hash-put! _%ht2193%_ '"rows" __tmp5422))
            (let ((__tmp5423
                   (gerbil-ascent/tools/research/candidate-interaction#wire
                    (gerbil-ascent/tools/research/candidate-interaction#field
                     'scope
                     _%answer2191%_))))
              (declare (not safe))
              (__hash-put! _%ht2193%_ '"scope" __tmp5423))
            _%ht2193%_))))
    (define gerbil-ascent/tools/research/candidate-interaction#reuse-fact
      (lambda (_%atom2114%_)
        (let ()
          (declare (not safe))
          (gerbil-ascent/candidate/evidence-store#reasoning-evidence-fact
           gerbil-ascent/tools/research/candidate-interaction#reuse-store
           gerbil-ascent/tools/research/candidate-interaction#reuse-source
           gerbil-ascent/tools/research/candidate-interaction#reuse-candidate
           gerbil-ascent/tools/research/candidate-interaction#reuse-handle
           _%atom2114%_))))
    (define gerbil-ascent/tools/research/candidate-interaction#reuse-packet
      (lambda (_%request2038%_)
        (let* ((_%ids2065%_
                (let* ((_%h2040%_ _%request2038%_)
                       (_%key2043%_ '"fragments")
                       (_%default2046%_ absent-obj)
                       (_%h2050%_
                        (let ()
                          (declare (not safe))
                          (cast HashTable::interface _%h2040%_)))
                       (_%h2052%_ _%h2050%_))
                  (declare (not safe))
                  (__hash-ref__% _%h2052%_ _%key2043%_ _%default2046%_)))
               (_%answer2067%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                   gerbil-ascent/tools/research/candidate-interaction#reuse-store
                   gerbil-ascent/tools/research/candidate-interaction#reuse-source
                   gerbil-ascent/tools/research/candidate-interaction#reuse-candidate)))
               (_%atoms2077%_
                (let ((_%seen2069%_ '()))
                  (for-each
                   (lambda (_%id2071%_)
                     (let ((_%n2073%_
                            (assoc _%id2071%_
                                   gerbil-ascent/tools/research/candidate-interaction#reuse-needs)))
                       (if _%n2073%_
                           '#!void
                           (let ()
                             (declare (not safe))
                             (error '"unknown fragment" _%id2071%_)))
                       (let ((__tmp5425
                              (lambda (_%a2075%_)
                                (if (let ()
                                      (declare (not safe))
                                      (##member _%a2075%_ _%seen2069%_))
                                    '#!void
                                    (set! _%seen2069%_
                                          (cons _%a2075%_ _%seen2069%_)))))
                             (__tmp5424
                              (list (list 'ready _%id2071%_)
                                    (list 'path
                                          (list-ref _%n2073%_ '1)
                                          (list-ref _%n2073%_ '2))
                                    (list 'path
                                          (list-ref _%n2073%_ '3)
                                          (list-ref _%n2073%_ '4)))))
                         (declare (not safe))
                         (##for-each __tmp5425 __tmp5424))))
                   _%ids2065%_)
                  (let () (declare (not safe)) (##reverse _%seen2069%_))))
               (_%facts2079%_
                (let ()
                  (declare (not safe))
                  (##map gerbil-ascent/tools/research/candidate-interaction#reuse-fact
                         _%atoms2077%_)))
               (_%alternatives2083%_
                (map (lambda (_%id2081%_)
                       (list _%id2081%_ (list (list 'ready _%id2081%_))))
                     _%ids2065%_))
               (_%partition2085%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/evidence-store#reasoning-evidence-partition
                   gerbil-ascent/tools/research/candidate-interaction#reuse-store
                   gerbil-ascent/tools/research/candidate-interaction#reuse-source
                   gerbil-ascent/tools/research/candidate-interaction#reuse-candidate
                   gerbil-ascent/tools/research/candidate-interaction#reuse-handle
                   _%alternatives2083%_)))
               (_%pieces2089%_
                (map (lambda (_%id2087%_)
                       (let ((__tmp5426 (list 'ready _%id2087%_)))
                         (declare (not safe))
                         (gerbil-ascent/candidate/evidence-store#reasoning-evidence-fragment
                          gerbil-ascent/tools/research/candidate-interaction#reuse-store
                          gerbil-ascent/tools/research/candidate-interaction#reuse-source
                          gerbil-ascent/tools/research/candidate-interaction#reuse-candidate
                          gerbil-ascent/tools/research/candidate-interaction#reuse-handle
                          __tmp5426)))
                     _%ids2065%_))
               (_%nodes2097%_
                (let ((_%seen2091%_ '()))
                  (let ((__tmp5427
                         (lambda (_%piece2093%_)
                           (if (eq? (gerbil-ascent/tools/research/candidate-interaction#field
                                     'status
                                     _%piece2093%_)
                                    'verified)
                               (for-each
                                (lambda (_%node2095%_)
                                  (if (assoc (car _%node2095%_) _%seen2091%_)
                                      '#!void
                                      (set! _%seen2091%_
                                            (cons _%node2095%_ _%seen2091%_))))
                                (gerbil-ascent/tools/research/candidate-interaction#field
                                 'nodes
                                 _%piece2093%_))
                               '#!void))))
                    (declare (not safe))
                    (##for-each __tmp5427 _%pieces2089%_))
                  (let () (declare (not safe)) (##reverse _%seen2091%_))))
               (_%ht2100%_
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   '7
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value))))
          (let ((__tmp5428
                 (let ((__tmp5429
                        (lambda (_%a2103%_)
                          (let ((_%ht2105%_
                                 (let ()
                                   (declare (not safe))
                                   (make-hash-table__%
                                    '#f
                                    '2
                                    absent-value
                                    absent-value
                                    absent-value
                                    absent-value
                                    absent-value
                                    absent-value
                                    absent-value))))
                            (let ((__tmp5430
                                   (gerbil-ascent/tools/research/candidate-interaction#wire
                                    (gerbil-ascent/tools/research/candidate-interaction#field
                                     'atom
                                     _%a2103%_))))
                              (declare (not safe))
                              (__hash-put! _%ht2105%_ '"atom" __tmp5430))
                            (let ((__tmp5431
                                   (gerbil-ascent/tools/research/candidate-interaction#field
                                    'present
                                    _%a2103%_)))
                              (declare (not safe))
                              (__hash-put! _%ht2105%_ '"present" __tmp5431))
                            _%ht2105%_))))
                   (declare (not safe))
                   (##map __tmp5429 _%facts2079%_))))
            (declare (not safe))
            (__hash-put! _%ht2100%_ '"facts" __tmp5428))
          (let ((__tmp5432
                 (map (lambda (_%id2108%_ _%piece2109%_)
                        (let ((_%ht2111%_
                               (let ()
                                 (declare (not safe))
                                 (make-hash-table__%
                                  '#f
                                  '2
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value))))
                          (let ()
                            (declare (not safe))
                            (__hash-put! _%ht2111%_ '"id" _%id2108%_))
                          (let ((__tmp5433
                                 (if (eq? (gerbil-ascent/tools/research/candidate-interaction#field
                                           'status
                                           _%piece2109%_)
                                          'verified)
                                     (gerbil-ascent/tools/research/candidate-interaction#field
                                      'roots
                                      _%piece2109%_)
                                     '())))
                            (declare (not safe))
                            (__hash-put! _%ht2111%_ '"roots" __tmp5433))
                          _%ht2111%_))
                      _%ids2065%_
                      _%pieces2089%_)))
            (declare (not safe))
            (__hash-put! _%ht2100%_ '"fragments" __tmp5432))
          (let ((__tmp5434
                 (gerbil-ascent/tools/research/candidate-interaction#wire
                  _%nodes2097%_)))
            (declare (not safe))
            (__hash-put! _%ht2100%_ '"nodes" __tmp5434))
          (let ((__tmp5435
                 (gerbil-ascent/tools/research/candidate-interaction#field
                  'allowed
                  _%partition2085%_)))
            (declare (not safe))
            (__hash-put! _%ht2100%_ '"allowed" __tmp5435))
          (let ((__tmp5436
                 (gerbil-ascent/tools/research/candidate-interaction#field
                  'pruned
                  _%partition2085%_)))
            (declare (not safe))
            (__hash-put! _%ht2100%_ '"pruned" __tmp5436))
          (let ((__tmp5437
                 (gerbil-ascent/tools/research/candidate-interaction#field
                  'reused
                  _%answer2067%_)))
            (declare (not safe))
            (__hash-put! _%ht2100%_ '"reused" __tmp5437))
          (let ((__tmp5438
                 (gerbil-ascent/tools/research/candidate-interaction#wire
                  (let ()
                    (declare (not safe))
                    (gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-stats
                     gerbil-ascent/tools/research/candidate-interaction#reuse-store)))))
            (declare (not safe))
            (__hash-put! _%ht2100%_ '"stats" __tmp5438))
          _%ht2100%_)))
    (define gerbil-ascent/tools/research/candidate-interaction#reuse-episode
      (lambda (_%request1959%_)
        (let* ((_%atom1986%_
                (gerbil-ascent/tools/research/candidate-interaction#symbols
                 (let* ((_%h1961%_ _%request1959%_)
                        (_%key1964%_ '"atom")
                        (_%default1967%_ absent-obj)
                        (_%h1971%_
                         (let ()
                           (declare (not safe))
                           (cast HashTable::interface _%h1961%_)))
                        (_%h1973%_ _%h1971%_))
                   (declare (not safe))
                   (__hash-ref__% _%h1973%_ _%key1964%_ _%default1967%_))))
               (_%premises2013%_
                (gerbil-ascent/tools/research/candidate-interaction#symbols
                 (let* ((_%h1988%_ _%request1959%_)
                        (_%key1991%_ '"premises")
                        (_%default1994%_ absent-obj)
                        (_%h1998%_
                         (let ()
                           (declare (not safe))
                           (cast HashTable::interface _%h1988%_)))
                        (_%h2000%_ _%h1998%_))
                   (declare (not safe))
                   (__hash-ref__% _%h2000%_ _%key1991%_ _%default1994%_))))
               (_%present?2017%_
                (lambda (_%a2015%_)
                  (eq? (gerbil-ascent/tools/research/candidate-interaction#field
                        'status
                        (gerbil-ascent/tools/research/candidate-interaction#reuse-fact
                         _%a2015%_))
                       'verified)))
               (_%supported2032%_
                (if (pair? _%premises2013%_)
                    (if (let ()
                          (declare (not safe))
                          (andmap__0 _%present?2017%_ _%premises2013%_))
                        (let ((_%$e2019%_ (car _%atom1986%_)))
                          (if (eq? 'ready _%$e2019%_)
                              (let ((_%n2022%_
                                     (assoc (cadr _%atom1986%_)
                                            gerbil-ascent/tools/research/candidate-interaction#reuse-needs)))
                                (if _%n2022%_
                                    (equal? _%premises2013%_
                                            (list (list 'path
                                                        (list-ref _%n2022%_ '1)
                                                        (list-ref
                                                         _%n2022%_
                                                         '2))
                                                  (list 'path
                                                        (list-ref _%n2022%_ '3)
                                                        (list-ref
                                                         _%n2022%_
                                                         '4))))
                                    '#f))
                              (if (eq? 'path _%$e2019%_)
                                  (if (or (pair? (let ()
                                                   (declare (not safe))
                                                   (##cdr _%premises2013%_)))
                                          (eq? (caar _%premises2013%_) 'edge))
                                      (let _%loop2027%_ ((_%at2029%_
                                                          (cadr _%atom1986%_))
                                                         (_%rest2030%_
                                                          _%premises2013%_))
                                        (if (null? _%rest2030%_)
                                            (= _%at2029%_ (caddr _%atom1986%_))
                                            (if (let ((__tmp5439
                                                       (caar _%rest2030%_)))
                                                  (declare (not safe))
                                                  (##memq __tmp5439
                                                          '(edge path)))
                                                (if (= _%at2029%_
                                                       (cadar _%rest2030%_))
                                                    (_%loop2027%_
                                                     (caddar _%rest2030%_)
                                                     (cdr _%rest2030%_))
                                                    '#f)
                                                '#f)))
                                      '#f)
                                  '#f)))
                        '#f)
                    '#f))
               (_%ht2035%_
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   '2
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value))))
          (let ((__tmp5440 (_%present?2017%_ _%atom1986%_)))
            (declare (not safe))
            (__hash-put! _%ht2035%_ '"present" __tmp5440))
          (let ((__tmp5441 (if _%supported2032%_ '#t '#f)))
            (declare (not safe))
            (__hash-put! _%ht2035%_ '"supportQualified" __tmp5441))
          _%ht2035%_)))
    (define gerbil-ascent/tools/research/candidate-interaction#main
      (lambda _%args1888%_
        (if (let ()
              (declare (not safe))
              (##member '"--dynamic-evidence" _%args1888%_))
            (let ((_%before1890%_
                   gerbil-ascent/candidate/evidence-store#GerbilAscentEvidenceStoreContract))
              (load (path-expand
                     '"lib/gerbil-ascent/candidate/evidence-store.o1"
                     (let () (declare (not safe)) (##getenv '"GERBIL_PATH"))))
              (if (eq? _%before1890%_
                       gerbil-ascent/candidate/evidence-store#GerbilAscentEvidenceStoreContract)
                  (let ()
                    (declare (not safe))
                    (error '"dynamic module did not initialize"))
                  '#!void))
            '#!void)
        (let () (declare (not safe)) (displayln '"{\"ready\":true}"))
        (force-output)
        (let _%loop1892%_ ()
          (let ((_%line1895%_ (read-line)))
            (if (eof-object? _%line1895%_)
                '#!void
                (begin
                  (let ((__tmp5442
                         (let ((__tmp5443
                                (let ((__tmp5447
                                       (lambda (_%$%g18961898%_)
                                         (let* ((_%e1902%_ _%$%g18961898%_)
                                                (_%ht1904%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (make-hash-table__%
                                                    '#f
                                                    '1
                                                    absent-value
                                                    absent-value
                                                    absent-value
                                                    absent-value
                                                    absent-value
                                                    absent-value
                                                    absent-value))))
                                           (let ((__tmp5448
                                                  (let ()
                                                    (declare (not safe))
                                                    (std/error#exception->string
                                                     _%e1902%_))))
                                             (declare (not safe))
                                             (__hash-put!
                                              _%ht1904%_
                                              '"error"
                                              __tmp5448))
                                           _%ht1904%_)))
                                      (__tmp5444
                                       (lambda ()
                                         (gerbil-ascent/tools/research/candidate-interaction#dispatch
                                          (let ((__tmp5446
                                                 (lambda ()
                                                   (call-with-input-string
                                                    _%line1895%_
                                                    std/encoding/json/util#read-json)))
                                                (__tmp5445
                                                 (let* ((_%object-as-hash1910%_
                                                         '#t)
                                                        (_%key-as-symbol1913%_
                                                         '#f)
                                                        (_%array-as-vector1916%_
                                                         '#f)
                                                        (_%key-as-symbol1921%_
                                                         _%key-as-symbol1913%_)
                                                        (_%array-as-vector1939%_
                                                         _%array-as-vector1916%_)
                                                        (_%object-as-hash1949%_
                                                         _%object-as-hash1910%_))
                                                   (declare (not safe))
                                                   (std/encoding/json/env#__make-JSONReadOptions__%
                                                    '#f
                                                    _%key-as-symbol1921%_
                                                    _%array-as-vector1939%_
                                                    _%object-as-hash1949%_))))
                                            (declare (not safe))
                                            (call-with-parameters__1
                                             __tmp5446
                                             std/encoding/json/env#current-json-read-options
                                             __tmp5445))))))
                                  (declare (not safe))
                                  (__with-catch __tmp5447 __tmp5444))))
                           (declare (not safe))
                           (std/encoding/json/util#json->string __tmp5443))))
                    (declare (not safe))
                    (displayln __tmp5442))
                  (force-output)
                  (_%loop1892%_)))))))))
