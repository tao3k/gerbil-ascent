(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/scheme-language[1]#_g39051_|
    (##structure
     gx#syntax-quote::t
     'value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39062_|
    (##structure
     gx#syntax-quote::t
     'value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39075_|
    (##structure
     gx#syntax-quote::t
     'where
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39077_|
    (##structure
     gx#syntax-quote::t
     'compute
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39079_|
    (##structure gx#syntax-quote::t 'not #f (gx#current-expander-context) '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39081_|
    (##structure
     gx#syntax-quote::t
     'reduce
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39105_|
    (##structure
     gx#syntax-quote::t
     'limits
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39107_|
    (##structure
     gx#syntax-quote::t
     'rule
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39109_|
    (##structure
     gx#syntax-quote::t
     'relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39114_|
    (##structure
     gx#syntax-quote::t
     'relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39119_|
    (##structure
     gx#syntax-quote::t
     'lattice
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39127_|
    (##structure
     gx#syntax-quote::t
     'import
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39131_|
    (##structure
     gx#syntax-quote::t
     'source
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39137_|
    (##structure
     gx#syntax-quote::t
     'private
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39143_|
    (##structure
     gx#syntax-quote::t
     'export
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39149_|
    (##structure
     gx#syntax-quote::t
     'rule
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-term|
      (lambda (_%stx20458%_)
        (let* ((_%__stx3801038011%_ _%stx20458%_)
               (_%$%g2046320497%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3801038011%_)))))
          (let ((_%__kont3801338014%_
                 (lambda (_%$%g2046520651%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0
                            '#f
                            'relational-captured-value))
                         (cons _%$%g2046520651%_ '()))))
                (_%__kont3801538016%_
                 (lambda (_%$%g2047820577%_)
                   (let* ((_%datum20590%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax->datum _%$%g2047820577%_)))
                          (_%spelling20593%_ (symbol->string _%datum20590%_)))
                     (if (eq? _%datum20590%_ '?_)
                         (cons (let ()
                                 (declare (not safe))
                                 (gx#datum->syntax__0
                                  '#f
                                  'gerbil-ascent-wildcard))
                               '())
                         (if (and (> (string-length _%spelling20593%_) '1)
                                  (let ((__tmp39049
                                         (string-ref _%spelling20593%_ '0)))
                                    (declare (not safe))
                                    (##char=? __tmp39049 '#\?)))
                             (cons (let ()
                                     (declare (not safe))
                                     (gx#datum->syntax__0
                                      '#f
                                      'gerbil-ascent-variable))
                                   (cons (cons (let ()
                                                 (declare (not safe))
                                                 (gx#datum->syntax__0
                                                  '#f
                                                  'quote))
                                               (cons _%$%g2047820577%_ '()))
                                         '()))
                             (let ()
                               (declare (not safe))
                               (gx#raise-syntax-error
                                '#f
                                '"relational term must be a ?variable or scalar literal"
                                _%$%g2047820577%_)))))))
                (_%__kont3801738018%_
                 (lambda (_%$%g2048520524%_)
                   (let ((_%datum20539%_
                          (let ()
                            (declare (not safe))
                            (gx#syntax->datum _%$%g2048520524%_))))
                     (if (or (exact-integer? _%datum20539%_)
                             (boolean? _%datum20539%_)
                             (char? _%datum20539%_))
                         (cons (let ()
                                 (declare (not safe))
                                 (gx#datum->syntax__0
                                  '#f
                                  'gerbil-ascent-literal))
                               (cons _%$%g2048520524%_ '()))
                         (let ()
                           (declare (not safe))
                           (gx#raise-syntax-error
                            '#f
                            '"relational term must be an immutable scalar literal"
                            _%$%g2048520524%_)))))))
            (let ((_%__match3806538066%_
                   (lambda (_%$%e2047920557%_
                            _%$%hd2048020561%_
                            _%$%tl2048120564%_
                            _%$%e2048220567%_
                            _%$%hd2048320571%_
                            _%$%tl2048420574%_)
                     (let ((_%$%g2047820577%_ _%$%hd2048320571%_))
                       (if (let ()
                             (declare (not safe))
                             (gx#identifier? _%$%g2047820577%_))
                           (_%__kont3801538016%_ _%$%g2047820577%_)
                           (_%__kont3801738018%_ _%$%hd2048320571%_))))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3801038011%_))
                  (let ((_%$%e2046620611%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3801038011%_))))
                    (let ((_%$%tl2046820618%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2046620611%_)))
                          (_%$%hd2046720615%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2046620611%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2046820618%_))
                          (let ((_%$%e2046920621%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2046820618%_))))
                            (let ((_%$%tl2047120628%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2046920621%_)))
                                  (_%$%hd2047020625%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2046920621%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%hd2047020625%_))
                                  (let ((_%$%e2047220631%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%hd2047020625%_))))
                                    (let ((_%$%tl2047420638%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2047220631%_)))
                                          (_%$%hd2047320635%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2047220631%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#identifier?
                                             _%$%hd2047320635%_))
                                          (if (let ((__tmp39050
                                                     |gerbil-ascent/program/scheme-language[1]#_g39051_|))
                                                (declare (not safe))
                                                (gx#free-identifier=?
                                                 __tmp39050
                                                 _%$%hd2047320635%_))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%tl2047420638%_))
                                                  (let ((_%$%e2047520641%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%tl2047420638%_))))
                                                    (let ((_%$%tl2047720648%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e2047520641%_)))
                                                          (_%$%hd2047620645%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e2047520641%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-null?
                                                             _%$%tl2047720648%_))
                                                          (if (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#stx-null? _%$%tl2047120628%_))
                      (_%__kont3801338014%_ _%$%hd2047620645%_)
                      (let () (declare (not safe)) (_%$%g2046320497%_)))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-null? _%$%tl2047120628%_))
                      (_%__match3806538066%_
                       _%$%e2046620611%_
                       _%$%hd2046720615%_
                       _%$%tl2046820618%_
                       _%$%e2046920621%_
                       _%$%hd2047020625%_
                       _%$%tl2047120628%_)
                      (let () (declare (not safe)) (_%$%g2046320497%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-null?
                                                         _%$%tl2047120628%_))
                                                      (_%__match3806538066%_
                                                       _%$%e2046620611%_
                                                       _%$%hd2046720615%_
                                                       _%$%tl2046820618%_
                                                       _%$%e2046920621%_
                                                       _%$%hd2047020625%_
                                                       _%$%tl2047120628%_)
                                                      (let ()
                                                        (declare (not safe))
                                                        (_%$%g2046320497%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2047120628%_))
                                                  (_%__match3806538066%_
                                                   _%$%e2046620611%_
                                                   _%$%hd2046720615%_
                                                   _%$%tl2046820618%_
                                                   _%$%e2046920621%_
                                                   _%$%hd2047020625%_
                                                   _%$%tl2047120628%_)
                                                  (let ()
                                                    (declare (not safe))
                                                    (_%$%g2046320497%_))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2047120628%_))
                                              (_%__match3806538066%_
                                               _%$%e2046620611%_
                                               _%$%hd2046720615%_
                                               _%$%tl2046820618%_
                                               _%$%e2046920621%_
                                               _%$%hd2047020625%_
                                               _%$%tl2047120628%_)
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2046320497%_))))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl2047120628%_))
                                      (_%__match3806538066%_
                                       _%$%e2046620611%_
                                       _%$%hd2046720615%_
                                       _%$%tl2046820618%_
                                       _%$%e2046920621%_
                                       _%$%hd2047020625%_
                                       _%$%tl2047120628%_)
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2046320497%_))))))
                          (let () (declare (not safe)) (_%$%g2046320497%_)))))
                  (let () (declare (not safe)) (_%$%g2046320497%_))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-atom|
      (lambda (_%stx20672%_)
        (let* ((_%__stx3808238083%_ _%stx20672%_)
               (_%$%g2067620710%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3808238083%_)))))
          (let ((_%__kont3808538086%_
                 (lambda (_%$%g2067820816%_ _%$%g2067920818%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'gerbil-ascent-atom))
                         (cons (cons (let ()
                                       (declare (not safe))
                                       (gx#datum->syntax__0 '#f 'quote))
                                     (cons _%$%g2067920818%_ '()))
                               (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'list))
                                           (let ((__tmp39052
                                                  (lambda (_%$%g2083620839%_
                                                           _%$%g2083720842%_)
                                                    (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'relational-term))
                        (cons _%$%g2083620839%_ '()))
                  _%$%g2083720842%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp39052
                                              '()
                                              _%$%g2067820816%_)))
                                     '())))))
                (_%__kont3808938090%_
                 (lambda (_%$%g2069820737%_)
                   (let ()
                     (declare (not safe))
                     (gx#raise-syntax-error
                      '#f
                      '"expected a relational atom"
                      _%$%g2069820737%_)))))
            (let ((_%__match3811738118%_
                   (lambda (_%$%e2068020758%_
                            _%$%hd2068120762%_
                            _%$%tl2068220765%_
                            _%$%e2068320768%_
                            _%$%hd2068420772%_
                            _%$%tl2068520775%_
                            _%$%e2068620778%_
                            _%$%hd2068720782%_
                            _%$%tl2068820785%_
                            _%__splice3808738088%_
                            _%$%target2068920788%_
                            _%$%tl2069120791%_)
                     (letrec ((_%$%loop2069220794%_
                               (lambda (_%$%hd2069020798%_
                                        _%$%term2069620801%_)
                                 (if (let ()
                                       (declare (not safe))
                                       (gx#stx-pair? _%$%hd2069020798%_))
                                     (let ((_%$%e2069320803%_
                                            (let ()
                                              (declare (not safe))
                                              (gx#syntax-e
                                               _%$%hd2069020798%_))))
                                       (let ((_%$%lp-tl2069520810%_
                                              (let ()
                                                (declare (not safe))
                                                (##cdr _%$%e2069320803%_)))
                                             (_%$%lp-hd2069420807%_
                                              (let ()
                                                (declare (not safe))
                                                (##car _%$%e2069320803%_))))
                                         (_%$%loop2069220794%_
                                          _%$%lp-tl2069520810%_
                                          (cons _%$%lp-hd2069420807%_
                                                _%$%term2069620801%_))))
                                     (let ((_%$%term2069720813%_
                                            (reverse _%$%term2069620801%_)))
                                       (if (let ()
                                             (declare (not safe))
                                             (gx#stx-null? _%$%tl2068520775%_))
                                           (let ((_%$%g2067820816%_
                                                  _%$%term2069720813%_)
                                                 (_%$%g2067920818%_
                                                  _%$%hd2068720782%_))
                                             (if (let ()
                                                   (declare (not safe))
                                                   (gx#identifier?
                                                    _%$%g2067920818%_))
                                                 (_%__kont3808538086%_
                                                  _%$%g2067820816%_
                                                  _%$%g2067920818%_)
                                                 (_%__kont3808938090%_
                                                  _%$%hd2068420772%_)))
                                           (let ()
                                             (declare (not safe))
                                             (_%$%g2067620710%_))))))))
                       (_%$%loop2069220794%_ _%$%target2068920788%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3808238083%_))
                  (let ((_%$%e2068020758%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3808238083%_))))
                    (let ((_%$%tl2068220765%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2068020758%_)))
                          (_%$%hd2068120762%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2068020758%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2068220765%_))
                          (let ((_%$%e2068320768%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2068220765%_))))
                            (let ((_%$%tl2068520775%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2068320768%_)))
                                  (_%$%hd2068420772%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2068320768%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%hd2068420772%_))
                                  (let ((_%$%e2068620778%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%hd2068420772%_))))
                                    (let ((_%$%tl2068820785%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2068620778%_)))
                                          (_%$%hd2068720782%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2068620778%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair/null?
                                             _%$%tl2068820785%_))
                                          (let ((_%__splice3808738088%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-split-splice->vector
                                                    _%$%tl2068820785%_
                                                    '0))))
                                            (let ((_%$%tl2069120791%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3808738088%_
                                                      '1)))
                                                  (_%$%target2068920788%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3808738088%_
                                                      '0))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2069120791%_))
                                                  (_%__match3811738118%_
                                                   _%$%e2068020758%_
                                                   _%$%hd2068120762%_
                                                   _%$%tl2068220765%_
                                                   _%$%e2068320768%_
                                                   _%$%hd2068420772%_
                                                   _%$%tl2068520775%_
                                                   _%$%e2068620778%_
                                                   _%$%hd2068720782%_
                                                   _%$%tl2068820785%_
                                                   _%__splice3808738088%_
                                                   _%$%target2068920788%_
                                                   _%$%tl2069120791%_)
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-null?
                                                         _%$%tl2068520775%_))
                                                      (_%__kont3808938090%_
                                                       _%$%hd2068420772%_)
                                                      (let ()
                                                        (declare (not safe))
                                                        (_%$%g2067620710%_))))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2068520775%_))
                                              (_%__kont3808938090%_
                                               _%$%hd2068420772%_)
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2067620710%_))))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl2068520775%_))
                                      (_%__kont3808938090%_ _%$%hd2068420772%_)
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2067620710%_))))))
                          (let () (declare (not safe)) (_%$%g2067620710%_)))))
                  (let () (declare (not safe)) (_%$%g2067620710%_))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-atom/lexical|
      (lambda (_%stx20850%_)
        (let* ((_%__stx3813438135%_ _%stx20850%_)
               (_%$%g2085420888%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3813438135%_)))))
          (let ((_%__kont3813738138%_
                 (lambda (_%$%g2085620994%_ _%$%g2085720996%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'gerbil-ascent-atom))
                         (cons _%$%g2085720996%_
                               (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'list))
                                           (let ((__tmp39053
                                                  (lambda (_%$%g2101421017%_
                                                           _%$%g2101521020%_)
                                                    (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'relational-term))
                        (cons _%$%g2101421017%_ '()))
                  _%$%g2101521020%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp39053
                                              '()
                                              _%$%g2085620994%_)))
                                     '())))))
                (_%__kont3814138142%_
                 (lambda (_%$%g2087620915%_)
                   (let ()
                     (declare (not safe))
                     (gx#raise-syntax-error
                      '#f
                      '"expected a relational atom"
                      _%$%g2087620915%_)))))
            (let ((_%__match3816938170%_
                   (lambda (_%$%e2085820936%_
                            _%$%hd2085920940%_
                            _%$%tl2086020943%_
                            _%$%e2086120946%_
                            _%$%hd2086220950%_
                            _%$%tl2086320953%_
                            _%$%e2086420956%_
                            _%$%hd2086520960%_
                            _%$%tl2086620963%_
                            _%__splice3813938140%_
                            _%$%target2086720966%_
                            _%$%tl2086920969%_)
                     (letrec ((_%$%loop2087020972%_
                               (lambda (_%$%hd2086820976%_
                                        _%$%term2087420979%_)
                                 (if (let ()
                                       (declare (not safe))
                                       (gx#stx-pair? _%$%hd2086820976%_))
                                     (let ((_%$%e2087120981%_
                                            (let ()
                                              (declare (not safe))
                                              (gx#syntax-e
                                               _%$%hd2086820976%_))))
                                       (let ((_%$%lp-tl2087320988%_
                                              (let ()
                                                (declare (not safe))
                                                (##cdr _%$%e2087120981%_)))
                                             (_%$%lp-hd2087220985%_
                                              (let ()
                                                (declare (not safe))
                                                (##car _%$%e2087120981%_))))
                                         (_%$%loop2087020972%_
                                          _%$%lp-tl2087320988%_
                                          (cons _%$%lp-hd2087220985%_
                                                _%$%term2087420979%_))))
                                     (let ((_%$%term2087520991%_
                                            (reverse _%$%term2087420979%_)))
                                       (if (let ()
                                             (declare (not safe))
                                             (gx#stx-null? _%$%tl2086320953%_))
                                           (let ((_%$%g2085620994%_
                                                  _%$%term2087520991%_)
                                                 (_%$%g2085720996%_
                                                  _%$%hd2086520960%_))
                                             (if (let ()
                                                   (declare (not safe))
                                                   (gx#identifier?
                                                    _%$%g2085720996%_))
                                                 (_%__kont3813738138%_
                                                  _%$%g2085620994%_
                                                  _%$%g2085720996%_)
                                                 (_%__kont3814138142%_
                                                  _%$%hd2086220950%_)))
                                           (let ()
                                             (declare (not safe))
                                             (_%$%g2085420888%_))))))))
                       (_%$%loop2087020972%_ _%$%target2086720966%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3813438135%_))
                  (let ((_%$%e2085820936%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3813438135%_))))
                    (let ((_%$%tl2086020943%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2085820936%_)))
                          (_%$%hd2085920940%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2085820936%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2086020943%_))
                          (let ((_%$%e2086120946%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2086020943%_))))
                            (let ((_%$%tl2086320953%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2086120946%_)))
                                  (_%$%hd2086220950%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2086120946%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%hd2086220950%_))
                                  (let ((_%$%e2086420956%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%hd2086220950%_))))
                                    (let ((_%$%tl2086620963%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2086420956%_)))
                                          (_%$%hd2086520960%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2086420956%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair/null?
                                             _%$%tl2086620963%_))
                                          (let ((_%__splice3813938140%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-split-splice->vector
                                                    _%$%tl2086620963%_
                                                    '0))))
                                            (let ((_%$%tl2086920969%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3813938140%_
                                                      '1)))
                                                  (_%$%target2086720966%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3813938140%_
                                                      '0))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2086920969%_))
                                                  (_%__match3816938170%_
                                                   _%$%e2085820936%_
                                                   _%$%hd2085920940%_
                                                   _%$%tl2086020943%_
                                                   _%$%e2086120946%_
                                                   _%$%hd2086220950%_
                                                   _%$%tl2086320953%_
                                                   _%$%e2086420956%_
                                                   _%$%hd2086520960%_
                                                   _%$%tl2086620963%_
                                                   _%__splice3813938140%_
                                                   _%$%target2086720966%_
                                                   _%$%tl2086920969%_)
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-null?
                                                         _%$%tl2086320953%_))
                                                      (_%__kont3814138142%_
                                                       _%$%hd2086220950%_)
                                                      (let ()
                                                        (declare (not safe))
                                                        (_%$%g2085420888%_))))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2086320953%_))
                                              (_%__kont3814138142%_
                                               _%$%hd2086220950%_)
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2085420888%_))))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl2086320953%_))
                                      (_%__kont3814138142%_ _%$%hd2086220950%_)
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2085420888%_))))))
                          (let () (declare (not safe)) (_%$%g2085420888%_)))))
                  (let () (declare (not safe)) (_%$%g2085420888%_))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-negation|
      (lambda (_%stx21028%_)
        (let* ((_%__stx3818638187%_ _%stx21028%_)
               (_%$%g2103221066%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3818638187%_)))))
          (let ((_%__kont3818938190%_
                 (lambda (_%$%g2103421172%_ _%$%g2103521174%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'gerbil-ascent-negation))
                         (cons (cons (let ()
                                       (declare (not safe))
                                       (gx#datum->syntax__0 '#f 'quote))
                                     (cons _%$%g2103521174%_ '()))
                               (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'list))
                                           (let ((__tmp39054
                                                  (lambda (_%$%g2119221195%_
                                                           _%$%g2119321198%_)
                                                    (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'relational-term))
                        (cons _%$%g2119221195%_ '()))
                  _%$%g2119321198%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp39054
                                              '()
                                              _%$%g2103421172%_)))
                                     '())))))
                (_%__kont3819338194%_
                 (lambda (_%$%g2105421093%_)
                   (let ()
                     (declare (not safe))
                     (gx#raise-syntax-error
                      '#f
                      '"expected a relational negation atom"
                      _%$%g2105421093%_)))))
            (let ((_%__match3822138222%_
                   (lambda (_%$%e2103621114%_
                            _%$%hd2103721118%_
                            _%$%tl2103821121%_
                            _%$%e2103921124%_
                            _%$%hd2104021128%_
                            _%$%tl2104121131%_
                            _%$%e2104221134%_
                            _%$%hd2104321138%_
                            _%$%tl2104421141%_
                            _%__splice3819138192%_
                            _%$%target2104521144%_
                            _%$%tl2104721147%_)
                     (letrec ((_%$%loop2104821150%_
                               (lambda (_%$%hd2104621154%_
                                        _%$%term2105221157%_)
                                 (if (let ()
                                       (declare (not safe))
                                       (gx#stx-pair? _%$%hd2104621154%_))
                                     (let ((_%$%e2104921159%_
                                            (let ()
                                              (declare (not safe))
                                              (gx#syntax-e
                                               _%$%hd2104621154%_))))
                                       (let ((_%$%lp-tl2105121166%_
                                              (let ()
                                                (declare (not safe))
                                                (##cdr _%$%e2104921159%_)))
                                             (_%$%lp-hd2105021163%_
                                              (let ()
                                                (declare (not safe))
                                                (##car _%$%e2104921159%_))))
                                         (_%$%loop2104821150%_
                                          _%$%lp-tl2105121166%_
                                          (cons _%$%lp-hd2105021163%_
                                                _%$%term2105221157%_))))
                                     (let ((_%$%term2105321169%_
                                            (reverse _%$%term2105221157%_)))
                                       (if (let ()
                                             (declare (not safe))
                                             (gx#stx-null? _%$%tl2104121131%_))
                                           (let ((_%$%g2103421172%_
                                                  _%$%term2105321169%_)
                                                 (_%$%g2103521174%_
                                                  _%$%hd2104321138%_))
                                             (if (let ()
                                                   (declare (not safe))
                                                   (gx#identifier?
                                                    _%$%g2103521174%_))
                                                 (_%__kont3818938190%_
                                                  _%$%g2103421172%_
                                                  _%$%g2103521174%_)
                                                 (_%__kont3819338194%_
                                                  _%$%hd2104021128%_)))
                                           (let ()
                                             (declare (not safe))
                                             (_%$%g2103221066%_))))))))
                       (_%$%loop2104821150%_ _%$%target2104521144%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3818638187%_))
                  (let ((_%$%e2103621114%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3818638187%_))))
                    (let ((_%$%tl2103821121%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2103621114%_)))
                          (_%$%hd2103721118%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2103621114%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2103821121%_))
                          (let ((_%$%e2103921124%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2103821121%_))))
                            (let ((_%$%tl2104121131%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2103921124%_)))
                                  (_%$%hd2104021128%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2103921124%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%hd2104021128%_))
                                  (let ((_%$%e2104221134%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%hd2104021128%_))))
                                    (let ((_%$%tl2104421141%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2104221134%_)))
                                          (_%$%hd2104321138%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2104221134%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair/null?
                                             _%$%tl2104421141%_))
                                          (let ((_%__splice3819138192%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-split-splice->vector
                                                    _%$%tl2104421141%_
                                                    '0))))
                                            (let ((_%$%tl2104721147%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3819138192%_
                                                      '1)))
                                                  (_%$%target2104521144%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3819138192%_
                                                      '0))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2104721147%_))
                                                  (_%__match3822138222%_
                                                   _%$%e2103621114%_
                                                   _%$%hd2103721118%_
                                                   _%$%tl2103821121%_
                                                   _%$%e2103921124%_
                                                   _%$%hd2104021128%_
                                                   _%$%tl2104121131%_
                                                   _%$%e2104221134%_
                                                   _%$%hd2104321138%_
                                                   _%$%tl2104421141%_
                                                   _%__splice3819138192%_
                                                   _%$%target2104521144%_
                                                   _%$%tl2104721147%_)
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-null?
                                                         _%$%tl2104121131%_))
                                                      (_%__kont3819338194%_
                                                       _%$%hd2104021128%_)
                                                      (let ()
                                                        (declare (not safe))
                                                        (_%$%g2103221066%_))))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2104121131%_))
                                              (_%__kont3819338194%_
                                               _%$%hd2104021128%_)
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2103221066%_))))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl2104121131%_))
                                      (_%__kont3819338194%_ _%$%hd2104021128%_)
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2103221066%_))))))
                          (let () (declare (not safe)) (_%$%g2103221066%_)))))
                  (let () (declare (not safe)) (_%$%g2103221066%_))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-negation/lexical|
      (lambda (_%stx21206%_)
        (let* ((_%__stx3823838239%_ _%stx21206%_)
               (_%$%g2121021244%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3823838239%_)))))
          (let ((_%__kont3824138242%_
                 (lambda (_%$%g2121221350%_ _%$%g2121321352%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'gerbil-ascent-negation))
                         (cons _%$%g2121321352%_
                               (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'list))
                                           (let ((__tmp39055
                                                  (lambda (_%$%g2137021373%_
                                                           _%$%g2137121376%_)
                                                    (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'relational-term))
                        (cons _%$%g2137021373%_ '()))
                  _%$%g2137121376%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp39055
                                              '()
                                              _%$%g2121221350%_)))
                                     '())))))
                (_%__kont3824538246%_
                 (lambda (_%$%g2123221271%_)
                   (let ()
                     (declare (not safe))
                     (gx#raise-syntax-error
                      '#f
                      '"expected a relational negation atom"
                      _%$%g2123221271%_)))))
            (let ((_%__match3827338274%_
                   (lambda (_%$%e2121421292%_
                            _%$%hd2121521296%_
                            _%$%tl2121621299%_
                            _%$%e2121721302%_
                            _%$%hd2121821306%_
                            _%$%tl2121921309%_
                            _%$%e2122021312%_
                            _%$%hd2122121316%_
                            _%$%tl2122221319%_
                            _%__splice3824338244%_
                            _%$%target2122321322%_
                            _%$%tl2122521325%_)
                     (letrec ((_%$%loop2122621328%_
                               (lambda (_%$%hd2122421332%_
                                        _%$%term2123021335%_)
                                 (if (let ()
                                       (declare (not safe))
                                       (gx#stx-pair? _%$%hd2122421332%_))
                                     (let ((_%$%e2122721337%_
                                            (let ()
                                              (declare (not safe))
                                              (gx#syntax-e
                                               _%$%hd2122421332%_))))
                                       (let ((_%$%lp-tl2122921344%_
                                              (let ()
                                                (declare (not safe))
                                                (##cdr _%$%e2122721337%_)))
                                             (_%$%lp-hd2122821341%_
                                              (let ()
                                                (declare (not safe))
                                                (##car _%$%e2122721337%_))))
                                         (_%$%loop2122621328%_
                                          _%$%lp-tl2122921344%_
                                          (cons _%$%lp-hd2122821341%_
                                                _%$%term2123021335%_))))
                                     (let ((_%$%term2123121347%_
                                            (reverse _%$%term2123021335%_)))
                                       (if (let ()
                                             (declare (not safe))
                                             (gx#stx-null? _%$%tl2121921309%_))
                                           (let ((_%$%g2121221350%_
                                                  _%$%term2123121347%_)
                                                 (_%$%g2121321352%_
                                                  _%$%hd2122121316%_))
                                             (if (let ()
                                                   (declare (not safe))
                                                   (gx#identifier?
                                                    _%$%g2121321352%_))
                                                 (_%__kont3824138242%_
                                                  _%$%g2121221350%_
                                                  _%$%g2121321352%_)
                                                 (_%__kont3824538246%_
                                                  _%$%hd2121821306%_)))
                                           (let ()
                                             (declare (not safe))
                                             (_%$%g2121021244%_))))))))
                       (_%$%loop2122621328%_ _%$%target2122321322%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3823838239%_))
                  (let ((_%$%e2121421292%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3823838239%_))))
                    (let ((_%$%tl2121621299%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2121421292%_)))
                          (_%$%hd2121521296%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2121421292%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2121621299%_))
                          (let ((_%$%e2121721302%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2121621299%_))))
                            (let ((_%$%tl2121921309%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2121721302%_)))
                                  (_%$%hd2121821306%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2121721302%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%hd2121821306%_))
                                  (let ((_%$%e2122021312%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%hd2121821306%_))))
                                    (let ((_%$%tl2122221319%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2122021312%_)))
                                          (_%$%hd2122121316%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2122021312%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair/null?
                                             _%$%tl2122221319%_))
                                          (let ((_%__splice3824338244%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-split-splice->vector
                                                    _%$%tl2122221319%_
                                                    '0))))
                                            (let ((_%$%tl2122521325%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3824338244%_
                                                      '1)))
                                                  (_%$%target2122321322%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3824338244%_
                                                      '0))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2122521325%_))
                                                  (_%__match3827338274%_
                                                   _%$%e2121421292%_
                                                   _%$%hd2121521296%_
                                                   _%$%tl2121621299%_
                                                   _%$%e2121721302%_
                                                   _%$%hd2121821306%_
                                                   _%$%tl2121921309%_
                                                   _%$%e2122021312%_
                                                   _%$%hd2122121316%_
                                                   _%$%tl2122221319%_
                                                   _%__splice3824338244%_
                                                   _%$%target2122321322%_
                                                   _%$%tl2122521325%_)
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-null?
                                                         _%$%tl2121921309%_))
                                                      (_%__kont3824538246%_
                                                       _%$%hd2121821306%_)
                                                      (let ()
                                                        (declare (not safe))
                                                        (_%$%g2121021244%_))))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2121921309%_))
                                              (_%__kont3824538246%_
                                               _%$%hd2121821306%_)
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2121021244%_))))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl2121921309%_))
                                      (_%__kont3824538246%_ _%$%hd2121821306%_)
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2121021244%_))))))
                          (let () (declare (not safe)) (_%$%g2121021244%_)))))
                  (let () (declare (not safe)) (_%$%g2121021244%_))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-reduce|
      (lambda (_%stx21384%_)
        (let* ((_%__stx3829038291%_ _%stx21384%_)
               (_%$%g2138821449%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3829038291%_)))))
          (let ((_%__kont3829338294%_
                 (lambda (_%$%g2139021633%_
                          _%$%g2139121635%_
                          _%$%g2139221636%_
                          _%$%g2139321637%_
                          _%$%g2139421638%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'relational-reducer))
                         (cons (cons (let ()
                                       (declare (not safe))
                                       (gx#datum->syntax__0 '#f 'quote))
                                     (cons _%$%g2139421638%_ '()))
                               (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'quote))
                                           (cons _%$%g2139321637%_ '()))
                                     (cons (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'quote))
                                                 (cons (let ((__tmp39056
                                                              (lambda (_%$%g2166921674%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               _%$%g2167021677%_)
                        (cons _%$%g2166921674%_ _%$%g2167021677%_))))
                 (declare (not safe))
                 (foldr__0 __tmp39056 '() _%$%g2139221636%_))
               '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           (cons (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'quote))
                                                       (cons _%$%g2139121635%_
                                                             '()))
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'list))
                     (let ((__tmp39057
                            (lambda (_%$%g2167121680%_ _%$%g2167221683%_)
                              (cons (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0
                                             '#f
                                             'relational-term))
                                          (cons _%$%g2167121680%_ '()))
                                    _%$%g2167221683%_))))
                       (declare (not safe))
                       (foldr__0 __tmp39057 '() _%$%g2139021633%_)))
               '()))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                (_%__kont3829938300%_
                 (lambda (_%$%g2143121494%_)
                   (let ()
                     (declare (not safe))
                     (gx#raise-syntax-error
                      '#f
                      '"expected checked reduction"
                      _%stx21384%_)))))
            (let* ((_%__match3834938350%_
                    (lambda (_%$%e2143221456%_
                             _%$%hd2143321460%_
                             _%$%tl2143421463%_
                             _%__splice3830138302%_
                             _%$%target2143521466%_
                             _%$%tl2143721469%_)
                      (letrec ((_%$%loop2143821472%_
                                (lambda (_%$%hd2143621476%_
                                         _%$%bad2144221479%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2143621476%_))
                                      (let ((_%$%e2143921481%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2143621476%_))))
                                        (let ((_%$%lp-tl2144121488%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2143921481%_)))
                                              (_%$%lp-hd2144021485%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2143921481%_))))
                                          (_%$%loop2143821472%_
                                           _%$%lp-tl2144121488%_
                                           (cons _%$%lp-hd2144021485%_
                                                 _%$%bad2144221479%_))))
                                      (let ((_%$%bad2144321491%_
                                             (reverse _%$%bad2144221479%_)))
                                        (_%__kont3829938300%_
                                         _%$%bad2144321491%_))))))
                        (_%$%loop2143821472%_ _%$%target2143521466%_ '()))))
                   (_%__match3834138342%_
                    (lambda (_%$%e2143221456%_
                             _%$%hd2143321460%_
                             _%$%tl2143421463%_)
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl2143421463%_))
                          (let ((_%__splice3830138302%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl2143421463%_
                                    '0))))
                            (let ((_%$%tl2143721469%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3830138302%_ '1)))
                                  (_%$%target2143521466%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3830138302%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl2143721469%_))
                                  (_%__match3834938350%_
                                   _%$%e2143221456%_
                                   _%$%hd2143321460%_
                                   _%$%tl2143421463%_
                                   _%__splice3830138302%_
                                   _%$%target2143521466%_
                                   _%$%tl2143721469%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g2138821449%_)))))
                          (let () (declare (not safe)) (_%$%g2138821449%_)))))
                   (_%__match3833538336%_
                    (lambda (_%$%e2139521517%_
                             _%$%hd2139621521%_
                             _%$%tl2139721524%_
                             _%$%e2139821527%_
                             _%$%hd2139921531%_
                             _%$%tl2140021534%_
                             _%$%e2140121537%_
                             _%$%hd2140221541%_
                             _%$%tl2140321544%_
                             _%$%e2140421547%_
                             _%$%hd2140521551%_
                             _%$%tl2140621554%_
                             _%__splice3829538296%_
                             _%$%target2140721557%_
                             _%$%tl2140921560%_)
                      (letrec ((_%$%loop2141021563%_
                                (lambda (_%$%hd2140821567%_
                                         _%$%input2141421570%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2140821567%_))
                                      (let ((_%$%e2141121572%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2140821567%_))))
                                        (let ((_%$%lp-tl2141321579%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2141121572%_)))
                                              (_%$%lp-hd2141221576%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2141121572%_))))
                                          (_%$%loop2141021563%_
                                           _%$%lp-tl2141321579%_
                                           (cons _%$%lp-hd2141221576%_
                                                 _%$%input2141421570%_))))
                                      (let ((_%$%input2141521582%_
                                             (reverse _%$%input2141421570%_)))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2140621554%_))
                                            (let ((_%$%e2141621585%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2140621554%_))))
                                              (let ((_%$%tl2141821592%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2141621585%_)))
                                                    (_%$%hd2141721589%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2141621585%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair?
                                                       _%$%hd2141721589%_))
                                                    (let ((_%$%e2141921595%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-e
                                                              _%$%hd2141721589%_))))
                                                      (let ((_%$%tl2142121602%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##cdr _%$%e2141921595%_)))
                    (_%$%hd2142021599%_
                     (let () (declare (not safe)) (##car _%$%e2141921595%_))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair/null? _%$%tl2142121602%_))
                    (let ((_%__splice3829738298%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-split-splice->vector
                              _%$%tl2142121602%_
                              '0))))
                      (let ((_%$%tl2142421608%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3829738298%_ '1)))
                            (_%$%target2142221605%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3829738298%_ '0))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-null? _%$%tl2142421608%_))
                            (letrec ((_%$%loop2142521611%_
                                      (lambda (_%$%hd2142321615%_
                                               _%$%term2142921618%_)
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%hd2142321615%_))
                                            (let ((_%$%e2142621620%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%hd2142321615%_))))
                                              (let ((_%$%lp-tl2142821627%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2142621620%_)))
                                                    (_%$%lp-hd2142721624%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2142621620%_))))
                                                (_%$%loop2142521611%_
                                                 _%$%lp-tl2142821627%_
                                                 (cons _%$%lp-hd2142721624%_
                                                       _%$%term2142921618%_))))
                                            (let ((_%$%term2143021630%_
                                                   (reverse _%$%term2142921618%_)))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2141821592%_))
                                                  (let ((_%$%g2139021633%_
                                                         _%$%term2143021630%_)
                                                        (_%$%g2139121635%_
                                                         _%$%hd2142021599%_)
                                                        (_%$%g2139221636%_
                                                         _%$%input2141521582%_)
                                                        (_%$%g2139321637%_
                                                         _%$%hd2140221541%_)
                                                        (_%$%g2139421638%_
                                                         _%$%hd2139921531%_))
                                                    (if (and (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#identifier? _%$%g2139121635%_))
                     (let ()
                       (declare (not safe))
                       (gx#identifier? _%$%g2139321637%_)))
                (_%__kont3829338294%_
                 _%$%g2139021633%_
                 _%$%g2139121635%_
                 _%$%g2139221636%_
                 _%$%g2139321637%_
                 _%$%g2139421638%_)
                (_%__match3834138342%_
                 _%$%e2139521517%_
                 _%$%hd2139621521%_
                 _%$%tl2139721524%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%__match3834138342%_
                                                   _%$%e2139521517%_
                                                   _%$%hd2139621521%_
                                                   _%$%tl2139721524%_)))))))
                              (_%$%loop2142521611%_
                               _%$%target2142221605%_
                               '()))
                            (_%__match3834138342%_
                             _%$%e2139521517%_
                             _%$%hd2139621521%_
                             _%$%tl2139721524%_))))
                    (_%__match3834138342%_
                     _%$%e2139521517%_
                     _%$%hd2139621521%_
                     _%$%tl2139721524%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3834138342%_
                                                     _%$%e2139521517%_
                                                     _%$%hd2139621521%_
                                                     _%$%tl2139721524%_))))
                                            (_%__match3834138342%_
                                             _%$%e2139521517%_
                                             _%$%hd2139621521%_
                                             _%$%tl2139721524%_)))))))
                        (_%$%loop2141021563%_ _%$%target2140721557%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3829038291%_))
                  (let ((_%$%e2139521517%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3829038291%_))))
                    (let ((_%$%tl2139721524%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2139521517%_)))
                          (_%$%hd2139621521%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2139521517%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2139721524%_))
                          (let ((_%$%e2139821527%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2139721524%_))))
                            (let ((_%$%tl2140021534%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2139821527%_)))
                                  (_%$%hd2139921531%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2139821527%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%tl2140021534%_))
                                  (let ((_%$%e2140121537%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%tl2140021534%_))))
                                    (let ((_%$%tl2140321544%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2140121537%_)))
                                          (_%$%hd2140221541%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2140121537%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl2140321544%_))
                                          (let ((_%$%e2140421547%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl2140321544%_))))
                                            (let ((_%$%tl2140621554%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2140421547%_)))
                                                  (_%$%hd2140521551%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2140421547%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair/null?
                                                     _%$%hd2140521551%_))
                                                  (let ((_%__splice3829538296%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-split-splice->vector
                                                            _%$%hd2140521551%_
                                                            '0))))
                                                    (let ((_%$%tl2140921560%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##vector-ref
                                                              _%__splice3829538296%_
                                                              '1)))
                                                          (_%$%target2140721557%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##vector-ref
                                                              _%__splice3829538296%_
                                                              '0))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-null?
                                                             _%$%tl2140921560%_))
                                                          (_%__match3833538336%_
                                                           _%$%e2139521517%_
                                                           _%$%hd2139621521%_
                                                           _%$%tl2139721524%_
                                                           _%$%e2139821527%_
                                                           _%$%hd2139921531%_
                                                           _%$%tl2140021534%_
                                                           _%$%e2140121537%_
                                                           _%$%hd2140221541%_
                                                           _%$%tl2140321544%_
                                                           _%$%e2140421547%_
                                                           _%$%hd2140521551%_
                                                           _%$%tl2140621554%_
                                                           _%__splice3829538296%_
                                                           _%$%target2140721557%_
                                                           _%$%tl2140921560%_)
                                                          (if (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#stx-pair/null? _%$%tl2139721524%_))
                      (let ((_%__splice3830138302%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-split-splice->vector
                                _%$%tl2139721524%_
                                '0))))
                        (let ((_%$%tl2143721469%_
                               (let ()
                                 (declare (not safe))
                                 (##vector-ref _%__splice3830138302%_ '1)))
                              (_%$%target2143521466%_
                               (let ()
                                 (declare (not safe))
                                 (##vector-ref _%__splice3830138302%_ '0))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-null? _%$%tl2143721469%_))
                              (_%__match3834938350%_
                               _%$%e2139521517%_
                               _%$%hd2139621521%_
                               _%$%tl2139721524%_
                               _%__splice3830138302%_
                               _%$%target2143521466%_
                               _%$%tl2143721469%_)
                              (let ()
                                (declare (not safe))
                                (_%$%g2138821449%_)))))
                      (let () (declare (not safe)) (_%$%g2138821449%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair/null?
                                                         _%$%tl2139721524%_))
                                                      (let ((_%__splice3830138302%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-split-splice->vector
                        _%$%tl2139721524%_
                        '0))))
                (let ((_%$%tl2143721469%_
                       (let ()
                         (declare (not safe))
                         (##vector-ref _%__splice3830138302%_ '1)))
                      (_%$%target2143521466%_
                       (let ()
                         (declare (not safe))
                         (##vector-ref _%__splice3830138302%_ '0))))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-null? _%$%tl2143721469%_))
                      (_%__match3834938350%_
                       _%$%e2139521517%_
                       _%$%hd2139621521%_
                       _%$%tl2139721524%_
                       _%__splice3830138302%_
                       _%$%target2143521466%_
                       _%$%tl2143721469%_)
                      (let () (declare (not safe)) (_%$%g2138821449%_)))))
              (let () (declare (not safe)) (_%$%g2138821449%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair/null?
                                                 _%$%tl2139721524%_))
                                              (let ((_%__splice3830138302%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-split-splice->vector
                                                        _%$%tl2139721524%_
                                                        '0))))
                                                (let ((_%$%tl2143721469%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##vector-ref
                                                          _%__splice3830138302%_
                                                          '1)))
                                                      (_%$%target2143521466%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##vector-ref
                                                          _%__splice3830138302%_
                                                          '0))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-null?
                                                         _%$%tl2143721469%_))
                                                      (_%__match3834938350%_
                                                       _%$%e2139521517%_
                                                       _%$%hd2139621521%_
                                                       _%$%tl2139721524%_
                                                       _%__splice3830138302%_
                                                       _%$%target2143521466%_
                                                       _%$%tl2143721469%_)
                                                      (let ()
                                                        (declare (not safe))
                                                        (_%$%g2138821449%_)))))
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2138821449%_))))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair/null? _%$%tl2139721524%_))
                                      (let ((_%__splice3830138302%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-split-splice->vector
                                                _%$%tl2139721524%_
                                                '0))))
                                        (let ((_%$%tl2143721469%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##vector-ref
                                                  _%__splice3830138302%_
                                                  '1)))
                                              (_%$%target2143521466%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##vector-ref
                                                  _%__splice3830138302%_
                                                  '0))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2143721469%_))
                                              (_%__match3834938350%_
                                               _%$%e2139521517%_
                                               _%$%hd2139621521%_
                                               _%$%tl2139721524%_
                                               _%__splice3830138302%_
                                               _%$%target2143521466%_
                                               _%$%tl2143721469%_)
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2138821449%_)))))
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2138821449%_))))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair/null? _%$%tl2139721524%_))
                              (let ((_%__splice3830138302%_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-split-splice->vector
                                        _%$%tl2139721524%_
                                        '0))))
                                (let ((_%$%tl2143721469%_
                                       (let ()
                                         (declare (not safe))
                                         (##vector-ref
                                          _%__splice3830138302%_
                                          '1)))
                                      (_%$%target2143521466%_
                                       (let ()
                                         (declare (not safe))
                                         (##vector-ref
                                          _%__splice3830138302%_
                                          '0))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl2143721469%_))
                                      (_%__match3834938350%_
                                       _%$%e2139521517%_
                                       _%$%hd2139621521%_
                                       _%$%tl2139721524%_
                                       _%__splice3830138302%_
                                       _%$%target2143521466%_
                                       _%$%tl2143721469%_)
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2138821449%_)))))
                              (let ()
                                (declare (not safe))
                                (_%$%g2138821449%_))))))
                  (let () (declare (not safe)) (_%$%g2138821449%_))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-reduce/lexical|
      (lambda (_%stx21693%_)
        (let* ((_%__stx3835238353%_ _%stx21693%_)
               (_%$%g2169721758%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3835238353%_)))))
          (let ((_%__kont3835538356%_
                 (lambda (_%$%g2169921942%_
                          _%$%g2170021944%_
                          _%$%g2170121945%_
                          _%$%g2170221946%_
                          _%$%g2170321947%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'relational-reducer))
                         (cons (cons (let ()
                                       (declare (not safe))
                                       (gx#datum->syntax__0 '#f 'quote))
                                     (cons _%$%g2170321947%_ '()))
                               (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'quote))
                                           (cons _%$%g2170221946%_ '()))
                                     (cons (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'quote))
                                                 (cons (let ((__tmp39058
                                                              (lambda (_%$%g2197821983%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               _%$%g2197921986%_)
                        (cons _%$%g2197821983%_ _%$%g2197921986%_))))
                 (declare (not safe))
                 (foldr__0 __tmp39058 '() _%$%g2170121945%_))
               '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           (cons _%$%g2170021944%_
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'list))
                     (let ((__tmp39059
                            (lambda (_%$%g2198021989%_ _%$%g2198121992%_)
                              (cons (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0
                                             '#f
                                             'relational-term))
                                          (cons _%$%g2198021989%_ '()))
                                    _%$%g2198121992%_))))
                       (declare (not safe))
                       (foldr__0 __tmp39059 '() _%$%g2169921942%_)))
               '()))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                (_%__kont3836138362%_
                 (lambda (_%$%g2174021803%_)
                   (let ()
                     (declare (not safe))
                     (gx#raise-syntax-error
                      '#f
                      '"expected checked reduction"
                      _%stx21693%_)))))
            (let* ((_%__match3841138412%_
                    (lambda (_%$%e2174121765%_
                             _%$%hd2174221769%_
                             _%$%tl2174321772%_
                             _%__splice3836338364%_
                             _%$%target2174421775%_
                             _%$%tl2174621778%_)
                      (letrec ((_%$%loop2174721781%_
                                (lambda (_%$%hd2174521785%_
                                         _%$%bad2175121788%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2174521785%_))
                                      (let ((_%$%e2174821790%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2174521785%_))))
                                        (let ((_%$%lp-tl2175021797%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2174821790%_)))
                                              (_%$%lp-hd2174921794%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2174821790%_))))
                                          (_%$%loop2174721781%_
                                           _%$%lp-tl2175021797%_
                                           (cons _%$%lp-hd2174921794%_
                                                 _%$%bad2175121788%_))))
                                      (let ((_%$%bad2175221800%_
                                             (reverse _%$%bad2175121788%_)))
                                        (_%__kont3836138362%_
                                         _%$%bad2175221800%_))))))
                        (_%$%loop2174721781%_ _%$%target2174421775%_ '()))))
                   (_%__match3840338404%_
                    (lambda (_%$%e2174121765%_
                             _%$%hd2174221769%_
                             _%$%tl2174321772%_)
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl2174321772%_))
                          (let ((_%__splice3836338364%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl2174321772%_
                                    '0))))
                            (let ((_%$%tl2174621778%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3836338364%_ '1)))
                                  (_%$%target2174421775%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3836338364%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl2174621778%_))
                                  (_%__match3841138412%_
                                   _%$%e2174121765%_
                                   _%$%hd2174221769%_
                                   _%$%tl2174321772%_
                                   _%__splice3836338364%_
                                   _%$%target2174421775%_
                                   _%$%tl2174621778%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g2169721758%_)))))
                          (let () (declare (not safe)) (_%$%g2169721758%_)))))
                   (_%__match3839738398%_
                    (lambda (_%$%e2170421826%_
                             _%$%hd2170521830%_
                             _%$%tl2170621833%_
                             _%$%e2170721836%_
                             _%$%hd2170821840%_
                             _%$%tl2170921843%_
                             _%$%e2171021846%_
                             _%$%hd2171121850%_
                             _%$%tl2171221853%_
                             _%$%e2171321856%_
                             _%$%hd2171421860%_
                             _%$%tl2171521863%_
                             _%__splice3835738358%_
                             _%$%target2171621866%_
                             _%$%tl2171821869%_)
                      (letrec ((_%$%loop2171921872%_
                                (lambda (_%$%hd2171721876%_
                                         _%$%input2172321879%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2171721876%_))
                                      (let ((_%$%e2172021881%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2171721876%_))))
                                        (let ((_%$%lp-tl2172221888%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2172021881%_)))
                                              (_%$%lp-hd2172121885%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2172021881%_))))
                                          (_%$%loop2171921872%_
                                           _%$%lp-tl2172221888%_
                                           (cons _%$%lp-hd2172121885%_
                                                 _%$%input2172321879%_))))
                                      (let ((_%$%input2172421891%_
                                             (reverse _%$%input2172321879%_)))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2171521863%_))
                                            (let ((_%$%e2172521894%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2171521863%_))))
                                              (let ((_%$%tl2172721901%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2172521894%_)))
                                                    (_%$%hd2172621898%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2172521894%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair?
                                                       _%$%hd2172621898%_))
                                                    (let ((_%$%e2172821904%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-e
                                                              _%$%hd2172621898%_))))
                                                      (let ((_%$%tl2173021911%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##cdr _%$%e2172821904%_)))
                    (_%$%hd2172921908%_
                     (let () (declare (not safe)) (##car _%$%e2172821904%_))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair/null? _%$%tl2173021911%_))
                    (let ((_%__splice3835938360%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-split-splice->vector
                              _%$%tl2173021911%_
                              '0))))
                      (let ((_%$%tl2173321917%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3835938360%_ '1)))
                            (_%$%target2173121914%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3835938360%_ '0))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-null? _%$%tl2173321917%_))
                            (letrec ((_%$%loop2173421920%_
                                      (lambda (_%$%hd2173221924%_
                                               _%$%term2173821927%_)
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%hd2173221924%_))
                                            (let ((_%$%e2173521929%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%hd2173221924%_))))
                                              (let ((_%$%lp-tl2173721936%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2173521929%_)))
                                                    (_%$%lp-hd2173621933%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2173521929%_))))
                                                (_%$%loop2173421920%_
                                                 _%$%lp-tl2173721936%_
                                                 (cons _%$%lp-hd2173621933%_
                                                       _%$%term2173821927%_))))
                                            (let ((_%$%term2173921939%_
                                                   (reverse _%$%term2173821927%_)))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2172721901%_))
                                                  (let ((_%$%g2169921942%_
                                                         _%$%term2173921939%_)
                                                        (_%$%g2170021944%_
                                                         _%$%hd2172921908%_)
                                                        (_%$%g2170121945%_
                                                         _%$%input2172421891%_)
                                                        (_%$%g2170221946%_
                                                         _%$%hd2171121850%_)
                                                        (_%$%g2170321947%_
                                                         _%$%hd2170821840%_))
                                                    (if (and (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#identifier? _%$%g2170021944%_))
                     (let ()
                       (declare (not safe))
                       (gx#identifier? _%$%g2170221946%_)))
                (_%__kont3835538356%_
                 _%$%g2169921942%_
                 _%$%g2170021944%_
                 _%$%g2170121945%_
                 _%$%g2170221946%_
                 _%$%g2170321947%_)
                (_%__match3840338404%_
                 _%$%e2170421826%_
                 _%$%hd2170521830%_
                 _%$%tl2170621833%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%__match3840338404%_
                                                   _%$%e2170421826%_
                                                   _%$%hd2170521830%_
                                                   _%$%tl2170621833%_)))))))
                              (_%$%loop2173421920%_
                               _%$%target2173121914%_
                               '()))
                            (_%__match3840338404%_
                             _%$%e2170421826%_
                             _%$%hd2170521830%_
                             _%$%tl2170621833%_))))
                    (_%__match3840338404%_
                     _%$%e2170421826%_
                     _%$%hd2170521830%_
                     _%$%tl2170621833%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3840338404%_
                                                     _%$%e2170421826%_
                                                     _%$%hd2170521830%_
                                                     _%$%tl2170621833%_))))
                                            (_%__match3840338404%_
                                             _%$%e2170421826%_
                                             _%$%hd2170521830%_
                                             _%$%tl2170621833%_)))))))
                        (_%$%loop2171921872%_ _%$%target2171621866%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3835238353%_))
                  (let ((_%$%e2170421826%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3835238353%_))))
                    (let ((_%$%tl2170621833%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2170421826%_)))
                          (_%$%hd2170521830%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2170421826%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2170621833%_))
                          (let ((_%$%e2170721836%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2170621833%_))))
                            (let ((_%$%tl2170921843%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2170721836%_)))
                                  (_%$%hd2170821840%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2170721836%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%tl2170921843%_))
                                  (let ((_%$%e2171021846%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%tl2170921843%_))))
                                    (let ((_%$%tl2171221853%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2171021846%_)))
                                          (_%$%hd2171121850%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2171021846%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl2171221853%_))
                                          (let ((_%$%e2171321856%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl2171221853%_))))
                                            (let ((_%$%tl2171521863%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2171321856%_)))
                                                  (_%$%hd2171421860%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2171321856%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair/null?
                                                     _%$%hd2171421860%_))
                                                  (let ((_%__splice3835738358%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-split-splice->vector
                                                            _%$%hd2171421860%_
                                                            '0))))
                                                    (let ((_%$%tl2171821869%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##vector-ref
                                                              _%__splice3835738358%_
                                                              '1)))
                                                          (_%$%target2171621866%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##vector-ref
                                                              _%__splice3835738358%_
                                                              '0))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-null?
                                                             _%$%tl2171821869%_))
                                                          (_%__match3839738398%_
                                                           _%$%e2170421826%_
                                                           _%$%hd2170521830%_
                                                           _%$%tl2170621833%_
                                                           _%$%e2170721836%_
                                                           _%$%hd2170821840%_
                                                           _%$%tl2170921843%_
                                                           _%$%e2171021846%_
                                                           _%$%hd2171121850%_
                                                           _%$%tl2171221853%_
                                                           _%$%e2171321856%_
                                                           _%$%hd2171421860%_
                                                           _%$%tl2171521863%_
                                                           _%__splice3835738358%_
                                                           _%$%target2171621866%_
                                                           _%$%tl2171821869%_)
                                                          (if (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#stx-pair/null? _%$%tl2170621833%_))
                      (let ((_%__splice3836338364%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-split-splice->vector
                                _%$%tl2170621833%_
                                '0))))
                        (let ((_%$%tl2174621778%_
                               (let ()
                                 (declare (not safe))
                                 (##vector-ref _%__splice3836338364%_ '1)))
                              (_%$%target2174421775%_
                               (let ()
                                 (declare (not safe))
                                 (##vector-ref _%__splice3836338364%_ '0))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-null? _%$%tl2174621778%_))
                              (_%__match3841138412%_
                               _%$%e2170421826%_
                               _%$%hd2170521830%_
                               _%$%tl2170621833%_
                               _%__splice3836338364%_
                               _%$%target2174421775%_
                               _%$%tl2174621778%_)
                              (let ()
                                (declare (not safe))
                                (_%$%g2169721758%_)))))
                      (let () (declare (not safe)) (_%$%g2169721758%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair/null?
                                                         _%$%tl2170621833%_))
                                                      (let ((_%__splice3836338364%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-split-splice->vector
                        _%$%tl2170621833%_
                        '0))))
                (let ((_%$%tl2174621778%_
                       (let ()
                         (declare (not safe))
                         (##vector-ref _%__splice3836338364%_ '1)))
                      (_%$%target2174421775%_
                       (let ()
                         (declare (not safe))
                         (##vector-ref _%__splice3836338364%_ '0))))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-null? _%$%tl2174621778%_))
                      (_%__match3841138412%_
                       _%$%e2170421826%_
                       _%$%hd2170521830%_
                       _%$%tl2170621833%_
                       _%__splice3836338364%_
                       _%$%target2174421775%_
                       _%$%tl2174621778%_)
                      (let () (declare (not safe)) (_%$%g2169721758%_)))))
              (let () (declare (not safe)) (_%$%g2169721758%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair/null?
                                                 _%$%tl2170621833%_))
                                              (let ((_%__splice3836338364%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-split-splice->vector
                                                        _%$%tl2170621833%_
                                                        '0))))
                                                (let ((_%$%tl2174621778%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##vector-ref
                                                          _%__splice3836338364%_
                                                          '1)))
                                                      (_%$%target2174421775%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##vector-ref
                                                          _%__splice3836338364%_
                                                          '0))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-null?
                                                         _%$%tl2174621778%_))
                                                      (_%__match3841138412%_
                                                       _%$%e2170421826%_
                                                       _%$%hd2170521830%_
                                                       _%$%tl2170621833%_
                                                       _%__splice3836338364%_
                                                       _%$%target2174421775%_
                                                       _%$%tl2174621778%_)
                                                      (let ()
                                                        (declare (not safe))
                                                        (_%$%g2169721758%_)))))
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2169721758%_))))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair/null? _%$%tl2170621833%_))
                                      (let ((_%__splice3836338364%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-split-splice->vector
                                                _%$%tl2170621833%_
                                                '0))))
                                        (let ((_%$%tl2174621778%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##vector-ref
                                                  _%__splice3836338364%_
                                                  '1)))
                                              (_%$%target2174421775%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##vector-ref
                                                  _%__splice3836338364%_
                                                  '0))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2174621778%_))
                                              (_%__match3841138412%_
                                               _%$%e2170421826%_
                                               _%$%hd2170521830%_
                                               _%$%tl2170621833%_
                                               _%__splice3836338364%_
                                               _%$%target2174421775%_
                                               _%$%tl2174621778%_)
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2169721758%_)))))
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2169721758%_))))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair/null? _%$%tl2170621833%_))
                              (let ((_%__splice3836338364%_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-split-splice->vector
                                        _%$%tl2170621833%_
                                        '0))))
                                (let ((_%$%tl2174621778%_
                                       (let ()
                                         (declare (not safe))
                                         (##vector-ref
                                          _%__splice3836338364%_
                                          '1)))
                                      (_%$%target2174421775%_
                                       (let ()
                                         (declare (not safe))
                                         (##vector-ref
                                          _%__splice3836338364%_
                                          '0))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl2174621778%_))
                                      (_%__match3841138412%_
                                       _%$%e2170421826%_
                                       _%$%hd2170521830%_
                                       _%$%tl2170621833%_
                                       _%__splice3836338364%_
                                       _%$%target2174421775%_
                                       _%$%tl2174621778%_)
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2169721758%_)))))
                              (let ()
                                (declare (not safe))
                                (_%$%g2169721758%_))))))
                  (let () (declare (not safe)) (_%$%g2169721758%_))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-operator-input|
      (lambda (_%stx22002%_)
        (let* ((_%__stx3841438415%_ _%stx22002%_)
               (_%$%g2200722041%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3841438415%_)))))
          (let ((_%__kont3841738418%_
                 (lambda (_%$%g2200922188%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0
                            '#f
                            'relational-operator-literal))
                         (cons _%$%g2200922188%_ '()))))
                (_%__kont3841938420%_
                 (lambda (_%$%g2202222120%_)
                   (let* ((_%datum22133%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax->datum _%$%g2202222120%_)))
                          (_%spelling22136%_ (symbol->string _%datum22133%_)))
                     (if (if (eq? _%datum22133%_ '?_)
                             '#f
                             (and (> (string-length _%spelling22136%_) '1)
                                  (let ((__tmp39060
                                         (string-ref _%spelling22136%_ '0)))
                                    (declare (not safe))
                                    (##char=? __tmp39060 '#\?))))
                         (cons (let ()
                                 (declare (not safe))
                                 (gx#datum->syntax__0 '#f 'vector))
                               (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'quote))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'variable))
                                                 '()))
                                     (cons (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'quote))
                                                 (cons _%$%g2202222120%_ '()))
                                           '())))
                         (let ()
                           (declare (not safe))
                           (gx#raise-syntax-error
                            '#f
                            '"operator input must be a ?variable or scalar literal"
                            _%$%g2202222120%_))))))
                (_%__kont3842138422%_
                 (lambda (_%$%g2202922068%_)
                   (let ((_%datum22082%_
                          (let ()
                            (declare (not safe))
                            (gx#syntax->datum _%$%g2202922068%_))))
                     (if (or (exact-integer? _%datum22082%_)
                             (boolean? _%datum22082%_)
                             (char? _%datum22082%_))
                         (cons (let ()
                                 (declare (not safe))
                                 (gx#datum->syntax__0
                                  '#f
                                  'relational-operator-literal))
                               (cons _%$%g2202922068%_ '()))
                         (let ()
                           (declare (not safe))
                           (gx#raise-syntax-error
                            '#f
                            '"operator input must be an immutable scalar literal"
                            _%$%g2202922068%_)))))))
            (let ((_%__match3846938470%_
                   (lambda (_%$%e2202322100%_
                            _%$%hd2202422104%_
                            _%$%tl2202522107%_
                            _%$%e2202622110%_
                            _%$%hd2202722114%_
                            _%$%tl2202822117%_)
                     (let ((_%$%g2202222120%_ _%$%hd2202722114%_))
                       (if (let ()
                             (declare (not safe))
                             (gx#identifier? _%$%g2202222120%_))
                           (_%__kont3841938420%_ _%$%g2202222120%_)
                           (_%__kont3842138422%_ _%$%hd2202722114%_))))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3841438415%_))
                  (let ((_%$%e2201022148%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3841438415%_))))
                    (let ((_%$%tl2201222155%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2201022148%_)))
                          (_%$%hd2201122152%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2201022148%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2201222155%_))
                          (let ((_%$%e2201322158%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2201222155%_))))
                            (let ((_%$%tl2201522165%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2201322158%_)))
                                  (_%$%hd2201422162%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2201322158%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%hd2201422162%_))
                                  (let ((_%$%e2201622168%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%hd2201422162%_))))
                                    (let ((_%$%tl2201822175%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2201622168%_)))
                                          (_%$%hd2201722172%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2201622168%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#identifier?
                                             _%$%hd2201722172%_))
                                          (if (let ((__tmp39061
                                                     |gerbil-ascent/program/scheme-language[1]#_g39062_|))
                                                (declare (not safe))
                                                (gx#free-identifier=?
                                                 __tmp39061
                                                 _%$%hd2201722172%_))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%tl2201822175%_))
                                                  (let ((_%$%e2201922178%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%tl2201822175%_))))
                                                    (let ((_%$%tl2202122185%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e2201922178%_)))
                                                          (_%$%hd2202022182%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e2201922178%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-null?
                                                             _%$%tl2202122185%_))
                                                          (if (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#stx-null? _%$%tl2201522165%_))
                      (_%__kont3841738418%_ _%$%hd2202022182%_)
                      (let () (declare (not safe)) (_%$%g2200722041%_)))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-null? _%$%tl2201522165%_))
                      (_%__match3846938470%_
                       _%$%e2201022148%_
                       _%$%hd2201122152%_
                       _%$%tl2201222155%_
                       _%$%e2201322158%_
                       _%$%hd2201422162%_
                       _%$%tl2201522165%_)
                      (let () (declare (not safe)) (_%$%g2200722041%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-null?
                                                         _%$%tl2201522165%_))
                                                      (_%__match3846938470%_
                                                       _%$%e2201022148%_
                                                       _%$%hd2201122152%_
                                                       _%$%tl2201222155%_
                                                       _%$%e2201322158%_
                                                       _%$%hd2201422162%_
                                                       _%$%tl2201522165%_)
                                                      (let ()
                                                        (declare (not safe))
                                                        (_%$%g2200722041%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2201522165%_))
                                                  (_%__match3846938470%_
                                                   _%$%e2201022148%_
                                                   _%$%hd2201122152%_
                                                   _%$%tl2201222155%_
                                                   _%$%e2201322158%_
                                                   _%$%hd2201422162%_
                                                   _%$%tl2201522165%_)
                                                  (let ()
                                                    (declare (not safe))
                                                    (_%$%g2200722041%_))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2201522165%_))
                                              (_%__match3846938470%_
                                               _%$%e2201022148%_
                                               _%$%hd2201122152%_
                                               _%$%tl2201222155%_
                                               _%$%e2201322158%_
                                               _%$%hd2201422162%_
                                               _%$%tl2201522165%_)
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2200722041%_))))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl2201522165%_))
                                      (_%__match3846938470%_
                                       _%$%e2201022148%_
                                       _%$%hd2201122152%_
                                       _%$%tl2201222155%_
                                       _%$%e2201322158%_
                                       _%$%hd2201422162%_
                                       _%$%tl2201522165%_)
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2200722041%_))))))
                          (let () (declare (not safe)) (_%$%g2200722041%_)))))
                  (let () (declare (not safe)) (_%$%g2200722041%_))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-checked-clause|
      (lambda (_%stx22209%_)
        (letrec ((_%logic-variable?22212%_
                  (lambda (_%input23423%_)
                    (if (let ()
                          (declare (not safe))
                          (gx#identifier? _%input23423%_))
                        (let* ((_%datum23426%_
                                (let ()
                                  (declare (not safe))
                                  (gx#syntax->datum _%input23423%_)))
                               (_%spelling23429%_
                                (symbol->string _%datum23426%_)))
                          (if (eq? _%datum23426%_ '?_)
                              '#f
                              (if (> (string-length _%spelling23429%_) '1)
                                  (let ((__tmp39063
                                         (string-ref _%spelling23429%_ '0)))
                                    (declare (not safe))
                                    (##char=? __tmp39063 '#\?))
                                  '#f)))
                        '#f))))
          (let* ((_%__stx3848638487%_ _%stx22209%_)
                 (_%$%g2222022455%_
                  (lambda ()
                    (let ()
                      (declare (not safe))
                      (gx#raise-syntax-error
                       '#f
                       '"Bad syntax; invalid match target"
                       _%__stx3848638487%_)))))
            (let ((_%__kont3848938490%_
                   (lambda (_%$%g2222223374%_
                            _%$%g2222323376%_
                            _%$%g2222423377%_
                            _%$%g2222523378%_
                            _%$%g2222623379%_)
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'relational-where))
                           (cons (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'quote))
                                       (cons _%$%g2222323376%_ '()))
                                 (cons (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f 'list))
                                             (let ((__tmp39064
                                                    (lambda (_%$%g2341023413%_
                                                             _%$%g2341123416%_)
                                                      (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (declare (not safe))
                            (gx#datum->syntax__0
                             '#f
                             'relational-operator-input))
                          (cons _%$%g2341023413%_ '()))
                    _%$%g2341123416%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (declare (not safe))
                                               (foldr__0
                                                __tmp39064
                                                '()
                                                _%$%g2222223374%_)))
                                       '())))))
                  (_%__kont3849338494%_
                   (lambda (_%$%g2226023210%_
                            _%$%g2226123212%_
                            _%$%g2226223213%_
                            _%$%g2226323214%_
                            _%$%g2226423215%_
                            _%$%g2226523216%_)
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'relational-compute))
                           (cons (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'quote))
                                       (cons _%$%g2226223213%_ '()))
                                 (cons (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0
                                                '#f
                                                'quote))
                                             (cons _%$%g2226123212%_ '()))
                                       (cons (cons (let ()
                                                     (declare (not safe))
                                                     (gx#datum->syntax__0
                                                      '#f
                                                      'list))
                                                   (let ((__tmp39065
                                                          (lambda (_%$%g2325023253%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           _%$%g2325123256%_)
                    (cons (cons (let ()
                                  (declare (not safe))
                                  (gx#datum->syntax__0
                                   '#f
                                   'relational-operator-input))
                                (cons _%$%g2325023253%_ '()))
                          _%$%g2325123256%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (declare (not safe))
                                                     (foldr__0
                                                      __tmp39065
                                                      '()
                                                      _%$%g2226023210%_)))
                                             '()))))))
                  (_%__kont3849738498%_
                   (lambda (_%$%g2230223040%_
                            _%$%g2230323042%_
                            _%$%g2230423043%_
                            _%$%g2230523044%_
                            _%$%g2230623045%_)
                     (cons _%$%g2230523044%_
                           (cons (cons _%$%g2230323042%_
                                       (let ((__tmp39066
                                              (lambda (_%$%g2307623079%_
                                                       _%$%g2307723082%_)
                                                (cons _%$%g2307623079%_
                                                      _%$%g2307723082%_))))
                                         (declare (not safe))
                                         (foldr__0
                                          __tmp39066
                                          '()
                                          _%$%g2230223040%_)))
                                 '()))))
                  (_%__kont3850138502%_
                   (lambda (_%$%g2234022848%_
                            _%$%g2234122850%_
                            _%$%g2234222851%_
                            _%$%g2234322852%_
                            _%$%g2234422853%_
                            _%$%g2234522854%_
                            _%$%g2234622855%_
                            _%$%g2234722856%_)
                     (cons _%$%g2234522854%_
                           (cons _%$%g2234422853%_
                                 (cons _%$%g2234322852%_
                                       (cons (let ((__tmp39067
                                                    (lambda (_%$%g2290822913%_
                                                             _%$%g2290922916%_)
                                                      (cons _%$%g2290822913%_
                                                            _%$%g2290922916%_))))
                                               (declare (not safe))
                                               (foldr__0
                                                __tmp39067
                                                '()
                                                _%$%g2234222851%_))
                                             (cons (cons _%$%g2234122850%_
                                                         (let ((__tmp39068
                                                                (lambda (_%$%g2291022919%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                 _%$%g2291122922%_)
                          (cons _%$%g2291022919%_ _%$%g2291122922%_))))
                   (declare (not safe))
                   (foldr__0 __tmp39068 '() _%$%g2234022848%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   '())))))))
                  (_%__kont3850738508%_
                   (lambda (_%$%g2239922634%_
                            _%$%g2240022636%_
                            _%$%g2240122637%_
                            _%$%g2240222638%_
                            _%$%g2240322639%_)
                     (cons _%$%g2240322639%_
                           (cons (cons _%$%g2240022636%_
                                       (let ((__tmp39069
                                              (lambda (_%$%g2266622669%_
                                                       _%$%g2266722672%_)
                                                (cons _%$%g2266622669%_
                                                      _%$%g2266722672%_))))
                                         (declare (not safe))
                                         (foldr__0
                                          __tmp39069
                                          '()
                                          _%$%g2239922634%_)))
                                 '()))))
                  (_%__kont3851138512%_
                   (lambda (_%$%g2243122512%_
                            _%$%g2243222514%_
                            _%$%g2243322515%_
                            _%$%g2243422516%_)
                     (let ()
                       (declare (not safe))
                       (gx#raise-syntax-error
                        '#f
                        '"expected atom, not, reduce, where, or compute clause"
                        _%$%g2243122512%_)))))
              (let* ((_%__match3880938810%_
                      (lambda (_%$%e2240422546%_
                               _%$%hd2240522550%_
                               _%$%tl2240622553%_
                               _%$%e2240722556%_
                               _%$%hd2240822560%_
                               _%$%tl2240922563%_
                               _%$%e2241022566%_
                               _%$%hd2241122570%_
                               _%$%tl2241222573%_
                               _%$%e2241322576%_
                               _%$%hd2241422580%_
                               _%$%tl2241522583%_
                               _%$%e2241622586%_
                               _%$%hd2241722590%_
                               _%$%tl2241822593%_
                               _%$%e2241922596%_
                               _%$%hd2242022600%_
                               _%$%tl2242122603%_
                               _%__splice3850938510%_
                               _%$%target2242222606%_
                               _%$%tl2242422609%_)
                        (letrec ((_%$%loop2242522612%_
                                  (lambda (_%$%hd2242322616%_
                                           _%$%term2242922619%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%hd2242322616%_))
                                        (let ((_%$%e2242622621%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%hd2242322616%_))))
                                          (let ((_%$%lp-tl2242822628%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2242622621%_)))
                                                (_%$%lp-hd2242722625%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2242622621%_))))
                                            (_%$%loop2242522612%_
                                             _%$%lp-tl2242822628%_
                                             (cons _%$%lp-hd2242722625%_
                                                   _%$%term2242922619%_))))
                                        (let ((_%$%term2243022631%_
                                               (reverse _%$%term2242922619%_)))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2241822593%_))
                                              (let ((_%$%g2239922634%_
                                                     _%$%term2243022631%_)
                                                    (_%$%g2240022636%_
                                                     _%$%hd2242022600%_)
                                                    (_%$%g2240122637%_
                                                     _%$%hd2241422580%_)
                                                    (_%$%g2240222638%_
                                                     _%$%hd2241122570%_)
                                                    (_%$%g2240322639%_
                                                     _%$%hd2240822560%_))
                                                (if (and (let ()
                                                           (declare (not safe))
                                                           (gx#identifier?
                                                            _%$%g2240322639%_))
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#identifier?
                                                            _%$%g2240022636%_))
                                                         (not (let ((__tmp39070
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (let ()
                               (declare (not safe))
                               (gx#syntax->datum _%$%g2240022636%_))))
                        (declare (not safe))
                        (##memq __tmp39070 '(where compute not reduce)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__kont3850738508%_
                                                     _%$%g2239922634%_
                                                     _%$%g2240022636%_
                                                     _%$%g2240122637%_
                                                     _%$%g2240222638%_
                                                     _%$%g2240322639%_)
                                                    (_%__kont3851138512%_
                                                     _%$%hd2241722590%_
                                                     _%$%hd2241422580%_
                                                     _%$%hd2241122570%_
                                                     _%$%hd2240822560%_)))
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2222022455%_))))))))
                          (_%$%loop2242522612%_ _%$%target2242222606%_ '()))))
                     (_%__match3880138802%_
                      (lambda (_%$%e2240422546%_
                               _%$%hd2240522550%_
                               _%$%tl2240622553%_
                               _%$%e2240722556%_
                               _%$%hd2240822560%_
                               _%$%tl2240922563%_
                               _%$%e2241022566%_
                               _%$%hd2241122570%_
                               _%$%tl2241222573%_
                               _%$%e2241322576%_
                               _%$%hd2241422580%_
                               _%$%tl2241522583%_
                               _%$%e2241622586%_
                               _%$%hd2241722590%_
                               _%$%tl2241822593%_
                               _%$%e2241922596%_
                               _%$%hd2242022600%_
                               _%$%tl2242122603%_)
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair/null? _%$%tl2242122603%_))
                            (let ((_%__splice3850938510%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-split-splice->vector
                                      _%$%tl2242122603%_
                                      '0))))
                              (let ((_%$%tl2242422609%_
                                     (let ()
                                       (declare (not safe))
                                       (##vector-ref
                                        _%__splice3850938510%_
                                        '1)))
                                    (_%$%target2242222606%_
                                     (let ()
                                       (declare (not safe))
                                       (##vector-ref
                                        _%__splice3850938510%_
                                        '0))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl2242422609%_))
                                    (_%__match3880938810%_
                                     _%$%e2240422546%_
                                     _%$%hd2240522550%_
                                     _%$%tl2240622553%_
                                     _%$%e2240722556%_
                                     _%$%hd2240822560%_
                                     _%$%tl2240922563%_
                                     _%$%e2241022566%_
                                     _%$%hd2241122570%_
                                     _%$%tl2241222573%_
                                     _%$%e2241322576%_
                                     _%$%hd2241422580%_
                                     _%$%tl2241522583%_
                                     _%$%e2241622586%_
                                     _%$%hd2241722590%_
                                     _%$%tl2241822593%_
                                     _%$%e2241922596%_
                                     _%$%hd2242022600%_
                                     _%$%tl2242122603%_
                                     _%__splice3850938510%_
                                     _%$%target2242222606%_
                                     _%$%tl2242422609%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2241822593%_))
                                        (_%__kont3851138512%_
                                         _%$%hd2241722590%_
                                         _%$%hd2241422580%_
                                         _%$%hd2241122570%_
                                         _%$%hd2240822560%_)
                                        (let ()
                                          (declare (not safe))
                                          (_%$%g2222022455%_))))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2241822593%_))
                                (_%__kont3851138512%_
                                 _%$%hd2241722590%_
                                 _%$%hd2241422580%_
                                 _%$%hd2241122570%_
                                 _%$%hd2240822560%_)
                                (let ()
                                  (declare (not safe))
                                  (_%$%g2222022455%_))))))
                     (_%__match3876538766%_
                      (lambda (_%$%e2234822682%_
                               _%$%hd2234922686%_
                               _%$%tl2235022689%_
                               _%$%e2235122692%_
                               _%$%hd2235222696%_
                               _%$%tl2235322699%_
                               _%$%e2235422702%_
                               _%$%hd2235522706%_
                               _%$%tl2235622709%_
                               _%$%e2235722712%_
                               _%$%hd2235822716%_
                               _%$%tl2235922719%_
                               _%$%e2236022722%_
                               _%$%hd2236122726%_
                               _%$%tl2236222729%_
                               _%$%e2236322732%_
                               _%$%hd2236422736%_
                               _%$%tl2236522739%_
                               _%$%e2236622742%_
                               _%$%hd2236722746%_
                               _%$%tl2236822749%_
                               _%$%e2236922752%_
                               _%$%hd2237022756%_
                               _%$%tl2237122759%_
                               _%$%e2237222762%_
                               _%$%hd2237322766%_
                               _%$%tl2237422769%_
                               _%__splice3850338504%_
                               _%$%target2237522772%_
                               _%$%tl2237722775%_)
                        (letrec ((_%$%loop2237822778%_
                                  (lambda (_%$%hd2237622782%_
                                           _%$%input2238222785%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%hd2237622782%_))
                                        (let ((_%$%e2237922787%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%hd2237622782%_))))
                                          (let ((_%$%lp-tl2238122794%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2237922787%_)))
                                                (_%$%lp-hd2238022791%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2237922787%_))))
                                            (_%$%loop2237822778%_
                                             _%$%lp-tl2238122794%_
                                             (cons _%$%lp-hd2238022791%_
                                                   _%$%input2238222785%_))))
                                        (let ((_%$%input2238322797%_
                                               (reverse _%$%input2238222785%_)))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair?
                                                 _%$%tl2237122759%_))
                                              (let ((_%$%e2238422800%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-e
                                                        _%$%tl2237122759%_))))
                                                (let ((_%$%tl2238622807%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##cdr _%$%e2238422800%_)))
                                                      (_%$%hd2238522804%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##car _%$%e2238422800%_))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair?
                                                         _%$%hd2238522804%_))
                                                      (let ((_%$%e2238722810%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-e _%$%hd2238522804%_))))
                (let ((_%$%tl2238922817%_
                       (let () (declare (not safe)) (##cdr _%$%e2238722810%_)))
                      (_%$%hd2238822814%_
                       (let ()
                         (declare (not safe))
                         (##car _%$%e2238722810%_))))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-pair/null? _%$%tl2238922817%_))
                      (let ((_%__splice3850538506%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-split-splice->vector
                                _%$%tl2238922817%_
                                '0))))
                        (let ((_%$%tl2239222823%_
                               (let ()
                                 (declare (not safe))
                                 (##vector-ref _%__splice3850538506%_ '1)))
                              (_%$%target2239022820%_
                               (let ()
                                 (declare (not safe))
                                 (##vector-ref _%__splice3850538506%_ '0))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-null? _%$%tl2239222823%_))
                              (letrec ((_%$%loop2239322826%_
                                        (lambda (_%$%hd2239122830%_
                                                 _%$%term2239722833%_)
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair?
                                                 _%$%hd2239122830%_))
                                              (let ((_%$%e2239422835%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-e
                                                        _%$%hd2239122830%_))))
                                                (let ((_%$%lp-tl2239622842%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##cdr _%$%e2239422835%_)))
                                                      (_%$%lp-hd2239522839%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##car _%$%e2239422835%_))))
                                                  (_%$%loop2239322826%_
                                                   _%$%lp-tl2239622842%_
                                                   (cons _%$%lp-hd2239522839%_
                                                         _%$%term2239722833%_))))
                                              (let ((_%$%term2239822845%_
                                                     (reverse _%$%term2239722833%_)))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl2238622807%_))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl2236222729%_))
                                                        (let ((_%$%g2234022848%_
                                                               _%$%term2239822845%_)
                                                              (_%$%g2234122850%_
                                                               _%$%hd2238822814%_)
                                                              (_%$%g2234222851%_
                                                               _%$%input2238322797%_)
                                                              (_%$%g2234322852%_
                                                               _%$%hd2237322766%_)
                                                              (_%$%g2234422853%_
                                                               _%$%hd2236722746%_)
                                                              (_%$%g2234522854%_
                                                               _%$%hd2235822716%_)
                                                              (_%$%g2234622855%_
                                                               _%$%hd2235522706%_)
                                                              (_%$%g2234722856%_
                                                               _%$%hd2235222696%_))
                                                          (if (and (_%logic-variable?22212%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%$%g2234422853%_)
                           (let ()
                             (declare (not safe))
                             (gx#identifier? _%$%g2234322852%_))
                           (let ((__tmp39071
                                  (let ((__tmp39072
                                         (let ((__tmp39073
                                                (lambda (_%$%g2290022903%_
                                                         _%$%g2290122906%_)
                                                  (cons _%$%g2290022903%_
                                                        _%$%g2290122906%_))))
                                           (declare (not safe))
                                           (foldr__0
                                            __tmp39073
                                            '()
                                            _%$%g2234222851%_))))
                                    (declare (not safe))
                                    (gx#syntax->list __tmp39072))))
                             (declare (not safe))
                             (andmap__0 _%logic-variable?22212%_ __tmp39071)))
                      (_%__kont3850138502%_
                       _%$%g2234022848%_
                       _%$%g2234122850%_
                       _%$%g2234222851%_
                       _%$%g2234322852%_
                       _%$%g2234422853%_
                       _%$%g2234522854%_
                       _%$%g2234622855%_
                       _%$%g2234722856%_)
                      (_%__match3880138802%_
                       _%$%e2234822682%_
                       _%$%hd2234922686%_
                       _%$%tl2235022689%_
                       _%$%e2235122692%_
                       _%$%hd2235222696%_
                       _%$%tl2235322699%_
                       _%$%e2235422702%_
                       _%$%hd2235522706%_
                       _%$%tl2235622709%_
                       _%$%e2235722712%_
                       _%$%hd2235822716%_
                       _%$%tl2235922719%_
                       _%$%e2236022722%_
                       _%$%hd2236122726%_
                       _%$%tl2236222729%_
                       _%$%e2236322732%_
                       _%$%hd2236422736%_
                       _%$%tl2236522739%_)))
                (_%__match3880138802%_
                 _%$%e2234822682%_
                 _%$%hd2234922686%_
                 _%$%tl2235022689%_
                 _%$%e2235122692%_
                 _%$%hd2235222696%_
                 _%$%tl2235322699%_
                 _%$%e2235422702%_
                 _%$%hd2235522706%_
                 _%$%tl2235622709%_
                 _%$%e2235722712%_
                 _%$%hd2235822716%_
                 _%$%tl2235922719%_
                 _%$%e2236022722%_
                 _%$%hd2236122726%_
                 _%$%tl2236222729%_
                 _%$%e2236322732%_
                 _%$%hd2236422736%_
                 _%$%tl2236522739%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3880138802%_
                                                     _%$%e2234822682%_
                                                     _%$%hd2234922686%_
                                                     _%$%tl2235022689%_
                                                     _%$%e2235122692%_
                                                     _%$%hd2235222696%_
                                                     _%$%tl2235322699%_
                                                     _%$%e2235422702%_
                                                     _%$%hd2235522706%_
                                                     _%$%tl2235622709%_
                                                     _%$%e2235722712%_
                                                     _%$%hd2235822716%_
                                                     _%$%tl2235922719%_
                                                     _%$%e2236022722%_
                                                     _%$%hd2236122726%_
                                                     _%$%tl2236222729%_
                                                     _%$%e2236322732%_
                                                     _%$%hd2236422736%_
                                                     _%$%tl2236522739%_)))))))
                                (_%$%loop2239322826%_
                                 _%$%target2239022820%_
                                 '()))
                              (_%__match3880138802%_
                               _%$%e2234822682%_
                               _%$%hd2234922686%_
                               _%$%tl2235022689%_
                               _%$%e2235122692%_
                               _%$%hd2235222696%_
                               _%$%tl2235322699%_
                               _%$%e2235422702%_
                               _%$%hd2235522706%_
                               _%$%tl2235622709%_
                               _%$%e2235722712%_
                               _%$%hd2235822716%_
                               _%$%tl2235922719%_
                               _%$%e2236022722%_
                               _%$%hd2236122726%_
                               _%$%tl2236222729%_
                               _%$%e2236322732%_
                               _%$%hd2236422736%_
                               _%$%tl2236522739%_))))
                      (_%__match3880138802%_
                       _%$%e2234822682%_
                       _%$%hd2234922686%_
                       _%$%tl2235022689%_
                       _%$%e2235122692%_
                       _%$%hd2235222696%_
                       _%$%tl2235322699%_
                       _%$%e2235422702%_
                       _%$%hd2235522706%_
                       _%$%tl2235622709%_
                       _%$%e2235722712%_
                       _%$%hd2235822716%_
                       _%$%tl2235922719%_
                       _%$%e2236022722%_
                       _%$%hd2236122726%_
                       _%$%tl2236222729%_
                       _%$%e2236322732%_
                       _%$%hd2236422736%_
                       _%$%tl2236522739%_))))
              (_%__match3880138802%_
               _%$%e2234822682%_
               _%$%hd2234922686%_
               _%$%tl2235022689%_
               _%$%e2235122692%_
               _%$%hd2235222696%_
               _%$%tl2235322699%_
               _%$%e2235422702%_
               _%$%hd2235522706%_
               _%$%tl2235622709%_
               _%$%e2235722712%_
               _%$%hd2235822716%_
               _%$%tl2235922719%_
               _%$%e2236022722%_
               _%$%hd2236122726%_
               _%$%tl2236222729%_
               _%$%e2236322732%_
               _%$%hd2236422736%_
               _%$%tl2236522739%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%__match3880138802%_
                                               _%$%e2234822682%_
                                               _%$%hd2234922686%_
                                               _%$%tl2235022689%_
                                               _%$%e2235122692%_
                                               _%$%hd2235222696%_
                                               _%$%tl2235322699%_
                                               _%$%e2235422702%_
                                               _%$%hd2235522706%_
                                               _%$%tl2235622709%_
                                               _%$%e2235722712%_
                                               _%$%hd2235822716%_
                                               _%$%tl2235922719%_
                                               _%$%e2236022722%_
                                               _%$%hd2236122726%_
                                               _%$%tl2236222729%_
                                               _%$%e2236322732%_
                                               _%$%hd2236422736%_
                                               _%$%tl2236522739%_)))))))
                          (_%$%loop2237822778%_ _%$%target2237522772%_ '()))))
                     (_%__match3869938700%_
                      (lambda (_%$%e2230722932%_
                               _%$%hd2230822936%_
                               _%$%tl2230922939%_
                               _%$%e2231022942%_
                               _%$%hd2231122946%_
                               _%$%tl2231222949%_
                               _%$%e2231322952%_
                               _%$%hd2231422956%_
                               _%$%tl2231522959%_
                               _%$%e2231622962%_
                               _%$%hd2231722966%_
                               _%$%tl2231822969%_
                               _%$%e2231922972%_
                               _%$%hd2232022976%_
                               _%$%tl2232122979%_
                               _%$%e2232222982%_
                               _%$%hd2232322986%_
                               _%$%tl2232422989%_
                               _%$%e2232522992%_
                               _%$%hd2232622996%_
                               _%$%tl2232722999%_
                               _%$%e2232823002%_
                               _%$%hd2232923006%_
                               _%$%tl2233023009%_
                               _%__splice3849938500%_
                               _%$%target2233123012%_
                               _%$%tl2233323015%_)
                        (letrec ((_%$%loop2233423018%_
                                  (lambda (_%$%hd2233223022%_
                                           _%$%term2233823025%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%hd2233223022%_))
                                        (let ((_%$%e2233523027%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%hd2233223022%_))))
                                          (let ((_%$%lp-tl2233723034%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2233523027%_)))
                                                (_%$%lp-hd2233623031%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2233523027%_))))
                                            (_%$%loop2233423018%_
                                             _%$%lp-tl2233723034%_
                                             (cons _%$%lp-hd2233623031%_
                                                   _%$%term2233823025%_))))
                                        (let ((_%$%term2233923037%_
                                               (reverse _%$%term2233823025%_)))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2232722999%_))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2232122979%_))
                                                  (_%__kont3849738498%_
                                                   _%$%term2233923037%_
                                                   _%$%hd2232923006%_
                                                   _%$%hd2231722966%_
                                                   _%$%hd2231422956%_
                                                   _%$%hd2231122946%_)
                                                  (_%__match3880138802%_
                                                   _%$%e2230722932%_
                                                   _%$%hd2230822936%_
                                                   _%$%tl2230922939%_
                                                   _%$%e2231022942%_
                                                   _%$%hd2231122946%_
                                                   _%$%tl2231222949%_
                                                   _%$%e2231322952%_
                                                   _%$%hd2231422956%_
                                                   _%$%tl2231522959%_
                                                   _%$%e2231622962%_
                                                   _%$%hd2231722966%_
                                                   _%$%tl2231822969%_
                                                   _%$%e2231922972%_
                                                   _%$%hd2232022976%_
                                                   _%$%tl2232122979%_
                                                   _%$%e2232222982%_
                                                   _%$%hd2232322986%_
                                                   _%$%tl2232422989%_))
                                              (_%__match3880138802%_
                                               _%$%e2230722932%_
                                               _%$%hd2230822936%_
                                               _%$%tl2230922939%_
                                               _%$%e2231022942%_
                                               _%$%hd2231122946%_
                                               _%$%tl2231222949%_
                                               _%$%e2231322952%_
                                               _%$%hd2231422956%_
                                               _%$%tl2231522959%_
                                               _%$%e2231622962%_
                                               _%$%hd2231722966%_
                                               _%$%tl2231822969%_
                                               _%$%e2231922972%_
                                               _%$%hd2232022976%_
                                               _%$%tl2232122979%_
                                               _%$%e2232222982%_
                                               _%$%hd2232322986%_
                                               _%$%tl2232422989%_)))))))
                          (_%$%loop2233423018%_ _%$%target2233123012%_ '()))))
                     (_%__match3863938640%_
                      (lambda (_%$%e2226623092%_
                               _%$%hd2226723096%_
                               _%$%tl2226823099%_
                               _%$%e2226923102%_
                               _%$%hd2227023106%_
                               _%$%tl2227123109%_
                               _%$%e2227223112%_
                               _%$%hd2227323116%_
                               _%$%tl2227423119%_
                               _%$%e2227523122%_
                               _%$%hd2227623126%_
                               _%$%tl2227723129%_
                               _%$%e2227823132%_
                               _%$%hd2227923136%_
                               _%$%tl2228023139%_
                               _%$%e2228123142%_
                               _%$%hd2228223146%_
                               _%$%tl2228323149%_
                               _%$%e2228423152%_
                               _%$%hd2228523156%_
                               _%$%tl2228623159%_
                               _%$%e2228723162%_
                               _%$%hd2228823166%_
                               _%$%tl2228923169%_
                               _%$%e2229023172%_
                               _%$%hd2229123176%_
                               _%$%tl2229223179%_
                               _%__splice3849538496%_
                               _%$%target2229323182%_
                               _%$%tl2229523185%_)
                        (letrec ((_%$%loop2229623188%_
                                  (lambda (_%$%hd2229423192%_
                                           _%$%input2230023195%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%hd2229423192%_))
                                        (let ((_%$%e2229723197%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%hd2229423192%_))))
                                          (let ((_%$%lp-tl2229923204%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2229723197%_)))
                                                (_%$%lp-hd2229823201%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2229723197%_))))
                                            (_%$%loop2229623188%_
                                             _%$%lp-tl2229923204%_
                                             (cons _%$%lp-hd2229823201%_
                                                   _%$%input2230023195%_))))
                                        (let ((_%$%input2230123207%_
                                               (reverse _%$%input2230023195%_)))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2228923169%_))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2228023139%_))
                                                  (let ((_%$%g2226023210%_
                                                         _%$%input2230123207%_)
                                                        (_%$%g2226123212%_
                                                         _%$%hd2229123176%_)
                                                        (_%$%g2226223213%_
                                                         _%$%hd2228523156%_)
                                                        (_%$%g2226323214%_
                                                         _%$%hd2227623126%_)
                                                        (_%$%g2226423215%_
                                                         _%$%hd2227323116%_)
                                                        (_%$%g2226523216%_
                                                         _%$%hd2227023106%_))
                                                    (if (and (_%logic-variable?22212%_
                                                              _%$%g2226223213%_)
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#identifier? _%$%g2226123212%_)))
                (_%__kont3849338494%_
                 _%$%g2226023210%_
                 _%$%g2226123212%_
                 _%$%g2226223213%_
                 _%$%g2226323214%_
                 _%$%g2226423215%_
                 _%$%g2226523216%_)
                (_%__match3880138802%_
                 _%$%e2226623092%_
                 _%$%hd2226723096%_
                 _%$%tl2226823099%_
                 _%$%e2226923102%_
                 _%$%hd2227023106%_
                 _%$%tl2227123109%_
                 _%$%e2227223112%_
                 _%$%hd2227323116%_
                 _%$%tl2227423119%_
                 _%$%e2227523122%_
                 _%$%hd2227623126%_
                 _%$%tl2227723129%_
                 _%$%e2227823132%_
                 _%$%hd2227923136%_
                 _%$%tl2228023139%_
                 _%$%e2228123142%_
                 _%$%hd2228223146%_
                 _%$%tl2228323149%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%__match3880138802%_
                                                   _%$%e2226623092%_
                                                   _%$%hd2226723096%_
                                                   _%$%tl2226823099%_
                                                   _%$%e2226923102%_
                                                   _%$%hd2227023106%_
                                                   _%$%tl2227123109%_
                                                   _%$%e2227223112%_
                                                   _%$%hd2227323116%_
                                                   _%$%tl2227423119%_
                                                   _%$%e2227523122%_
                                                   _%$%hd2227623126%_
                                                   _%$%tl2227723129%_
                                                   _%$%e2227823132%_
                                                   _%$%hd2227923136%_
                                                   _%$%tl2228023139%_
                                                   _%$%e2228123142%_
                                                   _%$%hd2228223146%_
                                                   _%$%tl2228323149%_))
                                              (_%__match3880138802%_
                                               _%$%e2226623092%_
                                               _%$%hd2226723096%_
                                               _%$%tl2226823099%_
                                               _%$%e2226923102%_
                                               _%$%hd2227023106%_
                                               _%$%tl2227123109%_
                                               _%$%e2227223112%_
                                               _%$%hd2227323116%_
                                               _%$%tl2227423119%_
                                               _%$%e2227523122%_
                                               _%$%hd2227623126%_
                                               _%$%tl2227723129%_
                                               _%$%e2227823132%_
                                               _%$%hd2227923136%_
                                               _%$%tl2228023139%_
                                               _%$%e2228123142%_
                                               _%$%hd2228223146%_
                                               _%$%tl2228323149%_)))))))
                          (_%$%loop2229623188%_ _%$%target2229323182%_ '()))))
                     (_%__match3857338574%_
                      (lambda (_%$%e2222723266%_
                               _%$%hd2222823270%_
                               _%$%tl2222923273%_
                               _%$%e2223023276%_
                               _%$%hd2223123280%_
                               _%$%tl2223223283%_
                               _%$%e2223323286%_
                               _%$%hd2223423290%_
                               _%$%tl2223523293%_
                               _%$%e2223623296%_
                               _%$%hd2223723300%_
                               _%$%tl2223823303%_
                               _%$%e2223923306%_
                               _%$%hd2224023310%_
                               _%$%tl2224123313%_
                               _%$%e2224223316%_
                               _%$%hd2224323320%_
                               _%$%tl2224423323%_
                               _%$%e2224523326%_
                               _%$%hd2224623330%_
                               _%$%tl2224723333%_
                               _%$%e2224823336%_
                               _%$%hd2224923340%_
                               _%$%tl2225023343%_
                               _%__splice3849138492%_
                               _%$%target2225123346%_
                               _%$%tl2225323349%_)
                        (letrec ((_%$%loop2225423352%_
                                  (lambda (_%$%hd2225223356%_
                                           _%$%input2225823359%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%hd2225223356%_))
                                        (let ((_%$%e2225523361%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%hd2225223356%_))))
                                          (let ((_%$%lp-tl2225723368%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2225523361%_)))
                                                (_%$%lp-hd2225623365%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2225523361%_))))
                                            (_%$%loop2225423352%_
                                             _%$%lp-tl2225723368%_
                                             (cons _%$%lp-hd2225623365%_
                                                   _%$%input2225823359%_))))
                                        (let ((_%$%input2225923371%_
                                               (reverse _%$%input2225823359%_)))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2224723333%_))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2224123313%_))
                                                  (let ((_%$%g2222223374%_
                                                         _%$%input2225923371%_)
                                                        (_%$%g2222323376%_
                                                         _%$%hd2224923340%_)
                                                        (_%$%g2222423377%_
                                                         _%$%hd2223723300%_)
                                                        (_%$%g2222523378%_
                                                         _%$%hd2223423290%_)
                                                        (_%$%g2222623379%_
                                                         _%$%hd2223123280%_))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#identifier?
                                                           _%$%g2222323376%_))
                                                        (_%__kont3848938490%_
                                                         _%$%g2222223374%_
                                                         _%$%g2222323376%_
                                                         _%$%g2222423377%_
                                                         _%$%g2222523378%_
                                                         _%$%g2222623379%_)
                                                        (_%__match3880138802%_
                                                         _%$%e2222723266%_
                                                         _%$%hd2222823270%_
                                                         _%$%tl2222923273%_
                                                         _%$%e2223023276%_
                                                         _%$%hd2223123280%_
                                                         _%$%tl2223223283%_
                                                         _%$%e2223323286%_
                                                         _%$%hd2223423290%_
                                                         _%$%tl2223523293%_
                                                         _%$%e2223623296%_
                                                         _%$%hd2223723300%_
                                                         _%$%tl2223823303%_
                                                         _%$%e2223923306%_
                                                         _%$%hd2224023310%_
                                                         _%$%tl2224123313%_
                                                         _%$%e2224223316%_
                                                         _%$%hd2224323320%_
                                                         _%$%tl2224423323%_)))
                                                  (_%__match3880138802%_
                                                   _%$%e2222723266%_
                                                   _%$%hd2222823270%_
                                                   _%$%tl2222923273%_
                                                   _%$%e2223023276%_
                                                   _%$%hd2223123280%_
                                                   _%$%tl2223223283%_
                                                   _%$%e2223323286%_
                                                   _%$%hd2223423290%_
                                                   _%$%tl2223523293%_
                                                   _%$%e2223623296%_
                                                   _%$%hd2223723300%_
                                                   _%$%tl2223823303%_
                                                   _%$%e2223923306%_
                                                   _%$%hd2224023310%_
                                                   _%$%tl2224123313%_
                                                   _%$%e2224223316%_
                                                   _%$%hd2224323320%_
                                                   _%$%tl2224423323%_))
                                              (_%__match3880138802%_
                                               _%$%e2222723266%_
                                               _%$%hd2222823270%_
                                               _%$%tl2222923273%_
                                               _%$%e2223023276%_
                                               _%$%hd2223123280%_
                                               _%$%tl2223223283%_
                                               _%$%e2223323286%_
                                               _%$%hd2223423290%_
                                               _%$%tl2223523293%_
                                               _%$%e2223623296%_
                                               _%$%hd2223723300%_
                                               _%$%tl2223823303%_
                                               _%$%e2223923306%_
                                               _%$%hd2224023310%_
                                               _%$%tl2224123313%_
                                               _%$%e2224223316%_
                                               _%$%hd2224323320%_
                                               _%$%tl2224423323%_)))))))
                          (_%$%loop2225423352%_ _%$%target2225123346%_ '())))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair? _%__stx3848638487%_))
                    (let ((_%$%e2222723266%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%__stx3848638487%_))))
                      (let ((_%$%tl2222923273%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e2222723266%_)))
                            (_%$%hd2222823270%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e2222723266%_))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair? _%$%tl2222923273%_))
                            (let ((_%$%e2223023276%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-e _%$%tl2222923273%_))))
                              (let ((_%$%tl2223223283%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e2223023276%_)))
                                    (_%$%hd2223123280%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e2223023276%_))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%tl2223223283%_))
                                    (let ((_%$%e2223323286%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%tl2223223283%_))))
                                      (let ((_%$%tl2223523293%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2223323286%_)))
                                            (_%$%hd2223423290%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2223323286%_))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2223523293%_))
                                            (let ((_%$%e2223623296%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2223523293%_))))
                                              (let ((_%$%tl2223823303%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2223623296%_)))
                                                    (_%$%hd2223723300%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2223623296%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair?
                                                       _%$%tl2223823303%_))
                                                    (let ((_%$%e2223923306%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-e
                                                              _%$%tl2223823303%_))))
                                                      (let ((_%$%tl2224123313%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##cdr _%$%e2223923306%_)))
                    (_%$%hd2224023310%_
                     (let () (declare (not safe)) (##car _%$%e2223923306%_))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair? _%$%hd2224023310%_))
                    (let ((_%$%e2224223316%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%$%hd2224023310%_))))
                      (let ((_%$%tl2224423323%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e2224223316%_)))
                            (_%$%hd2224323320%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e2224223316%_))))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%hd2224323320%_))
                            (if (let ((__tmp39074
                                       |gerbil-ascent/program/scheme-language[1]#_g39075_|))
                                  (declare (not safe))
                                  (gx#free-identifier=?
                                   __tmp39074
                                   _%$%hd2224323320%_))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%tl2224423323%_))
                                    (let ((_%$%e2224523326%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%tl2224423323%_))))
                                      (let ((_%$%tl2224723333%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2224523326%_)))
                                            (_%$%hd2224623330%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2224523326%_))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%hd2224623330%_))
                                            (let ((_%$%e2224823336%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%hd2224623330%_))))
                                              (let ((_%$%tl2225023343%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2224823336%_)))
                                                    (_%$%hd2224923340%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2224823336%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%tl2225023343%_))
                                                    (let ((_%__splice3849138492%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%tl2225023343%_
                                                              '0))))
                                                      (let ((_%$%tl2225323349%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3849138492%_ '1)))
                    (_%$%target2225123346%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3849138492%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2225323349%_))
                    (_%__match3857338574%_
                     _%$%e2222723266%_
                     _%$%hd2222823270%_
                     _%$%tl2222923273%_
                     _%$%e2223023276%_
                     _%$%hd2223123280%_
                     _%$%tl2223223283%_
                     _%$%e2223323286%_
                     _%$%hd2223423290%_
                     _%$%tl2223523293%_
                     _%$%e2223623296%_
                     _%$%hd2223723300%_
                     _%$%tl2223823303%_
                     _%$%e2223923306%_
                     _%$%hd2224023310%_
                     _%$%tl2224123313%_
                     _%$%e2224223316%_
                     _%$%hd2224323320%_
                     _%$%tl2224423323%_
                     _%$%e2224523326%_
                     _%$%hd2224623330%_
                     _%$%tl2224723333%_
                     _%$%e2224823336%_
                     _%$%hd2224923340%_
                     _%$%tl2225023343%_
                     _%__splice3849138492%_
                     _%$%target2225123346%_
                     _%$%tl2225323349%_)
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-pair/null? _%$%tl2224423323%_))
                        (let ((_%__splice3850938510%_
                               (let ()
                                 (declare (not safe))
                                 (gx#syntax-split-splice->vector
                                  _%$%tl2224423323%_
                                  '0))))
                          (let ((_%$%tl2242422609%_
                                 (let ()
                                   (declare (not safe))
                                   (##vector-ref _%__splice3850938510%_ '1)))
                                (_%$%target2242222606%_
                                 (let ()
                                   (declare (not safe))
                                   (##vector-ref _%__splice3850938510%_ '0))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2242422609%_))
                                (_%__match3880938810%_
                                 _%$%e2222723266%_
                                 _%$%hd2222823270%_
                                 _%$%tl2222923273%_
                                 _%$%e2223023276%_
                                 _%$%hd2223123280%_
                                 _%$%tl2223223283%_
                                 _%$%e2223323286%_
                                 _%$%hd2223423290%_
                                 _%$%tl2223523293%_
                                 _%$%e2223623296%_
                                 _%$%hd2223723300%_
                                 _%$%tl2223823303%_
                                 _%$%e2223923306%_
                                 _%$%hd2224023310%_
                                 _%$%tl2224123313%_
                                 _%$%e2224223316%_
                                 _%$%hd2224323320%_
                                 _%$%tl2224423323%_
                                 _%__splice3850938510%_
                                 _%$%target2242222606%_
                                 _%$%tl2242422609%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl2224123313%_))
                                    (_%__kont3851138512%_
                                     _%$%hd2224023310%_
                                     _%$%hd2223723300%_
                                     _%$%hd2223423290%_
                                     _%$%hd2223123280%_)
                                    (let ()
                                      (declare (not safe))
                                      (_%$%g2222022455%_))))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-null? _%$%tl2224123313%_))
                            (_%__kont3851138512%_
                             _%$%hd2224023310%_
                             _%$%hd2223723300%_
                             _%$%hd2223423290%_
                             _%$%hd2223123280%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g2222022455%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-pair/null?
                                                           _%$%tl2224423323%_))
                                                        (let ((_%__splice3850938510%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#syntax-split-splice->vector
                          _%$%tl2224423323%_
                          '0))))
                  (let ((_%$%tl2242422609%_
                         (let ()
                           (declare (not safe))
                           (##vector-ref _%__splice3850938510%_ '1)))
                        (_%$%target2242222606%_
                         (let ()
                           (declare (not safe))
                           (##vector-ref _%__splice3850938510%_ '0))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2242422609%_))
                        (_%__match3880938810%_
                         _%$%e2222723266%_
                         _%$%hd2222823270%_
                         _%$%tl2222923273%_
                         _%$%e2223023276%_
                         _%$%hd2223123280%_
                         _%$%tl2223223283%_
                         _%$%e2223323286%_
                         _%$%hd2223423290%_
                         _%$%tl2223523293%_
                         _%$%e2223623296%_
                         _%$%hd2223723300%_
                         _%$%tl2223823303%_
                         _%$%e2223923306%_
                         _%$%hd2224023310%_
                         _%$%tl2224123313%_
                         _%$%e2224223316%_
                         _%$%hd2224323320%_
                         _%$%tl2224423323%_
                         _%__splice3850938510%_
                         _%$%target2242222606%_
                         _%$%tl2242422609%_)
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-null? _%$%tl2224123313%_))
                            (_%__kont3851138512%_
                             _%$%hd2224023310%_
                             _%$%hd2223723300%_
                             _%$%hd2223423290%_
                             _%$%hd2223123280%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g2222022455%_))))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2224123313%_))
                    (_%__kont3851138512%_
                     _%$%hd2224023310%_
                     _%$%hd2223723300%_
                     _%$%hd2223423290%_
                     _%$%hd2223123280%_)
                    (let () (declare (not safe)) (_%$%g2222022455%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair/null?
                                                   _%$%tl2224423323%_))
                                                (let ((_%__splice3850938510%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-split-splice->vector
                                                          _%$%tl2224423323%_
                                                          '0))))
                                                  (let ((_%$%tl2242422609%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##vector-ref
                                                            _%__splice3850938510%_
                                                            '1)))
                                                        (_%$%target2242222606%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##vector-ref
                                                            _%__splice3850938510%_
                                                            '0))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl2242422609%_))
                                                        (_%__match3880938810%_
                                                         _%$%e2222723266%_
                                                         _%$%hd2222823270%_
                                                         _%$%tl2222923273%_
                                                         _%$%e2223023276%_
                                                         _%$%hd2223123280%_
                                                         _%$%tl2223223283%_
                                                         _%$%e2223323286%_
                                                         _%$%hd2223423290%_
                                                         _%$%tl2223523293%_
                                                         _%$%e2223623296%_
                                                         _%$%hd2223723300%_
                                                         _%$%tl2223823303%_
                                                         _%$%e2223923306%_
                                                         _%$%hd2224023310%_
                                                         _%$%tl2224123313%_
                                                         _%$%e2224223316%_
                                                         _%$%hd2224323320%_
                                                         _%$%tl2224423323%_
                                                         _%__splice3850938510%_
                                                         _%$%target2242222606%_
                                                         _%$%tl2242422609%_)
                                                        (if (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#stx-null?
                                                               _%$%tl2224123313%_))
                                                            (_%__kont3851138512%_
                                                             _%$%hd2224023310%_
                                                             _%$%hd2223723300%_
                                                             _%$%hd2223423290%_
                                                             _%$%hd2223123280%_)
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (_%$%g2222022455%_))))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl2224123313%_))
                                                    (_%__kont3851138512%_
                                                     _%$%hd2224023310%_
                                                     _%$%hd2223723300%_
                                                     _%$%hd2223423290%_
                                                     _%$%hd2223123280%_)
                                                    (let ()
                                                      (declare (not safe))
                                                      (_%$%g2222022455%_)))))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair/null?
                                           _%$%tl2224423323%_))
                                        (let ((_%__splice3850938510%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-split-splice->vector
                                                  _%$%tl2224423323%_
                                                  '0))))
                                          (let ((_%$%tl2242422609%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##vector-ref
                                                    _%__splice3850938510%_
                                                    '1)))
                                                (_%$%target2242222606%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##vector-ref
                                                    _%__splice3850938510%_
                                                    '0))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-null?
                                                   _%$%tl2242422609%_))
                                                (_%__match3880938810%_
                                                 _%$%e2222723266%_
                                                 _%$%hd2222823270%_
                                                 _%$%tl2222923273%_
                                                 _%$%e2223023276%_
                                                 _%$%hd2223123280%_
                                                 _%$%tl2223223283%_
                                                 _%$%e2223323286%_
                                                 _%$%hd2223423290%_
                                                 _%$%tl2223523293%_
                                                 _%$%e2223623296%_
                                                 _%$%hd2223723300%_
                                                 _%$%tl2223823303%_
                                                 _%$%e2223923306%_
                                                 _%$%hd2224023310%_
                                                 _%$%tl2224123313%_
                                                 _%$%e2224223316%_
                                                 _%$%hd2224323320%_
                                                 _%$%tl2224423323%_
                                                 _%__splice3850938510%_
                                                 _%$%target2242222606%_
                                                 _%$%tl2242422609%_)
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl2224123313%_))
                                                    (_%__kont3851138512%_
                                                     _%$%hd2224023310%_
                                                     _%$%hd2223723300%_
                                                     _%$%hd2223423290%_
                                                     _%$%hd2223123280%_)
                                                    (let ()
                                                      (declare (not safe))
                                                      (_%$%g2222022455%_))))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-null?
                                               _%$%tl2224123313%_))
                                            (_%__kont3851138512%_
                                             _%$%hd2224023310%_
                                             _%$%hd2223723300%_
                                             _%$%hd2223423290%_
                                             _%$%hd2223123280%_)
                                            (let ()
                                              (declare (not safe))
                                              (_%$%g2222022455%_)))))
                                (if (let ((__tmp39076
                                           |gerbil-ascent/program/scheme-language[1]#_g39077_|))
                                      (declare (not safe))
                                      (gx#free-identifier=?
                                       __tmp39076
                                       _%$%hd2224323320%_))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%tl2224423323%_))
                                        (let ((_%$%e2228423152%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%tl2224423323%_))))
                                          (let ((_%$%tl2228623159%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2228423152%_)))
                                                (_%$%hd2228523156%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2228423152%_))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair?
                                                   _%$%tl2228623159%_))
                                                (let ((_%$%e2228723162%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-e
                                                          _%$%tl2228623159%_))))
                                                  (let ((_%$%tl2228923169%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e2228723162%_)))
                                                        (_%$%hd2228823166%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e2228723162%_))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-pair?
                                                           _%$%hd2228823166%_))
                                                        (let ((_%$%e2229023172%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#syntax-e _%$%hd2228823166%_))))
                  (let ((_%$%tl2229223179%_
                         (let ()
                           (declare (not safe))
                           (##cdr _%$%e2229023172%_)))
                        (_%$%hd2229123176%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%e2229023172%_))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-pair/null? _%$%tl2229223179%_))
                        (let ((_%__splice3849538496%_
                               (let ()
                                 (declare (not safe))
                                 (gx#syntax-split-splice->vector
                                  _%$%tl2229223179%_
                                  '0))))
                          (let ((_%$%tl2229523185%_
                                 (let ()
                                   (declare (not safe))
                                   (##vector-ref _%__splice3849538496%_ '1)))
                                (_%$%target2229323182%_
                                 (let ()
                                   (declare (not safe))
                                   (##vector-ref _%__splice3849538496%_ '0))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2229523185%_))
                                (_%__match3863938640%_
                                 _%$%e2222723266%_
                                 _%$%hd2222823270%_
                                 _%$%tl2222923273%_
                                 _%$%e2223023276%_
                                 _%$%hd2223123280%_
                                 _%$%tl2223223283%_
                                 _%$%e2223323286%_
                                 _%$%hd2223423290%_
                                 _%$%tl2223523293%_
                                 _%$%e2223623296%_
                                 _%$%hd2223723300%_
                                 _%$%tl2223823303%_
                                 _%$%e2223923306%_
                                 _%$%hd2224023310%_
                                 _%$%tl2224123313%_
                                 _%$%e2224223316%_
                                 _%$%hd2224323320%_
                                 _%$%tl2224423323%_
                                 _%$%e2228423152%_
                                 _%$%hd2228523156%_
                                 _%$%tl2228623159%_
                                 _%$%e2228723162%_
                                 _%$%hd2228823166%_
                                 _%$%tl2228923169%_
                                 _%$%e2229023172%_
                                 _%$%hd2229123176%_
                                 _%$%tl2229223179%_
                                 _%__splice3849538496%_
                                 _%$%target2229323182%_
                                 _%$%tl2229523185%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair/null? _%$%tl2224423323%_))
                                    (let ((_%__splice3850938510%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-split-splice->vector
                                              _%$%tl2224423323%_
                                              '0))))
                                      (let ((_%$%tl2242422609%_
                                             (let ()
                                               (declare (not safe))
                                               (##vector-ref
                                                _%__splice3850938510%_
                                                '1)))
                                            (_%$%target2242222606%_
                                             (let ()
                                               (declare (not safe))
                                               (##vector-ref
                                                _%__splice3850938510%_
                                                '0))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-null?
                                               _%$%tl2242422609%_))
                                            (_%__match3880938810%_
                                             _%$%e2222723266%_
                                             _%$%hd2222823270%_
                                             _%$%tl2222923273%_
                                             _%$%e2223023276%_
                                             _%$%hd2223123280%_
                                             _%$%tl2223223283%_
                                             _%$%e2223323286%_
                                             _%$%hd2223423290%_
                                             _%$%tl2223523293%_
                                             _%$%e2223623296%_
                                             _%$%hd2223723300%_
                                             _%$%tl2223823303%_
                                             _%$%e2223923306%_
                                             _%$%hd2224023310%_
                                             _%$%tl2224123313%_
                                             _%$%e2224223316%_
                                             _%$%hd2224323320%_
                                             _%$%tl2224423323%_
                                             _%__splice3850938510%_
                                             _%$%target2242222606%_
                                             _%$%tl2242422609%_)
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-null?
                                                   _%$%tl2224123313%_))
                                                (_%__kont3851138512%_
                                                 _%$%hd2224023310%_
                                                 _%$%hd2223723300%_
                                                 _%$%hd2223423290%_
                                                 _%$%hd2223123280%_)
                                                (let ()
                                                  (declare (not safe))
                                                  (_%$%g2222022455%_))))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2224123313%_))
                                        (_%__kont3851138512%_
                                         _%$%hd2224023310%_
                                         _%$%hd2223723300%_
                                         _%$%hd2223423290%_
                                         _%$%hd2223123280%_)
                                        (let ()
                                          (declare (not safe))
                                          (_%$%g2222022455%_)))))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair/null? _%$%tl2224423323%_))
                            (let ((_%__splice3850938510%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-split-splice->vector
                                      _%$%tl2224423323%_
                                      '0))))
                              (let ((_%$%tl2242422609%_
                                     (let ()
                                       (declare (not safe))
                                       (##vector-ref
                                        _%__splice3850938510%_
                                        '1)))
                                    (_%$%target2242222606%_
                                     (let ()
                                       (declare (not safe))
                                       (##vector-ref
                                        _%__splice3850938510%_
                                        '0))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl2242422609%_))
                                    (_%__match3880938810%_
                                     _%$%e2222723266%_
                                     _%$%hd2222823270%_
                                     _%$%tl2222923273%_
                                     _%$%e2223023276%_
                                     _%$%hd2223123280%_
                                     _%$%tl2223223283%_
                                     _%$%e2223323286%_
                                     _%$%hd2223423290%_
                                     _%$%tl2223523293%_
                                     _%$%e2223623296%_
                                     _%$%hd2223723300%_
                                     _%$%tl2223823303%_
                                     _%$%e2223923306%_
                                     _%$%hd2224023310%_
                                     _%$%tl2224123313%_
                                     _%$%e2224223316%_
                                     _%$%hd2224323320%_
                                     _%$%tl2224423323%_
                                     _%__splice3850938510%_
                                     _%$%target2242222606%_
                                     _%$%tl2242422609%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2224123313%_))
                                        (_%__kont3851138512%_
                                         _%$%hd2224023310%_
                                         _%$%hd2223723300%_
                                         _%$%hd2223423290%_
                                         _%$%hd2223123280%_)
                                        (let ()
                                          (declare (not safe))
                                          (_%$%g2222022455%_))))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2224123313%_))
                                (_%__kont3851138512%_
                                 _%$%hd2224023310%_
                                 _%$%hd2223723300%_
                                 _%$%hd2223423290%_
                                 _%$%hd2223123280%_)
                                (let ()
                                  (declare (not safe))
                                  (_%$%g2222022455%_)))))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair/null? _%$%tl2224423323%_))
                    (let ((_%__splice3850938510%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-split-splice->vector
                              _%$%tl2224423323%_
                              '0))))
                      (let ((_%$%tl2242422609%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3850938510%_ '1)))
                            (_%$%target2242222606%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3850938510%_ '0))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-null? _%$%tl2242422609%_))
                            (_%__match3880938810%_
                             _%$%e2222723266%_
                             _%$%hd2222823270%_
                             _%$%tl2222923273%_
                             _%$%e2223023276%_
                             _%$%hd2223123280%_
                             _%$%tl2223223283%_
                             _%$%e2223323286%_
                             _%$%hd2223423290%_
                             _%$%tl2223523293%_
                             _%$%e2223623296%_
                             _%$%hd2223723300%_
                             _%$%tl2223823303%_
                             _%$%e2223923306%_
                             _%$%hd2224023310%_
                             _%$%tl2224123313%_
                             _%$%e2224223316%_
                             _%$%hd2224323320%_
                             _%$%tl2224423323%_
                             _%__splice3850938510%_
                             _%$%target2242222606%_
                             _%$%tl2242422609%_)
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2224123313%_))
                                (_%__kont3851138512%_
                                 _%$%hd2224023310%_
                                 _%$%hd2223723300%_
                                 _%$%hd2223423290%_
                                 _%$%hd2223123280%_)
                                (let ()
                                  (declare (not safe))
                                  (_%$%g2222022455%_))))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2224123313%_))
                        (_%__kont3851138512%_
                         _%$%hd2224023310%_
                         _%$%hd2223723300%_
                         _%$%hd2223423290%_
                         _%$%hd2223123280%_)
                        (let () (declare (not safe)) (_%$%g2222022455%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%tl2224423323%_))
                                                    (let ((_%__splice3850938510%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%tl2224423323%_
                                                              '0))))
                                                      (let ((_%$%tl2242422609%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3850938510%_ '1)))
                    (_%$%target2242222606%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3850938510%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2242422609%_))
                    (_%__match3880938810%_
                     _%$%e2222723266%_
                     _%$%hd2222823270%_
                     _%$%tl2222923273%_
                     _%$%e2223023276%_
                     _%$%hd2223123280%_
                     _%$%tl2223223283%_
                     _%$%e2223323286%_
                     _%$%hd2223423290%_
                     _%$%tl2223523293%_
                     _%$%e2223623296%_
                     _%$%hd2223723300%_
                     _%$%tl2223823303%_
                     _%$%e2223923306%_
                     _%$%hd2224023310%_
                     _%$%tl2224123313%_
                     _%$%e2224223316%_
                     _%$%hd2224323320%_
                     _%$%tl2224423323%_
                     _%__splice3850938510%_
                     _%$%target2242222606%_
                     _%$%tl2242422609%_)
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2224123313%_))
                        (_%__kont3851138512%_
                         _%$%hd2224023310%_
                         _%$%hd2223723300%_
                         _%$%hd2223423290%_
                         _%$%hd2223123280%_)
                        (let () (declare (not safe)) (_%$%g2222022455%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl2224123313%_))
                                                        (_%__kont3851138512%_
                                                         _%$%hd2224023310%_
                                                         _%$%hd2223723300%_
                                                         _%$%hd2223423290%_
                                                         _%$%hd2223123280%_)
                                                        (let ()
                                                          (declare (not safe))
                                                          (_%$%g2222022455%_)))))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair/null?
                                               _%$%tl2224423323%_))
                                            (let ((_%__splice3850938510%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-split-splice->vector
                                                      _%$%tl2224423323%_
                                                      '0))))
                                              (let ((_%$%tl2242422609%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##vector-ref
                                                        _%__splice3850938510%_
                                                        '1)))
                                                    (_%$%target2242222606%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##vector-ref
                                                        _%__splice3850938510%_
                                                        '0))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl2242422609%_))
                                                    (_%__match3880938810%_
                                                     _%$%e2222723266%_
                                                     _%$%hd2222823270%_
                                                     _%$%tl2222923273%_
                                                     _%$%e2223023276%_
                                                     _%$%hd2223123280%_
                                                     _%$%tl2223223283%_
                                                     _%$%e2223323286%_
                                                     _%$%hd2223423290%_
                                                     _%$%tl2223523293%_
                                                     _%$%e2223623296%_
                                                     _%$%hd2223723300%_
                                                     _%$%tl2223823303%_
                                                     _%$%e2223923306%_
                                                     _%$%hd2224023310%_
                                                     _%$%tl2224123313%_
                                                     _%$%e2224223316%_
                                                     _%$%hd2224323320%_
                                                     _%$%tl2224423323%_
                                                     _%__splice3850938510%_
                                                     _%$%target2242222606%_
                                                     _%$%tl2242422609%_)
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl2224123313%_))
                                                        (_%__kont3851138512%_
                                                         _%$%hd2224023310%_
                                                         _%$%hd2223723300%_
                                                         _%$%hd2223423290%_
                                                         _%$%hd2223123280%_)
                                                        (let ()
                                                          (declare (not safe))
                                                          (_%$%g2222022455%_))))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-null?
                                                   _%$%tl2224123313%_))
                                                (_%__kont3851138512%_
                                                 _%$%hd2224023310%_
                                                 _%$%hd2223723300%_
                                                 _%$%hd2223423290%_
                                                 _%$%hd2223123280%_)
                                                (let ()
                                                  (declare (not safe))
                                                  (_%$%g2222022455%_)))))
                                    (if (let ((__tmp39078
                                               |gerbil-ascent/program/scheme-language[1]#_g39079_|))
                                          (declare (not safe))
                                          (gx#free-identifier=?
                                           __tmp39078
                                           _%$%hd2224323320%_))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2224423323%_))
                                            (let ((_%$%e2232522992%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2224423323%_))))
                                              (let ((_%$%tl2232722999%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2232522992%_)))
                                                    (_%$%hd2232622996%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2232522992%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair?
                                                       _%$%hd2232622996%_))
                                                    (let ((_%$%e2232823002%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-e
                                                              _%$%hd2232622996%_))))
                                                      (let ((_%$%tl2233023009%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##cdr _%$%e2232823002%_)))
                    (_%$%hd2232923006%_
                     (let () (declare (not safe)) (##car _%$%e2232823002%_))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair/null? _%$%tl2233023009%_))
                    (let ((_%__splice3849938500%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-split-splice->vector
                              _%$%tl2233023009%_
                              '0))))
                      (let ((_%$%tl2233323015%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3849938500%_ '1)))
                            (_%$%target2233123012%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3849938500%_ '0))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-null? _%$%tl2233323015%_))
                            (_%__match3869938700%_
                             _%$%e2222723266%_
                             _%$%hd2222823270%_
                             _%$%tl2222923273%_
                             _%$%e2223023276%_
                             _%$%hd2223123280%_
                             _%$%tl2223223283%_
                             _%$%e2223323286%_
                             _%$%hd2223423290%_
                             _%$%tl2223523293%_
                             _%$%e2223623296%_
                             _%$%hd2223723300%_
                             _%$%tl2223823303%_
                             _%$%e2223923306%_
                             _%$%hd2224023310%_
                             _%$%tl2224123313%_
                             _%$%e2224223316%_
                             _%$%hd2224323320%_
                             _%$%tl2224423323%_
                             _%$%e2232522992%_
                             _%$%hd2232622996%_
                             _%$%tl2232722999%_
                             _%$%e2232823002%_
                             _%$%hd2232923006%_
                             _%$%tl2233023009%_
                             _%__splice3849938500%_
                             _%$%target2233123012%_
                             _%$%tl2233323015%_)
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair/null? _%$%tl2224423323%_))
                                (let ((_%__splice3850938510%_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-split-splice->vector
                                          _%$%tl2224423323%_
                                          '0))))
                                  (let ((_%$%tl2242422609%_
                                         (let ()
                                           (declare (not safe))
                                           (##vector-ref
                                            _%__splice3850938510%_
                                            '1)))
                                        (_%$%target2242222606%_
                                         (let ()
                                           (declare (not safe))
                                           (##vector-ref
                                            _%__splice3850938510%_
                                            '0))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2242422609%_))
                                        (_%__match3880938810%_
                                         _%$%e2222723266%_
                                         _%$%hd2222823270%_
                                         _%$%tl2222923273%_
                                         _%$%e2223023276%_
                                         _%$%hd2223123280%_
                                         _%$%tl2223223283%_
                                         _%$%e2223323286%_
                                         _%$%hd2223423290%_
                                         _%$%tl2223523293%_
                                         _%$%e2223623296%_
                                         _%$%hd2223723300%_
                                         _%$%tl2223823303%_
                                         _%$%e2223923306%_
                                         _%$%hd2224023310%_
                                         _%$%tl2224123313%_
                                         _%$%e2224223316%_
                                         _%$%hd2224323320%_
                                         _%$%tl2224423323%_
                                         _%__splice3850938510%_
                                         _%$%target2242222606%_
                                         _%$%tl2242422609%_)
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-null?
                                               _%$%tl2224123313%_))
                                            (_%__kont3851138512%_
                                             _%$%hd2224023310%_
                                             _%$%hd2223723300%_
                                             _%$%hd2223423290%_
                                             _%$%hd2223123280%_)
                                            (let ()
                                              (declare (not safe))
                                              (_%$%g2222022455%_))))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl2224123313%_))
                                    (_%__kont3851138512%_
                                     _%$%hd2224023310%_
                                     _%$%hd2223723300%_
                                     _%$%hd2223423290%_
                                     _%$%hd2223123280%_)
                                    (let ()
                                      (declare (not safe))
                                      (_%$%g2222022455%_)))))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-pair/null? _%$%tl2224423323%_))
                        (let ((_%__splice3850938510%_
                               (let ()
                                 (declare (not safe))
                                 (gx#syntax-split-splice->vector
                                  _%$%tl2224423323%_
                                  '0))))
                          (let ((_%$%tl2242422609%_
                                 (let ()
                                   (declare (not safe))
                                   (##vector-ref _%__splice3850938510%_ '1)))
                                (_%$%target2242222606%_
                                 (let ()
                                   (declare (not safe))
                                   (##vector-ref _%__splice3850938510%_ '0))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2242422609%_))
                                (_%__match3880938810%_
                                 _%$%e2222723266%_
                                 _%$%hd2222823270%_
                                 _%$%tl2222923273%_
                                 _%$%e2223023276%_
                                 _%$%hd2223123280%_
                                 _%$%tl2223223283%_
                                 _%$%e2223323286%_
                                 _%$%hd2223423290%_
                                 _%$%tl2223523293%_
                                 _%$%e2223623296%_
                                 _%$%hd2223723300%_
                                 _%$%tl2223823303%_
                                 _%$%e2223923306%_
                                 _%$%hd2224023310%_
                                 _%$%tl2224123313%_
                                 _%$%e2224223316%_
                                 _%$%hd2224323320%_
                                 _%$%tl2224423323%_
                                 _%__splice3850938510%_
                                 _%$%target2242222606%_
                                 _%$%tl2242422609%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl2224123313%_))
                                    (_%__kont3851138512%_
                                     _%$%hd2224023310%_
                                     _%$%hd2223723300%_
                                     _%$%hd2223423290%_
                                     _%$%hd2223123280%_)
                                    (let ()
                                      (declare (not safe))
                                      (_%$%g2222022455%_))))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-null? _%$%tl2224123313%_))
                            (_%__kont3851138512%_
                             _%$%hd2224023310%_
                             _%$%hd2223723300%_
                             _%$%hd2223423290%_
                             _%$%hd2223123280%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g2222022455%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-pair/null?
                                                           _%$%tl2224423323%_))
                                                        (let ((_%__splice3850938510%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#syntax-split-splice->vector
                          _%$%tl2224423323%_
                          '0))))
                  (let ((_%$%tl2242422609%_
                         (let ()
                           (declare (not safe))
                           (##vector-ref _%__splice3850938510%_ '1)))
                        (_%$%target2242222606%_
                         (let ()
                           (declare (not safe))
                           (##vector-ref _%__splice3850938510%_ '0))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2242422609%_))
                        (_%__match3880938810%_
                         _%$%e2222723266%_
                         _%$%hd2222823270%_
                         _%$%tl2222923273%_
                         _%$%e2223023276%_
                         _%$%hd2223123280%_
                         _%$%tl2223223283%_
                         _%$%e2223323286%_
                         _%$%hd2223423290%_
                         _%$%tl2223523293%_
                         _%$%e2223623296%_
                         _%$%hd2223723300%_
                         _%$%tl2223823303%_
                         _%$%e2223923306%_
                         _%$%hd2224023310%_
                         _%$%tl2224123313%_
                         _%$%e2224223316%_
                         _%$%hd2224323320%_
                         _%$%tl2224423323%_
                         _%__splice3850938510%_
                         _%$%target2242222606%_
                         _%$%tl2242422609%_)
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-null? _%$%tl2224123313%_))
                            (_%__kont3851138512%_
                             _%$%hd2224023310%_
                             _%$%hd2223723300%_
                             _%$%hd2223423290%_
                             _%$%hd2223123280%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g2222022455%_))))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2224123313%_))
                    (_%__kont3851138512%_
                     _%$%hd2224023310%_
                     _%$%hd2223723300%_
                     _%$%hd2223423290%_
                     _%$%hd2223123280%_)
                    (let () (declare (not safe)) (_%$%g2222022455%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair/null?
                                                   _%$%tl2224423323%_))
                                                (let ((_%__splice3850938510%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-split-splice->vector
                                                          _%$%tl2224423323%_
                                                          '0))))
                                                  (let ((_%$%tl2242422609%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##vector-ref
                                                            _%__splice3850938510%_
                                                            '1)))
                                                        (_%$%target2242222606%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##vector-ref
                                                            _%__splice3850938510%_
                                                            '0))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl2242422609%_))
                                                        (_%__match3880938810%_
                                                         _%$%e2222723266%_
                                                         _%$%hd2222823270%_
                                                         _%$%tl2222923273%_
                                                         _%$%e2223023276%_
                                                         _%$%hd2223123280%_
                                                         _%$%tl2223223283%_
                                                         _%$%e2223323286%_
                                                         _%$%hd2223423290%_
                                                         _%$%tl2223523293%_
                                                         _%$%e2223623296%_
                                                         _%$%hd2223723300%_
                                                         _%$%tl2223823303%_
                                                         _%$%e2223923306%_
                                                         _%$%hd2224023310%_
                                                         _%$%tl2224123313%_
                                                         _%$%e2224223316%_
                                                         _%$%hd2224323320%_
                                                         _%$%tl2224423323%_
                                                         _%__splice3850938510%_
                                                         _%$%target2242222606%_
                                                         _%$%tl2242422609%_)
                                                        (if (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#stx-null?
                                                               _%$%tl2224123313%_))
                                                            (_%__kont3851138512%_
                                                             _%$%hd2224023310%_
                                                             _%$%hd2223723300%_
                                                             _%$%hd2223423290%_
                                                             _%$%hd2223123280%_)
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (_%$%g2222022455%_))))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl2224123313%_))
                                                    (_%__kont3851138512%_
                                                     _%$%hd2224023310%_
                                                     _%$%hd2223723300%_
                                                     _%$%hd2223423290%_
                                                     _%$%hd2223123280%_)
                                                    (let ()
                                                      (declare (not safe))
                                                      (_%$%g2222022455%_)))))
                                        (if (let ((__tmp39080
                                                   |gerbil-ascent/program/scheme-language[1]#_g39081_|))
                                              (declare (not safe))
                                              (gx#free-identifier=?
                                               __tmp39080
                                               _%$%hd2224323320%_))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair?
                                                   _%$%tl2224423323%_))
                                                (let ((_%$%e2236622742%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-e
                                                          _%$%tl2224423323%_))))
                                                  (let ((_%$%tl2236822749%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e2236622742%_)))
                                                        (_%$%hd2236722746%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e2236622742%_))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-pair?
                                                           _%$%tl2236822749%_))
                                                        (let ((_%$%e2236922752%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#syntax-e _%$%tl2236822749%_))))
                  (let ((_%$%tl2237122759%_
                         (let ()
                           (declare (not safe))
                           (##cdr _%$%e2236922752%_)))
                        (_%$%hd2237022756%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%e2236922752%_))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-pair? _%$%hd2237022756%_))
                        (let ((_%$%e2237222762%_
                               (let ()
                                 (declare (not safe))
                                 (gx#syntax-e _%$%hd2237022756%_))))
                          (let ((_%$%tl2237422769%_
                                 (let ()
                                   (declare (not safe))
                                   (##cdr _%$%e2237222762%_)))
                                (_%$%hd2237322766%_
                                 (let ()
                                   (declare (not safe))
                                   (##car _%$%e2237222762%_))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair/null? _%$%tl2237422769%_))
                                (let ((_%__splice3850338504%_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-split-splice->vector
                                          _%$%tl2237422769%_
                                          '0))))
                                  (let ((_%$%tl2237722775%_
                                         (let ()
                                           (declare (not safe))
                                           (##vector-ref
                                            _%__splice3850338504%_
                                            '1)))
                                        (_%$%target2237522772%_
                                         (let ()
                                           (declare (not safe))
                                           (##vector-ref
                                            _%__splice3850338504%_
                                            '0))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2237722775%_))
                                        (_%__match3876538766%_
                                         _%$%e2222723266%_
                                         _%$%hd2222823270%_
                                         _%$%tl2222923273%_
                                         _%$%e2223023276%_
                                         _%$%hd2223123280%_
                                         _%$%tl2223223283%_
                                         _%$%e2223323286%_
                                         _%$%hd2223423290%_
                                         _%$%tl2223523293%_
                                         _%$%e2223623296%_
                                         _%$%hd2223723300%_
                                         _%$%tl2223823303%_
                                         _%$%e2223923306%_
                                         _%$%hd2224023310%_
                                         _%$%tl2224123313%_
                                         _%$%e2224223316%_
                                         _%$%hd2224323320%_
                                         _%$%tl2224423323%_
                                         _%$%e2236622742%_
                                         _%$%hd2236722746%_
                                         _%$%tl2236822749%_
                                         _%$%e2236922752%_
                                         _%$%hd2237022756%_
                                         _%$%tl2237122759%_
                                         _%$%e2237222762%_
                                         _%$%hd2237322766%_
                                         _%$%tl2237422769%_
                                         _%__splice3850338504%_
                                         _%$%target2237522772%_
                                         _%$%tl2237722775%_)
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair/null?
                                               _%$%tl2224423323%_))
                                            (let ((_%__splice3850938510%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-split-splice->vector
                                                      _%$%tl2224423323%_
                                                      '0))))
                                              (let ((_%$%tl2242422609%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##vector-ref
                                                        _%__splice3850938510%_
                                                        '1)))
                                                    (_%$%target2242222606%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##vector-ref
                                                        _%__splice3850938510%_
                                                        '0))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl2242422609%_))
                                                    (_%__match3880938810%_
                                                     _%$%e2222723266%_
                                                     _%$%hd2222823270%_
                                                     _%$%tl2222923273%_
                                                     _%$%e2223023276%_
                                                     _%$%hd2223123280%_
                                                     _%$%tl2223223283%_
                                                     _%$%e2223323286%_
                                                     _%$%hd2223423290%_
                                                     _%$%tl2223523293%_
                                                     _%$%e2223623296%_
                                                     _%$%hd2223723300%_
                                                     _%$%tl2223823303%_
                                                     _%$%e2223923306%_
                                                     _%$%hd2224023310%_
                                                     _%$%tl2224123313%_
                                                     _%$%e2224223316%_
                                                     _%$%hd2224323320%_
                                                     _%$%tl2224423323%_
                                                     _%__splice3850938510%_
                                                     _%$%target2242222606%_
                                                     _%$%tl2242422609%_)
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl2224123313%_))
                                                        (_%__kont3851138512%_
                                                         _%$%hd2224023310%_
                                                         _%$%hd2223723300%_
                                                         _%$%hd2223423290%_
                                                         _%$%hd2223123280%_)
                                                        (let ()
                                                          (declare (not safe))
                                                          (_%$%g2222022455%_))))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-null?
                                                   _%$%tl2224123313%_))
                                                (_%__kont3851138512%_
                                                 _%$%hd2224023310%_
                                                 _%$%hd2223723300%_
                                                 _%$%hd2223423290%_
                                                 _%$%hd2223123280%_)
                                                (let ()
                                                  (declare (not safe))
                                                  (_%$%g2222022455%_)))))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair/null? _%$%tl2224423323%_))
                                    (let ((_%__splice3850938510%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-split-splice->vector
                                              _%$%tl2224423323%_
                                              '0))))
                                      (let ((_%$%tl2242422609%_
                                             (let ()
                                               (declare (not safe))
                                               (##vector-ref
                                                _%__splice3850938510%_
                                                '1)))
                                            (_%$%target2242222606%_
                                             (let ()
                                               (declare (not safe))
                                               (##vector-ref
                                                _%__splice3850938510%_
                                                '0))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-null?
                                               _%$%tl2242422609%_))
                                            (_%__match3880938810%_
                                             _%$%e2222723266%_
                                             _%$%hd2222823270%_
                                             _%$%tl2222923273%_
                                             _%$%e2223023276%_
                                             _%$%hd2223123280%_
                                             _%$%tl2223223283%_
                                             _%$%e2223323286%_
                                             _%$%hd2223423290%_
                                             _%$%tl2223523293%_
                                             _%$%e2223623296%_
                                             _%$%hd2223723300%_
                                             _%$%tl2223823303%_
                                             _%$%e2223923306%_
                                             _%$%hd2224023310%_
                                             _%$%tl2224123313%_
                                             _%$%e2224223316%_
                                             _%$%hd2224323320%_
                                             _%$%tl2224423323%_
                                             _%__splice3850938510%_
                                             _%$%target2242222606%_
                                             _%$%tl2242422609%_)
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-null?
                                                   _%$%tl2224123313%_))
                                                (_%__kont3851138512%_
                                                 _%$%hd2224023310%_
                                                 _%$%hd2223723300%_
                                                 _%$%hd2223423290%_
                                                 _%$%hd2223123280%_)
                                                (let ()
                                                  (declare (not safe))
                                                  (_%$%g2222022455%_))))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2224123313%_))
                                        (_%__kont3851138512%_
                                         _%$%hd2224023310%_
                                         _%$%hd2223723300%_
                                         _%$%hd2223423290%_
                                         _%$%hd2223123280%_)
                                        (let ()
                                          (declare (not safe))
                                          (_%$%g2222022455%_)))))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair/null? _%$%tl2224423323%_))
                            (let ((_%__splice3850938510%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-split-splice->vector
                                      _%$%tl2224423323%_
                                      '0))))
                              (let ((_%$%tl2242422609%_
                                     (let ()
                                       (declare (not safe))
                                       (##vector-ref
                                        _%__splice3850938510%_
                                        '1)))
                                    (_%$%target2242222606%_
                                     (let ()
                                       (declare (not safe))
                                       (##vector-ref
                                        _%__splice3850938510%_
                                        '0))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl2242422609%_))
                                    (_%__match3880938810%_
                                     _%$%e2222723266%_
                                     _%$%hd2222823270%_
                                     _%$%tl2222923273%_
                                     _%$%e2223023276%_
                                     _%$%hd2223123280%_
                                     _%$%tl2223223283%_
                                     _%$%e2223323286%_
                                     _%$%hd2223423290%_
                                     _%$%tl2223523293%_
                                     _%$%e2223623296%_
                                     _%$%hd2223723300%_
                                     _%$%tl2223823303%_
                                     _%$%e2223923306%_
                                     _%$%hd2224023310%_
                                     _%$%tl2224123313%_
                                     _%$%e2224223316%_
                                     _%$%hd2224323320%_
                                     _%$%tl2224423323%_
                                     _%__splice3850938510%_
                                     _%$%target2242222606%_
                                     _%$%tl2242422609%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2224123313%_))
                                        (_%__kont3851138512%_
                                         _%$%hd2224023310%_
                                         _%$%hd2223723300%_
                                         _%$%hd2223423290%_
                                         _%$%hd2223123280%_)
                                        (let ()
                                          (declare (not safe))
                                          (_%$%g2222022455%_))))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2224123313%_))
                                (_%__kont3851138512%_
                                 _%$%hd2224023310%_
                                 _%$%hd2223723300%_
                                 _%$%hd2223423290%_
                                 _%$%hd2223123280%_)
                                (let ()
                                  (declare (not safe))
                                  (_%$%g2222022455%_)))))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair/null? _%$%tl2224423323%_))
                    (let ((_%__splice3850938510%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-split-splice->vector
                              _%$%tl2224423323%_
                              '0))))
                      (let ((_%$%tl2242422609%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3850938510%_ '1)))
                            (_%$%target2242222606%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3850938510%_ '0))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-null? _%$%tl2242422609%_))
                            (_%__match3880938810%_
                             _%$%e2222723266%_
                             _%$%hd2222823270%_
                             _%$%tl2222923273%_
                             _%$%e2223023276%_
                             _%$%hd2223123280%_
                             _%$%tl2223223283%_
                             _%$%e2223323286%_
                             _%$%hd2223423290%_
                             _%$%tl2223523293%_
                             _%$%e2223623296%_
                             _%$%hd2223723300%_
                             _%$%tl2223823303%_
                             _%$%e2223923306%_
                             _%$%hd2224023310%_
                             _%$%tl2224123313%_
                             _%$%e2224223316%_
                             _%$%hd2224323320%_
                             _%$%tl2224423323%_
                             _%__splice3850938510%_
                             _%$%target2242222606%_
                             _%$%tl2242422609%_)
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2224123313%_))
                                (_%__kont3851138512%_
                                 _%$%hd2224023310%_
                                 _%$%hd2223723300%_
                                 _%$%hd2223423290%_
                                 _%$%hd2223123280%_)
                                (let ()
                                  (declare (not safe))
                                  (_%$%g2222022455%_))))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2224123313%_))
                        (_%__kont3851138512%_
                         _%$%hd2224023310%_
                         _%$%hd2223723300%_
                         _%$%hd2223423290%_
                         _%$%hd2223123280%_)
                        (let () (declare (not safe)) (_%$%g2222022455%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%tl2224423323%_))
                                                    (let ((_%__splice3850938510%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%tl2224423323%_
                                                              '0))))
                                                      (let ((_%$%tl2242422609%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3850938510%_ '1)))
                    (_%$%target2242222606%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3850938510%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2242422609%_))
                    (_%__match3880938810%_
                     _%$%e2222723266%_
                     _%$%hd2222823270%_
                     _%$%tl2222923273%_
                     _%$%e2223023276%_
                     _%$%hd2223123280%_
                     _%$%tl2223223283%_
                     _%$%e2223323286%_
                     _%$%hd2223423290%_
                     _%$%tl2223523293%_
                     _%$%e2223623296%_
                     _%$%hd2223723300%_
                     _%$%tl2223823303%_
                     _%$%e2223923306%_
                     _%$%hd2224023310%_
                     _%$%tl2224123313%_
                     _%$%e2224223316%_
                     _%$%hd2224323320%_
                     _%$%tl2224423323%_
                     _%__splice3850938510%_
                     _%$%target2242222606%_
                     _%$%tl2242422609%_)
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2224123313%_))
                        (_%__kont3851138512%_
                         _%$%hd2224023310%_
                         _%$%hd2223723300%_
                         _%$%hd2223423290%_
                         _%$%hd2223123280%_)
                        (let () (declare (not safe)) (_%$%g2222022455%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl2224123313%_))
                                                        (_%__kont3851138512%_
                                                         _%$%hd2224023310%_
                                                         _%$%hd2223723300%_
                                                         _%$%hd2223423290%_
                                                         _%$%hd2223123280%_)
                                                        (let ()
                                                          (declare (not safe))
                                                          (_%$%g2222022455%_)))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair/null?
                                                   _%$%tl2224423323%_))
                                                (let ((_%__splice3850938510%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-split-splice->vector
                                                          _%$%tl2224423323%_
                                                          '0))))
                                                  (let ((_%$%tl2242422609%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##vector-ref
                                                            _%__splice3850938510%_
                                                            '1)))
                                                        (_%$%target2242222606%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##vector-ref
                                                            _%__splice3850938510%_
                                                            '0))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl2242422609%_))
                                                        (_%__match3880938810%_
                                                         _%$%e2222723266%_
                                                         _%$%hd2222823270%_
                                                         _%$%tl2222923273%_
                                                         _%$%e2223023276%_
                                                         _%$%hd2223123280%_
                                                         _%$%tl2223223283%_
                                                         _%$%e2223323286%_
                                                         _%$%hd2223423290%_
                                                         _%$%tl2223523293%_
                                                         _%$%e2223623296%_
                                                         _%$%hd2223723300%_
                                                         _%$%tl2223823303%_
                                                         _%$%e2223923306%_
                                                         _%$%hd2224023310%_
                                                         _%$%tl2224123313%_
                                                         _%$%e2224223316%_
                                                         _%$%hd2224323320%_
                                                         _%$%tl2224423323%_
                                                         _%__splice3850938510%_
                                                         _%$%target2242222606%_
                                                         _%$%tl2242422609%_)
                                                        (if (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#stx-null?
                                                               _%$%tl2224123313%_))
                                                            (_%__kont3851138512%_
                                                             _%$%hd2224023310%_
                                                             _%$%hd2223723300%_
                                                             _%$%hd2223423290%_
                                                             _%$%hd2223123280%_)
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (_%$%g2222022455%_))))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl2224123313%_))
                                                    (_%__kont3851138512%_
                                                     _%$%hd2224023310%_
                                                     _%$%hd2223723300%_
                                                     _%$%hd2223423290%_
                                                     _%$%hd2223123280%_)
                                                    (let ()
                                                      (declare (not safe))
                                                      (_%$%g2222022455%_))))))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair/null? _%$%tl2224423323%_))
                                (let ((_%__splice3850938510%_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-split-splice->vector
                                          _%$%tl2224423323%_
                                          '0))))
                                  (let ((_%$%tl2242422609%_
                                         (let ()
                                           (declare (not safe))
                                           (##vector-ref
                                            _%__splice3850938510%_
                                            '1)))
                                        (_%$%target2242222606%_
                                         (let ()
                                           (declare (not safe))
                                           (##vector-ref
                                            _%__splice3850938510%_
                                            '0))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2242422609%_))
                                        (_%__match3880938810%_
                                         _%$%e2222723266%_
                                         _%$%hd2222823270%_
                                         _%$%tl2222923273%_
                                         _%$%e2223023276%_
                                         _%$%hd2223123280%_
                                         _%$%tl2223223283%_
                                         _%$%e2223323286%_
                                         _%$%hd2223423290%_
                                         _%$%tl2223523293%_
                                         _%$%e2223623296%_
                                         _%$%hd2223723300%_
                                         _%$%tl2223823303%_
                                         _%$%e2223923306%_
                                         _%$%hd2224023310%_
                                         _%$%tl2224123313%_
                                         _%$%e2224223316%_
                                         _%$%hd2224323320%_
                                         _%$%tl2224423323%_
                                         _%__splice3850938510%_
                                         _%$%target2242222606%_
                                         _%$%tl2242422609%_)
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-null?
                                               _%$%tl2224123313%_))
                                            (_%__kont3851138512%_
                                             _%$%hd2224023310%_
                                             _%$%hd2223723300%_
                                             _%$%hd2223423290%_
                                             _%$%hd2223123280%_)
                                            (let ()
                                              (declare (not safe))
                                              (_%$%g2222022455%_))))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl2224123313%_))
                                    (_%__kont3851138512%_
                                     _%$%hd2224023310%_
                                     _%$%hd2223723300%_
                                     _%$%hd2223423290%_
                                     _%$%hd2223123280%_)
                                    (let ()
                                      (declare (not safe))
                                      (_%$%g2222022455%_)))))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2224123313%_))
                        (_%__kont3851138512%_
                         _%$%hd2224023310%_
                         _%$%hd2223723300%_
                         _%$%hd2223423290%_
                         _%$%hd2223123280%_)
                        (let () (declare (not safe)) (_%$%g2222022455%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (let ()
                                                      (declare (not safe))
                                                      (_%$%g2222022455%_)))))
                                            (let ()
                                              (declare (not safe))
                                              (_%$%g2222022455%_)))))
                                    (let ()
                                      (declare (not safe))
                                      (_%$%g2222022455%_)))))
                            (let ()
                              (declare (not safe))
                              (_%$%g2222022455%_)))))
                    (let () (declare (not safe)) (_%$%g2222022455%_)))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-collect|
      (lambda (_%stx23440%_)
        (let* ((_%__stx3884438845%_ _%stx23440%_)
               (_%$%g2344923832%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3884438845%_)))))
          (let ((_%__kont3884738848%_
                 (lambda (_%$%g2345125348%_
                          _%$%g2345225350%_
                          _%$%g2345325351%_
                          _%$%g2345425352%_
                          _%$%g2345525353%_
                          _%$%g2345625354%_
                          _%$%g2345725355%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'relational-collect))
                         (cons (let ((__tmp39084
                                      (lambda (_%$%g2541025419%_
                                               _%$%g2541125422%_)
                                        (cons _%$%g2541025419%_
                                              _%$%g2541125422%_)))
                                     (__tmp39082
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'relational-checked-lattice))
                                                  (cons (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'quote))
                      (cons _%$%g2345525353%_ '()))
                (cons (cons (let ()
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'length))
                            (cons (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'quote))
                                        (cons (let ((__tmp39083
                                                     (lambda (_%$%g2541225425%_
                                                              _%$%g2541325428%_)
                                                       (cons _%$%g2541225425%_
                                                             _%$%g2541325428%_))))
                                                (declare (not safe))
                                                (foldr__0
                                                 __tmp39083
                                                 '()
                                                 _%$%g2345425352%_))
                                              '()))
                                  '()))
                      (cons _%$%g2345325351%_
                            (cons (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'quote))
                                        (cons _%$%g2345225350%_ '()))
                                  '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            '())))
                                 (declare (not safe))
                                 (foldr__0
                                  __tmp39084
                                  __tmp39082
                                  _%$%g2345725355%_))
                               (cons (let ((__tmp39085
                                            (lambda (_%$%g2541425431%_
                                                     _%$%g2541525434%_)
                                              (cons _%$%g2541425431%_
                                                    _%$%g2541525434%_))))
                                       (declare (not safe))
                                       (foldr__0
                                        __tmp39085
                                        '()
                                        _%$%g2345625354%_))
                                     (let ((__tmp39086
                                            (lambda (_%$%g2541625437%_
                                                     _%$%g2541725440%_)
                                              (cons _%$%g2541625437%_
                                                    _%$%g2541725440%_))))
                                       (declare (not safe))
                                       (foldr__0
                                        __tmp39086
                                        '()
                                        _%$%g2345125348%_)))))))
                (_%__kont3885738858%_
                 (lambda (_%$%g2352125048%_
                          _%$%g2352225050%_
                          _%$%g2352325051%_
                          _%$%g2352425052%_
                          _%$%g2352525053%_
                          _%$%g2352625054%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'relational-collect))
                         (cons (let ((__tmp39089
                                      (lambda (_%$%g2510625115%_
                                               _%$%g2510725118%_)
                                        (cons _%$%g2510625115%_
                                              _%$%g2510725118%_)))
                                     (__tmp39087
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'relational-source))
                                                  (cons (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'quote))
                      (cons _%$%g2352425052%_ '()))
                (cons (cons (let ()
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'length))
                            (cons (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'quote))
                                        (cons (let ((__tmp39088
                                                     (lambda (_%$%g2510825121%_
                                                              _%$%g2510925124%_)
                                                       (cons _%$%g2510825121%_
                                                             _%$%g2510925124%_))))
                                                (declare (not safe))
                                                (foldr__0
                                                 __tmp39088
                                                 '()
                                                 _%$%g2352325051%_))
                                              '()))
                                  '()))
                      (cons _%$%g2352225050%_ '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            '())))
                                 (declare (not safe))
                                 (foldr__0
                                  __tmp39089
                                  __tmp39087
                                  _%$%g2352625054%_))
                               (cons (let ((__tmp39090
                                            (lambda (_%$%g2511025127%_
                                                     _%$%g2511125130%_)
                                              (cons _%$%g2511025127%_
                                                    _%$%g2511125130%_))))
                                       (declare (not safe))
                                       (foldr__0
                                        __tmp39090
                                        '()
                                        _%$%g2352525053%_))
                                     (let ((__tmp39091
                                            (lambda (_%$%g2511225133%_
                                                     _%$%g2511325136%_)
                                              (cons _%$%g2511225133%_
                                                    _%$%g2511325136%_))))
                                       (declare (not safe))
                                       (foldr__0
                                        __tmp39091
                                        '()
                                        _%$%g2352125048%_)))))))
                (_%__kont3886738868%_
                 (lambda (_%$%g2358724762%_
                          _%$%g2358824764%_
                          _%$%g2358924765%_
                          _%$%g2359024766%_
                          _%$%g2359124767%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'relational-collect))
                         (cons (let ((__tmp39094
                                      (lambda (_%$%g2481624825%_
                                               _%$%g2481724828%_)
                                        (cons _%$%g2481624825%_
                                              _%$%g2481724828%_)))
                                     (__tmp39092
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'relational-source))
                                                  (cons (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'quote))
                      (cons _%$%g2358924765%_ '()))
                (cons (cons (let ()
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'length))
                            (cons (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'quote))
                                        (cons (let ((__tmp39093
                                                     (lambda (_%$%g2481824831%_
                                                              _%$%g2481924834%_)
                                                       (cons _%$%g2481824831%_
                                                             _%$%g2481924834%_))))
                                                (declare (not safe))
                                                (foldr__0
                                                 __tmp39093
                                                 '()
                                                 _%$%g2358824764%_))
                                              '()))
                                  '()))
                      (cons (cons (let ()
                                    (declare (not safe))
                                    (gx#datum->syntax__0 '#f '@list))
                                  '())
                            '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            '())))
                                 (declare (not safe))
                                 (foldr__0
                                  __tmp39094
                                  __tmp39092
                                  _%$%g2359124767%_))
                               (cons (let ((__tmp39095
                                            (lambda (_%$%g2482024837%_
                                                     _%$%g2482124840%_)
                                              (cons _%$%g2482024837%_
                                                    _%$%g2482124840%_))))
                                       (declare (not safe))
                                       (foldr__0
                                        __tmp39095
                                        '()
                                        _%$%g2359024766%_))
                                     (let ((__tmp39096
                                            (lambda (_%$%g2482224843%_
                                                     _%$%g2482324846%_)
                                              (cons _%$%g2482224843%_
                                                    _%$%g2482324846%_))))
                                       (declare (not safe))
                                       (foldr__0
                                        __tmp39096
                                        '()
                                        _%$%g2358724762%_)))))))
                (_%__kont3887738878%_
                 (lambda (_%$%g2364924496%_
                          _%$%g2365024498%_
                          _%$%g2365124499%_
                          _%$%g2365224500%_
                          _%$%g2365324501%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'relational-collect))
                         (cons (let ((__tmp39097
                                      (lambda (_%$%g2454024549%_
                                               _%$%g2454124552%_)
                                        (cons _%$%g2454024549%_
                                              _%$%g2454124552%_))))
                                 (declare (not safe))
                                 (foldr__0 __tmp39097 '() _%$%g2365324501%_))
                               (cons (let ((__tmp39100
                                            (lambda (_%$%g2454224555%_
                                                     _%$%g2454324558%_)
                                              (cons _%$%g2454224555%_
                                                    _%$%g2454324558%_)))
                                           (__tmp39098
                                            (cons (cons (let ()
                                                          (declare (not safe))
                                                          (gx#datum->syntax__0
                                                           '#f
                                                           'gerbil-ascent-rule))
                                                        (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'list))
                            (cons (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0
                                           '#f
                                           'relational-atom))
                                        (cons _%$%g2365124499%_ '()))
                                  '()))
                      (cons (cons (let ()
                                    (declare (not safe))
                                    (gx#datum->syntax__0 '#f 'list))
                                  (let ((__tmp39099
                                         (lambda (_%$%g2454424561%_
                                                  _%$%g2454524564%_)
                                           (cons (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'relational-checked-clause))
                                                       (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'relational-atom))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'relational-negation))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0
                                    '#f
                                    'relational-reduce))
                                 (cons _%$%g2454424561%_ '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 _%$%g2454524564%_))))
                                    (declare (not safe))
                                    (foldr__0
                                     __tmp39099
                                     '()
                                     _%$%g2365024498%_)))
                            '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  '())))
                                       (declare (not safe))
                                       (foldr__0
                                        __tmp39100
                                        __tmp39098
                                        _%$%g2365224500%_))
                                     (let ((__tmp39101
                                            (lambda (_%$%g2454624567%_
                                                     _%$%g2454724570%_)
                                              (cons _%$%g2454624567%_
                                                    _%$%g2454724570%_))))
                                       (declare (not safe))
                                       (foldr__0
                                        __tmp39101
                                        '()
                                        _%$%g2364924496%_)))))))
                (_%__kont3888738888%_
                 (lambda (_%$%g2370824260%_
                          _%$%g2370924262%_
                          _%$%g2371024263%_
                          _%$%g2371124264%_
                          _%$%g2371224265%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'let))
                         (cons (cons (let ()
                                       (declare (not safe))
                                       (gx#datum->syntax__0 '#f 'relations))
                                     (cons (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'list))
                                                 (let ((__tmp39102
                                                        (lambda (_%$%g2430024305%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%$%g2430124308%_)
                  (cons _%$%g2430024305%_ _%$%g2430124308%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (declare (not safe))
                                                   (foldr__0
                                                    __tmp39102
                                                    '()
                                                    _%$%g2371224265%_)))
                                           '()))
                               (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'gerbil-ascent-program))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'relations))
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'list))
                     (let ((__tmp39103
                            (lambda (_%$%g2430224311%_ _%$%g2430324314%_)
                              (cons _%$%g2430224311%_ _%$%g2430324314%_))))
                       (declare (not safe))
                       (foldr__0 __tmp39103 '() _%$%g2371124264%_)))
               (cons _%$%g2371024263%_
                     (cons _%$%g2370924262%_
                           (cons _%$%g2370824260%_
                                 (cons (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f 'map))
                                             (cons (cons (let ()
                                                           (declare (not safe))
                                                           (gx#datum->syntax__0
                                                            '#f
                                                            'lambda))
                                                         (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               (declare (not safe))
                               (gx#datum->syntax__0 '#f 'relation))
                             '())
                       (cons (cons (let ()
                                     (declare (not safe))
                                     (gx#datum->syntax__0 '#f '.ref))
                                   (cons (let ()
                                           (declare (not safe))
                                           (gx#datum->syntax__0 '#f 'relation))
                                         (cons (cons (let ()
                                                       (declare (not safe))
                                                       (gx#datum->syntax__0
                                                        '#f
                                                        'quote))
                                                     (cons (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#datum->syntax__0
                                                              '#f
                                                              'name))
                                                           '()))
                                               '())))
                             '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons (let ()
                                                           (declare (not safe))
                                                           (gx#datum->syntax__0
                                                            '#f
                                                            'relations))
                                                         '())))
                                       '())))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3889338894%_
                 (lambda (_%$%g2375524082%_
                          _%$%g2375624084%_
                          _%$%g2375724085%_
                          _%$%g2375824086%_)
                   (let ()
                     (declare (not safe))
                     (gx#raise-syntax-error
                      '#f
                      '"expected relation, rule, or final limits clause"
                      _%$%g2375624084%_))))
                (_%__kont3890138902%_
                 (lambda (_%$%g2379823925%_ _%$%g2379923927%_)
                   (let ()
                     (declare (not safe))
                     (gx#raise-syntax-error
                      '#f
                      '"relational-program requires a final limits clause"
                      _%stx23440%_)))))
            (let* ((_%__match3904739048%_
                    (lambda (_%$%e2380023839%_
                             _%$%hd2380123843%_
                             _%$%tl2380223846%_
                             _%$%e2380323849%_
                             _%$%hd2380423853%_
                             _%$%tl2380523856%_
                             _%__splice3890338904%_
                             _%$%target2380623859%_
                             _%$%tl2380823862%_)
                      (letrec ((_%$%loop2380923865%_
                                (lambda (_%$%hd2380723869%_
                                         _%$%declared2381323872%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2380723869%_))
                                      (let ((_%$%e2381023874%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2380723869%_))))
                                        (let ((_%$%lp-tl2381223881%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2381023874%_)))
                                              (_%$%lp-hd2381123878%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2381023874%_))))
                                          (_%$%loop2380923865%_
                                           _%$%lp-tl2381223881%_
                                           (cons _%$%lp-hd2381123878%_
                                                 _%$%declared2381323872%_))))
                                      (let ((_%$%declared2381423884%_
                                             (reverse _%$%declared2381323872%_)))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2380523856%_))
                                            (let ((_%$%e2381523887%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2380523856%_))))
                                              (let ((_%$%tl2381723894%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2381523887%_)))
                                                    (_%$%hd2381623891%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2381523887%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%hd2381623891%_))
                                                    (let ((_%__splice3890538906%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%hd2381623891%_
                                                              '0))))
                                                      (let ((_%$%tl2382023900%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3890538906%_ '1)))
                    (_%$%target2381823897%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3890538906%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2382023900%_))
                    (letrec ((_%$%loop2382123903%_
                              (lambda (_%$%hd2381923907%_
                                       _%$%lowered2382523910%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%hd2381923907%_))
                                    (let ((_%$%e2382223912%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%hd2381923907%_))))
                                      (let ((_%$%lp-tl2382423919%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2382223912%_)))
                                            (_%$%lp-hd2382323916%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2382223912%_))))
                                        (_%$%loop2382123903%_
                                         _%$%lp-tl2382423919%_
                                         (cons _%$%lp-hd2382323916%_
                                               _%$%lowered2382523910%_))))
                                    (let ((_%$%lowered2382623922%_
                                           (reverse _%$%lowered2382523910%_)))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-null? _%$%tl2381723894%_))
                                          (_%__kont3890138902%_
                                           _%$%lowered2382623922%_
                                           _%$%declared2381423884%_)
                                          (let ()
                                            (declare (not safe))
                                            (_%$%g2344923832%_))))))))
                      (_%$%loop2382123903%_ _%$%target2381823897%_ '()))
                    (let () (declare (not safe)) (_%$%g2344923832%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (let ()
                                                      (declare (not safe))
                                                      (_%$%g2344923832%_)))))
                                            (let ()
                                              (declare (not safe))
                                              (_%$%g2344923832%_))))))))
                        (_%$%loop2380923865%_ _%$%target2380623859%_ '()))))
                   (_%__match3902739028%_
                    (lambda (_%$%e2375923958%_
                             _%$%hd2376023962%_
                             _%$%tl2376123965%_
                             _%$%e2376223968%_
                             _%$%hd2376323972%_
                             _%$%tl2376423975%_
                             _%__splice3889538896%_
                             _%$%target2376523978%_
                             _%$%tl2376723981%_)
                      (letrec ((_%$%loop2376823984%_
                                (lambda (_%$%hd2376623988%_
                                         _%$%declared2377223991%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2376623988%_))
                                      (let ((_%$%e2376923993%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2376623988%_))))
                                        (let ((_%$%lp-tl2377124000%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2376923993%_)))
                                              (_%$%lp-hd2377023997%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2376923993%_))))
                                          (_%$%loop2376823984%_
                                           _%$%lp-tl2377124000%_
                                           (cons _%$%lp-hd2377023997%_
                                                 _%$%declared2377223991%_))))
                                      (let ((_%$%declared2377324003%_
                                             (reverse _%$%declared2377223991%_)))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2376423975%_))
                                            (let ((_%$%e2377424006%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2376423975%_))))
                                              (let ((_%$%tl2377624013%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2377424006%_)))
                                                    (_%$%hd2377524010%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2377424006%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%hd2377524010%_))
                                                    (let ((_%__splice3889738898%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%hd2377524010%_
                                                              '0))))
                                                      (let ((_%$%tl2377924019%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3889738898%_ '1)))
                    (_%$%target2377724016%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3889738898%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2377924019%_))
                    (letrec ((_%$%loop2378024022%_
                              (lambda (_%$%hd2377824026%_
                                       _%$%lowered2378424029%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%hd2377824026%_))
                                    (let ((_%$%e2378124031%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%hd2377824026%_))))
                                      (let ((_%$%lp-tl2378324038%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2378124031%_)))
                                            (_%$%lp-hd2378224035%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2378124031%_))))
                                        (_%$%loop2378024022%_
                                         _%$%lp-tl2378324038%_
                                         (cons _%$%lp-hd2378224035%_
                                               _%$%lowered2378424029%_))))
                                    (let ((_%$%lowered2378524041%_
                                           (reverse _%$%lowered2378424029%_)))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl2377624013%_))
                                          (let ((_%$%e2378624044%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl2377624013%_))))
                                            (let ((_%$%tl2378824051%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2378624044%_)))
                                                  (_%$%hd2378724048%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2378624044%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair/null?
                                                     _%$%tl2378824051%_))
                                                  (let ((_%__splice3889938900%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-split-splice->vector
                                                            _%$%tl2378824051%_
                                                            '0))))
                                                    (let ((_%$%tl2379124057%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##vector-ref
                                                              _%__splice3889938900%_
                                                              '1)))
                                                          (_%$%target2378924054%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##vector-ref
                                                              _%__splice3889938900%_
                                                              '0))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-null?
                                                             _%$%tl2379124057%_))
                                                          (letrec ((_%$%loop2379224060%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (lambda (_%$%hd2379024064%_ _%$%rest2379624067%_)
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%hd2379024064%_))
                                  (let ((_%$%e2379324069%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%hd2379024064%_))))
                                    (let ((_%$%lp-tl2379524076%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2379324069%_)))
                                          (_%$%lp-hd2379424073%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2379324069%_))))
                                      (_%$%loop2379224060%_
                                       _%$%lp-tl2379524076%_
                                       (cons _%$%lp-hd2379424073%_
                                             _%$%rest2379624067%_))))
                                  (let ((_%$%rest2379724079%_
                                         (reverse _%$%rest2379624067%_)))
                                    (_%__kont3889338894%_
                                     _%$%rest2379724079%_
                                     _%$%hd2378724048%_
                                     _%$%lowered2378524041%_
                                     _%$%declared2377324003%_))))))
                    (_%$%loop2379224060%_ _%$%target2378924054%_ '()))
                  (_%__match3904739048%_
                   _%$%e2375923958%_
                   _%$%hd2376023962%_
                   _%$%tl2376123965%_
                   _%$%e2376223968%_
                   _%$%hd2376323972%_
                   _%$%tl2376423975%_
                   _%__splice3889538896%_
                   _%$%target2376523978%_
                   _%$%tl2376723981%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%__match3904739048%_
                                                   _%$%e2375923958%_
                                                   _%$%hd2376023962%_
                                                   _%$%tl2376123965%_
                                                   _%$%e2376223968%_
                                                   _%$%hd2376323972%_
                                                   _%$%tl2376423975%_
                                                   _%__splice3889538896%_
                                                   _%$%target2376523978%_
                                                   _%$%tl2376723981%_))))
                                          (_%__match3904739048%_
                                           _%$%e2375923958%_
                                           _%$%hd2376023962%_
                                           _%$%tl2376123965%_
                                           _%$%e2376223968%_
                                           _%$%hd2376323972%_
                                           _%$%tl2376423975%_
                                           _%__splice3889538896%_
                                           _%$%target2376523978%_
                                           _%$%tl2376723981%_)))))))
                      (_%$%loop2378024022%_ _%$%target2377724016%_ '()))
                    (_%__match3904739048%_
                     _%$%e2375923958%_
                     _%$%hd2376023962%_
                     _%$%tl2376123965%_
                     _%$%e2376223968%_
                     _%$%hd2376323972%_
                     _%$%tl2376423975%_
                     _%__splice3889538896%_
                     _%$%target2376523978%_
                     _%$%tl2376723981%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3904739048%_
                                                     _%$%e2375923958%_
                                                     _%$%hd2376023962%_
                                                     _%$%tl2376123965%_
                                                     _%$%e2376223968%_
                                                     _%$%hd2376323972%_
                                                     _%$%tl2376423975%_
                                                     _%__splice3889538896%_
                                                     _%$%target2376523978%_
                                                     _%$%tl2376723981%_))))
                                            (_%__match3904739048%_
                                             _%$%e2375923958%_
                                             _%$%hd2376023962%_
                                             _%$%tl2376123965%_
                                             _%$%e2376223968%_
                                             _%$%hd2376323972%_
                                             _%$%tl2376423975%_
                                             _%__splice3889538896%_
                                             _%$%target2376523978%_
                                             _%$%tl2376723981%_)))))))
                        (_%$%loop2376823984%_ _%$%target2376523978%_ '()))))
                   (_%__match3900739008%_
                    (lambda (_%$%e2371324124%_
                             _%$%hd2371424128%_
                             _%$%tl2371524131%_
                             _%$%e2371624134%_
                             _%$%hd2371724138%_
                             _%$%tl2371824141%_
                             _%__splice3888938890%_
                             _%$%target2371924144%_
                             _%$%tl2372124147%_)
                      (letrec ((_%$%loop2372224150%_
                                (lambda (_%$%hd2372024154%_
                                         _%$%declared2372624157%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2372024154%_))
                                      (let ((_%$%e2372324159%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2372024154%_))))
                                        (let ((_%$%lp-tl2372524166%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2372324159%_)))
                                              (_%$%lp-hd2372424163%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2372324159%_))))
                                          (_%$%loop2372224150%_
                                           _%$%lp-tl2372524166%_
                                           (cons _%$%lp-hd2372424163%_
                                                 _%$%declared2372624157%_))))
                                      (let ((_%$%declared2372724169%_
                                             (reverse _%$%declared2372624157%_)))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2371824141%_))
                                            (let ((_%$%e2372824172%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2371824141%_))))
                                              (let ((_%$%tl2373024179%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2372824172%_)))
                                                    (_%$%hd2372924176%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2372824172%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%hd2372924176%_))
                                                    (let ((_%__splice3889138892%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%hd2372924176%_
                                                              '0))))
                                                      (let ((_%$%tl2373324185%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3889138892%_ '1)))
                    (_%$%target2373124182%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3889138892%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2373324185%_))
                    (letrec ((_%$%loop2373424188%_
                              (lambda (_%$%hd2373224192%_
                                       _%$%lowered2373824195%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%hd2373224192%_))
                                    (let ((_%$%e2373524197%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%hd2373224192%_))))
                                      (let ((_%$%lp-tl2373724204%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2373524197%_)))
                                            (_%$%lp-hd2373624201%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2373524197%_))))
                                        (_%$%loop2373424188%_
                                         _%$%lp-tl2373724204%_
                                         (cons _%$%lp-hd2373624201%_
                                               _%$%lowered2373824195%_))))
                                    (let ((_%$%lowered2373924207%_
                                           (reverse _%$%lowered2373824195%_)))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl2373024179%_))
                                          (let ((_%$%e2374024210%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl2373024179%_))))
                                            (let ((_%$%tl2374224217%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2374024210%_)))
                                                  (_%$%hd2374124214%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2374024210%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%hd2374124214%_))
                                                  (let ((_%$%e2374324220%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%hd2374124214%_))))
                                                    (let ((_%$%tl2374524227%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e2374324220%_)))
                                                          (_%$%hd2374424224%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e2374324220%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#identifier?
                                                             _%$%hd2374424224%_))
                                                          (if (let ((__tmp39104
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/scheme-language[1]#_g39105_|))
                        (declare (not safe))
                        (gx#free-identifier=? __tmp39104 _%$%hd2374424224%_))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2374524227%_))
                          (let ((_%$%e2374624230%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2374524227%_))))
                            (let ((_%$%tl2374824237%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2374624230%_)))
                                  (_%$%hd2374724234%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2374624230%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%tl2374824237%_))
                                  (let ((_%$%e2374924240%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%tl2374824237%_))))
                                    (let ((_%$%tl2375124247%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2374924240%_)))
                                          (_%$%hd2375024244%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2374924240%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl2375124247%_))
                                          (let ((_%$%e2375224250%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl2375124247%_))))
                                            (let ((_%$%tl2375424257%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2375224250%_)))
                                                  (_%$%hd2375324254%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2375224250%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2375424257%_))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-null?
                                                         _%$%tl2374224217%_))
                                                      (_%__kont3888738888%_
                                                       _%$%hd2375324254%_
                                                       _%$%hd2375024244%_
                                                       _%$%hd2374724234%_
                                                       _%$%lowered2373924207%_
                                                       _%$%declared2372724169%_)
                                                      (_%__match3902739028%_
                                                       _%$%e2371324124%_
                                                       _%$%hd2371424128%_
                                                       _%$%tl2371524131%_
                                                       _%$%e2371624134%_
                                                       _%$%hd2371724138%_
                                                       _%$%tl2371824141%_
                                                       _%__splice3888938890%_
                                                       _%$%target2371924144%_
                                                       _%$%tl2372124147%_))
                                                  (_%__match3902739028%_
                                                   _%$%e2371324124%_
                                                   _%$%hd2371424128%_
                                                   _%$%tl2371524131%_
                                                   _%$%e2371624134%_
                                                   _%$%hd2371724138%_
                                                   _%$%tl2371824141%_
                                                   _%__splice3888938890%_
                                                   _%$%target2371924144%_
                                                   _%$%tl2372124147%_))))
                                          (_%__match3902739028%_
                                           _%$%e2371324124%_
                                           _%$%hd2371424128%_
                                           _%$%tl2371524131%_
                                           _%$%e2371624134%_
                                           _%$%hd2371724138%_
                                           _%$%tl2371824141%_
                                           _%__splice3888938890%_
                                           _%$%target2371924144%_
                                           _%$%tl2372124147%_))))
                                  (_%__match3902739028%_
                                   _%$%e2371324124%_
                                   _%$%hd2371424128%_
                                   _%$%tl2371524131%_
                                   _%$%e2371624134%_
                                   _%$%hd2371724138%_
                                   _%$%tl2371824141%_
                                   _%__splice3888938890%_
                                   _%$%target2371924144%_
                                   _%$%tl2372124147%_))))
                          (_%__match3902739028%_
                           _%$%e2371324124%_
                           _%$%hd2371424128%_
                           _%$%tl2371524131%_
                           _%$%e2371624134%_
                           _%$%hd2371724138%_
                           _%$%tl2371824141%_
                           _%__splice3888938890%_
                           _%$%target2371924144%_
                           _%$%tl2372124147%_))
                      (_%__match3902739028%_
                       _%$%e2371324124%_
                       _%$%hd2371424128%_
                       _%$%tl2371524131%_
                       _%$%e2371624134%_
                       _%$%hd2371724138%_
                       _%$%tl2371824141%_
                       _%__splice3888938890%_
                       _%$%target2371924144%_
                       _%$%tl2372124147%_))
                  (_%__match3902739028%_
                   _%$%e2371324124%_
                   _%$%hd2371424128%_
                   _%$%tl2371524131%_
                   _%$%e2371624134%_
                   _%$%hd2371724138%_
                   _%$%tl2371824141%_
                   _%__splice3888938890%_
                   _%$%target2371924144%_
                   _%$%tl2372124147%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%__match3902739028%_
                                                   _%$%e2371324124%_
                                                   _%$%hd2371424128%_
                                                   _%$%tl2371524131%_
                                                   _%$%e2371624134%_
                                                   _%$%hd2371724138%_
                                                   _%$%tl2371824141%_
                                                   _%__splice3888938890%_
                                                   _%$%target2371924144%_
                                                   _%$%tl2372124147%_))))
                                          (_%__match3902739028%_
                                           _%$%e2371324124%_
                                           _%$%hd2371424128%_
                                           _%$%tl2371524131%_
                                           _%$%e2371624134%_
                                           _%$%hd2371724138%_
                                           _%$%tl2371824141%_
                                           _%__splice3888938890%_
                                           _%$%target2371924144%_
                                           _%$%tl2372124147%_)))))))
                      (_%$%loop2373424188%_ _%$%target2373124182%_ '()))
                    (_%__match3902739028%_
                     _%$%e2371324124%_
                     _%$%hd2371424128%_
                     _%$%tl2371524131%_
                     _%$%e2371624134%_
                     _%$%hd2371724138%_
                     _%$%tl2371824141%_
                     _%__splice3888938890%_
                     _%$%target2371924144%_
                     _%$%tl2372124147%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3902739028%_
                                                     _%$%e2371324124%_
                                                     _%$%hd2371424128%_
                                                     _%$%tl2371524131%_
                                                     _%$%e2371624134%_
                                                     _%$%hd2371724138%_
                                                     _%$%tl2371824141%_
                                                     _%__splice3888938890%_
                                                     _%$%target2371924144%_
                                                     _%$%tl2372124147%_))))
                                            (_%__match3902739028%_
                                             _%$%e2371324124%_
                                             _%$%hd2371424128%_
                                             _%$%tl2371524131%_
                                             _%$%e2371624134%_
                                             _%$%hd2371724138%_
                                             _%$%tl2371824141%_
                                             _%__splice3888938890%_
                                             _%$%target2371924144%_
                                             _%$%tl2372124147%_)))))))
                        (_%$%loop2372224150%_ _%$%target2371924144%_ '()))))
                   (_%__match3898738988%_
                    (lambda (_%$%e2365424324%_
                             _%$%hd2365524328%_
                             _%$%tl2365624331%_
                             _%$%e2365724334%_
                             _%$%hd2365824338%_
                             _%$%tl2365924341%_
                             _%__splice3887938880%_
                             _%$%target2366024344%_
                             _%$%tl2366224347%_)
                      (letrec ((_%$%loop2366324350%_
                                (lambda (_%$%hd2366124354%_
                                         _%$%declared2366724357%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2366124354%_))
                                      (let ((_%$%e2366424359%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2366124354%_))))
                                        (let ((_%$%lp-tl2366624366%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2366424359%_)))
                                              (_%$%lp-hd2366524363%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2366424359%_))))
                                          (_%$%loop2366324350%_
                                           _%$%lp-tl2366624366%_
                                           (cons _%$%lp-hd2366524363%_
                                                 _%$%declared2366724357%_))))
                                      (let ((_%$%declared2366824369%_
                                             (reverse _%$%declared2366724357%_)))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2365924341%_))
                                            (let ((_%$%e2366924372%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2365924341%_))))
                                              (let ((_%$%tl2367124379%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2366924372%_)))
                                                    (_%$%hd2367024376%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2366924372%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%hd2367024376%_))
                                                    (let ((_%__splice3888138882%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%hd2367024376%_
                                                              '0))))
                                                      (let ((_%$%tl2367424385%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3888138882%_ '1)))
                    (_%$%target2367224382%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3888138882%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2367424385%_))
                    (letrec ((_%$%loop2367524388%_
                              (lambda (_%$%hd2367324392%_
                                       _%$%lowered2367924395%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%hd2367324392%_))
                                    (let ((_%$%e2367624397%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%hd2367324392%_))))
                                      (let ((_%$%lp-tl2367824404%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2367624397%_)))
                                            (_%$%lp-hd2367724401%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2367624397%_))))
                                        (_%$%loop2367524388%_
                                         _%$%lp-tl2367824404%_
                                         (cons _%$%lp-hd2367724401%_
                                               _%$%lowered2367924395%_))))
                                    (let ((_%$%lowered2368024407%_
                                           (reverse _%$%lowered2367924395%_)))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl2367124379%_))
                                          (let ((_%$%e2368124410%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl2367124379%_))))
                                            (let ((_%$%tl2368324417%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2368124410%_)))
                                                  (_%$%hd2368224414%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2368124410%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%hd2368224414%_))
                                                  (let ((_%$%e2368424420%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%hd2368224414%_))))
                                                    (let ((_%$%tl2368624427%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e2368424420%_)))
                                                          (_%$%hd2368524424%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e2368424420%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#identifier?
                                                             _%$%hd2368524424%_))
                                                          (if (let ((__tmp39106
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/scheme-language[1]#_g39107_|))
                        (declare (not safe))
                        (gx#free-identifier=? __tmp39106 _%$%hd2368524424%_))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2368624427%_))
                          (let ((_%$%e2368724430%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2368624427%_))))
                            (let ((_%$%tl2368924437%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2368724430%_)))
                                  (_%$%hd2368824434%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2368724430%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair/null? _%$%tl2368924437%_))
                                  (let ((_%__splice3888338884%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-split-splice->vector
                                            _%$%tl2368924437%_
                                            '0))))
                                    (let ((_%$%tl2369224443%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-ref
                                              _%__splice3888338884%_
                                              '1)))
                                          (_%$%target2369024440%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-ref
                                              _%__splice3888338884%_
                                              '0))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-null? _%$%tl2369224443%_))
                                          (letrec ((_%$%loop2369324446%_
                                                    (lambda (_%$%hd2369124450%_
                                                             _%$%body2369724453%_)
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-pair?
                                                             _%$%hd2369124450%_))
                                                          (let ((_%$%e2369424455%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%$%hd2369124450%_))))
                    (let ((_%$%lp-tl2369624462%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2369424455%_)))
                          (_%$%lp-hd2369524459%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2369424455%_))))
                      (_%$%loop2369324446%_
                       _%$%lp-tl2369624462%_
                       (cons _%$%lp-hd2369524459%_ _%$%body2369724453%_))))
                  (let ((_%$%body2369824465%_ (reverse _%$%body2369724453%_)))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-pair/null? _%$%tl2368324417%_))
                        (let ((_%__splice3888538886%_
                               (let ()
                                 (declare (not safe))
                                 (gx#syntax-split-splice->vector
                                  _%$%tl2368324417%_
                                  '0))))
                          (let ((_%$%tl2370124471%_
                                 (let ()
                                   (declare (not safe))
                                   (##vector-ref _%__splice3888538886%_ '1)))
                                (_%$%target2369924468%_
                                 (let ()
                                   (declare (not safe))
                                   (##vector-ref _%__splice3888538886%_ '0))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2370124471%_))
                                (letrec ((_%$%loop2370224474%_
                                          (lambda (_%$%hd2370024478%_
                                                   _%$%rest2370624481%_)
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair?
                                                   _%$%hd2370024478%_))
                                                (let ((_%$%e2370324483%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-e
                                                          _%$%hd2370024478%_))))
                                                  (let ((_%$%lp-tl2370524490%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e2370324483%_)))
                                                        (_%$%lp-hd2370424487%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e2370324483%_))))
                                                    (_%$%loop2370224474%_
                                                     _%$%lp-tl2370524490%_
                                                     (cons _%$%lp-hd2370424487%_
                                                           _%$%rest2370624481%_))))
                                                (let ((_%$%rest2370724493%_
                                                       (reverse _%$%rest2370624481%_)))
                                                  (_%__kont3887738878%_
                                                   _%$%rest2370724493%_
                                                   _%$%body2369824465%_
                                                   _%$%hd2368824434%_
                                                   _%$%lowered2368024407%_
                                                   _%$%declared2366824369%_))))))
                                  (_%$%loop2370224474%_
                                   _%$%target2369924468%_
                                   '()))
                                (_%__match3900739008%_
                                 _%$%e2365424324%_
                                 _%$%hd2365524328%_
                                 _%$%tl2365624331%_
                                 _%$%e2365724334%_
                                 _%$%hd2365824338%_
                                 _%$%tl2365924341%_
                                 _%__splice3887938880%_
                                 _%$%target2366024344%_
                                 _%$%tl2366224347%_))))
                        (_%__match3900739008%_
                         _%$%e2365424324%_
                         _%$%hd2365524328%_
                         _%$%tl2365624331%_
                         _%$%e2365724334%_
                         _%$%hd2365824338%_
                         _%$%tl2365924341%_
                         _%__splice3887938880%_
                         _%$%target2366024344%_
                         _%$%tl2366224347%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (_%$%loop2369324446%_
                                             _%$%target2369024440%_
                                             '()))
                                          (_%__match3900739008%_
                                           _%$%e2365424324%_
                                           _%$%hd2365524328%_
                                           _%$%tl2365624331%_
                                           _%$%e2365724334%_
                                           _%$%hd2365824338%_
                                           _%$%tl2365924341%_
                                           _%__splice3887938880%_
                                           _%$%target2366024344%_
                                           _%$%tl2366224347%_))))
                                  (_%__match3900739008%_
                                   _%$%e2365424324%_
                                   _%$%hd2365524328%_
                                   _%$%tl2365624331%_
                                   _%$%e2365724334%_
                                   _%$%hd2365824338%_
                                   _%$%tl2365924341%_
                                   _%__splice3887938880%_
                                   _%$%target2366024344%_
                                   _%$%tl2366224347%_))))
                          (_%__match3900739008%_
                           _%$%e2365424324%_
                           _%$%hd2365524328%_
                           _%$%tl2365624331%_
                           _%$%e2365724334%_
                           _%$%hd2365824338%_
                           _%$%tl2365924341%_
                           _%__splice3887938880%_
                           _%$%target2366024344%_
                           _%$%tl2366224347%_))
                      (_%__match3900739008%_
                       _%$%e2365424324%_
                       _%$%hd2365524328%_
                       _%$%tl2365624331%_
                       _%$%e2365724334%_
                       _%$%hd2365824338%_
                       _%$%tl2365924341%_
                       _%__splice3887938880%_
                       _%$%target2366024344%_
                       _%$%tl2366224347%_))
                  (_%__match3900739008%_
                   _%$%e2365424324%_
                   _%$%hd2365524328%_
                   _%$%tl2365624331%_
                   _%$%e2365724334%_
                   _%$%hd2365824338%_
                   _%$%tl2365924341%_
                   _%__splice3887938880%_
                   _%$%target2366024344%_
                   _%$%tl2366224347%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%__match3900739008%_
                                                   _%$%e2365424324%_
                                                   _%$%hd2365524328%_
                                                   _%$%tl2365624331%_
                                                   _%$%e2365724334%_
                                                   _%$%hd2365824338%_
                                                   _%$%tl2365924341%_
                                                   _%__splice3887938880%_
                                                   _%$%target2366024344%_
                                                   _%$%tl2366224347%_))))
                                          (_%__match3900739008%_
                                           _%$%e2365424324%_
                                           _%$%hd2365524328%_
                                           _%$%tl2365624331%_
                                           _%$%e2365724334%_
                                           _%$%hd2365824338%_
                                           _%$%tl2365924341%_
                                           _%__splice3887938880%_
                                           _%$%target2366024344%_
                                           _%$%tl2366224347%_)))))))
                      (_%$%loop2367524388%_ _%$%target2367224382%_ '()))
                    (_%__match3900739008%_
                     _%$%e2365424324%_
                     _%$%hd2365524328%_
                     _%$%tl2365624331%_
                     _%$%e2365724334%_
                     _%$%hd2365824338%_
                     _%$%tl2365924341%_
                     _%__splice3887938880%_
                     _%$%target2366024344%_
                     _%$%tl2366224347%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3900739008%_
                                                     _%$%e2365424324%_
                                                     _%$%hd2365524328%_
                                                     _%$%tl2365624331%_
                                                     _%$%e2365724334%_
                                                     _%$%hd2365824338%_
                                                     _%$%tl2365924341%_
                                                     _%__splice3887938880%_
                                                     _%$%target2366024344%_
                                                     _%$%tl2366224347%_))))
                                            (_%__match3900739008%_
                                             _%$%e2365424324%_
                                             _%$%hd2365524328%_
                                             _%$%tl2365624331%_
                                             _%$%e2365724334%_
                                             _%$%hd2365824338%_
                                             _%$%tl2365924341%_
                                             _%__splice3887938880%_
                                             _%$%target2366024344%_
                                             _%$%tl2366224347%_)))))))
                        (_%$%loop2366324350%_ _%$%target2366024344%_ '()))))
                   (_%__match3896738968%_
                    (lambda (_%$%e2359224580%_
                             _%$%hd2359324584%_
                             _%$%tl2359424587%_
                             _%$%e2359524590%_
                             _%$%hd2359624594%_
                             _%$%tl2359724597%_
                             _%__splice3886938870%_
                             _%$%target2359824600%_
                             _%$%tl2360024603%_)
                      (letrec ((_%$%loop2360124606%_
                                (lambda (_%$%hd2359924610%_
                                         _%$%declared2360524613%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2359924610%_))
                                      (let ((_%$%e2360224615%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2359924610%_))))
                                        (let ((_%$%lp-tl2360424622%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2360224615%_)))
                                              (_%$%lp-hd2360324619%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2360224615%_))))
                                          (_%$%loop2360124606%_
                                           _%$%lp-tl2360424622%_
                                           (cons _%$%lp-hd2360324619%_
                                                 _%$%declared2360524613%_))))
                                      (let ((_%$%declared2360624625%_
                                             (reverse _%$%declared2360524613%_)))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2359724597%_))
                                            (let ((_%$%e2360724628%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2359724597%_))))
                                              (let ((_%$%tl2360924635%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2360724628%_)))
                                                    (_%$%hd2360824632%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2360724628%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%hd2360824632%_))
                                                    (let ((_%__splice3887138872%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%hd2360824632%_
                                                              '0))))
                                                      (let ((_%$%tl2361224641%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3887138872%_ '1)))
                    (_%$%target2361024638%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3887138872%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2361224641%_))
                    (letrec ((_%$%loop2361324644%_
                              (lambda (_%$%hd2361124648%_
                                       _%$%lowered2361724651%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%hd2361124648%_))
                                    (let ((_%$%e2361424653%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%hd2361124648%_))))
                                      (let ((_%$%lp-tl2361624660%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2361424653%_)))
                                            (_%$%lp-hd2361524657%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2361424653%_))))
                                        (_%$%loop2361324644%_
                                         _%$%lp-tl2361624660%_
                                         (cons _%$%lp-hd2361524657%_
                                               _%$%lowered2361724651%_))))
                                    (let ((_%$%lowered2361824663%_
                                           (reverse _%$%lowered2361724651%_)))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl2360924635%_))
                                          (let ((_%$%e2361924666%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl2360924635%_))))
                                            (let ((_%$%tl2362124673%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2361924666%_)))
                                                  (_%$%hd2362024670%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2361924666%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%hd2362024670%_))
                                                  (let ((_%$%e2362224676%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%hd2362024670%_))))
                                                    (let ((_%$%tl2362424683%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e2362224676%_)))
                                                          (_%$%hd2362324680%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e2362224676%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#identifier?
                                                             _%$%hd2362324680%_))
                                                          (if (let ((__tmp39108
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/scheme-language[1]#_g39109_|))
                        (declare (not safe))
                        (gx#free-identifier=? __tmp39108 _%$%hd2362324680%_))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2362424683%_))
                          (let ((_%$%e2362524686%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2362424683%_))))
                            (let ((_%$%tl2362724693%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2362524686%_)))
                                  (_%$%hd2362624690%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2362524686%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%tl2362724693%_))
                                  (let ((_%$%e2362824696%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%tl2362724693%_))))
                                    (let ((_%$%tl2363024703%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2362824696%_)))
                                          (_%$%hd2362924700%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2362824696%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair/null?
                                             _%$%hd2362924700%_))
                                          (let ((_%__splice3887338874%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-split-splice->vector
                                                    _%$%hd2362924700%_
                                                    '0))))
                                            (let ((_%$%tl2363324709%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3887338874%_
                                                      '1)))
                                                  (_%$%target2363124706%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3887338874%_
                                                      '0))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2363324709%_))
                                                  (letrec ((_%$%loop2363424712%_
                                                            (lambda (_%$%hd2363224716%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             _%$%column2363824719%_)
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%hd2363224716%_))
                          (let ((_%$%e2363524721%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%hd2363224716%_))))
                            (let ((_%$%lp-tl2363724728%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2363524721%_)))
                                  (_%$%lp-hd2363624725%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2363524721%_))))
                              (_%$%loop2363424712%_
                               _%$%lp-tl2363724728%_
                               (cons _%$%lp-hd2363624725%_
                                     _%$%column2363824719%_))))
                          (let ((_%$%column2363924731%_
                                 (reverse _%$%column2363824719%_)))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2363024703%_))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair/null? _%$%tl2362124673%_))
                                    (let ((_%__splice3887538876%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-split-splice->vector
                                              _%$%tl2362124673%_
                                              '0))))
                                      (let ((_%$%tl2364224737%_
                                             (let ()
                                               (declare (not safe))
                                               (##vector-ref
                                                _%__splice3887538876%_
                                                '1)))
                                            (_%$%target2364024734%_
                                             (let ()
                                               (declare (not safe))
                                               (##vector-ref
                                                _%__splice3887538876%_
                                                '0))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-null?
                                               _%$%tl2364224737%_))
                                            (letrec ((_%$%loop2364324740%_
                                                      (lambda (_%$%hd2364124744%_
                                                               _%$%rest2364724747%_)
                                                        (if (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#stx-pair?
                                                               _%$%hd2364124744%_))
                                                            (let ((_%$%e2364424749%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%$%hd2364124744%_))))
                      (let ((_%$%lp-tl2364624756%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e2364424749%_)))
                            (_%$%lp-hd2364524753%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e2364424749%_))))
                        (_%$%loop2364324740%_
                         _%$%lp-tl2364624756%_
                         (cons _%$%lp-hd2364524753%_ _%$%rest2364724747%_))))
                    (let ((_%$%rest2364824759%_
                           (reverse _%$%rest2364724747%_)))
                      (let ((_%$%g2358724762%_ _%$%rest2364824759%_)
                            (_%$%g2358824764%_ _%$%column2363924731%_)
                            (_%$%g2358924765%_ _%$%hd2362624690%_)
                            (_%$%g2359024766%_ _%$%lowered2361824663%_)
                            (_%$%g2359124767%_ _%$%declared2360624625%_))
                        (if (and (let ()
                                   (declare (not safe))
                                   (gx#identifier? _%$%g2358924765%_))
                                 (let ((__tmp39110
                                        (let ((__tmp39111
                                               (let ((__tmp39112
                                                      (lambda (_%$%g2480824811%_
                                                               _%$%g2480924814%_)
                                                        (cons _%$%g2480824811%_
                                                              _%$%g2480924814%_))))
                                                 (declare (not safe))
                                                 (foldr__0
                                                  __tmp39112
                                                  '()
                                                  _%$%g2358824764%_))))
                                          (declare (not safe))
                                          (gx#syntax->list __tmp39111))))
                                   (declare (not safe))
                                   (andmap__0 gx#identifier? __tmp39110)))
                            (_%__kont3886738868%_
                             _%$%g2358724762%_
                             _%$%g2358824764%_
                             _%$%g2358924765%_
                             _%$%g2359024766%_
                             _%$%g2359124767%_)
                            (_%__match3898738988%_
                             _%$%e2359224580%_
                             _%$%hd2359324584%_
                             _%$%tl2359424587%_
                             _%$%e2359524590%_
                             _%$%hd2359624594%_
                             _%$%tl2359724597%_
                             _%__splice3886938870%_
                             _%$%target2359824600%_
                             _%$%tl2360024603%_))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%$%loop2364324740%_
                                               _%$%target2364024734%_
                                               '()))
                                            (_%__match3898738988%_
                                             _%$%e2359224580%_
                                             _%$%hd2359324584%_
                                             _%$%tl2359424587%_
                                             _%$%e2359524590%_
                                             _%$%hd2359624594%_
                                             _%$%tl2359724597%_
                                             _%__splice3886938870%_
                                             _%$%target2359824600%_
                                             _%$%tl2360024603%_))))
                                    (_%__match3898738988%_
                                     _%$%e2359224580%_
                                     _%$%hd2359324584%_
                                     _%$%tl2359424587%_
                                     _%$%e2359524590%_
                                     _%$%hd2359624594%_
                                     _%$%tl2359724597%_
                                     _%__splice3886938870%_
                                     _%$%target2359824600%_
                                     _%$%tl2360024603%_))
                                (_%__match3898738988%_
                                 _%$%e2359224580%_
                                 _%$%hd2359324584%_
                                 _%$%tl2359424587%_
                                 _%$%e2359524590%_
                                 _%$%hd2359624594%_
                                 _%$%tl2359724597%_
                                 _%__splice3886938870%_
                                 _%$%target2359824600%_
                                 _%$%tl2360024603%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%loop2363424712%_
                                                     _%$%target2363124706%_
                                                     '()))
                                                  (_%__match3898738988%_
                                                   _%$%e2359224580%_
                                                   _%$%hd2359324584%_
                                                   _%$%tl2359424587%_
                                                   _%$%e2359524590%_
                                                   _%$%hd2359624594%_
                                                   _%$%tl2359724597%_
                                                   _%__splice3886938870%_
                                                   _%$%target2359824600%_
                                                   _%$%tl2360024603%_))))
                                          (_%__match3898738988%_
                                           _%$%e2359224580%_
                                           _%$%hd2359324584%_
                                           _%$%tl2359424587%_
                                           _%$%e2359524590%_
                                           _%$%hd2359624594%_
                                           _%$%tl2359724597%_
                                           _%__splice3886938870%_
                                           _%$%target2359824600%_
                                           _%$%tl2360024603%_))))
                                  (_%__match3898738988%_
                                   _%$%e2359224580%_
                                   _%$%hd2359324584%_
                                   _%$%tl2359424587%_
                                   _%$%e2359524590%_
                                   _%$%hd2359624594%_
                                   _%$%tl2359724597%_
                                   _%__splice3886938870%_
                                   _%$%target2359824600%_
                                   _%$%tl2360024603%_))))
                          (_%__match3898738988%_
                           _%$%e2359224580%_
                           _%$%hd2359324584%_
                           _%$%tl2359424587%_
                           _%$%e2359524590%_
                           _%$%hd2359624594%_
                           _%$%tl2359724597%_
                           _%__splice3886938870%_
                           _%$%target2359824600%_
                           _%$%tl2360024603%_))
                      (_%__match3898738988%_
                       _%$%e2359224580%_
                       _%$%hd2359324584%_
                       _%$%tl2359424587%_
                       _%$%e2359524590%_
                       _%$%hd2359624594%_
                       _%$%tl2359724597%_
                       _%__splice3886938870%_
                       _%$%target2359824600%_
                       _%$%tl2360024603%_))
                  (_%__match3898738988%_
                   _%$%e2359224580%_
                   _%$%hd2359324584%_
                   _%$%tl2359424587%_
                   _%$%e2359524590%_
                   _%$%hd2359624594%_
                   _%$%tl2359724597%_
                   _%__splice3886938870%_
                   _%$%target2359824600%_
                   _%$%tl2360024603%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%__match3898738988%_
                                                   _%$%e2359224580%_
                                                   _%$%hd2359324584%_
                                                   _%$%tl2359424587%_
                                                   _%$%e2359524590%_
                                                   _%$%hd2359624594%_
                                                   _%$%tl2359724597%_
                                                   _%__splice3886938870%_
                                                   _%$%target2359824600%_
                                                   _%$%tl2360024603%_))))
                                          (_%__match3898738988%_
                                           _%$%e2359224580%_
                                           _%$%hd2359324584%_
                                           _%$%tl2359424587%_
                                           _%$%e2359524590%_
                                           _%$%hd2359624594%_
                                           _%$%tl2359724597%_
                                           _%__splice3886938870%_
                                           _%$%target2359824600%_
                                           _%$%tl2360024603%_)))))))
                      (_%$%loop2361324644%_ _%$%target2361024638%_ '()))
                    (_%__match3898738988%_
                     _%$%e2359224580%_
                     _%$%hd2359324584%_
                     _%$%tl2359424587%_
                     _%$%e2359524590%_
                     _%$%hd2359624594%_
                     _%$%tl2359724597%_
                     _%__splice3886938870%_
                     _%$%target2359824600%_
                     _%$%tl2360024603%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3898738988%_
                                                     _%$%e2359224580%_
                                                     _%$%hd2359324584%_
                                                     _%$%tl2359424587%_
                                                     _%$%e2359524590%_
                                                     _%$%hd2359624594%_
                                                     _%$%tl2359724597%_
                                                     _%__splice3886938870%_
                                                     _%$%target2359824600%_
                                                     _%$%tl2360024603%_))))
                                            (_%__match3898738988%_
                                             _%$%e2359224580%_
                                             _%$%hd2359324584%_
                                             _%$%tl2359424587%_
                                             _%$%e2359524590%_
                                             _%$%hd2359624594%_
                                             _%$%tl2359724597%_
                                             _%__splice3886938870%_
                                             _%$%target2359824600%_
                                             _%$%tl2360024603%_)))))))
                        (_%$%loop2360124606%_ _%$%target2359824600%_ '()))))
                   (_%__match3894738948%_
                    (lambda (_%$%e2352724856%_
                             _%$%hd2352824860%_
                             _%$%tl2352924863%_
                             _%$%e2353024866%_
                             _%$%hd2353124870%_
                             _%$%tl2353224873%_
                             _%__splice3885938860%_
                             _%$%target2353324876%_
                             _%$%tl2353524879%_)
                      (letrec ((_%$%loop2353624882%_
                                (lambda (_%$%hd2353424886%_
                                         _%$%declared2354024889%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2353424886%_))
                                      (let ((_%$%e2353724891%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2353424886%_))))
                                        (let ((_%$%lp-tl2353924898%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2353724891%_)))
                                              (_%$%lp-hd2353824895%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2353724891%_))))
                                          (_%$%loop2353624882%_
                                           _%$%lp-tl2353924898%_
                                           (cons _%$%lp-hd2353824895%_
                                                 _%$%declared2354024889%_))))
                                      (let ((_%$%declared2354124901%_
                                             (reverse _%$%declared2354024889%_)))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2353224873%_))
                                            (let ((_%$%e2354224904%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2353224873%_))))
                                              (let ((_%$%tl2354424911%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2354224904%_)))
                                                    (_%$%hd2354324908%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2354224904%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%hd2354324908%_))
                                                    (let ((_%__splice3886138862%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%hd2354324908%_
                                                              '0))))
                                                      (let ((_%$%tl2354724917%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3886138862%_ '1)))
                    (_%$%target2354524914%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3886138862%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2354724917%_))
                    (letrec ((_%$%loop2354824920%_
                              (lambda (_%$%hd2354624924%_
                                       _%$%lowered2355224927%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%hd2354624924%_))
                                    (let ((_%$%e2354924929%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%hd2354624924%_))))
                                      (let ((_%$%lp-tl2355124936%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2354924929%_)))
                                            (_%$%lp-hd2355024933%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2354924929%_))))
                                        (_%$%loop2354824920%_
                                         _%$%lp-tl2355124936%_
                                         (cons _%$%lp-hd2355024933%_
                                               _%$%lowered2355224927%_))))
                                    (let ((_%$%lowered2355324939%_
                                           (reverse _%$%lowered2355224927%_)))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl2354424911%_))
                                          (let ((_%$%e2355424942%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl2354424911%_))))
                                            (let ((_%$%tl2355624949%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2355424942%_)))
                                                  (_%$%hd2355524946%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2355424942%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%hd2355524946%_))
                                                  (let ((_%$%e2355724952%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%hd2355524946%_))))
                                                    (let ((_%$%tl2355924959%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e2355724952%_)))
                                                          (_%$%hd2355824956%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e2355724952%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#identifier?
                                                             _%$%hd2355824956%_))
                                                          (if (let ((__tmp39113
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/scheme-language[1]#_g39114_|))
                        (declare (not safe))
                        (gx#free-identifier=? __tmp39113 _%$%hd2355824956%_))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2355924959%_))
                          (let ((_%$%e2356024962%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2355924959%_))))
                            (let ((_%$%tl2356224969%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2356024962%_)))
                                  (_%$%hd2356124966%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2356024962%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%tl2356224969%_))
                                  (let ((_%$%e2356324972%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%tl2356224969%_))))
                                    (let ((_%$%tl2356524979%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2356324972%_)))
                                          (_%$%hd2356424976%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2356324972%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair/null?
                                             _%$%hd2356424976%_))
                                          (let ((_%__splice3886338864%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-split-splice->vector
                                                    _%$%hd2356424976%_
                                                    '0))))
                                            (let ((_%$%tl2356824985%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3886338864%_
                                                      '1)))
                                                  (_%$%target2356624982%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3886338864%_
                                                      '0))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2356824985%_))
                                                  (letrec ((_%$%loop2356924988%_
                                                            (lambda (_%$%hd2356724992%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             _%$%column2357324995%_)
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%hd2356724992%_))
                          (let ((_%$%e2357024997%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%hd2356724992%_))))
                            (let ((_%$%lp-tl2357225004%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2357024997%_)))
                                  (_%$%lp-hd2357125001%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2357024997%_))))
                              (_%$%loop2356924988%_
                               _%$%lp-tl2357225004%_
                               (cons _%$%lp-hd2357125001%_
                                     _%$%column2357324995%_))))
                          (let ((_%$%column2357425007%_
                                 (reverse _%$%column2357324995%_)))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair? _%$%tl2356524979%_))
                                (let ((_%$%e2357525010%_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-e _%$%tl2356524979%_))))
                                  (let ((_%$%tl2357725017%_
                                         (let ()
                                           (declare (not safe))
                                           (##cdr _%$%e2357525010%_)))
                                        (_%$%hd2357625014%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%e2357525010%_))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2357725017%_))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair/null?
                                               _%$%tl2355624949%_))
                                            (let ((_%__splice3886538866%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-split-splice->vector
                                                      _%$%tl2355624949%_
                                                      '0))))
                                              (let ((_%$%tl2358025023%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##vector-ref
                                                        _%__splice3886538866%_
                                                        '1)))
                                                    (_%$%target2357825020%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##vector-ref
                                                        _%__splice3886538866%_
                                                        '0))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl2358025023%_))
                                                    (letrec ((_%$%loop2358125026%_
                                                              (lambda (_%$%hd2357925030%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               _%$%rest2358525033%_)
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair? _%$%hd2357925030%_))
                            (let ((_%$%e2358225035%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-e _%$%hd2357925030%_))))
                              (let ((_%$%lp-tl2358425042%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e2358225035%_)))
                                    (_%$%lp-hd2358325039%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e2358225035%_))))
                                (_%$%loop2358125026%_
                                 _%$%lp-tl2358425042%_
                                 (cons _%$%lp-hd2358325039%_
                                       _%$%rest2358525033%_))))
                            (let ((_%$%rest2358625045%_
                                   (reverse _%$%rest2358525033%_)))
                              (let ((_%$%g2352125048%_ _%$%rest2358625045%_)
                                    (_%$%g2352225050%_ _%$%hd2357625014%_)
                                    (_%$%g2352325051%_ _%$%column2357425007%_)
                                    (_%$%g2352425052%_ _%$%hd2356124966%_)
                                    (_%$%g2352525053%_ _%$%lowered2355324939%_)
                                    (_%$%g2352625054%_
                                     _%$%declared2354124901%_))
                                (if (and (let ()
                                           (declare (not safe))
                                           (gx#identifier? _%$%g2352425052%_))
                                         (let ((__tmp39115
                                                (let ((__tmp39116
                                                       (let ((__tmp39117
                                                              (lambda (_%$%g2509825101%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               _%$%g2509925104%_)
                        (cons _%$%g2509825101%_ _%$%g2509925104%_))))
                 (declare (not safe))
                 (foldr__0 __tmp39117 '() _%$%g2352325051%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (declare (not safe))
                                                  (gx#syntax->list
                                                   __tmp39116))))
                                           (declare (not safe))
                                           (andmap__0
                                            gx#identifier?
                                            __tmp39115)))
                                    (_%__kont3885738858%_
                                     _%$%g2352125048%_
                                     _%$%g2352225050%_
                                     _%$%g2352325051%_
                                     _%$%g2352425052%_
                                     _%$%g2352525053%_
                                     _%$%g2352625054%_)
                                    (_%__match3896738968%_
                                     _%$%e2352724856%_
                                     _%$%hd2352824860%_
                                     _%$%tl2352924863%_
                                     _%$%e2353024866%_
                                     _%$%hd2353124870%_
                                     _%$%tl2353224873%_
                                     _%__splice3885938860%_
                                     _%$%target2353324876%_
                                     _%$%tl2353524879%_))))))))
              (_%$%loop2358125026%_ _%$%target2357825020%_ '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3896738968%_
                                                     _%$%e2352724856%_
                                                     _%$%hd2352824860%_
                                                     _%$%tl2352924863%_
                                                     _%$%e2353024866%_
                                                     _%$%hd2353124870%_
                                                     _%$%tl2353224873%_
                                                     _%__splice3885938860%_
                                                     _%$%target2353324876%_
                                                     _%$%tl2353524879%_))))
                                            (_%__match3896738968%_
                                             _%$%e2352724856%_
                                             _%$%hd2352824860%_
                                             _%$%tl2352924863%_
                                             _%$%e2353024866%_
                                             _%$%hd2353124870%_
                                             _%$%tl2353224873%_
                                             _%__splice3885938860%_
                                             _%$%target2353324876%_
                                             _%$%tl2353524879%_))
                                        (_%__match3896738968%_
                                         _%$%e2352724856%_
                                         _%$%hd2352824860%_
                                         _%$%tl2352924863%_
                                         _%$%e2353024866%_
                                         _%$%hd2353124870%_
                                         _%$%tl2353224873%_
                                         _%__splice3885938860%_
                                         _%$%target2353324876%_
                                         _%$%tl2353524879%_))))
                                (_%__match3896738968%_
                                 _%$%e2352724856%_
                                 _%$%hd2352824860%_
                                 _%$%tl2352924863%_
                                 _%$%e2353024866%_
                                 _%$%hd2353124870%_
                                 _%$%tl2353224873%_
                                 _%__splice3885938860%_
                                 _%$%target2353324876%_
                                 _%$%tl2353524879%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%loop2356924988%_
                                                     _%$%target2356624982%_
                                                     '()))
                                                  (_%__match3896738968%_
                                                   _%$%e2352724856%_
                                                   _%$%hd2352824860%_
                                                   _%$%tl2352924863%_
                                                   _%$%e2353024866%_
                                                   _%$%hd2353124870%_
                                                   _%$%tl2353224873%_
                                                   _%__splice3885938860%_
                                                   _%$%target2353324876%_
                                                   _%$%tl2353524879%_))))
                                          (_%__match3896738968%_
                                           _%$%e2352724856%_
                                           _%$%hd2352824860%_
                                           _%$%tl2352924863%_
                                           _%$%e2353024866%_
                                           _%$%hd2353124870%_
                                           _%$%tl2353224873%_
                                           _%__splice3885938860%_
                                           _%$%target2353324876%_
                                           _%$%tl2353524879%_))))
                                  (_%__match3896738968%_
                                   _%$%e2352724856%_
                                   _%$%hd2352824860%_
                                   _%$%tl2352924863%_
                                   _%$%e2353024866%_
                                   _%$%hd2353124870%_
                                   _%$%tl2353224873%_
                                   _%__splice3885938860%_
                                   _%$%target2353324876%_
                                   _%$%tl2353524879%_))))
                          (_%__match3896738968%_
                           _%$%e2352724856%_
                           _%$%hd2352824860%_
                           _%$%tl2352924863%_
                           _%$%e2353024866%_
                           _%$%hd2353124870%_
                           _%$%tl2353224873%_
                           _%__splice3885938860%_
                           _%$%target2353324876%_
                           _%$%tl2353524879%_))
                      (_%__match3896738968%_
                       _%$%e2352724856%_
                       _%$%hd2352824860%_
                       _%$%tl2352924863%_
                       _%$%e2353024866%_
                       _%$%hd2353124870%_
                       _%$%tl2353224873%_
                       _%__splice3885938860%_
                       _%$%target2353324876%_
                       _%$%tl2353524879%_))
                  (_%__match3896738968%_
                   _%$%e2352724856%_
                   _%$%hd2352824860%_
                   _%$%tl2352924863%_
                   _%$%e2353024866%_
                   _%$%hd2353124870%_
                   _%$%tl2353224873%_
                   _%__splice3885938860%_
                   _%$%target2353324876%_
                   _%$%tl2353524879%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%__match3896738968%_
                                                   _%$%e2352724856%_
                                                   _%$%hd2352824860%_
                                                   _%$%tl2352924863%_
                                                   _%$%e2353024866%_
                                                   _%$%hd2353124870%_
                                                   _%$%tl2353224873%_
                                                   _%__splice3885938860%_
                                                   _%$%target2353324876%_
                                                   _%$%tl2353524879%_))))
                                          (_%__match3896738968%_
                                           _%$%e2352724856%_
                                           _%$%hd2352824860%_
                                           _%$%tl2352924863%_
                                           _%$%e2353024866%_
                                           _%$%hd2353124870%_
                                           _%$%tl2353224873%_
                                           _%__splice3885938860%_
                                           _%$%target2353324876%_
                                           _%$%tl2353524879%_)))))))
                      (_%$%loop2354824920%_ _%$%target2354524914%_ '()))
                    (_%__match3896738968%_
                     _%$%e2352724856%_
                     _%$%hd2352824860%_
                     _%$%tl2352924863%_
                     _%$%e2353024866%_
                     _%$%hd2353124870%_
                     _%$%tl2353224873%_
                     _%__splice3885938860%_
                     _%$%target2353324876%_
                     _%$%tl2353524879%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3896738968%_
                                                     _%$%e2352724856%_
                                                     _%$%hd2352824860%_
                                                     _%$%tl2352924863%_
                                                     _%$%e2353024866%_
                                                     _%$%hd2353124870%_
                                                     _%$%tl2353224873%_
                                                     _%__splice3885938860%_
                                                     _%$%target2353324876%_
                                                     _%$%tl2353524879%_))))
                                            (_%__match3896738968%_
                                             _%$%e2352724856%_
                                             _%$%hd2352824860%_
                                             _%$%tl2352924863%_
                                             _%$%e2353024866%_
                                             _%$%hd2353124870%_
                                             _%$%tl2353224873%_
                                             _%__splice3885938860%_
                                             _%$%target2353324876%_
                                             _%$%tl2353524879%_)))))))
                        (_%$%loop2353624882%_ _%$%target2353324876%_ '()))))
                   (_%__match3892738928%_
                    (lambda (_%$%e2345825146%_
                             _%$%hd2345925150%_
                             _%$%tl2346025153%_
                             _%$%e2346125156%_
                             _%$%hd2346225160%_
                             _%$%tl2346325163%_
                             _%__splice3884938850%_
                             _%$%target2346425166%_
                             _%$%tl2346625169%_)
                      (letrec ((_%$%loop2346725172%_
                                (lambda (_%$%hd2346525176%_
                                         _%$%declared2347125179%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2346525176%_))
                                      (let ((_%$%e2346825181%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2346525176%_))))
                                        (let ((_%$%lp-tl2347025188%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2346825181%_)))
                                              (_%$%lp-hd2346925185%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2346825181%_))))
                                          (_%$%loop2346725172%_
                                           _%$%lp-tl2347025188%_
                                           (cons _%$%lp-hd2346925185%_
                                                 _%$%declared2347125179%_))))
                                      (let ((_%$%declared2347225191%_
                                             (reverse _%$%declared2347125179%_)))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2346325163%_))
                                            (let ((_%$%e2347325194%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2346325163%_))))
                                              (let ((_%$%tl2347525201%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2347325194%_)))
                                                    (_%$%hd2347425198%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2347325194%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%hd2347425198%_))
                                                    (let ((_%__splice3885138852%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%hd2347425198%_
                                                              '0))))
                                                      (let ((_%$%tl2347825207%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3885138852%_ '1)))
                    (_%$%target2347625204%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3885138852%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2347825207%_))
                    (letrec ((_%$%loop2347925210%_
                              (lambda (_%$%hd2347725214%_
                                       _%$%lowered2348325217%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%hd2347725214%_))
                                    (let ((_%$%e2348025219%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%hd2347725214%_))))
                                      (let ((_%$%lp-tl2348225226%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2348025219%_)))
                                            (_%$%lp-hd2348125223%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2348025219%_))))
                                        (_%$%loop2347925210%_
                                         _%$%lp-tl2348225226%_
                                         (cons _%$%lp-hd2348125223%_
                                               _%$%lowered2348325217%_))))
                                    (let ((_%$%lowered2348425229%_
                                           (reverse _%$%lowered2348325217%_)))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl2347525201%_))
                                          (let ((_%$%e2348525232%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl2347525201%_))))
                                            (let ((_%$%tl2348725239%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2348525232%_)))
                                                  (_%$%hd2348625236%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2348525232%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%hd2348625236%_))
                                                  (let ((_%$%e2348825242%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%hd2348625236%_))))
                                                    (let ((_%$%tl2349025249%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e2348825242%_)))
                                                          (_%$%hd2348925246%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e2348825242%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#identifier?
                                                             _%$%hd2348925246%_))
                                                          (if (let ((__tmp39118
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/scheme-language[1]#_g39119_|))
                        (declare (not safe))
                        (gx#free-identifier=? __tmp39118 _%$%hd2348925246%_))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2349025249%_))
                          (let ((_%$%e2349125252%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2349025249%_))))
                            (let ((_%$%tl2349325259%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2349125252%_)))
                                  (_%$%hd2349225256%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2349125252%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%tl2349325259%_))
                                  (let ((_%$%e2349425262%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%tl2349325259%_))))
                                    (let ((_%$%tl2349625269%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2349425262%_)))
                                          (_%$%hd2349525266%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2349425262%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair/null?
                                             _%$%hd2349525266%_))
                                          (let ((_%__splice3885338854%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-split-splice->vector
                                                    _%$%hd2349525266%_
                                                    '0))))
                                            (let ((_%$%tl2349925275%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3885338854%_
                                                      '1)))
                                                  (_%$%target2349725272%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3885338854%_
                                                      '0))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2349925275%_))
                                                  (letrec ((_%$%loop2350025278%_
                                                            (lambda (_%$%hd2349825282%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             _%$%column2350425285%_)
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%hd2349825282%_))
                          (let ((_%$%e2350125287%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%hd2349825282%_))))
                            (let ((_%$%lp-tl2350325294%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2350125287%_)))
                                  (_%$%lp-hd2350225291%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2350125287%_))))
                              (_%$%loop2350025278%_
                               _%$%lp-tl2350325294%_
                               (cons _%$%lp-hd2350225291%_
                                     _%$%column2350425285%_))))
                          (let ((_%$%column2350525297%_
                                 (reverse _%$%column2350425285%_)))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair? _%$%tl2349625269%_))
                                (let ((_%$%e2350625300%_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-e _%$%tl2349625269%_))))
                                  (let ((_%$%tl2350825307%_
                                         (let ()
                                           (declare (not safe))
                                           (##cdr _%$%e2350625300%_)))
                                        (_%$%hd2350725304%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%e2350625300%_))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%tl2350825307%_))
                                        (let ((_%$%e2350925310%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%tl2350825307%_))))
                                          (let ((_%$%tl2351125317%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2350925310%_)))
                                                (_%$%hd2351025314%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2350925310%_))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-null?
                                                   _%$%tl2351125317%_))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%tl2348725239%_))
                                                    (let ((_%__splice3885538856%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%tl2348725239%_
                                                              '0))))
                                                      (let ((_%$%tl2351425323%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3885538856%_ '1)))
                    (_%$%target2351225320%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3885538856%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2351425323%_))
                    (letrec ((_%$%loop2351525326%_
                              (lambda (_%$%hd2351325330%_ _%$%rest2351925333%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%hd2351325330%_))
                                    (let ((_%$%e2351625335%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%hd2351325330%_))))
                                      (let ((_%$%lp-tl2351825342%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2351625335%_)))
                                            (_%$%lp-hd2351725339%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2351625335%_))))
                                        (_%$%loop2351525326%_
                                         _%$%lp-tl2351825342%_
                                         (cons _%$%lp-hd2351725339%_
                                               _%$%rest2351925333%_))))
                                    (let ((_%$%rest2352025345%_
                                           (reverse _%$%rest2351925333%_)))
                                      (let ((_%$%g2345125348%_
                                             _%$%rest2352025345%_)
                                            (_%$%g2345225350%_
                                             _%$%hd2351025314%_)
                                            (_%$%g2345325351%_
                                             _%$%hd2350725304%_)
                                            (_%$%g2345425352%_
                                             _%$%column2350525297%_)
                                            (_%$%g2345525353%_
                                             _%$%hd2349225256%_)
                                            (_%$%g2345625354%_
                                             _%$%lowered2348425229%_)
                                            (_%$%g2345725355%_
                                             _%$%declared2347225191%_))
                                        (if (and (let ()
                                                   (declare (not safe))
                                                   (gx#identifier?
                                                    _%$%g2345525353%_))
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#identifier?
                                                    _%$%g2345225350%_))
                                                 (let ((__tmp39120
                                                        (let ((__tmp39121
                                                               (let ((__tmp39122
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (lambda (_%$%g2540225405%_ _%$%g2540325408%_)
                                (cons _%$%g2540225405%_ _%$%g2540325408%_))))
                         (declare (not safe))
                         (foldr__0 __tmp39122 '() _%$%g2345425352%_))))
                  (declare (not safe))
                  (gx#syntax->list __tmp39121))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (declare (not safe))
                                                   (andmap__0
                                                    gx#identifier?
                                                    __tmp39120)))
                                            (_%__kont3884738848%_
                                             _%$%g2345125348%_
                                             _%$%g2345225350%_
                                             _%$%g2345325351%_
                                             _%$%g2345425352%_
                                             _%$%g2345525353%_
                                             _%$%g2345625354%_
                                             _%$%g2345725355%_)
                                            (_%__match3894738948%_
                                             _%$%e2345825146%_
                                             _%$%hd2345925150%_
                                             _%$%tl2346025153%_
                                             _%$%e2346125156%_
                                             _%$%hd2346225160%_
                                             _%$%tl2346325163%_
                                             _%__splice3884938850%_
                                             _%$%target2346425166%_
                                             _%$%tl2346625169%_))))))))
                      (_%$%loop2351525326%_ _%$%target2351225320%_ '()))
                    (_%__match3894738948%_
                     _%$%e2345825146%_
                     _%$%hd2345925150%_
                     _%$%tl2346025153%_
                     _%$%e2346125156%_
                     _%$%hd2346225160%_
                     _%$%tl2346325163%_
                     _%__splice3884938850%_
                     _%$%target2346425166%_
                     _%$%tl2346625169%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3894738948%_
                                                     _%$%e2345825146%_
                                                     _%$%hd2345925150%_
                                                     _%$%tl2346025153%_
                                                     _%$%e2346125156%_
                                                     _%$%hd2346225160%_
                                                     _%$%tl2346325163%_
                                                     _%__splice3884938850%_
                                                     _%$%target2346425166%_
                                                     _%$%tl2346625169%_))
                                                (_%__match3894738948%_
                                                 _%$%e2345825146%_
                                                 _%$%hd2345925150%_
                                                 _%$%tl2346025153%_
                                                 _%$%e2346125156%_
                                                 _%$%hd2346225160%_
                                                 _%$%tl2346325163%_
                                                 _%__splice3884938850%_
                                                 _%$%target2346425166%_
                                                 _%$%tl2346625169%_))))
                                        (_%__match3894738948%_
                                         _%$%e2345825146%_
                                         _%$%hd2345925150%_
                                         _%$%tl2346025153%_
                                         _%$%e2346125156%_
                                         _%$%hd2346225160%_
                                         _%$%tl2346325163%_
                                         _%__splice3884938850%_
                                         _%$%target2346425166%_
                                         _%$%tl2346625169%_))))
                                (_%__match3894738948%_
                                 _%$%e2345825146%_
                                 _%$%hd2345925150%_
                                 _%$%tl2346025153%_
                                 _%$%e2346125156%_
                                 _%$%hd2346225160%_
                                 _%$%tl2346325163%_
                                 _%__splice3884938850%_
                                 _%$%target2346425166%_
                                 _%$%tl2346625169%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%loop2350025278%_
                                                     _%$%target2349725272%_
                                                     '()))
                                                  (_%__match3894738948%_
                                                   _%$%e2345825146%_
                                                   _%$%hd2345925150%_
                                                   _%$%tl2346025153%_
                                                   _%$%e2346125156%_
                                                   _%$%hd2346225160%_
                                                   _%$%tl2346325163%_
                                                   _%__splice3884938850%_
                                                   _%$%target2346425166%_
                                                   _%$%tl2346625169%_))))
                                          (_%__match3894738948%_
                                           _%$%e2345825146%_
                                           _%$%hd2345925150%_
                                           _%$%tl2346025153%_
                                           _%$%e2346125156%_
                                           _%$%hd2346225160%_
                                           _%$%tl2346325163%_
                                           _%__splice3884938850%_
                                           _%$%target2346425166%_
                                           _%$%tl2346625169%_))))
                                  (_%__match3894738948%_
                                   _%$%e2345825146%_
                                   _%$%hd2345925150%_
                                   _%$%tl2346025153%_
                                   _%$%e2346125156%_
                                   _%$%hd2346225160%_
                                   _%$%tl2346325163%_
                                   _%__splice3884938850%_
                                   _%$%target2346425166%_
                                   _%$%tl2346625169%_))))
                          (_%__match3894738948%_
                           _%$%e2345825146%_
                           _%$%hd2345925150%_
                           _%$%tl2346025153%_
                           _%$%e2346125156%_
                           _%$%hd2346225160%_
                           _%$%tl2346325163%_
                           _%__splice3884938850%_
                           _%$%target2346425166%_
                           _%$%tl2346625169%_))
                      (_%__match3894738948%_
                       _%$%e2345825146%_
                       _%$%hd2345925150%_
                       _%$%tl2346025153%_
                       _%$%e2346125156%_
                       _%$%hd2346225160%_
                       _%$%tl2346325163%_
                       _%__splice3884938850%_
                       _%$%target2346425166%_
                       _%$%tl2346625169%_))
                  (_%__match3894738948%_
                   _%$%e2345825146%_
                   _%$%hd2345925150%_
                   _%$%tl2346025153%_
                   _%$%e2346125156%_
                   _%$%hd2346225160%_
                   _%$%tl2346325163%_
                   _%__splice3884938850%_
                   _%$%target2346425166%_
                   _%$%tl2346625169%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%__match3894738948%_
                                                   _%$%e2345825146%_
                                                   _%$%hd2345925150%_
                                                   _%$%tl2346025153%_
                                                   _%$%e2346125156%_
                                                   _%$%hd2346225160%_
                                                   _%$%tl2346325163%_
                                                   _%__splice3884938850%_
                                                   _%$%target2346425166%_
                                                   _%$%tl2346625169%_))))
                                          (_%__match3894738948%_
                                           _%$%e2345825146%_
                                           _%$%hd2345925150%_
                                           _%$%tl2346025153%_
                                           _%$%e2346125156%_
                                           _%$%hd2346225160%_
                                           _%$%tl2346325163%_
                                           _%__splice3884938850%_
                                           _%$%target2346425166%_
                                           _%$%tl2346625169%_)))))))
                      (_%$%loop2347925210%_ _%$%target2347625204%_ '()))
                    (_%__match3894738948%_
                     _%$%e2345825146%_
                     _%$%hd2345925150%_
                     _%$%tl2346025153%_
                     _%$%e2346125156%_
                     _%$%hd2346225160%_
                     _%$%tl2346325163%_
                     _%__splice3884938850%_
                     _%$%target2346425166%_
                     _%$%tl2346625169%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3894738948%_
                                                     _%$%e2345825146%_
                                                     _%$%hd2345925150%_
                                                     _%$%tl2346025153%_
                                                     _%$%e2346125156%_
                                                     _%$%hd2346225160%_
                                                     _%$%tl2346325163%_
                                                     _%__splice3884938850%_
                                                     _%$%target2346425166%_
                                                     _%$%tl2346625169%_))))
                                            (_%__match3894738948%_
                                             _%$%e2345825146%_
                                             _%$%hd2345925150%_
                                             _%$%tl2346025153%_
                                             _%$%e2346125156%_
                                             _%$%hd2346225160%_
                                             _%$%tl2346325163%_
                                             _%__splice3884938850%_
                                             _%$%target2346425166%_
                                             _%$%tl2346625169%_)))))))
                        (_%$%loop2346725172%_ _%$%target2346425166%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3884438845%_))
                  (let ((_%$%e2345825146%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3884438845%_))))
                    (let ((_%$%tl2346025153%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2345825146%_)))
                          (_%$%hd2345925150%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2345825146%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2346025153%_))
                          (let ((_%$%e2346125156%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2346025153%_))))
                            (let ((_%$%tl2346325163%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2346125156%_)))
                                  (_%$%hd2346225160%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2346125156%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair/null? _%$%hd2346225160%_))
                                  (let ((_%__splice3884938850%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-split-splice->vector
                                            _%$%hd2346225160%_
                                            '0))))
                                    (let ((_%$%tl2346625169%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-ref
                                              _%__splice3884938850%_
                                              '1)))
                                          (_%$%target2346425166%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-ref
                                              _%__splice3884938850%_
                                              '0))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-null? _%$%tl2346625169%_))
                                          (_%__match3892738928%_
                                           _%$%e2345825146%_
                                           _%$%hd2345925150%_
                                           _%$%tl2346025153%_
                                           _%$%e2346125156%_
                                           _%$%hd2346225160%_
                                           _%$%tl2346325163%_
                                           _%__splice3884938850%_
                                           _%$%target2346425166%_
                                           _%$%tl2346625169%_)
                                          (let ()
                                            (declare (not safe))
                                            (_%$%g2344923832%_)))))
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g2344923832%_)))))
                          (let () (declare (not safe)) (_%$%g2344923832%_)))))
                  (let () (declare (not safe)) (_%$%g2344923832%_))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-program|
      (lambda (_%stx25470%_)
        (let* ((_%$%g2547325493%_
                (lambda (_%$%g2547425489%_)
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%$%g2547425489%_))))
               (_%$%g2547225562%_
                (lambda (_%$%g2547425497%_)
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-pair? _%$%g2547425497%_))
                      (let ((_%$%e2547625500%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-e _%$%g2547425497%_))))
                        (let ((_%$%hd2547725504%_
                               (let ()
                                 (declare (not safe))
                                 (##car _%$%e2547625500%_)))
                              (_%$%tl2547825507%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%$%e2547625500%_))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair/null? _%$%tl2547825507%_))
                              (let ((_g39123_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-split-splice
                                        _%$%tl2547825507%_
                                        '0))))
                                (begin
                                  (let ((_g39124_
                                         (let ()
                                           (declare (not safe))
                                           (if (##values? _g39123_)
                                               (##values-length _g39123_)
                                               1))))
                                    (if (not (let ()
                                               (declare (not safe))
                                               (##fx= _g39124_ 2)))
                                        (error "Context expects 2 values"
                                               _g39124_)))
                                  (let ((_%$%target2547925510%_
                                         (let ()
                                           (declare (not safe))
                                           (##values-ref _g39123_ 0)))
                                        (_%$%tl2548125513%_
                                         (let ()
                                           (declare (not safe))
                                           (##values-ref _g39123_ 1))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2548125513%_))
                                        (letrec ((_%$%loop2548225516%_
                                                  (lambda (_%$%hd2548025520%_
                                                           _%$%clause2548625523%_)
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-pair?
                                                           _%$%hd2548025520%_))
                                                        (let ((_%$%e2548325525%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#syntax-e _%$%hd2548025520%_))))
                  (let ((_%$%lp-hd2548425529%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%e2548325525%_)))
                        (_%$%lp-tl2548525532%_
                         (let ()
                           (declare (not safe))
                           (##cdr _%$%e2548325525%_))))
                    (_%$%loop2548225516%_
                     _%$%lp-tl2548525532%_
                     (cons _%$%lp-hd2548425529%_ _%$%clause2548625523%_))))
                (let ((_%$%clause2548725535%_
                       (reverse _%$%clause2548625523%_)))
                  (cons (let ()
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'relational-collect))
                        (cons '()
                              (cons '()
                                    (let ((__tmp39125
                                           (lambda (_%$%g2555325556%_
                                                    _%$%g2555425559%_)
                                             (cons _%$%g2555325556%_
                                                   _%$%g2555425559%_))))
                                      (declare (not safe))
                                      (foldr__0
                                       __tmp39125
                                       '()
                                       _%$%clause2548725535%_))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                          (_%$%loop2548225516%_
                                           _%$%target2547925510%_
                                           '()))
                                        (_%$%g2547325493%_
                                         _%$%g2547425497%_)))))
                              (_%$%g2547325493%_ _%$%g2547425497%_))))
                      (_%$%g2547325493%_ _%$%g2547425497%_)))))
          (_%$%g2547225562%_ _%stx25470%_))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-fragment|
      (lambda (_%$stx25567%_)
        (let* ((_%$%g2557125765%_
                (lambda (_%$%g2557225761%_)
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%$%g2557225761%_))))
               (_%$%g2557026499%_
                (lambda (_%$%g2557225769%_)
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-pair? _%$%g2557225769%_))
                      (let ((_%$%e2558625772%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-e _%$%g2557225769%_))))
                        (let ((_%$%hd2558725776%_
                               (let ()
                                 (declare (not safe))
                                 (##car _%$%e2558625772%_)))
                              (_%$%tl2558825779%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%$%e2558625772%_))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair? _%$%tl2558825779%_))
                              (let ((_%$%e2558925782%_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-e _%$%tl2558825779%_))))
                                (let ((_%$%hd2559025786%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%$%e2558925782%_)))
                                      (_%$%tl2559125789%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%e2558925782%_))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2559025786%_))
                                      (let ((_%$%e2559225792%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2559025786%_))))
                                        (let ((_%$%hd2559325796%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2559225792%_)))
                                              (_%$%tl2559425799%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2559225792%_))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#identifier?
                                                 _%$%hd2559325796%_))
                                              (if (let ((__tmp39126
                                                         |gerbil-ascent/program/scheme-language[1]#_g39127_|))
                                                    (declare (not safe))
                                                    (gx#free-identifier=?
                                                     __tmp39126
                                                     _%$%hd2559325796%_))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair/null?
                                                         _%$%tl2559425799%_))
                                                      (let ((_g39128_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-split-splice _%$%tl2559425799%_ '0))))
                (begin
                  (let ((_g39129_
                         (let ()
                           (declare (not safe))
                           (if (##values? _g39128_)
                               (##values-length _g39128_)
                               1))))
                    (if (not (let () (declare (not safe)) (##fx= _g39129_ 2)))
                        (error "Context expects 2 values" _g39129_)))
                  (let ((_%$%target2559525802%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g39128_ 0)))
                        (_%$%tl2559725805%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g39128_ 1))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2559725805%_))
                        (letrec ((_%$%loop2559825808%_
                                  (lambda (_%$%hd2559625812%_
                                           _%$%imported-handle2560225815%_
                                           _%$%import-name2560325816%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%hd2559625812%_))
                                        (let ((_%$%e2559925818%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%hd2559625812%_))))
                                          (let ((_%$%lp-hd2560025822%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2559925818%_)))
                                                (_%$%lp-tl2560125825%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2559925818%_))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair?
                                                   _%$%lp-hd2560025822%_))
                                                (let ((_%$%e2560625828%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-e
                                                          _%$%lp-hd2560025822%_))))
                                                  (let ((_%$%hd2560725832%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e2560625828%_)))
                                                        (_%$%tl2560825835%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e2560625828%_))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-pair?
                                                           _%$%tl2560825835%_))
                                                        (let ((_%$%e2560925838%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#syntax-e _%$%tl2560825835%_))))
                  (let ((_%$%hd2561025842%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%e2560925838%_)))
                        (_%$%tl2561125845%_
                         (let ()
                           (declare (not safe))
                           (##cdr _%$%e2560925838%_))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2561125845%_))
                        (_%$%loop2559825808%_
                         _%$%lp-tl2560125825%_
                         (cons _%$%hd2561025842%_
                               _%$%imported-handle2560225815%_)
                         (cons _%$%hd2560725832%_ _%$%import-name2560325816%_))
                        (_%$%g2557125765%_ _%$%g2557225769%_))))
                (_%$%g2557125765%_ _%$%g2557225769%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (_%$%g2557125765%_
                                                 _%$%g2557225769%_))))
                                        (let ((_%$%imported-handle2560425848%_
                                               (reverse _%$%imported-handle2560225815%_))
                                              (_%$%import-name2560525850%_
                                               (reverse _%$%import-name2560325816%_)))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair?
                                                 _%$%tl2559125789%_))
                                              (let ((_%$%e2561225852%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-e
                                                        _%$%tl2559125789%_))))
                                                (let ((_%$%hd2561325856%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##car _%$%e2561225852%_)))
                                                      (_%$%tl2561425859%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##cdr _%$%e2561225852%_))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair?
                                                         _%$%hd2561325856%_))
                                                      (let ((_%$%e2561525862%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-e _%$%hd2561325856%_))))
                (let ((_%$%hd2561625866%_
                       (let () (declare (not safe)) (##car _%$%e2561525862%_)))
                      (_%$%tl2561725869%_
                       (let ()
                         (declare (not safe))
                         (##cdr _%$%e2561525862%_))))
                  (if (let ()
                        (declare (not safe))
                        (gx#identifier? _%$%hd2561625866%_))
                      (if (let ((__tmp39130
                                 |gerbil-ascent/program/scheme-language[1]#_g39131_|))
                            (declare (not safe))
                            (gx#free-identifier=?
                             __tmp39130
                             _%$%hd2561625866%_))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair/null? _%$%tl2561725869%_))
                              (let ((_g39132_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-split-splice
                                        _%$%tl2561725869%_
                                        '0))))
                                (begin
                                  (let ((_g39133_
                                         (let ()
                                           (declare (not safe))
                                           (if (##values? _g39132_)
                                               (##values-length _g39132_)
                                               1))))
                                    (if (not (let ()
                                               (declare (not safe))
                                               (##fx= _g39133_ 2)))
                                        (error "Context expects 2 values"
                                               _g39133_)))
                                  (let ((_%$%target2561825872%_
                                         (let ()
                                           (declare (not safe))
                                           (##values-ref _g39132_ 0)))
                                        (_%$%tl2562025875%_
                                         (let ()
                                           (declare (not safe))
                                           (##values-ref _g39132_ 1))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2562025875%_))
                                        (letrec ((_%$%loop2562125878%_
                                                  (lambda (_%$%hd2561925882%_
                                                           _%$%source-rows2562525885%_
                                                           _%$%source-column2562625886%_
                                                           _%$%source-name2562725887%_)
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-pair?
                                                           _%$%hd2561925882%_))
                                                        (let ((_%$%e2562225889%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#syntax-e _%$%hd2561925882%_))))
                  (let ((_%$%lp-hd2562325893%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%e2562225889%_)))
                        (_%$%lp-tl2562425896%_
                         (let ()
                           (declare (not safe))
                           (##cdr _%$%e2562225889%_))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-pair? _%$%lp-hd2562325893%_))
                        (let ((_%$%e2563125899%_
                               (let ()
                                 (declare (not safe))
                                 (gx#syntax-e _%$%lp-hd2562325893%_))))
                          (let ((_%$%hd2563225903%_
                                 (let ()
                                   (declare (not safe))
                                   (##car _%$%e2563125899%_)))
                                (_%$%tl2563325906%_
                                 (let ()
                                   (declare (not safe))
                                   (##cdr _%$%e2563125899%_))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair? _%$%tl2563325906%_))
                                (let ((_%$%e2563425909%_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-e _%$%tl2563325906%_))))
                                  (let ((_%$%hd2563525913%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%e2563425909%_)))
                                        (_%$%tl2563625916%_
                                         (let ()
                                           (declare (not safe))
                                           (##cdr _%$%e2563425909%_))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair/null?
                                           _%$%hd2563525913%_))
                                        (let ((_g39134_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-split-splice
                                                  _%$%hd2563525913%_
                                                  '0))))
                                          (begin
                                            (let ((_g39135_
                                                   (let ()
                                                     (declare (not safe))
                                                     (if (##values? _g39134_)
                                                         (##values-length
                                                          _g39134_)
                                                         1))))
                                              (if (not (let ()
                                                         (declare (not safe))
                                                         (##fx= _g39135_ 2)))
                                                  (error "Context expects 2 values"
                                                         _g39135_)))
                                            (let ((_%$%target2563725919%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##values-ref
                                                      _g39134_
                                                      0)))
                                                  (_%$%tl2563925922%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##values-ref
                                                      _g39134_
                                                      1))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2563925922%_))
                                                  (letrec ((_%$%loop2564025925%_
                                                            (lambda (_%$%hd2563825929%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             _%$%source-column2564425932%_)
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%hd2563825929%_))
                          (let ((_%$%e2564125934%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%hd2563825929%_))))
                            (let ((_%$%lp-hd2564225938%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2564125934%_)))
                                  (_%$%lp-tl2564325941%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2564125934%_))))
                              (_%$%loop2564025925%_
                               _%$%lp-tl2564325941%_
                               (cons _%$%lp-hd2564225938%_
                                     _%$%source-column2564425932%_))))
                          (let ((_%$%source-column2564525944%_
                                 (reverse _%$%source-column2564425932%_)))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair? _%$%tl2563625916%_))
                                (let ((_%$%e2564625947%_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-e _%$%tl2563625916%_))))
                                  (let ((_%$%hd2564725951%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%e2564625947%_)))
                                        (_%$%tl2564825954%_
                                         (let ()
                                           (declare (not safe))
                                           (##cdr _%$%e2564625947%_))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2564825954%_))
                                        (_%$%loop2562125878%_
                                         _%$%lp-tl2562425896%_
                                         (cons _%$%hd2564725951%_
                                               _%$%source-rows2562525885%_)
                                         (cons _%$%source-column2564525944%_
                                               _%$%source-column2562625886%_)
                                         (cons _%$%hd2563225903%_
                                               _%$%source-name2562725887%_))
                                        (_%$%g2557125765%_
                                         _%$%g2557225769%_))))
                                (_%$%g2557125765%_ _%$%g2557225769%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%loop2564025925%_
                                                     _%$%target2563725919%_
                                                     '()))
                                                  (_%$%g2557125765%_
                                                   _%$%g2557225769%_)))))
                                        (_%$%g2557125765%_
                                         _%$%g2557225769%_))))
                                (_%$%g2557125765%_ _%$%g2557225769%_))))
                        (_%$%g2557125765%_ _%$%g2557225769%_))))
                (let ((_%$%source-rows2562825957%_
                       (reverse _%$%source-rows2562525885%_))
                      (_%$%source-column2562925959%_
                       (reverse _%$%source-column2562625886%_))
                      (_%$%source-name2563025960%_
                       (reverse _%$%source-name2562725887%_)))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-pair? _%$%tl2561425859%_))
                      (let ((_%$%e2564925962%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-e _%$%tl2561425859%_))))
                        (let ((_%$%hd2565025966%_
                               (let ()
                                 (declare (not safe))
                                 (##car _%$%e2564925962%_)))
                              (_%$%tl2565125969%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%$%e2564925962%_))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair? _%$%hd2565025966%_))
                              (let ((_%$%e2565225972%_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-e _%$%hd2565025966%_))))
                                (let ((_%$%hd2565325976%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%$%e2565225972%_)))
                                      (_%$%tl2565425979%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%e2565225972%_))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#identifier? _%$%hd2565325976%_))
                                      (if (let ((__tmp39136
                                                 |gerbil-ascent/program/scheme-language[1]#_g39137_|))
                                            (declare (not safe))
                                            (gx#free-identifier=?
                                             __tmp39136
                                             _%$%hd2565325976%_))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair/null?
                                                 _%$%tl2565425979%_))
                                              (let ((_g39138_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-split-splice
                                                        _%$%tl2565425979%_
                                                        '0))))
                                                (begin
                                                  (let ((_g39139_
                                                         (let ()
                                                           (declare (not safe))
                                                           (if (##values?
                                                                _g39138_)
                                                               (##values-length
                                                                _g39138_)
                                                               1))))
                                                    (if (not (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##fx= _g39139_ 2)))
                (error "Context expects 2 values" _g39139_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (let ((_%$%target2565525982%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##values-ref
                                                            _g39138_
                                                            0)))
                                                        (_%$%tl2565725985%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##values-ref
                                                            _g39138_
                                                            1))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl2565725985%_))
                                                        (letrec ((_%$%loop2565825988%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (lambda (_%$%hd2565625992%_
                                   _%$%private-column2566225995%_
                                   _%$%private-name2566325996%_)
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair? _%$%hd2565625992%_))
                                (let ((_%$%e2565925998%_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-e _%$%hd2565625992%_))))
                                  (let ((_%$%lp-hd2566026002%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%e2565925998%_)))
                                        (_%$%lp-tl2566126005%_
                                         (let ()
                                           (declare (not safe))
                                           (##cdr _%$%e2565925998%_))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%lp-hd2566026002%_))
                                        (let ((_%$%e2566626008%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%lp-hd2566026002%_))))
                                          (let ((_%$%hd2566726012%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2566626008%_)))
                                                (_%$%tl2566826015%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2566626008%_))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair?
                                                   _%$%tl2566826015%_))
                                                (let ((_%$%e2566926018%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-e
                                                          _%$%tl2566826015%_))))
                                                  (let ((_%$%hd2567026022%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e2566926018%_)))
                                                        (_%$%tl2567126025%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e2566926018%_))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-pair/null?
                                                           _%$%hd2567026022%_))
                                                        (let ((_g39140_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#syntax-split-splice _%$%hd2567026022%_ '0))))
                  (begin
                    (let ((_g39141_
                           (let ()
                             (declare (not safe))
                             (if (##values? _g39140_)
                                 (##values-length _g39140_)
                                 1))))
                      (if (not (let ()
                                 (declare (not safe))
                                 (##fx= _g39141_ 2)))
                          (error "Context expects 2 values" _g39141_)))
                    (let ((_%$%target2567226028%_
                           (let ()
                             (declare (not safe))
                             (##values-ref _g39140_ 0)))
                          (_%$%tl2567426031%_
                           (let ()
                             (declare (not safe))
                             (##values-ref _g39140_ 1))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-null? _%$%tl2567426031%_))
                          (letrec ((_%$%loop2567526034%_
                                    (lambda (_%$%hd2567326038%_
                                             _%$%private-column2567926041%_)
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%hd2567326038%_))
                                          (let ((_%$%e2567626043%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%hd2567326038%_))))
                                            (let ((_%$%lp-hd2567726047%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2567626043%_)))
                                                  (_%$%lp-tl2567826050%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2567626043%_))))
                                              (_%$%loop2567526034%_
                                               _%$%lp-tl2567826050%_
                                               (cons _%$%lp-hd2567726047%_
                                                     _%$%private-column2567926041%_))))
                                          (let ((_%$%private-column2568026053%_
                                                 (reverse _%$%private-column2567926041%_)))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-null?
                                                   _%$%tl2567126025%_))
                                                (_%$%loop2565825988%_
                                                 _%$%lp-tl2566126005%_
                                                 (cons _%$%private-column2568026053%_
                                                       _%$%private-column2566225995%_)
                                                 (cons _%$%hd2566726012%_
                                                       _%$%private-name2566325996%_))
                                                (_%$%g2557125765%_
                                                 _%$%g2557225769%_)))))))
                            (_%$%loop2567526034%_ _%$%target2567226028%_ '()))
                          (_%$%g2557125765%_ _%$%g2557225769%_)))))
                (_%$%g2557125765%_ _%$%g2557225769%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (_%$%g2557125765%_
                                                 _%$%g2557225769%_))))
                                        (_%$%g2557125765%_
                                         _%$%g2557225769%_))))
                                (let ((_%$%private-column2566426056%_
                                       (reverse _%$%private-column2566225995%_))
                                      (_%$%private-name2566526058%_
                                       (reverse _%$%private-name2566325996%_)))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%tl2565125969%_))
                                      (let ((_%$%e2568126060%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%tl2565125969%_))))
                                        (let ((_%$%hd2568226064%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2568126060%_)))
                                              (_%$%tl2568326067%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2568126060%_))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair?
                                                 _%$%hd2568226064%_))
                                              (let ((_%$%e2568426070%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-e
                                                        _%$%hd2568226064%_))))
                                                (let ((_%$%hd2568526074%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##car _%$%e2568426070%_)))
                                                      (_%$%tl2568626077%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##cdr _%$%e2568426070%_))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#identifier?
                                                         _%$%hd2568526074%_))
                                                      (if (let ((__tmp39142
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         |gerbil-ascent/program/scheme-language[1]#_g39143_|))
                    (declare (not safe))
                    (gx#free-identifier=? __tmp39142 _%$%hd2568526074%_))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-pair/null? _%$%tl2568626077%_))
                      (let ((_g39144_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-split-splice
                                _%$%tl2568626077%_
                                '0))))
                        (begin
                          (let ((_g39145_
                                 (let ()
                                   (declare (not safe))
                                   (if (##values? _g39144_)
                                       (##values-length _g39144_)
                                       1))))
                            (if (not (let ()
                                       (declare (not safe))
                                       (##fx= _g39145_ 2)))
                                (error "Context expects 2 values" _g39145_)))
                          (let ((_%$%target2568726080%_
                                 (let ()
                                   (declare (not safe))
                                   (##values-ref _g39144_ 0)))
                                (_%$%tl2568926083%_
                                 (let ()
                                   (declare (not safe))
                                   (##values-ref _g39144_ 1))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2568926083%_))
                                (letrec ((_%$%loop2569026086%_
                                          (lambda (_%$%hd2568826090%_
                                                   _%$%exported-name2569426093%_
                                                   _%$%public-name2569526094%_)
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair?
                                                   _%$%hd2568826090%_))
                                                (let ((_%$%e2569126096%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-e
                                                          _%$%hd2568826090%_))))
                                                  (let ((_%$%lp-hd2569226100%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e2569126096%_)))
                                                        (_%$%lp-tl2569326103%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e2569126096%_))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-pair?
                                                           _%$%lp-hd2569226100%_))
                                                        (let ((_%$%e2569826106%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#syntax-e _%$%lp-hd2569226100%_))))
                  (let ((_%$%hd2569926110%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%e2569826106%_)))
                        (_%$%tl2570026113%_
                         (let ()
                           (declare (not safe))
                           (##cdr _%$%e2569826106%_))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-pair? _%$%tl2570026113%_))
                        (let ((_%$%e2570126116%_
                               (let ()
                                 (declare (not safe))
                                 (gx#syntax-e _%$%tl2570026113%_))))
                          (let ((_%$%hd2570226120%_
                                 (let ()
                                   (declare (not safe))
                                   (##car _%$%e2570126116%_)))
                                (_%$%tl2570326123%_
                                 (let ()
                                   (declare (not safe))
                                   (##cdr _%$%e2570126116%_))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2570326123%_))
                                (_%$%loop2569026086%_
                                 _%$%lp-tl2569326103%_
                                 (cons _%$%hd2570226120%_
                                       _%$%exported-name2569426093%_)
                                 (cons _%$%hd2569926110%_
                                       _%$%public-name2569526094%_))
                                (_%$%g2557125765%_ _%$%g2557225769%_))))
                        (_%$%g2557125765%_ _%$%g2557225769%_))))
                (_%$%g2557125765%_ _%$%g2557225769%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (let ((_%$%exported-name2569626126%_
                                                       (reverse _%$%exported-name2569426093%_))
                                                      (_%$%public-name2569726128%_
                                                       (reverse _%$%public-name2569526094%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair/null?
                                                         _%$%tl2568326067%_))
                                                      (let ((_g39146_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-split-splice _%$%tl2568326067%_ '0))))
                (begin
                  (let ((_g39147_
                         (let ()
                           (declare (not safe))
                           (if (##values? _g39146_)
                               (##values-length _g39146_)
                               1))))
                    (if (not (let () (declare (not safe)) (##fx= _g39147_ 2)))
                        (error "Context expects 2 values" _g39147_)))
                  (let ((_%$%target2570426130%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g39146_ 0)))
                        (_%$%tl2570626133%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g39146_ 1))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2570626133%_))
                        (letrec ((_%$%loop2570726136%_
                                  (lambda (_%$%hd2570526140%_
                                           _%$%body-term2571126143%_
                                           _%$%body2571226144%_
                                           _%$%head-term2571326145%_
                                           _%$%head2571426146%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%hd2570526140%_))
                                        (let ((_%$%e2570826148%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%hd2570526140%_))))
                                          (let ((_%$%lp-hd2570926152%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2570826148%_)))
                                                (_%$%lp-tl2571026155%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2570826148%_))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair?
                                                   _%$%lp-hd2570926152%_))
                                                (let ((_%$%e2571926158%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-e
                                                          _%$%lp-hd2570926152%_))))
                                                  (let ((_%$%hd2572026162%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e2571926158%_)))
                                                        (_%$%tl2572126165%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e2571926158%_))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#identifier?
                                                           _%$%hd2572026162%_))
                                                        (if (let ((__tmp39148
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/program/scheme-language[1]#_g39149_|))
                      (declare (not safe))
                      (gx#free-identifier=? __tmp39148 _%$%hd2572026162%_))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-pair? _%$%tl2572126165%_))
                        (let ((_%$%e2572226168%_
                               (let ()
                                 (declare (not safe))
                                 (gx#syntax-e _%$%tl2572126165%_))))
                          (let ((_%$%hd2572326172%_
                                 (let ()
                                   (declare (not safe))
                                   (##car _%$%e2572226168%_)))
                                (_%$%tl2572426175%_
                                 (let ()
                                   (declare (not safe))
                                   (##cdr _%$%e2572226168%_))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair? _%$%hd2572326172%_))
                                (let ((_%$%e2572526178%_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-e _%$%hd2572326172%_))))
                                  (let ((_%$%hd2572626182%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%e2572526178%_)))
                                        (_%$%tl2572726185%_
                                         (let ()
                                           (declare (not safe))
                                           (##cdr _%$%e2572526178%_))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair/null?
                                           _%$%tl2572726185%_))
                                        (let ((_g39150_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-split-splice
                                                  _%$%tl2572726185%_
                                                  '0))))
                                          (begin
                                            (let ((_g39151_
                                                   (let ()
                                                     (declare (not safe))
                                                     (if (##values? _g39150_)
                                                         (##values-length
                                                          _g39150_)
                                                         1))))
                                              (if (not (let ()
                                                         (declare (not safe))
                                                         (##fx= _g39151_ 2)))
                                                  (error "Context expects 2 values"
                                                         _g39151_)))
                                            (let ((_%$%target2572826188%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##values-ref
                                                      _g39150_
                                                      0)))
                                                  (_%$%tl2573026191%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##values-ref
                                                      _g39150_
                                                      1))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2573026191%_))
                                                  (letrec ((_%$%loop2573126194%_
                                                            (lambda (_%$%hd2572926198%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             _%$%head-term2573526201%_)
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%hd2572926198%_))
                          (let ((_%$%e2573226203%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%hd2572926198%_))))
                            (let ((_%$%lp-hd2573326207%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2573226203%_)))
                                  (_%$%lp-tl2573426210%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2573226203%_))))
                              (_%$%loop2573126194%_
                               _%$%lp-tl2573426210%_
                               (cons _%$%lp-hd2573326207%_
                                     _%$%head-term2573526201%_))))
                          (let ((_%$%head-term2573626213%_
                                 (reverse _%$%head-term2573526201%_)))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair/null? _%$%tl2572426175%_))
                                (let ((_g39152_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-split-splice
                                          _%$%tl2572426175%_
                                          '0))))
                                  (begin
                                    (let ((_g39153_
                                           (let ()
                                             (declare (not safe))
                                             (if (##values? _g39152_)
                                                 (##values-length _g39152_)
                                                 1))))
                                      (if (not (let ()
                                                 (declare (not safe))
                                                 (##fx= _g39153_ 2)))
                                          (error "Context expects 2 values"
                                                 _g39153_)))
                                    (let ((_%$%target2573726216%_
                                           (let ()
                                             (declare (not safe))
                                             (##values-ref _g39152_ 0)))
                                          (_%$%tl2573926219%_
                                           (let ()
                                             (declare (not safe))
                                             (##values-ref _g39152_ 1))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-null? _%$%tl2573926219%_))
                                          (letrec ((_%$%loop2574026222%_
                                                    (lambda (_%$%hd2573826226%_
                                                             _%$%body-term2574426229%_
                                                             _%$%body2574526230%_)
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-pair?
                                                             _%$%hd2573826226%_))
                                                          (let ((_%$%e2574126232%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%$%hd2573826226%_))))
                    (let ((_%$%lp-hd2574226236%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2574126232%_)))
                          (_%$%lp-tl2574326239%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2574126232%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%lp-hd2574226236%_))
                          (let ((_%$%e2574826242%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%lp-hd2574226236%_))))
                            (let ((_%$%hd2574926246%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2574826242%_)))
                                  (_%$%tl2575026249%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2574826242%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair/null? _%$%tl2575026249%_))
                                  (let ((_g39154_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-split-splice
                                            _%$%tl2575026249%_
                                            '0))))
                                    (begin
                                      (let ((_g39155_
                                             (let ()
                                               (declare (not safe))
                                               (if (##values? _g39154_)
                                                   (##values-length _g39154_)
                                                   1))))
                                        (if (not (let ()
                                                   (declare (not safe))
                                                   (##fx= _g39155_ 2)))
                                            (error "Context expects 2 values"
                                                   _g39155_)))
                                      (let ((_%$%target2575126252%_
                                             (let ()
                                               (declare (not safe))
                                               (##values-ref _g39154_ 0)))
                                            (_%$%tl2575326255%_
                                             (let ()
                                               (declare (not safe))
                                               (##values-ref _g39154_ 1))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-null?
                                               _%$%tl2575326255%_))
                                            (letrec ((_%$%loop2575426258%_
                                                      (lambda (_%$%hd2575226262%_
                                                               _%$%body-term2575826265%_)
                                                        (if (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#stx-pair?
                                                               _%$%hd2575226262%_))
                                                            (let ((_%$%e2575526267%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%$%hd2575226262%_))))
                      (let ((_%$%lp-hd2575626271%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e2575526267%_)))
                            (_%$%lp-tl2575726274%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e2575526267%_))))
                        (_%$%loop2575426258%_
                         _%$%lp-tl2575726274%_
                         (cons _%$%lp-hd2575626271%_
                               _%$%body-term2575826265%_))))
                    (let ((_%$%body-term2575926277%_
                           (reverse _%$%body-term2575826265%_)))
                      (_%$%loop2574026222%_
                       _%$%lp-tl2574326239%_
                       (cons _%$%body-term2575926277%_
                             _%$%body-term2574426229%_)
                       (cons _%$%hd2574926246%_ _%$%body2574526230%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%$%loop2575426258%_
                                               _%$%target2575126252%_
                                               '()))
                                            (_%$%g2557125765%_
                                             _%$%g2557225769%_)))))
                                  (_%$%g2557125765%_ _%$%g2557225769%_))))
                          (_%$%g2557125765%_ _%$%g2557225769%_))))
                  (let ((_%$%body-term2574626280%_
                         (reverse _%$%body-term2574426229%_))
                        (_%$%body2574726282%_ (reverse _%$%body2574526230%_)))
                    (_%$%loop2570726136%_
                     _%$%lp-tl2571026155%_
                     (cons _%$%body-term2574626280%_ _%$%body-term2571126143%_)
                     (cons _%$%body2574726282%_ _%$%body2571226144%_)
                     (cons _%$%head-term2573626213%_ _%$%head-term2571326145%_)
                     (cons _%$%hd2572626182%_ _%$%head2571426146%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (_%$%loop2574026222%_
                                             _%$%target2573726216%_
                                             '()
                                             '()))
                                          (_%$%g2557125765%_
                                           _%$%g2557225769%_)))))
                                (_%$%g2557125765%_ _%$%g2557225769%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%loop2573126194%_
                                                     _%$%target2572826188%_
                                                     '()))
                                                  (_%$%g2557125765%_
                                                   _%$%g2557225769%_)))))
                                        (_%$%g2557125765%_
                                         _%$%g2557225769%_))))
                                (_%$%g2557125765%_ _%$%g2557225769%_))))
                        (_%$%g2557125765%_ _%$%g2557225769%_))
                    (_%$%g2557125765%_ _%$%g2557225769%_))
                (_%$%g2557125765%_ _%$%g2557225769%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (_%$%g2557125765%_
                                                 _%$%g2557225769%_))))
                                        (let ((_%$%body-term2571526284%_
                                               (reverse _%$%body-term2571126143%_))
                                              (_%$%body2571626286%_
                                               (reverse _%$%body2571226144%_))
                                              (_%$%head-term2571726287%_
                                               (reverse _%$%head-term2571326145%_))
                                              (_%$%head2571826288%_
                                               (reverse _%$%head2571426146%_)))
                                          (cons (let ()
                                                  (declare (not safe))
                                                  (gx#datum->syntax__0
                                                   '#f
                                                   'let))
                                                (cons (begin
                                                        (let ()
                                                          (declare (not safe))
                                                          (gx#syntax-check-splice-targets
                                                           _%$%imported-handle2560425848%_
                                                           _%$%import-name2560525850%_))
                                                        (let ((__tmp39160
                                                               (lambda (_%$%g2636126399%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                _%$%g2636226402%_
                                _%$%g2636326404%_)
                         (cons (cons _%$%g2636226402%_
                                     (cons _%$%g2636126399%_ '()))
                               _%$%g2636326404%_)))
                      (__tmp39156
                       (begin
                         (let ()
                           (declare (not safe))
                           (gx#syntax-check-splice-targets
                            _%$%source-name2563025960%_
                            _%$%source-name2563025960%_))
                         (let ((__tmp39159
                                (lambda (_%$%g2636426407%_
                                         _%$%g2636526410%_
                                         _%$%g2636626412%_)
                                  (cons (cons _%$%g2636426407%_
                                              (cons (cons (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#datum->syntax__0
                                                             '#f
                                                             'gensym))
                                                          (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                (declare (not safe))
                                (gx#datum->syntax__0 '#f 'quote))
                              (cons _%$%g2636426407%_ '()))
                        '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '()))
                                        _%$%g2636626412%_)))
                               (__tmp39157
                                (begin
                                  (let ()
                                    (declare (not safe))
                                    (gx#syntax-check-splice-targets
                                     _%$%private-name2566526058%_
                                     _%$%private-name2566526058%_))
                                  (let ((__tmp39158
                                         (lambda (_%$%g2636726415%_
                                                  _%$%g2636826418%_
                                                  _%$%g2636926420%_)
                                           (cons (cons _%$%g2636726415%_
                                                       (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'gensym))
                           (cons (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'quote))
                                       (cons _%$%g2636726415%_ '()))
                                 '()))
                     '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 _%$%g2636926420%_))))
                                    (declare (not safe))
                                    (foldr__1
                                     __tmp39158
                                     '()
                                     _%$%private-name2566526058%_
                                     _%$%private-name2566526058%_)))))
                           (declare (not safe))
                           (foldr__1
                            __tmp39159
                            __tmp39157
                            _%$%source-name2563025960%_
                            _%$%source-name2563025960%_)))))
                  (declare (not safe))
                  (foldr__1
                   __tmp39160
                   __tmp39156
                   _%$%imported-handle2560425848%_
                   _%$%import-name2560525850%_)))
              (cons (cons (let ()
                            (declare (not safe))
                            (gx#datum->syntax__0 '#f 'gerbil-ascent-fragment))
                          (cons (cons (let ()
                                        (declare (not safe))
                                        (gx#datum->syntax__0 '#f 'list))
                                      (begin
                                        (let ()
                                          (declare (not safe))
                                          (gx#syntax-check-splice-targets
                                           _%$%source-rows2562825957%_
                                           _%$%source-column2562925959%_
                                           _%$%source-name2563025960%_))
                                        (let ((__tmp39164
                                               (lambda (_%$%g2637026423%_
                                                        _%$%g2637126426%_
                                                        _%$%g2637226428%_
                                                        _%$%g2637326430%_)
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'relational-source))
                     (cons _%$%g2637226428%_
                           (cons (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'length))
                                       (cons (cons (let ()
                                                     (declare (not safe))
                                                     (gx#datum->syntax__0
                                                      '#f
                                                      'quote))
                                                   (cons (let ((__tmp39165
                                                                (lambda (_%$%g2637426433%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                 _%$%g2637526436%_)
                          (cons _%$%g2637426433%_ _%$%g2637526436%_))))
                   (declare (not safe))
                   (foldr__0 __tmp39165 '() _%$%g2637126426%_))
                 '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             '()))
                                 (cons _%$%g2637026423%_ '()))))
               _%$%g2637326430%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (__tmp39161
                                               (begin
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-check-splice-targets
                                                    _%$%private-column2566426056%_
                                                    _%$%private-name2566526058%_))
                                                 (let ((__tmp39162
                                                        (lambda (_%$%g2637626439%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%$%g2637726442%_
                         _%$%g2637826444%_)
                  (cons (cons (let ()
                                (declare (not safe))
                                (gx#datum->syntax__0 '#f 'relational-source))
                              (cons _%$%g2637726442%_
                                    (cons (cons (let ()
                                                  (declare (not safe))
                                                  (gx#datum->syntax__0
                                                   '#f
                                                   'length))
                                                (cons (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'quote))
                                                            (cons (let ((__tmp39163
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                 (lambda (_%$%g2637926447%_ _%$%g2638026450%_)
                                   (cons _%$%g2637926447%_
                                         _%$%g2638026450%_))))
                            (declare (not safe))
                            (foldr__0 __tmp39163 '() _%$%g2637626439%_))
                          '()))
              '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                          (cons (cons (let ()
                                                        (declare (not safe))
                                                        (gx#datum->syntax__0
                                                         '#f
                                                         '@list))
                                                      '())
                                                '()))))
                        _%$%g2637826444%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (declare (not safe))
                                                   (foldr__1
                                                    __tmp39162
                                                    '()
                                                    _%$%private-column2566426056%_
                                                    _%$%private-name2566526058%_)))))
                                          (declare (not safe))
                                          (__foldr*
                                           __tmp39164
                                           __tmp39161
                                           _%$%source-rows2562825957%_
                                           _%$%source-column2562925959%_
                                           _%$%source-name2563025960%_))))
                                (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0 '#f 'list))
                                            (begin
                                              (let ()
                                                (declare (not safe))
                                                (gx#syntax-check-splice-targets
                                                 _%$%body2571626286%_
                                                 _%$%body-term2571526284%_
                                                 _%$%head-term2571726287%_
                                                 _%$%head2571826288%_))
                                              (let ((__tmp39166
                                                     (lambda (_%$%g2638126453%_
                                                              _%$%g2638226456%_
                                                              _%$%g2638326458%_
                                                              _%$%g2638426460%_
                                                              _%$%g2638526462%_)
                                                       (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'gerbil-ascent-rule))
                           (cons (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'list))
                                       (cons (cons (let ()
                                                     (declare (not safe))
                                                     (gx#datum->syntax__0
                                                      '#f
                                                      'relational-atom/lexical))
                                                   (cons (cons _%$%g2638426460%_
                                                               (let ((__tmp39167
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (lambda (_%$%g2638626465%_ _%$%g2638726468%_)
                                (cons _%$%g2638626465%_ _%$%g2638726468%_))))
                         (declare (not safe))
                         (foldr__0 __tmp39167 '() _%$%g2638326458%_)))
                 '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             '()))
                                 (cons (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f 'list))
                                             (begin
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-check-splice-targets
                                                  _%$%g2638226456%_
                                                  _%$%g2638126453%_))
                                               (let ((__tmp39168
                                                      (lambda (_%$%g2638826471%_
                                                               _%$%g2638926474%_
                                                               _%$%g2639026476%_)
                                                        (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (declare (not safe))
                              (gx#datum->syntax__0
                               '#f
                               'relational-checked-clause))
                            (cons (let ()
                                    (declare (not safe))
                                    (gx#datum->syntax__0
                                     '#f
                                     'relational-atom/lexical))
                                  (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0
                                           '#f
                                           'relational-negation/lexical))
                                        (cons (let ()
                                                (declare (not safe))
                                                (gx#datum->syntax__0
                                                 '#f
                                                 'relational-reduce/lexical))
                                              (cons (cons _%$%g2638926474%_
                                                          (let ((__tmp39169
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (lambda (_%$%g2639126479%_ _%$%g2639226482%_)
                           (cons _%$%g2639126479%_ _%$%g2639226482%_))))
                    (declare (not safe))
                    (foldr__0 __tmp39169 '() _%$%g2638826471%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '())))))
                      _%$%g2639026476%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (declare (not safe))
                                                 (foldr__1
                                                  __tmp39168
                                                  '()
                                                  _%$%g2638226456%_
                                                  _%$%g2638126453%_))))
                                       '())))
                     _%$%g2638526462%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (declare (not safe))
                                                (__foldr*
                                                 __tmp39166
                                                 '()
                                                 _%$%body2571626286%_
                                                 _%$%body-term2571526284%_
                                                 _%$%head-term2571726287%_
                                                 _%$%head2571826288%_))))
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'list))
                                                  (begin
                                                    (let ()
                                                      (declare (not safe))
                                                      (gx#syntax-check-splice-targets
                                                       _%$%exported-name2569626126%_
                                                       _%$%public-name2569726128%_))
                                                    (let ((__tmp39170
                                                           (lambda (_%$%g2639326485%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%$%g2639426488%_
                            _%$%g2639526490%_)
                     (cons (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'cons))
                                 (cons (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0
                                                '#f
                                                'quote))
                                             (cons _%$%g2639426488%_ '()))
                                       (cons _%$%g2639326485%_ '())))
                           _%$%g2639526490%_))))
              (declare (not safe))
              (foldr__1
               __tmp39170
               '()
               _%$%exported-name2569626126%_
               _%$%public-name2569726128%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (cons (cons (let ()
                                                          (declare (not safe))
                                                          (gx#datum->syntax__0
                                                           '#f
                                                           'list))
                                                        (let ((__tmp39171
                                                               (lambda (_%$%g2639626493%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                _%$%g2639726496%_)
                         (cons _%$%g2639626493%_ _%$%g2639726496%_))))
                  (declare (not safe))
                  (foldr__0 __tmp39171 '() _%$%source-name2563025960%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  '())))))
                    '()))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                          (_%$%loop2570726136%_
                           _%$%target2570426130%_
                           '()
                           '()
                           '()
                           '()))
                        (_%$%g2557125765%_ _%$%g2557225769%_)))))
              (_%$%g2557125765%_ _%$%g2557225769%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                  (_%$%loop2569026086%_
                                   _%$%target2568726080%_
                                   '()
                                   '()))
                                (_%$%g2557125765%_ _%$%g2557225769%_)))))
                      (_%$%g2557125765%_ _%$%g2557225769%_))
                  (_%$%g2557125765%_ _%$%g2557225769%_))
              (_%$%g2557125765%_ _%$%g2557225769%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%$%g2557125765%_
                                               _%$%g2557225769%_))))
                                      (_%$%g2557125765%_
                                       _%$%g2557225769%_)))))))
                  (_%$%loop2565825988%_ _%$%target2565525982%_ '() '()))
                (_%$%g2557125765%_ _%$%g2557225769%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%$%g2557125765%_
                                               _%$%g2557225769%_))
                                          (_%$%g2557125765%_
                                           _%$%g2557225769%_))
                                      (_%$%g2557125765%_ _%$%g2557225769%_))))
                              (_%$%g2557125765%_ _%$%g2557225769%_))))
                      (_%$%g2557125765%_ _%$%g2557225769%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                          (_%$%loop2562125878%_
                                           _%$%target2561825872%_
                                           '()
                                           '()
                                           '()))
                                        (_%$%g2557125765%_
                                         _%$%g2557225769%_)))))
                              (_%$%g2557125765%_ _%$%g2557225769%_))
                          (_%$%g2557125765%_ _%$%g2557225769%_))
                      (_%$%g2557125765%_ _%$%g2557225769%_))))
              (_%$%g2557125765%_ _%$%g2557225769%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%$%g2557125765%_
                                               _%$%g2557225769%_)))))))
                          (_%$%loop2559825808%_
                           _%$%target2559525802%_
                           '()
                           '()))
                        (_%$%g2557125765%_ _%$%g2557225769%_)))))
              (_%$%g2557125765%_ _%$%g2557225769%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%$%g2557125765%_
                                                   _%$%g2557225769%_))
                                              (_%$%g2557125765%_
                                               _%$%g2557225769%_))))
                                      (_%$%g2557125765%_ _%$%g2557225769%_))))
                              (_%$%g2557125765%_ _%$%g2557225769%_))))
                      (_%$%g2557125765%_ _%$%g2557225769%_)))))
          (_%$%g2557026499%_ _%$stx25567%_))))))
