(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/view-state::timestamp 1791687880)
  (begin
    (define gerbil-ascent/program/view-state#staged-frontier-count::t
      (let ((__tmp35890 (list)) (__tmp35889 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/view-state#staged-frontier-count::t
         'staged-frontier-count
         __tmp35890
         '(count)
         __tmp35889
         '#f)))
    (define gerbil-ascent/program/view-state#staged-frontier-count?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/view-state#staged-frontier-count::t)))
    (define gerbil-ascent/program/view-state#make-staged-frontier-count
      (lambda _%$args18524%_
        (apply make-instance
               gerbil-ascent/program/view-state#staged-frontier-count::t
               _%$args18524%_)))
    (define gerbil-ascent/program/view-state#staged-frontier-count-count
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#staged-frontier-count::t
         'count)))
    (define gerbil-ascent/program/view-state#staged-frontier-count-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#staged-frontier-count::t
         'count)))
    (define gerbil-ascent/program/view-state#&staged-frontier-count-count
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#staged-frontier-count::t
         'count)))
    (define gerbil-ascent/program/view-state#&staged-frontier-count-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#staged-frontier-count::t
         'count)))
    (define gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
      (lambda (_%frontier18522%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%frontier18522%_
               'gerbil-ascent/program/view-state#staged-frontier-count::t))
            (let ()
              (declare (not safe))
              (##unchecked-structure-ref _%frontier18522%_ '1 '#f '#f))
            (let ()
              (declare (not safe))
              (gerbil-ascent/core/relation-view#gerbil-ascent-row-count
               _%frontier18522%_)))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-empty-view
      (let ()
        (declare (not safe))
        (gerbil-ascent/core/relation-view#gerbil-ascent-explicit-view '() '0)))
    (define gerbil-ascent/program/view-state#view-routing-state::t
      (let ((__tmp35892 (list)) (__tmp35891 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/view-state#view-routing-state::t
         'view-routing-state
         __tmp35892
         '(storage all delta versions names generation journals routing)
         __tmp35891
         '#f)))
    (define gerbil-ascent/program/view-state#view-routing-state?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/view-state#view-routing-state::t)))
    (define gerbil-ascent/program/view-state#make-view-routing-state
      (lambda _%$args18519%_
        (apply make-instance
               gerbil-ascent/program/view-state#view-routing-state::t
               _%$args18519%_)))
    (define gerbil-ascent/program/view-state#view-routing-state-storage
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'storage)))
    (define gerbil-ascent/program/view-state#view-routing-state-all
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'all)))
    (define gerbil-ascent/program/view-state#view-routing-state-delta
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'delta)))
    (define gerbil-ascent/program/view-state#view-routing-state-versions
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'versions)))
    (define gerbil-ascent/program/view-state#view-routing-state-names
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'names)))
    (define gerbil-ascent/program/view-state#view-routing-state-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'generation)))
    (define gerbil-ascent/program/view-state#view-routing-state-journals
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'journals)))
    (define gerbil-ascent/program/view-state#view-routing-state-routing
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'routing)))
    (define gerbil-ascent/program/view-state#view-routing-state-storage-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'storage)))
    (define gerbil-ascent/program/view-state#view-routing-state-all-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'all)))
    (define gerbil-ascent/program/view-state#view-routing-state-delta-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'delta)))
    (define gerbil-ascent/program/view-state#view-routing-state-versions-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'versions)))
    (define gerbil-ascent/program/view-state#view-routing-state-names-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'names)))
    (define gerbil-ascent/program/view-state#view-routing-state-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'generation)))
    (define gerbil-ascent/program/view-state#view-routing-state-journals-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'journals)))
    (define gerbil-ascent/program/view-state#view-routing-state-routing-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'routing)))
    (define gerbil-ascent/program/view-state#&view-routing-state-storage
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'storage)))
    (define gerbil-ascent/program/view-state#&view-routing-state-all
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'all)))
    (define gerbil-ascent/program/view-state#&view-routing-state-delta
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'delta)))
    (define gerbil-ascent/program/view-state#&view-routing-state-versions
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'versions)))
    (define gerbil-ascent/program/view-state#&view-routing-state-names
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'names)))
    (define gerbil-ascent/program/view-state#&view-routing-state-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'generation)))
    (define gerbil-ascent/program/view-state#&view-routing-state-journals
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'journals)))
    (define gerbil-ascent/program/view-state#&view-routing-state-routing
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'routing)))
    (define gerbil-ascent/program/view-state#&view-routing-state-storage-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'storage)))
    (define gerbil-ascent/program/view-state#&view-routing-state-all-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'all)))
    (define gerbil-ascent/program/view-state#&view-routing-state-delta-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'delta)))
    (define gerbil-ascent/program/view-state#&view-routing-state-versions-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'versions)))
    (define gerbil-ascent/program/view-state#&view-routing-state-names-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'names)))
    (define gerbil-ascent/program/view-state#&view-routing-state-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'generation)))
    (define gerbil-ascent/program/view-state#&view-routing-state-journals-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'journals)))
    (define gerbil-ascent/program/view-state#&view-routing-state-routing-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'routing)))
    (define gerbil-ascent/program/view-state#initial-delta
      (lambda (_%view18513%_
               _%name18514%_
               _%generation18515%_
               _%revision18516%_)
        (let ((__tmp35894
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/core/relation-view#gerbil-ascent-view-bind
                  _%view18513%_
                  _%name18514%_
                  _%generation18515%_
                  _%revision18516%_
                  'delta)))
              (__tmp35893
               (lambda ()
                 (reverse (let ()
                            (declare (not safe))
                            (gerbil-ascent/core/relation-view#gerbil-ascent-view-rows
                             _%view18513%_))))))
          (declare (not safe))
          (gerbil-ascent/core/relation-view#gerbil-ascent-view-with-export
           __tmp35894
           __tmp35893))))
    (define gerbil-ascent/program/view-state#publish-source-cut!
      (lambda (_%state18499%_ _%index18500%_ _%view18501%_ _%revision18502%_)
        (let* ((_%name18504%_
                (vector-ref
                 (##structure-ref
                  _%state18499%_
                  '5
                  gerbil-ascent/program/view-state#view-routing-state::t
                  '#f)
                 _%index18500%_))
               (_%generation18506%_
                (##structure-ref
                 _%state18499%_
                 '6
                 gerbil-ascent/program/view-state#view-routing-state::t
                 '#f))
               (_%frozen18508%_
                (gerbil-ascent/program/view-state#gerbil-ascent-view-export-cut__%
                 _%view18501%_
                 (vector-ref
                  (##structure-ref
                   _%state18499%_
                   '7
                   gerbil-ascent/program/view-state#view-routing-state::t
                   '#f)
                  _%index18500%_)
                 (let ((__tmp35895
                        (vector-ref
                         (##structure-ref
                          _%state18499%_
                          '1
                          gerbil-ascent/program/view-state#view-routing-state::t
                          '#f)
                         _%index18500%_)))
                   (declare (not safe))
                   (gerbil-ascent/table/storage#gerbil-ascent-storage-eqrel-state?
                    __tmp35895))))
               (_%total18510%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/core/relation-view#gerbil-ascent-view-bind
                   _%frozen18508%_
                   _%name18504%_
                   _%generation18506%_
                   _%revision18502%_
                   'total))))
          (vector-set!
           (##structure-ref
            _%state18499%_
            '2
            gerbil-ascent/program/view-state#view-routing-state::t
            '#f)
           _%index18500%_
           _%total18510%_)
          (vector-set!
           (##structure-ref
            _%state18499%_
            '3
            gerbil-ascent/program/view-state#view-routing-state::t
            '#f)
           _%index18500%_
           (gerbil-ascent/program/view-state#initial-delta
            _%frozen18508%_
            _%name18504%_
            _%generation18506%_
            _%revision18502%_)))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-initialize-view-cuts!
      (lambda (_%relations18489%_ _%eligible?18490%_ _%state18491%_)
        (let ((_%all18493%_
               (##structure-ref
                _%state18491%_
                '2
                gerbil-ascent/program/view-state#view-routing-state::t
                '#f))
              (_%journals18494%_
               (##structure-ref
                _%state18491%_
                '7
                gerbil-ascent/program/view-state#view-routing-state::t
                '#f)))
          (for-each
           (lambda (_%relation18496%_ _%index18497%_)
             (if (_%eligible?18490%_ _%index18497%_)
                 (begin
                   (vector-set!
                    _%journals18494%_
                    _%index18497%_
                    (list (gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event__0
                           'source
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref _%relation18496%_ 'rows)))))
                   (gerbil-ascent/program/view-state#publish-source-cut!
                    _%state18491%_
                    _%index18497%_
                    (if (let ((__tmp35896
                               (vector-ref _%all18493%_ _%index18497%_)))
                          (declare (not safe))
                          (##structure-instance-of?
                           __tmp35896
                           'gerbil-ascent/core/relation-view#relation-view::t))
                        (vector-ref _%all18493%_ _%index18497%_)
                        gerbil-ascent/program/view-state#gerbil-ascent-empty-view)
                    '0))
                 '#!void))
           _%relations18489%_
           (let ((__tmp35897 (vector-length _%all18493%_)))
             (declare (not safe))
             (##iota __tmp35897))))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-route-view-sources!
      (lambda (_%rule-plans18467%_ _%eligible?18468%_ _%state18469%_)
        (let ((_%all18471%_
               (##structure-ref
                _%state18469%_
                '2
                gerbil-ascent/program/view-state#view-routing-state::t
                '#f))
              (_%routing18472%_
               (##structure-ref
                _%state18469%_
                '8
                gerbil-ascent/program/view-state#view-routing-state::t
                '#f))
              (_%storage18473%_
               (##structure-ref
                _%state18469%_
                '1
                gerbil-ascent/program/view-state#view-routing-state::t
                '#f))
              (_%versions18474%_
               (##structure-ref
                _%state18469%_
                '4
                gerbil-ascent/program/view-state#view-routing-state::t
                '#f)))
          (for-each
           (lambda (_%rule18476%_)
             (for-each
              (lambda (_%clause18478%_)
                (if (eq? (vector-ref _%clause18478%_ '0) 'atom)
                    (let* ((_%atom18480%_ (vector-ref _%clause18478%_ '1))
                           (_%index18482%_ (vector-ref _%atom18480%_ '0)))
                      (if (and (_%eligible?18468%_ _%index18482%_)
                               (let ((__tmp35899
                                      (lambda (_%term18485%_)
                                        (not (eq? (car _%term18485%_)
                                                  'literal))))
                                     (__tmp35898
                                      (vector-ref _%atom18480%_ '4)))
                                 (declare (not safe))
                                 (ormap__0 __tmp35899 __tmp35898)))
                          (vector-set! _%routing18472%_ _%index18482%_ '#t)
                          '#!void))
                    '#!void))
              (vector-ref _%rule18476%_ '1)))
           _%rule-plans18467%_)
          (let ((__tmp35902
                 (lambda (_%index18487%_)
                   (if (vector-ref _%routing18472%_ _%index18487%_)
                       (gerbil-ascent/program/view-state#publish-source-cut!
                        _%state18469%_
                        _%index18487%_
                        (let ((__tmp35903
                               (vector-ref _%storage18473%_ _%index18487%_)))
                          (declare (not safe))
                          (gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__%
                           __tmp35903
                           '#t))
                        (vector-ref _%versions18474%_ _%index18487%_))
                       '#!void)))
                (__tmp35900
                 (let ((__tmp35901 (vector-length _%all18471%_)))
                   (declare (not safe))
                   (##iota __tmp35901))))
            (declare (not safe))
            (##for-each __tmp35902 __tmp35900)))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-view-relation?
      (lambda (_%storage18464%_ _%index18465%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/table/storage#gerbil-ascent-canonical-view-storage-provider?
               _%storage18464%_))
            (let ()
              (declare (not safe))
              (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
               _%index18465%_))
            '#f)))
    (define gerbil-ascent/program/view-state#gerbil-ascent-add-frontier
      (lambda (_%old18454%_ _%frontier18455%_)
        (if (= (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                _%frontier18455%_)
               '0)
            _%old18454%_
            (if (= (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                    _%old18454%_)
                   '0)
                _%frontier18455%_
                (if (or (let ()
                          (declare (not safe))
                          (##structure-instance-of?
                           _%old18454%_
                           'gerbil-ascent/program/view-state#staged-frontier-count::t))
                        (let ()
                          (declare (not safe))
                          (##structure-instance-of?
                           _%frontier18455%_
                           'gerbil-ascent/program/view-state#staged-frontier-count::t)))
                    (let ((__tmp35904
                           (+ (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                               _%old18454%_)
                              (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                               _%frontier18455%_))))
                      (declare (not safe))
                      (##structure
                       gerbil-ascent/program/view-state#staged-frontier-count::t
                       __tmp35904))
                    (let ()
                      (declare (not safe))
                      (gerbil-ascent/core/relation-view#gerbil-ascent-view-union
                       _%old18454%_
                       _%frontier18455%_)))))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-stage-view!
      (lambda (_%state18447%_ _%row18448%_ _%budget18449%_ _%check18450%_)
        (let ((_%frontier18452%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/table/storage#gerbil-ascent-storage-view-extension!
                  _%state18447%_
                  _%row18448%_
                  _%budget18449%_))))
          (if _%check18450%_
              (let ()
                (declare (not safe))
                (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
                 _%check18450%_
                 _%frontier18452%_))
              '#!void)
          (if (let ()
                (declare (not safe))
                (gerbil-ascent/table/storage#gerbil-ascent-storage-eqrel-state?
                 _%state18447%_))
              (let ((__tmp35905
                     (let ()
                       (declare (not safe))
                       (gerbil-ascent/core/relation-view#gerbil-ascent-row-count
                        _%frontier18452%_))))
                (declare (not safe))
                (##structure
                 gerbil-ascent/program/view-state#staged-frontier-count::t
                 __tmp35905))
              _%frontier18452%_))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-commit-view!__%
      (lambda (_%index18387%_
               _%state18388%_
               _%frontier18389%_
               _%all18390%_
               _%delta18391%_
               _%all-size18392%_
               _%delta-size18393%_
               _%all-version18394%_
               _%delta-version18395%_
               _%name18396%_
               _%generation18397%_
               _%events18398%_
               _%indexed?18399%_)
        (let ((__tmp35910
               (lambda ()
                 (let ((__tmp35911
                        (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                         _%frontier18389%_)))
                   (declare (not safe))
                   (gerbil-ascent/table/storage#gerbil-ascent-storage-publish-view!
                    _%state18388%_
                    _%frontier18389%_
                    __tmp35911
                    _%indexed?18399%_))))
              (__tmp35906
               (lambda (_%carrier18402%_ _%change-carrier18403%_)
                 (let* ((_%revision18405%_
                         (+ '1
                            (vector-ref _%all-version18394%_ _%index18387%_)))
                        (_%eqrel?18407%_
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/table/storage#gerbil-ascent-storage-eqrel-state?
                            _%state18388%_)))
                        (_%total18409%_
                         (gerbil-ascent/program/view-state#gerbil-ascent-view-export-cut__%
                          (let ()
                            (declare (not safe))
                            (gerbil-ascent/core/relation-view#gerbil-ascent-view-bind
                             _%carrier18402%_
                             _%name18396%_
                             _%generation18397%_
                             _%revision18405%_
                             'total))
                          _%events18398%_
                          _%eqrel?18407%_))
                        (_%change18412%_
                         (let ((__tmp35909
                                (let ()
                                  (declare (not safe))
                                  (gerbil-ascent/core/relation-view#gerbil-ascent-view-bind
                                   _%change-carrier18403%_
                                   _%name18396%_
                                   _%generation18397%_
                                   _%revision18405%_
                                   'delta)))
                               (__tmp35907
                                (lambda ()
                                  (let ((__tmp35908
                                         (gerbil-ascent/program/view-state#export-events__%
                                          _%events18398%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%total18409%_
                                             '5
                                             '#f
                                             '#f))
                                          (- (let ()
                                               (declare (not safe))
                                               (##unchecked-structure-ref
                                                _%total18409%_
                                                '5
                                                '#f
                                                '#f))
                                             (##structure-ref
                                              _%change-carrier18403%_
                                              '5
                                              gerbil-ascent/core/relation-view#relation-view::t
                                              '#f))
                                          '#t
                                          _%eqrel?18407%_)))
                                    (declare (not safe))
                                    (##reverse __tmp35908)))))
                           (declare (not safe))
                           (gerbil-ascent/core/relation-view#gerbil-ascent-view-with-export
                            __tmp35909
                            __tmp35907))))
                   (vector-set! _%all18390%_ _%index18387%_ _%total18409%_)
                   (vector-set! _%delta18391%_ _%index18387%_ _%change18412%_)
                   (vector-set!
                    _%all-size18392%_
                    _%index18387%_
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-ref _%total18409%_ '5 '#f '#f)))
                   (vector-set!
                    _%delta-size18393%_
                    _%index18387%_
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-ref _%change18412%_ '5 '#f '#f)))
                   (vector-set!
                    _%all-version18394%_
                    _%index18387%_
                    _%revision18405%_)
                   (vector-set!
                    _%delta-version18395%_
                    _%index18387%_
                    (+ '1
                       (vector-ref _%delta-version18395%_ _%index18387%_)))))))
          (declare (not safe))
          (##call-with-values __tmp35910 __tmp35906))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-commit-view!__0
      (lambda (_%index18418%_
               _%state18419%_
               _%frontier18420%_
               _%all18421%_
               _%delta18422%_
               _%all-size18423%_
               _%delta-size18424%_
               _%all-version18425%_
               _%delta-version18426%_
               _%name18427%_
               _%generation18428%_
               _%events18429%_)
        (let ((_%indexed?18431%_ '#f))
          (gerbil-ascent/program/view-state#gerbil-ascent-commit-view!__%
           _%index18418%_
           _%state18419%_
           _%frontier18420%_
           _%all18421%_
           _%delta18422%_
           _%all-size18423%_
           _%delta-size18424%_
           _%all-version18425%_
           _%delta-version18426%_
           _%name18427%_
           _%generation18428%_
           _%events18429%_
           _%indexed?18431%_))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-commit-view!
      (lambda _g35912_
        (let ((_g35913_ (let () (declare (not safe)) (##length _g35912_))))
          (cond ((let () (declare (not safe)) (##fx= _g35913_ 12))
                 (apply gerbil-ascent/program/view-state#gerbil-ascent-commit-view!__0
                        _g35912_))
                ((let () (declare (not safe)) (##fx= _g35913_ 13))
                 (apply gerbil-ascent/program/view-state#gerbil-ascent-commit-view!__%
                        _g35912_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/view-state#gerbil-ascent-commit-view!
                  _g35912_))))))
    (define gerbil-ascent/program/view-state#view-event::t
      (let ((__tmp35915 (list)) (__tmp35914 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/view-state#view-event::t
         'view-event
         __tmp35915
         '(kind rows eqrel?)
         __tmp35914
         '#f)))
    (define gerbil-ascent/program/view-state#view-event?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/view-state#view-event::t)))
    (define gerbil-ascent/program/view-state#make-view-event
      (lambda _%$args18383%_
        (apply make-instance
               gerbil-ascent/program/view-state#view-event::t
               _%$args18383%_)))
    (define gerbil-ascent/program/view-state#view-event-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-event::t
         'kind)))
    (define gerbil-ascent/program/view-state#view-event-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-event::t
         'rows)))
    (define gerbil-ascent/program/view-state#view-event-eqrel?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-event::t
         'eqrel?)))
    (define gerbil-ascent/program/view-state#view-event-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-event::t
         'kind)))
    (define gerbil-ascent/program/view-state#view-event-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-event::t
         'rows)))
    (define gerbil-ascent/program/view-state#view-event-eqrel?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-event::t
         'eqrel?)))
    (define gerbil-ascent/program/view-state#&view-event-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-event::t
         'kind)))
    (define gerbil-ascent/program/view-state#&view-event-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-event::t
         'rows)))
    (define gerbil-ascent/program/view-state#&view-event-eqrel?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-event::t
         'eqrel?)))
    (define gerbil-ascent/program/view-state#&view-event-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-event::t
         'kind)))
    (define gerbil-ascent/program/view-state#&view-event-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-event::t
         'rows)))
    (define gerbil-ascent/program/view-state#&view-event-eqrel?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-event::t
         'eqrel?)))
    (define gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event__%
      (lambda (_%kind18365%_ _%rows18366%_ _%eqrel?18367%_)
        (let ((__tmp35916
               (map (lambda (_%row18369%_) (map values _%row18369%_))
                    _%rows18366%_)))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/view-state#view-event::t
           _%kind18365%_
           __tmp35916
           _%eqrel?18367%_))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event__0
      (lambda (_%kind18374%_ _%rows18375%_)
        (let ((_%eqrel?18377%_ '#f))
          (gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event__%
           _%kind18374%_
           _%rows18375%_
           _%eqrel?18377%_))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event
      (lambda _g35917_
        (let ((_g35918_ (let () (declare (not safe)) (##length _g35917_))))
          (cond ((let () (declare (not safe)) (##fx= _g35918_ 2))
                 (apply gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event__0
                        _g35917_))
                ((let () (declare (not safe)) (##fx= _g35918_ 3))
                 (apply gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event__%
                        _g35917_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event
                  _g35917_))))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-view-export-cut__%
      (lambda (_%view18344%_ _%events18345%_ _%eqrel?18346%_)
        (let ((__tmp35919
               (lambda ()
                 (gerbil-ascent/program/view-state#export-events__%
                  _%events18345%_
                  (##structure-ref
                   _%view18344%_
                   '5
                   gerbil-ascent/core/relation-view#relation-view::t
                   '#f)
                  '0
                  '#f
                  (let ((_%$e18349%_ _%eqrel?18346%_))
                    (if _%$e18349%_
                        _%$e18349%_
                        (if (pair? _%events18345%_)
                            (##structure-ref
                             (let ()
                               (declare (not safe))
                               (##car _%events18345%_))
                             '3
                             gerbil-ascent/program/view-state#view-event::t
                             '#f)
                            '#f)))))))
          (declare (not safe))
          (gerbil-ascent/core/relation-view#gerbil-ascent-view-with-export
           _%view18344%_
           __tmp35919))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-view-export-cut__0
      (lambda (_%view18355%_ _%events18356%_)
        (let ((_%eqrel?18358%_ '#f))
          (gerbil-ascent/program/view-state#gerbil-ascent-view-export-cut__%
           _%view18355%_
           _%events18356%_
           _%eqrel?18358%_))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-view-export-cut
      (lambda _g35920_
        (let ((_g35921_ (let () (declare (not safe)) (##length _g35920_))))
          (cond ((let () (declare (not safe)) (##fx= _g35921_ 2))
                 (apply gerbil-ascent/program/view-state#gerbil-ascent-view-export-cut__0
                        _g35920_))
                ((let () (declare (not safe)) (##fx= _g35921_ 3))
                 (apply gerbil-ascent/program/view-state#gerbil-ascent-view-export-cut__%
                        _g35920_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/view-state#gerbil-ascent-view-export-cut
                  _g35920_))))))
    (define gerbil-ascent/program/view-state#export-events__%
      (lambda (_%events18310%_
               _%budget18311%_
               _%skip18312%_
               _%delta?18313%_
               _%eqrel?18314%_)
        (let ((_%$e18316%_
               (if _%eqrel?18314%_
                   '#f
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/program/view-replay#gerbil-ascent-small-journal-export
                      _%events18310%_
                      gerbil-ascent/program/view-state#view-event-kind
                      gerbil-ascent/program/view-state#view-event-rows
                      _%budget18311%_
                      _%skip18312%_
                      _%delta?18313%_)))))
          (if _%$e18316%_
              _%$e18316%_
              (gerbil-ascent/program/view-state#replay-events
               _%events18310%_
               _%budget18311%_
               _%skip18312%_
               _%delta?18313%_
               _%eqrel?18314%_)))))
    (define gerbil-ascent/program/view-state#export-events__0
      (lambda (_%events18322%_ _%budget18323%_ _%skip18324%_)
        (let* ((_%delta?18326%_ '#f) (_%eqrel?18328%_ '#f))
          (gerbil-ascent/program/view-state#export-events__%
           _%events18322%_
           _%budget18323%_
           _%skip18324%_
           _%delta?18326%_
           _%eqrel?18328%_))))
    (define gerbil-ascent/program/view-state#export-events__1
      (lambda (_%events18330%_ _%budget18331%_ _%skip18332%_ _%delta?18333%_)
        (let ((_%eqrel?18335%_ '#f))
          (gerbil-ascent/program/view-state#export-events__%
           _%events18330%_
           _%budget18331%_
           _%skip18332%_
           _%delta?18333%_
           _%eqrel?18335%_))))
    (define gerbil-ascent/program/view-state#export-events
      (lambda _g35922_
        (let ((_g35923_ (let () (declare (not safe)) (##length _g35922_))))
          (cond ((let () (declare (not safe)) (##fx= _g35923_ 3))
                 (apply gerbil-ascent/program/view-state#export-events__0
                        _g35922_))
                ((let () (declare (not safe)) (##fx= _g35923_ 4))
                 (apply gerbil-ascent/program/view-state#export-events__1
                        _g35922_))
                ((let () (declare (not safe)) (##fx= _g35923_ 5))
                 (apply gerbil-ascent/program/view-state#export-events__%
                        _g35922_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/view-state#export-events
                  _g35922_))))))
    (define gerbil-ascent/program/view-state#replay-events
      (lambda (_%events18281%_
               _%budget18282%_
               _%skip18283%_
               _%delta?18284%_
               _%eqrel?18285%_)
        (let ((_%state18287%_
               (if _%eqrel?18285%_
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-state))
                   (let ()
                     (declare (not safe))
                     (make-hash-table__%
                      '#f
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value))))
              (_%output18288%_ '())
              (_%admitted18289%_ '0))
          (let ((__tmp35925
                 (lambda (_%event18291%_)
                   (let ((_%batch18293%_ '())
                         (_%derived?18294%_
                          (if _%delta?18284%_
                              '#f
                              (eq? (##structure-ref
                                    _%event18291%_
                                    '1
                                    gerbil-ascent/program/view-state#view-event::t
                                    '#f)
                                   'derived))))
                     (for-each
                      (lambda (_%row18296%_)
                        (let* ((_%frontier18298%_
                                ((if _%eqrel?18285%_
                                     gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-insert!
                                     gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-insert!)
                                 _%state18287%_
                                 _%row18296%_
                                 _%budget18282%_))
                               (_%next18300%_
                                (+ _%admitted18289%_
                                   (let ()
                                     (declare (not safe))
                                     (##unchecked-structure-ref
                                      _%frontier18298%_
                                      '5
                                      '#f
                                      '#f)))))
                          (if (> _%next18300%_ _%skip18283%_)
                              (begin
                                (if (> _%skip18283%_ _%admitted18289%_)
                                    (let ()
                                      (declare (not safe))
                                      (error '"ASCENT ordered delta splits an injection frontier"))
                                    '#!void)
                                (let ((__tmp35926
                                       (if _%derived?18294%_
                                           (lambda (_%stored18303%_)
                                             (set! _%batch18293%_
                                                   (cons _%stored18303%_
                                                         _%batch18293%_)))
                                           (lambda (_%stored18305%_)
                                             (set! _%output18288%_
                                                   (cons _%stored18305%_
                                                         _%output18288%_))))))
                                  (declare (not safe))
                                  (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
                                   __tmp35926
                                   _%frontier18298%_)))
                              '#!void)
                          (set! _%admitted18289%_ _%next18300%_)))
                      (##structure-ref
                       _%event18291%_
                       '2
                       gerbil-ascent/program/view-state#view-event::t
                       '#f))
                     (if _%derived?18294%_
                         (let ((__tmp35927
                                (lambda (_%row18307%_)
                                  (set! _%output18288%_
                                        (cons _%row18307%_ _%output18288%_)))))
                           (declare (not safe))
                           (##for-each __tmp35927 _%batch18293%_))
                         '#!void))))
                (__tmp35924 (reverse _%events18281%_)))
            (declare (not safe))
            (##for-each __tmp35925 __tmp35924))
          (let () (declare (not safe)) (##reverse _%output18288%_)))))))
