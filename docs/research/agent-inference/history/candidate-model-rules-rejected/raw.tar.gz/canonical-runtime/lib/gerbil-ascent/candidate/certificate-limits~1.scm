(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34035_|
    (##structure
     gx#syntax-quote::t
     'certificate-material::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34037_|
    (##structure
     gx#syntax-quote::t
     'make-certificate-material
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34039_|
    (##structure
     gx#syntax-quote::t
     'certificate-material?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34041_|
    (##structure
     gx#syntax-quote::t
     'certificate-material-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34042_|
    (##structure
     gx#syntax-quote::t
     'certificate-material-cells
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34044_|
    (##structure
     gx#syntax-quote::t
     'certificate-material-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34045_|
    (##structure
     gx#syntax-quote::t
     'certificate-material-cells-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34047_|
    (##structure
     gx#syntax-quote::t
     '&certificate-material-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34048_|
    (##structure
     gx#syntax-quote::t
     '&certificate-material-cells
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34050_|
    (##structure
     gx#syntax-quote::t
     '&certificate-material-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34051_|
    (##structure
     gx#syntax-quote::t
     '&certificate-material-cells-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[:0:]#certificate-material|
    (let ((__obj33988
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj33988
         'gerbil-ascent/candidate/certificate-limits#certificate-material::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj33988
         'certificate-material
         '3
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33988 '(rows cells) '6 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33988 '(rows cells) '8 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33988 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33988 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33988 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33988 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33988 '#f '13 '#f '#f))
      (let ((__tmp34034
             |gerbil-ascent/candidate/certificate-limits[1]#_g34035_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj33988 __tmp34034 '4 '#f '#f))
      (let ((__tmp34036
             |gerbil-ascent/candidate/certificate-limits[1]#_g34037_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj33988 __tmp34036 '14 '#f '#f))
      (let ((__tmp34038
             |gerbil-ascent/candidate/certificate-limits[1]#_g34039_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj33988 __tmp34038 '15 '#f '#f))
      (let ((__tmp34040
             (cons (cons 'rows
                         |gerbil-ascent/candidate/certificate-limits[1]#_g34041_|)
                   (cons (cons 'cells
                               |gerbil-ascent/candidate/certificate-limits[1]#_g34042_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33988 __tmp34040 '16 '#f '#f))
      (let ((__tmp34043
             (cons (cons 'rows
                         |gerbil-ascent/candidate/certificate-limits[1]#_g34044_|)
                   (cons (cons 'cells
                               |gerbil-ascent/candidate/certificate-limits[1]#_g34045_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33988 __tmp34043 '17 '#f '#f))
      (let ((__tmp34046
             (cons (cons 'rows
                         |gerbil-ascent/candidate/certificate-limits[1]#_g34047_|)
                   (cons (cons 'cells
                               |gerbil-ascent/candidate/certificate-limits[1]#_g34048_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33988 __tmp34046 '18 '#f '#f))
      (let ((__tmp34049
             (cons (cons 'rows
                         |gerbil-ascent/candidate/certificate-limits[1]#_g34050_|)
                   (cons (cons 'cells
                               |gerbil-ascent/candidate/certificate-limits[1]#_g34051_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33988 __tmp34049 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33988 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33988 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33988 '() '21 '#f '#f))
      __obj33988)))
