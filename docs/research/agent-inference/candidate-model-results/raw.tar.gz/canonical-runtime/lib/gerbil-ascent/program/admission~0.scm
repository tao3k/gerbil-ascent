(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/admission::timestamp 1791689670)
  (begin
    (define gerbil-ascent/program/admission#gerbil-ascent-check-replacement-rows!
      (lambda (_%name15656%_ _%rows15657%_ _%width15658%_ _%check15659%_)
        (if (list? _%rows15657%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT replacement source rows"
                     _%name15656%_
                     _%rows15657%_)))
        (for-each
         (lambda (_%row15661%_)
           (if (and (list? _%row15661%_)
                    (= (let () (declare (not safe)) (##length _%row15661%_))
                       _%width15658%_))
               '#!void
               (let ()
                 (declare (not safe))
                 (error '"invalid ASCENT replacement source row"
                        _%name15656%_
                        _%row15661%_)))
           (if _%check15659%_ (_%check15659%_ _%row15661%_) '#!void))
         _%rows15657%_)))
    (define gerbil-ascent/program/admission#gerbil-ascent-initialize-source-row!
      (lambda (_%stored15647%_
               _%width15648%_
               _%check15649%_
               _%present15650%_
               _%all15651%_
               _%index15652%_
               _%count15653%_
               _%output-limit15654%_)
        (if (and (list? _%stored15647%_)
                 (= (let () (declare (not safe)) (##length _%stored15647%_))
                    _%width15648%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT storage provider row" _%stored15647%_)))
        (if _%check15649%_ (_%check15649%_ _%stored15647%_) '#!void)
        (gerbil-ascent/program/admission#gerbil-ascent-admit-source-row!
         _%stored15647%_
         _%present15650%_
         _%all15651%_
         _%index15652%_
         _%count15653%_
         _%output-limit15654%_)))
    (define gerbil-ascent/program/admission#gerbil-ascent-admit-source-row!
      (lambda (_%stored15638%_
               _%present15639%_
               _%all15640%_
               _%index15641%_
               _%count15642%_
               _%output-limit15643%_)
        (let ()
          (declare (not safe))
          (hash-put! _%present15639%_ _%stored15638%_ '#t))
        (let ((_%next-count15645%_ (+ _%count15642%_ '1)))
          (if (> _%next-count15645%_ _%output-limit15643%_)
              (let ()
                (declare (not safe))
                (error '"ASCENT source fact budget exceeded"))
              '#!void)
          (vector-set!
           _%all15640%_
           _%index15641%_
           (cons _%stored15638%_ (vector-ref _%all15640%_ _%index15641%_)))
          _%next-count15645%_)))
    (define gerbil-ascent/program/admission#gerbil-ascent-prepare-storage-batch
      (lambda (_%expanded15450%_
               _%width15451%_
               _%check15452%_
               _%present15453%_
               _%count15454%_
               _%output-limit15455%_)
        (if (list? _%expanded15450%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"ASCENT storage provider returned non-list rows")))
        (let* ((_%batch-seen15457%_
                (if (pair? _%expanded15450%_)
                    (if (pair? (let ()
                                 (declare (not safe))
                                 (##cdr _%expanded15450%_)))
                        (let ()
                          (declare (not safe))
                          (make-hash-table__%
                           '#f
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value))
                        '#f)
                    '#f))
               (_%accepted15633%_
                (let* ((_%head15459%_ (cons '#f '()))
                       (_%tail15462%_ _%head15459%_))
                  (for-each
                   (lambda (_%stored15625%_)
                     (if (and (list? _%stored15625%_)
                              (= (let ()
                                   (declare (not safe))
                                   (##length _%stored15625%_))
                                 _%width15451%_))
                         '#!void
                         (let ()
                           (declare (not safe))
                           (error '"invalid ASCENT storage provider row"
                                  _%stored15625%_)))
                     (if _%check15452%_
                         (_%check15452%_ _%stored15625%_)
                         '#!void)
                     (if (or (let ()
                               (declare (not safe))
                               (hash-get _%present15453%_ _%stored15625%_))
                             (and _%batch-seen15457%_
                                  (let ()
                                    (declare (not safe))
                                    (__hash-get
                                     _%batch-seen15457%_
                                     _%stored15625%_))))
                         '#!void
                         (begin
                           (if _%batch-seen15457%_
                               (let ()
                                 (declare (not safe))
                                 (__hash-put!
                                  _%batch-seen15457%_
                                  _%stored15625%_
                                  '#t))
                               '#!void)
                           (let ((_%new-tail15630%_
                                  (cons _%stored15625%_ '())))
                             (let ()
                               (declare (not safe))
                               (##set-cdr! _%tail15462%_ _%new-tail15630%_))
                             (set! _%tail15462%_ _%new-tail15630%_)))))
                   _%expanded15450%_)
                  (let () (declare (not safe)) (##cdr _%head15459%_))))
               (_%added-count15635%_
                (if _%batch-seen15457%_
                    (let ()
                      (declare (not safe))
                      (__hash-length _%batch-seen15457%_))
                    (if (pair? _%accepted15633%_) '1 '0))))
          (if (> (+ _%count15454%_ _%added-count15635%_) _%output-limit15455%_)
              (let ()
                (declare (not safe))
                (error '"ASCENT session output fact budget exceeded"))
              '#!void)
          (values _%accepted15633%_ _%added-count15635%_))))))
