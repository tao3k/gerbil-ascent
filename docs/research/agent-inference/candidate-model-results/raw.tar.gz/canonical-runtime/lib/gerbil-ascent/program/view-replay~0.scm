(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/view-replay::timestamp 1791689670)
  (begin
    (define gerbil-ascent/program/view-replay#replay-node::t
      (let ((__tmp33827 (list)) (__tmp33826 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/view-replay#replay-node::t
         'replay-node
         __tmp33827
         '(parent members size)
         __tmp33826
         '#f)))
    (define gerbil-ascent/program/view-replay#replay-node?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/view-replay#replay-node::t)))
    (define gerbil-ascent/program/view-replay#make-replay-node
      (lambda _%$args18295%_
        (apply make-instance
               gerbil-ascent/program/view-replay#replay-node::t
               _%$args18295%_)))
    (define gerbil-ascent/program/view-replay#replay-node-parent
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-replay#replay-node::t
         'parent)))
    (define gerbil-ascent/program/view-replay#replay-node-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-replay#replay-node::t
         'members)))
    (define gerbil-ascent/program/view-replay#replay-node-size
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-replay#replay-node::t
         'size)))
    (define gerbil-ascent/program/view-replay#replay-node-parent-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-replay#replay-node::t
         'parent)))
    (define gerbil-ascent/program/view-replay#replay-node-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-replay#replay-node::t
         'members)))
    (define gerbil-ascent/program/view-replay#replay-node-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-replay#replay-node::t
         'size)))
    (define gerbil-ascent/program/view-replay#&replay-node-parent
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-replay#replay-node::t
         'parent)))
    (define gerbil-ascent/program/view-replay#&replay-node-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-replay#replay-node::t
         'members)))
    (define gerbil-ascent/program/view-replay#&replay-node-size
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-replay#replay-node::t
         'size)))
    (define gerbil-ascent/program/view-replay#&replay-node-parent-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-replay#replay-node::t
         'parent)))
    (define gerbil-ascent/program/view-replay#&replay-node-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-replay#replay-node::t
         'members)))
    (define gerbil-ascent/program/view-replay#&replay-node-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-replay#replay-node::t
         'size)))
    (define gerbil-ascent/program/view-replay#replay-group::t
      (let ((__tmp33829 (list)) (__tmp33828 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/view-replay#replay-group::t
         'replay-group
         __tmp33829
         '(nodes roots values used width bits)
         __tmp33828
         '#f)))
    (define gerbil-ascent/program/view-replay#replay-group?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/view-replay#replay-group::t)))
    (define gerbil-ascent/program/view-replay#make-replay-group
      (lambda _%$args18292%_
        (apply make-instance
               gerbil-ascent/program/view-replay#replay-group::t
               _%$args18292%_)))
    (define gerbil-ascent/program/view-replay#replay-group-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'nodes)))
    (define gerbil-ascent/program/view-replay#replay-group-roots
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'roots)))
    (define gerbil-ascent/program/view-replay#replay-group-values
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'values)))
    (define gerbil-ascent/program/view-replay#replay-group-used
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'used)))
    (define gerbil-ascent/program/view-replay#replay-group-width
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'width)))
    (define gerbil-ascent/program/view-replay#replay-group-bits
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'bits)))
    (define gerbil-ascent/program/view-replay#replay-group-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'nodes)))
    (define gerbil-ascent/program/view-replay#replay-group-roots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'roots)))
    (define gerbil-ascent/program/view-replay#replay-group-values-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'values)))
    (define gerbil-ascent/program/view-replay#replay-group-used-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'used)))
    (define gerbil-ascent/program/view-replay#replay-group-width-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'width)))
    (define gerbil-ascent/program/view-replay#replay-group-bits-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'bits)))
    (define gerbil-ascent/program/view-replay#&replay-group-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'nodes)))
    (define gerbil-ascent/program/view-replay#&replay-group-roots
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'roots)))
    (define gerbil-ascent/program/view-replay#&replay-group-values
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'values)))
    (define gerbil-ascent/program/view-replay#&replay-group-used
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'used)))
    (define gerbil-ascent/program/view-replay#&replay-group-width
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'width)))
    (define gerbil-ascent/program/view-replay#&replay-group-bits
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-replay#replay-group::t
         'bits)))
    (define gerbil-ascent/program/view-replay#&replay-group-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'nodes)))
    (define gerbil-ascent/program/view-replay#&replay-group-roots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'roots)))
    (define gerbil-ascent/program/view-replay#&replay-group-values-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'values)))
    (define gerbil-ascent/program/view-replay#&replay-group-used-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'used)))
    (define gerbil-ascent/program/view-replay#&replay-group-width-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'width)))
    (define gerbil-ascent/program/view-replay#&replay-group-bits-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-replay#replay-group::t
         'bits)))
    (define gerbil-ascent/program/view-replay#root
      (lambda (_%n18290%_)
        (if (##structure-ref
             _%n18290%_
             '1
             gerbil-ascent/program/view-replay#replay-node::t
             '#f)
            (gerbil-ascent/program/view-replay#root
             (##structure-ref
              _%n18290%_
              '1
              gerbil-ascent/program/view-replay#replay-node::t
              '#f))
            _%n18290%_)))
    (define gerbil-ascent/program/view-replay#position
      (lambda (_%group18286%_ _%a18287%_ _%b18288%_)
        (let ((__tmp33830
               (let ((__tmp33831
                      (##structure-ref
                       _%group18286%_
                       '5
                       gerbil-ascent/program/view-replay#replay-group::t
                       '#f)))
                 (declare (not safe))
                 (##fx* _%a18287%_ __tmp33831))))
          (declare (not safe))
          (##fx+ __tmp33830 _%b18288%_))))
    (define gerbil-ascent/program/view-replay#reaches?
      (lambda (_%group18280%_ _%a18281%_ _%b18282%_)
        (let ((_%p18284%_
               (gerbil-ascent/program/view-replay#position
                _%group18280%_
                (car (##structure-ref
                      _%a18281%_
                      '2
                      gerbil-ascent/program/view-replay#replay-node::t
                      '#f))
                (car (##structure-ref
                      _%b18282%_
                      '2
                      gerbil-ascent/program/view-replay#replay-node::t
                      '#f)))))
          (not (let ((__tmp33832
                      (let ((__tmp33835
                             (u16vector-ref
                              (##structure-ref
                               _%group18280%_
                               '6
                               gerbil-ascent/program/view-replay#replay-group::t
                               '#f)
                              (let ()
                                (declare (not safe))
                                (##fxarithmetic-shift-right _%p18284%_ '4))))
                            (__tmp33833
                             (let ((__tmp33834
                                    (let ()
                                      (declare (not safe))
                                      (##fxand _%p18284%_ '15))))
                               (declare (not safe))
                               (##fxarithmetic-shift-left '1 __tmp33834))))
                        (declare (not safe))
                        (##fxand __tmp33835 __tmp33833))))
                 (declare (not safe))
                 (##fxzero? __tmp33832))))))
    (define gerbil-ascent/program/view-replay#mark!
      (lambda (_%group18267%_ _%a18268%_ _%b18269%_)
        (let* ((_%p18271%_
                (gerbil-ascent/program/view-replay#position
                 _%group18267%_
                 _%a18268%_
                 _%b18269%_))
               (_%word18273%_
                (let ()
                  (declare (not safe))
                  (##fxarithmetic-shift-right _%p18271%_ '4)))
               (_%mask18275%_
                (let ((__tmp33836
                       (let () (declare (not safe)) (##fxand _%p18271%_ '15))))
                  (declare (not safe))
                  (##fxarithmetic-shift-left '1 __tmp33836)))
               (_%bits18277%_
                (##structure-ref
                 _%group18267%_
                 '6
                 gerbil-ascent/program/view-replay#replay-group::t
                 '#f)))
          (u16vector-set!
           _%bits18277%_
           _%word18273%_
           (let ((__tmp33837 (u16vector-ref _%bits18277%_ _%word18273%_)))
             (declare (not safe))
             (##fxior __tmp33837 _%mask18275%_))))))
    (define gerbil-ascent/program/view-replay#fresh!
      (lambda (_%group18259%_ _%value18260%_)
        (let* ((_%id18262%_
                (##structure-ref
                 _%group18259%_
                 '4
                 gerbil-ascent/program/view-replay#replay-group::t
                 '#f))
               (_%n18264%_
                (let ((__tmp33838 (list _%id18262%_)))
                  (declare (not safe))
                  (##structure
                   gerbil-ascent/program/view-replay#replay-node::t
                   '#f
                   __tmp33838
                   '1))))
          (vector-set!
           (##structure-ref
            _%group18259%_
            '3
            gerbil-ascent/program/view-replay#replay-group::t
            '#f)
           _%id18262%_
           _%value18260%_)
          (##structure-set!
           _%group18259%_
           (+ _%id18262%_ '1)
           '4
           gerbil-ascent/program/view-replay#replay-group::t
           '#f)
          (let ((__tmp33839
                 (##structure-ref
                  _%group18259%_
                  '1
                  gerbil-ascent/program/view-replay#replay-group::t
                  '#f)))
            (declare (not safe))
            (hash-put! __tmp33839 _%value18260%_ _%n18264%_))
          (gerbil-ascent/program/view-replay#mark!
           _%group18259%_
           _%id18262%_
           _%id18262%_)
          _%n18264%_)))
    (define gerbil-ascent/program/view-replay#group-key
      (lambda (_%row18257%_)
        (list (length _%row18257%_)
              (if (= (length _%row18257%_) '3) (car _%row18257%_) '#f))))
    (define gerbil-ascent/program/view-replay#prepare
      (lambda (_%events18234%_ _%rows-of18235%_)
        (let ((_%sizes18237%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (for-each
           (lambda (_%event18239%_)
             (for-each
              (lambda (_%row18241%_)
                (let* ((_%key18243%_
                        (gerbil-ascent/program/view-replay#group-key
                         _%row18241%_))
                       (__tmp33840
                        (+ '1
                           (let ((_%$e18245%_
                                  (let ()
                                    (declare (not safe))
                                    (__hash-get _%sizes18237%_ _%key18243%_))))
                             (if _%$e18245%_ _%$e18245%_ '0)))))
                  (declare (not safe))
                  (__hash-put! _%sizes18237%_ _%key18243%_ __tmp33840)))
              (_%rows-of18235%_ _%event18239%_)))
           _%events18234%_)
          (if (let ((__tmp33842
                     (lambda (_%entry18248%_)
                       (and (let ((__tmp33843 (caar _%entry18248%_)))
                              (declare (not safe))
                              (##memq __tmp33843 '(2 3)))
                            (<= (cdr _%entry18248%_) '256))))
                    (__tmp33841
                     (let ()
                       (declare (not safe))
                       (__hash->list _%sizes18237%_))))
                (declare (not safe))
                (andmap__0 __tmp33842 __tmp33841))
              (let ((_%groups18250%_
                     (let ()
                       (declare (not safe))
                       (make-hash-table__%
                        '#f
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value))))
                (let ((__tmp33844
                       (lambda (_%key18252%_ _%size18253%_)
                         (let* ((_%width18255%_ (* '2 _%size18253%_))
                                (__tmp33845
                                 (let ((__tmp33848
                                        (let ()
                                          (declare (not safe))
                                          (make-hash-table__%
                                           '#f
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value)))
                                       (__tmp33847
                                        (make-vector _%width18255%_ '#f))
                                       (__tmp33846
                                        (make-u16vector
                                         (quotient
                                          (+ (* _%width18255%_ _%width18255%_)
                                             '15)
                                          '16)
                                         '0)))
                                   (declare (not safe))
                                   (##structure
                                    gerbil-ascent/program/view-replay#replay-group::t
                                    __tmp33848
                                    '()
                                    __tmp33847
                                    '0
                                    _%width18255%_
                                    __tmp33846))))
                           (declare (not safe))
                           (__hash-put!
                            _%groups18250%_
                            _%key18252%_
                            __tmp33845)))))
                  (declare (not safe))
                  (__hash-for-each __tmp33844 _%sizes18237%_))
                _%groups18250%_)
              '#f))))
    (define gerbil-ascent/program/view-replay#merge!
      (lambda (_%group18216%_ _%roots18217%_ _%cycle18218%_)
        (let* ((_%winner18223%_
                (let ((__tmp33851
                       (lambda (_%n18220%_ _%best18221%_)
                         (if (> (##structure-ref
                                 _%n18220%_
                                 '3
                                 gerbil-ascent/program/view-replay#replay-node::t
                                 '#f)
                                (##structure-ref
                                 _%best18221%_
                                 '3
                                 gerbil-ascent/program/view-replay#replay-node::t
                                 '#f))
                             _%n18220%_
                             _%best18221%_)))
                      (__tmp33850 (car _%cycle18218%_))
                      (__tmp33849 (cdr _%cycle18218%_)))
                  (declare (not safe))
                  (foldl__0 __tmp33851 __tmp33850 __tmp33849)))
               (_%members18225%_
                (##structure-ref
                 _%winner18223%_
                 '2
                 gerbil-ascent/program/view-replay#replay-node::t
                 '#f))
               (_%size18227%_
                (##structure-ref
                 _%winner18223%_
                 '3
                 gerbil-ascent/program/view-replay#replay-node::t
                 '#f)))
          (for-each
           (lambda (_%n18230%_)
             (if (eq? _%n18230%_ _%winner18223%_)
                 '#!void
                 (begin
                   (set! _%members18225%_
                         (append (##structure-ref
                                  _%n18230%_
                                  '2
                                  gerbil-ascent/program/view-replay#replay-node::t
                                  '#f)
                                 _%members18225%_))
                   (set! _%size18227%_
                         (+ _%size18227%_
                            (##structure-ref
                             _%n18230%_
                             '3
                             gerbil-ascent/program/view-replay#replay-node::t
                             '#f)))
                   (##structure-set!
                    _%n18230%_
                    _%winner18223%_
                    '1
                    gerbil-ascent/program/view-replay#replay-node::t
                    '#f))))
           _%cycle18218%_)
          (##structure-set!
           _%winner18223%_
           _%members18225%_
           '2
           gerbil-ascent/program/view-replay#replay-node::t
           '#f)
          (##structure-set!
           _%winner18223%_
           _%size18227%_
           '3
           gerbil-ascent/program/view-replay#replay-node::t
           '#f)
          (##structure-set!
           _%group18216%_
           (filter (lambda (_%n18232%_)
                     (not (##structure-ref
                           _%n18232%_
                           '1
                           gerbil-ascent/program/view-replay#replay-node::t
                           '#f)))
                   _%roots18217%_)
           '2
           gerbil-ascent/program/view-replay#replay-group::t
           '#f))))
    (define gerbil-ascent/program/view-replay#write-rights!
      (lambda (_%group18208%_
               _%prefix18209%_
               _%emit18210%_
               _%left18211%_
               _%rights18212%_)
        (if (null? _%rights18212%_)
            '#!void
            (begin
              (let ((_%right18214%_ (car _%rights18212%_)))
                (gerbil-ascent/program/view-replay#mark!
                 _%group18208%_
                 _%left18211%_
                 _%right18214%_)
                (if _%emit18210%_
                    (_%emit18210%_
                     (let ((__tmp33852
                            (list (vector-ref
                                   (##structure-ref
                                    _%group18208%_
                                    '3
                                    gerbil-ascent/program/view-replay#replay-group::t
                                    '#f)
                                   _%left18211%_)
                                  (vector-ref
                                   (##structure-ref
                                    _%group18208%_
                                    '3
                                    gerbil-ascent/program/view-replay#replay-group::t
                                    '#f)
                                   _%right18214%_))))
                       (declare (not safe))
                       (##append _%prefix18209%_ __tmp33852)))
                    '#!void))
              (gerbil-ascent/program/view-replay#write-rights!
               _%group18208%_
               _%prefix18209%_
               _%emit18210%_
               _%left18211%_
               (cdr _%rights18212%_))))))
    (define gerbil-ascent/program/view-replay#write-block!
      (lambda (_%group18202%_
               _%prefix18203%_
               _%emit18204%_
               _%lefts18205%_
               _%rights18206%_)
        (if (null? _%lefts18205%_)
            '#!void
            (begin
              (gerbil-ascent/program/view-replay#write-rights!
               _%group18202%_
               _%prefix18203%_
               _%emit18204%_
               (car _%lefts18205%_)
               _%rights18206%_)
              (gerbil-ascent/program/view-replay#write-block!
               _%group18202%_
               _%prefix18203%_
               _%emit18204%_
               (cdr _%lefts18205%_)
               _%rights18206%_)))))
    (define gerbil-ascent/program/view-replay#count-targets
      (lambda (_%group18195%_ _%p18196%_ _%succs18197%_ _%count18198%_)
        (if (null? _%succs18197%_)
            _%count18198%_
            (let ((_%s18200%_ (car _%succs18197%_)))
              (gerbil-ascent/program/view-replay#count-targets
               _%group18195%_
               _%p18196%_
               (cdr _%succs18197%_)
               (if (gerbil-ascent/program/view-replay#reaches?
                    _%group18195%_
                    _%p18196%_
                    _%s18200%_)
                   _%count18198%_
                   (let ((__tmp33853
                          (let ((__tmp33855
                                 (##structure-ref
                                  _%p18196%_
                                  '3
                                  gerbil-ascent/program/view-replay#replay-node::t
                                  '#f))
                                (__tmp33854
                                 (##structure-ref
                                  _%s18200%_
                                  '3
                                  gerbil-ascent/program/view-replay#replay-node::t
                                  '#f)))
                            (declare (not safe))
                            (##fx* __tmp33855 __tmp33854))))
                     (declare (not safe))
                     (##fx+ _%count18198%_ __tmp33853))))))))
    (define gerbil-ascent/program/view-replay#count-sources
      (lambda (_%group18190%_ _%preds18191%_ _%succs18192%_ _%count18193%_)
        (if (null? _%preds18191%_)
            _%count18193%_
            (gerbil-ascent/program/view-replay#count-sources
             _%group18190%_
             (cdr _%preds18191%_)
             _%succs18192%_
             (gerbil-ascent/program/view-replay#count-targets
              _%group18190%_
              (car _%preds18191%_)
              _%succs18192%_
              _%count18193%_)))))
    (define gerbil-ascent/program/view-replay#write-targets!
      (lambda (_%group18182%_
               _%p18183%_
               _%succs18184%_
               _%prefix18185%_
               _%emit18186%_)
        (if (null? _%succs18184%_)
            '#!void
            (begin
              (let ((_%s18188%_ (car _%succs18184%_)))
                (if (gerbil-ascent/program/view-replay#reaches?
                     _%group18182%_
                     _%p18183%_
                     _%s18188%_)
                    '#!void
                    (gerbil-ascent/program/view-replay#write-block!
                     _%group18182%_
                     _%prefix18185%_
                     _%emit18186%_
                     (##structure-ref
                      _%p18183%_
                      '2
                      gerbil-ascent/program/view-replay#replay-node::t
                      '#f)
                     (##structure-ref
                      _%s18188%_
                      '2
                      gerbil-ascent/program/view-replay#replay-node::t
                      '#f))))
              (gerbil-ascent/program/view-replay#write-targets!
               _%group18182%_
               _%p18183%_
               (cdr _%succs18184%_)
               _%prefix18185%_
               _%emit18186%_)))))
    (define gerbil-ascent/program/view-replay#write-sources!
      (lambda (_%group18176%_
               _%preds18177%_
               _%succs18178%_
               _%prefix18179%_
               _%emit18180%_)
        (if (null? _%preds18177%_)
            '#!void
            (begin
              (gerbil-ascent/program/view-replay#write-targets!
               _%group18176%_
               (car _%preds18177%_)
               _%succs18178%_
               _%prefix18179%_
               _%emit18180%_)
              (gerbil-ascent/program/view-replay#write-sources!
               _%group18176%_
               (cdr _%preds18177%_)
               _%succs18178%_
               _%prefix18179%_
               _%emit18180%_)))))
    (define gerbil-ascent/program/view-replay#collect-roots
      (lambda (_%roots18172%_ _%selected?18173%_ _%out18174%_)
        (if (null? _%roots18172%_)
            _%out18174%_
            (gerbil-ascent/program/view-replay#collect-roots
             (cdr _%roots18172%_)
             _%selected?18173%_
             (if (_%selected?18173%_ (car _%roots18172%_))
                 (cons (car _%roots18172%_) _%out18174%_)
                 _%out18174%_)))))
    (define gerbil-ascent/program/view-replay#insert!
      (lambda (_%group18123%_ _%row18124%_ _%budget18125%_ _%consume18126%_)
        (let* ((_%pair18128%_
                (if (= (length _%row18124%_) '3)
                    (cdr _%row18124%_)
                    _%row18124%_))
               (_%nodes18130%_
                (##structure-ref
                 _%group18123%_
                 '1
                 gerbil-ascent/program/view-replay#replay-group::t
                 '#f))
               (_%known-left18132%_
                (let ((__tmp33856 (car _%pair18128%_)))
                  (declare (not safe))
                  (hash-get _%nodes18130%_ __tmp33856)))
               (_%known-right18134%_
                (let ((__tmp33857 (cadr _%pair18128%_)))
                  (declare (not safe))
                  (hash-get _%nodes18130%_ __tmp33857)))
               (_%a18136%_
                (if _%known-left18132%_
                    (gerbil-ascent/program/view-replay#root
                     _%known-left18132%_)
                    (gerbil-ascent/program/view-replay#fresh!
                     _%group18123%_
                     (car _%pair18128%_))))
               (_%b18138%_
                (if (equal? (car _%pair18128%_) (cadr _%pair18128%_))
                    _%a18136%_
                    (if _%known-right18134%_
                        (gerbil-ascent/program/view-replay#root
                         _%known-right18134%_)
                        (gerbil-ascent/program/view-replay#fresh!
                         _%group18123%_
                         (cadr _%pair18128%_)))))
               (_%new18143%_
                (let ((__tmp33859
                       (if _%known-left18132%_ '() (list _%a18136%_)))
                      (__tmp33858
                       (if (or _%known-right18134%_
                               (eq? _%a18136%_ _%b18138%_))
                           '()
                           (list _%b18138%_))))
                  (declare (not safe))
                  (##append __tmp33859 __tmp33858)))
               (_%roots18145%_
                (append _%new18143%_
                        (##structure-ref
                         _%group18123%_
                         '2
                         gerbil-ascent/program/view-replay#replay-group::t
                         '#f)))
               (_%preds18149%_
                (gerbil-ascent/program/view-replay#collect-roots
                 _%roots18145%_
                 (lambda (_%p18147%_)
                   (gerbil-ascent/program/view-replay#reaches?
                    _%group18123%_
                    _%p18147%_
                    _%a18136%_))
                 '()))
               (_%succs18153%_
                (gerbil-ascent/program/view-replay#collect-roots
                 _%roots18145%_
                 (lambda (_%s18151%_)
                   (gerbil-ascent/program/view-replay#reaches?
                    _%group18123%_
                    _%b18138%_
                    _%s18151%_))
                 '()))
               (_%cycle18157%_
                (if (eq? _%a18136%_ _%b18138%_)
                    '#f
                    (if (gerbil-ascent/program/view-replay#reaches?
                         _%group18123%_
                         _%b18138%_
                         _%a18136%_)
                        (let ((__tmp33861
                               (lambda (_%p18155%_)
                                 (gerbil-ascent/program/view-replay#reaches?
                                  _%group18123%_
                                  _%b18138%_
                                  _%p18155%_)))
                              (__tmp33860 (reverse _%preds18149%_)))
                          (declare (not safe))
                          (##filter __tmp33861 __tmp33860))
                        '#f)))
               (_%needed18159%_
                (gerbil-ascent/program/view-replay#count-sources
                 _%group18123%_
                 _%preds18149%_
                 _%succs18153%_
                 (let () (declare (not safe)) (##length _%new18143%_))))
               (_%prefix18161%_
                (if (= (length _%row18124%_) '3)
                    (list (car _%row18124%_))
                    '()))
               (_%values18163%_
                (##structure-ref
                 _%group18123%_
                 '3
                 gerbil-ascent/program/view-replay#replay-group::t
                 '#f)))
          (if (> _%needed18159%_ _%budget18125%_)
              (let ()
                (declare (not safe))
                (error '"ASCENT trrel output fact budget exceeded"))
              '#!void)
          (let ((_%emit18166%_ (_%consume18126%_ _%needed18159%_)))
            (let ((__tmp33862
                   (lambda (_%n18168%_)
                     (if _%emit18166%_
                         (let ((_%v18170%_
                                (vector-ref
                                 _%values18163%_
                                 (car (##structure-ref
                                       _%n18168%_
                                       '2
                                       gerbil-ascent/program/view-replay#replay-node::t
                                       '#f)))))
                           (_%emit18166%_
                            (let ((__tmp33863 (list _%v18170%_ _%v18170%_)))
                              (declare (not safe))
                              (##append _%prefix18161%_ __tmp33863))))
                         '#!void))))
              (declare (not safe))
              (##for-each __tmp33862 _%new18143%_))
            (gerbil-ascent/program/view-replay#write-sources!
             _%group18123%_
             _%preds18149%_
             _%succs18153%_
             _%prefix18161%_
             _%emit18166%_))
          (##structure-set!
           _%group18123%_
           _%roots18145%_
           '2
           gerbil-ascent/program/view-replay#replay-group::t
           '#f)
          (if _%cycle18157%_
              (gerbil-ascent/program/view-replay#merge!
               _%group18123%_
               _%roots18145%_
               _%cycle18157%_)
              '#!void))))
    (define gerbil-ascent/program/view-replay#gerbil-ascent-small-journal-export
      (lambda (_%events18093%_
               _%kind-of18094%_
               _%rows-of18095%_
               _%budget18096%_
               _%skip18097%_
               _%delta?18098%_)
        (let ((_%groups18100%_
               (gerbil-ascent/program/view-replay#prepare
                _%events18093%_
                _%rows-of18095%_)))
          (if _%groups18100%_
              (let ((_%output18102%_ '()) (_%admitted18103%_ '0))
                (let ((__tmp33865
                       (lambda (_%event18105%_)
                         (let ((_%batch18107%_ '())
                               (_%derived?18108%_
                                (if _%delta?18098%_
                                    '#f
                                    (eq? (_%kind-of18094%_ _%event18105%_)
                                         'derived))))
                           (for-each
                            (lambda (_%row18110%_)
                              (gerbil-ascent/program/view-replay#insert!
                               (let ((__tmp33866
                                      (gerbil-ascent/program/view-replay#group-key
                                       _%row18110%_)))
                                 (declare (not safe))
                                 (__hash-get _%groups18100%_ __tmp33866))
                               _%row18110%_
                               _%budget18096%_
                               (lambda (_%needed18112%_)
                                 (let* ((_%next18114%_
                                         (+ _%admitted18103%_ _%needed18112%_))
                                        (_%$r18120%_
                                         (if (> _%next18114%_ _%skip18097%_)
                                             (begin
                                               (if (> _%skip18097%_
                                                      _%admitted18103%_)
                                                   (let ()
                                                     (declare (not safe))
                                                     (error '"ASCENT ordered delta splits an injection frontier"))
                                                   '#!void)
                                               (if _%derived?18108%_
                                                   (lambda (_%stored18116%_)
                                                     (set! _%batch18107%_
                                                           (cons _%stored18116%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%batch18107%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (lambda (_%stored18118%_)
                                                     (set! _%output18102%_
                                                           (cons _%stored18118%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%output18102%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             '#f)))
                                   (set! _%admitted18103%_ _%next18114%_)
                                   _%$r18120%_))))
                            (_%rows-of18095%_ _%event18105%_))
                           (if _%derived?18108%_
                               (set! _%output18102%_
                                     (append! (reverse! _%batch18107%_)
                                              _%output18102%_))
                               '#!void))))
                      (__tmp33864 (reverse _%events18093%_)))
                  (declare (not safe))
                  (##for-each __tmp33865 __tmp33864))
                (reverse! _%output18102%_))
              '#f))))))
