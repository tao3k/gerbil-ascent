(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/types::timestamp 1791691003)
  (begin
    (define gerbil-ascent/candidate/types#reasoning-snapshot::t
      (let ((__tmp35156 (list)) (__tmp35155 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/types#reasoning-snapshot::t
         'reasoning-snapshot
         __tmp35156
         '(identity generation digest relations)
         __tmp35155
         '#f)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/types#reasoning-snapshot::t)))
    (define gerbil-ascent/candidate/types#make-reasoning-snapshot
      (lambda _%$args26844%_
        (apply make-instance
               gerbil-ascent/candidate/types#reasoning-snapshot::t
               _%$args26844%_)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'identity)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'generation)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'digest)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot-relations
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'relations)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'identity)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'generation)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'digest)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot-relations-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'relations)))
    (define gerbil-ascent/candidate/types#&reasoning-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'identity)))
    (define gerbil-ascent/candidate/types#&reasoning-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'generation)))
    (define gerbil-ascent/candidate/types#&reasoning-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'digest)))
    (define gerbil-ascent/candidate/types#&reasoning-snapshot-relations
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'relations)))
    (define gerbil-ascent/candidate/types#&reasoning-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'identity)))
    (define gerbil-ascent/candidate/types#&reasoning-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'generation)))
    (define gerbil-ascent/candidate/types#&reasoning-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'digest)))
    (define gerbil-ascent/candidate/types#&reasoning-snapshot-relations-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'relations)))
    (define gerbil-ascent/candidate/types#reasoning-diagnostic::t
      (let ((__tmp35158 (list)) (__tmp35157 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'reasoning-diagnostic
         __tmp35158
         '(code path detail)
         __tmp35157
         '#f)))
    (define gerbil-ascent/candidate/types#reasoning-diagnostic?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/types#reasoning-diagnostic::t)))
    (define gerbil-ascent/candidate/types#make-reasoning-diagnostic
      (lambda _%$args26841%_
        (apply make-instance
               gerbil-ascent/candidate/types#reasoning-diagnostic::t
               _%$args26841%_)))
    (define gerbil-ascent/candidate/types#reasoning-diagnostic-code
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'code)))
    (define gerbil-ascent/candidate/types#reasoning-diagnostic-path
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'path)))
    (define gerbil-ascent/candidate/types#reasoning-diagnostic-detail
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'detail)))
    (define gerbil-ascent/candidate/types#reasoning-diagnostic-code-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'code)))
    (define gerbil-ascent/candidate/types#reasoning-diagnostic-path-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'path)))
    (define gerbil-ascent/candidate/types#reasoning-diagnostic-detail-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'detail)))
    (define gerbil-ascent/candidate/types#&reasoning-diagnostic-code
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'code)))
    (define gerbil-ascent/candidate/types#&reasoning-diagnostic-path
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'path)))
    (define gerbil-ascent/candidate/types#&reasoning-diagnostic-detail
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'detail)))
    (define gerbil-ascent/candidate/types#&reasoning-diagnostic-code-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'code)))
    (define gerbil-ascent/candidate/types#&reasoning-diagnostic-path-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'path)))
    (define gerbil-ascent/candidate/types#&reasoning-diagnostic-detail-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'detail)))
    (define gerbil-ascent/candidate/types#reasoning-candidate::t
      (let ((__tmp35160 (list)) (__tmp35159 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/types#reasoning-candidate::t
         'reasoning-candidate
         __tmp35160
         '(relations facts rules query limits)
         __tmp35159
         '#f)))
    (define gerbil-ascent/candidate/types#reasoning-candidate?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/types#reasoning-candidate::t)))
    (define gerbil-ascent/candidate/types#make-reasoning-candidate
      (lambda _%$args26838%_
        (apply make-instance
               gerbil-ascent/candidate/types#reasoning-candidate::t
               _%$args26838%_)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-relations
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'relations)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-facts
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'facts)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-rules
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'rules)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-query
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'query)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-limits
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'limits)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-relations-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'relations)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-facts-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'facts)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-rules-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'rules)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'query)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-limits-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'limits)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-relations
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'relations)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-facts
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'facts)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-rules
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'rules)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-query
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'query)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-limits
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'limits)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-relations-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'relations)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-facts-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'facts)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-rules-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'rules)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'query)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-limits-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'limits)))
    (define gerbil-ascent/candidate/types#candidate-rejection::t
      (let ((__tmp35162 (list)) (__tmp35161 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/types#candidate-rejection::t
         'candidate-rejection
         __tmp35162
         '(diagnostic)
         __tmp35161
         '#f)))
    (define gerbil-ascent/candidate/types#candidate-rejection?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/types#candidate-rejection::t)))
    (define gerbil-ascent/candidate/types#make-candidate-rejection
      (lambda _%$args26835%_
        (apply make-instance
               gerbil-ascent/candidate/types#candidate-rejection::t
               _%$args26835%_)))
    (define gerbil-ascent/candidate/types#candidate-rejection-diagnostic
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#candidate-rejection::t
         'diagnostic)))
    (define gerbil-ascent/candidate/types#candidate-rejection-diagnostic-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#candidate-rejection::t
         'diagnostic)))
    (define gerbil-ascent/candidate/types#&candidate-rejection-diagnostic
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#candidate-rejection::t
         'diagnostic)))
    (define gerbil-ascent/candidate/types#&candidate-rejection-diagnostic-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#candidate-rejection::t
         'diagnostic)))
    (define gerbil-ascent/candidate/types#+max-relations+ '64)
    (define gerbil-ascent/candidate/types#+max-rules+ '64)
    (define gerbil-ascent/candidate/types#+max-input-facts+ '1024)
    (define gerbil-ascent/candidate/types#+max-derived-facts+ '4096)
    (define gerbil-ascent/candidate/types#+max-output-facts+ '4096)
    (define gerbil-ascent/candidate/types#reasoning-snapshot-content-digest
      (lambda (_%identity26764%_ _%generation26765%_ _%relations26766%_)
        (let* ((_%bytes26786%_
                (let* ((_%bytes26770%_
                        (let ((__tmp35163
                               (call-with-output-string
                                '""
                                (lambda (_%port26768%_)
                                  (write (list 'reasoning-snapshot-v1
                                               _%identity26764%_
                                               _%generation26765%_
                                               _%relations26766%_)
                                         _%port26768%_)))))
                          (declare (not safe))
                          (##string->utf8 __tmp35163)))
                       (_%bytes26775%_ _%bytes26770%_))
                  (declare (not safe))
                  (std/crypto/digest#__sha256 _%bytes26775%_)))
               (_%start26789%_ '0)
               (_%end26792%_
                (let ()
                  (declare (not safe))
                  (##u8vector-length _%bytes26786%_)))
               (_%bytes26797%_ _%bytes26786%_))
          (if (and (let () (declare (not safe)) (##fx>= _%start26789%_ '0))
                   (let ((__tmp35164
                          (let ((__tmp35165
                                 (let ()
                                   (declare (not safe))
                                   (##u8vector-length _%bytes26797%_))))
                            (declare (not safe))
                            (##fxmax __tmp35165 '1))))
                     (declare (not safe))
                     (##fx< _%start26789%_ __tmp35164)))
              (let ((_%start26812%_ _%start26789%_))
                (if (let ((__tmp35166
                           (let ()
                             (declare (not safe))
                             (##u8vector-length _%bytes26797%_))))
                      (declare (not safe))
                      (##fx<= _%start26812%_ _%end26792%_ __tmp35166))
                    (let ((_%end26825%_ _%end26792%_))
                      (declare (not safe))
                      (std/encoding/hex#__hex-encode__%
                       _%bytes26797%_
                       _%start26812%_
                       _%end26825%_))
                    (begin
                      (raise-contract-violation-error
                       '"contract violation"
                       'context:
                       'gerbil-ascent/candidate/types
                       'contract:
                       '(in-range-inclusive? start (u8vector-length bytes))
                       'value:
                       _%end26792%_)
                      '#!void)))
              (begin
                (raise-contract-violation-error
                 '"contract violation"
                 'context:
                 'gerbil-ascent/candidate/types
                 'contract:
                 '(in-range? 0 (fxmax (u8vector-length bytes) 1))
                 'value:
                 _%start26789%_)
                '#!void)))))
    (define gerbil-ascent/candidate/types#snapshot-scalar?
      (lambda (_%value26753%_)
        (let ((_%$e26755%_ (exact-integer? _%value26753%_)))
          (if _%$e26755%_
              _%$e26755%_
              (let ((_%$e26758%_ (boolean? _%value26753%_)))
                (if _%$e26758%_
                    _%$e26758%_
                    (let ((_%$e26761%_ (symbol? _%value26753%_)))
                      (if _%$e26761%_
                          _%$e26761%_
                          (char? _%value26753%_)))))))))
    (define gerbil-ascent/candidate/types#snapshot-row-valid?
      (lambda (_%row26750%_ _%arity26751%_)
        (if (list? _%row26750%_)
            (if (= (let () (declare (not safe)) (##length _%row26750%_))
                   _%arity26751%_)
                (let ()
                  (declare (not safe))
                  (andmap__0
                   gerbil-ascent/candidate/types#snapshot-scalar?
                   _%row26750%_))
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/types#snapshot-relation-valid?
      (lambda (_%entry26744%_ _%names26745%_ _%remaining-facts26746%_)
        (if (list? _%entry26744%_)
            (if (= (let () (declare (not safe)) (##length _%entry26744%_)) '3)
                (if (symbol? (car _%entry26744%_))
                    (if (let ((__tmp35167 (car _%entry26744%_)))
                          (declare (not safe))
                          (hash-get _%names26745%_ __tmp35167))
                        '#f
                        (if (exact-integer? (cadr _%entry26744%_))
                            (if (<= '0 (cadr _%entry26744%_))
                                (if (list? (caddr _%entry26744%_))
                                    (if (<= (length (caddr _%entry26744%_))
                                            _%remaining-facts26746%_)
                                        (if (let ((__tmp35169
                                                   (lambda (_%row26748%_)
                                                     (gerbil-ascent/candidate/types#snapshot-row-valid?
                                                      _%row26748%_
                                                      (cadr _%entry26744%_))))
                                                  (__tmp35168
                                                   (caddr _%entry26744%_)))
                                              (declare (not safe))
                                              (andmap__0
                                               __tmp35169
                                               __tmp35168))
                                            (begin
                                              (let ((__tmp35170
                                                     (car _%entry26744%_)))
                                                (declare (not safe))
                                                (hash-put!
                                                 _%names26745%_
                                                 __tmp35170
                                                 '#t))
                                              '#t)
                                            '#f)
                                        '#f)
                                    '#f)
                                '#f)
                            '#f))
                    '#f)
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot-valid?
      (lambda (_%snapshot26733%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%snapshot26733%_
               'gerbil-ascent/candidate/types#reasoning-snapshot::t))
            (if (or (symbol? (let ()
                               (declare (not safe))
                               (##unchecked-structure-ref
                                _%snapshot26733%_
                                '1
                                '#f
                                '#f)))
                    (string? (let ()
                               (declare (not safe))
                               (##unchecked-structure-ref
                                _%snapshot26733%_
                                '1
                                '#f
                                '#f))))
                (if (exact-integer?
                     (let ()
                       (declare (not safe))
                       (##unchecked-structure-ref
                        _%snapshot26733%_
                        '2
                        '#f
                        '#f)))
                    (if (<= '0
                            (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%snapshot26733%_
                               '2
                               '#f
                               '#f)))
                        (let ((_%relations26738%_
                               (let ()
                                 (declare (not safe))
                                 (##unchecked-structure-ref
                                  _%snapshot26733%_
                                  '4
                                  '#f
                                  '#f)))
                              (_%names26739%_
                               (let ()
                                 (declare (not safe))
                                 (make-hash-table__%
                                  '#f
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value)))
                              (_%facts26740%_ '0))
                          (if (let ()
                                (declare (not safe))
                                (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                                 _%relations26738%_
                                 '131072
                                 '128))
                              (if (list? _%relations26738%_)
                                  (if (<= (let ()
                                            (declare (not safe))
                                            (##length _%relations26738%_))
                                          gerbil-ascent/candidate/types#+max-relations+)
                                      (if (let ((__tmp35171
                                                 (lambda (_%entry26742%_)
                                                   (and (gerbil-ascent/candidate/types#snapshot-relation-valid?
                                                         _%entry26742%_
                                                         _%names26739%_
                                                         (- gerbil-ascent/candidate/types#+max-input-facts+
                                                            _%facts26740%_))
                                                        (begin
                                                          (set! _%facts26740%_
                                                                (+ _%facts26740%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (length (caddr _%entry26742%_))))
                  '#t)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (declare (not safe))
                                            (andmap__0
                                             __tmp35171
                                             _%relations26738%_))
                                          (equal? (let ()
                                                    (declare (not safe))
                                                    (##unchecked-structure-ref
                                                     _%snapshot26733%_
                                                     '3
                                                     '#f
                                                     '#f))
                                                  (gerbil-ascent/candidate/types#reasoning-snapshot-content-digest
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%snapshot26733%_
                                                      '1
                                                      '#f
                                                      '#f))
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%snapshot26733%_
                                                      '2
                                                      '#f
                                                      '#f))
                                                   _%relations26738%_))
                                          '#f)
                                      '#f)
                                  '#f)
                              '#f))
                        '#f)
                    '#f)
                '#f)
            '#f)))))
