(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37367_|
    (##structure
     gx#syntax-quote::t
     'finite-rule::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37369_|
    (##structure
     gx#syntax-quote::t
     'make-finite-rule
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37371_|
    (##structure
     gx#syntax-quote::t
     'finite-rule?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37373_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37374_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-head
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37375_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-body
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37376_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-level
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37378_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37379_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-head-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37380_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-body-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37381_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-level-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37383_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37384_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-head
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37385_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-body
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37386_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-level
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37388_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37389_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-head-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37390_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-body-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37391_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-level-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37393_|
    (##structure
     gx#syntax-quote::t
     'finite-clause::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37395_|
    (##structure
     gx#syntax-quote::t
     'make-finite-clause
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37397_|
    (##structure
     gx#syntax-quote::t
     'finite-clause?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37399_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37400_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37401_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-apply
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37402_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-output
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37403_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-operator
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37405_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37406_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37407_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-apply-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37408_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-output-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37409_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-operator-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37411_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37412_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37413_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-apply
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37414_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-output
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37415_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-operator
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37417_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37418_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37419_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-apply-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37420_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-output-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37421_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-operator-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/finite-plan[:0:]#finite-rule|
      (let ((__obj37194
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37194
           'gerbil-ascent/candidate/finite-plan#finite-rule::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37194 'finite-rule '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37194
           '(relation head body level)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37194
           '(relation head body level)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37194 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37194 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37194 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37194 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37194 '#f '13 '#f '#f))
        (let ((__tmp37366 |gerbil-ascent/candidate/finite-plan[1]#_g37367_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37194 __tmp37366 '4 '#f '#f))
        (let ((__tmp37368 |gerbil-ascent/candidate/finite-plan[1]#_g37369_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37194 __tmp37368 '14 '#f '#f))
        (let ((__tmp37370 |gerbil-ascent/candidate/finite-plan[1]#_g37371_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37194 __tmp37370 '15 '#f '#f))
        (let ((__tmp37372
               (cons (cons 'relation
                           |gerbil-ascent/candidate/finite-plan[1]#_g37373_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37374_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37375_|)
                                 (cons (cons 'level
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37376_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37194 __tmp37372 '16 '#f '#f))
        (let ((__tmp37377
               (cons (cons 'relation
                           |gerbil-ascent/candidate/finite-plan[1]#_g37378_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37379_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37380_|)
                                 (cons (cons 'level
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37381_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37194 __tmp37377 '17 '#f '#f))
        (let ((__tmp37382
               (cons (cons 'relation
                           |gerbil-ascent/candidate/finite-plan[1]#_g37383_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37384_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37385_|)
                                 (cons (cons 'level
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37386_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37194 __tmp37382 '18 '#f '#f))
        (let ((__tmp37387
               (cons (cons 'relation
                           |gerbil-ascent/candidate/finite-plan[1]#_g37388_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37389_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37390_|)
                                 (cons (cons 'level
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37391_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37194 __tmp37387 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37194 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37194 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37194 '() '21 '#f '#f))
        __obj37194))
    (define |gerbil-ascent/candidate/finite-plan[:0:]#finite-clause|
      (let ((__obj37195
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37195
           'gerbil-ascent/candidate/finite-plan#finite-clause::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37195 'finite-clause '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37195
           '(kind relation apply output operator)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37195
           '(kind relation apply output operator)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37195 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37195 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37195 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37195 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37195 '#f '13 '#f '#f))
        (let ((__tmp37392 |gerbil-ascent/candidate/finite-plan[1]#_g37393_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37195 __tmp37392 '4 '#f '#f))
        (let ((__tmp37394 |gerbil-ascent/candidate/finite-plan[1]#_g37395_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37195 __tmp37394 '14 '#f '#f))
        (let ((__tmp37396 |gerbil-ascent/candidate/finite-plan[1]#_g37397_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37195 __tmp37396 '15 '#f '#f))
        (let ((__tmp37398
               (cons (cons 'kind
                           |gerbil-ascent/candidate/finite-plan[1]#_g37399_|)
                     (cons (cons 'relation
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37400_|)
                           (cons (cons 'apply
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37401_|)
                                 (cons (cons 'output
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37402_|)
                                       (cons (cons 'operator
                                                   |gerbil-ascent/candidate/finite-plan[1]#_g37403_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37195 __tmp37398 '16 '#f '#f))
        (let ((__tmp37404
               (cons (cons 'kind
                           |gerbil-ascent/candidate/finite-plan[1]#_g37405_|)
                     (cons (cons 'relation
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37406_|)
                           (cons (cons 'apply
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37407_|)
                                 (cons (cons 'output
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37408_|)
                                       (cons (cons 'operator
                                                   |gerbil-ascent/candidate/finite-plan[1]#_g37409_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37195 __tmp37404 '17 '#f '#f))
        (let ((__tmp37410
               (cons (cons 'kind
                           |gerbil-ascent/candidate/finite-plan[1]#_g37411_|)
                     (cons (cons 'relation
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37412_|)
                           (cons (cons 'apply
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37413_|)
                                 (cons (cons 'output
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37414_|)
                                       (cons (cons 'operator
                                                   |gerbil-ascent/candidate/finite-plan[1]#_g37415_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37195 __tmp37410 '18 '#f '#f))
        (let ((__tmp37416
               (cons (cons 'kind
                           |gerbil-ascent/candidate/finite-plan[1]#_g37417_|)
                     (cons (cons 'relation
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37418_|)
                           (cons (cons 'apply
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37419_|)
                                 (cons (cons 'output
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37420_|)
                                       (cons (cons 'operator
                                                   |gerbil-ascent/candidate/finite-plan[1]#_g37421_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37195 __tmp37416 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37195 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37195 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37195 '() '21 '#f '#f))
        __obj37195))))
