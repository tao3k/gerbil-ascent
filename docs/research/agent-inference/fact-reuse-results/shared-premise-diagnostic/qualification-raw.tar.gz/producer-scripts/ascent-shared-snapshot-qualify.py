import importlib.util,json,subprocess,sys,time,tarfile
from pathlib import Path
p=Path.cwd()/'tools/research/candidate-model.py'
spec=importlib.util.spec_from_file_location('consumer',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
run=m.ROOT/'.cache/ascent/candidate-interaction/shared-premise-snapshot-qualification';run.mkdir(exist_ok=True);assert not (run/'plan.json').exists()
old=m.ROOT/'.cache/ascent/candidate-interaction/reuse-study/plan.json';plan=json.loads(old.read_text());capture=json.loads((m.RUNTIME/'source-capture.json').read_text())
assert all(m.digest(m.ROOT/'.cache/ascent/shared-premise/source-snapshot'/name)==sha for name,sha in capture['sourceSha256'].items()),'live Library source changed'
m.save(run/'plan.json',{'consumerSha256':m.digest(p),'testSha256':m.digest(p.with_name('test_candidate_transport.py')),'binarySha256':m.digest(m.RUNTIME/'bin/candidate-interaction'),'taskPlanSha256':m.digest(old),'sourceCaptureSha256':m.digest(m.RUNTIME/'source-capture.json'),'iterations':3,'cases':[0,1],'modes':['native','dynamic-module','full-gxi'],'loadSeconds':{'native':20,'dynamic-module':60,'full-gxi':60},'rpcSeconds':20,'shutdownSeconds':5,'criteria':'Unchanged frozen tasks; ready rows and every Fact match independent judge; repeat packet proof nodes identical and ancestor-closed, build once; original contract checks remain enforced; no terminate/kill accepted as clean.'})
results=[]
for repeat in range(3):
    for label,mode in [('native',False),('dynamic-module','module'),('full-gxi',True)]:
        folder=run/f'{repeat}-{label}';folder.mkdir();c=None;entry={'repeat':repeat,'mode':label,'passed':False};began=time.monotonic()
        try:
            c=m.Consumer(folder,dynamic=mode)
            checks=[]
            for t in plan['tasks']:
                init=c.call(op='reuse-init',identity=t['id'],edges=t['edges'],needs=t['needs'])
                assert {x[0] for x in init['rows']}=={n[0] for n in t['needs'] if m.ready(t,n[0])}
                packets=[c.call(op='reuse-packet',fragments=list(range(12))) for _ in range(2)]
                assert packets[0]['facts']==packets[1]['facts'] and packets[0]['nodes']==packets[1]['nodes']
                for packet in packets:
                    assert packet['reused']
                    stats=dict(packet['stats']);assert stats['proof-builds']==1 and stats['hits']>=1
                    assert set(packet['allowed'])=={n[0] for n in t['needs'] if m.ready(t,n[0])}
                    ids={node[0] for node in packet['nodes']};assert all(parent in ids for node in packet['nodes'] for parent in node[5])
                    for fact in packet['facts']:
                        a=fact['atom'];truth=m.ready(t,a[1]) if a[0]=='ready' else m.reachable(t['edges'],*a[1:])
                        assert fact['present']==truth
                assert c.call(op='reuse-episode',atom=['path',0,7],premises=[['edge',0,2],['edge',2,4],['edge',4,6],['edge',6,7]])['supportQualified']
                assert not c.call(op='reuse-episode',atom=['path',0,7],premises=[['edge',1,3]])['supportQualified']
                checks.append({'case':t['case'] if 'case' in t else t['id'],'rows':len(init['rows']),'facts':len(packets[0]['facts']),'nodes':len(packets[0]['nodes']),'proofBuilds':dict(packets[-1]['stats'])['proof-builds']})
            entry.update(passed=True,checks=checks)
        except Exception as e: entry['failure']=str(e)
        finally:
            if c:
                entry['shutdown']=c.close();entry['passed']=entry['passed'] and entry['shutdown']['clean']
            entry['seconds']=time.monotonic()-began;results.append(entry);m.save(run/'receipt.json',results)
            print(json.dumps({'mode':label,'repeat':repeat,'passed':entry['passed'],'seconds':entry['seconds'],'failure':entry.get('failure')}),flush=True)
assert all(x['passed'] for x in results)
with (run/'transport-tests.log').open('w') as log:
    check=subprocess.run([sys.executable,'-W','error::ResourceWarning',str(p.with_name('test_candidate_transport.py'))],stdout=log,stderr=subprocess.STDOUT)
assert check.returncode==0
m.save(run/'test-receipt.json',{'exit':check.returncode,'tests':9})
assert m.digest(p)==json.loads((run/'plan.json').read_text())['consumerSha256']
print('LOAD_QUALIFICATION_OK',flush=True)
