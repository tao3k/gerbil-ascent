# SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
import unittest
from ascent_test_support.crosspath_branch import BranchQueue,parse_expansion
class BranchTests(unittest.TestCase):
    def test_native_rejection_does_not_admit_frontier(self):
        q=BranchQueue(2,[{'id':0,'stage':0},{'id':1,'stage':0},{'id':2,'stage':1}])
        self.assertEqual(q.next(),([],[0,1]));q.expand([],0,False)
        self.assertEqual(q.next(),([],[1]));q.expand([],1,True)
        self.assertEqual(q.next(),([1],[2]));q.expand([1],2,True)
        self.assertIsNone(q.next())
    def test_duplicate_or_unrelated_child_rejected(self):
        q=BranchQueue(2,[{'id':0,'stage':0},{'id':2,'stage':1}])
        with self.assertRaises(ValueError):q.expand([],2,True)
        q.expand([],0,True)
        with self.assertRaises(ValueError):q.expand([],0,True)
    def test_exact_single_action(self):
        good={'type':'function_call','name':'expand','arguments':'{"optionId":2}'}
        self.assertEqual(parse_expansion({'output':[good]},[2]),2)
        for output in ([],[good,good],[{**good,'arguments':'{"optionId":true}'}],[{**good,'arguments':'{"optionId":2,"extra":1}'}]):
            with self.assertRaises(ValueError):parse_expansion({'output':output},[2])
