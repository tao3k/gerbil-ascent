(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/closure-index::timestamp 1791687861)
  (begin
    (define gerbil-ascent/candidate/closure-index#closure-relation::t
      (let ((__tmp34016 (list)) (__tmp34015 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/closure-index#closure-relation::t
         'closure-relation
         __tmp34016
         '(rows members source)
         __tmp34015
         '#f)))
    (define gerbil-ascent/candidate/closure-index#closure-relation?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/closure-index#closure-relation::t)))
    (define gerbil-ascent/candidate/closure-index#make-closure-relation
      (lambda _%$args28596%_
        (apply make-instance
               gerbil-ascent/candidate/closure-index#closure-relation::t
               _%$args28596%_)))
    (define gerbil-ascent/candidate/closure-index#closure-relation-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'rows)))
    (define gerbil-ascent/candidate/closure-index#closure-relation-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'members)))
    (define gerbil-ascent/candidate/closure-index#closure-relation-source
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'source)))
    (define gerbil-ascent/candidate/closure-index#closure-relation-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'rows)))
    (define gerbil-ascent/candidate/closure-index#closure-relation-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'members)))
    (define gerbil-ascent/candidate/closure-index#closure-relation-source-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'source)))
    (define gerbil-ascent/candidate/closure-index#&closure-relation-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'rows)))
    (define gerbil-ascent/candidate/closure-index#&closure-relation-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'members)))
    (define gerbil-ascent/candidate/closure-index#&closure-relation-source
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'source)))
    (define gerbil-ascent/candidate/closure-index#&closure-relation-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'rows)))
    (define gerbil-ascent/candidate/closure-index#&closure-relation-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'members)))
    (define gerbil-ascent/candidate/closure-index#&closure-relation-source-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'source)))
    (define gerbil-ascent/candidate/closure-index#make-closure-index__%
      (lambda (_%closure28570%_ _%sources28571%_)
        (let ((_%index28573%_
               (let ((__tmp34017 (length _%closure28570%_)))
                 (declare (not safe))
                 (make-hash-table-eq 'size: __tmp34017))))
          (for-each
           (lambda (_%entry28575%_)
             (let* ((_%rows28577%_ (caddr _%entry28575%_))
                    (_%members28579%_
                     (let ((__tmp34018 (length _%rows28577%_)))
                       (declare (not safe))
                       (make-hash-table__%
                        '#f
                        __tmp34018
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value))))
               (for-each
                (lambda (_%row28582%_)
                  (let ()
                    (declare (not safe))
                    (__hash-put! _%members28579%_ _%row28582%_ '#t)))
                _%rows28577%_)
               (let ((__tmp34020 (car _%entry28575%_))
                     (__tmp34019
                      (let ()
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/closure-index#closure-relation::t
                         _%rows28577%_
                         _%members28579%_
                         '#f))))
                 (declare (not safe))
                 (__hash-put! _%index28573%_ __tmp34020 __tmp34019))))
           _%closure28570%_)
          (for-each
           (lambda (_%entry28584%_)
             (##structure-set!
              (gerbil-ascent/candidate/closure-index#closure-entry
               _%index28573%_
               (car _%entry28584%_))
              (list->vector (caddr _%entry28584%_))
              '3
              gerbil-ascent/candidate/closure-index#closure-relation::t
              '#f))
           _%sources28571%_)
          _%index28573%_)))
    (define gerbil-ascent/candidate/closure-index#make-closure-index__0
      (lambda (_%closure28589%_)
        (let ((_%sources28591%_ '()))
          (gerbil-ascent/candidate/closure-index#make-closure-index__%
           _%closure28589%_
           _%sources28591%_))))
    (define gerbil-ascent/candidate/closure-index#make-closure-index
      (lambda _g34021_
        (let ((_g34022_ (let () (declare (not safe)) (##length _g34021_))))
          (cond ((let () (declare (not safe)) (##fx= _g34022_ 1))
                 (apply gerbil-ascent/candidate/closure-index#make-closure-index__0
                        _g34021_))
                ((let () (declare (not safe)) (##fx= _g34022_ 2))
                 (apply gerbil-ascent/candidate/closure-index#make-closure-index__%
                        _g34021_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/candidate/closure-index#make-closure-index
                  _g34021_))))))
    (define gerbil-ascent/candidate/closure-index#closure-entry
      (lambda (_%index28563%_ _%name28564%_)
        (let ((_%$e28566%_
               (let ()
                 (declare (not safe))
                 (hash-get _%index28563%_ _%name28564%_))))
          (if _%$e28566%_
              _%$e28566%_
              (let ()
                (declare (not safe))
                (error '"candidate is missing inspected entry"
                       _%name28564%_))))))
    (define gerbil-ascent/candidate/closure-index#closure-index-rows
      (lambda (_%index28560%_ _%name28561%_)
        (##structure-ref
         (gerbil-ascent/candidate/closure-index#closure-entry
          _%index28560%_
          _%name28561%_)
         '1
         gerbil-ascent/candidate/closure-index#closure-relation::t
         '#f)))
    (define gerbil-ascent/candidate/closure-index#closure-index-member?
      (lambda (_%index28556%_ _%name28557%_ _%row28558%_)
        (if (let ((__tmp34023
                   (##structure-ref
                    (gerbil-ascent/candidate/closure-index#closure-entry
                     _%index28556%_
                     _%name28557%_)
                    '2
                    gerbil-ascent/candidate/closure-index#closure-relation::t
                    '#f)))
              (declare (not safe))
              (hash-get __tmp34023 _%row28558%_))
            '#t
            '#f)))
    (define gerbil-ascent/candidate/closure-index#closure-index-source
      (lambda (_%index28551%_ _%name28552%_)
        (let ((_%entry28554%_
               (let ()
                 (declare (not safe))
                 (hash-get _%index28551%_ _%name28552%_))))
          (if _%entry28554%_
              (##structure-ref
               _%entry28554%_
               '3
               gerbil-ascent/candidate/closure-index#closure-relation::t
               '#f)
              '#f))))))
