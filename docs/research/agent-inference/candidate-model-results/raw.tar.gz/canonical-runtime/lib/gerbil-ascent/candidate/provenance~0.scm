(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/provenance::timestamp 1791689704)
  (begin
    (define gerbil-ascent/candidate/provenance#positive-proof::t
      (let ((__tmp37228 (list)) (__tmp37227 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/provenance#positive-proof::t
         'positive-proof
         __tmp37228
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  query
                  work-budget
                  nodes
                  roots)
         __tmp37227
         '#f)))
    (define gerbil-ascent/candidate/provenance#positive-proof?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/provenance#positive-proof::t)))
    (define gerbil-ascent/candidate/provenance#make-positive-proof
      (lambda _%$args29417%_
        (apply make-instance
               gerbil-ascent/candidate/provenance#positive-proof::t
               _%$args29417%_)))
    (define gerbil-ascent/candidate/provenance#positive-proof-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'status)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/provenance#positive-proof-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/provenance#positive-proof-query
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'query)))
    (define gerbil-ascent/candidate/provenance#positive-proof-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'work-budget)))
    (define gerbil-ascent/candidate/provenance#positive-proof-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#positive-proof-roots
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'roots)))
    (define gerbil-ascent/candidate/provenance#positive-proof-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'status)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/provenance#positive-proof-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/provenance#positive-proof-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'query)))
    (define gerbil-ascent/candidate/provenance#positive-proof-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'work-budget)))
    (define gerbil-ascent/candidate/provenance#positive-proof-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#positive-proof-roots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'roots)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'status)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-query
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'query)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'work-budget)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-roots
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'roots)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'status)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'query)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'work-budget)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-roots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'roots)))
    (define gerbil-ascent/candidate/provenance#proof-node::t
      (let ((__tmp37230 (list)) (__tmp37229 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/provenance#proof-node::t
         'proof-node
         __tmp37230
         '(id kind relation row label inputs)
         __tmp37229
         '#f)))
    (define gerbil-ascent/candidate/provenance#proof-node?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/provenance#proof-node::t)))
    (define gerbil-ascent/candidate/provenance#make-proof-node
      (lambda _%$args29414%_
        (apply make-instance
               gerbil-ascent/candidate/provenance#proof-node::t
               _%$args29414%_)))
    (define gerbil-ascent/candidate/provenance#proof-node-id
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'id)))
    (define gerbil-ascent/candidate/provenance#proof-node-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'kind)))
    (define gerbil-ascent/candidate/provenance#proof-node-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#proof-node-row
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'row)))
    (define gerbil-ascent/candidate/provenance#proof-node-label
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'label)))
    (define gerbil-ascent/candidate/provenance#proof-node-inputs
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'inputs)))
    (define gerbil-ascent/candidate/provenance#proof-node-id-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'id)))
    (define gerbil-ascent/candidate/provenance#proof-node-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'kind)))
    (define gerbil-ascent/candidate/provenance#proof-node-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#proof-node-row-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'row)))
    (define gerbil-ascent/candidate/provenance#proof-node-label-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'label)))
    (define gerbil-ascent/candidate/provenance#proof-node-inputs-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'inputs)))
    (define gerbil-ascent/candidate/provenance#&proof-node-id
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'id)))
    (define gerbil-ascent/candidate/provenance#&proof-node-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'kind)))
    (define gerbil-ascent/candidate/provenance#&proof-node-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#&proof-node-row
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'row)))
    (define gerbil-ascent/candidate/provenance#&proof-node-label
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'label)))
    (define gerbil-ascent/candidate/provenance#&proof-node-inputs
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'inputs)))
    (define gerbil-ascent/candidate/provenance#&proof-node-id-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'id)))
    (define gerbil-ascent/candidate/provenance#&proof-node-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'kind)))
    (define gerbil-ascent/candidate/provenance#&proof-node-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#&proof-node-row-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'row)))
    (define gerbil-ascent/candidate/provenance#&proof-node-label-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'label)))
    (define gerbil-ascent/candidate/provenance#&proof-node-inputs-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'inputs)))
    (define gerbil-ascent/candidate/provenance#proof-relation::t
      (let ((__tmp37232 (list)) (__tmp37231 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/provenance#proof-relation::t
         'proof-relation
         __tmp37232
         '(nodes tail members)
         __tmp37231
         '#f)))
    (define gerbil-ascent/candidate/provenance#proof-relation?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/provenance#proof-relation::t)))
    (define gerbil-ascent/candidate/provenance#make-proof-relation
      (lambda _%$args29411%_
        (apply make-instance
               gerbil-ascent/candidate/provenance#proof-relation::t
               _%$args29411%_)))
    (define gerbil-ascent/candidate/provenance#proof-relation-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#proof-relation-tail
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'tail)))
    (define gerbil-ascent/candidate/provenance#proof-relation-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'members)))
    (define gerbil-ascent/candidate/provenance#proof-relation-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#proof-relation-tail-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'tail)))
    (define gerbil-ascent/candidate/provenance#proof-relation-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'members)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-tail
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'tail)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'members)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-tail-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'tail)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'members)))
    (define gerbil-ascent/candidate/provenance#positive-atom?
      (lambda (_%atom29409%_)
        (if (pair? _%atom29409%_)
            (if (symbol? (let () (declare (not safe)) (##car _%atom29409%_)))
                (not (let ((__tmp37233
                            (let ()
                              (declare (not safe))
                              (##car _%atom29409%_))))
                       (declare (not safe))
                       (##memq __tmp37233 '(not where compute reduce))))
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/provenance#positive-fixed-clause?
      (lambda (_%clause29398%_)
        (if (list? _%clause29398%_)
            (if (pair? _%clause29398%_)
                (let ((_%$e29400%_
                       (let () (declare (not safe)) (##car _%clause29398%_))))
                  (if (eq? 'where _%$e29400%_)
                      (if (= (let ()
                               (declare (not safe))
                               (##length _%clause29398%_))
                             '2)
                          (if (list? (cadr _%clause29398%_))
                              (if (pair? (cadr _%clause29398%_))
                                  (let ((_%$e29403%_ (caadr _%clause29398%_)))
                                    (if (eq? 'even? _%$e29403%_)
                                        (= (length (cadr _%clause29398%_)) '2)
                                        (if (eq? '< _%$e29403%_)
                                            (= (length (cadr _%clause29398%_))
                                               '3)
                                            '#f)))
                                  '#f)
                              '#f)
                          '#f)
                      (if (eq? 'compute _%$e29400%_)
                          (if (= (let ()
                                   (declare (not safe))
                                   (##length _%clause29398%_))
                                 '3)
                              (if (let ((__tmp37234 (cadr _%clause29398%_)))
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/program#candidate-variable?
                                     __tmp37234))
                                  (if (list? (caddr _%clause29398%_))
                                      (if (pair? (caddr _%clause29398%_))
                                          (let ((_%$e29406%_
                                                 (caaddr _%clause29398%_)))
                                            (if (eq? 'identity _%$e29406%_)
                                                (= (length (caddr _%clause29398%_))
                                                   '2)
                                                (if (eq? '+ _%$e29406%_)
                                                    (= (length (caddr _%clause29398%_))
                                                       '3)
                                                    '#f)))
                                          '#f)
                                      '#f)
                                  '#f)
                              '#f)
                          '#f)))
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/provenance#positive-rule-body?
      (lambda (_%rule29391%_)
        (let ((__tmp37236
               (lambda (_%clause29393%_)
                 (let ((_%$e29395%_
                        (gerbil-ascent/candidate/provenance#positive-atom?
                         _%clause29393%_)))
                   (if _%$e29395%_
                       _%$e29395%_
                       (gerbil-ascent/candidate/provenance#positive-fixed-clause?
                        _%clause29393%_)))))
              (__tmp37235 (vector-ref _%rule29391%_ '1)))
          (declare (not safe))
          (andmap__0 __tmp37236 __tmp37235))))
    (define gerbil-ascent/candidate/provenance#positive-rules?
      (lambda (_%spec29389%_)
        (let ((__tmp37237
               (##structure-ref
                _%spec29389%_
                '3
                gerbil-ascent/candidate/types#reasoning-candidate::t
                '#f)))
          (declare (not safe))
          (andmap__0
           gerbil-ascent/candidate/provenance#positive-rule-body?
           __tmp37237))))
    (define gerbil-ascent/candidate/provenance#instantiate-head
      (lambda (_%head29384%_ _%bindings29385%_)
        (map (lambda (_%term29387%_)
               (if (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/program#candidate-variable?
                      _%term29387%_))
                   (cdr (assq _%term29387%_ _%bindings29385%_))
                   _%term29387%_))
             (cdr _%head29384%_))))
    (define gerbil-ascent/candidate/provenance#candidate-positive-proof/option
      (lambda (_%snapshot29208%_
               _%spec29209%_
               _%candidate-digest29210%_
               _%native-status29211%_
               _%native-rows29212%_
               _%max-steps29213%_
               _%retain-closed-absence?29214%_)
        (if (and (exact-integer? _%max-steps29213%_) (> _%max-steps29213%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid positive proof work budget"
                     _%max-steps29213%_)))
        (let ((_%query29216%_
               (vector-ref
                (##structure-ref
                 _%spec29209%_
                 '4
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f)
                '0)))
          (letrec ((_%result29218%_
                    (lambda (_%status29380%_ _%nodes29381%_ _%roots29382%_)
                      (let ((__tmp37241
                             (##structure-ref
                              _%snapshot29208%_
                              '1
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp37240
                             (##structure-ref
                              _%snapshot29208%_
                              '2
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp37239
                             (##structure-ref
                              _%snapshot29208%_
                              '3
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp37238
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                _%query29216%_))))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/provenance#positive-proof::t
                         _%status29380%_
                         __tmp37241
                         __tmp37240
                         __tmp37239
                         _%candidate-digest29210%_
                         __tmp37238
                         _%max-steps29213%_
                         _%nodes29381%_
                         _%roots29382%_)))))
            (if (or (not (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                            _%snapshot29208%_)))
                    (not (eq? _%native-status29211%_ 'complete))
                    (not (gerbil-ascent/candidate/provenance#positive-rules?
                          _%spec29209%_)))
                (_%result29218%_ 'unsupported '() '())
                (let ((_%index29226%_
                       (let ()
                         (declare (not safe))
                         (make-hash-table__%
                          '#f
                          absent-value
                          absent-value
                          absent-value
                          absent-value
                          absent-value
                          absent-value
                          absent-value
                          absent-value)))
                      (_%plans29227%_
                       (map gerbil-ascent/candidate/grounding-plan#prepare-grounding-rule
                            (##structure-ref
                             _%spec29209%_
                             '3
                             gerbil-ascent/candidate/types#reasoning-candidate::t
                             '#f)))
                      (_%query-match29228%_
                       (let ()
                         (declare (not safe))
                         (gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
                          _%query29216%_)))
                      (_%nodes29229%_ '())
                      (_%next-id29230%_ '0)
                      (_%derived-count29231%_ '0)
                      (_%steps29232%_ '0)
                      (_%material29233%_
                       (if _%retain-closed-absence?29214%_
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/candidate/certificate-limits#make-certificate-material-budget))
                           '#f))
                      (_%bounded?29234%_ '#f)
                      (_%derived-limit29235%_
                       (cadr (##structure-ref
                              _%spec29209%_
                              '5
                              gerbil-ascent/candidate/types#reasoning-candidate::t
                              '#f))))
                  (letrec ((_%facts29237%_
                            (lambda (_%name29376%_)
                              (let ((_%relation29378%_
                                     (let ()
                                       (declare (not safe))
                                       (__hash-get
                                        _%index29226%_
                                        _%name29376%_))))
                                (if _%relation29378%_
                                    (##structure-ref
                                     _%relation29378%_
                                     '1
                                     gerbil-ascent/candidate/provenance#proof-relation::t
                                     '#f)
                                    '()))))
                           (_%active?29238%_
                            (lambda () (not _%bounded?29234%_)))
                           (_%known?29239%_
                            (lambda (_%name29370%_ _%row29371%_)
                              (let ((_%relation29373%_
                                     (let ()
                                       (declare (not safe))
                                       (__hash-get
                                        _%index29226%_
                                        _%name29370%_))))
                                (if _%relation29373%_
                                    (let ((__tmp37242
                                           (##structure-ref
                                            _%relation29373%_
                                            '3
                                            gerbil-ascent/candidate/provenance#proof-relation::t
                                            '#f)))
                                      (declare (not safe))
                                      (hash-get __tmp37242 _%row29371%_))
                                    '#f))))
                           (_%reserve-row!29240%_
                            (lambda (_%row29362%_)
                              (let ((_%$e29364%_ (not _%material29233%_)))
                                (if _%$e29364%_
                                    _%$e29364%_
                                    (let ((_%$e29367%_
                                           (let ()
                                             (declare (not safe))
                                             (gerbil-ascent/candidate/certificate-limits#certificate-material-reserve!
                                              _%material29233%_
                                              _%row29362%_))))
                                      (if _%$e29367%_
                                          _%$e29367%_
                                          (begin
                                            (set! _%bounded?29234%_ '#t)
                                            '#f)))))))
                           (_%install!29241%_
                            (lambda (_%node29348%_)
                              (let* ((_%name29350%_
                                      (##structure-ref
                                       _%node29348%_
                                       '3
                                       gerbil-ascent/candidate/provenance#proof-node::t
                                       '#f))
                                     (_%relation29357%_
                                      (let ((_%$e29352%_
                                             (let ()
                                               (declare (not safe))
                                               (__hash-get
                                                _%index29226%_
                                                _%name29350%_))))
                                        (if _%$e29352%_
                                            _%$e29352%_
                                            (let ((_%owned29355%_
                                                   (let ((__tmp37243
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (make-hash-table__%
                                                             '#f
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value))))
                                                     (declare (not safe))
                                                     (##structure
                                                      gerbil-ascent/candidate/provenance#proof-relation::t
                                                      '()
                                                      '#f
                                                      __tmp37243))))
                                              (let ()
                                                (declare (not safe))
                                                (__hash-put!
                                                 _%index29226%_
                                                 _%name29350%_
                                                 _%owned29355%_))
                                              _%owned29355%_))))
                                     (_%cell29359%_ (list _%node29348%_)))
                                (if (##structure-ref
                                     _%relation29357%_
                                     '2
                                     gerbil-ascent/candidate/provenance#proof-relation::t
                                     '#f)
                                    (set-cdr!
                                     (##structure-ref
                                      _%relation29357%_
                                      '2
                                      gerbil-ascent/candidate/provenance#proof-relation::t
                                      '#f)
                                     _%cell29359%_)
                                    (##structure-set!
                                     _%relation29357%_
                                     _%cell29359%_
                                     '1
                                     gerbil-ascent/candidate/provenance#proof-relation::t
                                     '#f))
                                (##structure-set!
                                 _%relation29357%_
                                 _%cell29359%_
                                 '2
                                 gerbil-ascent/candidate/provenance#proof-relation::t
                                 '#f)
                                (let ((__tmp37245
                                       (##structure-ref
                                        _%relation29357%_
                                        '3
                                        gerbil-ascent/candidate/provenance#proof-relation::t
                                        '#f))
                                      (__tmp37244
                                       (##structure-ref
                                        _%node29348%_
                                        '4
                                        gerbil-ascent/candidate/provenance#proof-node::t
                                        '#f)))
                                  (declare (not safe))
                                  (hash-put!
                                   __tmp37245
                                   __tmp37244
                                   _%node29348%_))
                                (set! _%nodes29229%_
                                      (cons _%node29348%_ _%nodes29229%_)))))
                           (_%add!29242%_
                            (lambda (_%kind29340%_
                                     _%name29341%_
                                     _%row29342%_
                                     _%label29343%_
                                     _%inputs29344%_)
                              (if (if _%bounded?29234%_
                                      '#f
                                      (if (_%known?29239%_
                                           _%name29341%_
                                           _%row29342%_)
                                          '#f
                                          (_%reserve-row!29240%_
                                           _%row29342%_)))
                                  (let ((_%node29346%_
                                         (let ((__tmp37247
                                                (let ()
                                                  (declare (not safe))
                                                  (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                                   _%row29342%_)))
                                               (__tmp37246
                                                (let ()
                                                  (declare (not safe))
                                                  (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                                   _%inputs29344%_))))
                                           (declare (not safe))
                                           (##structure
                                            gerbil-ascent/candidate/provenance#proof-node::t
                                            _%next-id29230%_
                                            _%kind29340%_
                                            _%name29341%_
                                            __tmp37247
                                            _%label29343%_
                                            __tmp37246))))
                                    (set! _%next-id29230%_
                                          (+ _%next-id29230%_ '1))
                                    (_%install!29241%_ _%node29346%_))
                                  '#!void))))
                    (let ((__tmp37249
                           (lambda (_%entry29244%_)
                             (let ((_%position29246%_ '0))
                               (let ((__tmp37251
                                      (lambda (_%row29248%_)
                                        (set! _%position29246%_
                                              (+ _%position29246%_ '1))
                                        (_%add!29242%_
                                         'source
                                         (car _%entry29244%_)
                                         _%row29248%_
                                         _%position29246%_
                                         '())))
                                     (__tmp37250 (caddr _%entry29244%_)))
                                 (declare (not safe))
                                 (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                                  _%active?29238%_
                                  __tmp37251
                                  __tmp37250)))))
                          (__tmp37248
                           (##structure-ref
                            _%snapshot29208%_
                            '4
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f)))
                      (declare (not safe))
                      (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                       _%active?29238%_
                       __tmp37249
                       __tmp37248))
                    (let ((__tmp37253
                           (lambda (_%fact29250%_)
                             (_%add!29242%_
                              'candidate
                              (vector-ref _%fact29250%_ '0)
                              (vector-ref _%fact29250%_ '1)
                              (vector-ref _%fact29250%_ '2)
                              '())))
                          (__tmp37252
                           (##structure-ref
                            _%spec29209%_
                            '2
                            gerbil-ascent/candidate/types#reasoning-candidate::t
                            '#f)))
                      (declare (not safe))
                      (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                       _%active?29238%_
                       __tmp37253
                       __tmp37252))
                    (let _%saturate29252%_ ()
                      (let ((_%pending29255%_ '())
                            (_%pending-count29256%_ '0)
                            (_%pending-index29257%_ '#f))
                        (let ((__tmp37254
                               (lambda (_%rule29259%_)
                                 (let ((_%rule29262%_ _%rule29259%_))
                                   (let ((_%name29279%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%rule29262%_
                                             '1
                                             '#f
                                             '#f)))
                                         (_%render29280%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%rule29262%_
                                             '2
                                             '#f
                                             '#f)))
                                         (_%body29281%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%rule29262%_
                                             '3
                                             '#f
                                             '#f)))
                                         (_%label29282%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%rule29262%_
                                             '4
                                             '#f
                                             '#f))))
                                     (letrec ((_%walk29284%_
                                               (lambda (_%remaining29286%_
                                                        _%bindings29287%_
                                                        _%inputs29288%_)
                                                 (if _%bounded?29234%_
                                                     '#!void
                                                     (if (null? _%remaining29286%_)
                                                         (let ((_%row29290%_
                                                                (_%render29280%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%bindings29287%_)))
                   (if (or (_%known?29239%_ _%name29279%_ _%row29290%_)
                           (let ((_%members29295%_
                                  (and _%pending-index29257%_
                                       (let ()
                                         (declare (not safe))
                                         (hash-get
                                          _%pending-index29257%_
                                          _%name29279%_)))))
                             (and _%members29295%_
                                  (let ()
                                    (declare (not safe))
                                    (hash-get
                                     _%members29295%_
                                     _%row29290%_)))))
                       '#!void
                       (begin
                         (if (>= (+ _%derived-count29231%_
                                    _%pending-count29256%_)
                                 _%derived-limit29235%_)
                             (set! _%bounded?29234%_ '#t)
                             '#!void)
                         (if (if _%bounded?29234%_
                                 '#f
                                 (_%reserve-row!29240%_ _%row29290%_))
                             (let* ((_%node29297%_
                                     (let ((__tmp37257
                                            (+ _%next-id29230%_
                                               _%pending-count29256%_))
                                           (__tmp37256
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                               _%row29290%_)))
                                           (__tmp37255
                                            (reverse _%inputs29288%_)))
                                       (declare (not safe))
                                       (##structure
                                        gerbil-ascent/candidate/provenance#proof-node::t
                                        __tmp37257
                                        'rule
                                        _%name29279%_
                                        __tmp37256
                                        _%label29282%_
                                        __tmp37255)))
                                    (_%members29304%_
                                     (let ((_%$e29299%_
                                            (if _%pending-index29257%_
                                                (let ()
                                                  (declare (not safe))
                                                  (hash-get
                                                   _%pending-index29257%_
                                                   _%name29279%_))
                                                '#f)))
                                       (if _%$e29299%_
                                           _%$e29299%_
                                           (let ((_%table29302%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (make-hash-table__%
                                                     '#f
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value))))
                                             (if _%pending-index29257%_
                                                 '#!void
                                                 (set! _%pending-index29257%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (make-hash-table-eq))))
                                             (let ()
                                               (declare (not safe))
                                               (hash-put!
                                                _%pending-index29257%_
                                                _%name29279%_
                                                _%table29302%_))
                                             _%table29302%_)))))
                               (let ((__tmp37258
                                      (let ()
                                        (declare (not safe))
                                        (##unchecked-structure-ref
                                         _%node29297%_
                                         '4
                                         '#f
                                         '#f))))
                                 (declare (not safe))
                                 (hash-put!
                                  _%members29304%_
                                  __tmp37258
                                  _%node29297%_))
                               (set! _%pending29255%_
                                     (cons _%node29297%_ _%pending29255%_))
                               (set! _%pending-count29256%_
                                     (+ _%pending-count29256%_ '1)))
                             '#!void))))
                 (let* ((_%clause29307%_ (car _%remaining29286%_))
                        (_%clause29309%_ _%clause29307%_))
                   (if (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%clause29309%_
                          '1
                          '#f
                          '#f))
                       (let ((__tmp37260
                              (lambda (_%node29324%_)
                                (if _%bounded?29234%_
                                    '#!void
                                    (begin
                                      (set! _%steps29232%_
                                            (+ _%steps29232%_ '1))
                                      (if (> _%steps29232%_ _%max-steps29213%_)
                                          (set! _%bounded?29234%_ '#t)
                                          (let ((_%next29326%_
                                                 ((let ()
                                                    (declare (not safe))
                                                    (##unchecked-structure-ref
                                                     _%clause29309%_
                                                     '2
                                                     '#f
                                                     '#f))
                                                  (##structure-ref
                                                   _%node29324%_
                                                   '4
                                                   gerbil-ascent/candidate/provenance#proof-node::t
                                                   '#f)
                                                  _%bindings29287%_)))
                                            (if _%next29326%_
                                                (_%walk29284%_
                                                 (cdr _%remaining29286%_)
                                                 _%next29326%_
                                                 (cons (##structure-ref
                                                        _%node29324%_
                                                        '1
                                                        gerbil-ascent/candidate/provenance#proof-node::t
                                                        '#f)
                                                       _%inputs29288%_))
                                                '#!void)))))))
                             (__tmp37259
                              (_%facts29237%_
                               (let ()
                                 (declare (not safe))
                                 (##unchecked-structure-ref
                                  _%clause29309%_
                                  '1
                                  '#f
                                  '#f)))))
                         (declare (not safe))
                         (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                          _%active?29238%_
                          __tmp37260
                          __tmp37259))
                       (begin
                         (set! _%steps29232%_ (+ _%steps29232%_ '1))
                         (if (> _%steps29232%_ _%max-steps29213%_)
                             (set! _%bounded?29234%_ '#t)
                             (let ((_%next29322%_
                                    ((let ()
                                       (declare (not safe))
                                       (##unchecked-structure-ref
                                        _%clause29309%_
                                        '2
                                        '#f
                                        '#f))
                                     _%bindings29287%_)))
                               (if _%next29322%_
                                   (_%walk29284%_
                                    (cdr _%remaining29286%_)
                                    _%next29322%_
                                    _%inputs29288%_)
                                   '#!void)))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                       (_%walk29284%_
                                        _%body29281%_
                                        '()
                                        '())))))))
                          (declare (not safe))
                          (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                           _%active?29238%_
                           __tmp37254
                           _%plans29227%_))
                        (if _%bounded?29234%_
                            (_%result29218%_ 'bounded '() '())
                            (if (null? _%pending29255%_)
                                (let* ((_%matching29330%_
                                        (filter (lambda (_%node29328%_)
                                                  (_%query-match29228%_
                                                   (##structure-ref
                                                    _%node29328%_
                                                    '4
                                                    gerbil-ascent/candidate/provenance#proof-node::t
                                                    '#f)
                                                   '()))
                                                (_%facts29237%_
                                                 (car _%query29216%_))))
                                       (_%rows29332%_
                                        (let ()
                                          (declare (not safe))
                                          (##map gerbil-ascent/candidate/provenance#proof-node-row
                                                 _%matching29330%_)))
                                       (_%roots29334%_
                                        (let ()
                                          (declare (not safe))
                                          (##map gerbil-ascent/candidate/provenance#proof-node-id
                                                 _%matching29330%_))))
                                  (if (and (pair? _%roots29334%_)
                                           (let ()
                                             (declare (not safe))
                                             (gerbil-ascent/candidate/funs#candidate-same-row-set?
                                              _%rows29332%_
                                              _%native-rows29212%_)))
                                      (_%result29218%_
                                       'complete
                                       (let ()
                                         (declare (not safe))
                                         (##reverse _%nodes29229%_))
                                       _%roots29334%_)
                                      (if (and _%retain-closed-absence?29214%_
                                               (null? _%roots29334%_)
                                               (null? _%native-rows29212%_))
                                          (_%result29218%_
                                           'closed-absent
                                           (let ()
                                             (declare (not safe))
                                             (##reverse _%nodes29229%_))
                                           '())
                                          (_%result29218%_
                                           'unsupported
                                           '()
                                           '()))))
                                (begin
                                  (let ((__tmp37261
                                         (let ()
                                           (declare (not safe))
                                           (##reverse _%pending29255%_))))
                                    (declare (not safe))
                                    (##for-each _%install!29241%_ __tmp37261))
                                  (set! _%next-id29230%_
                                        (+ _%next-id29230%_
                                           _%pending-count29256%_))
                                  (set! _%derived-count29231%_
                                        (+ _%derived-count29231%_
                                           _%pending-count29256%_))
                                  (_%saturate29252%_)))))))))))))
    (define gerbil-ascent/candidate/provenance#candidate-positive-proof
      (lambda (_%snapshot29201%_
               _%spec29202%_
               _%candidate-digest29203%_
               _%native-status29204%_
               _%native-rows29205%_
               _%max-steps29206%_)
        (gerbil-ascent/candidate/provenance#candidate-positive-proof/option
         _%snapshot29201%_
         _%spec29202%_
         _%candidate-digest29203%_
         _%native-status29204%_
         _%native-rows29205%_
         _%max-steps29206%_
         '#f)))
    (define gerbil-ascent/candidate/provenance#candidate-positive-closed-absence
      (lambda (_%snapshot29194%_
               _%spec29195%_
               _%candidate-digest29196%_
               _%native-status29197%_
               _%native-rows29198%_
               _%max-steps29199%_)
        (gerbil-ascent/candidate/provenance#candidate-positive-proof/option
         _%snapshot29194%_
         _%spec29195%_
         _%candidate-digest29196%_
         _%native-status29197%_
         _%native-rows29198%_
         _%max-steps29199%_
         '#t)))
    (define gerbil-ascent/candidate/provenance#proof-metadata-lookup
      (lambda (_%entries29142%_)
        (let* ((_%$%entries2914329153%_ _%entries29142%_)
               (_%$%else2914629167%_
                (lambda ()
                  (let ((_%index29161%_
                         (let ()
                           (declare (not safe))
                           (make-hash-table__%
                            '#f
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value))))
                    (for-each
                     (lambda (_%entry29163%_)
                       (if (let ((__tmp37262 (car _%entry29163%_)))
                             (declare (not safe))
                             (__hash-get _%index29161%_ __tmp37262))
                           '#!void
                           (let ((__tmp37264 (car _%entry29163%_))
                                 (__tmp37263 (cdr _%entry29163%_)))
                             (declare (not safe))
                             (__hash-put!
                              _%index29161%_
                              __tmp37264
                              __tmp37263))))
                     _%entries29142%_)
                    (lambda (_%key29165%_)
                      (let ()
                        (declare (not safe))
                        (__hash-get _%index29161%_ _%key29165%_)))))))
          (let ((_%$%K2915129191%_ (lambda () (lambda (_%_29189%_) '#f)))
                (_%$%K2914829175%_
                 (lambda (_%entry29171%_)
                   (lambda (_%key29173%_)
                     (if (equal? _%key29173%_ (car _%entry29171%_))
                         (cdr _%entry29171%_)
                         '#f)))))
            (let ((_%$%try-match2914529185%_
                   (lambda ()
                     (if (pair? _%$%entries2914329153%_)
                         (let ((_%$%tl2915029180%_
                                (let ()
                                  (declare (not safe))
                                  (##cdr _%$%entries2914329153%_)))
                               (_%$%hd2914929178%_
                                (let ()
                                  (declare (not safe))
                                  (##car _%$%entries2914329153%_))))
                           (if (null? _%$%tl2915029180%_)
                               (let ((_%entry29183%_ _%$%hd2914929178%_))
                                 (_%$%K2914829175%_ _%entry29183%_))
                               (_%$%else2914629167%_)))
                         (_%$%else2914629167%_)))))
              (if (null? _%$%entries2914329153%_)
                  (_%$%K2915129191%_)
                  (_%$%try-match2914529185%_)))))))
    (define gerbil-ascent/candidate/provenance#candidate-verify-positive-proof
      (lambda (_%snapshot29055%_
               _%spec29056%_
               _%candidate-digest29057%_
               _%native-status29058%_
               _%native-rows29059%_
               _%proof29060%_
               _%max-nodes29061%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%proof29060%_
               'gerbil-ascent/candidate/provenance#positive-proof::t))
            (if (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                   _%snapshot29055%_))
                (if (eq? (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%proof29060%_
                            '1
                            '#f
                            '#f))
                         'complete)
                    (if (eq? _%native-status29058%_ 'complete)
                        (if (gerbil-ascent/candidate/provenance#positive-rules?
                             _%spec29056%_)
                            (if (exact-integer? _%max-nodes29061%_)
                                (if (> _%max-nodes29061%_ '0)
                                    (if (equal? (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%proof29060%_
                                                   '2
                                                   '#f
                                                   '#f))
                                                (##structure-ref
                                                 _%snapshot29055%_
                                                 '1
                                                 gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                 '#f))
                                        (if (equal? (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%proof29060%_
                                                       '3
                                                       '#f
                                                       '#f))
                                                    (##structure-ref
                                                     _%snapshot29055%_
                                                     '2
                                                     gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                     '#f))
                                            (if (equal? (let ()
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           _%proof29060%_
                                                           '4
                                                           '#f
                                                           '#f))
                                                        (##structure-ref
                                                         _%snapshot29055%_
                                                         '3
                                                         gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                         '#f))
                                                (if (equal? (let ()
                                                              (declare
                                                                (not safe))
                                                              (##unchecked-structure-ref
                                                               _%proof29060%_
                                                               '5
                                                               '#f
                                                               '#f))
                                                            _%candidate-digest29057%_)
                                                    (if (equal? (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%proof29060%_
                           '6
                           '#f
                           '#f))
                        (vector-ref
                         (##structure-ref
                          _%spec29056%_
                          '4
                          gerbil-ascent/candidate/types#reasoning-candidate::t
                          '#f)
                         '0))
                (let* ((_%nodes29063%_
                        (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%proof29060%_
                           '8
                           '#f
                           '#f)))
                       (_%node-count29065%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                           _%nodes29063%_
                           _%max-nodes29061%_))))
                  (if _%node-count29065%_
                      (if (let ((__tmp37265
                                 (let ()
                                   (declare (not safe))
                                   (##unchecked-structure-ref
                                    _%proof29060%_
                                    '9
                                    '#f
                                    '#f))))
                            (declare (not safe))
                            (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                             __tmp37265
                             _%node-count29065%_))
                          (let* ((_%by-id29068%_
                                  (make-vector _%node-count29065%_ '#f))
                                 (_%arities29070%_
                                  (gerbil-ascent/candidate/provenance#proof-metadata-lookup
                                   (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/funs#candidate-schema-of
                                      _%snapshot29055%_
                                      _%spec29056%_))))
                                 (_%source29072%_
                                  (##structure-ref
                                   _%snapshot29055%_
                                   '4
                                   gerbil-ascent/candidate/types#reasoning-snapshot::t
                                   '#f))
                                 (_%facts29074%_
                                  (##structure-ref
                                   _%spec29056%_
                                   '2
                                   gerbil-ascent/candidate/types#reasoning-candidate::t
                                   '#f))
                                 (_%rules29076%_
                                  (##structure-ref
                                   _%spec29056%_
                                   '3
                                   gerbil-ascent/candidate/types#reasoning-candidate::t
                                   '#f))
                                 (_%query29078%_
                                  (let ()
                                    (declare (not safe))
                                    (##unchecked-structure-ref
                                     _%proof29060%_
                                     '6
                                     '#f
                                     '#f)))
                                 (_%source-rows29082%_
                                  (gerbil-ascent/candidate/provenance#proof-metadata-lookup
                                   (map (lambda (_%entry29080%_)
                                          (cons (car _%entry29080%_)
                                                (list->vector
                                                 (caddr _%entry29080%_))))
                                        _%source29072%_)))
                                 (_%fact-keys29084%_
                                  (if (pair? _%facts29074%_)
                                      (let ()
                                        (declare (not safe))
                                        (make-hash-table__%
                                         '#f
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value))
                                      '#f))
                                 (_%rule-labels29088%_
                                  (gerbil-ascent/candidate/provenance#proof-metadata-lookup
                                   (map (lambda (_%rule29086%_)
                                          (cons (vector-ref _%rule29086%_ '2)
                                                (cons _%rule29086%_
                                                      (let ((__tmp37266
                                                             (filter gerbil-ascent/candidate/provenance#positive-atom?
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (vector-ref _%rule29086%_ '1))))
                (declare (not safe))
                (##length __tmp37266)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        _%rules29076%_))))
                            (for-each
                             (lambda (_%fact29091%_)
                               (let ((__tmp37267
                                      (list (vector-ref _%fact29091%_ '2)
                                            (vector-ref _%fact29091%_ '0)
                                            (vector-ref _%fact29091%_ '1))))
                                 (declare (not safe))
                                 (hash-put!
                                  _%fact-keys29084%_
                                  __tmp37267
                                  '#t)))
                             _%facts29074%_)
                            (letrec ((_%existing-input?29093%_
                                      (lambda (_%id29139%_ _%before29140%_)
                                        (if (exact-integer? _%id29139%_)
                                            (if (<= '0 _%id29139%_)
                                                (< _%id29139%_ _%before29140%_)
                                                '#f)
                                            '#f)))
                                     (_%node-valid?29094%_
                                      (lambda (_%node29108%_ _%index29109%_)
                                        (if (let ()
                                              (declare (not safe))
                                              (##structure-instance-of?
                                               _%node29108%_
                                               'gerbil-ascent/candidate/provenance#proof-node::t))
                                            (if (exact-integer?
                                                 (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%node29108%_
                                                    '1
                                                    '#f
                                                    '#f)))
                                                (if (= (let ()
                                                         (declare (not safe))
                                                         (##unchecked-structure-ref
                                                          _%node29108%_
                                                          '1
                                                          '#f
                                                          '#f))
                                                       _%index29109%_)
                                                    (if (symbol? (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%node29108%_
                            '3
                            '#f
                            '#f)))
                (if (let ((_%arity29111%_
                           (let ((__tmp37268
                                  (let ()
                                    (declare (not safe))
                                    (##unchecked-structure-ref
                                     _%node29108%_
                                     '3
                                     '#f
                                     '#f))))
                             (declare (not safe))
                             (_%arities29070%_ __tmp37268))))
                      (and _%arity29111%_
                           (equal? (let ((__tmp37269
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%node29108%_
                                             '4
                                             '#f
                                             '#f))))
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                                      __tmp37269
                                      _%arity29111%_))
                                   _%arity29111%_)))
                    (let ((_%$e29113%_
                           (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%node29108%_
                              '2
                              '#f
                              '#f))))
                      (if (eq? 'source _%$e29113%_)
                          (if (null? (let ()
                                       (declare (not safe))
                                       (##unchecked-structure-ref
                                        _%node29108%_
                                        '6
                                        '#f
                                        '#f)))
                              (let ((_%rows29116%_
                                     (let ((__tmp37270
                                            (let ()
                                              (declare (not safe))
                                              (##unchecked-structure-ref
                                               _%node29108%_
                                               '3
                                               '#f
                                               '#f))))
                                       (declare (not safe))
                                       (_%source-rows29082%_ __tmp37270))))
                                (if _%rows29116%_
                                    (if (exact-integer?
                                         (let ()
                                           (declare (not safe))
                                           (##unchecked-structure-ref
                                            _%node29108%_
                                            '5
                                            '#f
                                            '#f)))
                                        (if (<= '1
                                                (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%node29108%_
                                                   '5
                                                   '#f
                                                   '#f)))
                                            (if (<= (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%node29108%_
                                                       '5
                                                       '#f
                                                       '#f))
                                                    (vector-length
                                                     _%rows29116%_))
                                                (equal? (let ()
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           _%node29108%_
                                                           '4
                                                           '#f
                                                           '#f))
                                                        (vector-ref
                                                         _%rows29116%_
                                                         (- (let ()
                                                              (declare
                                                                (not safe))
                                                              (##unchecked-structure-ref
                                                               _%node29108%_
                                                               '5
                                                               '#f
                                                               '#f))
                                                            '1)))
                                                '#f)
                                            '#f)
                                        '#f)
                                    '#f))
                              '#f)
                          (if (eq? 'candidate _%$e29113%_)
                              (if (null? (let ()
                                           (declare (not safe))
                                           (##unchecked-structure-ref
                                            _%node29108%_
                                            '6
                                            '#f
                                            '#f)))
                                  (if _%fact-keys29084%_
                                      (let ((__tmp37271
                                             (list (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%node29108%_
                                                      '5
                                                      '#f
                                                      '#f))
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%node29108%_
                                                      '3
                                                      '#f
                                                      '#f))
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%node29108%_
                                                      '4
                                                      '#f
                                                      '#f)))))
                                        (declare (not safe))
                                        (__hash-get
                                         _%fact-keys29084%_
                                         __tmp37271))
                                      '#f)
                                  '#f)
                              (if (eq? 'rule _%$e29113%_)
                                  (let* ((_%entry29118%_
                                          (let ((__tmp37272
                                                 (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%node29108%_
                                                    '5
                                                    '#f
                                                    '#f))))
                                            (declare (not safe))
                                            (_%rule-labels29088%_ __tmp37272)))
                                         (_%rule29120%_
                                          (if _%entry29118%_
                                              (car _%entry29118%_)
                                              '#f)))
                                    (if _%rule29120%_
                                        (if (eq? (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%node29108%_
                                                    '3
                                                    '#f
                                                    '#f))
                                                 (car (vector-ref
                                                       _%rule29120%_
                                                       '0)))
                                            (if (equal? (let ((__tmp37274
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (##unchecked-structure-ref _%node29108%_ '6 '#f '#f)))
                      (__tmp37273 (cdr _%entry29118%_)))
                  (declare (not safe))
                  (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                   __tmp37274
                   __tmp37273))
                (cdr _%entry29118%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (let _%loop29123%_ ((_%clauses29125%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (vector-ref _%rule29120%_ '1))
                            (_%inputs29126%_
                             (let ()
                               (declare (not safe))
                               (##unchecked-structure-ref
                                _%node29108%_
                                '6
                                '#f
                                '#f)))
                            (_%bindings29127%_ '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (null? _%clauses29125%_)
                                                      (if (null? _%inputs29126%_)
                                                          (equal? (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (declare (not safe))
                            (##unchecked-structure-ref
                             _%node29108%_
                             '4
                             '#f
                             '#f))
                          (gerbil-ascent/candidate/provenance#instantiate-head
                           (vector-ref _%rule29120%_ '0)
                           _%bindings29127%_))
                  '#f)
              (let ((_%clause29129%_ (car _%clauses29125%_)))
                (if (gerbil-ascent/candidate/provenance#positive-fixed-clause?
                     _%clause29129%_)
                    (let ((_%next29131%_
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/candidate/funs#candidate-fixed-clause
                              _%clause29129%_
                              _%bindings29127%_))))
                      (if _%next29131%_
                          (_%loop29123%_
                           (cdr _%clauses29125%_)
                           _%inputs29126%_
                           _%next29131%_)
                          '#f))
                    (let ((_%id29133%_ (car _%inputs29126%_)))
                      (if (_%existing-input?29093%_ _%id29133%_ _%index29109%_)
                          (let ((_%input29135%_
                                 (vector-ref _%by-id29068%_ _%id29133%_)))
                            (if (eq? (##structure-ref
                                      _%input29135%_
                                      '3
                                      gerbil-ascent/candidate/provenance#proof-node::t
                                      '#f)
                                     (car _%clause29129%_))
                                (let ((_%next29137%_
                                       (let ((__tmp37275
                                              (##structure-ref
                                               _%input29135%_
                                               '4
                                               gerbil-ascent/candidate/provenance#proof-node::t
                                               '#f)))
                                         (declare (not safe))
                                         (gerbil-ascent/candidate/funs#candidate-bind-atom
                                          _%clause29129%_
                                          __tmp37275
                                          _%bindings29127%_))))
                                  (if _%next29137%_
                                      (_%loop29123%_
                                       (cdr _%clauses29125%_)
                                       (cdr _%inputs29126%_)
                                       _%next29137%_)
                                      '#f))
                                '#f))
                          '#f))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                '#f)
                                            '#f)
                                        '#f))
                                  '#f))))
                    '#f)
                '#f)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '#f)
                                                '#f)
                                            '#f))))
                              (if (let _%loop29096%_ ((_%remaining29098%_
                                                       _%nodes29063%_)
                                                      (_%index29099%_ '0))
                                    (or (null? _%remaining29098%_)
                                        (and (_%node-valid?29094%_
                                              (car _%remaining29098%_)
                                              _%index29099%_)
                                             (begin
                                               (vector-set!
                                                _%by-id29068%_
                                                _%index29099%_
                                                (car _%remaining29098%_))
                                               (_%loop29096%_
                                                (cdr _%remaining29098%_)
                                                (+ _%index29099%_ '1))))))
                                  (if (let ((__tmp37277
                                             (lambda (_%id29104%_)
                                               (and (_%existing-input?29093%_
                                                     _%id29104%_
                                                     _%node-count29065%_)
                                                    (eq? (##structure-ref
                                                          (vector-ref
                                                           _%by-id29068%_
                                                           _%id29104%_)
                                                          '3
                                                          gerbil-ascent/candidate/provenance#proof-node::t
                                                          '#f)
                                                         (car _%query29078%_))
                                                    (let ((__tmp37278
                                                           (##structure-ref
                                                            (vector-ref
                                                             _%by-id29068%_
                                                             _%id29104%_)
                                                            '4
                                                            gerbil-ascent/candidate/provenance#proof-node::t
                                                            '#f)))
                                                      (declare (not safe))
                                                      (gerbil-ascent/candidate/funs#candidate-bind-atom
                                                       _%query29078%_
                                                       __tmp37278
                                                       '())))))
                                            (__tmp37276
                                             (let ()
                                               (declare (not safe))
                                               (##unchecked-structure-ref
                                                _%proof29060%_
                                                '9
                                                '#f
                                                '#f))))
                                        (declare (not safe))
                                        (andmap__0 __tmp37277 __tmp37276))
                                      (let ((__tmp37279
                                             (map (lambda (_%id29106%_)
                                                    (##structure-ref
                                                     (vector-ref
                                                      _%by-id29068%_
                                                      _%id29106%_)
                                                     '4
                                                     gerbil-ascent/candidate/provenance#proof-node::t
                                                     '#f))
                                                  (let ()
                                                    (declare (not safe))
                                                    (##unchecked-structure-ref
                                                     _%proof29060%_
                                                     '9
                                                     '#f
                                                     '#f)))))
                                        (declare (not safe))
                                        (gerbil-ascent/candidate/funs#candidate-same-row-set?
                                         __tmp37279
                                         _%native-rows29059%_))
                                      '#f)
                                  '#f)))
                          '#f)
                      '#f))
                '#f)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '#f)
                                                '#f)
                                            '#f)
                                        '#f)
                                    '#f)
                                '#f)
                            '#f)
                        '#f)
                    '#f)
                '#f)
            '#f)))))
