(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/closure-index[1]#_g34625_|
    (##structure
     gx#syntax-quote::t
     'closure-relation::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34627_|
    (##structure
     gx#syntax-quote::t
     'make-closure-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34629_|
    (##structure
     gx#syntax-quote::t
     'closure-relation?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34631_|
    (##structure
     gx#syntax-quote::t
     'closure-relation-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34632_|
    (##structure
     gx#syntax-quote::t
     'closure-relation-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34633_|
    (##structure
     gx#syntax-quote::t
     'closure-relation-source
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34635_|
    (##structure
     gx#syntax-quote::t
     'closure-relation-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34636_|
    (##structure
     gx#syntax-quote::t
     'closure-relation-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34637_|
    (##structure
     gx#syntax-quote::t
     'closure-relation-source-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34639_|
    (##structure
     gx#syntax-quote::t
     '&closure-relation-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34640_|
    (##structure
     gx#syntax-quote::t
     '&closure-relation-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34641_|
    (##structure
     gx#syntax-quote::t
     '&closure-relation-source
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34643_|
    (##structure
     gx#syntax-quote::t
     '&closure-relation-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34644_|
    (##structure
     gx#syntax-quote::t
     '&closure-relation-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34645_|
    (##structure
     gx#syntax-quote::t
     '&closure-relation-source-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[:0:]#closure-relation|
    (let ((__obj34475
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34475
         'gerbil-ascent/candidate/closure-index#closure-relation::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34475 'closure-relation '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34475
         '(rows members source)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34475
         '(rows members source)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34475 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34475 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34475 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34475 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34475 '#f '13 '#f '#f))
      (let ((__tmp34624 |gerbil-ascent/candidate/closure-index[1]#_g34625_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34475 __tmp34624 '4 '#f '#f))
      (let ((__tmp34626 |gerbil-ascent/candidate/closure-index[1]#_g34627_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34475 __tmp34626 '14 '#f '#f))
      (let ((__tmp34628 |gerbil-ascent/candidate/closure-index[1]#_g34629_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34475 __tmp34628 '15 '#f '#f))
      (let ((__tmp34630
             (cons (cons 'rows
                         |gerbil-ascent/candidate/closure-index[1]#_g34631_|)
                   (cons (cons 'members
                               |gerbil-ascent/candidate/closure-index[1]#_g34632_|)
                         (cons (cons 'source
                                     |gerbil-ascent/candidate/closure-index[1]#_g34633_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34475 __tmp34630 '16 '#f '#f))
      (let ((__tmp34634
             (cons (cons 'rows
                         |gerbil-ascent/candidate/closure-index[1]#_g34635_|)
                   (cons (cons 'members
                               |gerbil-ascent/candidate/closure-index[1]#_g34636_|)
                         (cons (cons 'source
                                     |gerbil-ascent/candidate/closure-index[1]#_g34637_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34475 __tmp34634 '17 '#f '#f))
      (let ((__tmp34638
             (cons (cons 'rows
                         |gerbil-ascent/candidate/closure-index[1]#_g34639_|)
                   (cons (cons 'members
                               |gerbil-ascent/candidate/closure-index[1]#_g34640_|)
                         (cons (cons 'source
                                     |gerbil-ascent/candidate/closure-index[1]#_g34641_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34475 __tmp34638 '18 '#f '#f))
      (let ((__tmp34642
             (cons (cons 'rows
                         |gerbil-ascent/candidate/closure-index[1]#_g34643_|)
                   (cons (cons 'members
                               |gerbil-ascent/candidate/closure-index[1]#_g34644_|)
                         (cons (cons 'source
                                     |gerbil-ascent/candidate/closure-index[1]#_g34645_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34475 __tmp34642 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34475 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34475 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34475 '() '21 '#f '#f))
      __obj34475)))
