(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33850_|
    (##structure
     gx#syntax-quote::t
     'lattice-round::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33852_|
    (##structure
     gx#syntax-quote::t
     'make-lattice-round
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33854_|
    (##structure
     gx#syntax-quote::t
     'lattice-round?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33856_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-table
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33857_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-changes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33858_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-sequence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33859_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-ordered?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33861_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-table-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33862_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-changes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33863_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-sequence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33864_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-ordered?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33866_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-table
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33867_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-changes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33868_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-sequence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33869_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-ordered?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33871_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-table-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33872_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-changes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33873_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-sequence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33874_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-ordered?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33876_|
    (##structure
     gx#syntax-quote::t
     'lattice-change::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33878_|
    (##structure
     gx#syntax-quote::t
     'make-lattice-change
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33880_|
    (##structure
     gx#syntax-quote::t
     'lattice-change?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33882_|
    (##structure
     gx#syntax-quote::t
     'lattice-change-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33883_|
    (##structure
     gx#syntax-quote::t
     'lattice-change-sequence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33885_|
    (##structure
     gx#syntax-quote::t
     'lattice-change-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33886_|
    (##structure
     gx#syntax-quote::t
     'lattice-change-sequence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33888_|
    (##structure
     gx#syntax-quote::t
     '&lattice-change-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33889_|
    (##structure
     gx#syntax-quote::t
     '&lattice-change-sequence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33891_|
    (##structure
     gx#syntax-quote::t
     '&lattice-change-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33892_|
    (##structure
     gx#syntax-quote::t
     '&lattice-change-sequence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33894_|
    (gx#core-deserialize-mark
     '(0
       (id . _%id15689%_)
       (arg . _%arg15752%_)
       ($%arg15664 . _%$%arg1566415722%_)
       ($%arg15665 . _%$%arg1566515736%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33895_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33894_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33898_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33899_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33898_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33901_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33898_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33903_|
    (gx#core-deserialize-mark
     '(0
       (id . _%id15809%_)
       (arg . _%arg15872%_)
       ($%arg15785 . _%$%arg1578515842%_)
       ($%arg15786 . _%$%arg1578615856%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33904_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33903_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33907_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33908_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33907_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33910_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33907_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33912_|
    (gx#core-deserialize-mark
     '(0
       (id . _%id15929%_)
       ($%arg15905 . _%$%arg1590515962%_)
       (arg . _%arg15992%_)
       ($%arg15906 . _%$%arg1590615976%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33913_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33912_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33916_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33917_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33916_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33919_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33916_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33921_|
    (gx#core-deserialize-mark
     '(0
       ($%arg16026 . _%$%arg1602616096%_)
       (id . _%id16049%_)
       ($%arg16025 . _%$%arg1602516082%_)
       (arg . _%arg16112%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33922_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33921_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33925_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33926_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33925_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33928_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33925_|)))
  (begin
    (define |gerbil-ascent/program/lattice-frontier[:0:]#lattice-round|
      (let ((__obj33793
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33793
           'gerbil-ascent/program/lattice-frontier#lattice-round::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33793 'lattice-round '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33793
           '(table changes sequence ordered?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33793
           '(table changes sequence ordered?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33793 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33793 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33793 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33793 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33793 '#f '13 '#f '#f))
        (let ((__tmp33849
               |gerbil-ascent/program/lattice-frontier[1]#_g33850_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33793 __tmp33849 '4 '#f '#f))
        (let ((__tmp33851
               |gerbil-ascent/program/lattice-frontier[1]#_g33852_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33793 __tmp33851 '14 '#f '#f))
        (let ((__tmp33853
               |gerbil-ascent/program/lattice-frontier[1]#_g33854_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33793 __tmp33853 '15 '#f '#f))
        (let ((__tmp33855
               (cons (cons 'table
                           |gerbil-ascent/program/lattice-frontier[1]#_g33856_|)
                     (cons (cons 'changes
                                 |gerbil-ascent/program/lattice-frontier[1]#_g33857_|)
                           (cons (cons 'sequence
                                       |gerbil-ascent/program/lattice-frontier[1]#_g33858_|)
                                 (cons (cons 'ordered?
                                             |gerbil-ascent/program/lattice-frontier[1]#_g33859_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33793 __tmp33855 '16 '#f '#f))
        (let ((__tmp33860
               (cons (cons 'table
                           |gerbil-ascent/program/lattice-frontier[1]#_g33861_|)
                     (cons (cons 'changes
                                 |gerbil-ascent/program/lattice-frontier[1]#_g33862_|)
                           (cons (cons 'sequence
                                       |gerbil-ascent/program/lattice-frontier[1]#_g33863_|)
                                 (cons (cons 'ordered?
                                             |gerbil-ascent/program/lattice-frontier[1]#_g33864_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33793 __tmp33860 '17 '#f '#f))
        (let ((__tmp33865
               (cons (cons 'table
                           |gerbil-ascent/program/lattice-frontier[1]#_g33866_|)
                     (cons (cons 'changes
                                 |gerbil-ascent/program/lattice-frontier[1]#_g33867_|)
                           (cons (cons 'sequence
                                       |gerbil-ascent/program/lattice-frontier[1]#_g33868_|)
                                 (cons (cons 'ordered?
                                             |gerbil-ascent/program/lattice-frontier[1]#_g33869_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33793 __tmp33865 '18 '#f '#f))
        (let ((__tmp33870
               (cons (cons 'table
                           |gerbil-ascent/program/lattice-frontier[1]#_g33871_|)
                     (cons (cons 'changes
                                 |gerbil-ascent/program/lattice-frontier[1]#_g33872_|)
                           (cons (cons 'sequence
                                       |gerbil-ascent/program/lattice-frontier[1]#_g33873_|)
                                 (cons (cons 'ordered?
                                             |gerbil-ascent/program/lattice-frontier[1]#_g33874_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33793 __tmp33870 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33793 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33793 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33793 '() '21 '#f '#f))
        __obj33793))
    (define |gerbil-ascent/program/lattice-frontier[:0:]#lattice-change|
      (let ((__obj33794
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33794
           'gerbil-ascent/program/lattice-frontier#lattice-change::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33794 'lattice-change '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33794 '(row sequence) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33794 '(row sequence) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33794 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33794 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33794 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33794 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33794 '#f '13 '#f '#f))
        (let ((__tmp33875
               |gerbil-ascent/program/lattice-frontier[1]#_g33876_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33794 __tmp33875 '4 '#f '#f))
        (let ((__tmp33877
               |gerbil-ascent/program/lattice-frontier[1]#_g33878_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33794 __tmp33877 '14 '#f '#f))
        (let ((__tmp33879
               |gerbil-ascent/program/lattice-frontier[1]#_g33880_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33794 __tmp33879 '15 '#f '#f))
        (let ((__tmp33881
               (cons (cons 'row
                           |gerbil-ascent/program/lattice-frontier[1]#_g33882_|)
                     (cons (cons 'sequence
                                 |gerbil-ascent/program/lattice-frontier[1]#_g33883_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33794 __tmp33881 '16 '#f '#f))
        (let ((__tmp33884
               (cons (cons 'row
                           |gerbil-ascent/program/lattice-frontier[1]#_g33885_|)
                     (cons (cons 'sequence
                                 |gerbil-ascent/program/lattice-frontier[1]#_g33886_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33794 __tmp33884 '17 '#f '#f))
        (let ((__tmp33887
               (cons (cons 'row
                           |gerbil-ascent/program/lattice-frontier[1]#_g33888_|)
                     (cons (cons 'sequence
                                 |gerbil-ascent/program/lattice-frontier[1]#_g33889_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33794 __tmp33887 '18 '#f '#f))
        (let ((__tmp33890
               (cons (cons 'row
                           |gerbil-ascent/program/lattice-frontier[1]#_g33891_|)
                     (cons (cons 'sequence
                                 |gerbil-ascent/program/lattice-frontier[1]#_g33892_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33794 __tmp33890 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33794 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33794 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33794 '() '21 '#f '#f))
        __obj33794))
    (define |gerbil-ascent/program/lattice-frontier[:0:]#@lattice-frontier-ref|
      (lambda (_%$stx15646%_)
        (let* ((_%__stx3369033691%_ _%$stx15646%_)
               (_%$%g1565115672%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3369033691%_)))))
          (let ((_%__kont3369333694%_
                 (lambda (_%$%g1565315738%_)
                   (cons (let ((__tmp33893
                                |gerbil-ascent/program/lattice-frontier[1]#_g33895_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp33893
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'frontier))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'key))
                                                 '()))
                                     (cons (let ((__tmp33896
                                                  (lambda (_%$%g1575315756%_
                                                           _%$%g1575415759%_)
                                                    (cons _%$%g1575315756%_
                                                          _%$%g1575415759%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp33896
                                              '()
                                              _%$%g1565315738%_))
                                           '()))
                               (cons (cons (let ((__tmp33897
                                                  |gerbil-ascent/program/lattice-frontier[1]#_g33899_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp33897
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'frontier))
                     (cons (let ((__tmp33900
                                  |gerbil-ascent/program/lattice-frontier[1]#_g33901_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp33900 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'lattice-round))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f '__lattice-frontier-ref))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'frontier))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'key))
                                 '())))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3369733698%_
                 (lambda (_%$%g1566615679%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0 '#f 'lattice-frontier-ref)))))
            (let* ((_%$%g1565015691%_
                    (lambda ()
                      (let ((_%$%g1566615679%_ _%__stx3369033691%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1566615679%_))
                            (_%__kont3369733698%_ _%$%g1566615679%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1565115672%_))))))
                   (_%__match3371333714%_
                    (lambda (_%$%e1565415698%_
                             _%$%hd1565515702%_
                             _%$%tl1565615705%_
                             _%__splice3369533696%_
                             _%$%target1565715708%_
                             _%$%tl1565915711%_)
                      (letrec ((_%$%loop1566015714%_
                                (lambda (_%$%hd1565815718%_
                                         _%$%arg1566415721%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1565815718%_))
                                      (let ((_%$%e1566115724%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1565815718%_))))
                                        (let ((_%$%lp-tl1566315731%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1566115724%_)))
                                              (_%$%lp-hd1566215728%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1566115724%_))))
                                          (_%$%loop1566015714%_
                                           _%$%lp-tl1566315731%_
                                           (cons _%$%lp-hd1566215728%_
                                                 _%$%arg1566415721%_))))
                                      (let ((_%$%arg1566515734%_
                                             (reverse _%$%arg1566415721%_)))
                                        (_%__kont3369333694%_
                                         _%$%arg1566515734%_))))))
                        (_%$%loop1566015714%_ _%$%target1565715708%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3369033691%_))
                  (let ((_%$%e1565415698%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3369033691%_))))
                    (let ((_%$%tl1565615705%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1565415698%_)))
                          (_%$%hd1565515702%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1565415698%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1565615705%_))
                          (let ((_%__splice3369533696%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1565615705%_
                                    '0))))
                            (let ((_%$%tl1565915711%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3369533696%_ '1)))
                                  (_%$%target1565715708%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3369533696%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1565915711%_))
                                  (_%__match3371333714%_
                                   _%$%e1565415698%_
                                   _%$%hd1565515702%_
                                   _%$%tl1565615705%_
                                   _%__splice3369533696%_
                                   _%$%target1565715708%_
                                   _%$%tl1565915711%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1565015691%_)))))
                          (let () (declare (not safe)) (_%$%g1565015691%_)))))
                  (let () (declare (not safe)) (_%$%g1565015691%_))))))))
    (define |gerbil-ascent/program/lattice-frontier[:0:]#@lattice-frontier-stage!|
      (lambda (_%$stx15767%_)
        (let* ((_%__stx3371633717%_ _%$stx15767%_)
               (_%$%g1577215793%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3371633717%_)))))
          (let ((_%__kont3371933720%_
                 (lambda (_%$%g1577415858%_)
                   (cons (let ((__tmp33902
                                |gerbil-ascent/program/lattice-frontier[1]#_g33904_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp33902
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'frontier))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'key))
                                                 (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'row))
                                                       '())))
                                     (cons (let ((__tmp33905
                                                  (lambda (_%$%g1587315876%_
                                                           _%$%g1587415879%_)
                                                    (cons _%$%g1587315876%_
                                                          _%$%g1587415879%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp33905
                                              '()
                                              _%$%g1577415858%_))
                                           '()))
                               (cons (cons (let ((__tmp33906
                                                  |gerbil-ascent/program/lattice-frontier[1]#_g33908_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp33906
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'frontier))
                     (cons (let ((__tmp33909
                                  |gerbil-ascent/program/lattice-frontier[1]#_g33910_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp33909 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'lattice-round))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f '__lattice-frontier-stage!))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'frontier))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'key))
                                 (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'row))
                                       '()))))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3372333724%_
                 (lambda (_%$%g1578715800%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0 '#f 'lattice-frontier-stage!)))))
            (let* ((_%$%g1577115811%_
                    (lambda ()
                      (let ((_%$%g1578715800%_ _%__stx3371633717%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1578715800%_))
                            (_%__kont3372333724%_ _%$%g1578715800%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1577215793%_))))))
                   (_%__match3373933740%_
                    (lambda (_%$%e1577515818%_
                             _%$%hd1577615822%_
                             _%$%tl1577715825%_
                             _%__splice3372133722%_
                             _%$%target1577815828%_
                             _%$%tl1578015831%_)
                      (letrec ((_%$%loop1578115834%_
                                (lambda (_%$%hd1577915838%_
                                         _%$%arg1578515841%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1577915838%_))
                                      (let ((_%$%e1578215844%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1577915838%_))))
                                        (let ((_%$%lp-tl1578415851%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1578215844%_)))
                                              (_%$%lp-hd1578315848%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1578215844%_))))
                                          (_%$%loop1578115834%_
                                           _%$%lp-tl1578415851%_
                                           (cons _%$%lp-hd1578315848%_
                                                 _%$%arg1578515841%_))))
                                      (let ((_%$%arg1578615854%_
                                             (reverse _%$%arg1578515841%_)))
                                        (_%__kont3371933720%_
                                         _%$%arg1578615854%_))))))
                        (_%$%loop1578115834%_ _%$%target1577815828%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3371633717%_))
                  (let ((_%$%e1577515818%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3371633717%_))))
                    (let ((_%$%tl1577715825%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1577515818%_)))
                          (_%$%hd1577615822%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1577515818%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1577715825%_))
                          (let ((_%__splice3372133722%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1577715825%_
                                    '0))))
                            (let ((_%$%tl1578015831%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3372133722%_ '1)))
                                  (_%$%target1577815828%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3372133722%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1578015831%_))
                                  (_%__match3373933740%_
                                   _%$%e1577515818%_
                                   _%$%hd1577615822%_
                                   _%$%tl1577715825%_
                                   _%__splice3372133722%_
                                   _%$%target1577815828%_
                                   _%$%tl1578015831%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1577115811%_)))))
                          (let () (declare (not safe)) (_%$%g1577115811%_)))))
                  (let () (declare (not safe)) (_%$%g1577115811%_))))))))
    (define |gerbil-ascent/program/lattice-frontier[:0:]#@lattice-frontier-rows|
      (lambda (_%$stx15887%_)
        (let* ((_%__stx3374233743%_ _%$stx15887%_)
               (_%$%g1589215913%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3374233743%_)))))
          (let ((_%__kont3374533746%_
                 (lambda (_%$%g1589415978%_)
                   (cons (let ((__tmp33911
                                |gerbil-ascent/program/lattice-frontier[1]#_g33913_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp33911
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'frontier))
                                           '())
                                     (cons (let ((__tmp33914
                                                  (lambda (_%$%g1599315996%_
                                                           _%$%g1599415999%_)
                                                    (cons _%$%g1599315996%_
                                                          _%$%g1599415999%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp33914
                                              '()
                                              _%$%g1589415978%_))
                                           '()))
                               (cons (cons (let ((__tmp33915
                                                  |gerbil-ascent/program/lattice-frontier[1]#_g33917_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp33915
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'frontier))
                     (cons (let ((__tmp33918
                                  |gerbil-ascent/program/lattice-frontier[1]#_g33919_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp33918 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'lattice-round))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f '__lattice-frontier-rows))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'frontier))
                           '()))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3374933750%_
                 (lambda (_%$%g1590715920%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0 '#f 'lattice-frontier-rows)))))
            (let* ((_%$%g1589115931%_
                    (lambda ()
                      (let ((_%$%g1590715920%_ _%__stx3374233743%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1590715920%_))
                            (_%__kont3374933750%_ _%$%g1590715920%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1589215913%_))))))
                   (_%__match3376533766%_
                    (lambda (_%$%e1589515938%_
                             _%$%hd1589615942%_
                             _%$%tl1589715945%_
                             _%__splice3374733748%_
                             _%$%target1589815948%_
                             _%$%tl1590015951%_)
                      (letrec ((_%$%loop1590115954%_
                                (lambda (_%$%hd1589915958%_
                                         _%$%arg1590515961%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1589915958%_))
                                      (let ((_%$%e1590215964%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1589915958%_))))
                                        (let ((_%$%lp-tl1590415971%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1590215964%_)))
                                              (_%$%lp-hd1590315968%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1590215964%_))))
                                          (_%$%loop1590115954%_
                                           _%$%lp-tl1590415971%_
                                           (cons _%$%lp-hd1590315968%_
                                                 _%$%arg1590515961%_))))
                                      (let ((_%$%arg1590615974%_
                                             (reverse _%$%arg1590515961%_)))
                                        (_%__kont3374533746%_
                                         _%$%arg1590615974%_))))))
                        (_%$%loop1590115954%_ _%$%target1589815948%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3374233743%_))
                  (let ((_%$%e1589515938%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3374233743%_))))
                    (let ((_%$%tl1589715945%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1589515938%_)))
                          (_%$%hd1589615942%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1589515938%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1589715945%_))
                          (let ((_%__splice3374733748%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1589715945%_
                                    '0))))
                            (let ((_%$%tl1590015951%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3374733748%_ '1)))
                                  (_%$%target1589815948%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3374733748%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1590015951%_))
                                  (_%__match3376533766%_
                                   _%$%e1589515938%_
                                   _%$%hd1589615942%_
                                   _%$%tl1589715945%_
                                   _%__splice3374733748%_
                                   _%$%target1589815948%_
                                   _%$%tl1590015951%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1589115931%_)))))
                          (let () (declare (not safe)) (_%$%g1589115931%_)))))
                  (let () (declare (not safe)) (_%$%g1589115931%_))))))))
    (define |gerbil-ascent/program/lattice-frontier[:0:]#@lattice-frontier-clear!|
      (lambda (_%$stx16007%_)
        (let* ((_%__stx3376833769%_ _%$stx16007%_)
               (_%$%g1601216033%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3376833769%_)))))
          (let ((_%__kont3377133772%_
                 (lambda (_%$%g1601416098%_)
                   (cons (let ((__tmp33920
                                |gerbil-ascent/program/lattice-frontier[1]#_g33922_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp33920
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'frontier))
                                           '())
                                     (cons (let ((__tmp33923
                                                  (lambda (_%$%g1611316116%_
                                                           _%$%g1611416119%_)
                                                    (cons _%$%g1611316116%_
                                                          _%$%g1611416119%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp33923
                                              '()
                                              _%$%g1601416098%_))
                                           '()))
                               (cons (cons (let ((__tmp33924
                                                  |gerbil-ascent/program/lattice-frontier[1]#_g33926_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp33924
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'frontier))
                     (cons (let ((__tmp33927
                                  |gerbil-ascent/program/lattice-frontier[1]#_g33928_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp33927 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'lattice-round))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f '__lattice-frontier-clear!))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'frontier))
                           '()))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3377533776%_
                 (lambda (_%$%g1602716040%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0 '#f 'lattice-frontier-clear!)))))
            (let* ((_%$%g1601116051%_
                    (lambda ()
                      (let ((_%$%g1602716040%_ _%__stx3376833769%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1602716040%_))
                            (_%__kont3377533776%_ _%$%g1602716040%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1601216033%_))))))
                   (_%__match3379133792%_
                    (lambda (_%$%e1601516058%_
                             _%$%hd1601616062%_
                             _%$%tl1601716065%_
                             _%__splice3377333774%_
                             _%$%target1601816068%_
                             _%$%tl1602016071%_)
                      (letrec ((_%$%loop1602116074%_
                                (lambda (_%$%hd1601916078%_
                                         _%$%arg1602516081%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1601916078%_))
                                      (let ((_%$%e1602216084%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1601916078%_))))
                                        (let ((_%$%lp-tl1602416091%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1602216084%_)))
                                              (_%$%lp-hd1602316088%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1602216084%_))))
                                          (_%$%loop1602116074%_
                                           _%$%lp-tl1602416091%_
                                           (cons _%$%lp-hd1602316088%_
                                                 _%$%arg1602516081%_))))
                                      (let ((_%$%arg1602616094%_
                                             (reverse _%$%arg1602516081%_)))
                                        (_%__kont3377133772%_
                                         _%$%arg1602616094%_))))))
                        (_%$%loop1602116074%_ _%$%target1601816068%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3376833769%_))
                  (let ((_%$%e1601516058%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3376833769%_))))
                    (let ((_%$%tl1601716065%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1601516058%_)))
                          (_%$%hd1601616062%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1601516058%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1601716065%_))
                          (let ((_%__splice3377333774%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1601716065%_
                                    '0))))
                            (let ((_%$%tl1602016071%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3377333774%_ '1)))
                                  (_%$%target1601816068%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3377333774%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1602016071%_))
                                  (_%__match3379133792%_
                                   _%$%e1601516058%_
                                   _%$%hd1601616062%_
                                   _%$%tl1601716065%_
                                   _%__splice3377333774%_
                                   _%$%target1601816068%_
                                   _%$%tl1602016071%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1601116051%_)))))
                          (let () (declare (not safe)) (_%$%g1601116051%_)))))
                  (let () (declare (not safe)) (_%$%g1601116051%_))))))))))
