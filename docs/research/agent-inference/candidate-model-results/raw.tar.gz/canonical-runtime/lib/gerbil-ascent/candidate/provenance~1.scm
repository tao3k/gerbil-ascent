(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/provenance[1]#_g37517_|
    (##structure
     gx#syntax-quote::t
     'positive-proof::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37519_|
    (##structure
     gx#syntax-quote::t
     'make-positive-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37521_|
    (##structure
     gx#syntax-quote::t
     'positive-proof?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37523_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37524_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37525_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37526_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37527_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37528_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37529_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37530_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37531_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37533_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37534_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37535_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37536_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37537_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37538_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37539_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37540_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37541_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37543_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37544_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37545_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37546_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37547_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37548_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37549_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37550_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37551_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37553_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37554_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37555_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37556_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37557_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37558_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37559_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37560_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37561_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37563_|
    (##structure
     gx#syntax-quote::t
     'proof-node::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37565_|
    (##structure
     gx#syntax-quote::t
     'make-proof-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37567_|
    (##structure
     gx#syntax-quote::t
     'proof-node?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37569_|
    (##structure
     gx#syntax-quote::t
     'proof-node-id
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37570_|
    (##structure
     gx#syntax-quote::t
     'proof-node-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37571_|
    (##structure
     gx#syntax-quote::t
     'proof-node-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37572_|
    (##structure
     gx#syntax-quote::t
     'proof-node-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37573_|
    (##structure
     gx#syntax-quote::t
     'proof-node-label
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37574_|
    (##structure
     gx#syntax-quote::t
     'proof-node-inputs
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37576_|
    (##structure
     gx#syntax-quote::t
     'proof-node-id-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37577_|
    (##structure
     gx#syntax-quote::t
     'proof-node-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37578_|
    (##structure
     gx#syntax-quote::t
     'proof-node-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37579_|
    (##structure
     gx#syntax-quote::t
     'proof-node-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37580_|
    (##structure
     gx#syntax-quote::t
     'proof-node-label-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37581_|
    (##structure
     gx#syntax-quote::t
     'proof-node-inputs-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37583_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-id
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37584_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37585_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37586_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37587_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-label
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37588_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-inputs
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37590_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-id-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37591_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37592_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37593_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37594_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-label-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37595_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-inputs-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37597_|
    (##structure
     gx#syntax-quote::t
     'proof-relation::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37599_|
    (##structure
     gx#syntax-quote::t
     'make-proof-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37601_|
    (##structure
     gx#syntax-quote::t
     'proof-relation?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37603_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37604_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-tail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37605_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37607_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37608_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-tail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37609_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37611_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37612_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-tail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37613_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37615_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37616_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-tail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37617_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/provenance[:0:]#positive-proof|
      (let ((__obj37224
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37224
           'gerbil-ascent/candidate/provenance#positive-proof::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37224 'positive-proof '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37224
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    work-budget
                    nodes
                    roots)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37224
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    work-budget
                    nodes
                    roots)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37224 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37224 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37224 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37224 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37224 '#f '13 '#f '#f))
        (let ((__tmp37516 |gerbil-ascent/candidate/provenance[1]#_g37517_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37224 __tmp37516 '4 '#f '#f))
        (let ((__tmp37518 |gerbil-ascent/candidate/provenance[1]#_g37519_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37224 __tmp37518 '14 '#f '#f))
        (let ((__tmp37520 |gerbil-ascent/candidate/provenance[1]#_g37521_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37224 __tmp37520 '15 '#f '#f))
        (let ((__tmp37522
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g37523_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g37524_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g37525_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g37526_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g37527_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g37528_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g37529_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g37530_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g37531_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37224 __tmp37522 '16 '#f '#f))
        (let ((__tmp37532
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g37533_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g37534_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g37535_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g37536_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g37537_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g37538_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g37539_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g37540_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g37541_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37224 __tmp37532 '17 '#f '#f))
        (let ((__tmp37542
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g37543_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g37544_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g37545_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g37546_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g37547_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g37548_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g37549_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g37550_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g37551_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37224 __tmp37542 '18 '#f '#f))
        (let ((__tmp37552
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g37553_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g37554_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g37555_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g37556_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g37557_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g37558_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g37559_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g37560_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g37561_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37224 __tmp37552 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37224 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37224 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37224 '() '21 '#f '#f))
        __obj37224))
    (define |gerbil-ascent/candidate/provenance[:0:]#proof-node|
      (let ((__obj37225
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37225
           'gerbil-ascent/candidate/provenance#proof-node::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37225 'proof-node '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37225
           '(id kind relation row label inputs)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37225
           '(id kind relation row label inputs)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37225 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37225 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37225 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37225 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37225 '#f '13 '#f '#f))
        (let ((__tmp37562 |gerbil-ascent/candidate/provenance[1]#_g37563_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37225 __tmp37562 '4 '#f '#f))
        (let ((__tmp37564 |gerbil-ascent/candidate/provenance[1]#_g37565_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37225 __tmp37564 '14 '#f '#f))
        (let ((__tmp37566 |gerbil-ascent/candidate/provenance[1]#_g37567_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37225 __tmp37566 '15 '#f '#f))
        (let ((__tmp37568
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g37569_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g37570_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g37571_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g37572_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g37573_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g37574_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37225 __tmp37568 '16 '#f '#f))
        (let ((__tmp37575
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g37576_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g37577_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g37578_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g37579_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g37580_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g37581_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37225 __tmp37575 '17 '#f '#f))
        (let ((__tmp37582
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g37583_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g37584_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g37585_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g37586_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g37587_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g37588_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37225 __tmp37582 '18 '#f '#f))
        (let ((__tmp37589
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g37590_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g37591_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g37592_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g37593_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g37594_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g37595_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37225 __tmp37589 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37225 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37225 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37225 '() '21 '#f '#f))
        __obj37225))
    (define |gerbil-ascent/candidate/provenance[:0:]#proof-relation|
      (let ((__obj37226
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37226
           'gerbil-ascent/candidate/provenance#proof-relation::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37226 'proof-relation '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37226
           '(nodes tail members)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37226
           '(nodes tail members)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37226 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37226 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37226 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37226 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37226 '#f '13 '#f '#f))
        (let ((__tmp37596 |gerbil-ascent/candidate/provenance[1]#_g37597_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37226 __tmp37596 '4 '#f '#f))
        (let ((__tmp37598 |gerbil-ascent/candidate/provenance[1]#_g37599_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37226 __tmp37598 '14 '#f '#f))
        (let ((__tmp37600 |gerbil-ascent/candidate/provenance[1]#_g37601_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37226 __tmp37600 '15 '#f '#f))
        (let ((__tmp37602
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g37603_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g37604_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g37605_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37226 __tmp37602 '16 '#f '#f))
        (let ((__tmp37606
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g37607_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g37608_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g37609_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37226 __tmp37606 '17 '#f '#f))
        (let ((__tmp37610
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g37611_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g37612_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g37613_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37226 __tmp37610 '18 '#f '#f))
        (let ((__tmp37614
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g37615_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g37616_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g37617_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37226 __tmp37614 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37226 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37226 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37226 '() '21 '#f '#f))
        __obj37226))))
