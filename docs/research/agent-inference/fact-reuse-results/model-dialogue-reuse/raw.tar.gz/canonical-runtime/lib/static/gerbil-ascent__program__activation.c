#ifdef ___LINKER_INFO
; File: "gerbil-ascent__program__activation.c", produced by Gambit v4.9.8
(
409008
(C)
"gerbil-ascent__program__activation"
("gerbil-ascent__program__activation")
()
(("gerbil-ascent__program__activation"))
( #|*/"*/"symbols|#
"gerbil-ascent/program/activation#gerbil-ascent-activate-plans"
"gerbil-ascent/program/activation#gerbil-ascent-activate-rule"
"gerbil-ascent__program__activation"
"gerbil-ascent__program__activation#"
) #|*/"*/"symbols|#
( #|*/"*/"keywords|#
) #|*/"*/"keywords|#
( #|*/"*/"globals-s-d|#
"gerbil-ascent/program/activation#gerbil-ascent-activate-rule"
"gerbil-ascent__program__activation#"
) #|*/"*/"globals-s-d|#
( #|*/"*/"globals-s-nd|#
"gerbil-ascent/program/activation#gerbil-ascent-activate-plans"
"gerbil-ascent/program/activation::timestamp"
) #|*/"*/"globals-s-nd|#
( #|*/"*/"globals-ns|#
"##dead-end"
"##make-vector"
"make-vector"
"map"
"vector-map"
"vector-ref"
) #|*/"*/"globals-ns|#
( #|*/"*/"meta-info|#
) #|*/"*/"meta-info|#
)
#else
#define ___VERSION 409008
#define ___MODULE_NAME "gerbil-ascent__program__activation"
#define ___LINKER_ID ___LNK_gerbil_2d_ascent____program____activation
#define ___MH_PROC ___H_gerbil_2d_ascent____program____activation
#define ___SCRIPT_LINE 0
#define ___SYMCOUNT 4
#define ___GLOCOUNT 10
#define ___SUPCOUNT 4
#define ___SUBCOUNT 4
#define ___LBLCOUNT 26
#define ___MODDESCR ___REF_SUB(1)
#include "gambit.h"

___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___NEED_SYM(___S_gerbil_2d_ascent____program____activation)
___NEED_SYM(___S_gerbil_2d_ascent____program____activation_23_)

___NEED_GLO(___G__23__23_dead_2d_end)
___NEED_GLO(___G__23__23_make_2d_vector)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_activation_3a__3a_timestamp)
___NEED_GLO(___G_gerbil_2d_ascent____program____activation_23_)
___NEED_GLO(___G_make_2d_vector)
___NEED_GLO(___G_map)
___NEED_GLO(___G_vector_2d_map)
___NEED_GLO(___G_vector_2d_ref)

___BEGIN_SYM
___DEF_SYM(0,___S_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans,"gerbil-ascent/program/activation#gerbil-ascent-activate-plans")

___DEF_SYM(1,___S_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule,"gerbil-ascent/program/activation#gerbil-ascent-activate-rule")

___DEF_SYM(2,___S_gerbil_2d_ascent____program____activation,"gerbil-ascent__program__activation")

___DEF_SYM(3,___S_gerbil_2d_ascent____program____activation_23_,"gerbil-ascent__program__activation#")

___END_SYM

#define ___SYM_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans ___SYM(0,___S_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule ___SYM(1,___S_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
#define ___SYM_gerbil_2d_ascent____program____activation ___SYM(2,___S_gerbil_2d_ascent____program____activation)
#define ___SYM_gerbil_2d_ascent____program____activation_23_ ___SYM(3,___S_gerbil_2d_ascent____program____activation_23_)

___BEGIN_GLO
___DEF_GLO(0,"gerbil-ascent/program/activation#gerbil-ascent-activate-plans")

___DEF_GLO(1,"gerbil-ascent/program/activation#gerbil-ascent-activate-rule")

___DEF_GLO(2,"gerbil-ascent/program/activation::timestamp")

___DEF_GLO(3,"gerbil-ascent__program__activation#")

___DEF_GLO(4,"##dead-end")
___DEF_GLO(5,"##make-vector")
___DEF_GLO(6,"make-vector")
___DEF_GLO(7,"map")
___DEF_GLO(8,"vector-map")
___DEF_GLO(9,"vector-ref")
___END_GLO

#define ___GLO_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans ___GLO(0,___G_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans ___PRM(0,___G_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule ___GLO(1,___G_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule ___PRM(1,___G_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_activation_3a__3a_timestamp ___GLO(2,___G_gerbil_2d_ascent_2f_program_2f_activation_3a__3a_timestamp)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_activation_3a__3a_timestamp ___PRM(2,___G_gerbil_2d_ascent_2f_program_2f_activation_3a__3a_timestamp)
#define ___GLO_gerbil_2d_ascent____program____activation_23_ ___GLO(3,___G_gerbil_2d_ascent____program____activation_23_)
#define ___PRM_gerbil_2d_ascent____program____activation_23_ ___PRM(3,___G_gerbil_2d_ascent____program____activation_23_)
#define ___GLO__23__23_dead_2d_end ___GLO(4,___G__23__23_dead_2d_end)
#define ___PRM__23__23_dead_2d_end ___PRM(4,___G__23__23_dead_2d_end)
#define ___GLO__23__23_make_2d_vector ___GLO(5,___G__23__23_make_2d_vector)
#define ___PRM__23__23_make_2d_vector ___PRM(5,___G__23__23_make_2d_vector)
#define ___GLO_make_2d_vector ___GLO(6,___G_make_2d_vector)
#define ___PRM_make_2d_vector ___PRM(6,___G_make_2d_vector)
#define ___GLO_map ___GLO(7,___G_map)
#define ___PRM_map ___PRM(7,___G_map)
#define ___GLO_vector_2d_map ___GLO(8,___G_vector_2d_map)
#define ___PRM_vector_2d_map ___PRM(8,___G_vector_2d_map)
#define ___GLO_vector_2d_ref ___GLO(9,___G_vector_2d_ref)
#define ___PRM_vector_2d_ref ___PRM(9,___G_vector_2d_ref)

___DEF_SUB_BIGFIX(___X0,1UL)
               ___BIGFIX1(0x6acb08e8L)
___DEF_SUB_VEC(___X1,6UL)
               ___VEC1(___REF_SUB(2))
               ___VEC1(___REF_SUB(3))
               ___VEC1(___REF_NUL)
               ___VEC1(___REF_FIX(1))
               ___VEC1(___REF_PRC(1))
               ___VEC1(___REF_FAL)
               ___VEC0
___DEF_SUB_VEC(___X2,1UL)
               ___VEC1(___REF_SYM(2,___S_gerbil_2d_ascent____program____activation))
               ___VEC0
___DEF_SUB_VEC(___X3,0UL)
               ___VEC0

___BEGIN_SUB
 ___DEF_SUB(___X0)
,___DEF_SUB(___X1)
,___DEF_SUB(___X2)
,___DEF_SUB(___X3)
___END_SUB



#undef ___MD_ALL
#define ___MD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___MR_ALL
#define ___MR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___MW_ALL
#define ___MW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_M_COD
___BEGIN_M_HLBL
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent____program____activation_23_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___END_M_HLBL

___BEGIN_M_SW

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent____program____activation_23_
#undef ___PH_LBL0
#define ___PH_LBL0 1
#undef ___PD_ALL
#define ___PD_ALL ___D_R0 ___D_R1
#undef ___PR_ALL
#define ___PR_ALL ___R_R0 ___R_R1
#undef ___PW_ALL
#define ___PW_ALL ___W_R1
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent____program____activation_23_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent____program____activation_23_)
   ___IF_NARGS_EQ(0,___NOTHING)
   ___WRONG_NARGS(0,0,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent____program____activation_23_)
   ___SET_GLO(2,___G_gerbil_2d_ascent_2f_program_2f_activation_3a__3a_timestamp,___BIGFIX(0,1791690984LL))
   ___SET_R1(___VOID)
   ___JUMPRET(___R0)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule
#undef ___PH_LBL0
#define ___PH_LBL0 3
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___IF(___NOT(___VECTORP(___R1)))
   ___GOTO(___L22_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___END_IF
   ___IF(___NOT(___VECTORINBOUNDSP(___R1,___FIX(5L))))
   ___GOTO(___L22_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___END_IF
   ___SET_R2(___VECTORREF(___R1,___FIX(5L)))
   ___IF(___NOT(___VECTORP(___R1)))
   ___GOTO(___L21_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___END_IF
   ___IF(___NOT(___VECTORINBOUNDSP(___R1,___FIX(0L))))
   ___GOTO(___L21_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___END_IF
   ___SET_R3(___VECTORREF(___R1,___FIX(0L)))
   ___IF(___NOT(___VECTORP(___R1)))
   ___GOTO(___L20_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___END_IF
   ___IF(___NOT(___VECTORINBOUNDSP(___R1,___FIX(1L))))
   ___GOTO(___L20_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___END_IF
   ___SET_R4(___VECTORREF(___R1,___FIX(1L)))
   ___IF(___NOT(___VECTORP(___R1)))
   ___GOTO(___L19_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___END_IF
   ___IF(___NOT(___VECTORINBOUNDSP(___R1,___FIX(2L))))
   ___GOTO(___L19_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___END_IF
   ___SET_STK(1,___VECTORREF(___R1,___FIX(2L)))
   ___SET_STK(2,___R1)
   ___SET_R1(___STK(1))
   ___ADJFP(2)
   ___IF(___NOT(___VECTORP(___STK(0))))
   ___GOTO(___L18_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___END_IF
   ___IF(___NOT(___VECTORINBOUNDSP(___STK(0),___FIX(3L))))
   ___GOTO(___L18_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___END_IF
   ___SET_STK(-1,___VECTORREF(___STK(0),___FIX(3L)))
   ___SET_STK(1,___R1)
   ___SET_R1(___STK(-1))
   ___ADJFP(1)
   ___IF(___NOT(___VECTORP(___STK(-1))))
   ___GOTO(___L17_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___END_IF
   ___IF(___NOT(___VECTORINBOUNDSP(___STK(-1),___FIX(4L))))
   ___GOTO(___L17_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___END_IF
   ___SET_STK(-2,___VECTORREF(___STK(-1),___FIX(4L)))
   ___SET_STK(-1,___R1)
   ___SET_R1(___STK(-2))
   ___IF(___NOT(___NOTFALSEP(___R2)))
   ___GOTO(___L16_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___END_IF
   ___IF(___NOT(___VECTORP(___R2)))
   ___GOTO(___L15_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___END_IF
   ___IF(___NOT(___VECTORINBOUNDSP(___R2,___FIX(2L))))
   ___GOTO(___L15_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___END_IF
   ___SET_STK(-2,___VECTORREF(___R2,___FIX(2L)))
   ___SET_STK(1,___R1)
   ___SET_R1(___STK(-2))
   ___ADJFP(1)
   ___IF(___NOT(___FIXNUMP(___R1)))
   ___GOTO(___L14_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___END_IF
   ___IF(___FIXNEGATIVEP(___R1))
   ___GOTO(___L14_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___END_IF
   ___IF(___NOT(___FIXLE(___R1,___FIX(253L))))
   ___GOTO(___L13_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___END_IF
   ___MAKEVECTORSMALL2(___R1,___FAL)
   ___SET_R1(___GET_SMALL_ALLOC)
   ___CHECK_HEAP(1,4096)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___GOTO(___L11_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_R4(___STK(-5))
   ___SET_R3(___STK(-6))
   ___SET_R2(___STK(-7))
   ___SET_R0(___STK(-11))
   ___ADJFP(-8)
___DEF_GLBL(___L11_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_STK(-3,___STK(0))
   ___ADJFP(-1)
___DEF_GLBL(___L12_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___BEGIN_ALLOC_VECTOR(7UL)
   ___ADD_VECTOR_ELEM(0,___R3)
   ___ADD_VECTOR_ELEM(1,___R4)
   ___ADD_VECTOR_ELEM(2,___STK(0))
   ___ADD_VECTOR_ELEM(3,___STK(-1))
   ___ADD_VECTOR_ELEM(4,___STK(-2))
   ___ADD_VECTOR_ELEM(5,___R2)
   ___ADD_VECTOR_ELEM(6,___R1)
   ___END_ALLOC_VECTOR(7)
   ___SET_R1(___GET_VECTOR(7))
   ___ADJFP(-3)
   ___CHECK_HEAP(3,4096)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___JUMPRET(___R0)
___DEF_GLBL(___L13_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_STK(-3,___R0)
   ___SET_STK(1,___R2)
   ___SET_STK(2,___R3)
   ___SET_STK(3,___R4)
   ___SET_R2(___FAL)
   ___SET_R0(___LBL(2))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM__23__23_make_2d_vector)
___DEF_GLBL(___L14_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_STK(-3,___R0)
   ___SET_STK(1,___R2)
   ___SET_STK(2,___R3)
   ___SET_STK(3,___R4)
   ___SET_R2(___FAL)
   ___SET_R0(___LBL(4))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM_make_2d_vector)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_R0(___LBL(4))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L15_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_STK(-2,___R0)
   ___SET_STK(1,___R1)
   ___SET_STK(2,___R2)
   ___SET_STK(3,___R3)
   ___SET_STK(4,___R4)
   ___SET_R1(___R2)
   ___SET_R2(___FIX(2L))
   ___SET_R0(___LBL(4))
   ___ADJFP(9)
   ___JUMPPRM(___SET_NARGS(2),___PRM_vector_2d_ref)
___DEF_GLBL(___L16_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_STK(-2,___R1)
   ___SET_R1(___FAL)
   ___GOTO(___L12_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_GLBL(___L17_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_STK(-2,___R0)
   ___SET_STK(1,___R1)
   ___SET_STK(2,___R2)
   ___SET_STK(3,___R3)
   ___SET_STK(4,___R4)
   ___SET_R1(___STK(-1))
   ___SET_R2(___FIX(4L))
   ___SET_R0(___LBL(5))
   ___ADJFP(9)
   ___JUMPPRM(___SET_NARGS(2),___PRM_vector_2d_ref)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_R0(___LBL(5))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L18_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_STK(-1,___R0)
   ___SET_STK(1,___R1)
   ___SET_STK(2,___R2)
   ___SET_STK(3,___R3)
   ___SET_STK(4,___R4)
   ___SET_R1(___STK(0))
   ___SET_R2(___FIX(3L))
   ___SET_R0(___LBL(6))
   ___ADJFP(10)
   ___JUMPPRM(___SET_NARGS(2),___PRM_vector_2d_ref)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_R0(___LBL(6))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L19_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_STK(4,___R3)
   ___SET_STK(5,___R4)
   ___SET_R2(___FIX(2L))
   ___SET_R0(___LBL(7))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM_vector_2d_ref)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_R0(___LBL(7))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L20_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_STK(4,___R3)
   ___SET_R2(___FIX(1L))
   ___SET_R0(___LBL(8))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM_vector_2d_ref)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_R0(___LBL(8))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L21_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_R2(___FIX(0L))
   ___SET_R0(___LBL(9))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM_vector_2d_ref)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_R0(___LBL(9))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L22_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R2(___FIX(5L))
   ___SET_R0(___LBL(10))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM_vector_2d_ref)
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
   ___SET_R0(___LBL(10))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans
#undef ___PH_LBL0
#define ___PH_LBL0 15
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___SET_STK(1,___R1)
   ___SET_R1(___LBL(2))
   ___SET_R2(___STK(1))
   ___ADJFP(1)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___ADJFP(-1)
   ___JUMPGLOSAFE(___SET_NARGS(2),8,___G_vector_2d_map)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(2,1,0,0)
   ___IF(___NOT(___PROCEDUREP(___PRC(3))))
   ___GOTO(___L15_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___END_IF
   ___SET_R2(___R1)
   ___POLL(3)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___GOTO(___L12_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_GLBL(___L11_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___SET_R2(___CDR(___R2))
   ___POLL(4)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
___DEF_GLBL(___L12_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___IF(___PAIRP(___R2))
   ___GOTO(___L11_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___END_IF
   ___IF(___NOT(___NULLP(___R2)))
   ___GOTO(___L15_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___END_IF
   ___POLL(5)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L14_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___END_IF
___DEF_GLBL(___L13_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R1(___CAR(___R1))
   ___ADJFP(8)
   ___POLL(6)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___SET_R0(___LBL(7))
   ___JUMPINT(___SET_NARGS(1),___PRC(3),___L_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___SET_STK(-5,___R1)
   ___SET_R1(___CDR(___STK(-6)))
   ___SET_R0(___LBL(8))
   ___IF(___PAIRP(___R1))
   ___GOTO(___L13_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___END_IF
___DEF_GLBL(___L14_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___SET_R1(___NUL)
   ___JUMPRET(___R0)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___SET_R1(___CONS(___STK(-5),___R1))
   ___ADJFP(-7)
   ___CHECK_HEAP(9,4096)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___ADJFP(-1)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L15_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___SET_R2(___R1)
   ___SET_R1(___PRC(3))
   ___POLL(10)
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans)
   ___JUMPPRM(___SET_NARGS(2),___PRM_map)
___END_P_SW
___END_P_COD

___END_M_SW
___END_M_COD

___BEGIN_LBL
 ___DEF_LBL_INTRO(___H_gerbil_2d_ascent____program____activation_23_,___REF_SYM(3,___S_gerbil_2d_ascent____program____activation_23_),___REF_FAL,1,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____program____activation_23_,0,-1)
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule,___REF_SYM(1,___S_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule),___REF_FAL,11,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule,___IFD(___RETI,4,4,0x3feL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule,___IFD(___RETN,9,0,0x7fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule,___IFD(___RETN,9,0,0x7fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule,___IFD(___RETN,9,0,0x7dL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule,___IFD(___RETN,9,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule,___IFD(___RETN,5,0,0x1fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule,___IFD(___RETN,5,0,0xfL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans,___REF_SYM(0,___S_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans),___REF_FAL,11,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans,___IFD(___RETI,1,4,0x3f0L))
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans,___IFD(___RETN,5,0,0x5L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans,___IFD(___RETI,1,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans,___IFD(___RETI,0,0,0x3fL))
___END_LBL

___BEGIN_MOD_PRM
___DEF_MOD_PRM(3,___G_gerbil_2d_ascent____program____activation_23_,1)
___DEF_MOD_PRM(1,___G_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule,3)
___DEF_MOD_PRM(0,___G_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans,15)
___END_MOD_PRM

___BEGIN_MOD_C_INIT
___END_MOD_C_INIT

___BEGIN_MOD_GLO
___DEF_MOD_GLO(3,___G_gerbil_2d_ascent____program____activation_23_,1)
___DEF_MOD_GLO(1,___G_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule,3)
___DEF_MOD_GLO(0,___G_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans,15)
___END_MOD_GLO

___BEGIN_MOD_SYM_KEY
___DEF_MOD_SYM(0,___S_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_plans,"gerbil-ascent/program/activation#gerbil-ascent-activate-plans")

___DEF_MOD_SYM(1,___S_gerbil_2d_ascent_2f_program_2f_activation_23_gerbil_2d_ascent_2d_activate_2d_rule,"gerbil-ascent/program/activation#gerbil-ascent-activate-rule")

___DEF_MOD_SYM(2,___S_gerbil_2d_ascent____program____activation,"gerbil-ascent__program__activation")

___DEF_MOD_SYM(3,___S_gerbil_2d_ascent____program____activation_23_,"gerbil-ascent__program__activation#")

___END_MOD_SYM_KEY

#endif
