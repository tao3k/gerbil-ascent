(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/index::timestamp 1791687878)
  (begin
    (define gerbil-ascent/program/index#row-indexes::t
      (let ((__tmp35177 (list)) (__tmp35176 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/index#row-indexes::t
         'row-indexes
         __tmp35177
         '(rows advance! plan! visit-parts)
         __tmp35176
         '#f)))
    (define gerbil-ascent/program/index#row-indexes?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/program/index#row-indexes::t)))
    (define gerbil-ascent/program/index#make-row-indexes
      (lambda _%$args15307%_
        (apply make-instance
               gerbil-ascent/program/index#row-indexes::t
               _%$args15307%_)))
    (define gerbil-ascent/program/index#row-indexes-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#row-indexes::t
         'rows)))
    (define gerbil-ascent/program/index#row-indexes-advance!
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#row-indexes::t
         'advance!)))
    (define gerbil-ascent/program/index#row-indexes-plan!
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#row-indexes::t
         'plan!)))
    (define gerbil-ascent/program/index#row-indexes-visit-parts
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#row-indexes::t
         'visit-parts)))
    (define gerbil-ascent/program/index#row-indexes-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#row-indexes::t
         'rows)))
    (define gerbil-ascent/program/index#row-indexes-advance!-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#row-indexes::t
         'advance!)))
    (define gerbil-ascent/program/index#row-indexes-plan!-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#row-indexes::t
         'plan!)))
    (define gerbil-ascent/program/index#row-indexes-visit-parts-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#row-indexes::t
         'visit-parts)))
    (define gerbil-ascent/program/index#&row-indexes-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#row-indexes::t
         'rows)))
    (define gerbil-ascent/program/index#&row-indexes-advance!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#row-indexes::t
         'advance!)))
    (define gerbil-ascent/program/index#&row-indexes-plan!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#row-indexes::t
         'plan!)))
    (define gerbil-ascent/program/index#&row-indexes-visit-parts
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#row-indexes::t
         'visit-parts)))
    (define gerbil-ascent/program/index#&row-indexes-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#row-indexes::t
         'rows)))
    (define gerbil-ascent/program/index#&row-indexes-advance!-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#row-indexes::t
         'advance!)))
    (define gerbil-ascent/program/index#&row-indexes-plan!-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#row-indexes::t
         'plan!)))
    (define gerbil-ascent/program/index#&row-indexes-visit-parts-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#row-indexes::t
         'visit-parts)))
    (define gerbil-ascent/program/index#row-indexes-plan-atoms!
      (lambda (_%indexes15301%_)
        (lambda (_%atoms15303%_)
          ((##structure-ref
            _%indexes15301%_
            '3
            gerbil-ascent/program/index#row-indexes::t
            '#f)
           (lambda (_%accept!15305%_)
             (for-each _%accept!15305%_ _%atoms15303%_))))))
    (define gerbil-ascent/program/index#visit-action-atoms!
      (lambda (_%actions15294%_ _%accept!15295%_)
        (for-each
         (lambda (_%action15297%_)
           (let ((_%atom15299%_ (vector-ref _%action15297%_ '0)))
             (if (vector? _%atom15299%_)
                 (_%accept!15295%_ _%atom15299%_)
                 '#!void)))
         _%actions15294%_)))
    (define gerbil-ascent/program/index#collect-sharing-atoms
      (lambda (_%visit!15108%_ _%providers15109%_)
        (let* ((_%seen15111%_
                (let ((__tmp35178 (vector-length _%providers15109%_)))
                  (declare (not safe))
                  (##make-vector __tmp35178 '#f)))
               (_%head15113%_ (cons '#f '()))
               (_%tail15116%_ _%head15113%_))
          (letrec ((_%accept!15277%_
                    (lambda (_%atom15279%_)
                      (let ((_%index15281%_ (vector-ref _%atom15279%_ '0))
                            (_%columns15282%_ (vector-ref _%atom15279%_ '2)))
                        (if (and (let ((__tmp35179
                                        (vector-ref
                                         _%providers15109%_
                                         _%index15281%_)))
                                   (declare (not safe))
                                   (gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider?
                                    __tmp35179))
                                 (pair? _%columns15282%_))
                            (let ((_%table15289%_
                                   (let ((_%$e15284%_
                                          (vector-ref
                                           _%seen15111%_
                                           _%index15281%_)))
                                     (if _%$e15284%_
                                         _%$e15284%_
                                         (let ((_%fresh15287%_
                                                (let ()
                                                  (declare (not safe))
                                                  (make-hash-table__%
                                                   '#f
                                                   absent-value
                                                   absent-value
                                                   absent-value
                                                   absent-value
                                                   absent-value
                                                   absent-value
                                                   absent-value
                                                   absent-value))))
                                           (vector-set!
                                            _%seen15111%_
                                            _%index15281%_
                                            _%fresh15287%_)
                                           _%fresh15287%_)))))
                              (if (let ()
                                    (declare (not safe))
                                    (hash-get _%table15289%_ _%columns15282%_))
                                  '#!void
                                  (begin
                                    (let ()
                                      (declare (not safe))
                                      (hash-put!
                                       _%table15289%_
                                       _%columns15282%_
                                       '#t))
                                    (let ((_%new-tail15291%_
                                           (cons _%atom15279%_ '())))
                                      (let ()
                                        (declare (not safe))
                                        (##set-cdr!
                                         _%tail15116%_
                                         _%new-tail15291%_))
                                      (set! _%tail15116%_
                                            _%new-tail15291%_)))))
                            '#!void)))))
            (_%visit!15108%_ _%accept!15277%_)
            (let () (declare (not safe)) (##cdr _%head15113%_))))))
    (define gerbil-ascent/program/index#provider-row-member::t
      (let ((__tmp35181 (list)) (__tmp35180 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/index#provider-row-member::t
         'provider-row-member
         __tmp35181
         '(ordinal key occurrences)
         __tmp35180
         '#f)))
    (define gerbil-ascent/program/index#provider-row-member?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/index#provider-row-member::t)))
    (define gerbil-ascent/program/index#make-provider-row-member
      (lambda _%$args15105%_
        (apply make-instance
               gerbil-ascent/program/index#provider-row-member::t
               _%$args15105%_)))
    (define gerbil-ascent/program/index#provider-row-member-ordinal
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#provider-row-member::t
         'ordinal)))
    (define gerbil-ascent/program/index#provider-row-member-key
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#provider-row-member::t
         'key)))
    (define gerbil-ascent/program/index#provider-row-member-occurrences
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#provider-row-member::t
         'occurrences)))
    (define gerbil-ascent/program/index#provider-row-member-ordinal-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#provider-row-member::t
         'ordinal)))
    (define gerbil-ascent/program/index#provider-row-member-key-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#provider-row-member::t
         'key)))
    (define gerbil-ascent/program/index#provider-row-member-occurrences-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#provider-row-member::t
         'occurrences)))
    (define gerbil-ascent/program/index#&provider-row-member-ordinal
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#provider-row-member::t
         'ordinal)))
    (define gerbil-ascent/program/index#&provider-row-member-key
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#provider-row-member::t
         'key)))
    (define gerbil-ascent/program/index#&provider-row-member-occurrences
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#provider-row-member::t
         'occurrences)))
    (define gerbil-ascent/program/index#&provider-row-member-ordinal-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#provider-row-member::t
         'ordinal)))
    (define gerbil-ascent/program/index#&provider-row-member-key-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#provider-row-member::t
         'key)))
    (define gerbil-ascent/program/index#&provider-row-member-occurrences-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#provider-row-member::t
         'occurrences)))
    (define gerbil-ascent/program/index#provider-row-witness::t
      (let ((__tmp35183 (list)) (__tmp35182 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/index#provider-row-witness::t
         'provider-row-witness
         __tmp35183
         '(members counts)
         __tmp35182
         '#f)))
    (define gerbil-ascent/program/index#provider-row-witness?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/index#provider-row-witness::t)))
    (define gerbil-ascent/program/index#make-provider-row-witness
      (lambda _%$args15102%_
        (apply make-instance
               gerbil-ascent/program/index#provider-row-witness::t
               _%$args15102%_)))
    (define gerbil-ascent/program/index#provider-row-witness-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#provider-row-witness::t
         'members)))
    (define gerbil-ascent/program/index#provider-row-witness-counts
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#provider-row-witness::t
         'counts)))
    (define gerbil-ascent/program/index#provider-row-witness-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#provider-row-witness::t
         'members)))
    (define gerbil-ascent/program/index#provider-row-witness-counts-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#provider-row-witness::t
         'counts)))
    (define gerbil-ascent/program/index#&provider-row-witness-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#provider-row-witness::t
         'members)))
    (define gerbil-ascent/program/index#&provider-row-witness-counts
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#provider-row-witness::t
         'counts)))
    (define gerbil-ascent/program/index#&provider-row-witness-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#provider-row-witness::t
         'members)))
    (define gerbil-ascent/program/index#&provider-row-witness-counts-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#provider-row-witness::t
         'counts)))
    (define gerbil-ascent/program/index#checked-provider-rows
      (lambda (_%rows15081%_ _%terms15082%_ _%witness15083%_ _%key15084%_)
        (let ((_%snapshot15086%_
               (let ((__tmp35184 (length _%terms15082%_)))
                 (declare (not safe))
                 (gerbil-ascent/table/funs#gerbil-ascent-index-row-snapshot/arity
                  _%rows15081%_
                  __tmp35184)))
              (_%seen15087%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value)))
              (_%matched15088%_ '0))
          (let ((__tmp35185
                 (lambda (_%row15090%_)
                   (let ((_%member15092%_
                          (let ((__tmp35186
                                 (##structure-ref
                                  _%witness15083%_
                                  '1
                                  gerbil-ascent/program/index#provider-row-witness::t
                                  '#f)))
                            (declare (not safe))
                            (hash-get __tmp35186 _%row15090%_))))
                     (if _%member15092%_
                         '#!void
                         (let ()
                           (declare (not safe))
                           (error '"ASCENT index provider returned foreign row")))
                     (let ((_%enumerated15097%_
                            (let ((_%$e15094%_
                                   (let ((__tmp35187
                                          (##structure-ref
                                           _%member15092%_
                                           '1
                                           gerbil-ascent/program/index#provider-row-member::t
                                           '#f)))
                                     (declare (not safe))
                                     (__hash-get _%seen15087%_ __tmp35187))))
                              (if _%$e15094%_ _%$e15094%_ '0))))
                       (if (>= _%enumerated15097%_
                               (##structure-ref
                                _%member15092%_
                                '3
                                gerbil-ascent/program/index#provider-row-member::t
                                '#f))
                           (let ()
                             (declare (not safe))
                             (error '"ASCENT index provider returned duplicate row"))
                           '#!void)
                       (let ((__tmp35189
                              (##structure-ref
                               _%member15092%_
                               '1
                               gerbil-ascent/program/index#provider-row-member::t
                               '#f))
                             (__tmp35188 (+ _%enumerated15097%_ '1)))
                         (declare (not safe))
                         (__hash-put! _%seen15087%_ __tmp35189 __tmp35188)))
                     (if (equal? (##structure-ref
                                  _%member15092%_
                                  '2
                                  gerbil-ascent/program/index#provider-row-member::t
                                  '#f)
                                 _%key15084%_)
                         (set! _%matched15088%_ (+ _%matched15088%_ '1))
                         '#!void)))))
            (declare (not safe))
            (##for-each __tmp35185 _%snapshot15086%_))
          (if (= _%matched15088%_
                 (or (let ((__tmp35190
                            (##structure-ref
                             _%witness15083%_
                             '2
                             gerbil-ascent/program/index#provider-row-witness::t
                             '#f)))
                       (declare (not safe))
                       (hash-get __tmp35190 _%key15084%_))
                     '0))
              '#!void
              (let ()
                (declare (not safe))
                (error '"ASCENT index provider omitted matching rows")))
          _%snapshot15086%_)))
    (define gerbil-ascent/program/index#extend-provider-row-witness!
      (lambda (_%witness15059%_ _%rows15060%_ _%columns15061%_)
        (let ((_%members15063%_
               (##structure-ref
                _%witness15059%_
                '1
                gerbil-ascent/program/index#provider-row-witness::t
                '#f))
              (_%counts15064%_
               (##structure-ref
                _%witness15059%_
                '2
                gerbil-ascent/program/index#provider-row-witness::t
                '#f)))
          (for-each
           (lambda (_%row15066%_)
             (let* ((_%member15073%_
                     (let ((_%$e15068%_
                            (let ()
                              (declare (not safe))
                              (hash-get _%members15063%_ _%row15066%_))))
                       (if _%$e15068%_
                           _%$e15068%_
                           (let ((_%fresh15071%_
                                  (let ((__tmp35192
                                         (let ()
                                           (declare (not safe))
                                           (hash-length _%members15063%_)))
                                        (__tmp35191
                                         (let ()
                                           (declare (not safe))
                                           (gerbil-ascent/table/funs#gerbil-ascent-index-key
                                            _%row15066%_
                                            _%columns15061%_))))
                                    (declare (not safe))
                                    (##structure
                                     gerbil-ascent/program/index#provider-row-member::t
                                     __tmp35192
                                     __tmp35191
                                     '0))))
                             (let ()
                               (declare (not safe))
                               (hash-put!
                                _%members15063%_
                                _%row15066%_
                                _%fresh15071%_))
                             _%fresh15071%_))))
                    (_%key15075%_
                     (##structure-ref
                      _%member15073%_
                      '2
                      gerbil-ascent/program/index#provider-row-member::t
                      '#f)))
               (##structure-set!
                _%member15073%_
                (+ '1
                   (##structure-ref
                    _%member15073%_
                    '3
                    gerbil-ascent/program/index#provider-row-member::t
                    '#f))
                '3
                gerbil-ascent/program/index#provider-row-member::t
                '#f)
               (let ((__tmp35193
                      (+ '1
                         (let ((_%$e15078%_
                                (let ()
                                  (declare (not safe))
                                  (hash-get _%counts15064%_ _%key15075%_))))
                           (if _%$e15078%_ _%$e15078%_ '0)))))
                 (declare (not safe))
                 (hash-put! _%counts15064%_ _%key15075%_ __tmp35193))))
           _%rows15060%_))
        _%witness15059%_))
    (define gerbil-ascent/program/index#build-provider-row-witness
      (lambda (_%rows15056%_ _%columns15057%_)
        (gerbil-ascent/program/index#extend-provider-row-witness!
         (let ((__tmp35195
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value)))
               (__tmp35194
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value))))
           (declare (not safe))
           (##structure
            gerbil-ascent/program/index#provider-row-witness::t
            __tmp35195
            __tmp35194))
         _%rows15056%_
         _%columns15057%_)))
    (define gerbil-ascent/program/index#row-indexes-plan-rules!
      (lambda (_%indexes15047%_ _%rules15048%_)
        ((##structure-ref
          _%indexes15047%_
          '3
          gerbil-ascent/program/index#row-indexes::t
          '#f)
         (lambda (_%accept!15050%_)
           (for-each
            (lambda (_%rule15052%_)
              (for-each
               (lambda (_%clause15054%_)
                 (if (let ((__tmp35196 (vector-ref _%clause15054%_ '0)))
                       (declare (not safe))
                       (##memq __tmp35196 '(atom negation aggregate)))
                     (_%accept!15050%_ (vector-ref _%clause15054%_ '1))
                     '#!void))
               (vector-ref _%rule15052%_ '1)))
            _%rules15048%_)))))
    (define gerbil-ascent/program/index#row-indexes-plan-actions!
      (lambda (_%indexes15040%_ _%actions15041%_)
        ((##structure-ref
          _%indexes15040%_
          '3
          gerbil-ascent/program/index#row-indexes::t
          '#f)
         (lambda (_%$%g1504215044%_)
           (gerbil-ascent/program/index#visit-action-atoms!
            _%actions15041%_
            _%$%g1504215044%_)))))
    (define gerbil-ascent/program/index#row-indexes-plan-positive-rules!
      (lambda (_%indexes15033%_ _%rules15034%_)
        ((##structure-ref
          _%indexes15033%_
          '3
          gerbil-ascent/program/index#row-indexes::t
          '#f)
         (lambda (_%accept!15036%_)
           (for-each
            (lambda (_%rule15038%_)
              (gerbil-ascent/program/index#visit-action-atoms!
               (vector-ref (vector-ref _%rule15038%_ '0) '1)
               _%accept!15036%_))
            _%rules15034%_)))))
    (define gerbil-ascent/program/index#empty-row-indexes
      (let ((__tmp35201
             (lambda (_%atom15007%_
                      _%environment15008%_
                      _%use-delta?15009%_
                      _%slot-terms15010%_)
               (let ()
                 (declare (not safe))
                 (error '"ASCENT empty index owner has no lookup consumer"))))
            (__tmp35198
             (let ((_%$%opt-lambda1501115017%_
                    (lambda (_%index15013%_
                             _%rows15014%_
                             _%reverse-order?15015%_)
                      '#!void)))
               (lambda _g35199_
                 (let ((_g35200_
                        (let () (declare (not safe)) (##length _g35199_))))
                   (cond ((let () (declare (not safe)) (##fx= _g35200_ 2))
                          (apply (lambda (_%index15020%_ _%rows15021%_)
                                   (let ((_%reverse-order?15023%_ '#f))
                                     (_%$%opt-lambda1501115017%_
                                      _%index15020%_
                                      _%rows15021%_
                                      _%reverse-order?15023%_)))
                                 _g35199_))
                         ((let () (declare (not safe)) (##fx= _g35200_ 3))
                          (apply _%$%opt-lambda1501115017%_ _g35199_))
                         (else
                          (##raise-wrong-number-of-arguments-exception
                           'case-lambda-dispatch
                           _g35199_)))))))
            (__tmp35197
             (lambda (_%visit!15029%_)
               (_%visit!15029%_
                (lambda (_%_15031%_)
                  (let ()
                    (declare (not safe))
                    (error '"ASCENT empty index owner has lookup requirements")))))))
        (declare (not safe))
        (##structure
         gerbil-ascent/program/index#row-indexes::t
         __tmp35201
         __tmp35198
         __tmp35197
         '#f)))
    (define gerbil-ascent/program/index#physical-index-entry::t
      (let ((__tmp35203 (list)) (__tmp35202 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/index#physical-index-entry::t
         'physical-index-entry
         __tmp35203
         '(version lookup shared? witness)
         __tmp35202
         '#f)))
    (define gerbil-ascent/program/index#physical-index-entry?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/index#physical-index-entry::t)))
    (define gerbil-ascent/program/index#make-physical-index-entry
      (lambda _%$args15004%_
        (apply make-instance
               gerbil-ascent/program/index#physical-index-entry::t
               _%$args15004%_)))
    (define gerbil-ascent/program/index#physical-index-entry-version
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#physical-index-entry::t
         'version)))
    (define gerbil-ascent/program/index#physical-index-entry-lookup
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#physical-index-entry::t
         'lookup)))
    (define gerbil-ascent/program/index#physical-index-entry-shared?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#physical-index-entry::t
         'shared?)))
    (define gerbil-ascent/program/index#physical-index-entry-witness
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#physical-index-entry::t
         'witness)))
    (define gerbil-ascent/program/index#physical-index-entry-version-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#physical-index-entry::t
         'version)))
    (define gerbil-ascent/program/index#physical-index-entry-lookup-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#physical-index-entry::t
         'lookup)))
    (define gerbil-ascent/program/index#physical-index-entry-shared?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#physical-index-entry::t
         'shared?)))
    (define gerbil-ascent/program/index#physical-index-entry-witness-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#physical-index-entry::t
         'witness)))
    (define gerbil-ascent/program/index#&physical-index-entry-version
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#physical-index-entry::t
         'version)))
    (define gerbil-ascent/program/index#&physical-index-entry-lookup
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#physical-index-entry::t
         'lookup)))
    (define gerbil-ascent/program/index#&physical-index-entry-shared?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#physical-index-entry::t
         'shared?)))
    (define gerbil-ascent/program/index#&physical-index-entry-witness
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#physical-index-entry::t
         'witness)))
    (define gerbil-ascent/program/index#&physical-index-entry-version-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#physical-index-entry::t
         'version)))
    (define gerbil-ascent/program/index#&physical-index-entry-lookup-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#physical-index-entry::t
         'lookup)))
    (define gerbil-ascent/program/index#&physical-index-entry-shared?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#physical-index-entry::t
         'shared?)))
    (define gerbil-ascent/program/index#&physical-index-entry-witness-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#physical-index-entry::t
         'witness)))
    (define gerbil-ascent/program/index#atom-index-view::t
      (let ((__tmp35205 (list)) (__tmp35204 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/index#atom-index-view::t
         'atom-index-view
         __tmp35205
         '(entry permutation)
         __tmp35204
         '#f)))
    (define gerbil-ascent/program/index#atom-index-view?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/index#atom-index-view::t)))
    (define gerbil-ascent/program/index#make-atom-index-view
      (lambda _%$args15001%_
        (apply make-instance
               gerbil-ascent/program/index#atom-index-view::t
               _%$args15001%_)))
    (define gerbil-ascent/program/index#atom-index-view-entry
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#atom-index-view::t
         'entry)))
    (define gerbil-ascent/program/index#atom-index-view-permutation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#atom-index-view::t
         'permutation)))
    (define gerbil-ascent/program/index#atom-index-view-entry-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#atom-index-view::t
         'entry)))
    (define gerbil-ascent/program/index#atom-index-view-permutation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#atom-index-view::t
         'permutation)))
    (define gerbil-ascent/program/index#&atom-index-view-entry
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#atom-index-view::t
         'entry)))
    (define gerbil-ascent/program/index#&atom-index-view-permutation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#atom-index-view::t
         'permutation)))
    (define gerbil-ascent/program/index#&atom-index-view-entry-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#atom-index-view::t
         'entry)))
    (define gerbil-ascent/program/index#&atom-index-view-permutation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#atom-index-view::t
         'permutation)))
    (define gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__%
      (lambda (_%all14970%_
               _%delta14971%_
               _%all-size14972%_
               _%delta-size14973%_
               _%all-version14974%_
               _%delta-version14975%_
               _%index-providers14976%_
               _%required?14977%_)
        (if _%required?14977%_
            (gerbil-ascent/program/index#make-required-row-indexes
             _%all14970%_
             _%delta14971%_
             _%all-size14972%_
             _%delta-size14973%_
             _%all-version14974%_
             _%delta-version14975%_
             _%index-providers14976%_)
            gerbil-ascent/program/index#empty-row-indexes)))
    (define gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__0
      (lambda (_%all14982%_
               _%delta14983%_
               _%all-size14984%_
               _%delta-size14985%_
               _%all-version14986%_
               _%delta-version14987%_
               _%index-providers14988%_)
        (let ((_%required?14990%_ '#t))
          (gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__%
           _%all14982%_
           _%delta14983%_
           _%all-size14984%_
           _%delta-size14985%_
           _%all-version14986%_
           _%delta-version14987%_
           _%index-providers14988%_
           _%required?14990%_))))
    (define gerbil-ascent/program/index#gerbil-ascent-make-row-indexes
      (lambda _g35206_
        (let ((_g35207_ (let () (declare (not safe)) (##length _g35206_))))
          (cond ((let () (declare (not safe)) (##fx= _g35207_ 7))
                 (apply gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__0
                        _g35206_))
                ((let () (declare (not safe)) (##fx= _g35207_ 8))
                 (apply gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__%
                        _g35206_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/index#gerbil-ascent-make-row-indexes
                  _g35206_))))))
    (define gerbil-ascent/program/index#make-required-row-indexes
      (lambda (_%all14670%_
               _%delta14671%_
               _%all-size14672%_
               _%delta-size14673%_
               _%all-version14674%_
               _%delta-version14675%_
               _%index-providers14676%_)
        (let ((_%all-indexes14689%_ '#f)
              (_%delta-indexes14690%_ '#f)
              (_%all-atoms14691%_ '#f)
              (_%delta-atoms14692%_ '#f)
              (_%layouts14693%_
               (let ((__tmp35208 (vector-length _%all14670%_)))
                 (declare (not safe))
                 (##make-vector __tmp35208 '#f)))
              (_%planned-atoms14694%_ '#f)
              (_%sharing?14695%_
               (let ((_%found?14678%_ '#f))
                 (vector-for-each
                  (lambda (_%provider14680%_)
                    (let ((_%next14686%_
                           (let ((_%$e14683%_ _%found?14678%_))
                             (if _%$e14683%_
                                 _%$e14683%_
                                 (let ()
                                   (declare (not safe))
                                   (gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider?
                                    _%provider14680%_))))))
                      (if (eq? _%next14686%_ '#!void)
                          '#!void
                          (set! _%found?14678%_ _%next14686%_))))
                  _%index-providers14676%_)
                 _%found?14678%_))
              (_%ordered-all14696%_ '#f)
              (_%ordered-delta14697%_ '#f))
          (letrec* ((_%ordered-cut14699%_
                     (lambda (_%captured14948%_
                              _%index14949%_
                              _%use-delta?14950%_)
                       (let* ((_%cache14962%_
                               (if _%use-delta?14950%_
                                   (let ((_%$e14952%_ _%ordered-delta14697%_))
                                     (if _%$e14952%_
                                         _%$e14952%_
                                         (let ((_%v14955%_
                                                (let ((__tmp35209
                                                       (vector-length
                                                        _%all14670%_)))
                                                  (declare (not safe))
                                                  (##make-vector
                                                   __tmp35209
                                                   '#f))))
                                           (set! _%ordered-delta14697%_
                                                 _%v14955%_)
                                           _%v14955%_)))
                                   (let ((_%$e14957%_ _%ordered-all14696%_))
                                     (if _%$e14957%_
                                         _%$e14957%_
                                         (let ((_%v14960%_
                                                (let ((__tmp35210
                                                       (vector-length
                                                        _%all14670%_)))
                                                  (declare (not safe))
                                                  (##make-vector
                                                   __tmp35210
                                                   '#f))))
                                           (set! _%ordered-all14696%_
                                                 _%v14960%_)
                                           _%v14960%_)))))
                              (_%prior14964%_
                               (vector-ref _%cache14962%_ _%index14949%_)))
                         (if (and _%prior14964%_
                                  (eq? (car _%prior14964%_) _%captured14948%_))
                             (cdr _%prior14964%_)
                             (let ((_%rows14967%_
                                    (if (eq? (##structure-ref
                                              _%captured14948%_
                                              '4
                                              gerbil-ascent/core/relation-view#relation-view::t
                                              '#f)
                                             'delta)
                                        (let ()
                                          (declare (not safe))
                                          (gerbil-ascent/core/relation-view#gerbil-ascent-view-rows
                                           _%captured14948%_))
                                        (reverse (let ()
                                                   (declare (not safe))
                                                   (gerbil-ascent/core/relation-view#gerbil-ascent-view-rows
                                                    _%captured14948%_))))))
                               (vector-set!
                                _%cache14962%_
                                _%index14949%_
                                (cons _%captured14948%_ _%rows14967%_))
                               _%rows14967%_)))))
                    (_%plan!14700%_
                     (lambda (_%visit!14941%_)
                       (if (or _%all-indexes14689%_ _%delta-indexes14690%_)
                           (let ()
                             (declare (not safe))
                             (error '"cannot replan a live physical index"))
                           '#!void)
                       (let ((_%fresh14946%_
                              (if _%sharing?14695%_
                                  (gerbil-ascent/program/index#collect-sharing-atoms
                                   _%visit!14941%_
                                   _%index-providers14676%_)
                                  '#f)))
                         (set! _%planned-atoms14694%_
                               (if (pair? _%fresh14946%_)
                                   _%fresh14946%_
                                   '#f)))))
                    (_%ensure-layouts!14701%_
                     (lambda ()
                       (if _%planned-atoms14694%_
                           (let ((_%requirements14856%_
                                  (let ((__tmp35211
                                         (vector-length _%all14670%_)))
                                    (declare (not safe))
                                    (##make-vector __tmp35211 '())))
                                 (_%fresh14857%_
                                  (let ((__tmp35212
                                         (vector-length _%all14670%_)))
                                    (declare (not safe))
                                    (##make-vector __tmp35212 '#f))))
                             (for-each
                              (lambda (_%atom14859%_)
                                (let ((_%i14861%_
                                       (vector-ref _%atom14859%_ '0))
                                      (_%columns14862%_
                                       (vector-ref _%atom14859%_ '2)))
                                  (if (and (let ((__tmp35213
                                                  (vector-ref
                                                   _%index-providers14676%_
                                                   _%i14861%_)))
                                             (declare (not safe))
                                             (gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider?
                                              __tmp35213))
                                           (= (length _%columns14862%_)
                                              (let ((__tmp35214
                                                     (let ((_%seen14864%_
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (make-hash-table-eq))))
                                                       (for-each
                                                        (lambda (_%c14866%_)
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (__hash-put!
                                                             _%seen14864%_
                                                             _%c14866%_
                                                             '#t)))
                                                        _%columns14862%_)
                                                       _%seen14864%_)))
                                                (declare (not safe))
                                                (__hash-length __tmp35214))))
                                      (vector-set!
                                       _%requirements14856%_
                                       _%i14861%_
                                       (cons _%columns14862%_
                                             (vector-ref
                                              _%requirements14856%_
                                              _%i14861%_)))
                                      '#!void)))
                              _%planned-atoms14694%_)
                             (let ((_%$start14868%_ '0)
                                   (_%$end14870%_
                                    (vector-length _%all14670%_)))
                               (if (> _%$start14868%_ _%$end14870%_)
                                   (let ((_%$start14873%_ '0)
                                         (_%$end14875%_
                                          (vector-length _%all14670%_))
                                         (_%$step14877%_ '-1))
                                     (if (> _%$step14877%_ '0)
                                         (let _%loop14881%_ ((_%k14884%_
                                                              _%$start14873%_))
                                           (if (< _%k14884%_ _%$end14875%_)
                                               (begin
                                                 (let ((_%columns14890%_
                                                        (vector-ref
                                                         _%requirements14856%_
                                                         _%k14884%_)))
                                                   (if (pair? _%columns14890%_)
                                                       (let ((_%layout14892%_
                                                              (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gerbil-ascent/table/index-sharing#gerbil-ascent-index-sharing-layout
                         _%columns14890%_))))
                 (vector-set!
                  _%fresh14857%_
                  _%k14884%_
                  (if (> (let ()
                           (declare (not safe))
                           (__hash-length _%layout14892%_))
                         '0)
                      _%layout14892%_
                      '#f)))
               '#!void))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (_%loop14881%_
                                                  (+ _%k14884%_
                                                     _%$step14877%_)))
                                               '#!void))
                                         (if (< _%$step14877%_ '0)
                                             (let _%loop14895%_ ((_%k14897%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          _%$start14873%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (if (> _%k14897%_ _%$end14875%_)
                                                   (begin
                                                     (let ((_%columns14902%_
                                                            (vector-ref
                                                             _%requirements14856%_
                                                             _%k14897%_)))
                                                       (if (pair? _%columns14902%_)
                                                           (let ((_%layout14904%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (let ()
                            (declare (not safe))
                            (gerbil-ascent/table/index-sharing#gerbil-ascent-index-sharing-layout
                             _%columns14902%_))))
                     (vector-set!
                      _%fresh14857%_
                      _%k14897%_
                      (if (> (let ()
                               (declare (not safe))
                               (__hash-length _%layout14904%_))
                             '0)
                          _%layout14904%_
                          '#f)))
                   '#!void))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (_%loop14895%_
                                                      (+ _%k14897%_
                                                         _%$step14877%_)))
                                                   '#!void))
                                             (let ()
                                               (raise-contract-violation-error
                                                '"contract violation"
                                                'context:
                                                'gerbil-ascent/program/index
                                                'contract:
                                                '(not (zero? -1))
                                                'value:
                                                _%$step14877%_)
                                               '#!void))))
                                   (let ((_%$start14907%_ '0)
                                         (_%$end14909%_
                                          (vector-length _%all14670%_))
                                         (_%$step14911%_ '1))
                                     (if (> _%$step14911%_ '0)
                                         (let _%loop14915%_ ((_%k14918%_
                                                              _%$start14907%_))
                                           (if (< _%k14918%_ _%$end14909%_)
                                               (begin
                                                 (let ((_%columns14924%_
                                                        (vector-ref
                                                         _%requirements14856%_
                                                         _%k14918%_)))
                                                   (if (pair? _%columns14924%_)
                                                       (let ((_%layout14926%_
                                                              (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gerbil-ascent/table/index-sharing#gerbil-ascent-index-sharing-layout
                         _%columns14924%_))))
                 (vector-set!
                  _%fresh14857%_
                  _%k14918%_
                  (if (> (let ()
                           (declare (not safe))
                           (__hash-length _%layout14926%_))
                         '0)
                      _%layout14926%_
                      '#f)))
               '#!void))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (_%loop14915%_
                                                  (+ _%k14918%_
                                                     _%$step14911%_)))
                                               '#!void))
                                         (if (< _%$step14911%_ '0)
                                             (let _%loop14929%_ ((_%k14931%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          _%$start14907%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (if (> _%k14931%_ _%$end14909%_)
                                                   (begin
                                                     (let ((_%columns14936%_
                                                            (vector-ref
                                                             _%requirements14856%_
                                                             _%k14931%_)))
                                                       (if (pair? _%columns14936%_)
                                                           (let ((_%layout14938%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (let ()
                            (declare (not safe))
                            (gerbil-ascent/table/index-sharing#gerbil-ascent-index-sharing-layout
                             _%columns14936%_))))
                     (vector-set!
                      _%fresh14857%_
                      _%k14931%_
                      (if (> (let ()
                               (declare (not safe))
                               (__hash-length _%layout14938%_))
                             '0)
                          _%layout14938%_
                          '#f)))
                   '#!void))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (_%loop14929%_
                                                      (+ _%k14931%_
                                                         _%$step14911%_)))
                                                   '#!void))
                                             (let ()
                                               (raise-contract-violation-error
                                                '"contract violation"
                                                'context:
                                                'gerbil-ascent/program/index
                                                'contract:
                                                '(not (zero? 1))
                                                'value:
                                                _%$step14911%_)
                                               '#!void))))))
                             (set! _%layouts14693%_ _%fresh14857%_)
                             (set! _%planned-atoms14694%_ '#f))
                           '#!void)))
                    (_%visit-parts14702%_
                     (lambda (_%atom14847%_
                              _%environment14848%_
                              _%use-delta?14849%_
                              _%slot-terms14850%_
                              _%consume14851%_)
                       (let ((_%captured14853%_
                              (vector-ref
                               (if _%use-delta?14849%_
                                   _%delta14671%_
                                   _%all14670%_)
                               (vector-ref _%atom14847%_ '0))))
                         (if (let ()
                               (declare (not safe))
                               (gerbil-ascent/core/relation-view#gerbil-ascent-admitted-row-parts?
                                _%captured14853%_))
                             (if (let ((__tmp35215
                                        (vector-ref
                                         _%index-providers14676%_
                                         (vector-ref _%atom14847%_ '0))))
                                   (declare (not safe))
                                   (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                                    __tmp35215))
                                 (begin
                                   ((if _%slot-terms14850%_
                                        gerbil-ascent/core/relation-view#gerbil-ascent-visit-admitted-view-parts!
                                        gerbil-ascent/core/relation-view#gerbil-ascent-visit-view-parts!)
                                    _%captured14853%_
                                    (vector-ref _%atom14847%_ '2)
                                    (if _%slot-terms14850%_
                                        (let ((__tmp35217
                                               (vector-ref _%atom14847%_ '1))
                                              (__tmp35216
                                               (vector-ref _%atom14847%_ '2)))
                                          (declare (not safe))
                                          (gerbil-ascent/core/positive-plan#gerbil-ascent-index-key
                                           __tmp35217
                                           __tmp35216
                                           _%environment14848%_
                                           _%slot-terms14850%_))
                                        (let ((__tmp35218
                                               (vector-ref _%atom14847%_ '4)))
                                          (declare (not safe))
                                          (gerbil-ascent/core/positive-plan#gerbil-ascent-index-key/terms
                                           __tmp35218
                                           _%environment14848%_)))
                                    _%consume14851%_)
                                   '#t)
                                 '#f)
                             '#f))))
                    (_%indexed-rows__3516335164%_
                     (lambda (_%atom14735%_
                              _%environment14736%_
                              _%use-delta?14737%_
                              _%slot-terms14738%_
                              _%ordered?14739%_)
                       (let* ((_%index14741%_ (vector-ref _%atom14735%_ '0))
                              (_%columns14743%_ (vector-ref _%atom14735%_ '2))
                              (_%captured14745%_
                               (vector-ref
                                (if _%use-delta?14737%_
                                    _%delta14671%_
                                    _%all14670%_)
                                _%index14741%_))
                              (_%rows14747%_
                               (if (and _%ordered?14739%_
                                        (let ()
                                          (declare (not safe))
                                          (##structure-instance-of?
                                           _%captured14745%_
                                           'gerbil-ascent/core/relation-view#relation-view::t)))
                                   (_%ordered-cut14699%_
                                    _%captured14745%_
                                    _%index14741%_
                                    _%use-delta?14737%_)
                                   _%captured14745%_)))
                         (if (let ()
                               (declare (not safe))
                               (##structure-instance-of?
                                _%rows14747%_
                                'gerbil-ascent/core/relation-view#relation-view::t))
                             (let ((__tmp35219
                                    (if _%slot-terms14738%_
                                        (let ((__tmp35220
                                               (vector-ref _%atom14735%_ '1)))
                                          (declare (not safe))
                                          (gerbil-ascent/core/positive-plan#gerbil-ascent-index-key
                                           __tmp35220
                                           _%columns14743%_
                                           _%environment14736%_
                                           _%slot-terms14738%_))
                                        (let ((__tmp35221
                                               (vector-ref _%atom14735%_ '4)))
                                          (declare (not safe))
                                          (gerbil-ascent/core/positive-plan#gerbil-ascent-index-key/terms
                                           __tmp35221
                                           _%environment14736%_)))))
                               (declare (not safe))
                               (gerbil-ascent/core/relation-view#gerbil-ascent-view-select
                                _%rows14747%_
                                _%columns14743%_
                                __tmp35219))
                             (if (or (null? _%columns14743%_)
                                     (< (vector-ref
                                         (if _%use-delta?14737%_
                                             _%delta-size14673%_
                                             _%all-size14672%_)
                                         _%index14741%_)
                                        '32))
                                 _%rows14747%_
                                 (begin
                                   (_%ensure-layouts!14701%_)
                                   (let* ((_%identities14763%_
                                           (if _%use-delta?14737%_
                                               (let ((_%$e14753%_
                                                      _%delta-atoms14692%_))
                                                 (if _%$e14753%_
                                                     _%$e14753%_
                                                     (let ((_%fresh14756%_
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (make-hash-table-eq))))
                                                       (set! _%delta-atoms14692%_
                                                             _%fresh14756%_)
                                                       _%fresh14756%_)))
                                               (let ((_%$e14758%_
                                                      _%all-atoms14691%_))
                                                 (if _%$e14758%_
                                                     _%$e14758%_
                                                     (let ((_%fresh14761%_
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (make-hash-table-eq))))
                                                       (set! _%all-atoms14691%_
                                                             _%fresh14761%_)
                                                       _%fresh14761%_)))))
                                          (_%version14765%_
                                           (vector-ref
                                            (if _%use-delta?14737%_
                                                _%delta-version14675%_
                                                _%all-version14674%_)
                                            _%index14741%_))
                                          (_%view14810%_
                                           (let ((_%$e14767%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (__hash-get
                                                     _%identities14763%_
                                                     _%atom14735%_))))
                                             (if _%$e14767%_
                                                 _%$e14767%_
                                                 (let* ((_%layout14770%_
                                                         (vector-ref
                                                          _%layouts14693%_
                                                          _%index14741%_))
                                                        (_%permutation14772%_
                                                         (if _%layout14770%_
                                                             (let ((__tmp35222
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (list-sort < _%columns14743%_)))
                       (declare (not safe))
                       (hash-get _%layout14770%_ __tmp35222))
                     '#f))
                (_%physical-columns14777%_
                 (let ((_%$e14774%_ _%permutation14772%_))
                   (if _%$e14774%_ _%$e14774%_ _%columns14743%_)))
                (_%caches14789%_
                 (if _%use-delta?14737%_
                     (let ((_%$e14779%_ _%delta-indexes14690%_))
                       (if _%$e14779%_
                           _%$e14779%_
                           (let ((_%fresh14782%_
                                  (let ((__tmp35223
                                         (vector-length _%delta14671%_)))
                                    (declare (not safe))
                                    (##make-vector __tmp35223 '#f))))
                             (set! _%delta-indexes14690%_ _%fresh14782%_)
                             _%fresh14782%_)))
                     (let ((_%$e14784%_ _%all-indexes14689%_))
                       (if _%$e14784%_
                           _%$e14784%_
                           (let ((_%fresh14787%_
                                  (let ((__tmp35224
                                         (vector-length _%all14670%_)))
                                    (declare (not safe))
                                    (##make-vector __tmp35224 '#f))))
                             (set! _%all-indexes14689%_ _%fresh14787%_)
                             _%fresh14787%_)))))
                (_%cache14796%_
                 (let ((_%$e14791%_
                        (vector-ref _%caches14789%_ _%index14741%_)))
                   (if _%$e14791%_
                       _%$e14791%_
                       (let ((_%fresh14794%_
                              (let ()
                                (declare (not safe))
                                (make-hash-table__%
                                 '#f
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value))))
                         (vector-set!
                          _%caches14789%_
                          _%index14741%_
                          _%fresh14794%_)
                         _%fresh14794%_))))
                (_%shared14798%_
                 (let ()
                   (declare (not safe))
                   (hash-get _%cache14796%_ _%physical-columns14777%_)))
                (_%resolved14805%_
                 (let ((_%$e14800%_ _%shared14798%_))
                   (if _%$e14800%_
                       _%$e14800%_
                       (let ((_%fresh14803%_
                              (let ((__tmp35225
                                     (if _%permutation14772%_ '#t '#f)))
                                (declare (not safe))
                                (##structure
                                 gerbil-ascent/program/index#physical-index-entry::t
                                 '#f
                                 '#f
                                 __tmp35225
                                 '#f))))
                         (let ()
                           (declare (not safe))
                           (hash-put!
                            _%cache14796%_
                            _%physical-columns14777%_
                            _%fresh14803%_))
                         _%fresh14803%_))))
                (_%view14808%_
                 (let ()
                   (declare (not safe))
                   (##structure
                    gerbil-ascent/program/index#atom-index-view::t
                    _%resolved14805%_
                    _%permutation14772%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (let ()
                                                     (declare (not safe))
                                                     (__hash-put!
                                                      _%identities14763%_
                                                      _%atom14735%_
                                                      _%view14808%_))
                                                   _%view14808%_))))
                                          (_%entry14812%_
                                           (##structure-ref
                                            _%view14810%_
                                            '1
                                            gerbil-ascent/program/index#atom-index-view::t
                                            '#f))
                                          (_%permutation14814%_
                                           (##structure-ref
                                            _%view14810%_
                                            '2
                                            gerbil-ascent/program/index#atom-index-view::t
                                            '#f))
                                          (_%provider14816%_
                                           (vector-ref
                                            _%index-providers14676%_
                                            _%index14741%_))
                                          (_%lookup14823%_
                                           (if (and (##structure-ref
                                                     _%entry14812%_
                                                     '1
                                                     gerbil-ascent/program/index#physical-index-entry::t
                                                     '#f)
                                                    (= (##structure-ref
                                                        _%entry14812%_
                                                        '1
                                                        gerbil-ascent/program/index#physical-index-entry::t
                                                        '#f)
                                                       _%version14765%_))
                                               (##structure-ref
                                                _%entry14812%_
                                                '2
                                                gerbil-ascent/program/index#physical-index-entry::t
                                                '#f)
                                               (let* ((_%members14818%_
                                                       (if _%permutation14814%_
                                                           '#f
                                                           (if (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                          _%provider14816%_))
                       '#f
                       (gerbil-ascent/program/index#build-provider-row-witness
                        _%rows14747%_
                        _%columns14743%_))))
              (_%built14820%_
               (if _%permutation14814%_
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/table/index-sharing#gerbil-ascent-shared-index-build
                      _%rows14747%_
                      _%permutation14814%_))
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/table/access#gerbil-ascent-physical-index-build
                      _%provider14816%_
                      _%rows14747%_
                      _%columns14743%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (##structure-set!
                                                  _%entry14812%_
                                                  _%built14820%_
                                                  '2
                                                  gerbil-ascent/program/index#physical-index-entry::t
                                                  '#f)
                                                 (##structure-set!
                                                  _%entry14812%_
                                                  _%members14818%_
                                                  '4
                                                  gerbil-ascent/program/index#physical-index-entry::t
                                                  '#f)
                                                 (##structure-set!
                                                  _%entry14812%_
                                                  _%version14765%_
                                                  '1
                                                  gerbil-ascent/program/index#physical-index-entry::t
                                                  '#f)
                                                 _%built14820%_))))
                                     (if (if _%permutation14814%_
                                             '#f
                                             (and (let ()
                                                    (declare (not safe))
                                                    (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                                                     _%provider14816%_))
                                                  (null? (cdr _%columns14743%_))))
                                         (let ((__tmp35226
                                                (let ((__tmp35228
                                                       (car (vector-ref
                                                             _%atom14735%_
                                                             '4)))
                                                      (__tmp35227
                                                       (if _%slot-terms14738%_
                                                           (car _%slot-terms14738%_)
                                                           '#f)))
                                                  (declare (not safe))
                                                  (gerbil-ascent/core/positive-plan#gerbil-ascent-index-value
                                                   __tmp35228
                                                   _%environment14736%_
                                                   __tmp35227))))
                                           (declare (not safe))
                                           (gerbil-ascent/table/access#gerbil-ascent-physical-index-single-rows
                                            _%lookup14823%_
                                            __tmp35226))
                                         (let ((_%key14826%_
                                                (if _%slot-terms14738%_
                                                    (let ((__tmp35229
                                                           (vector-ref
                                                            _%atom14735%_
                                                            '1)))
                                                      (declare (not safe))
                                                      (gerbil-ascent/core/positive-plan#gerbil-ascent-index-key
                                                       __tmp35229
                                                       _%columns14743%_
                                                       _%environment14736%_
                                                       _%slot-terms14738%_))
                                                    (let ((__tmp35230
                                                           (vector-ref
                                                            _%atom14735%_
                                                            '4)))
                                                      (declare (not safe))
                                                      (gerbil-ascent/core/positive-plan#gerbil-ascent-index-key/terms
                                                       __tmp35230
                                                       _%environment14736%_)))))
                                           (if _%permutation14814%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gerbil-ascent/table/index-sharing#gerbil-ascent-shared-index-rows
                                                  _%lookup14823%_
                                                  _%columns14743%_
                                                  _%key14826%_))
                                               (if (let ()
                                                     (declare (not safe))
                                                     (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                                                      _%provider14816%_))
                                                   (let ()
                                                     (declare (not safe))
                                                     (gerbil-ascent/table/access#gerbil-ascent-physical-index-rows
                                                      _%provider14816%_
                                                      _%lookup14823%_
                                                      _%key14826%_))
                                                   (let ((__tmp35232
                                                          (lambda (_%failure14828%_)
                                                            (##structure-set!
                                                             _%entry14812%_
                                                             '#f
                                                             '1
                                                             gerbil-ascent/program/index#physical-index-entry::t
                                                             '#f)
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (raise _%failure14828%_))))
                                                         (__tmp35231
                                                          (lambda ()
                                                            (gerbil-ascent/program/index#checked-provider-rows
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gerbil-ascent/table/access#gerbil-ascent-physical-index-rows
                        _%provider14816%_
                        _%lookup14823%_
                        _%key14826%_))
                     (vector-ref _%atom14735%_ '1)
                     (##structure-ref
                      _%entry14812%_
                      '4
                      gerbil-ascent/program/index#physical-index-entry::t
                      '#f)
                     _%key14826%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (declare (not safe))
                                                     (__with-catch
                                                      __tmp35232
                                                      __tmp35231)))))))))))))
                    (_%indexed-rows__0__3516535166%_
                     (lambda (_%atom14834%_
                              _%environment14835%_
                              _%use-delta?14836%_
                              _%slot-terms14837%_)
                       (let ((_%ordered?14839%_ '#f))
                         (_%indexed-rows__3516335164%_
                          _%atom14834%_
                          _%environment14835%_
                          _%use-delta?14836%_
                          _%slot-terms14837%_
                          _%ordered?14839%_))))
                    (_%indexed-rows14703%_
                     (lambda _g35233_
                       (let ((_g35234_
                              (let ()
                                (declare (not safe))
                                (##length _g35233_))))
                         (cond ((let ()
                                  (declare (not safe))
                                  (##fx= _g35234_ 4))
                                (apply _%indexed-rows__0__3516535166%_
                                       _g35233_))
                               ((let ()
                                  (declare (not safe))
                                  (##fx= _g35234_ 5))
                                (apply _%indexed-rows__3516335164%_ _g35233_))
                               (else
                                (##raise-wrong-number-of-arguments-exception
                                 'case-lambda-dispatch
                                 _g35233_))))))
                    (_%advance-all-indexes!__3516735168%_
                     (lambda (_%index14707%_
                              _%new-rows14708%_
                              _%reverse-order?14709%_)
                       (let ((_%cache14711%_
                              (if _%all-indexes14689%_
                                  (vector-ref
                                   _%all-indexes14689%_
                                   _%index14707%_)
                                  '#f)))
                         (if (and _%cache14711%_ (pair? _%new-rows14708%_))
                             (let ((_%rows14713%_
                                    (if _%reverse-order?14709%_
                                        (reverse _%new-rows14708%_)
                                        _%new-rows14708%_))
                                   (_%version14714%_
                                    (vector-ref
                                     _%all-version14674%_
                                     _%index14707%_))
                                   (_%provider14715%_
                                    (vector-ref
                                     _%index-providers14676%_
                                     _%index14707%_)))
                               (let ((__tmp35235
                                      (lambda (_%columns14717%_ _%entry14718%_)
                                        (if (and (##structure-ref
                                                  _%entry14718%_
                                                  '1
                                                  gerbil-ascent/program/index#physical-index-entry::t
                                                  '#f)
                                                 (= (##structure-ref
                                                     _%entry14718%_
                                                     '1
                                                     gerbil-ascent/program/index#physical-index-entry::t
                                                     '#f)
                                                    _%version14714%_))
                                            (begin
                                              (##structure-set!
                                               _%entry14718%_
                                               '#f
                                               '1
                                               gerbil-ascent/program/index#physical-index-entry::t
                                               '#f)
                                              (let ((_%extended14720%_
                                                     (if (##structure-ref
                                                          _%entry14718%_
                                                          '3
                                                          gerbil-ascent/program/index#physical-index-entry::t
                                                          '#f)
                                                         (let ((__tmp35236
                                                                (##structure-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%entry14718%_
                         '2
                         gerbil-ascent/program/index#physical-index-entry::t
                         '#f)))
                   (declare (not safe))
                   (gerbil-ascent/table/index-sharing#gerbil-ascent-shared-index-extend!
                    __tmp35236
                    _%rows14713%_))
                 (let ((__tmp35237
                        (##structure-ref
                         _%entry14718%_
                         '2
                         gerbil-ascent/program/index#physical-index-entry::t
                         '#f)))
                   (declare (not safe))
                   (gerbil-ascent/table/access#gerbil-ascent-physical-index-extend!
                    _%provider14715%_
                    __tmp35237
                    _%rows14713%_
                    _%columns14717%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (##structure-set!
                                                 _%entry14718%_
                                                 _%extended14720%_
                                                 '2
                                                 gerbil-ascent/program/index#physical-index-entry::t
                                                 '#f)
                                                (if (##structure-ref
                                                     _%entry14718%_
                                                     '4
                                                     gerbil-ascent/program/index#physical-index-entry::t
                                                     '#f)
                                                    (gerbil-ascent/program/index#extend-provider-row-witness!
                                                     (##structure-ref
                                                      _%entry14718%_
                                                      '4
                                                      gerbil-ascent/program/index#physical-index-entry::t
                                                      '#f)
                                                     _%rows14713%_
                                                     _%columns14717%_)
                                                    '#!void)
                                                (##structure-set!
                                                 _%entry14718%_
                                                 (+ _%version14714%_ '1)
                                                 '1
                                                 gerbil-ascent/program/index#physical-index-entry::t
                                                 '#f)))
                                            '#!void))))
                                 (declare (not safe))
                                 (hash-for-each __tmp35235 _%cache14711%_)))
                             '#!void))))
                    (_%advance-all-indexes!__0__3516935170%_
                     (lambda (_%index14725%_ _%new-rows14726%_)
                       (let ((_%reverse-order?14728%_ '#f))
                         (_%advance-all-indexes!__3516735168%_
                          _%index14725%_
                          _%new-rows14726%_
                          _%reverse-order?14728%_))))
                    (_%advance-all-indexes!14704%_
                     (lambda _g35238_
                       (let ((_g35239_
                              (let ()
                                (declare (not safe))
                                (##length _g35238_))))
                         (cond ((let ()
                                  (declare (not safe))
                                  (##fx= _g35239_ 2))
                                (apply _%advance-all-indexes!__0__3516935170%_
                                       _g35238_))
                               ((let ()
                                  (declare (not safe))
                                  (##fx= _g35239_ 3))
                                (apply _%advance-all-indexes!__3516735168%_
                                       _g35238_))
                               (else
                                (##raise-wrong-number-of-arguments-exception
                                 'case-lambda-dispatch
                                 _g35238_)))))))
            (let ()
              (declare (not safe))
              (##structure
               gerbil-ascent/program/index#row-indexes::t
               _%indexed-rows14703%_
               _%advance-all-indexes!14704%_
               _%plan!14700%_
               _%visit-parts14702%_))))))))
