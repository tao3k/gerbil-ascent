prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/table

(begin
  (declare-type
   gerbil-ascent/table/index-sharing#gerbil-ascent-index-sharing-certificate?
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-type
   gerbil-ascent/table/index-sharing#ordered-subset?
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-class
   gerbil-ascent/table/index-sharing#column-order::t
   (@class gerbil-ascent/table/index-sharing#column-order::t
           ()
           (object::t t::t)
           (sets successors)
           (sets successors)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/table/index-sharing#column-order::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/index-sharing#column-order::t)
    'class::t))
  (declare-type
   gerbil-ascent/table/index-sharing#column-order?
   (@predicate gerbil-ascent/table/index-sharing#column-order::t))
  (declare-type
   gerbil-ascent/table/index-sharing#make-column-order
   (@constructor gerbil-ascent/table/index-sharing#column-order::t))
  (declare-type
   gerbil-ascent/table/index-sharing#column-order-sets
   (@accessor gerbil-ascent/table/index-sharing#column-order::t sets #t))
  (declare-type
   gerbil-ascent/table/index-sharing#column-order-successors
   (@accessor gerbil-ascent/table/index-sharing#column-order::t successors #t))
  (declare-type
   gerbil-ascent/table/index-sharing#column-order-sets-set!
   (@mutator gerbil-ascent/table/index-sharing#column-order::t sets #t))
  (declare-type
   gerbil-ascent/table/index-sharing#column-order-successors-set!
   (@mutator gerbil-ascent/table/index-sharing#column-order::t successors #t))
  (declare-type
   gerbil-ascent/table/index-sharing#&column-order-sets
   (@accessor gerbil-ascent/table/index-sharing#column-order::t sets #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&column-order-successors
   (@accessor gerbil-ascent/table/index-sharing#column-order::t successors #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&column-order-sets-set!
   (@mutator gerbil-ascent/table/index-sharing#column-order::t sets #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&column-order-successors-set!
   (@mutator gerbil-ascent/table/index-sharing#column-order::t successors #f))
  (declare-type
   gerbil-ascent/table/index-sharing#compile-column-order
   (@lambda 1
            #f
            signature:
            (return:
             gerbil-ascent/table/index-sharing#column-order::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-type
   gerbil-ascent/table/index-sharing#distinct-ordered-columns?
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-type
   gerbil-ascent/table/index-sharing#columns-lexicographic<?
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-type
   gerbil-ascent/table/index-sharing#normalize-column-requirements
   (@lambda 1
            #f
            signature:
            (return:
             vector::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-type
   gerbil-ascent/table/index-sharing#gerbil-ascent-index-sharing-layout
   (@lambda 1
            #f
            signature:
            (return:
             HashTable::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-class
   gerbil-ascent/table/index-sharing#shared-index::t
   (@class gerbil-ascent/table/index-sharing#shared-index::t
           ()
           (object::t t::t)
           (columns root ordinal views projection key-plans)
           (columns root ordinal views projection key-plans)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/table/index-sharing#shared-index::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/index-sharing#shared-index::t)
    'class::t))
  (declare-type
   gerbil-ascent/table/index-sharing#shared-index?
   (@predicate gerbil-ascent/table/index-sharing#shared-index::t))
  (declare-type
   gerbil-ascent/table/index-sharing#make-shared-index
   (@constructor gerbil-ascent/table/index-sharing#shared-index::t))
  (declare-type
   gerbil-ascent/table/index-sharing#shared-index-columns
   (@accessor gerbil-ascent/table/index-sharing#shared-index::t columns #t))
  (declare-type
   gerbil-ascent/table/index-sharing#shared-index-root
   (@accessor gerbil-ascent/table/index-sharing#shared-index::t root #t))
  (declare-type
   gerbil-ascent/table/index-sharing#shared-index-ordinal
   (@accessor gerbil-ascent/table/index-sharing#shared-index::t ordinal #t))
  (declare-type
   gerbil-ascent/table/index-sharing#shared-index-views
   (@accessor gerbil-ascent/table/index-sharing#shared-index::t views #t))
  (declare-type
   gerbil-ascent/table/index-sharing#shared-index-projection
   (@accessor gerbil-ascent/table/index-sharing#shared-index::t projection #t))
  (declare-type
   gerbil-ascent/table/index-sharing#shared-index-key-plans
   (@accessor gerbil-ascent/table/index-sharing#shared-index::t key-plans #t))
  (declare-type
   gerbil-ascent/table/index-sharing#shared-index-columns-set!
   (@mutator gerbil-ascent/table/index-sharing#shared-index::t columns #t))
  (declare-type
   gerbil-ascent/table/index-sharing#shared-index-root-set!
   (@mutator gerbil-ascent/table/index-sharing#shared-index::t root #t))
  (declare-type
   gerbil-ascent/table/index-sharing#shared-index-ordinal-set!
   (@mutator gerbil-ascent/table/index-sharing#shared-index::t ordinal #t))
  (declare-type
   gerbil-ascent/table/index-sharing#shared-index-views-set!
   (@mutator gerbil-ascent/table/index-sharing#shared-index::t views #t))
  (declare-type
   gerbil-ascent/table/index-sharing#shared-index-projection-set!
   (@mutator gerbil-ascent/table/index-sharing#shared-index::t projection #t))
  (declare-type
   gerbil-ascent/table/index-sharing#shared-index-key-plans-set!
   (@mutator gerbil-ascent/table/index-sharing#shared-index::t key-plans #t))
  (declare-type
   gerbil-ascent/table/index-sharing#&shared-index-columns
   (@accessor gerbil-ascent/table/index-sharing#shared-index::t columns #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&shared-index-root
   (@accessor gerbil-ascent/table/index-sharing#shared-index::t root #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&shared-index-ordinal
   (@accessor gerbil-ascent/table/index-sharing#shared-index::t ordinal #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&shared-index-views
   (@accessor gerbil-ascent/table/index-sharing#shared-index::t views #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&shared-index-projection
   (@accessor gerbil-ascent/table/index-sharing#shared-index::t projection #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&shared-index-key-plans
   (@accessor gerbil-ascent/table/index-sharing#shared-index::t key-plans #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&shared-index-columns-set!
   (@mutator gerbil-ascent/table/index-sharing#shared-index::t columns #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&shared-index-root-set!
   (@mutator gerbil-ascent/table/index-sharing#shared-index::t root #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&shared-index-ordinal-set!
   (@mutator gerbil-ascent/table/index-sharing#shared-index::t ordinal #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&shared-index-views-set!
   (@mutator gerbil-ascent/table/index-sharing#shared-index::t views #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&shared-index-projection-set!
   (@mutator gerbil-ascent/table/index-sharing#shared-index::t projection #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&shared-index-key-plans-set!
   (@mutator gerbil-ascent/table/index-sharing#shared-index::t key-plans #f))
  (declare-class
   gerbil-ascent/table/index-sharing#column-projection::t
   (@class gerbil-ascent/table/index-sharing#column-projection::t
           ()
           (object::t t::t)
           (columns writes frame)
           (columns writes frame)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/table/index-sharing#column-projection::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/index-sharing#column-projection::t)
    'class::t))
  (declare-type
   gerbil-ascent/table/index-sharing#column-projection?
   (@predicate gerbil-ascent/table/index-sharing#column-projection::t))
  (declare-type
   gerbil-ascent/table/index-sharing#make-column-projection
   (@constructor gerbil-ascent/table/index-sharing#column-projection::t))
  (declare-type
   gerbil-ascent/table/index-sharing#column-projection-columns
   (@accessor
    gerbil-ascent/table/index-sharing#column-projection::t
    columns
    #t))
  (declare-type
   gerbil-ascent/table/index-sharing#column-projection-writes
   (@accessor
    gerbil-ascent/table/index-sharing#column-projection::t
    writes
    #t))
  (declare-type
   gerbil-ascent/table/index-sharing#column-projection-frame
   (@accessor gerbil-ascent/table/index-sharing#column-projection::t frame #t))
  (declare-type
   gerbil-ascent/table/index-sharing#column-projection-columns-set!
   (@mutator
    gerbil-ascent/table/index-sharing#column-projection::t
    columns
    #t))
  (declare-type
   gerbil-ascent/table/index-sharing#column-projection-writes-set!
   (@mutator gerbil-ascent/table/index-sharing#column-projection::t writes #t))
  (declare-type
   gerbil-ascent/table/index-sharing#column-projection-frame-set!
   (@mutator gerbil-ascent/table/index-sharing#column-projection::t frame #t))
  (declare-type
   gerbil-ascent/table/index-sharing#&column-projection-columns
   (@accessor
    gerbil-ascent/table/index-sharing#column-projection::t
    columns
    #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&column-projection-writes
   (@accessor
    gerbil-ascent/table/index-sharing#column-projection::t
    writes
    #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&column-projection-frame
   (@accessor gerbil-ascent/table/index-sharing#column-projection::t frame #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&column-projection-columns-set!
   (@mutator
    gerbil-ascent/table/index-sharing#column-projection::t
    columns
    #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&column-projection-writes-set!
   (@mutator gerbil-ascent/table/index-sharing#column-projection::t writes #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&column-projection-frame-set!
   (@mutator gerbil-ascent/table/index-sharing#column-projection::t frame #f))
  (declare-class
   gerbil-ascent/table/index-sharing#key-projection::t
   (@class gerbil-ascent/table/index-sharing#key-projection::t
           ()
           (object::t t::t)
           (physical writes frame)
           (physical writes frame)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/table/index-sharing#key-projection::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/index-sharing#key-projection::t)
    'class::t))
  (declare-type
   gerbil-ascent/table/index-sharing#key-projection?
   (@predicate gerbil-ascent/table/index-sharing#key-projection::t))
  (declare-type
   gerbil-ascent/table/index-sharing#make-key-projection
   (@constructor gerbil-ascent/table/index-sharing#key-projection::t))
  (declare-type
   gerbil-ascent/table/index-sharing#key-projection-physical
   (@accessor gerbil-ascent/table/index-sharing#key-projection::t physical #t))
  (declare-type
   gerbil-ascent/table/index-sharing#key-projection-writes
   (@accessor gerbil-ascent/table/index-sharing#key-projection::t writes #t))
  (declare-type
   gerbil-ascent/table/index-sharing#key-projection-frame
   (@accessor gerbil-ascent/table/index-sharing#key-projection::t frame #t))
  (declare-type
   gerbil-ascent/table/index-sharing#key-projection-physical-set!
   (@mutator gerbil-ascent/table/index-sharing#key-projection::t physical #t))
  (declare-type
   gerbil-ascent/table/index-sharing#key-projection-writes-set!
   (@mutator gerbil-ascent/table/index-sharing#key-projection::t writes #t))
  (declare-type
   gerbil-ascent/table/index-sharing#key-projection-frame-set!
   (@mutator gerbil-ascent/table/index-sharing#key-projection::t frame #t))
  (declare-type
   gerbil-ascent/table/index-sharing#&key-projection-physical
   (@accessor gerbil-ascent/table/index-sharing#key-projection::t physical #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&key-projection-writes
   (@accessor gerbil-ascent/table/index-sharing#key-projection::t writes #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&key-projection-frame
   (@accessor gerbil-ascent/table/index-sharing#key-projection::t frame #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&key-projection-physical-set!
   (@mutator gerbil-ascent/table/index-sharing#key-projection::t physical #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&key-projection-writes-set!
   (@mutator gerbil-ascent/table/index-sharing#key-projection::t writes #f))
  (declare-type
   gerbil-ascent/table/index-sharing#&key-projection-frame-set!
   (@mutator gerbil-ascent/table/index-sharing#key-projection::t frame #f))
  (declare-type
   gerbil-ascent/table/index-sharing#key-sequence=?
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-type
   gerbil-ascent/table/index-sharing#gerbil-ascent-shared-index-build
   (@lambda 2
            #f
            signature:
            (return:
             gerbil-ascent/table/index-sharing#shared-index::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-type
   gerbil-ascent/table/index-sharing#gerbil-ascent-shared-index-extend!
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-type
   gerbil-ascent/table/index-sharing#column-projection-for!
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-type
   gerbil-ascent/table/index-sharing#same-columns?
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-type
   gerbil-ascent/table/index-sharing#column-writes
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-type
   gerbil-ascent/table/index-sharing#fill-column-frame!
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-type
   gerbil-ascent/table/index-sharing#compile-key-projection
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-type
   gerbil-ascent/table/index-sharing#same-physical-prefix?
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-type
   gerbil-ascent/table/index-sharing#column-sequence=?
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-type
   gerbil-ascent/table/index-sharing#project-lookup-key
   (@lambda 4
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-type
   gerbil-ascent/table/index-sharing#adapt-lookup-key
   (@lambda 4
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing)))
  (declare-type
   gerbil-ascent/table/index-sharing#gerbil-ascent-shared-index-rows
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/index-sharing))))
