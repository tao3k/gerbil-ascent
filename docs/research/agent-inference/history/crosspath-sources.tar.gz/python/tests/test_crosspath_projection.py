# SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
"""The v2 solver must not see raw native eligibility pruning or failed Fact IDs."""
import json
from ascent_test_support import crosspath_search_v2 as m


class Native:
    def call(self,**kw):
        if kw['op']=='inspect':
            return {'valid':True,'cost':0,'risk':0,'value':0,'depth':0,'nextOptionIds':[0],'ineligibleOrWrongStage':[4]},0
        if kw['op']=='evaluate':
            return {'valid':True,'cost':30,'risk':10,'value':100,'depth':7,'ineligibleOrWrongStage':[]},0
        if kw['op']=='grade':
            return {'valid':True,'cost':30,'risk':10,'value':100,'depth':7,'gap':0,'optimal':True,'oracle':{'optimum':100}},0
        raise AssertionError(kw)


def test_projection_removes_eligibility_oracle(monkeypatch,tmp_path):
    monkeypatch.setattr(m,'BASE',tmp_path)
    monkeypatch.setattr(m,'provider_key',lambda:'fixture-unused')
    turns=[]
    selection=[0,5,10,15,20,25,30]
    def provider(request,key,destination):
        turns.append(request)
        if len(turns)==1:
            calls=[{'type':'function_call','name':'inspect','call_id':'p','arguments':json.dumps({'selection':[]})},
                   {'type':'function_call','name':'evaluate','call_id':'e','arguments':json.dumps({'selection':selection})}]
        else:
            outputs=[json.loads(x['output']) for x in request['input'] if x.get('type')=='function_call_output']
            assert outputs[0]=={'cost':0,'risk':0,'value':0,'depth':0,'nextStageOptionIds':[0,1,2,3,4]}
            assert 'ineligibleOrWrongStage' not in outputs[1]
            calls=[{'type':'function_call','name':'submit','call_id':'s','arguments':json.dumps({'selection':selection})}]
        return '',{'terminal':{'status':'completed','output':calls,'usage':{'input_tokens':10,'output_tokens':5,'total_tokens':15}},'error':None,'providerSeconds':0}
    monkeypatch.setattr(m,'provider',provider)
    plan={'calls':3,'totalTokenBudget':65536,'perCallOutputCap':8192,'finalOutputCap':2048,'toolActions':32,'model':'fixture',
          'reasoningEffort':'low','finalReasoningEffort':'none','instructions':m.INSTRUCTIONS,'tools':m.TOOLS}
    row=m.run_phase(plan,m.task(1,'fixture'),0,'baseline',Native(),tmp_path/'phase')
    assert row['submitted'] and row['observedTotalTokens']==30 and row['failure'] is None
