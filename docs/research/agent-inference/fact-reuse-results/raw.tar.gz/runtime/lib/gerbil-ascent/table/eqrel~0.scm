(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/eqrel::timestamp 1791687545)
  (begin
    (define gerbil-ascent/table/eqrel#eqrel-component::t
      (let ((__tmp6294 (list)) (__tmp6293 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/eqrel#eqrel-component::t
         'eqrel-component
         __tmp6294
         '(members size)
         __tmp6293
         '#f)))
    (define gerbil-ascent/table/eqrel#eqrel-component?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/eqrel#eqrel-component::t)))
    (define gerbil-ascent/table/eqrel#make-eqrel-component
      (lambda _%$args6287%_
        (apply make-instance
               gerbil-ascent/table/eqrel#eqrel-component::t
               _%$args6287%_)))
    (define gerbil-ascent/table/eqrel#eqrel-component-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#eqrel-component::t
         'members)))
    (define gerbil-ascent/table/eqrel#eqrel-component-size
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#eqrel-component::t
         'size)))
    (define gerbil-ascent/table/eqrel#eqrel-component-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#eqrel-component::t
         'members)))
    (define gerbil-ascent/table/eqrel#eqrel-component-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#eqrel-component::t
         'size)))
    (define gerbil-ascent/table/eqrel#&eqrel-component-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#eqrel-component::t
         'members)))
    (define gerbil-ascent/table/eqrel#&eqrel-component-size
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#eqrel-component::t
         'size)))
    (define gerbil-ascent/table/eqrel#&eqrel-component-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#eqrel-component::t
         'members)))
    (define gerbil-ascent/table/eqrel#&eqrel-component-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#eqrel-component::t
         'size)))
    (define gerbil-ascent/table/eqrel#eqrel-cut::t
      (let ((__tmp6296 (list)) (__tmp6295 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/eqrel#eqrel-cut::t
         'eqrel-cut
         __tmp6296
         '(count view)
         __tmp6295
         '#f)))
    (define gerbil-ascent/table/eqrel#eqrel-cut?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/eqrel#eqrel-cut::t)))
    (define gerbil-ascent/table/eqrel#make-eqrel-cut
      (lambda _%$args6284%_
        (apply make-instance
               gerbil-ascent/table/eqrel#eqrel-cut::t
               _%$args6284%_)))
    (define gerbil-ascent/table/eqrel#eqrel-cut-count
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#eqrel-cut::t
         'count)))
    (define gerbil-ascent/table/eqrel#eqrel-cut-view
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#eqrel-cut::t
         'view)))
    (define gerbil-ascent/table/eqrel#eqrel-cut-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#eqrel-cut::t
         'count)))
    (define gerbil-ascent/table/eqrel#eqrel-cut-view-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#eqrel-cut::t
         'view)))
    (define gerbil-ascent/table/eqrel#&eqrel-cut-count
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#eqrel-cut::t
         'count)))
    (define gerbil-ascent/table/eqrel#&eqrel-cut-view
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#eqrel-cut::t
         'view)))
    (define gerbil-ascent/table/eqrel#&eqrel-cut-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#eqrel-cut::t
         'count)))
    (define gerbil-ascent/table/eqrel#&eqrel-cut-view-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#eqrel-cut::t
         'view)))
    (define gerbil-ascent/table/eqrel#eqrel-state::t
      (let ((__tmp6298 (list)) (__tmp6297 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/eqrel#eqrel-state::t
         'eqrel-state
         __tmp6298
         '(components count published origin)
         __tmp6297
         '#f)))
    (define gerbil-ascent/table/eqrel#eqrel-state?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/eqrel#eqrel-state::t)))
    (define gerbil-ascent/table/eqrel#make-eqrel-state
      (lambda _%$args6281%_
        (apply make-instance
               gerbil-ascent/table/eqrel#eqrel-state::t
               _%$args6281%_)))
    (define gerbil-ascent/table/eqrel#eqrel-state-components
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#eqrel-state::t
         'components)))
    (define gerbil-ascent/table/eqrel#eqrel-state-count
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#eqrel-state::t
         'count)))
    (define gerbil-ascent/table/eqrel#eqrel-state-published
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#eqrel-state::t
         'published)))
    (define gerbil-ascent/table/eqrel#eqrel-state-origin
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#eqrel-state::t
         'origin)))
    (define gerbil-ascent/table/eqrel#eqrel-state-components-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#eqrel-state::t
         'components)))
    (define gerbil-ascent/table/eqrel#eqrel-state-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#eqrel-state::t
         'count)))
    (define gerbil-ascent/table/eqrel#eqrel-state-published-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#eqrel-state::t
         'published)))
    (define gerbil-ascent/table/eqrel#eqrel-state-origin-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#eqrel-state::t
         'origin)))
    (define gerbil-ascent/table/eqrel#&eqrel-state-components
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#eqrel-state::t
         'components)))
    (define gerbil-ascent/table/eqrel#&eqrel-state-count
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#eqrel-state::t
         'count)))
    (define gerbil-ascent/table/eqrel#&eqrel-state-published
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#eqrel-state::t
         'published)))
    (define gerbil-ascent/table/eqrel#&eqrel-state-origin
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#eqrel-state::t
         'origin)))
    (define gerbil-ascent/table/eqrel#&eqrel-state-components-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#eqrel-state::t
         'components)))
    (define gerbil-ascent/table/eqrel#&eqrel-state-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#eqrel-state::t
         'count)))
    (define gerbil-ascent/table/eqrel#&eqrel-state-published-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#eqrel-state::t
         'published)))
    (define gerbil-ascent/table/eqrel#&eqrel-state-origin-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#eqrel-state::t
         'origin)))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-state?
      gerbil-ascent/table/eqrel#eqrel-state?)
    (define gerbil-ascent/table/eqrel#empty-cut
      (lambda ()
        (let ((__tmp6299
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/core/relation-view#gerbil-ascent-explicit-view
                  '()
                  '0))))
          (declare (not safe))
          (##structure gerbil-ascent/table/eqrel#eqrel-cut::t '0 __tmp6299))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-state
      (lambda ()
        (let* ((_%empty6278%_ (gerbil-ascent/table/eqrel#empty-cut))
               (__tmp6300
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value))))
          (declare (not safe))
          (##structure
           gerbil-ascent/table/eqrel#eqrel-state::t
           __tmp6300
           '0
           _%empty6278%_
           _%empty6278%_))))
    (define gerbil-ascent/table/eqrel#member-key
      (lambda (_%width6273%_ _%group6274%_ _%node6275%_)
        (list _%width6273%_ _%group6274%_ _%node6275%_)))
    (define gerbil-ascent/table/eqrel#coordinate-key::t
      (let ((__tmp6302 (list))
            (__tmp6301
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/eqrel#coordinate-key::t
         'coordinate-key
         __tmp6302
         '(bound? value coherent?)
         __tmp6301
         '#f)))
    (define gerbil-ascent/table/eqrel#coordinate-key?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/eqrel#coordinate-key::t)))
    (define gerbil-ascent/table/eqrel#make-coordinate-key
      (lambda _%$args6270%_
        (apply make-instance
               gerbil-ascent/table/eqrel#coordinate-key::t
               _%$args6270%_)))
    (define gerbil-ascent/table/eqrel#coordinate-key-bound?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#coordinate-key::t
         'bound?)))
    (define gerbil-ascent/table/eqrel#coordinate-key-value
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#coordinate-key::t
         'value)))
    (define gerbil-ascent/table/eqrel#coordinate-key-coherent?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#coordinate-key::t
         'coherent?)))
    (define gerbil-ascent/table/eqrel#coordinate-key-bound?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#coordinate-key::t
         'bound?)))
    (define gerbil-ascent/table/eqrel#coordinate-key-value-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#coordinate-key::t
         'value)))
    (define gerbil-ascent/table/eqrel#coordinate-key-coherent?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#coordinate-key::t
         'coherent?)))
    (define gerbil-ascent/table/eqrel#&coordinate-key-bound?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#coordinate-key::t
         'bound?)))
    (define gerbil-ascent/table/eqrel#&coordinate-key-value
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#coordinate-key::t
         'value)))
    (define gerbil-ascent/table/eqrel#&coordinate-key-coherent?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#coordinate-key::t
         'coherent?)))
    (define gerbil-ascent/table/eqrel#&coordinate-key-bound?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#coordinate-key::t
         'bound?)))
    (define gerbil-ascent/table/eqrel#&coordinate-key-value-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#coordinate-key::t
         'value)))
    (define gerbil-ascent/table/eqrel#&coordinate-key-coherent?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#coordinate-key::t
         'coherent?)))
    (define gerbil-ascent/table/eqrel#compile-coordinate-key
      (lambda (_%coordinate6259%_ _%columns6260%_ _%key6261%_)
        (let ((_%bound?6263%_ '#f) (_%value6264%_ '#f) (_%coherent?6265%_ '#t))
          (for-each
           (lambda (_%column6267%_ _%selected6268%_)
             (if (= _%column6267%_ _%coordinate6259%_)
                 (if _%bound?6263%_
                     (set! _%coherent?6265%_
                           (if _%coherent?6265%_
                               (equal? _%value6264%_ _%selected6268%_)
                               '#f))
                     (begin
                       (set! _%bound?6263%_ '#t)
                       (set! _%value6264%_ _%selected6268%_)))
                 '#!void))
           _%columns6260%_
           _%key6261%_)
          (let ()
            (declare (not safe))
            (##structure
             gerbil-ascent/table/eqrel#coordinate-key::t
             _%bound?6263%_
             _%value6264%_
             _%coherent?6265%_)))))
    (define gerbil-ascent/table/eqrel#coordinate-accepts?
      (lambda (_%constraint6246%_ _%value6247%_)
        (let ((_%constraint6249%_ _%constraint6246%_))
          (if (let ()
                (declare (not safe))
                (##unchecked-structure-ref _%constraint6249%_ '3 '#f '#f))
              (let ((_%$e6256%_
                     (not (let ()
                            (declare (not safe))
                            (##unchecked-structure-ref
                             _%constraint6249%_
                             '1
                             '#f
                             '#f)))))
                (if _%$e6256%_
                    _%$e6256%_
                    (equal? (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%constraint6249%_
                               '2
                               '#f
                               '#f))
                            _%value6247%_)))
              '#f))))
    (define gerbil-ascent/table/eqrel#coordinate-members
      (lambda (_%constraint6231%_ _%members6232%_)
        (let ((_%constraint6234%_ _%constraint6231%_))
          (if (let ()
                (declare (not safe))
                (##unchecked-structure-ref _%constraint6234%_ '3 '#f '#f))
              (if (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%constraint6234%_ '1 '#f '#f))
                  (let ((_%found6244%_
                         (member (let ()
                                   (declare (not safe))
                                   (##unchecked-structure-ref
                                    _%constraint6234%_
                                    '2
                                    '#f
                                    '#f))
                                 _%members6232%_)))
                    (if _%found6244%_ (list (car _%found6244%_)) '()))
                  _%members6232%_)
              '()))))
    (define gerbil-ascent/table/eqrel#visit-selected-members!
      (lambda (_%left-key6199%_
               _%right-key6200%_
               _%lefts6201%_
               _%rights6202%_
               _%emit6203%_)
        (let* ((_%forward6205%_
                (gerbil-ascent/table/eqrel#coordinate-members
                 _%right-key6200%_
                 _%rights6202%_))
               (_%backward6207%_
                (gerbil-ascent/table/eqrel#coordinate-members
                 _%left-key6199%_
                 _%rights6202%_))
               (_%both6217%_
                (if (or (eq? _%forward6205%_ _%rights6202%_)
                        (eq? _%backward6207%_ _%rights6202%_))
                    _%rights6202%_
                    (filter (lambda (_%b6212%_)
                              (let ((_%$e6214%_
                                     (gerbil-ascent/table/eqrel#coordinate-accepts?
                                      _%right-key6200%_
                                      _%b6212%_)))
                                (if _%$e6214%_
                                    _%$e6214%_
                                    (gerbil-ascent/table/eqrel#coordinate-accepts?
                                     _%left-key6199%_
                                     _%b6212%_))))
                            _%rights6202%_))))
          (for-each
           (lambda (_%a6220%_)
             (let ((_%forward?6222%_
                    (gerbil-ascent/table/eqrel#coordinate-accepts?
                     _%left-key6199%_
                     _%a6220%_))
                   (_%backward?6223%_
                    (gerbil-ascent/table/eqrel#coordinate-accepts?
                     _%right-key6200%_
                     _%a6220%_)))
               (for-each
                (lambda (_%b6225%_)
                  (if (and _%forward?6222%_
                           (gerbil-ascent/table/eqrel#coordinate-accepts?
                            _%right-key6200%_
                            _%b6225%_))
                      (_%emit6203%_ _%a6220%_ _%b6225%_)
                      '#!void)
                  (if (and _%backward?6223%_
                           (gerbil-ascent/table/eqrel#coordinate-accepts?
                            _%left-key6199%_
                            _%b6225%_))
                      (_%emit6203%_ _%b6225%_ _%a6220%_)
                      '#!void))
                (if (and _%forward?6222%_ _%backward?6223%_)
                    _%both6217%_
                    (if _%forward?6222%_
                        _%forward6205%_
                        (if _%backward?6223%_ _%backward6207%_ '()))))))
           _%lefts6201%_))))
    (define gerbil-ascent/table/eqrel#injection-view
      (lambda (_%prefix6148%_
               _%diagonals6149%_
               _%lefts6150%_
               _%rights6151%_
               _%count6152%_)
        (letrec ((_%emit6154%_
                  (lambda (_%consume6195%_ _%a6196%_ _%b6197%_)
                    (_%consume6195%_
                     (let ((__tmp6303 (list _%a6196%_ _%b6197%_)))
                       (declare (not safe))
                       (##append _%prefix6148%_ __tmp6303)))))
                 (_%visit6155%_
                  (lambda (_%columns6163%_ _%key6164%_ _%consume6165%_)
                    (if (and (list? _%columns6163%_)
                             (list? _%key6164%_)
                             (= (let ()
                                  (declare (not safe))
                                  (##length _%columns6163%_))
                                (let ()
                                  (declare (not safe))
                                  (##length _%key6164%_)))
                             (let ((__tmp6304
                                    (lambda (_%n6167%_)
                                      (and (exact-integer? _%n6167%_)
                                           (>= _%n6167%_ '0)
                                           (< _%n6167%_
                                              (+ '2
                                                 (length _%prefix6148%_)))))))
                               (declare (not safe))
                               (andmap__0 __tmp6304 _%columns6163%_)))
                        '#!void
                        (let ()
                          (declare (not safe))
                          (error '"invalid ASCENT eqrel view key")))
                    (if (null? _%columns6163%_)
                        (begin
                          (for-each
                           (lambda (_%node6169%_)
                             (_%emit6154%_
                              _%consume6165%_
                              _%node6169%_
                              _%node6169%_))
                           _%diagonals6149%_)
                          (for-each
                           (lambda (_%a6171%_)
                             (for-each
                              (lambda (_%b6173%_)
                                (_%emit6154%_
                                 _%consume6165%_
                                 _%a6171%_
                                 _%b6173%_)
                                (_%emit6154%_
                                 _%consume6165%_
                                 _%b6173%_
                                 _%a6171%_))
                              _%rights6151%_))
                           _%lefts6150%_))
                        (let ((_%offset6175%_ (length _%prefix6148%_)))
                          (if (let ((__tmp6305
                                     (lambda (_%column6177%_ _%value6178%_)
                                       (or (>= _%column6177%_ _%offset6175%_)
                                           (equal? (list-ref
                                                    _%prefix6148%_
                                                    _%column6177%_)
                                                   _%value6178%_)))))
                                (declare (not safe))
                                (andmap__1
                                 __tmp6305
                                 _%columns6163%_
                                 _%key6164%_))
                              (let ((_%left-key6183%_
                                     (gerbil-ascent/table/eqrel#compile-coordinate-key
                                      _%offset6175%_
                                      _%columns6163%_
                                      _%key6164%_))
                                    (_%right-key6184%_
                                     (gerbil-ascent/table/eqrel#compile-coordinate-key
                                      (+ _%offset6175%_ '1)
                                      _%columns6163%_
                                      _%key6164%_)))
                                (for-each
                                 (lambda (_%node6186%_)
                                   (if (and (gerbil-ascent/table/eqrel#coordinate-accepts?
                                             _%left-key6183%_
                                             _%node6186%_)
                                            (gerbil-ascent/table/eqrel#coordinate-accepts?
                                             _%right-key6184%_
                                             _%node6186%_))
                                       (_%emit6154%_
                                        _%consume6165%_
                                        _%node6186%_
                                        _%node6186%_)
                                       '#!void))
                                 _%diagonals6149%_)
                                (gerbil-ascent/table/eqrel#visit-selected-members!
                                 _%left-key6183%_
                                 _%right-key6184%_
                                 _%lefts6150%_
                                 _%rights6151%_
                                 (lambda (_%$%g61876190%_ _%$%g61886192%_)
                                   (_%emit6154%_
                                    _%consume6165%_
                                    _%$%g61876190%_
                                    _%$%g61886192%_))))
                              '#!void))))))
          (let ((__tmp6308
                 (+ (length _%diagonals6149%_)
                    (length _%lefts6150%_)
                    (length _%rights6151%_)))
                (__tmp6306
                 (lambda (_%row6157%_)
                   (let ((_%found?6159%_ '#f))
                     (_%visit6155%_
                      (let ((__tmp6307 (length _%row6157%_)))
                        (declare (not safe))
                        (##iota __tmp6307))
                      _%row6157%_
                      (lambda (_%_6161%_) (set! _%found?6159%_ '#t)))
                     _%found?6159%_))))
            (declare (not safe))
            (##structure
             gerbil-ascent/core/relation-view#relation-view::t
             '#f
             '#f
             '0
             'delta
             _%count6152%_
             __tmp6308
             _%visit6155%_
             __tmp6306
             '#f
             '#f)))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-insert!
      (lambda (_%state5951%_ _%row5952%_ _%budget5953%_)
        (let* ((_%components5955%_
                (##structure-ref
                 _%state5951%_
                 '1
                 gerbil-ascent/table/eqrel#eqrel-state::t
                 '#f))
               (_%width5957%_ (length _%row5952%_))
               (_%_5959%_
                (if (let () (declare (not safe)) (##memq _%width5957%_ '(2 3)))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"ASCENT eqrel requires two or three columns"
                             _%row5952%_))))
               (_%group5961%_ (if (= _%width5957%_ '3) (car _%row5952%_) '#f))
               (_%prefix5963%_
                (if (= _%width5957%_ '3) (list _%group5961%_) '()))
               (_%pair5965%_
                (if (= _%width5957%_ '3) (cdr _%row5952%_) _%row5952%_))
               (_%left5967%_ (car _%pair5965%_))
               (_%right5969%_ (cadr _%pair5965%_))
               (_%same-node?5971%_ (equal? _%left5967%_ _%right5969%_))
               (_%left-key5973%_
                (list _%width5957%_ _%group5961%_ _%left5967%_))
               (_%right-key5975%_
                (if _%same-node?5971%_
                    _%left-key5973%_
                    (list _%width5957%_ _%group5961%_ _%right5969%_)))
               (_%a6009%_
                (let* ((_%h5977%_ _%components5955%_)
                       (_%key5980%_ _%left-key5973%_)
                       (_%h5984%_
                        (let ()
                          (declare (not safe))
                          (cast HashTable::interface _%h5977%_)))
                       (_%h5986%_ _%h5984%_))
                  (declare (not safe))
                  (__hash-get _%h5986%_ _%key5980%_)))
               (_%b6032%_
                (if _%same-node?5971%_
                    _%a6009%_
                    (let* ((_%h6011%_ _%components5955%_)
                           (_%key6014%_ _%right-key5975%_)
                           (_%h6018%_
                            (let ()
                              (declare (not safe))
                              (cast HashTable::interface _%h6011%_)))
                           (_%h6020%_ _%h6018%_))
                      (declare (not safe))
                      (__hash-get _%h6020%_ _%key6014%_))))
               (_%left-size6034%_
                (if _%a6009%_
                    (##structure-ref
                     _%a6009%_
                     '2
                     gerbil-ascent/table/eqrel#eqrel-component::t
                     '#f)
                    '1))
               (_%right-size6036%_
                (if _%b6032%_
                    (##structure-ref
                     _%b6032%_
                     '2
                     gerbil-ascent/table/eqrel#eqrel-component::t
                     '#f)
                    '1))
               (_%merge?6041%_
                (not (let ((_%$e6038%_ _%same-node?5971%_))
                       (if _%$e6038%_
                           _%$e6038%_
                           (if _%a6009%_
                               (if _%b6032%_ (eq? _%a6009%_ _%b6032%_) '#f)
                               '#f)))))
               (_%diagonals6046%_
                (let ((__tmp6310 (if _%a6009%_ '() (list _%left5967%_)))
                      (__tmp6309
                       (if (or _%b6032%_ _%same-node?5971%_)
                           '()
                           (list _%right5969%_))))
                  (declare (not safe))
                  (##append __tmp6310 __tmp6309)))
               (_%needed6048%_
                (+ (let () (declare (not safe)) (##length _%diagonals6046%_))
                   (if _%merge?6041%_
                       (* '2 _%left-size6034%_ _%right-size6036%_)
                       '0))))
          (if (> _%needed6048%_ _%budget5953%_)
              (let ()
                (declare (not safe))
                (error '"ASCENT eqrel output fact budget exceeded"))
              '#!void)
          (if _%a6009%_
              '#!void
              (begin
                (set! _%a6009%_
                      (let ((__tmp6311 (list _%left5967%_)))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/table/eqrel#eqrel-component::t
                         __tmp6311
                         '1)))
                (let* ((_%h6051%_ _%components5955%_)
                       (_%key6054%_ _%left-key5973%_)
                       (_%value6057%_ _%a6009%_)
                       (_%h6061%_
                        (let ()
                          (declare (not safe))
                          (cast HashTable::interface _%h6051%_)))
                       (_%h6063%_ _%h6061%_))
                  (declare (not safe))
                  (__hash-put! _%h6063%_ _%key6054%_ _%value6057%_))))
          (if _%b6032%_
              '#!void
              (begin
                (set! _%b6032%_
                      (if _%same-node?5971%_
                          _%a6009%_
                          (let ((__tmp6312 (list _%right5969%_)))
                            (declare (not safe))
                            (##structure
                             gerbil-ascent/table/eqrel#eqrel-component::t
                             __tmp6312
                             '1))))
                (let* ((_%h6082%_ _%components5955%_)
                       (_%key6085%_ _%right-key5975%_)
                       (_%value6088%_ _%b6032%_)
                       (_%h6092%_
                        (let ()
                          (declare (not safe))
                          (cast HashTable::interface _%h6082%_)))
                       (_%h6094%_ _%h6092%_))
                  (declare (not safe))
                  (__hash-put! _%h6094%_ _%key6085%_ _%value6088%_))))
          (let ((_%lefts6106%_
                 (if _%merge?6041%_
                     (##structure-ref
                      _%a6009%_
                      '1
                      gerbil-ascent/table/eqrel#eqrel-component::t
                      '#f)
                     '()))
                (_%rights6107%_
                 (if _%merge?6041%_
                     (##structure-ref
                      _%b6032%_
                      '1
                      gerbil-ascent/table/eqrel#eqrel-component::t
                      '#f)
                     '())))
            (if _%merge?6041%_
                (let* ((_%large6109%_
                        (if (>= _%left-size6034%_ _%right-size6036%_)
                            _%a6009%_
                            _%b6032%_))
                       (_%small6111%_
                        (if (eq? _%large6109%_ _%a6009%_) _%b6032%_ _%a6009%_))
                       (_%members6113%_
                        (##structure-ref
                         _%small6111%_
                         '1
                         gerbil-ascent/table/eqrel#eqrel-component::t
                         '#f)))
                  (for-each
                   (lambda (_%node6116%_)
                     (let* ((_%h6118%_ _%components5955%_)
                            (_%key6121%_
                             (list _%width5957%_ _%group5961%_ _%node6116%_))
                            (_%value6124%_ _%large6109%_)
                            (_%h6128%_
                             (let ()
                               (declare (not safe))
                               (cast HashTable::interface _%h6118%_)))
                            (_%h6130%_ _%h6128%_))
                       (declare (not safe))
                       (__hash-put! _%h6130%_ _%key6121%_ _%value6124%_)))
                   _%members6113%_)
                  (##structure-set!
                   _%large6109%_
                   (append _%members6113%_
                           (##structure-ref
                            _%large6109%_
                            '1
                            gerbil-ascent/table/eqrel#eqrel-component::t
                            '#f))
                   '1
                   gerbil-ascent/table/eqrel#eqrel-component::t
                   '#f)
                  (##structure-set!
                   _%large6109%_
                   (+ _%left-size6034%_ _%right-size6036%_)
                   '2
                   gerbil-ascent/table/eqrel#eqrel-component::t
                   '#f))
                '#!void)
            (##structure-set!
             _%state5951%_
             (+ (##structure-ref
                 _%state5951%_
                 '2
                 gerbil-ascent/table/eqrel#eqrel-state::t
                 '#f)
                _%needed6048%_)
             '2
             gerbil-ascent/table/eqrel#eqrel-state::t
             '#f)
            (gerbil-ascent/table/eqrel#injection-view
             _%prefix5963%_
             _%diagonals6046%_
             _%lefts6106%_
             _%rights6107%_
             _%needed6048%_)))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-extension
      (lambda (_%state5945%_
               _%_all5946%_
               _%_pending5947%_
               _%row5948%_
               _%budget5949%_)
        (let ((__tmp6313
               (gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-insert!
                _%state5945%_
                _%row5948%_
                _%budget5949%_)))
          (declare (not safe))
          (gerbil-ascent/core/relation-view#gerbil-ascent-view-rows
           __tmp6313))))
    (define gerbil-ascent/table/eqrel#capture
      (lambda (_%state5840%_ _%indexed?5841%_)
        (let ((_%seen5860%_ (let () (declare (not safe)) (make-hash-table-eq)))
              (_%blocks5861%_ '())
              (_%nodes5862%_
               (let* ((_%h5843%_
                       (##structure-ref
                        _%state5840%_
                        '1
                        gerbil-ascent/table/eqrel#eqrel-state::t
                        '#f))
                      (_%h5847%_
                       (let ()
                         (declare (not safe))
                         (cast HashTable::interface _%h5843%_)))
                      (_%h5849%_ _%h5847%_))
                 (declare (not safe))
                 (__hash-length _%h5849%_))))
          (let* ((_%proc5915%_
                  (lambda (_%key5864%_ _%component5865%_)
                    (if (let* ((_%h5867%_ _%seen5860%_)
                               (_%key5870%_ _%component5865%_)
                               (_%h5874%_ _%h5867%_)
                               (_%h5876%_ _%h5874%_))
                          (declare (not safe))
                          (__hash-get _%h5876%_ _%key5870%_))
                        '#!void
                        (begin
                          (let* ((_%h5889%_ _%seen5860%_)
                                 (_%key5892%_ _%component5865%_)
                                 (_%value5895%_ '#t)
                                 (_%h5899%_ _%h5889%_)
                                 (_%h5901%_ _%h5899%_))
                            (declare (not safe))
                            (__hash-put! _%h5901%_ _%key5892%_ _%value5895%_))
                          (let ((_%spine5913%_
                                 (##structure-ref
                                  _%component5865%_
                                  '1
                                  gerbil-ascent/table/eqrel#eqrel-component::t
                                  '#f)))
                            (set! _%blocks5861%_
                                  (cons (let ((__tmp6314
                                               (if (= (car _%key5864%_) '3)
                                                   (list (cadr _%key5864%_))
                                                   '())))
                                          (declare (not safe))
                                          (##structure
                                           gerbil-ascent/core/relation-view#rectangle::t
                                           __tmp6314
                                           _%spine5913%_
                                           _%spine5913%_))
                                        _%blocks5861%_)))))))
                 (_%h5918%_
                  (##structure-ref
                   _%state5840%_
                   '1
                   gerbil-ascent/table/eqrel#eqrel-state::t
                   '#f))
                 (_%proc5923%_ _%proc5915%_)
                 (_%h5933%_
                  (let ()
                    (declare (not safe))
                    (cast HashTable::interface _%h5918%_)))
                 (_%h5935%_ _%h5933%_))
            (declare (not safe))
            (__hash-for-each _%proc5923%_ _%h5935%_))
          (let ((__tmp6318
                 (##structure-ref
                  _%state5840%_
                  '2
                  gerbil-ascent/table/eqrel#eqrel-state::t
                  '#f))
                (__tmp6315
                 (let ((__tmp6317
                        (##structure-ref
                         _%state5840%_
                         '2
                         gerbil-ascent/table/eqrel#eqrel-state::t
                         '#f))
                       (__tmp6316 (* '2 _%nodes5862%_)))
                   (declare (not safe))
                   (gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__%
                    _%blocks5861%_
                    __tmp6317
                    __tmp6316
                    _%indexed?5841%_))))
            (declare (not safe))
            (##structure
             gerbil-ascent/table/eqrel#eqrel-cut::t
             __tmp6318
             __tmp6315)))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze__%
      (lambda (_%state5825%_ _%indexed?5826%_)
        (let ((_%cut5828%_
               (gerbil-ascent/table/eqrel#capture
                _%state5825%_
                _%indexed?5826%_)))
          (##structure-set!
           _%state5825%_
           _%cut5828%_
           '3
           gerbil-ascent/table/eqrel#eqrel-state::t
           '#f)
          (let ()
            (declare (not safe))
            (##unchecked-structure-ref _%cut5828%_ '2 '#f '#f)))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze__0
      (lambda (_%state5833%_)
        (let ((_%indexed?5835%_ '#t))
          (gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze__%
           _%state5833%_
           _%indexed?5835%_))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze
      (lambda _g6319_
        (let ((_g6320_ (let () (declare (not safe)) (##length _g6319_))))
          (cond ((let () (declare (not safe)) (##fx= _g6320_ 1))
                 (apply gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze__0
                        _g6319_))
                ((let () (declare (not safe)) (##fx= _g6320_ 2))
                 (apply gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze__%
                        _g6319_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze
                  _g6319_))))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!__%
      (lambda (_%state5797%_ _%count5798%_ _%indexed?5799%_)
        (let* ((_%published5801%_
                (##structure-ref
                 _%state5797%_
                 '3
                 gerbil-ascent/table/eqrel#eqrel-state::t
                 '#f))
               (_%origin5803%_
                (if (= _%count5798%_
                       (- (##structure-ref
                           _%state5797%_
                           '2
                           gerbil-ascent/table/eqrel#eqrel-state::t
                           '#f)
                          (##structure-ref
                           _%published5801%_
                           '1
                           gerbil-ascent/table/eqrel#eqrel-cut::t
                           '#f)))
                    _%published5801%_
                    (##structure-ref
                     _%state5797%_
                     '4
                     gerbil-ascent/table/eqrel#eqrel-state::t
                     '#f)))
               (_%next5805%_
                (gerbil-ascent/table/eqrel#capture
                 _%state5797%_
                 _%indexed?5799%_))
               (_%total5807%_
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-ref _%next5805%_ '2 '#f '#f))))
          (if (= _%count5798%_
                 (- (let ()
                      (declare (not safe))
                      (##unchecked-structure-ref _%next5805%_ '1 '#f '#f))
                    (##structure-ref
                     _%origin5803%_
                     '1
                     gerbil-ascent/table/eqrel#eqrel-cut::t
                     '#f)))
              '#!void
              (let ()
                (declare (not safe))
                (error '"ASCENT eqrel delta origin mismatch")))
          (let ((_%delta5810%_
                 (if (= (##structure-ref
                         _%origin5803%_
                         '1
                         gerbil-ascent/table/eqrel#eqrel-cut::t
                         '#f)
                        '0)
                     _%total5807%_
                     (let ((__tmp6321
                            (##structure-ref
                             _%origin5803%_
                             '2
                             gerbil-ascent/table/eqrel#eqrel-cut::t
                             '#f)))
                       (declare (not safe))
                       (gerbil-ascent/core/relation-view#gerbil-ascent-view-difference
                        _%total5807%_
                        __tmp6321
                        _%count5798%_)))))
            (##structure-set!
             _%state5797%_
             _%origin5803%_
             '4
             gerbil-ascent/table/eqrel#eqrel-state::t
             '#f)
            (##structure-set!
             _%state5797%_
             _%next5805%_
             '3
             gerbil-ascent/table/eqrel#eqrel-state::t
             '#f)
            (values _%total5807%_ _%delta5810%_)))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!__0
      (lambda (_%state5815%_ _%count5816%_)
        (let ((_%indexed?5818%_ '#t))
          (gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!__%
           _%state5815%_
           _%count5816%_
           _%indexed?5818%_))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!
      (lambda _g6322_
        (let ((_g6323_ (let () (declare (not safe)) (##length _g6322_))))
          (cond ((let () (declare (not safe)) (##fx= _g6323_ 2))
                 (apply gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!__0
                        _g6322_))
                ((let () (declare (not safe)) (##fx= _g6323_ 3))
                 (apply gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!__%
                        _g6322_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!
                  _g6322_))))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-observation
      (lambda (_%state5777%_)
        (list (let* ((_%h5779%_
                      (##structure-ref
                       _%state5777%_
                       '1
                       gerbil-ascent/table/eqrel#eqrel-state::t
                       '#f))
                     (_%h5783%_
                      (let ()
                        (declare (not safe))
                        (cast HashTable::interface _%h5779%_)))
                     (_%h5785%_ _%h5783%_))
                (declare (not safe))
                (__hash-length _%h5785%_))
              (##structure-ref
               _%state5777%_
               '2
               gerbil-ascent/table/eqrel#eqrel-state::t
               '#f))))))
