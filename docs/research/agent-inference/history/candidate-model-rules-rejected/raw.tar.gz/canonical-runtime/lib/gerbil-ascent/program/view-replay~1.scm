(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/view-replay[1]#_g33933_|
    (##structure
     gx#syntax-quote::t
     'replay-node::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33935_|
    (##structure
     gx#syntax-quote::t
     'make-replay-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33937_|
    (##structure
     gx#syntax-quote::t
     'replay-node?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33939_|
    (##structure
     gx#syntax-quote::t
     'replay-node-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33940_|
    (##structure
     gx#syntax-quote::t
     'replay-node-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33941_|
    (##structure
     gx#syntax-quote::t
     'replay-node-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33943_|
    (##structure
     gx#syntax-quote::t
     'replay-node-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33944_|
    (##structure
     gx#syntax-quote::t
     'replay-node-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33945_|
    (##structure
     gx#syntax-quote::t
     'replay-node-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33947_|
    (##structure
     gx#syntax-quote::t
     '&replay-node-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33948_|
    (##structure
     gx#syntax-quote::t
     '&replay-node-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33949_|
    (##structure
     gx#syntax-quote::t
     '&replay-node-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33951_|
    (##structure
     gx#syntax-quote::t
     '&replay-node-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33952_|
    (##structure
     gx#syntax-quote::t
     '&replay-node-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33953_|
    (##structure
     gx#syntax-quote::t
     '&replay-node-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33955_|
    (##structure
     gx#syntax-quote::t
     'replay-group::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33957_|
    (##structure
     gx#syntax-quote::t
     'make-replay-group
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33959_|
    (##structure
     gx#syntax-quote::t
     'replay-group?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33961_|
    (##structure
     gx#syntax-quote::t
     'replay-group-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33962_|
    (##structure
     gx#syntax-quote::t
     'replay-group-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33963_|
    (##structure
     gx#syntax-quote::t
     'replay-group-values
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33964_|
    (##structure
     gx#syntax-quote::t
     'replay-group-used
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33965_|
    (##structure
     gx#syntax-quote::t
     'replay-group-width
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33966_|
    (##structure
     gx#syntax-quote::t
     'replay-group-bits
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33968_|
    (##structure
     gx#syntax-quote::t
     'replay-group-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33969_|
    (##structure
     gx#syntax-quote::t
     'replay-group-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33970_|
    (##structure
     gx#syntax-quote::t
     'replay-group-values-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33971_|
    (##structure
     gx#syntax-quote::t
     'replay-group-used-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33972_|
    (##structure
     gx#syntax-quote::t
     'replay-group-width-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33973_|
    (##structure
     gx#syntax-quote::t
     'replay-group-bits-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33975_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33976_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33977_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-values
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33978_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-used
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33979_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-width
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33980_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-bits
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33982_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33983_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33984_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-values-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33985_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-used-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33986_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-width-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33987_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-bits-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/view-replay[:0:]#replay-node|
      (let ((__obj33806
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33806
           'gerbil-ascent/program/view-replay#replay-node::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33806 'replay-node '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33806
           '(parent members size)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33806
           '(parent members size)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33806 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33806 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33806 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33806 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33806 '#f '13 '#f '#f))
        (let ((__tmp33932 |gerbil-ascent/program/view-replay[1]#_g33933_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33806 __tmp33932 '4 '#f '#f))
        (let ((__tmp33934 |gerbil-ascent/program/view-replay[1]#_g33935_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33806 __tmp33934 '14 '#f '#f))
        (let ((__tmp33936 |gerbil-ascent/program/view-replay[1]#_g33937_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33806 __tmp33936 '15 '#f '#f))
        (let ((__tmp33938
               (cons (cons 'parent
                           |gerbil-ascent/program/view-replay[1]#_g33939_|)
                     (cons (cons 'members
                                 |gerbil-ascent/program/view-replay[1]#_g33940_|)
                           (cons (cons 'size
                                       |gerbil-ascent/program/view-replay[1]#_g33941_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33806 __tmp33938 '16 '#f '#f))
        (let ((__tmp33942
               (cons (cons 'parent
                           |gerbil-ascent/program/view-replay[1]#_g33943_|)
                     (cons (cons 'members
                                 |gerbil-ascent/program/view-replay[1]#_g33944_|)
                           (cons (cons 'size
                                       |gerbil-ascent/program/view-replay[1]#_g33945_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33806 __tmp33942 '17 '#f '#f))
        (let ((__tmp33946
               (cons (cons 'parent
                           |gerbil-ascent/program/view-replay[1]#_g33947_|)
                     (cons (cons 'members
                                 |gerbil-ascent/program/view-replay[1]#_g33948_|)
                           (cons (cons 'size
                                       |gerbil-ascent/program/view-replay[1]#_g33949_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33806 __tmp33946 '18 '#f '#f))
        (let ((__tmp33950
               (cons (cons 'parent
                           |gerbil-ascent/program/view-replay[1]#_g33951_|)
                     (cons (cons 'members
                                 |gerbil-ascent/program/view-replay[1]#_g33952_|)
                           (cons (cons 'size
                                       |gerbil-ascent/program/view-replay[1]#_g33953_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33806 __tmp33950 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33806 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33806 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33806 '() '21 '#f '#f))
        __obj33806))
    (define |gerbil-ascent/program/view-replay[:0:]#replay-group|
      (let ((__obj33807
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33807
           'gerbil-ascent/program/view-replay#replay-group::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33807 'replay-group '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33807
           '(nodes roots values used width bits)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33807
           '(nodes roots values used width bits)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33807 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33807 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33807 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33807 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33807 '#f '13 '#f '#f))
        (let ((__tmp33954 |gerbil-ascent/program/view-replay[1]#_g33955_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33807 __tmp33954 '4 '#f '#f))
        (let ((__tmp33956 |gerbil-ascent/program/view-replay[1]#_g33957_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33807 __tmp33956 '14 '#f '#f))
        (let ((__tmp33958 |gerbil-ascent/program/view-replay[1]#_g33959_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33807 __tmp33958 '15 '#f '#f))
        (let ((__tmp33960
               (cons (cons 'nodes
                           |gerbil-ascent/program/view-replay[1]#_g33961_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/program/view-replay[1]#_g33962_|)
                           (cons (cons 'values
                                       |gerbil-ascent/program/view-replay[1]#_g33963_|)
                                 (cons (cons 'used
                                             |gerbil-ascent/program/view-replay[1]#_g33964_|)
                                       (cons (cons 'width
                                                   |gerbil-ascent/program/view-replay[1]#_g33965_|)
                                             (cons (cons 'bits
                                                         |gerbil-ascent/program/view-replay[1]#_g33966_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33807 __tmp33960 '16 '#f '#f))
        (let ((__tmp33967
               (cons (cons 'nodes
                           |gerbil-ascent/program/view-replay[1]#_g33968_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/program/view-replay[1]#_g33969_|)
                           (cons (cons 'values
                                       |gerbil-ascent/program/view-replay[1]#_g33970_|)
                                 (cons (cons 'used
                                             |gerbil-ascent/program/view-replay[1]#_g33971_|)
                                       (cons (cons 'width
                                                   |gerbil-ascent/program/view-replay[1]#_g33972_|)
                                             (cons (cons 'bits
                                                         |gerbil-ascent/program/view-replay[1]#_g33973_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33807 __tmp33967 '17 '#f '#f))
        (let ((__tmp33974
               (cons (cons 'nodes
                           |gerbil-ascent/program/view-replay[1]#_g33975_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/program/view-replay[1]#_g33976_|)
                           (cons (cons 'values
                                       |gerbil-ascent/program/view-replay[1]#_g33977_|)
                                 (cons (cons 'used
                                             |gerbil-ascent/program/view-replay[1]#_g33978_|)
                                       (cons (cons 'width
                                                   |gerbil-ascent/program/view-replay[1]#_g33979_|)
                                             (cons (cons 'bits
                                                         |gerbil-ascent/program/view-replay[1]#_g33980_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33807 __tmp33974 '18 '#f '#f))
        (let ((__tmp33981
               (cons (cons 'nodes
                           |gerbil-ascent/program/view-replay[1]#_g33982_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/program/view-replay[1]#_g33983_|)
                           (cons (cons 'values
                                       |gerbil-ascent/program/view-replay[1]#_g33984_|)
                                 (cons (cons 'used
                                             |gerbil-ascent/program/view-replay[1]#_g33985_|)
                                       (cons (cons 'width
                                                   |gerbil-ascent/program/view-replay[1]#_g33986_|)
                                             (cons (cons 'bits
                                                         |gerbil-ascent/program/view-replay[1]#_g33987_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33807 __tmp33981 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33807 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33807 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33807 '() '21 '#f '#f))
        __obj33807))))
