(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37662_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37664_|
    (##structure
     gx#syntax-quote::t
     'make-finite-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37666_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37668_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37669_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37670_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37671_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37672_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37673_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-program
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37674_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37675_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37676_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-closure
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37678_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37679_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37680_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37681_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37682_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37683_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-program-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37684_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37685_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37686_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-closure-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37688_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37689_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37690_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37691_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37692_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37693_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-program
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37694_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37695_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37696_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-closure
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37698_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37699_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37700_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37701_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37702_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37703_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-program-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37704_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37705_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37706_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-closure-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37708_|
    (##structure
     gx#syntax-quote::t
     'replay-relation::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37710_|
    (##structure
     gx#syntax-quote::t
     'make-replay-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37712_|
    (##structure
     gx#syntax-quote::t
     'replay-relation?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37714_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-arity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37715_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-reversed
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37716_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-present
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37717_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-frontier
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37718_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-dirty?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37720_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-arity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37721_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-reversed-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37722_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-present-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37723_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-frontier-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37724_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-dirty?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37726_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-arity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37727_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-reversed
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37728_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-present
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37729_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-frontier
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37730_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-dirty?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37732_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-arity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37733_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-reversed-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37734_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-present-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37735_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-frontier-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37736_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-dirty?-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/finite-evidence[:0:]#finite-evidence|
      (let ((__obj37546
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37546
           'gerbil-ascent/candidate/finite-evidence#finite-evidence::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37546 'finite-evidence '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37546
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    program
                    query
                    work-budget
                    closure)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37546
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    program
                    query
                    work-budget
                    closure)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37546 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37546 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37546 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37546 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37546 '#f '13 '#f '#f))
        (let ((__tmp37661
               |gerbil-ascent/candidate/finite-evidence[1]#_g37662_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37546 __tmp37661 '4 '#f '#f))
        (let ((__tmp37663
               |gerbil-ascent/candidate/finite-evidence[1]#_g37664_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37546 __tmp37663 '14 '#f '#f))
        (let ((__tmp37665
               |gerbil-ascent/candidate/finite-evidence[1]#_g37666_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37546 __tmp37665 '15 '#f '#f))
        (let ((__tmp37667
               (cons (cons 'status
                           |gerbil-ascent/candidate/finite-evidence[1]#_g37668_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g37669_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g37670_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g37671_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37672_|)
                                             (cons (cons 'program
                                                         |gerbil-ascent/candidate/finite-evidence[1]#_g37673_|)
                                                   (cons (cons 'query
                                                               |gerbil-ascent/candidate/finite-evidence[1]#_g37674_|)
                                                         (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/finite-evidence[1]#_g37675_|)
                       (cons (cons 'closure
                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37676_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37546 __tmp37667 '16 '#f '#f))
        (let ((__tmp37677
               (cons (cons 'status
                           |gerbil-ascent/candidate/finite-evidence[1]#_g37678_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g37679_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g37680_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g37681_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37682_|)
                                             (cons (cons 'program
                                                         |gerbil-ascent/candidate/finite-evidence[1]#_g37683_|)
                                                   (cons (cons 'query
                                                               |gerbil-ascent/candidate/finite-evidence[1]#_g37684_|)
                                                         (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/finite-evidence[1]#_g37685_|)
                       (cons (cons 'closure
                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37686_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37546 __tmp37677 '17 '#f '#f))
        (let ((__tmp37687
               (cons (cons 'status
                           |gerbil-ascent/candidate/finite-evidence[1]#_g37688_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g37689_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g37690_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g37691_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37692_|)
                                             (cons (cons 'program
                                                         |gerbil-ascent/candidate/finite-evidence[1]#_g37693_|)
                                                   (cons (cons 'query
                                                               |gerbil-ascent/candidate/finite-evidence[1]#_g37694_|)
                                                         (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/finite-evidence[1]#_g37695_|)
                       (cons (cons 'closure
                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37696_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37546 __tmp37687 '18 '#f '#f))
        (let ((__tmp37697
               (cons (cons 'status
                           |gerbil-ascent/candidate/finite-evidence[1]#_g37698_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g37699_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g37700_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g37701_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37702_|)
                                             (cons (cons 'program
                                                         |gerbil-ascent/candidate/finite-evidence[1]#_g37703_|)
                                                   (cons (cons 'query
                                                               |gerbil-ascent/candidate/finite-evidence[1]#_g37704_|)
                                                         (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/finite-evidence[1]#_g37705_|)
                       (cons (cons 'closure
                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37706_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37546 __tmp37697 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37546 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37546 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37546 '() '21 '#f '#f))
        __obj37546))
    (define |gerbil-ascent/candidate/finite-evidence[:0:]#replay-relation|
      (let ((__obj37547
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37547
           'gerbil-ascent/candidate/finite-evidence#replay-relation::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37547 'replay-relation '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37547
           '(arity reversed present frontier dirty?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37547
           '(arity reversed present frontier dirty?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37547 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37547 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37547 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37547 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37547 '#f '13 '#f '#f))
        (let ((__tmp37707
               |gerbil-ascent/candidate/finite-evidence[1]#_g37708_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37547 __tmp37707 '4 '#f '#f))
        (let ((__tmp37709
               |gerbil-ascent/candidate/finite-evidence[1]#_g37710_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37547 __tmp37709 '14 '#f '#f))
        (let ((__tmp37711
               |gerbil-ascent/candidate/finite-evidence[1]#_g37712_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37547 __tmp37711 '15 '#f '#f))
        (let ((__tmp37713
               (cons (cons 'arity
                           |gerbil-ascent/candidate/finite-evidence[1]#_g37714_|)
                     (cons (cons 'reversed
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g37715_|)
                           (cons (cons 'present
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g37716_|)
                                 (cons (cons 'frontier
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g37717_|)
                                       (cons (cons 'dirty?
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37718_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37547 __tmp37713 '16 '#f '#f))
        (let ((__tmp37719
               (cons (cons 'arity
                           |gerbil-ascent/candidate/finite-evidence[1]#_g37720_|)
                     (cons (cons 'reversed
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g37721_|)
                           (cons (cons 'present
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g37722_|)
                                 (cons (cons 'frontier
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g37723_|)
                                       (cons (cons 'dirty?
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37724_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37547 __tmp37719 '17 '#f '#f))
        (let ((__tmp37725
               (cons (cons 'arity
                           |gerbil-ascent/candidate/finite-evidence[1]#_g37726_|)
                     (cons (cons 'reversed
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g37727_|)
                           (cons (cons 'present
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g37728_|)
                                 (cons (cons 'frontier
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g37729_|)
                                       (cons (cons 'dirty?
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37730_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37547 __tmp37725 '18 '#f '#f))
        (let ((__tmp37731
               (cons (cons 'arity
                           |gerbil-ascent/candidate/finite-evidence[1]#_g37732_|)
                     (cons (cons 'reversed
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g37733_|)
                           (cons (cons 'present
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g37734_|)
                                 (cons (cons 'frontier
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g37735_|)
                                       (cons (cons 'dirty?
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37736_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37547 __tmp37731 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37547 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37547 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37547 '() '21 '#f '#f))
        __obj37547))))
