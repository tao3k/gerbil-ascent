(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/scheme-snapshot::timestamp 1791689700)
  (begin
    (define gerbil-ascent/program/scheme-snapshot#relational-copy-term
      (lambda (_%term20241%_)
        (let ((_%$e20243%_
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%term20241%_ 'kind))))
          (if (eq? 'variable _%$e20243%_)
              (let ((__tmp36593
                     (let ()
                       (declare (not safe))
                       (clan/poo/object#.ref _%term20241%_ 'value))))
                (declare (not safe))
                (gerbil-ascent/program/objects#gerbil-ascent-variable
                 __tmp36593))
              (if (eq? 'wildcard _%$e20243%_)
                  (let ()
                    (declare (not safe))
                    (gerbil-ascent/program/objects#gerbil-ascent-wildcard))
                  (if (eq? 'literal _%$e20243%_)
                      (let ((_%value20246%_
                             (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref _%term20241%_ 'value))))
                        (if (let ()
                              (declare (not safe))
                              (gerbil-ascent/program/scheme-checked#relational-scalar?
                               _%value20246%_))
                            '#!void
                            (let ()
                              (declare (not safe))
                              (error '"non-scalar relational literal"
                                     _%value20246%_)))
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/program/objects#gerbil-ascent-literal
                           _%value20246%_)))
                      (let ((__tmp36594
                             (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref _%term20241%_ 'kind))))
                        (declare (not safe))
                        (error '"unsupported relational term"
                               __tmp36594))))))))
    (define gerbil-ascent/program/scheme-snapshot#relational-copy-atom
      (lambda (_%atom20239%_)
        (if (eq? (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%atom20239%_ 'ascent-clause-kind))
                 'atom)
            '#!void
            (let ()
              (declare (not safe))
              (error '"unsupported relational clause")))
        (let ((__tmp36596
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%atom20239%_ 'relation)))
              (__tmp36595
               (map gerbil-ascent/program/scheme-snapshot#relational-copy-term
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%atom20239%_ 'terms)))))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-atom
           __tmp36596
           __tmp36595))))
    (define gerbil-ascent/program/scheme-snapshot#relational-copy-clause
      (lambda (_%clause20227%_)
        (let ((_%$e20229%_
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%clause20227%_ 'ascent-clause-kind))))
          (if (eq? 'atom _%$e20229%_)
              (gerbil-ascent/program/scheme-snapshot#relational-copy-atom
               _%clause20227%_)
              (if (eq? 'negation _%$e20229%_)
                  (let ((__tmp36598
                         (let ()
                           (declare (not safe))
                           (clan/poo/object#.ref _%clause20227%_ 'relation)))
                        (__tmp36597
                         (map gerbil-ascent/program/scheme-snapshot#relational-copy-term
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%clause20227%_
                                 'terms)))))
                    (declare (not safe))
                    (gerbil-ascent/program/objects#gerbil-ascent-negation
                     __tmp36598
                     __tmp36597))
                  (if (eq? 'aggregate _%$e20229%_)
                      (let ((_%descriptor20232%_
                             (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref
                                _%clause20227%_
                                'checked-operator)))
                            (_%terms20233%_
                             (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref _%clause20227%_ 'terms))))
                        (if (and (vector? _%descriptor20232%_)
                                 (= (let ()
                                      (declare (not safe))
                                      (##vector-length _%descriptor20232%_))
                                    '6)
                                 (eq? (vector-ref _%descriptor20232%_ '0)
                                      'reduce)
                                 (eq? (vector-ref _%descriptor20232%_ '2)
                                      (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%clause20227%_
                                         'variable)))
                                 (eq? (vector-ref _%descriptor20232%_ '3)
                                      (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%clause20227%_
                                         'relation)))
                                 (equal? (vector-ref _%descriptor20232%_ '4)
                                         (let ()
                                           (declare (not safe))
                                           (clan/poo/object#.ref
                                            _%clause20227%_
                                            'variables)))
                                 (equal? (vector-ref _%descriptor20232%_ '5)
                                         (let ()
                                           (declare (not safe))
                                           (gerbil-ascent/program/scheme-checked#relational-term-fingerprint
                                            _%terms20233%_)))
                                 (not (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%clause20227%_
                                         'output-pattern))))
                            '#!void
                            (let ()
                              (declare (not safe))
                              (error '"untrusted relational reduction")))
                        (let ((__tmp36603 (vector-ref _%descriptor20232%_ '2))
                              (__tmp36602 (vector-ref _%descriptor20232%_ '1))
                              (__tmp36601 (vector-ref _%descriptor20232%_ '4))
                              (__tmp36600 (vector-ref _%descriptor20232%_ '3))
                              (__tmp36599
                               (map gerbil-ascent/program/scheme-snapshot#relational-copy-term
                                    _%terms20233%_)))
                          (declare (not safe))
                          (gerbil-ascent/program/scheme-checked#relational-reducer
                           __tmp36603
                           __tmp36602
                           __tmp36601
                           __tmp36600
                           __tmp36599)))
                      (if (eq? 'guard _%$e20229%_)
                          (let ((_%descriptor20235%_
                                 (let ()
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    _%clause20227%_
                                    'checked-operator))))
                            (if (and (vector? _%descriptor20235%_)
                                     (= (let ()
                                          (declare (not safe))
                                          (##vector-length
                                           _%descriptor20235%_))
                                        '3)
                                     (eq? (vector-ref _%descriptor20235%_ '0)
                                          'where)
                                     (equal? (let ((__tmp36604
                                                    (vector-ref
                                                     _%descriptor20235%_
                                                     '2)))
                                               (declare (not safe))
                                               (gerbil-ascent/program/scheme-checked#relational-operand-variables
                                                __tmp36604))
                                             (let ()
                                               (declare (not safe))
                                               (clan/poo/object#.ref
                                                _%clause20227%_
                                                'variables))))
                                '#!void
                                (let ()
                                  (declare (not safe))
                                  (error '"untrusted relational filter")))
                            (let ((__tmp36606
                                   (vector-ref _%descriptor20235%_ '1))
                                  (__tmp36605
                                   (vector-ref _%descriptor20235%_ '2)))
                              (declare (not safe))
                              (gerbil-ascent/program/scheme-checked#relational-where
                               __tmp36606
                               __tmp36605)))
                          (if (eq? 'binding _%$e20229%_)
                              (let ((_%descriptor20237%_
                                     (let ()
                                       (declare (not safe))
                                       (clan/poo/object#.ref
                                        _%clause20227%_
                                        'checked-operator))))
                                (if (and (vector? _%descriptor20237%_)
                                         (= (let ()
                                              (declare (not safe))
                                              (##vector-length
                                               _%descriptor20237%_))
                                            '4)
                                         (eq? (vector-ref
                                               _%descriptor20237%_
                                               '0)
                                              'compute)
                                         (equal? (let ((__tmp36607
                                                        (vector-ref
                                                         _%descriptor20237%_
                                                         '2)))
                                                   (declare (not safe))
                                                   (gerbil-ascent/program/scheme-checked#relational-operand-variables
                                                    __tmp36607))
                                                 (let ()
                                                   (declare (not safe))
                                                   (clan/poo/object#.ref
                                                    _%clause20227%_
                                                    'variables)))
                                         (eq? (vector-ref
                                               _%descriptor20237%_
                                               '3)
                                              (let ()
                                                (declare (not safe))
                                                (clan/poo/object#.ref
                                                 _%clause20227%_
                                                 'variable))))
                                    '#!void
                                    (let ()
                                      (declare (not safe))
                                      (error '"untrusted relational projection")))
                                (let ((__tmp36610
                                       (vector-ref _%descriptor20237%_ '3))
                                      (__tmp36609
                                       (vector-ref _%descriptor20237%_ '1))
                                      (__tmp36608
                                       (vector-ref _%descriptor20237%_ '2)))
                                  (declare (not safe))
                                  (gerbil-ascent/program/scheme-checked#relational-compute
                                   __tmp36610
                                   __tmp36609
                                   __tmp36608)))
                              (let ((__tmp36611
                                     (let ()
                                       (declare (not safe))
                                       (clan/poo/object#.ref
                                        _%clause20227%_
                                        'ascent-clause-kind))))
                                (declare (not safe))
                                (error '"unsupported relational clause"
                                       __tmp36611))))))))))
    (define gerbil-ascent/program/scheme-snapshot#relational-copy-rule
      (lambda (_%rule20225%_)
        (let ((__tmp36613
               (map gerbil-ascent/program/scheme-snapshot#relational-copy-atom
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%rule20225%_ 'heads))))
              (__tmp36612
               (map gerbil-ascent/program/scheme-snapshot#relational-copy-clause
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%rule20225%_ 'body)))))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-rule
           __tmp36613
           __tmp36612))))
    (define gerbil-ascent/program/scheme-snapshot#relational-snapshot-program
      (lambda (_%program20205%_)
        (let ()
          (declare (not safe))
          (clan/poo/mop#validate
           gerbil-ascent/program/types#GerbilAscentProgramContract
           _%program20205%_))
        (let ((__tmp36619
               (map (lambda (_%relation20207%_)
                      (let* ((_%domain20209%_
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%relation20207%_
                                 'checked-domain)))
                             (_%domains20211%_
                              (if _%domain20209%_
                                  (begin
                                    (if (and (vector? _%domain20209%_)
                                             (= (let ()
                                                  (declare (not safe))
                                                  (##vector-length
                                                   _%domain20209%_))
                                                '2)
                                             (eq? (vector-ref
                                                   _%domain20209%_
                                                   '0)
                                                  'finite-domain))
                                        '#!void
                                        (let ()
                                          (declare (not safe))
                                          (error '"untrusted finite domain descriptor")))
                                    (vector-ref _%domain20209%_ '1))
                                  '#f))
                             (_%name20213%_
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%relation20207%_
                                 'name)))
                             (_%arity20215%_
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%relation20207%_
                                 'arity)))
                             (_%rows20217%_
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%relation20207%_
                                 'rows)))
                             (_%$e20220%_
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%relation20207%_
                                 'storage-kind))))
                        (if (eq? 'relation _%$e20220%_)
                            (if _%domain20209%_
                                (let ()
                                  (declare (not safe))
                                  (gerbil-ascent/program/scheme-checked#relational-finite-source
                                   _%name20213%_
                                   _%arity20215%_
                                   _%rows20217%_
                                   _%domains20211%_))
                                (let ()
                                  (declare (not safe))
                                  (gerbil-ascent/program/scheme-checked#relational-source
                                   _%name20213%_
                                   _%arity20215%_
                                   _%rows20217%_)))
                            (if (eq? 'lattice _%$e20220%_)
                                (let ((_%descriptor20223%_
                                       (let ()
                                         (declare (not safe))
                                         (clan/poo/object#.ref
                                          _%relation20207%_
                                          'checked-operator))))
                                  (if (and (vector? _%descriptor20223%_)
                                           (= (let ()
                                                (declare (not safe))
                                                (##vector-length
                                                 _%descriptor20223%_))
                                              '2)
                                           (eq? (vector-ref
                                                 _%descriptor20223%_
                                                 '0)
                                                'lattice))
                                      '#!void
                                      (let ()
                                        (declare (not safe))
                                        (error '"untrusted relational lattice")))
                                  (if _%domain20209%_
                                      (let ((__tmp36620
                                             (vector-ref
                                              _%descriptor20223%_
                                              '1)))
                                        (declare (not safe))
                                        (gerbil-ascent/program/scheme-checked#relational-finite-lattice
                                         _%name20213%_
                                         _%arity20215%_
                                         _%rows20217%_
                                         __tmp36620
                                         _%domains20211%_))
                                      (let ((__tmp36621
                                             (vector-ref
                                              _%descriptor20223%_
                                              '1)))
                                        (declare (not safe))
                                        (gerbil-ascent/program/scheme-checked#relational-checked-lattice
                                         _%name20213%_
                                         _%arity20215%_
                                         _%rows20217%_
                                         __tmp36621))))
                                (let ()
                                  (declare (not safe))
                                  (error '"unsupported relational storage kind"))))))
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%program20205%_ 'relations))))
              (__tmp36618
               (map gerbil-ascent/program/scheme-snapshot#relational-copy-rule
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%program20205%_ 'rules))))
              (__tmp36617
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%program20205%_ 'max-input-facts)))
              (__tmp36616
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%program20205%_ 'max-derived-facts)))
              (__tmp36615
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%program20205%_ 'max-output-facts)))
              (__tmp36614
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%program20205%_ 'source-handles))))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-program__%
           __tmp36619
           __tmp36618
           __tmp36617
           __tmp36616
           __tmp36615
           __tmp36614))))))
