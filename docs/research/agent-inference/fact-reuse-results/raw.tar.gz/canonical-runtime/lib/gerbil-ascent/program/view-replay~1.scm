(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/view-replay[1]#_g34394_|
    (##structure
     gx#syntax-quote::t
     'replay-node::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34396_|
    (##structure
     gx#syntax-quote::t
     'make-replay-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34398_|
    (##structure
     gx#syntax-quote::t
     'replay-node?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34400_|
    (##structure
     gx#syntax-quote::t
     'replay-node-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34401_|
    (##structure
     gx#syntax-quote::t
     'replay-node-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34402_|
    (##structure
     gx#syntax-quote::t
     'replay-node-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34404_|
    (##structure
     gx#syntax-quote::t
     'replay-node-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34405_|
    (##structure
     gx#syntax-quote::t
     'replay-node-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34406_|
    (##structure
     gx#syntax-quote::t
     'replay-node-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34408_|
    (##structure
     gx#syntax-quote::t
     '&replay-node-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34409_|
    (##structure
     gx#syntax-quote::t
     '&replay-node-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34410_|
    (##structure
     gx#syntax-quote::t
     '&replay-node-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34412_|
    (##structure
     gx#syntax-quote::t
     '&replay-node-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34413_|
    (##structure
     gx#syntax-quote::t
     '&replay-node-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34414_|
    (##structure
     gx#syntax-quote::t
     '&replay-node-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34416_|
    (##structure
     gx#syntax-quote::t
     'replay-group::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34418_|
    (##structure
     gx#syntax-quote::t
     'make-replay-group
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34420_|
    (##structure
     gx#syntax-quote::t
     'replay-group?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34422_|
    (##structure
     gx#syntax-quote::t
     'replay-group-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34423_|
    (##structure
     gx#syntax-quote::t
     'replay-group-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34424_|
    (##structure
     gx#syntax-quote::t
     'replay-group-values
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34425_|
    (##structure
     gx#syntax-quote::t
     'replay-group-used
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34426_|
    (##structure
     gx#syntax-quote::t
     'replay-group-width
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34427_|
    (##structure
     gx#syntax-quote::t
     'replay-group-bits
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34429_|
    (##structure
     gx#syntax-quote::t
     'replay-group-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34430_|
    (##structure
     gx#syntax-quote::t
     'replay-group-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34431_|
    (##structure
     gx#syntax-quote::t
     'replay-group-values-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34432_|
    (##structure
     gx#syntax-quote::t
     'replay-group-used-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34433_|
    (##structure
     gx#syntax-quote::t
     'replay-group-width-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34434_|
    (##structure
     gx#syntax-quote::t
     'replay-group-bits-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34436_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34437_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34438_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-values
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34439_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-used
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34440_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-width
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34441_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-bits
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34443_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34444_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34445_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-values-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34446_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-used-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34447_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-width-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34448_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-bits-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/view-replay[:0:]#replay-node|
      (let ((__obj34267
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34267
           'gerbil-ascent/program/view-replay#replay-node::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34267 'replay-node '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34267
           '(parent members size)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34267
           '(parent members size)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34267 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34267 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34267 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34267 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34267 '#f '13 '#f '#f))
        (let ((__tmp34393 |gerbil-ascent/program/view-replay[1]#_g34394_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34267 __tmp34393 '4 '#f '#f))
        (let ((__tmp34395 |gerbil-ascent/program/view-replay[1]#_g34396_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34267 __tmp34395 '14 '#f '#f))
        (let ((__tmp34397 |gerbil-ascent/program/view-replay[1]#_g34398_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34267 __tmp34397 '15 '#f '#f))
        (let ((__tmp34399
               (cons (cons 'parent
                           |gerbil-ascent/program/view-replay[1]#_g34400_|)
                     (cons (cons 'members
                                 |gerbil-ascent/program/view-replay[1]#_g34401_|)
                           (cons (cons 'size
                                       |gerbil-ascent/program/view-replay[1]#_g34402_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34267 __tmp34399 '16 '#f '#f))
        (let ((__tmp34403
               (cons (cons 'parent
                           |gerbil-ascent/program/view-replay[1]#_g34404_|)
                     (cons (cons 'members
                                 |gerbil-ascent/program/view-replay[1]#_g34405_|)
                           (cons (cons 'size
                                       |gerbil-ascent/program/view-replay[1]#_g34406_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34267 __tmp34403 '17 '#f '#f))
        (let ((__tmp34407
               (cons (cons 'parent
                           |gerbil-ascent/program/view-replay[1]#_g34408_|)
                     (cons (cons 'members
                                 |gerbil-ascent/program/view-replay[1]#_g34409_|)
                           (cons (cons 'size
                                       |gerbil-ascent/program/view-replay[1]#_g34410_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34267 __tmp34407 '18 '#f '#f))
        (let ((__tmp34411
               (cons (cons 'parent
                           |gerbil-ascent/program/view-replay[1]#_g34412_|)
                     (cons (cons 'members
                                 |gerbil-ascent/program/view-replay[1]#_g34413_|)
                           (cons (cons 'size
                                       |gerbil-ascent/program/view-replay[1]#_g34414_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34267 __tmp34411 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34267 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34267 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34267 '() '21 '#f '#f))
        __obj34267))
    (define |gerbil-ascent/program/view-replay[:0:]#replay-group|
      (let ((__obj34268
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34268
           'gerbil-ascent/program/view-replay#replay-group::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34268 'replay-group '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34268
           '(nodes roots values used width bits)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34268
           '(nodes roots values used width bits)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34268 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34268 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34268 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34268 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34268 '#f '13 '#f '#f))
        (let ((__tmp34415 |gerbil-ascent/program/view-replay[1]#_g34416_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34268 __tmp34415 '4 '#f '#f))
        (let ((__tmp34417 |gerbil-ascent/program/view-replay[1]#_g34418_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34268 __tmp34417 '14 '#f '#f))
        (let ((__tmp34419 |gerbil-ascent/program/view-replay[1]#_g34420_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34268 __tmp34419 '15 '#f '#f))
        (let ((__tmp34421
               (cons (cons 'nodes
                           |gerbil-ascent/program/view-replay[1]#_g34422_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/program/view-replay[1]#_g34423_|)
                           (cons (cons 'values
                                       |gerbil-ascent/program/view-replay[1]#_g34424_|)
                                 (cons (cons 'used
                                             |gerbil-ascent/program/view-replay[1]#_g34425_|)
                                       (cons (cons 'width
                                                   |gerbil-ascent/program/view-replay[1]#_g34426_|)
                                             (cons (cons 'bits
                                                         |gerbil-ascent/program/view-replay[1]#_g34427_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34268 __tmp34421 '16 '#f '#f))
        (let ((__tmp34428
               (cons (cons 'nodes
                           |gerbil-ascent/program/view-replay[1]#_g34429_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/program/view-replay[1]#_g34430_|)
                           (cons (cons 'values
                                       |gerbil-ascent/program/view-replay[1]#_g34431_|)
                                 (cons (cons 'used
                                             |gerbil-ascent/program/view-replay[1]#_g34432_|)
                                       (cons (cons 'width
                                                   |gerbil-ascent/program/view-replay[1]#_g34433_|)
                                             (cons (cons 'bits
                                                         |gerbil-ascent/program/view-replay[1]#_g34434_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34268 __tmp34428 '17 '#f '#f))
        (let ((__tmp34435
               (cons (cons 'nodes
                           |gerbil-ascent/program/view-replay[1]#_g34436_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/program/view-replay[1]#_g34437_|)
                           (cons (cons 'values
                                       |gerbil-ascent/program/view-replay[1]#_g34438_|)
                                 (cons (cons 'used
                                             |gerbil-ascent/program/view-replay[1]#_g34439_|)
                                       (cons (cons 'width
                                                   |gerbil-ascent/program/view-replay[1]#_g34440_|)
                                             (cons (cons 'bits
                                                         |gerbil-ascent/program/view-replay[1]#_g34441_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34268 __tmp34435 '18 '#f '#f))
        (let ((__tmp34442
               (cons (cons 'nodes
                           |gerbil-ascent/program/view-replay[1]#_g34443_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/program/view-replay[1]#_g34444_|)
                           (cons (cons 'values
                                       |gerbil-ascent/program/view-replay[1]#_g34445_|)
                                 (cons (cons 'used
                                             |gerbil-ascent/program/view-replay[1]#_g34446_|)
                                       (cons (cons 'width
                                                   |gerbil-ascent/program/view-replay[1]#_g34447_|)
                                             (cons (cons 'bits
                                                         |gerbil-ascent/program/view-replay[1]#_g34448_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34268 __tmp34442 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34268 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34268 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34268 '() '21 '#f '#f))
        __obj34268))))
