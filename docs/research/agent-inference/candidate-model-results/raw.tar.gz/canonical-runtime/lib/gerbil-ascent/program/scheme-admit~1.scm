(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/scheme-admit[1]#_g37838_|
    (##structure
     gx#syntax-quote::t
     'relational-admission::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37840_|
    (##structure
     gx#syntax-quote::t
     'make-relational-admission
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37842_|
    (##structure
     gx#syntax-quote::t
     'relational-admission?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37844_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-run
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37846_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-run-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37848_|
    (##structure
     gx#syntax-quote::t
     '&relational-admission-run
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37850_|
    (##structure
     gx#syntax-quote::t
     '&relational-admission-run-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37852_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37854_|
    (##structure
     gx#syntax-quote::t
     'make-relational-diagnostic
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37856_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37858_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic-code
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37859_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic-path
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37860_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic-detail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37862_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic-code-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37863_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic-path-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37864_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic-detail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37866_|
    (##structure
     gx#syntax-quote::t
     '&relational-diagnostic-code
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37867_|
    (##structure
     gx#syntax-quote::t
     '&relational-diagnostic-path
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37868_|
    (##structure
     gx#syntax-quote::t
     '&relational-diagnostic-detail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37870_|
    (##structure
     gx#syntax-quote::t
     '&relational-diagnostic-code-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37871_|
    (##structure
     gx#syntax-quote::t
     '&relational-diagnostic-path-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37872_|
    (##structure
     gx#syntax-quote::t
     '&relational-diagnostic-detail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37874_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-report::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37876_|
    (##structure
     gx#syntax-quote::t
     'make-relational-admission-report
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37878_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-report?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37880_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-report-admission
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37881_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-report-diagnostic
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37883_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-report-admission-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37884_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-report-diagnostic-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37886_|
    (##structure
     gx#syntax-quote::t
     '&relational-admission-report-admission
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37887_|
    (##structure
     gx#syntax-quote::t
     '&relational-admission-report-diagnostic
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37889_|
    (##structure
     gx#syntax-quote::t
     '&relational-admission-report-admission-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37890_|
    (##structure
     gx#syntax-quote::t
     '&relational-admission-report-diagnostic-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/scheme-admit[:0:]#relational-admission|
      (let ((__obj37694
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37694
           'gerbil-ascent/program/scheme-admit#relational-admission::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37694
           'relational-admission
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37694 '(run) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37694 '(run) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37694 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37694 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37694 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37694 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37694 '#f '13 '#f '#f))
        (let ((__tmp37837 |gerbil-ascent/program/scheme-admit[1]#_g37838_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37694 __tmp37837 '4 '#f '#f))
        (let ((__tmp37839 |gerbil-ascent/program/scheme-admit[1]#_g37840_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37694 __tmp37839 '14 '#f '#f))
        (let ((__tmp37841 |gerbil-ascent/program/scheme-admit[1]#_g37842_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37694 __tmp37841 '15 '#f '#f))
        (let ((__tmp37843
               (cons (cons 'run
                           |gerbil-ascent/program/scheme-admit[1]#_g37844_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj37694 __tmp37843 '16 '#f '#f))
        (let ((__tmp37845
               (cons (cons 'run
                           |gerbil-ascent/program/scheme-admit[1]#_g37846_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj37694 __tmp37845 '17 '#f '#f))
        (let ((__tmp37847
               (cons (cons 'run
                           |gerbil-ascent/program/scheme-admit[1]#_g37848_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj37694 __tmp37847 '18 '#f '#f))
        (let ((__tmp37849
               (cons (cons 'run
                           |gerbil-ascent/program/scheme-admit[1]#_g37850_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj37694 __tmp37849 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37694 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37694 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37694 '() '21 '#f '#f))
        __obj37694))
    (define |gerbil-ascent/program/scheme-admit[:0:]#relational-diagnostic|
      (let ((__obj37695
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37695
           'gerbil-ascent/program/scheme-admit#relational-diagnostic::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37695
           'relational-diagnostic
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37695
           '(code path detail)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37695
           '(code path detail)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37695 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37695 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37695 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37695 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37695 '#f '13 '#f '#f))
        (let ((__tmp37851 |gerbil-ascent/program/scheme-admit[1]#_g37852_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37695 __tmp37851 '4 '#f '#f))
        (let ((__tmp37853 |gerbil-ascent/program/scheme-admit[1]#_g37854_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37695 __tmp37853 '14 '#f '#f))
        (let ((__tmp37855 |gerbil-ascent/program/scheme-admit[1]#_g37856_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37695 __tmp37855 '15 '#f '#f))
        (let ((__tmp37857
               (cons (cons 'code
                           |gerbil-ascent/program/scheme-admit[1]#_g37858_|)
                     (cons (cons 'path
                                 |gerbil-ascent/program/scheme-admit[1]#_g37859_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/program/scheme-admit[1]#_g37860_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37695 __tmp37857 '16 '#f '#f))
        (let ((__tmp37861
               (cons (cons 'code
                           |gerbil-ascent/program/scheme-admit[1]#_g37862_|)
                     (cons (cons 'path
                                 |gerbil-ascent/program/scheme-admit[1]#_g37863_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/program/scheme-admit[1]#_g37864_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37695 __tmp37861 '17 '#f '#f))
        (let ((__tmp37865
               (cons (cons 'code
                           |gerbil-ascent/program/scheme-admit[1]#_g37866_|)
                     (cons (cons 'path
                                 |gerbil-ascent/program/scheme-admit[1]#_g37867_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/program/scheme-admit[1]#_g37868_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37695 __tmp37865 '18 '#f '#f))
        (let ((__tmp37869
               (cons (cons 'code
                           |gerbil-ascent/program/scheme-admit[1]#_g37870_|)
                     (cons (cons 'path
                                 |gerbil-ascent/program/scheme-admit[1]#_g37871_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/program/scheme-admit[1]#_g37872_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37695 __tmp37869 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37695 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37695 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37695 '() '21 '#f '#f))
        __obj37695))
    (define |gerbil-ascent/program/scheme-admit[:0:]#relational-admission-report|
      (let ((__obj37696
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37696
           'gerbil-ascent/program/scheme-admit#relational-admission-report::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37696
           'relational-admission-report
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37696
           '(admission diagnostic)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37696
           '(admission diagnostic)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37696 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37696 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37696 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37696 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37696 '#f '13 '#f '#f))
        (let ((__tmp37873 |gerbil-ascent/program/scheme-admit[1]#_g37874_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37696 __tmp37873 '4 '#f '#f))
        (let ((__tmp37875 |gerbil-ascent/program/scheme-admit[1]#_g37876_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37696 __tmp37875 '14 '#f '#f))
        (let ((__tmp37877 |gerbil-ascent/program/scheme-admit[1]#_g37878_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37696 __tmp37877 '15 '#f '#f))
        (let ((__tmp37879
               (cons (cons 'admission
                           |gerbil-ascent/program/scheme-admit[1]#_g37880_|)
                     (cons (cons 'diagnostic
                                 |gerbil-ascent/program/scheme-admit[1]#_g37881_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37696 __tmp37879 '16 '#f '#f))
        (let ((__tmp37882
               (cons (cons 'admission
                           |gerbil-ascent/program/scheme-admit[1]#_g37883_|)
                     (cons (cons 'diagnostic
                                 |gerbil-ascent/program/scheme-admit[1]#_g37884_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37696 __tmp37882 '17 '#f '#f))
        (let ((__tmp37885
               (cons (cons 'admission
                           |gerbil-ascent/program/scheme-admit[1]#_g37886_|)
                     (cons (cons 'diagnostic
                                 |gerbil-ascent/program/scheme-admit[1]#_g37887_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37696 __tmp37885 '18 '#f '#f))
        (let ((__tmp37888
               (cons (cons 'admission
                           |gerbil-ascent/program/scheme-admit[1]#_g37889_|)
                     (cons (cons 'diagnostic
                                 |gerbil-ascent/program/scheme-admit[1]#_g37890_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37696 __tmp37888 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37696 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37696 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37696 '() '21 '#f '#f))
        __obj37696))))
