prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/program

(begin
  (declare-type
   gerbil-ascent/program/scheme-snapshot#relational-copy-term
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/scheme-snapshot)))
  (declare-type
   gerbil-ascent/program/scheme-snapshot#relational-copy-atom
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/scheme-snapshot)))
  (declare-type
   gerbil-ascent/program/scheme-snapshot#relational-copy-clause
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/scheme-snapshot)))
  (declare-type
   gerbil-ascent/program/scheme-snapshot#relational-copy-rule
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/scheme-snapshot)))
  (declare-type
   gerbil-ascent/program/scheme-snapshot#relational-snapshot-program
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/scheme-snapshot))))
