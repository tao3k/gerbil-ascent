(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/storage[1]#_g35606_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35608_|
    (##structure
     gx#syntax-quote::t
     'make-storage-state-owner
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35610_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35612_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35613_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner-phase
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35615_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35616_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner-phase-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35618_|
    (##structure
     gx#syntax-quote::t
     '&storage-state-owner-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35619_|
    (##structure
     gx#syntax-quote::t
     '&storage-state-owner-phase
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35621_|
    (##structure
     gx#syntax-quote::t
     '&storage-state-owner-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35622_|
    (##structure
     gx#syntax-quote::t
     '&storage-state-owner-phase-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[:0:]#storage-state-owner|
    (let ((__obj35556
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj35556
         'gerbil-ascent/table/storage#storage-state-owner::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj35556
         'storage-state-owner
         '3
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35556 '(value phase) '6 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35556 '(value phase) '8 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35556 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35556 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35556 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35556 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35556 '#f '13 '#f '#f))
      (let ((__tmp35605 |gerbil-ascent/table/storage[1]#_g35606_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35556 __tmp35605 '4 '#f '#f))
      (let ((__tmp35607 |gerbil-ascent/table/storage[1]#_g35608_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35556 __tmp35607 '14 '#f '#f))
      (let ((__tmp35609 |gerbil-ascent/table/storage[1]#_g35610_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35556 __tmp35609 '15 '#f '#f))
      (let ((__tmp35611
             (cons (cons 'value |gerbil-ascent/table/storage[1]#_g35612_|)
                   (cons (cons 'phase
                               |gerbil-ascent/table/storage[1]#_g35613_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35556 __tmp35611 '16 '#f '#f))
      (let ((__tmp35614
             (cons (cons 'value |gerbil-ascent/table/storage[1]#_g35615_|)
                   (cons (cons 'phase
                               |gerbil-ascent/table/storage[1]#_g35616_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35556 __tmp35614 '17 '#f '#f))
      (let ((__tmp35617
             (cons (cons 'value |gerbil-ascent/table/storage[1]#_g35618_|)
                   (cons (cons 'phase
                               |gerbil-ascent/table/storage[1]#_g35619_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35556 __tmp35617 '18 '#f '#f))
      (let ((__tmp35620
             (cons (cons 'value |gerbil-ascent/table/storage[1]#_g35621_|)
                   (cons (cons 'phase
                               |gerbil-ascent/table/storage[1]#_g35622_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35556 __tmp35620 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35556 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35556 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35556 '() '21 '#f '#f))
      __obj35556)))
