(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/feedback::timestamp 1791693098)
  (begin
    (define gerbil-ascent/candidate/feedback#reasoning-feedback::t
      (let ((__tmp34476 (list))
            (__tmp34475
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reasoning-feedback
         __tmp34476
         '(status reason missing extra)
         __tmp34475
         '#f)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/feedback#reasoning-feedback::t)))
    (define gerbil-ascent/candidate/feedback#make-reasoning-feedback
      (lambda _%$args30604%_
        (apply make-instance
               gerbil-ascent/candidate/feedback#reasoning-feedback::t
               _%$args30604%_)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'status)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-reason
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reason)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-missing
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'missing)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-extra
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'extra)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'status)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-reason-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reason)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-missing-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'missing)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-extra-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'extra)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'status)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-reason
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reason)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-missing
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'missing)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-extra
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'extra)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'status)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-reason-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reason)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-missing-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'missing)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-extra-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'extra)))
    (define gerbil-ascent/candidate/feedback#refuse-feedback
      (lambda (_%reason30602%_)
        (let ()
          (declare (not safe))
          (##structure
           gerbil-ascent/candidate/feedback#reasoning-feedback::t
           'inconclusive
           _%reason30602%_
           '()
           '()))))
    (define gerbil-ascent/candidate/feedback#receipt-feedback-reason
      (lambda (_%snapshot30595%_ _%candidate30596%_ _%receipt30597%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
               _%receipt30597%_
               _%snapshot30595%_
               _%candidate30596%_))
            (if (eq? (##structure-ref
                      _%receipt30597%_
                      '1
                      gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                      '#f)
                     'complete)
                '#f
                (##structure-ref
                 _%receipt30597%_
                 '1
                 gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                 '#f))
            'unbound)))
    (define gerbil-ascent/candidate/feedback#reasoning-compare-rows
      (lambda (_%snapshot30588%_
               _%candidate30589%_
               _%receipt30590%_
               _%expected30591%_)
        (let ((_%reason30593%_
               (gerbil-ascent/candidate/feedback#receipt-feedback-reason
                _%snapshot30588%_
                _%candidate30589%_
                _%receipt30590%_)))
          (if _%reason30593%_
              (gerbil-ascent/candidate/feedback#refuse-feedback
               _%reason30593%_)
              (gerbil-ascent/candidate/feedback#compare-qualified-rows
               _%receipt30590%_
               _%expected30591%_)))))
    (define gerbil-ascent/candidate/feedback#reasoning-compare-attempts
      (lambda (_%snapshot30575%_
               _%candidate30576%_
               _%receipt30577%_
               _%reference-candidate30578%_
               _%reference-receipt30579%_)
        (let ((_%reason30581%_
               (gerbil-ascent/candidate/feedback#receipt-feedback-reason
                _%snapshot30575%_
                _%candidate30576%_
                _%receipt30577%_)))
          (if _%reason30581%_
              (gerbil-ascent/candidate/feedback#refuse-feedback
               _%reason30581%_)
              (if (let ()
                    (declare (not safe))
                    (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                     _%reference-receipt30579%_
                     _%snapshot30575%_
                     _%reference-candidate30578%_))
                  (if (eq? (##structure-ref
                            _%reference-receipt30579%_
                            '1
                            gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                            '#f)
                           'complete)
                      (if (equal? (##structure-ref
                                   _%receipt30577%_
                                   '6
                                   gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                   '#f)
                                  (##structure-ref
                                   _%reference-receipt30579%_
                                   '6
                                   gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                   '#f))
                          (gerbil-ascent/candidate/feedback#compare-qualified-rows
                           _%receipt30577%_
                           (##structure-ref
                            _%reference-receipt30579%_
                            '7
                            gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                            '#f))
                          (gerbil-ascent/candidate/feedback#refuse-feedback
                           'query-mismatch))
                      (gerbil-ascent/candidate/feedback#refuse-feedback
                       'reference-incomplete))
                  (gerbil-ascent/candidate/feedback#refuse-feedback
                   'reference-unbound))))))
    (define gerbil-ascent/candidate/feedback#compare-qualified-rows
      (lambda (_%receipt30545%_ _%expected30546%_)
        (if (and (let ()
                   (declare (not safe))
                   (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                    _%expected30546%_
                    '16384
                    '128))
                 (list? _%expected30546%_)
                 (let* ((_%arity30548%_
                         (length (cdr (##structure-ref
                                       _%receipt30545%_
                                       '6
                                       gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                       '#f))))
                        (__tmp34477
                         (lambda (_%row30550%_)
                           (and (list? _%row30550%_)
                                (= (let ()
                                     (declare (not safe))
                                     (##length _%row30550%_))
                                   _%arity30548%_)
                                (let ()
                                  (declare (not safe))
                                  (andmap__0
                                   gerbil-ascent/candidate/program#scalar?
                                   _%row30550%_))))))
                   (declare (not safe))
                   (andmap__0 __tmp34477 _%expected30546%_)))
            (let ((_%actual-set30554%_
                   (let ()
                     (declare (not safe))
                     (make-hash-table__%
                      '#f
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value)))
                  (_%expected-set30555%_
                   (let ()
                     (declare (not safe))
                     (make-hash-table__%
                      '#f
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value)))
                  (_%actual30556%_ '())
                  (_%wanted30557%_ '()))
              (letrec ((_%insert30559%_
                        (lambda (_%rows30568%_ _%table30569%_)
                          (let ((_%unique30571%_ '()))
                            (for-each
                             (lambda (_%row30573%_)
                               (if (let ()
                                     (declare (not safe))
                                     (hash-get _%table30569%_ _%row30573%_))
                                   '#!void
                                   (begin
                                     (let ()
                                       (declare (not safe))
                                       (hash-put!
                                        _%table30569%_
                                        _%row30573%_
                                        '#t))
                                     (set! _%unique30571%_
                                           (cons _%row30573%_
                                                 _%unique30571%_)))))
                             _%rows30568%_)
                            (let ()
                              (declare (not safe))
                              (##reverse _%unique30571%_))))))
                (set! _%actual30556%_
                      (_%insert30559%_
                       (##structure-ref
                        _%receipt30545%_
                        '7
                        gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                        '#f)
                       _%actual-set30554%_))
                (set! _%wanted30557%_
                      (_%insert30559%_
                       _%expected30546%_
                       _%expected-set30555%_))
                (let ((_%missing30565%_
                       (let ((__tmp34478
                              (lambda (_%row30561%_)
                                (not (let ()
                                       (declare (not safe))
                                       (__hash-get
                                        _%actual-set30554%_
                                        _%row30561%_))))))
                         (declare (not safe))
                         (##filter __tmp34478 _%wanted30557%_)))
                      (_%extra30566%_
                       (let ((__tmp34479
                              (lambda (_%row30563%_)
                                (not (let ()
                                       (declare (not safe))
                                       (__hash-get
                                        _%expected-set30555%_
                                        _%row30563%_))))))
                         (declare (not safe))
                         (##filter __tmp34479 _%actual30556%_))))
                  (let ((__tmp34482
                         (if (and (null? _%missing30565%_)
                                  (null? _%extra30566%_))
                             'match
                             'mismatch))
                        (__tmp34481
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/datum#candidate-copy-pairs
                            _%missing30565%_)))
                        (__tmp34480
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/datum#candidate-copy-pairs
                            _%extra30566%_))))
                    (declare (not safe))
                    (##structure
                     gerbil-ascent/candidate/feedback#reasoning-feedback::t
                     __tmp34482
                     '#f
                     __tmp34481
                     __tmp34480)))))
            (gerbil-ascent/candidate/feedback#refuse-feedback
             'invalid-reference))))))
