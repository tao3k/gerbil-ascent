(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/grounding-plan::timestamp 1791687886)
  (begin
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule::t
      (let ((__tmp37031 (list))
            (__tmp37030
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'grounding-rule
         __tmp37031
         '(name head body label)
         __tmp37030
         '#f)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t)))
    (define gerbil-ascent/candidate/grounding-plan#make-grounding-rule
      (lambda _%$args27637%_
        (apply make-instance
               gerbil-ascent/candidate/grounding-plan#grounding-rule::t
               _%$args27637%_)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule-name
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'name)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule-head
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'head)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule-body
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'body)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule-label
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'label)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule-name-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'name)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule-head-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'head)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule-body-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'body)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule-label-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'label)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-rule-name
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'name)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-rule-head
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'head)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-rule-body
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'body)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-rule-label
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'label)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-rule-name-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'name)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-rule-head-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'head)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-rule-body-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'body)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-rule-label-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'label)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-clause::t
      (let ((__tmp37033 (list))
            (__tmp37032
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/grounding-plan#grounding-clause::t
         'grounding-clause
         __tmp37033
         '(relation apply)
         __tmp37032
         '#f)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-clause?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/grounding-plan#grounding-clause::t)))
    (define gerbil-ascent/candidate/grounding-plan#make-grounding-clause
      (lambda _%$args27634%_
        (apply make-instance
               gerbil-ascent/candidate/grounding-plan#grounding-clause::t
               _%$args27634%_)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-clause-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-clause::t
         'relation)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-clause-apply
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-clause::t
         'apply)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-clause-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-clause::t
         'relation)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-clause-apply-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-clause::t
         'apply)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-clause-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-clause::t
         'relation)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-clause-apply
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-clause::t
         'apply)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-clause-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-clause::t
         'relation)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-clause-apply-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-clause::t
         'apply)))
    (define gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
      (lambda (_%atom27608%_)
        (let ((__tmp37036
               (lambda (_%term27610%_ _%next27611%_)
                 (if (eq? _%term27610%_ '?_)
                     (lambda (_%row27614%_ _%bindings27615%_)
                       (_%next27611%_ (cdr _%row27614%_) _%bindings27615%_))
                     (if (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/program#candidate-variable?
                            _%term27610%_))
                         (lambda (_%row27618%_ _%bindings27619%_)
                           (let ((_%$e27621%_
                                  (assq _%term27610%_ _%bindings27619%_)))
                             (if _%$e27621%_
                                 (if (equal? (cdr _%$e27621%_)
                                             (car _%row27618%_))
                                     (_%next27611%_
                                      (cdr _%row27618%_)
                                      _%bindings27619%_)
                                     '#f)
                                 (_%next27611%_
                                  (cdr _%row27618%_)
                                  (cons (cons _%term27610%_ (car _%row27618%_))
                                        _%bindings27619%_)))))
                         (lambda (_%row27628%_ _%bindings27629%_)
                           (if (equal? _%term27610%_ (car _%row27628%_))
                               (_%next27611%_
                                (cdr _%row27628%_)
                                _%bindings27629%_)
                               '#f))))))
              (__tmp37035
               (lambda (_%_27631%_ _%bindings27632%_) _%bindings27632%_))
              (__tmp37034 (cdr _%atom27608%_)))
          (declare (not safe))
          (foldr__0 __tmp37036 __tmp37035 __tmp37034))))
    (define gerbil-ascent/candidate/grounding-plan#prepare-grounding-rule
      (lambda (_%rule27569%_)
        (let* ((_%$%rule2757027578%_ _%rule27569%_)
               (_%$%E2757227581%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%rule2757027578%_
                           '(#(head body label))))
                  '#!void))
               (_%$%K2757327590%_
                (lambda (_%label27584%_ _%body27585%_ _%head27586%_)
                  (let ((__tmp37043 (car _%head27586%_))
                        (__tmp37042
                         (gerbil-ascent/candidate/grounding-plan#prepare-grounding-head
                          _%head27586%_))
                        (__tmp37037
                         (map (lambda (_%clause27588%_)
                                (if (let ((__tmp37038 (car _%clause27588%_)))
                                      (declare (not safe))
                                      (##memq __tmp37038 '(where compute)))
                                    (let ((__tmp37039
                                           (gerbil-ascent/candidate/grounding-plan#prepare-grounding-fixed
                                            _%clause27588%_)))
                                      (declare (not safe))
                                      (##structure
                                       gerbil-ascent/candidate/grounding-plan#grounding-clause::t
                                       '#f
                                       __tmp37039))
                                    (let ((__tmp37041 (car _%clause27588%_))
                                          (__tmp37040
                                           (gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
                                            _%clause27588%_)))
                                      (declare (not safe))
                                      (##structure
                                       gerbil-ascent/candidate/grounding-plan#grounding-clause::t
                                       __tmp37041
                                       __tmp37040))))
                              _%body27585%_)))
                    (declare (not safe))
                    (##structure
                     gerbil-ascent/candidate/grounding-plan#grounding-rule::t
                     __tmp37043
                     __tmp37042
                     __tmp37037
                     _%label27584%_)))))
          (if (vector? _%$%rule2757027578%_)
              (if (let ((__tmp37044
                         (let ()
                           (declare (not safe))
                           (##vector-length _%$%rule2757027578%_))))
                    (declare (not safe))
                    (##fx= __tmp37044 '3))
                  (let* ((_%$%e2757427593%_
                          (let ()
                            (declare (not safe))
                            (##vector-ref _%$%rule2757027578%_ '0)))
                         (_%head27596%_ _%$%e2757427593%_)
                         (_%$%e2757527598%_
                          (let ()
                            (declare (not safe))
                            (##vector-ref _%$%rule2757027578%_ '1)))
                         (_%body27601%_ _%$%e2757527598%_)
                         (_%$%e2757627603%_
                          (let ()
                            (declare (not safe))
                            (##vector-ref _%$%rule2757027578%_ '2)))
                         (_%label27606%_ _%$%e2757627603%_))
                    (_%$%K2757327590%_
                     _%label27606%_
                     _%body27601%_
                     _%head27596%_))
                  (_%$%E2757227581%_))
              (_%$%E2757227581%_)))))
    (define gerbil-ascent/candidate/grounding-plan#prepare-grounding-head
      (lambda (_%head27555%_)
        (let ((_%getters27563%_
               (map (lambda (_%term27557%_)
                      (if (let ()
                            (declare (not safe))
                            (gerbil-ascent/candidate/program#candidate-variable?
                             _%term27557%_))
                          (lambda (_%bindings27559%_)
                            (cdr (assq _%term27557%_ _%bindings27559%_)))
                          (lambda (_%_27561%_) _%term27557%_)))
                    (cdr _%head27555%_))))
          (lambda (_%bindings27565%_)
            (let ((__tmp37045
                   (lambda (_%get27567%_) (_%get27567%_ _%bindings27565%_))))
              (declare (not safe))
              (##map __tmp37045 _%getters27563%_))))))
    (define gerbil-ascent/candidate/grounding-plan#prepare-grounding-fixed
      (lambda (_%clause27315%_)
        (let* ((_%$%clause2731627368%_ _%clause27315%_)
               (_%$%else2732127378%_
                (lambda ()
                  (lambda (_%bindings27376%_)
                    (let ()
                      (declare (not safe))
                      (gerbil-ascent/candidate/funs#candidate-fixed-clause
                       _%clause27315%_
                       _%bindings27376%_))))))
          (let ((_%$%K2735827530%_
                 (lambda (_%name27520%_)
                   (lambda (_%bindings27522%_)
                     (let ((_%$e27524%_
                            (assq _%name27520%_ _%bindings27522%_)))
                       (if _%$e27524%_
                           (if (exact-integer? (cdr _%$e27524%_))
                               (if (even? (cdr _%$e27524%_))
                                   _%bindings27522%_
                                   '#f)
                               '#f)
                           '#f)))))
                (_%$%K2734727485%_
                 (lambda (_%right27477%_ _%left27478%_)
                   (lambda (_%bindings27480%_)
                     (let ((_%a27482%_ (assq _%left27478%_ _%bindings27480%_))
                           (_%b27483%_
                            (assq _%right27477%_ _%bindings27480%_)))
                       (if _%a27482%_
                           (if _%b27483%_
                               (if (exact-integer? (cdr _%a27482%_))
                                   (if (exact-integer? (cdr _%b27483%_))
                                       (if (< (cdr _%a27482%_)
                                              (cdr _%b27483%_))
                                           _%bindings27480%_
                                           '#f)
                                       '#f)
                                   '#f)
                               '#f)
                           '#f)))))
                (_%$%K2733627441%_
                 (lambda (_%name27434%_ _%output27435%_)
                   (lambda (_%bindings27437%_)
                     (let ((_%input27439%_
                            (assq _%name27434%_ _%bindings27437%_)))
                       (if _%input27439%_
                           (if (assq _%output27435%_ _%bindings27437%_)
                               '#f
                               (cons (cons _%output27435%_
                                           (cdr _%input27439%_))
                                     _%bindings27437%_))
                           '#f)))))
                (_%$%K2732327391%_
                 (lambda (_%right27382%_ _%left27383%_ _%output27384%_)
                   (lambda (_%bindings27386%_)
                     (let ((_%a27388%_ (assq _%left27383%_ _%bindings27386%_))
                           (_%b27389%_
                            (assq _%right27382%_ _%bindings27386%_)))
                       (if _%a27388%_
                           (if _%b27389%_
                               (if (assq _%output27384%_ _%bindings27386%_)
                                   '#f
                                   (if (exact-integer? (cdr _%a27388%_))
                                       (if (exact-integer? (cdr _%b27389%_))
                                           (cons (cons _%output27384%_
                                                       (+ (cdr _%a27388%_)
                                                          (cdr _%b27389%_)))
                                                 _%bindings27386%_)
                                           '#f)
                                       '#f))
                               '#f)
                           '#f))))))
            (if (pair? _%$%clause2731627368%_)
                (let ((_%$%tl2736027535%_
                       (let ()
                         (declare (not safe))
                         (##cdr _%$%clause2731627368%_)))
                      (_%$%hd2735927533%_
                       (let ()
                         (declare (not safe))
                         (##car _%$%clause2731627368%_))))
                  (if (let ()
                        (declare (not safe))
                        (##eq? _%$%hd2735927533%_ 'where))
                      (if (pair? _%$%tl2736027535%_)
                          (let ((_%$%tl2736227540%_
                                 (let ()
                                   (declare (not safe))
                                   (##cdr _%$%tl2736027535%_)))
                                (_%$%hd2736127538%_
                                 (let ()
                                   (declare (not safe))
                                   (##car _%$%tl2736027535%_))))
                            (if (pair? _%$%hd2736127538%_)
                                (let ((_%$%tl2736427545%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%hd2736127538%_)))
                                      (_%$%hd2736327543%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%$%hd2736127538%_))))
                                  (if (let ()
                                        (declare (not safe))
                                        (##eq? _%$%hd2736327543%_ 'even?))
                                      (if (pair? _%$%tl2736427545%_)
                                          (let ((_%$%tl2736627550%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%tl2736427545%_)))
                                                (_%$%hd2736527548%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%tl2736427545%_))))
                                            (if (null? _%$%tl2736627550%_)
                                                (if (null? _%$%tl2736227540%_)
                                                    (let ((_%name27553%_
                                                           _%$%hd2736527548%_))
                                                      (_%$%K2735827530%_
                                                       _%name27553%_))
                                                    (_%$%else2732127378%_))
                                                (_%$%else2732127378%_)))
                                          (_%$%else2732127378%_))
                                      (if (let ()
                                            (declare (not safe))
                                            (##eq? _%$%hd2736327543%_ '<))
                                          (if (pair? _%$%tl2736427545%_)
                                              (let ((_%$%tl2735527505%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%tl2736427545%_)))
                                                    (_%$%hd2735427503%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%tl2736427545%_))))
                                                (if (pair? _%$%tl2735527505%_)
                                                    (let ((_%$%tl2735727512%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%tl2735527505%_)))
                                                          (_%$%hd2735627510%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%tl2735527505%_))))
                                                      (if (null? _%$%tl2735727512%_)
                                                          (if (null? _%$%tl2736227540%_)
                                                              (let ((_%left27508%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             _%$%hd2735427503%_)
                            (_%right27515%_ _%$%hd2735627510%_))
                        (_%$%K2734727485%_ _%right27515%_ _%left27508%_))
                      (_%$%else2732127378%_))
                  (_%$%else2732127378%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%else2732127378%_)))
                                              (_%$%else2732127378%_))
                                          (_%$%else2732127378%_))))
                                (_%$%else2732127378%_)))
                          (_%$%else2732127378%_))
                      (if (let ()
                            (declare (not safe))
                            (##eq? _%$%hd2735927533%_ 'compute))
                          (if (pair? _%$%tl2736027535%_)
                              (let ((_%$%tl2734027451%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%tl2736027535%_)))
                                    (_%$%hd2733927449%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%tl2736027535%_))))
                                (if (pair? _%$%tl2734027451%_)
                                    (let ((_%$%tl2734227458%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%tl2734027451%_)))
                                          (_%$%hd2734127456%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%tl2734027451%_))))
                                      (if (pair? _%$%hd2734127456%_)
                                          (let ((_%$%tl2734427463%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%hd2734127456%_)))
                                                (_%$%hd2734327461%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%hd2734127456%_))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (##eq? _%$%hd2734327461%_
                                                         'identity))
                                                (if (pair? _%$%tl2734427463%_)
                                                    (let ((_%$%tl2734627468%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%tl2734427463%_)))
                                                          (_%$%hd2734527466%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%tl2734427463%_))))
                                                      (if (null? _%$%tl2734627468%_)
                                                          (if (null? _%$%tl2734227458%_)
                                                              (let ((_%output27454%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             _%$%hd2733927449%_)
                            (_%name27471%_ _%$%hd2734527466%_))
                        (_%$%K2733627441%_ _%name27471%_ _%output27454%_))
                      (_%$%else2732127378%_))
                  (_%$%else2732127378%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%else2732127378%_))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (##eq? _%$%hd2734327461%_
                                                             '+))
                                                    (if (pair? _%$%tl2734427463%_)
                                                        (let ((_%$%tl2733327418%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (##cdr _%$%tl2734427463%_)))
                      (_%$%hd2733227416%_
                       (let ()
                         (declare (not safe))
                         (##car _%$%tl2734427463%_))))
                  (if (pair? _%$%tl2733327418%_)
                      (let ((_%$%tl2733527425%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%tl2733327418%_)))
                            (_%$%hd2733427423%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%tl2733327418%_))))
                        (if (null? _%$%tl2733527425%_)
                            (if (null? _%$%tl2734227458%_)
                                (let ((_%output27404%_ _%$%hd2733927449%_)
                                      (_%left27421%_ _%$%hd2733227416%_)
                                      (_%right27428%_ _%$%hd2733427423%_))
                                  (_%$%K2732327391%_
                                   _%right27428%_
                                   _%left27421%_
                                   _%output27404%_))
                                (_%$%else2732127378%_))
                            (_%$%else2732127378%_)))
                      (_%$%else2732127378%_)))
                (_%$%else2732127378%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%else2732127378%_))))
                                          (_%$%else2732127378%_)))
                                    (_%$%else2732127378%_)))
                              (_%$%else2732127378%_))
                          (_%$%else2732127378%_))))
                (_%$%else2732127378%_))))))))
