(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/feedback[1]#_g34489_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34491_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-feedback
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34493_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34495_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34496_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-reason
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34497_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-missing
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34498_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-extra
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34500_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34501_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-reason-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34502_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-missing-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34503_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-extra-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34505_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34506_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-reason
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34507_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-missing
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34508_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-extra
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34510_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34511_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-reason-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34512_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-missing-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34513_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-extra-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[:0:]#reasoning-feedback|
    (let ((__obj34417
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34417
         'gerbil-ascent/candidate/feedback#reasoning-feedback::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34417 'reasoning-feedback '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34417
         '(status reason missing extra)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34417
         '(status reason missing extra)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34417 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34417 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34417 '#t '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34417 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34417 '#f '13 '#f '#f))
      (let ((__tmp34488 |gerbil-ascent/candidate/feedback[1]#_g34489_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34417 __tmp34488 '4 '#f '#f))
      (let ((__tmp34490 |gerbil-ascent/candidate/feedback[1]#_g34491_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34417 __tmp34490 '14 '#f '#f))
      (let ((__tmp34492 |gerbil-ascent/candidate/feedback[1]#_g34493_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34417 __tmp34492 '15 '#f '#f))
      (let ((__tmp34494
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g34495_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g34496_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g34497_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g34498_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34417 __tmp34494 '16 '#f '#f))
      (let ((__tmp34499
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g34500_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g34501_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g34502_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g34503_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34417 __tmp34499 '17 '#f '#f))
      (let ((__tmp34504
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g34505_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g34506_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g34507_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g34508_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34417 __tmp34504 '18 '#f '#f))
      (let ((__tmp34509
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g34510_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g34511_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g34512_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g34513_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34417 __tmp34509 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34417 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34417 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34417 '() '21 '#f '#f))
      __obj34417)))
