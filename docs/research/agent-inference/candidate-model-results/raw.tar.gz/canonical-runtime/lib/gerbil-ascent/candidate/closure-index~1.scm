(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/closure-index[1]#_g34182_|
    (##structure
     gx#syntax-quote::t
     'closure-relation::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34184_|
    (##structure
     gx#syntax-quote::t
     'make-closure-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34186_|
    (##structure
     gx#syntax-quote::t
     'closure-relation?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34188_|
    (##structure
     gx#syntax-quote::t
     'closure-relation-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34189_|
    (##structure
     gx#syntax-quote::t
     'closure-relation-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34190_|
    (##structure
     gx#syntax-quote::t
     'closure-relation-source
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34192_|
    (##structure
     gx#syntax-quote::t
     'closure-relation-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34193_|
    (##structure
     gx#syntax-quote::t
     'closure-relation-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34194_|
    (##structure
     gx#syntax-quote::t
     'closure-relation-source-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34196_|
    (##structure
     gx#syntax-quote::t
     '&closure-relation-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34197_|
    (##structure
     gx#syntax-quote::t
     '&closure-relation-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34198_|
    (##structure
     gx#syntax-quote::t
     '&closure-relation-source
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34200_|
    (##structure
     gx#syntax-quote::t
     '&closure-relation-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34201_|
    (##structure
     gx#syntax-quote::t
     '&closure-relation-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34202_|
    (##structure
     gx#syntax-quote::t
     '&closure-relation-source-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[:0:]#closure-relation|
    (let ((__obj34032
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34032
         'gerbil-ascent/candidate/closure-index#closure-relation::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34032 'closure-relation '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34032
         '(rows members source)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34032
         '(rows members source)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34032 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34032 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34032 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34032 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34032 '#f '13 '#f '#f))
      (let ((__tmp34181 |gerbil-ascent/candidate/closure-index[1]#_g34182_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34032 __tmp34181 '4 '#f '#f))
      (let ((__tmp34183 |gerbil-ascent/candidate/closure-index[1]#_g34184_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34032 __tmp34183 '14 '#f '#f))
      (let ((__tmp34185 |gerbil-ascent/candidate/closure-index[1]#_g34186_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34032 __tmp34185 '15 '#f '#f))
      (let ((__tmp34187
             (cons (cons 'rows
                         |gerbil-ascent/candidate/closure-index[1]#_g34188_|)
                   (cons (cons 'members
                               |gerbil-ascent/candidate/closure-index[1]#_g34189_|)
                         (cons (cons 'source
                                     |gerbil-ascent/candidate/closure-index[1]#_g34190_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34032 __tmp34187 '16 '#f '#f))
      (let ((__tmp34191
             (cons (cons 'rows
                         |gerbil-ascent/candidate/closure-index[1]#_g34192_|)
                   (cons (cons 'members
                               |gerbil-ascent/candidate/closure-index[1]#_g34193_|)
                         (cons (cons 'source
                                     |gerbil-ascent/candidate/closure-index[1]#_g34194_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34032 __tmp34191 '17 '#f '#f))
      (let ((__tmp34195
             (cons (cons 'rows
                         |gerbil-ascent/candidate/closure-index[1]#_g34196_|)
                   (cons (cons 'members
                               |gerbil-ascent/candidate/closure-index[1]#_g34197_|)
                         (cons (cons 'source
                                     |gerbil-ascent/candidate/closure-index[1]#_g34198_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34032 __tmp34195 '18 '#f '#f))
      (let ((__tmp34199
             (cons (cons 'rows
                         |gerbil-ascent/candidate/closure-index[1]#_g34200_|)
                   (cons (cons 'members
                               |gerbil-ascent/candidate/closure-index[1]#_g34201_|)
                         (cons (cons 'source
                                     |gerbil-ascent/candidate/closure-index[1]#_g34202_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34032 __tmp34199 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34032 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34032 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34032 '() '21 '#f '#f))
      __obj34032)))
