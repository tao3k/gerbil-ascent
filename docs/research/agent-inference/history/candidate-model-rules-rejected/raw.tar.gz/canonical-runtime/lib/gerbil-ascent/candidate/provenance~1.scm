(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/provenance[1]#_g37411_|
    (##structure
     gx#syntax-quote::t
     'positive-proof::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37413_|
    (##structure
     gx#syntax-quote::t
     'make-positive-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37415_|
    (##structure
     gx#syntax-quote::t
     'positive-proof?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37417_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37418_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37419_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37420_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37421_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37422_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37423_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37424_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37425_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37427_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37428_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37429_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37430_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37431_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37432_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37433_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37434_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37435_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37437_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37438_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37439_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37440_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37441_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37442_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37443_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37444_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37445_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37447_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37448_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37449_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37450_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37451_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37452_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37453_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37454_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37455_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37457_|
    (##structure
     gx#syntax-quote::t
     'proof-node::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37459_|
    (##structure
     gx#syntax-quote::t
     'make-proof-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37461_|
    (##structure
     gx#syntax-quote::t
     'proof-node?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37463_|
    (##structure
     gx#syntax-quote::t
     'proof-node-id
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37464_|
    (##structure
     gx#syntax-quote::t
     'proof-node-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37465_|
    (##structure
     gx#syntax-quote::t
     'proof-node-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37466_|
    (##structure
     gx#syntax-quote::t
     'proof-node-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37467_|
    (##structure
     gx#syntax-quote::t
     'proof-node-label
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37468_|
    (##structure
     gx#syntax-quote::t
     'proof-node-inputs
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37470_|
    (##structure
     gx#syntax-quote::t
     'proof-node-id-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37471_|
    (##structure
     gx#syntax-quote::t
     'proof-node-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37472_|
    (##structure
     gx#syntax-quote::t
     'proof-node-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37473_|
    (##structure
     gx#syntax-quote::t
     'proof-node-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37474_|
    (##structure
     gx#syntax-quote::t
     'proof-node-label-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37475_|
    (##structure
     gx#syntax-quote::t
     'proof-node-inputs-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37477_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-id
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37478_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37479_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37480_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37481_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-label
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37482_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-inputs
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37484_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-id-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37485_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37486_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37487_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37488_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-label-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37489_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-inputs-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37491_|
    (##structure
     gx#syntax-quote::t
     'proof-relation::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37493_|
    (##structure
     gx#syntax-quote::t
     'make-proof-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37495_|
    (##structure
     gx#syntax-quote::t
     'proof-relation?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37497_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37498_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-tail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37499_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37501_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37502_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-tail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37503_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37505_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37506_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-tail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37507_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37509_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37510_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-tail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37511_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/provenance[:0:]#positive-proof|
      (let ((__obj37203
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37203
           'gerbil-ascent/candidate/provenance#positive-proof::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37203 'positive-proof '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37203
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    work-budget
                    nodes
                    roots)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37203
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    work-budget
                    nodes
                    roots)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37203 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37203 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37203 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37203 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37203 '#f '13 '#f '#f))
        (let ((__tmp37410 |gerbil-ascent/candidate/provenance[1]#_g37411_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37203 __tmp37410 '4 '#f '#f))
        (let ((__tmp37412 |gerbil-ascent/candidate/provenance[1]#_g37413_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37203 __tmp37412 '14 '#f '#f))
        (let ((__tmp37414 |gerbil-ascent/candidate/provenance[1]#_g37415_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37203 __tmp37414 '15 '#f '#f))
        (let ((__tmp37416
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g37417_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g37418_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g37419_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g37420_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g37421_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g37422_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g37423_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g37424_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g37425_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37203 __tmp37416 '16 '#f '#f))
        (let ((__tmp37426
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g37427_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g37428_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g37429_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g37430_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g37431_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g37432_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g37433_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g37434_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g37435_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37203 __tmp37426 '17 '#f '#f))
        (let ((__tmp37436
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g37437_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g37438_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g37439_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g37440_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g37441_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g37442_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g37443_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g37444_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g37445_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37203 __tmp37436 '18 '#f '#f))
        (let ((__tmp37446
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g37447_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g37448_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g37449_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g37450_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g37451_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g37452_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g37453_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g37454_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g37455_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37203 __tmp37446 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37203 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37203 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37203 '() '21 '#f '#f))
        __obj37203))
    (define |gerbil-ascent/candidate/provenance[:0:]#proof-node|
      (let ((__obj37204
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37204
           'gerbil-ascent/candidate/provenance#proof-node::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37204 'proof-node '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37204
           '(id kind relation row label inputs)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37204
           '(id kind relation row label inputs)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37204 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37204 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37204 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37204 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37204 '#f '13 '#f '#f))
        (let ((__tmp37456 |gerbil-ascent/candidate/provenance[1]#_g37457_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37204 __tmp37456 '4 '#f '#f))
        (let ((__tmp37458 |gerbil-ascent/candidate/provenance[1]#_g37459_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37204 __tmp37458 '14 '#f '#f))
        (let ((__tmp37460 |gerbil-ascent/candidate/provenance[1]#_g37461_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37204 __tmp37460 '15 '#f '#f))
        (let ((__tmp37462
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g37463_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g37464_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g37465_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g37466_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g37467_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g37468_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37204 __tmp37462 '16 '#f '#f))
        (let ((__tmp37469
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g37470_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g37471_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g37472_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g37473_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g37474_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g37475_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37204 __tmp37469 '17 '#f '#f))
        (let ((__tmp37476
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g37477_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g37478_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g37479_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g37480_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g37481_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g37482_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37204 __tmp37476 '18 '#f '#f))
        (let ((__tmp37483
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g37484_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g37485_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g37486_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g37487_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g37488_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g37489_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37204 __tmp37483 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37204 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37204 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37204 '() '21 '#f '#f))
        __obj37204))
    (define |gerbil-ascent/candidate/provenance[:0:]#proof-relation|
      (let ((__obj37205
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37205
           'gerbil-ascent/candidate/provenance#proof-relation::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37205 'proof-relation '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37205
           '(nodes tail members)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37205
           '(nodes tail members)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37205 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37205 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37205 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37205 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37205 '#f '13 '#f '#f))
        (let ((__tmp37490 |gerbil-ascent/candidate/provenance[1]#_g37491_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37205 __tmp37490 '4 '#f '#f))
        (let ((__tmp37492 |gerbil-ascent/candidate/provenance[1]#_g37493_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37205 __tmp37492 '14 '#f '#f))
        (let ((__tmp37494 |gerbil-ascent/candidate/provenance[1]#_g37495_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37205 __tmp37494 '15 '#f '#f))
        (let ((__tmp37496
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g37497_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g37498_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g37499_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37205 __tmp37496 '16 '#f '#f))
        (let ((__tmp37500
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g37501_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g37502_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g37503_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37205 __tmp37500 '17 '#f '#f))
        (let ((__tmp37504
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g37505_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g37506_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g37507_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37205 __tmp37504 '18 '#f '#f))
        (let ((__tmp37508
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g37509_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g37510_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g37511_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37205 __tmp37508 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37205 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37205 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37205 '() '21 '#f '#f))
        __obj37205))))
