(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/reasoning::timestamp 1791693098)
  (begin
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt::t
      (let ((__tmp34257 (list)) (__tmp34256 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'reasoning-receipt
         __tmp34257
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  query
                  rows
                  diagnostics
                  evidence
                  proof
                  nonmembership
                  stratified)
         __tmp34256
         '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t)))
    (define gerbil-ascent/candidate/reasoning#make-reasoning-receipt
      (lambda _%$args30541%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#reasoning-receipt::t
               _%$args30541%_)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-query
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'query)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-diagnostics
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'diagnostics)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-evidence
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-proof
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-nonmembership
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'nonmembership)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-stratified
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'stratified)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'query)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-diagnostics-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'diagnostics)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-evidence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-proof-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-nonmembership-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'nonmembership)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-stratified-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'stratified)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-query
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'query)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-diagnostics
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'diagnostics)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-evidence
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-proof
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-nonmembership
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'nonmembership)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-stratified
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'stratified)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'query)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-diagnostics-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'diagnostics)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-evidence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-proof-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-nonmembership-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'nonmembership)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-stratified-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'stratified)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence::t
      (let ((__tmp34259 (list)) (__tmp34258 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reasoning-evidence
         __tmp34259
         '(kind support reachable)
         __tmp34258
         '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t)))
    (define gerbil-ascent/candidate/reasoning#make-reasoning-evidence
      (lambda _%$args30538%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#reasoning-evidence::t
               _%$args30538%_)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'kind)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-support
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'support)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-reachable
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reachable)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'kind)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-support-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'support)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-reachable-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reachable)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'kind)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-support
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'support)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-reachable
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reachable)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'kind)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-support-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'support)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-reachable-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reachable)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
      (let ((__tmp34261 (list)) (__tmp34260 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'reasoning-stratified-evidence
         __tmp34261
         '(status finite proof work-budget)
         __tmp34260
         '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t)))
    (define gerbil-ascent/candidate/reasoning#make-reasoning-stratified-evidence
      (lambda _%$args30535%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
               _%$args30535%_)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-finite
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'finite)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-proof
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-finite-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'finite)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-proof-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-finite
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'finite)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-proof
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-finite-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'finite)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-proof-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/reasoning#copy-row
      (lambda (_%row30532%_ _%arity30533%_)
        (if (list? _%row30532%_)
            (if (= (let () (declare (not safe)) (##length _%row30532%_))
                   _%arity30533%_)
                (if (let ()
                      (declare (not safe))
                      (andmap__0
                       gerbil-ascent/candidate/program#scalar?
                       _%row30532%_))
                    (let () (declare (not safe)) (##map identity _%row30532%_))
                    '#f)
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/reasoning#digest-datum
      (lambda (_%datum30463%_)
        (let* ((_%bytes30483%_
                (let* ((_%bytes30467%_
                        (let ((__tmp34262
                               (call-with-output-string
                                '""
                                (lambda (_%port30465%_)
                                  (write _%datum30463%_ _%port30465%_)))))
                          (declare (not safe))
                          (##string->utf8 __tmp34262)))
                       (_%bytes30472%_ _%bytes30467%_))
                  (declare (not safe))
                  (std/crypto/digest#__sha256 _%bytes30472%_)))
               (_%start30486%_ '0)
               (_%end30489%_
                (let ()
                  (declare (not safe))
                  (##u8vector-length _%bytes30483%_)))
               (_%bytes30494%_ _%bytes30483%_))
          (if (and (let () (declare (not safe)) (##fx>= _%start30486%_ '0))
                   (let ((__tmp34263
                          (let ((__tmp34264
                                 (let ()
                                   (declare (not safe))
                                   (##u8vector-length _%bytes30494%_))))
                            (declare (not safe))
                            (##fxmax __tmp34264 '1))))
                     (declare (not safe))
                     (##fx< _%start30486%_ __tmp34263)))
              (let ((_%start30509%_ _%start30486%_))
                (if (let ((__tmp34265
                           (let ()
                             (declare (not safe))
                             (##u8vector-length _%bytes30494%_))))
                      (declare (not safe))
                      (##fx<= _%start30509%_ _%end30489%_ __tmp34265))
                    (let ((_%end30522%_ _%end30489%_))
                      (declare (not safe))
                      (std/encoding/hex#__hex-encode__%
                       _%bytes30494%_
                       _%start30509%_
                       _%end30522%_))
                    (begin
                      (raise-contract-violation-error
                       '"contract violation"
                       'context:
                       'gerbil-ascent/candidate/reasoning
                       'contract:
                       '(in-range-inclusive? start (u8vector-length bytes))
                       'value:
                       _%end30489%_)
                      '#!void)))
              (begin
                (raise-contract-violation-error
                 '"contract violation"
                 'context:
                 'gerbil-ascent/candidate/reasoning
                 'contract:
                 '(in-range? 0 (fxmax (u8vector-length bytes) 1))
                 'value:
                 _%start30486%_)
                '#!void)))))
    (define gerbil-ascent/candidate/reasoning#candidate-content-digest
      (lambda (_%candidate30461%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/datum#reasoning-bounded-data?
               _%candidate30461%_
               '16384
               '128))
            (gerbil-ascent/candidate/reasoning#digest-datum
             (list 'reasoning-candidate-v1 _%candidate30461%_))
            '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
      (lambda (_%receipt30455%_ _%snapshot30456%_ _%candidate30457%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%receipt30455%_
               'gerbil-ascent/candidate/reasoning#reasoning-receipt::t))
            (if (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                   _%snapshot30456%_))
                (if (equal? (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%receipt30455%_
                               '2
                               '#f
                               '#f))
                            (##structure-ref
                             _%snapshot30456%_
                             '1
                             gerbil-ascent/candidate/types#reasoning-snapshot::t
                             '#f))
                    (if (equal? (let ()
                                  (declare (not safe))
                                  (##unchecked-structure-ref
                                   _%receipt30455%_
                                   '3
                                   '#f
                                   '#f))
                                (##structure-ref
                                 _%snapshot30456%_
                                 '2
                                 gerbil-ascent/candidate/types#reasoning-snapshot::t
                                 '#f))
                        (if (equal? (let ()
                                      (declare (not safe))
                                      (##unchecked-structure-ref
                                       _%receipt30455%_
                                       '4
                                       '#f
                                       '#f))
                                    (##structure-ref
                                     _%snapshot30456%_
                                     '3
                                     gerbil-ascent/candidate/types#reasoning-snapshot::t
                                     '#f))
                            (let ((_%digest30459%_
                                   (gerbil-ascent/candidate/reasoning#candidate-content-digest
                                    _%candidate30457%_)))
                              (if _%digest30459%_
                                  (equal? _%digest30459%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%receipt30455%_
                                             '5
                                             '#f
                                             '#f)))
                                  '#f))
                            '#f)
                        '#f)
                    '#f)
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-source-snapshot
      (lambda (_%identity30421%_ _%generation30422%_ _%declarations30423%_)
        (if (and (or (symbol? _%identity30421%_) (string? _%identity30421%_))
                 (exact-integer? _%generation30422%_)
                 (<= '0 _%generation30422%_)
                 (let ()
                   (declare (not safe))
                   (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                    _%declarations30423%_
                    '131072
                    '128))
                 (list? _%declarations30423%_)
                 (<= (let ()
                       (declare (not safe))
                       (##length _%declarations30423%_))
                     gerbil-ascent/candidate/types#+max-relations+))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid reasoning source snapshot")))
        (let _%loop30428%_ ((_%remaining30430%_ _%declarations30423%_)
                            (_%seen30431%_ '())
                            (_%copied30432%_ '())
                            (_%facts30433%_ '0))
          (if (null? _%remaining30430%_)
              (let* ((_%relations30435%_ (reverse _%copied30432%_))
                     (__tmp34266
                      (let ()
                        (declare (not safe))
                        (gerbil-ascent/candidate/types#reasoning-snapshot-content-digest
                         _%identity30421%_
                         _%generation30422%_
                         _%relations30435%_))))
                (declare (not safe))
                (##structure
                 gerbil-ascent/candidate/types#reasoning-snapshot::t
                 _%identity30421%_
                 _%generation30422%_
                 __tmp34266
                 _%relations30435%_))
              (let ((_%entry30437%_ (car _%remaining30430%_)))
                (if (and (list? _%entry30437%_)
                         (= (let ()
                              (declare (not safe))
                              (##length _%entry30437%_))
                            '3)
                         (symbol? (car _%entry30437%_))
                         (exact-integer? (cadr _%entry30437%_))
                         (<= '0 (cadr _%entry30437%_))
                         (list? (caddr _%entry30437%_))
                         (not (memq (car _%entry30437%_) _%seen30431%_)))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"invalid or duplicate reasoning source declaration"
                             _%entry30437%_)))
                (let* ((_%name30439%_ (car _%entry30437%_))
                       (_%arity30441%_ (cadr _%entry30437%_))
                       (_%rows30443%_ (caddr _%entry30437%_))
                       (_%next-facts30445%_
                        (+ _%facts30433%_ (length _%rows30443%_))))
                  (if (> _%next-facts30445%_
                         gerbil-ascent/candidate/types#+max-input-facts+)
                      (let ()
                        (declare (not safe))
                        (error '"reasoning source snapshot exceeds input cap"))
                      '#!void)
                  (let ((_%owned30453%_
                         (map (lambda (_%row30448%_)
                                (let ((_%$e30450%_
                                       (gerbil-ascent/candidate/reasoning#copy-row
                                        _%row30448%_
                                        _%arity30441%_)))
                                  (if _%$e30450%_
                                      _%$e30450%_
                                      (let ()
                                        (declare (not safe))
                                        (error '"invalid reasoning source row"
                                               _%name30439%_
                                               _%row30448%_)))))
                              _%rows30443%_)))
                    (_%loop30428%_
                     (cdr _%remaining30430%_)
                     (cons _%name30439%_ _%seen30431%_)
                     (cons (list _%name30439%_ _%arity30441%_ _%owned30453%_)
                           _%copied30432%_)
                     _%next-facts30445%_))))))))
    (define gerbil-ascent/candidate/reasoning#query-row-matches?
      (lambda (_%terms30404%_ _%row30405%_)
        (let _%loop30407%_ ((_%terms30409%_ _%terms30404%_)
                            (_%values30410%_ _%row30405%_)
                            (_%bindings30411%_ '()))
          (if (null? _%terms30409%_)
              '#t
              (let ((_%term30413%_ (car _%terms30409%_))
                    (_%value30414%_ (car _%values30410%_)))
                (if (eq? _%term30413%_ '?_)
                    (_%loop30407%_
                     (cdr _%terms30409%_)
                     (cdr _%values30410%_)
                     _%bindings30411%_)
                    (if (let ()
                          (declare (not safe))
                          (gerbil-ascent/candidate/program#candidate-variable?
                           _%term30413%_))
                        (let ((_%binding30418%_
                               (assq _%term30413%_ _%bindings30411%_)))
                          (if _%binding30418%_
                              (if (equal? (cdr _%binding30418%_)
                                          _%value30414%_)
                                  (_%loop30407%_
                                   (cdr _%terms30409%_)
                                   (cdr _%values30410%_)
                                   _%bindings30411%_)
                                  '#f)
                              (_%loop30407%_
                               (cdr _%terms30409%_)
                               (cdr _%values30410%_)
                               (cons (cons _%term30413%_ _%value30414%_)
                                     _%bindings30411%_))))
                        (if (equal? _%term30413%_ _%value30414%_)
                            (_%loop30407%_
                             (cdr _%terms30409%_)
                             (cdr _%values30410%_)
                             _%bindings30411%_)
                            '#f))))))))
    (define gerbil-ascent/candidate/reasoning#candidate-graph-case?
      (lambda (_%snapshot30392%_ _%spec30393%_ _%query30394%_)
        (let ((_%source30396%_
               (##structure-ref
                _%snapshot30392%_
                '4
                gerbil-ascent/candidate/types#reasoning-snapshot::t
                '#f))
              (_%derived30397%_
               (##structure-ref
                _%spec30393%_
                '1
                gerbil-ascent/candidate/types#reasoning-candidate::t
                '#f))
              (_%rules30398%_
               (##structure-ref
                _%spec30393%_
                '3
                gerbil-ascent/candidate/types#reasoning-candidate::t
                '#f)))
          (if (= (length _%source30396%_) '1)
              (if (eq? (caar _%source30396%_) 'edge)
                  (if (= (cadar _%source30396%_) '2)
                      (if (equal? _%derived30397%_ '((path . 2)))
                          (if (= (length _%rules30398%_) '2)
                              (if (let ((_%forms30402%_
                                         (map (lambda (_%rule30400%_)
                                                (cons (vector-ref
                                                       _%rule30400%_
                                                       '0)
                                                      (vector-ref
                                                       _%rule30400%_
                                                       '1)))
                                              _%rules30398%_)))
                                    (and (let ()
                                           (declare (not safe))
                                           (##member
                                            '((path ?x ?y) (edge ?x ?y))
                                            _%forms30402%_))
                                         (let ()
                                           (declare (not safe))
                                           (##member
                                            '((path ?x ?z)
                                              (path ?x ?y)
                                              (edge ?y ?z))
                                            _%forms30402%_))))
                                  (if (= (length _%query30394%_) '3)
                                      (if (eq? (car _%query30394%_) 'path)
                                          (if (exact-integer?
                                               (cadr _%query30394%_))
                                              (exact-integer?
                                               (caddr _%query30394%_))
                                              '#f)
                                          '#f)
                                      '#f)
                                  '#f)
                              '#f)
                          '#f)
                      '#f)
                  '#f)
              '#f))))
    (define gerbil-ascent/candidate/reasoning#candidate-edge-records
      (lambda (_%snapshot30384%_ _%spec30385%_)
        (let ((__tmp34268
               (map (lambda (_%row30387%_ _%index30388%_)
                      (list 'source _%index30388%_ _%row30387%_))
                    (caddar (##structure-ref
                             _%snapshot30384%_
                             '4
                             gerbil-ascent/candidate/types#reasoning-snapshot::t
                             '#f))
                    (let ((__tmp34269
                           (length (caddar (##structure-ref
                                            _%snapshot30384%_
                                            '4
                                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                                            '#f)))))
                      (declare (not safe))
                      (##iota __tmp34269 '1))))
              (__tmp34267
               (map (lambda (_%fact30390%_)
                      (list 'candidate
                            (vector-ref _%fact30390%_ '2)
                            (vector-ref _%fact30390%_ '1)))
                    (##structure-ref
                     _%spec30385%_
                     '2
                     gerbil-ascent/candidate/types#reasoning-candidate::t
                     '#f))))
          (declare (not safe))
          (##append __tmp34268 __tmp34267))))
    (define gerbil-ascent/candidate/reasoning#candidate-edge-index
      (lambda (_%records30376%_)
        (let ((_%index30378%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (for-each
           (lambda (_%record30380%_)
             (let* ((_%origin30382%_ (caaddr _%record30380%_))
                    (__tmp34270
                     (cons _%record30380%_
                           (let ()
                             (declare (not safe))
                             (__hash-ref__%
                              _%index30378%_
                              _%origin30382%_
                              '())))))
               (declare (not safe))
               (__hash-put! _%index30378%_ _%origin30382%_ __tmp34270)))
           _%records30376%_)
          _%index30378%_)))
    (define gerbil-ascent/candidate/reasoning#candidate-graph-walk
      (lambda (_%records30301%_ _%origin30302%_ _%target30303%_)
        (let ((_%index30305%_
               (gerbil-ascent/candidate/reasoning#candidate-edge-index
                _%records30301%_))
              (_%visited30306%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value)))
              (_%reachable30307%_ (list _%origin30302%_))
              (_%support30308%_ '#f))
          (let ()
            (declare (not safe))
            (__hash-put! _%visited30306%_ _%origin30302%_ '#t))
          (let _%loop30310%_ ((_%front30312%_
                               (list (cons _%origin30302%_ '())))
                              (_%back30313%_ '()))
            (if (null? _%front30312%_)
                (if (null? _%back30313%_)
                    (values _%support30308%_
                            (let ()
                              (declare (not safe))
                              (##reverse _%reachable30307%_)))
                    (_%loop30310%_ (reverse _%back30313%_) '()))
                (let* ((_%state30317%_ (car _%front30312%_))
                       (_%node30319%_ (car _%state30317%_))
                       (_%path30321%_ (cdr _%state30317%_))
                       (_%next30323%_ _%back30313%_))
                  (let ((__tmp34272
                         (lambda (_%record30326%_)
                           (let* ((_%$%record3032730342%_ _%record30326%_)
                                  (_%$%E3032930345%_
                                   (lambda ()
                                     (let ()
                                       (declare (not safe))
                                       (error '"No clause matching"
                                              _%$%record3032730342%_
                                              '([_ _ [_ neighbor]])))
                                     '#!void))
                                  (_%$%K3033030352%_
                                   (lambda (_%neighbor30348%_)
                                     (let ((_%extended30350%_
                                            (cons _%record30326%_
                                                  _%path30321%_)))
                                       (if (if _%support30308%_
                                               '#f
                                               (equal? _%neighbor30348%_
                                                       _%target30303%_))
                                           (set! _%support30308%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##reverse
                                                    _%extended30350%_)))
                                           '#!void)
                                       (if (let ()
                                             (declare (not safe))
                                             (__hash-get
                                              _%visited30306%_
                                              _%neighbor30348%_))
                                           '#!void
                                           (begin
                                             (let ()
                                               (declare (not safe))
                                               (__hash-put!
                                                _%visited30306%_
                                                _%neighbor30348%_
                                                '#t))
                                             (set! _%reachable30307%_
                                                   (cons _%neighbor30348%_
                                                         _%reachable30307%_))
                                             (set! _%next30323%_
                                                   (cons (cons _%neighbor30348%_
                                                               _%extended30350%_)
                                                         _%next30323%_))))))))
                             (if (pair? _%$%record3032730342%_)
                                 (let ((_%$%tl3033230355%_
                                        (let ()
                                          (declare (not safe))
                                          (##cdr _%$%record3032730342%_))))
                                   (if (pair? _%$%tl3033230355%_)
                                       (let ((_%$%tl3033430358%_
                                              (let ()
                                                (declare (not safe))
                                                (##cdr _%$%tl3033230355%_))))
                                         (if (pair? _%$%tl3033430358%_)
                                             (let ((_%$%hd3033530361%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##car _%$%tl3033430358%_)))
                                                   (_%$%tl3033630363%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##cdr _%$%tl3033430358%_))))
                                               (if (pair? _%$%hd3033530361%_)
                                                   (let ((_%$%tl3033830366%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (##cdr _%$%hd3033530361%_))))
                                                     (if (pair? _%$%tl3033830366%_)
                                                         (let ((_%$%hd3033930369%_
                                                                (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##car _%$%tl3033830366%_)))
                       (_%$%tl3034030371%_
                        (let ()
                          (declare (not safe))
                          (##cdr _%$%tl3033830366%_))))
                   (let ((_%neighbor30374%_ _%$%hd3033930369%_))
                     (if (null? _%$%tl3034030371%_)
                         (if (null? _%$%tl3033630363%_)
                             (_%$%K3033030352%_ _%neighbor30374%_)
                             (_%$%E3032930345%_))
                         (_%$%E3032930345%_))))
                 (_%$%E3032930345%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (_%$%E3032930345%_)))
                                             (_%$%E3032930345%_)))
                                       (_%$%E3032930345%_)))
                                 (_%$%E3032930345%_)))))
                        (__tmp34271
                         (reverse (let ()
                                    (declare (not safe))
                                    (__hash-ref__%
                                     _%index30305%_
                                     _%node30319%_
                                     '())))))
                    (declare (not safe))
                    (##for-each __tmp34272 __tmp34271))
                  (_%loop30310%_ (cdr _%front30312%_) _%next30323%_)))))))
    (define gerbil-ascent/candidate/reasoning#candidate-evidence
      (lambda (_%snapshot30289%_ _%spec30290%_ _%query30291%_ _%rows30292%_)
        (if (gerbil-ascent/candidate/reasoning#candidate-graph-case?
             _%snapshot30289%_
             _%spec30290%_
             _%query30291%_)
            (let ((_g34273_
                   (gerbil-ascent/candidate/reasoning#candidate-graph-walk
                    (gerbil-ascent/candidate/reasoning#candidate-edge-records
                     _%snapshot30289%_
                     _%spec30290%_)
                    (cadr _%query30291%_)
                    (caddr _%query30291%_))))
              (begin
                (let ((_g34274_
                       (let ()
                         (declare (not safe))
                         (if (##values? _g34273_)
                             (##values-length _g34273_)
                             1))))
                  (if (not (let () (declare (not safe)) (##fx= _g34274_ 2)))
                      (error "Context expects 2 values" _g34274_)))
                (let ((_%support30294%_
                       (let () (declare (not safe)) (##values-ref _g34273_ 0)))
                      (_%reachable30295%_
                       (let ()
                         (declare (not safe))
                         (##values-ref _g34273_ 1))))
                  (if (and (pair? _%rows30292%_) _%support30294%_)
                      (let ()
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                         'witness
                         _%support30294%_
                         '()))
                      (if (and (null? _%rows30292%_)
                               (if _%support30294%_
                                   '#f
                                   (not (member (caddr _%query30291%_)
                                                _%reachable30295%_))))
                          (let ()
                            (declare (not safe))
                            (##structure
                             gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                             'cut
                             '()
                             _%reachable30295%_))
                          (if (and (null? _%rows30292%_)
                                   (if _%support30294%_
                                       '#f
                                       (equal? (cadr _%query30291%_)
                                               (caddr _%query30291%_))))
                              (let ()
                                (declare (not safe))
                                (##structure
                                 gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                                 'unsupported
                                 '()
                                 '()))
                              '#f))))))
            (let ()
              (declare (not safe))
              (##structure
               gerbil-ascent/candidate/reasoning#reasoning-evidence::t
               'unsupported
               '()
               '())))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
      (lambda (_%snapshot30223%_
               _%digest30224%_
               _%status30225%_
               _%query30226%_
               _%rows30227%_
               _%diagnostics30228%_
               _%evidence30229%_
               _%proof30230%_
               _%nonmembership30231%_
               _%stratified30232%_)
        (let ((__tmp34291
               (##structure-ref
                _%snapshot30223%_
                '1
                gerbil-ascent/candidate/types#reasoning-snapshot::t
                '#f))
              (__tmp34290
               (##structure-ref
                _%snapshot30223%_
                '2
                gerbil-ascent/candidate/types#reasoning-snapshot::t
                '#f))
              (__tmp34289
               (##structure-ref
                _%snapshot30223%_
                '3
                gerbil-ascent/candidate/types#reasoning-snapshot::t
                '#f))
              (__tmp34288
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/datum#candidate-copy-pairs
                  _%query30226%_)))
              (__tmp34287
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/datum#candidate-copy-pairs
                  _%rows30227%_)))
              (__tmp34281
               (map (lambda (_%diagnostic30234%_)
                      (let ((__tmp34286
                             (##structure-ref
                              _%diagnostic30234%_
                              '1
                              gerbil-ascent/candidate/types#reasoning-diagnostic::t
                              '#f))
                            (__tmp34284
                             (let ((__tmp34285
                                    (##structure-ref
                                     _%diagnostic30234%_
                                     '2
                                     gerbil-ascent/candidate/types#reasoning-diagnostic::t
                                     '#f)))
                               (declare (not safe))
                               (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                __tmp34285)))
                            (__tmp34282
                             (let ((__tmp34283
                                    (##structure-ref
                                     _%diagnostic30234%_
                                     '3
                                     gerbil-ascent/candidate/types#reasoning-diagnostic::t
                                     '#f)))
                               (declare (not safe))
                               (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                __tmp34283))))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/types#reasoning-diagnostic::t
                         __tmp34286
                         __tmp34284
                         __tmp34282)))
                    _%diagnostics30228%_))
              (__tmp34275
               (if _%evidence30229%_
                   (let ((__tmp34280
                          (##structure-ref
                           _%evidence30229%_
                           '1
                           gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                           '#f))
                         (__tmp34278
                          (let ((__tmp34279
                                 (##structure-ref
                                  _%evidence30229%_
                                  '2
                                  gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                                  '#f)))
                            (declare (not safe))
                            (gerbil-ascent/candidate/datum#candidate-copy-pairs
                             __tmp34279)))
                         (__tmp34276
                          (let ((__tmp34277
                                 (##structure-ref
                                  _%evidence30229%_
                                  '3
                                  gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                                  '#f)))
                            (declare (not safe))
                            (gerbil-ascent/candidate/datum#candidate-copy-pairs
                             __tmp34277))))
                     (declare (not safe))
                     (##structure
                      gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                      __tmp34280
                      __tmp34278
                      __tmp34276))
                   '#f)))
          (declare (not safe))
          (##structure
           gerbil-ascent/candidate/reasoning#reasoning-receipt::t
           _%status30225%_
           __tmp34291
           __tmp34290
           __tmp34289
           _%digest30224%_
           __tmp34288
           __tmp34287
           __tmp34281
           __tmp34275
           _%proof30230%_
           _%nonmembership30231%_
           _%stratified30232%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
      (lambda (_%snapshot30239%_
               _%digest30240%_
               _%status30241%_
               _%query30242%_
               _%rows30243%_
               _%diagnostics30244%_
               _%evidence30245%_)
        (let* ((_%proof30247%_ '#f)
               (_%nonmembership30249%_ '#f)
               (_%stratified30251%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
           _%snapshot30239%_
           _%digest30240%_
           _%status30241%_
           _%query30242%_
           _%rows30243%_
           _%diagnostics30244%_
           _%evidence30245%_
           _%proof30247%_
           _%nonmembership30249%_
           _%stratified30251%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for__1
      (lambda (_%snapshot30253%_
               _%digest30254%_
               _%status30255%_
               _%query30256%_
               _%rows30257%_
               _%diagnostics30258%_
               _%evidence30259%_
               _%proof30260%_)
        (let* ((_%nonmembership30262%_ '#f) (_%stratified30264%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
           _%snapshot30253%_
           _%digest30254%_
           _%status30255%_
           _%query30256%_
           _%rows30257%_
           _%diagnostics30258%_
           _%evidence30259%_
           _%proof30260%_
           _%nonmembership30262%_
           _%stratified30264%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for__2
      (lambda (_%snapshot30266%_
               _%digest30267%_
               _%status30268%_
               _%query30269%_
               _%rows30270%_
               _%diagnostics30271%_
               _%evidence30272%_
               _%proof30273%_
               _%nonmembership30274%_)
        (let ((_%stratified30276%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
           _%snapshot30266%_
           _%digest30267%_
           _%status30268%_
           _%query30269%_
           _%rows30270%_
           _%diagnostics30271%_
           _%evidence30272%_
           _%proof30273%_
           _%nonmembership30274%_
           _%stratified30276%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for
      (lambda _g34292_
        (let ((_g34293_ (let () (declare (not safe)) (##length _g34292_))))
          (cond ((let () (declare (not safe)) (##fx= _g34293_ 7))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
                        _g34292_))
                ((let () (declare (not safe)) (##fx= _g34293_ 8))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-receipt-for__1
                        _g34292_))
                ((let () (declare (not safe)) (##fx= _g34293_ 9))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-receipt-for__2
                        _g34292_))
                ((let () (declare (not safe)) (##fx= _g34293_ 10))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
                        _g34292_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/candidate/reasoning#reasoning-receipt-for
                  _g34292_))))))
    (define gerbil-ascent/candidate/reasoning#captured-stage::t
      (let ((__tmp34295 (list)) (__tmp34294 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#captured-stage::t
         'captured-stage
         __tmp34295
         '(ok? value)
         __tmp34294
         '#f)))
    (define gerbil-ascent/candidate/reasoning#captured-stage?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#captured-stage::t)))
    (define gerbil-ascent/candidate/reasoning#make-captured-stage
      (lambda _%$args30219%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#captured-stage::t
               _%$args30219%_)))
    (define gerbil-ascent/candidate/reasoning#captured-stage-ok?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'ok?)))
    (define gerbil-ascent/candidate/reasoning#captured-stage-value
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'value)))
    (define gerbil-ascent/candidate/reasoning#captured-stage-ok?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'ok?)))
    (define gerbil-ascent/candidate/reasoning#captured-stage-value-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'value)))
    (define gerbil-ascent/candidate/reasoning#&captured-stage-ok?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'ok?)))
    (define gerbil-ascent/candidate/reasoning#&captured-stage-value
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'value)))
    (define gerbil-ascent/candidate/reasoning#&captured-stage-ok?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'ok?)))
    (define gerbil-ascent/candidate/reasoning#&captured-stage-value-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'value)))
    (define gerbil-ascent/candidate/reasoning#capture
      (lambda (_%thunk30214%_)
        (let ((__tmp34298
               (lambda (_%failure30216%_)
                 (let ()
                   (declare (not safe))
                   (##structure
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#f
                    _%failure30216%_))))
              (__tmp34296
               (lambda ()
                 (let ((__tmp34297 (_%thunk30214%_)))
                   (declare (not safe))
                   (##structure
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#t
                    __tmp34297)))))
          (declare (not safe))
          (__with-catch __tmp34298 __tmp34296))))
    (define gerbil-ascent/candidate/reasoning#failure-detail
      (lambda (_%failure30210%_)
        (let ((_%message30212%_
               (let ()
                 (declare (not safe))
                 (std/error#exception->string _%failure30210%_))))
          (if (> (let ()
                   (declare (not safe))
                   (##string-length _%message30212%_))
                 '240)
              (substring _%message30212%_ '0 '240)
              _%message30212%_))))
    (define gerbil-ascent/candidate/reasoning#produce-receipt-stratified
      (lambda (_%snapshot30199%_
               _%spec30200%_
               _%digest30201%_
               _%rows30202%_
               _%work-budget30203%_)
        (let ((_%finite30205%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/finite-evidence#candidate-finite-evidence
                  _%snapshot30199%_
                  _%spec30200%_
                  _%digest30201%_
                  'complete
                  _%rows30202%_
                  _%work-budget30203%_))))
          (if (eq? (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref _%finite30205%_ '1 '#f '#f))
                   'complete)
              (let ((_g34299_
                     (let ()
                       (declare (not safe))
                       (gerbil-ascent/candidate/stratified-producer#candidate-produce-stratified-proof
                        _%snapshot30199%_
                        _%spec30200%_
                        _%digest30201%_
                        'complete
                        _%rows30202%_
                        _%finite30205%_
                        _%work-budget30203%_
                        _%work-budget30203%_))))
                (begin
                  (let ((_g34300_
                         (let ()
                           (declare (not safe))
                           (if (##values? _g34299_)
                               (##values-length _g34299_)
                               1))))
                    (if (not (let () (declare (not safe)) (##fx= _g34300_ 2)))
                        (error "Context expects 2 values" _g34300_)))
                  (let ((_%status30207%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g34299_ 0)))
                        (_%proof30208%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g34299_ 1))))
                    (let ()
                      (declare (not safe))
                      (##structure
                       gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                       _%status30207%_
                       _%finite30205%_
                       _%proof30208%_
                       _%work-budget30203%_)))))
              (let ((__tmp34301
                     (let ()
                       (declare (not safe))
                       (##unchecked-structure-ref
                        _%finite30205%_
                        '1
                        '#f
                        '#f))))
                (declare (not safe))
                (##structure
                 gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                 __tmp34301
                 _%finite30205%_
                 '()
                 _%work-budget30203%_))))))
    (define gerbil-ascent/candidate/reasoning#reasoning-verify-finite-receipt
      (lambda (_%receipt30191%_
               _%snapshot30192%_
               _%candidate30193%_
               _%work-budget30194%_)
        (if (and (exact-integer? _%work-budget30194%_)
                 (> _%work-budget30194%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"finite receipt verification needs positive work budget"
                     _%work-budget30194%_)))
        (if (and (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                  _%receipt30191%_
                  _%snapshot30192%_
                  _%candidate30193%_)
                 (eq? (##structure-ref
                       _%receipt30191%_
                       '1
                       gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                       '#f)
                      'complete)
                 (let ((__tmp34302
                        (##structure-ref
                         _%receipt30191%_
                         '12
                         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                         '#f)))
                   (declare (not safe))
                   (##structure-instance-of?
                    __tmp34302
                    'gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t)))
            (let ((_%checked30197%_
                   (gerbil-ascent/candidate/reasoning#capture
                    (lambda ()
                      (let ((__tmp34306
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program#candidate-inspect
                                _%snapshot30192%_
                                _%candidate30193%_)))
                            (__tmp34305
                             (##structure-ref
                              _%receipt30191%_
                              '5
                              gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                              '#f))
                            (__tmp34304
                             (##structure-ref
                              _%receipt30191%_
                              '7
                              gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                              '#f))
                            (__tmp34303
                             (##structure-ref
                              (##structure-ref
                               _%receipt30191%_
                               '12
                               gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                               '#f)
                              '2
                              gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                              '#f)))
                        (declare (not safe))
                        (gerbil-ascent/candidate/finite-evidence#candidate-verify-finite-evidence
                         _%snapshot30192%_
                         __tmp34306
                         __tmp34305
                         'complete
                         __tmp34304
                         __tmp34303
                         _%work-budget30194%_))))))
              (if (##structure-ref
                   _%checked30197%_
                   '1
                   gerbil-ascent/candidate/reasoning#captured-stage::t
                   '#f)
                  (##structure-ref
                   _%checked30197%_
                   '2
                   gerbil-ascent/candidate/reasoning#captured-stage::t
                   '#f)
                  'invalid))
            'invalid)))
    (define gerbil-ascent/candidate/reasoning#reasoning-verify-stratified-receipt
      (lambda (_%receipt30178%_
               _%snapshot30179%_
               _%candidate30180%_
               _%work-budget30181%_)
        (if (and (exact-integer? _%work-budget30181%_)
                 (> _%work-budget30181%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"stratified receipt verification needs positive work budget"
                     _%work-budget30181%_)))
        (if (and (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                  _%receipt30178%_
                  _%snapshot30179%_
                  _%candidate30180%_)
                 (eq? (##structure-ref
                       _%receipt30178%_
                       '1
                       gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                       '#f)
                      'complete)
                 (let ((__tmp34307
                        (##structure-ref
                         _%receipt30178%_
                         '12
                         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                         '#f)))
                   (declare (not safe))
                   (##structure-instance-of?
                    __tmp34307
                    'gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t)))
            (let* ((_%evidence30183%_
                    (##structure-ref
                     _%receipt30178%_
                     '12
                     gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                     '#f))
                   (_%$e30185%_
                    (##structure-ref
                     _%evidence30183%_
                     '1
                     gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                     '#f)))
              (if (eq? 'complete _%$e30185%_)
                  (let ((_%checked30189%_
                         (gerbil-ascent/candidate/reasoning#capture
                          (lambda ()
                            (let ((__tmp34312
                                   (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/program#candidate-inspect
                                      _%snapshot30179%_
                                      _%candidate30180%_)))
                                  (__tmp34311
                                   (##structure-ref
                                    _%receipt30178%_
                                    '5
                                    gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                    '#f))
                                  (__tmp34310
                                   (##structure-ref
                                    _%receipt30178%_
                                    '7
                                    gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                    '#f))
                                  (__tmp34309
                                   (##structure-ref
                                    _%evidence30183%_
                                    '2
                                    gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                                    '#f))
                                  (__tmp34308
                                   (##structure-ref
                                    _%evidence30183%_
                                    '3
                                    gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                                    '#f)))
                              (declare (not safe))
                              (gerbil-ascent/candidate/stratified-proof#candidate-verify-stratified-proof
                               _%snapshot30179%_
                               __tmp34312
                               __tmp34311
                               'complete
                               __tmp34310
                               __tmp34309
                               _%work-budget30181%_
                               __tmp34308
                               _%work-budget30181%_))))))
                    (if (##structure-ref
                         _%checked30189%_
                         '1
                         gerbil-ascent/candidate/reasoning#captured-stage::t
                         '#f)
                        (##structure-ref
                         _%checked30189%_
                         '2
                         gerbil-ascent/candidate/reasoning#captured-stage::t
                         '#f)
                        'invalid))
                  (if (eq? 'bounded _%$e30185%_)
                      'bounded
                      (if (eq? 'unsupported _%$e30185%_)
                          'unsupported
                          'invalid))))
            'invalid)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation::t
      (let ((__tmp34314 (list)) (__tmp34313 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#attempt-observation::t
         'attempt-observation
         __tmp34314
         '(rows evidence)
         __tmp34313
         '#f)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#attempt-observation::t)))
    (define gerbil-ascent/candidate/reasoning#make-attempt-observation
      (lambda _%$args30175%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#attempt-observation::t
               _%$args30175%_)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation-evidence
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation-evidence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#&attempt-observation-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#&attempt-observation-evidence
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#&attempt-observation-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#&attempt-observation-evidence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#attempt-failure
      (lambda (_%snapshot30167%_
               _%digest30168%_
               _%status30169%_
               _%query30170%_
               _%code30171%_
               _%path30172%_
               _%failure30173%_)
        (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
         _%snapshot30167%_
         _%digest30168%_
         _%status30169%_
         _%query30170%_
         '()
         (list (let ((__tmp34315
                      (gerbil-ascent/candidate/reasoning#failure-detail
                       _%failure30173%_)))
                 (declare (not safe))
                 (##structure
                  gerbil-ascent/candidate/types#reasoning-diagnostic::t
                  _%code30171%_
                  _%path30172%_
                  __tmp34315)))
         '#f)))
    (define gerbil-ascent/candidate/reasoning#attempt-proof-diagnostics
      (lambda (_%result30161%_ _%code30162%_)
        (if (or (not _%result30161%_)
                (##structure-ref
                 _%result30161%_
                 '1
                 gerbil-ascent/candidate/reasoning#captured-stage::t
                 '#f))
            '()
            (list (let ((__tmp34316
                         (gerbil-ascent/candidate/reasoning#failure-detail
                          (##structure-ref
                           _%result30161%_
                           '2
                           gerbil-ascent/candidate/reasoning#captured-stage::t
                           '#f))))
                    (declare (not safe))
                    (##structure
                     gerbil-ascent/candidate/types#reasoning-diagnostic::t
                     _%code30162%_
                     '(explain)
                     __tmp34316))))))
    (define gerbil-ascent/candidate/reasoning#attempt-proof-value
      (lambda (_%result30159%_)
        (if _%result30159%_
            (if (##structure-ref
                 _%result30159%_
                 '1
                 gerbil-ascent/candidate/reasoning#captured-stage::t
                 '#f)
                (##structure-ref
                 _%result30159%_
                 '2
                 gerbil-ascent/candidate/reasoning#captured-stage::t
                 '#f)
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/reasoning#attempt-publish
      (lambda (_%snapshot30113%_
               _%spec30114%_
               _%digest30115%_
               _%query30116%_
               _%observation30117%_
               _%proof-steps30118%_
               _%stratified-steps30119%_)
        (let* ((_%$%observation3012030127%_ _%observation30117%_)
               (_%$%E3012230130%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%observation3012030127%_
                           '((attempt-observation rows evidence))))
                  '#!void))
               (_%$%K3012330146%_
                (lambda (_%evidence30133%_ _%rows30134%_)
                  (let* ((_%proof30137%_
                          (gerbil-ascent/candidate/reasoning#capture
                           (lambda ()
                             (if _%proof-steps30118%_
                                 (let ()
                                   (declare (not safe))
                                   (gerbil-ascent/candidate/provenance#candidate-positive-proof
                                    _%snapshot30113%_
                                    _%spec30114%_
                                    _%digest30115%_
                                    'complete
                                    _%rows30134%_
                                    _%proof-steps30118%_))
                                 '#f))))
                         (_%absence30140%_
                          (gerbil-ascent/candidate/reasoning#capture
                           (lambda ()
                             (if _%proof-steps30118%_
                                 (let ()
                                   (declare (not safe))
                                   (gerbil-ascent/candidate/nonmembership#candidate-positive-nonmembership
                                    _%snapshot30113%_
                                    _%spec30114%_
                                    _%digest30115%_
                                    'complete
                                    _%rows30134%_
                                    _%proof-steps30118%_))
                                 '#f))))
                         (_%stratified30143%_
                          (if _%stratified-steps30119%_
                              (gerbil-ascent/candidate/reasoning#capture
                               (lambda ()
                                 (gerbil-ascent/candidate/reasoning#produce-receipt-stratified
                                  _%snapshot30113%_
                                  _%spec30114%_
                                  _%digest30115%_
                                  _%rows30134%_
                                  _%stratified-steps30119%_)))
                              '#f)))
                    (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
                     _%snapshot30113%_
                     _%digest30115%_
                     'complete
                     _%query30116%_
                     _%rows30134%_
                     (let ((__tmp34319
                            (gerbil-ascent/candidate/reasoning#attempt-proof-diagnostics
                             _%proof30137%_
                             'proof-failed))
                           (__tmp34318
                            (gerbil-ascent/candidate/reasoning#attempt-proof-diagnostics
                             _%absence30140%_
                             'nonmembership-failed))
                           (__tmp34317
                            (gerbil-ascent/candidate/reasoning#attempt-proof-diagnostics
                             _%stratified30143%_
                             'stratified-evidence-failed)))
                       (declare (not safe))
                       (##append __tmp34319 __tmp34318 __tmp34317))
                     _%evidence30133%_
                     (gerbil-ascent/candidate/reasoning#attempt-proof-value
                      _%proof30137%_)
                     (gerbil-ascent/candidate/reasoning#attempt-proof-value
                      _%absence30140%_)
                     (gerbil-ascent/candidate/reasoning#attempt-proof-value
                      _%stratified30143%_))))))
          (if (let ()
                (declare (not safe))
                (##structure-instance-of?
                 _%$%observation3012030127%_
                 'gerbil-ascent/candidate/reasoning#attempt-observation::t))
              (let* ((_%$%e3012430149%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%observation3012030127%_
                         '1
                         '#f
                         '#f)))
                     (_%rows30152%_ _%$%e3012430149%_)
                     (_%$%e3012530154%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%observation3012030127%_
                         '2
                         '#f
                         '#f)))
                     (_%evidence30157%_ _%$%e3012530154%_))
                (_%$%K3012330146%_ _%evidence30157%_ _%rows30152%_))
              (_%$%E3012230130%_)))))
    (define gerbil-ascent/candidate/reasoning#attempt-observe
      (lambda (_%snapshot30090%_
               _%spec30091%_
               _%digest30092%_
               _%query30093%_
               _%solved30094%_
               _%proof-steps30095%_
               _%stratified-steps30096%_)
        (let ((_%observed30108%_
               (gerbil-ascent/candidate/reasoning#capture
                (lambda ()
                  (let* ((_%all30099%_
                          (let ((__tmp34320 (car _%query30093%_)))
                            (declare (not safe))
                            (gerbil-ascent/program/scheme-query#relational-query-name
                             _%solved30094%_
                             __tmp34320)))
                         (_%rows30105%_
                          (let ((__tmp34321
                                 (lambda (_%$%g3010030102%_)
                                   (gerbil-ascent/candidate/reasoning#query-row-matches?
                                    (cdr _%query30093%_)
                                    _%$%g3010030102%_))))
                            (declare (not safe))
                            (##filter __tmp34321 _%all30099%_)))
                         (__tmp34322
                          (gerbil-ascent/candidate/reasoning#candidate-evidence
                           _%snapshot30090%_
                           _%spec30091%_
                           _%query30093%_
                           _%rows30105%_)))
                    (declare (not safe))
                    (##structure
                     gerbil-ascent/candidate/reasoning#attempt-observation::t
                     _%rows30105%_
                     __tmp34322))))))
          (if (##structure-ref
               _%observed30108%_
               '1
               gerbil-ascent/candidate/reasoning#captured-stage::t
               '#f)
              (if (##structure-ref
                   (##structure-ref
                    _%observed30108%_
                    '2
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#f)
                   '2
                   gerbil-ascent/candidate/reasoning#attempt-observation::t
                   '#f)
                  (gerbil-ascent/candidate/reasoning#attempt-publish
                   _%snapshot30090%_
                   _%spec30091%_
                   _%digest30092%_
                   _%query30093%_
                   (##structure-ref
                    _%observed30108%_
                    '2
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#f)
                   _%proof-steps30095%_
                   _%stratified-steps30096%_)
                  (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
                   _%snapshot30090%_
                   _%digest30092%_
                   'unknown
                   _%query30093%_
                   '()
                   (list (let ()
                           (declare (not safe))
                           (##structure
                            gerbil-ascent/candidate/types#reasoning-diagnostic::t
                            'evidence-mismatch
                            '(explain)
                            _%query30093%_)))
                   '#f))
              (gerbil-ascent/candidate/reasoning#attempt-failure
               _%snapshot30090%_
               _%digest30092%_
               'unknown
               _%query30093%_
               'query-failed
               '(query)
               (##structure-ref
                _%observed30108%_
                '2
                gerbil-ascent/candidate/reasoning#captured-stage::t
                '#f))))))
    (define gerbil-ascent/candidate/reasoning#attempt-solve
      (lambda (_%snapshot30077%_
               _%spec30078%_
               _%digest30079%_
               _%query30080%_
               _%report30081%_
               _%proof-steps30082%_
               _%stratified-steps30083%_)
        (let ((_%diagnostic30085%_
               (##structure-ref
                _%report30081%_
                '2
                gerbil-ascent/program/scheme-admit#relational-admission-report::t
                '#f)))
          (if _%diagnostic30085%_
              (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
               _%snapshot30077%_
               _%digest30079%_
               'rejected
               _%query30080%_
               '()
               (list (let ((__tmp34326
                            (##structure-ref
                             _%diagnostic30085%_
                             '1
                             gerbil-ascent/program/scheme-admit#relational-diagnostic::t
                             '#f))
                           (__tmp34324
                            (let ((__tmp34325
                                   (##structure-ref
                                    _%diagnostic30085%_
                                    '2
                                    gerbil-ascent/program/scheme-admit#relational-diagnostic::t
                                    '#f)))
                              (declare (not safe))
                              (gerbil-ascent/candidate/program#candidate-planner-path
                               _%spec30078%_
                               __tmp34325)))
                           (__tmp34323
                            (##structure-ref
                             _%diagnostic30085%_
                             '3
                             gerbil-ascent/program/scheme-admit#relational-diagnostic::t
                             '#f)))
                       (declare (not safe))
                       (##structure
                        gerbil-ascent/candidate/types#reasoning-diagnostic::t
                        __tmp34326
                        __tmp34324
                        __tmp34323)))
               '#f)
              (let ((_%solved30088%_
                     (gerbil-ascent/candidate/reasoning#capture
                      (lambda ()
                        (let ((__tmp34327
                               (##structure-ref
                                _%report30081%_
                                '1
                                gerbil-ascent/program/scheme-admit#relational-admission-report::t
                                '#f)))
                          (declare (not safe))
                          (gerbil-ascent/program/scheme-admit#relational-solve
                           __tmp34327))))))
                (if (##structure-ref
                     _%solved30088%_
                     '1
                     gerbil-ascent/candidate/reasoning#captured-stage::t
                     '#f)
                    (gerbil-ascent/candidate/reasoning#attempt-observe
                     _%snapshot30077%_
                     _%spec30078%_
                     _%digest30079%_
                     _%query30080%_
                     (##structure-ref
                      _%solved30088%_
                      '2
                      gerbil-ascent/candidate/reasoning#captured-stage::t
                      '#f)
                     _%proof-steps30082%_
                     _%stratified-steps30083%_)
                    (gerbil-ascent/candidate/reasoning#attempt-failure
                     _%snapshot30077%_
                     _%digest30079%_
                     'unknown
                     _%query30080%_
                     'solve-failed
                     '(solve)
                     (##structure-ref
                      _%solved30088%_
                      '2
                      gerbil-ascent/candidate/reasoning#captured-stage::t
                      '#f))))))))
    (define gerbil-ascent/candidate/reasoning#attempt-prepare
      (lambda (_%snapshot30065%_
               _%spec30066%_
               _%digest30067%_
               _%proof-steps30068%_
               _%stratified-steps30069%_)
        (let* ((_%query30071%_
                (vector-ref
                 (##structure-ref
                  _%spec30066%_
                  '4
                  gerbil-ascent/candidate/types#reasoning-candidate::t
                  '#f)
                 '0))
               (_%prepared30074%_
                (gerbil-ascent/candidate/reasoning#capture
                 (lambda ()
                   (let ((__tmp34328
                          (let ()
                            (declare (not safe))
                            (gerbil-ascent/candidate/program#candidate-program
                             _%snapshot30065%_
                             _%spec30066%_))))
                     (declare (not safe))
                     (gerbil-ascent/program/scheme-admit#relational-admit/report
                      __tmp34328))))))
          (if (##structure-ref
               _%prepared30074%_
               '1
               gerbil-ascent/candidate/reasoning#captured-stage::t
               '#f)
              (gerbil-ascent/candidate/reasoning#attempt-solve
               _%snapshot30065%_
               _%spec30066%_
               _%digest30067%_
               _%query30071%_
               (##structure-ref
                _%prepared30074%_
                '2
                gerbil-ascent/candidate/reasoning#captured-stage::t
                '#f)
               _%proof-steps30068%_
               _%stratified-steps30069%_)
              (gerbil-ascent/candidate/reasoning#attempt-failure
               _%snapshot30065%_
               _%digest30067%_
               'rejected
               _%query30071%_
               'planner-rejected
               '(program)
               (##structure-ref
                _%prepared30074%_
                '2
                gerbil-ascent/candidate/reasoning#captured-stage::t
                '#f))))))
    (define gerbil-ascent/candidate/reasoning#reasoning-attempt__%
      (lambda (_%snapshot30024%_
               _%candidate30025%_
               _%proof-steps30026%_
               _%stratified-steps30027%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
               _%snapshot30024%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"reasoning attempt requires a current valid source snapshot"
                     _%snapshot30024%_)))
        (if (or (not _%proof-steps30026%_)
                (and (exact-integer? _%proof-steps30026%_)
                     (> _%proof-steps30026%_ '0)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"reasoning attempt requires positive proof work budget or #f"
                     _%proof-steps30026%_)))
        (if (or (not _%stratified-steps30027%_)
                (and (exact-integer? _%stratified-steps30027%_)
                     (> _%stratified-steps30027%_ '0)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"reasoning attempt requires positive stratified work budget"
                     _%stratified-steps30027%_)))
        (let* ((_%digest30035%_
                (gerbil-ascent/candidate/reasoning#candidate-content-digest
                 _%candidate30025%_))
               (_%inspection30038%_
                (gerbil-ascent/candidate/reasoning#capture
                 (lambda ()
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/program#candidate-inspect
                      _%snapshot30024%_
                      _%candidate30025%_))))))
          (if (##structure-ref
               _%inspection30038%_
               '1
               gerbil-ascent/candidate/reasoning#captured-stage::t
               '#f)
              (gerbil-ascent/candidate/reasoning#attempt-prepare
               _%snapshot30024%_
               (##structure-ref
                _%inspection30038%_
                '2
                gerbil-ascent/candidate/reasoning#captured-stage::t
                '#f)
               _%digest30035%_
               _%proof-steps30026%_
               _%stratified-steps30027%_)
              (if (let ((__tmp34329
                         (##structure-ref
                          _%inspection30038%_
                          '2
                          gerbil-ascent/candidate/reasoning#captured-stage::t
                          '#f)))
                    (declare (not safe))
                    (##structure-instance-of?
                     __tmp34329
                     'gerbil-ascent/candidate/types#candidate-rejection::t))
                  (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
                   _%snapshot30024%_
                   _%digest30035%_
                   'rejected
                   '#f
                   '()
                   (list (##structure-ref
                          (##structure-ref
                           _%inspection30038%_
                           '2
                           gerbil-ascent/candidate/reasoning#captured-stage::t
                           '#f)
                          '1
                          gerbil-ascent/candidate/types#candidate-rejection::t
                          '#f))
                   '#f)
                  (gerbil-ascent/candidate/reasoning#attempt-failure
                   _%snapshot30024%_
                   _%digest30035%_
                   'unknown
                   '#f
                   'inspector-failed
                   '(candidate)
                   (##structure-ref
                    _%inspection30038%_
                    '2
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#f)))))))
    (define gerbil-ascent/candidate/reasoning#reasoning-attempt__0
      (lambda (_%snapshot30047%_ _%candidate30048%_)
        (let* ((_%proof-steps30050%_ '100000) (_%stratified-steps30052%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-attempt__%
           _%snapshot30047%_
           _%candidate30048%_
           _%proof-steps30050%_
           _%stratified-steps30052%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-attempt__1
      (lambda (_%snapshot30054%_ _%candidate30055%_ _%proof-steps30056%_)
        (let ((_%stratified-steps30058%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-attempt__%
           _%snapshot30054%_
           _%candidate30055%_
           _%proof-steps30056%_
           _%stratified-steps30058%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-attempt
      (lambda _g34330_
        (let ((_g34331_ (let () (declare (not safe)) (##length _g34330_))))
          (cond ((let () (declare (not safe)) (##fx= _g34331_ 2))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-attempt__0
                        _g34330_))
                ((let () (declare (not safe)) (##fx= _g34331_ 3))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                        _g34330_))
                ((let () (declare (not safe)) (##fx= _g34331_ 4))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-attempt__%
                        _g34330_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/candidate/reasoning#reasoning-attempt
                  _g34330_))))))))
