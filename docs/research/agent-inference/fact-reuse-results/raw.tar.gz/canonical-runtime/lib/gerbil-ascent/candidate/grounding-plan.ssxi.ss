prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/candidate

(begin
  (declare-class
   gerbil-ascent/candidate/grounding-plan#grounding-rule::t
   (@class gerbil-ascent/candidate/grounding-plan#grounding-rule::t
           ()
           (object::t t::t)
           (name head body label)
           (name head body label)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#grounding-rule::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/grounding-plan#grounding-rule::t)
    'class::t))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#grounding-rule?
   (@predicate gerbil-ascent/candidate/grounding-plan#grounding-rule::t))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#make-grounding-rule
   (@constructor gerbil-ascent/candidate/grounding-plan#grounding-rule::t))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#grounding-rule-name
   (@accessor
    gerbil-ascent/candidate/grounding-plan#grounding-rule::t
    name
    #t))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#grounding-rule-head
   (@accessor
    gerbil-ascent/candidate/grounding-plan#grounding-rule::t
    head
    #t))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#grounding-rule-body
   (@accessor
    gerbil-ascent/candidate/grounding-plan#grounding-rule::t
    body
    #t))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#grounding-rule-label
   (@accessor
    gerbil-ascent/candidate/grounding-plan#grounding-rule::t
    label
    #t))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#grounding-rule-name-set!
   (@mutator gerbil-ascent/candidate/grounding-plan#grounding-rule::t name #t))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#grounding-rule-head-set!
   (@mutator gerbil-ascent/candidate/grounding-plan#grounding-rule::t head #t))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#grounding-rule-body-set!
   (@mutator gerbil-ascent/candidate/grounding-plan#grounding-rule::t body #t))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#grounding-rule-label-set!
   (@mutator
    gerbil-ascent/candidate/grounding-plan#grounding-rule::t
    label
    #t))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#&grounding-rule-name
   (@accessor
    gerbil-ascent/candidate/grounding-plan#grounding-rule::t
    name
    #f))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#&grounding-rule-head
   (@accessor
    gerbil-ascent/candidate/grounding-plan#grounding-rule::t
    head
    #f))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#&grounding-rule-body
   (@accessor
    gerbil-ascent/candidate/grounding-plan#grounding-rule::t
    body
    #f))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#&grounding-rule-label
   (@accessor
    gerbil-ascent/candidate/grounding-plan#grounding-rule::t
    label
    #f))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#&grounding-rule-name-set!
   (@mutator gerbil-ascent/candidate/grounding-plan#grounding-rule::t name #f))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#&grounding-rule-head-set!
   (@mutator gerbil-ascent/candidate/grounding-plan#grounding-rule::t head #f))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#&grounding-rule-body-set!
   (@mutator gerbil-ascent/candidate/grounding-plan#grounding-rule::t body #f))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#&grounding-rule-label-set!
   (@mutator
    gerbil-ascent/candidate/grounding-plan#grounding-rule::t
    label
    #f))
  (declare-class
   gerbil-ascent/candidate/grounding-plan#grounding-clause::t
   (@class gerbil-ascent/candidate/grounding-plan#grounding-clause::t
           ()
           (object::t t::t)
           (relation apply)
           (relation apply)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#grounding-clause::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/grounding-plan#grounding-clause::t)
    'class::t))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#grounding-clause?
   (@predicate gerbil-ascent/candidate/grounding-plan#grounding-clause::t))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#make-grounding-clause
   (@constructor gerbil-ascent/candidate/grounding-plan#grounding-clause::t))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#grounding-clause-relation
   (@accessor
    gerbil-ascent/candidate/grounding-plan#grounding-clause::t
    relation
    #t))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#grounding-clause-apply
   (@accessor
    gerbil-ascent/candidate/grounding-plan#grounding-clause::t
    apply
    #t))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#grounding-clause-relation-set!
   (@mutator
    gerbil-ascent/candidate/grounding-plan#grounding-clause::t
    relation
    #t))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#grounding-clause-apply-set!
   (@mutator
    gerbil-ascent/candidate/grounding-plan#grounding-clause::t
    apply
    #t))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#&grounding-clause-relation
   (@accessor
    gerbil-ascent/candidate/grounding-plan#grounding-clause::t
    relation
    #f))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#&grounding-clause-apply
   (@accessor
    gerbil-ascent/candidate/grounding-plan#grounding-clause::t
    apply
    #f))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#&grounding-clause-relation-set!
   (@mutator
    gerbil-ascent/candidate/grounding-plan#grounding-clause::t
    relation
    #f))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#&grounding-clause-apply-set!
   (@mutator
    gerbil-ascent/candidate/grounding-plan#grounding-clause::t
    apply
    #f))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/grounding-plan)))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#prepare-grounding-rule
   (@lambda 1
            #f
            signature:
            (return:
             gerbil-ascent/candidate/grounding-plan#grounding-rule::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/grounding-plan)))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#prepare-grounding-head
   (@lambda 1
            #f
            signature:
            (return:
             procedure::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/grounding-plan)))
  (declare-type
   gerbil-ascent/candidate/grounding-plan#prepare-grounding-fixed
   (@lambda 1
            #f
            signature:
            (return:
             procedure::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/grounding-plan))))
