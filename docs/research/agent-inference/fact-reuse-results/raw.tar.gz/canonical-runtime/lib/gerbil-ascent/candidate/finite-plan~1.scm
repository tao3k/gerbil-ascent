(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37853_|
    (##structure
     gx#syntax-quote::t
     'finite-rule::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37855_|
    (##structure
     gx#syntax-quote::t
     'make-finite-rule
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37857_|
    (##structure
     gx#syntax-quote::t
     'finite-rule?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37859_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37860_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-head
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37861_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-body
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37862_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-level
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37864_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37865_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-head-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37866_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-body-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37867_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-level-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37869_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37870_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-head
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37871_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-body
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37872_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-level
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37874_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37875_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-head-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37876_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-body-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37877_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-level-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37879_|
    (##structure
     gx#syntax-quote::t
     'finite-clause::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37881_|
    (##structure
     gx#syntax-quote::t
     'make-finite-clause
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37883_|
    (##structure
     gx#syntax-quote::t
     'finite-clause?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37885_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37886_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37887_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-apply
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37888_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-output
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37889_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-operator
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37891_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37892_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37893_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-apply-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37894_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-output-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37895_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-operator-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37897_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37898_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37899_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-apply
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37900_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-output
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37901_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-operator
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37903_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37904_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37905_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-apply-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37906_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-output-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37907_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-operator-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/finite-plan[:0:]#finite-rule|
      (let ((__obj37766
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37766
           'gerbil-ascent/candidate/finite-plan#finite-rule::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37766 'finite-rule '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37766
           '(relation head body level)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37766
           '(relation head body level)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37766 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37766 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37766 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37766 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37766 '#f '13 '#f '#f))
        (let ((__tmp37852 |gerbil-ascent/candidate/finite-plan[1]#_g37853_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37766 __tmp37852 '4 '#f '#f))
        (let ((__tmp37854 |gerbil-ascent/candidate/finite-plan[1]#_g37855_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37766 __tmp37854 '14 '#f '#f))
        (let ((__tmp37856 |gerbil-ascent/candidate/finite-plan[1]#_g37857_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37766 __tmp37856 '15 '#f '#f))
        (let ((__tmp37858
               (cons (cons 'relation
                           |gerbil-ascent/candidate/finite-plan[1]#_g37859_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37860_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37861_|)
                                 (cons (cons 'level
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37862_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37766 __tmp37858 '16 '#f '#f))
        (let ((__tmp37863
               (cons (cons 'relation
                           |gerbil-ascent/candidate/finite-plan[1]#_g37864_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37865_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37866_|)
                                 (cons (cons 'level
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37867_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37766 __tmp37863 '17 '#f '#f))
        (let ((__tmp37868
               (cons (cons 'relation
                           |gerbil-ascent/candidate/finite-plan[1]#_g37869_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37870_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37871_|)
                                 (cons (cons 'level
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37872_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37766 __tmp37868 '18 '#f '#f))
        (let ((__tmp37873
               (cons (cons 'relation
                           |gerbil-ascent/candidate/finite-plan[1]#_g37874_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37875_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37876_|)
                                 (cons (cons 'level
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37877_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37766 __tmp37873 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37766 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37766 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37766 '() '21 '#f '#f))
        __obj37766))
    (define |gerbil-ascent/candidate/finite-plan[:0:]#finite-clause|
      (let ((__obj37767
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37767
           'gerbil-ascent/candidate/finite-plan#finite-clause::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37767 'finite-clause '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37767
           '(kind relation apply output operator)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37767
           '(kind relation apply output operator)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37767 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37767 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37767 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37767 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37767 '#f '13 '#f '#f))
        (let ((__tmp37878 |gerbil-ascent/candidate/finite-plan[1]#_g37879_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37767 __tmp37878 '4 '#f '#f))
        (let ((__tmp37880 |gerbil-ascent/candidate/finite-plan[1]#_g37881_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37767 __tmp37880 '14 '#f '#f))
        (let ((__tmp37882 |gerbil-ascent/candidate/finite-plan[1]#_g37883_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37767 __tmp37882 '15 '#f '#f))
        (let ((__tmp37884
               (cons (cons 'kind
                           |gerbil-ascent/candidate/finite-plan[1]#_g37885_|)
                     (cons (cons 'relation
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37886_|)
                           (cons (cons 'apply
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37887_|)
                                 (cons (cons 'output
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37888_|)
                                       (cons (cons 'operator
                                                   |gerbil-ascent/candidate/finite-plan[1]#_g37889_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37767 __tmp37884 '16 '#f '#f))
        (let ((__tmp37890
               (cons (cons 'kind
                           |gerbil-ascent/candidate/finite-plan[1]#_g37891_|)
                     (cons (cons 'relation
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37892_|)
                           (cons (cons 'apply
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37893_|)
                                 (cons (cons 'output
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37894_|)
                                       (cons (cons 'operator
                                                   |gerbil-ascent/candidate/finite-plan[1]#_g37895_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37767 __tmp37890 '17 '#f '#f))
        (let ((__tmp37896
               (cons (cons 'kind
                           |gerbil-ascent/candidate/finite-plan[1]#_g37897_|)
                     (cons (cons 'relation
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37898_|)
                           (cons (cons 'apply
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37899_|)
                                 (cons (cons 'output
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37900_|)
                                       (cons (cons 'operator
                                                   |gerbil-ascent/candidate/finite-plan[1]#_g37901_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37767 __tmp37896 '18 '#f '#f))
        (let ((__tmp37902
               (cons (cons 'kind
                           |gerbil-ascent/candidate/finite-plan[1]#_g37903_|)
                     (cons (cons 'relation
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37904_|)
                           (cons (cons 'apply
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37905_|)
                                 (cons (cons 'output
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37906_|)
                                       (cons (cons 'operator
                                                   |gerbil-ascent/candidate/finite-plan[1]#_g37907_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37767 __tmp37902 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37767 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37767 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37767 '() '21 '#f '#f))
        __obj37767))))
