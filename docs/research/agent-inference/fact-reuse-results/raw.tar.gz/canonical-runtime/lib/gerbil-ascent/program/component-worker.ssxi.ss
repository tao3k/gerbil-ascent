prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/program

(begin
  (declare-class
   gerbil-ascent/program/component-worker#component-snapshot::t
   (@class gerbil-ascent/program/component-worker#component-snapshot::t
           ()
           (object::t t::t)
           (rows sizes)
           (rows sizes)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/program/component-worker#component-snapshot::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/component-worker#component-snapshot::t)
    'class::t))
  (declare-type
   gerbil-ascent/program/component-worker#component-snapshot?
   (@predicate gerbil-ascent/program/component-worker#component-snapshot::t))
  (declare-type
   gerbil-ascent/program/component-worker#make-component-snapshot
   (@constructor gerbil-ascent/program/component-worker#component-snapshot::t))
  (declare-type
   gerbil-ascent/program/component-worker#component-snapshot-rows
   (@accessor
    gerbil-ascent/program/component-worker#component-snapshot::t
    rows
    #t))
  (declare-type
   gerbil-ascent/program/component-worker#component-snapshot-sizes
   (@accessor
    gerbil-ascent/program/component-worker#component-snapshot::t
    sizes
    #t))
  (declare-type
   gerbil-ascent/program/component-worker#component-snapshot-rows-set!
   (@mutator
    gerbil-ascent/program/component-worker#component-snapshot::t
    rows
    #t))
  (declare-type
   gerbil-ascent/program/component-worker#component-snapshot-sizes-set!
   (@mutator
    gerbil-ascent/program/component-worker#component-snapshot::t
    sizes
    #t))
  (declare-type
   gerbil-ascent/program/component-worker#&component-snapshot-rows
   (@accessor
    gerbil-ascent/program/component-worker#component-snapshot::t
    rows
    #f))
  (declare-type
   gerbil-ascent/program/component-worker#&component-snapshot-sizes
   (@accessor
    gerbil-ascent/program/component-worker#component-snapshot::t
    sizes
    #f))
  (declare-type
   gerbil-ascent/program/component-worker#&component-snapshot-rows-set!
   (@mutator
    gerbil-ascent/program/component-worker#component-snapshot::t
    rows
    #f))
  (declare-type
   gerbil-ascent/program/component-worker#&component-snapshot-sizes-set!
   (@mutator
    gerbil-ascent/program/component-worker#component-snapshot::t
    sizes
    #f))
  (declare-type
   gerbil-ascent/program/component-worker#gerbil-ascent-run-positive-component!
   (@lambda 5
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/component-worker))))
