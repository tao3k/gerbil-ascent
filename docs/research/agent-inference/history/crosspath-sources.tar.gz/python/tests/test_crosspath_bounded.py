# SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
import unittest
from ascent_test_support.crosspath_annotation_bounded import merge_episode
class MergeTests(unittest.TestCase):
    def item(self):return {'index':0,'span':[0,4],'textSha256':'chunk','kind':'derive','fragment':0,'ready':True,'nativeTruthMatches':True,'prior':None,'definiteRepeatedDerivation':False,'claimKey':[0,True,'paths','edges']}
    def test_cross_chunk_repetition_and_global_offsets(self):
        first=merge_episode(self.item(),[],0,0,'whole')
        second=merge_episode(self.item(),[first],20,5,'whole')
        self.assertEqual(second['span'],[20,24]);self.assertEqual(second['index'],5);self.assertEqual(second['prior'],0);self.assertTrue(second['definiteRepeatedDerivation'])
    def test_no_invented_within_chunk_link(self):
        first=merge_episode(self.item(),[],20,5,'whole')
        e=self.item();e['span']=[6,10]
        second=merge_episode(e,[first],20,6,'whole')
        self.assertIsNone(second['prior']);self.assertFalse(second['definiteRepeatedDerivation'])
    def test_alternative_witness_not_same_derivation(self):
        first=merge_episode(self.item(),[],0,0,'whole');e=self.item();e['claimKey'][-1]='different edges'
        self.assertFalse(merge_episode(e,[first],20,5,'whole')['definiteRepeatedDerivation'])
