(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/provenance::timestamp 1791687887)
  (begin
    (define gerbil-ascent/candidate/provenance#positive-proof::t
      (let ((__tmp37207 (list)) (__tmp37206 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/provenance#positive-proof::t
         'positive-proof
         __tmp37207
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  query
                  work-budget
                  nodes
                  roots)
         __tmp37206
         '#f)))
    (define gerbil-ascent/candidate/provenance#positive-proof?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/provenance#positive-proof::t)))
    (define gerbil-ascent/candidate/provenance#make-positive-proof
      (lambda _%$args29399%_
        (apply make-instance
               gerbil-ascent/candidate/provenance#positive-proof::t
               _%$args29399%_)))
    (define gerbil-ascent/candidate/provenance#positive-proof-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'status)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/provenance#positive-proof-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/provenance#positive-proof-query
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'query)))
    (define gerbil-ascent/candidate/provenance#positive-proof-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'work-budget)))
    (define gerbil-ascent/candidate/provenance#positive-proof-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#positive-proof-roots
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'roots)))
    (define gerbil-ascent/candidate/provenance#positive-proof-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'status)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/provenance#positive-proof-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/provenance#positive-proof-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'query)))
    (define gerbil-ascent/candidate/provenance#positive-proof-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'work-budget)))
    (define gerbil-ascent/candidate/provenance#positive-proof-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#positive-proof-roots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'roots)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'status)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-query
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'query)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'work-budget)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-roots
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'roots)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'status)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'query)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'work-budget)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-roots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'roots)))
    (define gerbil-ascent/candidate/provenance#proof-node::t
      (let ((__tmp37209 (list)) (__tmp37208 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/provenance#proof-node::t
         'proof-node
         __tmp37209
         '(id kind relation row label inputs)
         __tmp37208
         '#f)))
    (define gerbil-ascent/candidate/provenance#proof-node?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/provenance#proof-node::t)))
    (define gerbil-ascent/candidate/provenance#make-proof-node
      (lambda _%$args29396%_
        (apply make-instance
               gerbil-ascent/candidate/provenance#proof-node::t
               _%$args29396%_)))
    (define gerbil-ascent/candidate/provenance#proof-node-id
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'id)))
    (define gerbil-ascent/candidate/provenance#proof-node-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'kind)))
    (define gerbil-ascent/candidate/provenance#proof-node-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#proof-node-row
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'row)))
    (define gerbil-ascent/candidate/provenance#proof-node-label
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'label)))
    (define gerbil-ascent/candidate/provenance#proof-node-inputs
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'inputs)))
    (define gerbil-ascent/candidate/provenance#proof-node-id-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'id)))
    (define gerbil-ascent/candidate/provenance#proof-node-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'kind)))
    (define gerbil-ascent/candidate/provenance#proof-node-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#proof-node-row-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'row)))
    (define gerbil-ascent/candidate/provenance#proof-node-label-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'label)))
    (define gerbil-ascent/candidate/provenance#proof-node-inputs-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'inputs)))
    (define gerbil-ascent/candidate/provenance#&proof-node-id
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'id)))
    (define gerbil-ascent/candidate/provenance#&proof-node-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'kind)))
    (define gerbil-ascent/candidate/provenance#&proof-node-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#&proof-node-row
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'row)))
    (define gerbil-ascent/candidate/provenance#&proof-node-label
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'label)))
    (define gerbil-ascent/candidate/provenance#&proof-node-inputs
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'inputs)))
    (define gerbil-ascent/candidate/provenance#&proof-node-id-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'id)))
    (define gerbil-ascent/candidate/provenance#&proof-node-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'kind)))
    (define gerbil-ascent/candidate/provenance#&proof-node-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#&proof-node-row-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'row)))
    (define gerbil-ascent/candidate/provenance#&proof-node-label-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'label)))
    (define gerbil-ascent/candidate/provenance#&proof-node-inputs-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'inputs)))
    (define gerbil-ascent/candidate/provenance#proof-relation::t
      (let ((__tmp37211 (list)) (__tmp37210 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/provenance#proof-relation::t
         'proof-relation
         __tmp37211
         '(nodes tail members)
         __tmp37210
         '#f)))
    (define gerbil-ascent/candidate/provenance#proof-relation?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/provenance#proof-relation::t)))
    (define gerbil-ascent/candidate/provenance#make-proof-relation
      (lambda _%$args29393%_
        (apply make-instance
               gerbil-ascent/candidate/provenance#proof-relation::t
               _%$args29393%_)))
    (define gerbil-ascent/candidate/provenance#proof-relation-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#proof-relation-tail
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'tail)))
    (define gerbil-ascent/candidate/provenance#proof-relation-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'members)))
    (define gerbil-ascent/candidate/provenance#proof-relation-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#proof-relation-tail-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'tail)))
    (define gerbil-ascent/candidate/provenance#proof-relation-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'members)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-tail
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'tail)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'members)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-tail-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'tail)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'members)))
    (define gerbil-ascent/candidate/provenance#positive-atom?
      (lambda (_%atom29391%_)
        (if (pair? _%atom29391%_)
            (if (symbol? (let () (declare (not safe)) (##car _%atom29391%_)))
                (not (let ((__tmp37212
                            (let ()
                              (declare (not safe))
                              (##car _%atom29391%_))))
                       (declare (not safe))
                       (##memq __tmp37212 '(not where compute reduce))))
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/provenance#positive-fixed-clause?
      (lambda (_%clause29380%_)
        (if (list? _%clause29380%_)
            (if (pair? _%clause29380%_)
                (let ((_%$e29382%_
                       (let () (declare (not safe)) (##car _%clause29380%_))))
                  (if (eq? 'where _%$e29382%_)
                      (if (= (let ()
                               (declare (not safe))
                               (##length _%clause29380%_))
                             '2)
                          (if (list? (cadr _%clause29380%_))
                              (if (pair? (cadr _%clause29380%_))
                                  (let ((_%$e29385%_ (caadr _%clause29380%_)))
                                    (if (eq? 'even? _%$e29385%_)
                                        (= (length (cadr _%clause29380%_)) '2)
                                        (if (eq? '< _%$e29385%_)
                                            (= (length (cadr _%clause29380%_))
                                               '3)
                                            '#f)))
                                  '#f)
                              '#f)
                          '#f)
                      (if (eq? 'compute _%$e29382%_)
                          (if (= (let ()
                                   (declare (not safe))
                                   (##length _%clause29380%_))
                                 '3)
                              (if (let ((__tmp37213 (cadr _%clause29380%_)))
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/program#candidate-variable?
                                     __tmp37213))
                                  (if (list? (caddr _%clause29380%_))
                                      (if (pair? (caddr _%clause29380%_))
                                          (let ((_%$e29388%_
                                                 (caaddr _%clause29380%_)))
                                            (if (eq? 'identity _%$e29388%_)
                                                (= (length (caddr _%clause29380%_))
                                                   '2)
                                                (if (eq? '+ _%$e29388%_)
                                                    (= (length (caddr _%clause29380%_))
                                                       '3)
                                                    '#f)))
                                          '#f)
                                      '#f)
                                  '#f)
                              '#f)
                          '#f)))
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/provenance#positive-rule-body?
      (lambda (_%rule29373%_)
        (let ((__tmp37215
               (lambda (_%clause29375%_)
                 (let ((_%$e29377%_
                        (gerbil-ascent/candidate/provenance#positive-atom?
                         _%clause29375%_)))
                   (if _%$e29377%_
                       _%$e29377%_
                       (gerbil-ascent/candidate/provenance#positive-fixed-clause?
                        _%clause29375%_)))))
              (__tmp37214 (vector-ref _%rule29373%_ '1)))
          (declare (not safe))
          (andmap__0 __tmp37215 __tmp37214))))
    (define gerbil-ascent/candidate/provenance#positive-rules?
      (lambda (_%spec29371%_)
        (let ((__tmp37216
               (##structure-ref
                _%spec29371%_
                '3
                gerbil-ascent/candidate/types#reasoning-candidate::t
                '#f)))
          (declare (not safe))
          (andmap__0
           gerbil-ascent/candidate/provenance#positive-rule-body?
           __tmp37216))))
    (define gerbil-ascent/candidate/provenance#instantiate-head
      (lambda (_%head29366%_ _%bindings29367%_)
        (map (lambda (_%term29369%_)
               (if (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/program#candidate-variable?
                      _%term29369%_))
                   (cdr (assq _%term29369%_ _%bindings29367%_))
                   _%term29369%_))
             (cdr _%head29366%_))))
    (define gerbil-ascent/candidate/provenance#candidate-positive-proof/option
      (lambda (_%snapshot29190%_
               _%spec29191%_
               _%candidate-digest29192%_
               _%native-status29193%_
               _%native-rows29194%_
               _%max-steps29195%_
               _%retain-closed-absence?29196%_)
        (if (and (exact-integer? _%max-steps29195%_) (> _%max-steps29195%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid positive proof work budget"
                     _%max-steps29195%_)))
        (let ((_%query29198%_
               (vector-ref
                (##structure-ref
                 _%spec29191%_
                 '4
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f)
                '0)))
          (letrec ((_%result29200%_
                    (lambda (_%status29362%_ _%nodes29363%_ _%roots29364%_)
                      (let ((__tmp37220
                             (##structure-ref
                              _%snapshot29190%_
                              '1
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp37219
                             (##structure-ref
                              _%snapshot29190%_
                              '2
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp37218
                             (##structure-ref
                              _%snapshot29190%_
                              '3
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp37217
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                _%query29198%_))))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/provenance#positive-proof::t
                         _%status29362%_
                         __tmp37220
                         __tmp37219
                         __tmp37218
                         _%candidate-digest29192%_
                         __tmp37217
                         _%max-steps29195%_
                         _%nodes29363%_
                         _%roots29364%_)))))
            (if (or (not (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                            _%snapshot29190%_)))
                    (not (eq? _%native-status29193%_ 'complete))
                    (not (gerbil-ascent/candidate/provenance#positive-rules?
                          _%spec29191%_)))
                (_%result29200%_ 'unsupported '() '())
                (let ((_%index29208%_
                       (let ()
                         (declare (not safe))
                         (make-hash-table__%
                          '#f
                          absent-value
                          absent-value
                          absent-value
                          absent-value
                          absent-value
                          absent-value
                          absent-value
                          absent-value)))
                      (_%plans29209%_
                       (map gerbil-ascent/candidate/grounding-plan#prepare-grounding-rule
                            (##structure-ref
                             _%spec29191%_
                             '3
                             gerbil-ascent/candidate/types#reasoning-candidate::t
                             '#f)))
                      (_%query-match29210%_
                       (let ()
                         (declare (not safe))
                         (gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
                          _%query29198%_)))
                      (_%nodes29211%_ '())
                      (_%next-id29212%_ '0)
                      (_%derived-count29213%_ '0)
                      (_%steps29214%_ '0)
                      (_%material29215%_
                       (if _%retain-closed-absence?29196%_
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/candidate/certificate-limits#make-certificate-material-budget))
                           '#f))
                      (_%bounded?29216%_ '#f)
                      (_%derived-limit29217%_
                       (cadr (##structure-ref
                              _%spec29191%_
                              '5
                              gerbil-ascent/candidate/types#reasoning-candidate::t
                              '#f))))
                  (letrec ((_%facts29219%_
                            (lambda (_%name29358%_)
                              (let ((_%relation29360%_
                                     (let ()
                                       (declare (not safe))
                                       (__hash-get
                                        _%index29208%_
                                        _%name29358%_))))
                                (if _%relation29360%_
                                    (##structure-ref
                                     _%relation29360%_
                                     '1
                                     gerbil-ascent/candidate/provenance#proof-relation::t
                                     '#f)
                                    '()))))
                           (_%active?29220%_
                            (lambda () (not _%bounded?29216%_)))
                           (_%known?29221%_
                            (lambda (_%name29352%_ _%row29353%_)
                              (let ((_%relation29355%_
                                     (let ()
                                       (declare (not safe))
                                       (__hash-get
                                        _%index29208%_
                                        _%name29352%_))))
                                (if _%relation29355%_
                                    (let ((__tmp37221
                                           (##structure-ref
                                            _%relation29355%_
                                            '3
                                            gerbil-ascent/candidate/provenance#proof-relation::t
                                            '#f)))
                                      (declare (not safe))
                                      (hash-get __tmp37221 _%row29353%_))
                                    '#f))))
                           (_%reserve-row!29222%_
                            (lambda (_%row29344%_)
                              (let ((_%$e29346%_ (not _%material29215%_)))
                                (if _%$e29346%_
                                    _%$e29346%_
                                    (let ((_%$e29349%_
                                           (let ()
                                             (declare (not safe))
                                             (gerbil-ascent/candidate/certificate-limits#certificate-material-reserve!
                                              _%material29215%_
                                              _%row29344%_))))
                                      (if _%$e29349%_
                                          _%$e29349%_
                                          (begin
                                            (set! _%bounded?29216%_ '#t)
                                            '#f)))))))
                           (_%install!29223%_
                            (lambda (_%node29330%_)
                              (let* ((_%name29332%_
                                      (##structure-ref
                                       _%node29330%_
                                       '3
                                       gerbil-ascent/candidate/provenance#proof-node::t
                                       '#f))
                                     (_%relation29339%_
                                      (let ((_%$e29334%_
                                             (let ()
                                               (declare (not safe))
                                               (__hash-get
                                                _%index29208%_
                                                _%name29332%_))))
                                        (if _%$e29334%_
                                            _%$e29334%_
                                            (let ((_%owned29337%_
                                                   (let ((__tmp37222
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (make-hash-table__%
                                                             '#f
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value))))
                                                     (declare (not safe))
                                                     (##structure
                                                      gerbil-ascent/candidate/provenance#proof-relation::t
                                                      '()
                                                      '#f
                                                      __tmp37222))))
                                              (let ()
                                                (declare (not safe))
                                                (__hash-put!
                                                 _%index29208%_
                                                 _%name29332%_
                                                 _%owned29337%_))
                                              _%owned29337%_))))
                                     (_%cell29341%_ (list _%node29330%_)))
                                (if (##structure-ref
                                     _%relation29339%_
                                     '2
                                     gerbil-ascent/candidate/provenance#proof-relation::t
                                     '#f)
                                    (set-cdr!
                                     (##structure-ref
                                      _%relation29339%_
                                      '2
                                      gerbil-ascent/candidate/provenance#proof-relation::t
                                      '#f)
                                     _%cell29341%_)
                                    (##structure-set!
                                     _%relation29339%_
                                     _%cell29341%_
                                     '1
                                     gerbil-ascent/candidate/provenance#proof-relation::t
                                     '#f))
                                (##structure-set!
                                 _%relation29339%_
                                 _%cell29341%_
                                 '2
                                 gerbil-ascent/candidate/provenance#proof-relation::t
                                 '#f)
                                (let ((__tmp37224
                                       (##structure-ref
                                        _%relation29339%_
                                        '3
                                        gerbil-ascent/candidate/provenance#proof-relation::t
                                        '#f))
                                      (__tmp37223
                                       (##structure-ref
                                        _%node29330%_
                                        '4
                                        gerbil-ascent/candidate/provenance#proof-node::t
                                        '#f)))
                                  (declare (not safe))
                                  (hash-put!
                                   __tmp37224
                                   __tmp37223
                                   _%node29330%_))
                                (set! _%nodes29211%_
                                      (cons _%node29330%_ _%nodes29211%_)))))
                           (_%add!29224%_
                            (lambda (_%kind29322%_
                                     _%name29323%_
                                     _%row29324%_
                                     _%label29325%_
                                     _%inputs29326%_)
                              (if (if _%bounded?29216%_
                                      '#f
                                      (if (_%known?29221%_
                                           _%name29323%_
                                           _%row29324%_)
                                          '#f
                                          (_%reserve-row!29222%_
                                           _%row29324%_)))
                                  (let ((_%node29328%_
                                         (let ((__tmp37226
                                                (let ()
                                                  (declare (not safe))
                                                  (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                                   _%row29324%_)))
                                               (__tmp37225
                                                (let ()
                                                  (declare (not safe))
                                                  (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                                   _%inputs29326%_))))
                                           (declare (not safe))
                                           (##structure
                                            gerbil-ascent/candidate/provenance#proof-node::t
                                            _%next-id29212%_
                                            _%kind29322%_
                                            _%name29323%_
                                            __tmp37226
                                            _%label29325%_
                                            __tmp37225))))
                                    (set! _%next-id29212%_
                                          (+ _%next-id29212%_ '1))
                                    (_%install!29223%_ _%node29328%_))
                                  '#!void))))
                    (let ((__tmp37228
                           (lambda (_%entry29226%_)
                             (let ((_%position29228%_ '0))
                               (let ((__tmp37230
                                      (lambda (_%row29230%_)
                                        (set! _%position29228%_
                                              (+ _%position29228%_ '1))
                                        (_%add!29224%_
                                         'source
                                         (car _%entry29226%_)
                                         _%row29230%_
                                         _%position29228%_
                                         '())))
                                     (__tmp37229 (caddr _%entry29226%_)))
                                 (declare (not safe))
                                 (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                                  _%active?29220%_
                                  __tmp37230
                                  __tmp37229)))))
                          (__tmp37227
                           (##structure-ref
                            _%snapshot29190%_
                            '4
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f)))
                      (declare (not safe))
                      (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                       _%active?29220%_
                       __tmp37228
                       __tmp37227))
                    (let ((__tmp37232
                           (lambda (_%fact29232%_)
                             (_%add!29224%_
                              'candidate
                              (vector-ref _%fact29232%_ '0)
                              (vector-ref _%fact29232%_ '1)
                              (vector-ref _%fact29232%_ '2)
                              '())))
                          (__tmp37231
                           (##structure-ref
                            _%spec29191%_
                            '2
                            gerbil-ascent/candidate/types#reasoning-candidate::t
                            '#f)))
                      (declare (not safe))
                      (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                       _%active?29220%_
                       __tmp37232
                       __tmp37231))
                    (let _%saturate29234%_ ()
                      (let ((_%pending29237%_ '())
                            (_%pending-count29238%_ '0)
                            (_%pending-index29239%_ '#f))
                        (let ((__tmp37233
                               (lambda (_%rule29241%_)
                                 (let ((_%rule29244%_ _%rule29241%_))
                                   (let ((_%name29261%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%rule29244%_
                                             '1
                                             '#f
                                             '#f)))
                                         (_%render29262%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%rule29244%_
                                             '2
                                             '#f
                                             '#f)))
                                         (_%body29263%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%rule29244%_
                                             '3
                                             '#f
                                             '#f)))
                                         (_%label29264%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%rule29244%_
                                             '4
                                             '#f
                                             '#f))))
                                     (letrec ((_%walk29266%_
                                               (lambda (_%remaining29268%_
                                                        _%bindings29269%_
                                                        _%inputs29270%_)
                                                 (if _%bounded?29216%_
                                                     '#!void
                                                     (if (null? _%remaining29268%_)
                                                         (let ((_%row29272%_
                                                                (_%render29262%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%bindings29269%_)))
                   (if (or (_%known?29221%_ _%name29261%_ _%row29272%_)
                           (let ((_%members29277%_
                                  (and _%pending-index29239%_
                                       (let ()
                                         (declare (not safe))
                                         (hash-get
                                          _%pending-index29239%_
                                          _%name29261%_)))))
                             (and _%members29277%_
                                  (let ()
                                    (declare (not safe))
                                    (hash-get
                                     _%members29277%_
                                     _%row29272%_)))))
                       '#!void
                       (begin
                         (if (>= (+ _%derived-count29213%_
                                    _%pending-count29238%_)
                                 _%derived-limit29217%_)
                             (set! _%bounded?29216%_ '#t)
                             '#!void)
                         (if (if _%bounded?29216%_
                                 '#f
                                 (_%reserve-row!29222%_ _%row29272%_))
                             (let* ((_%node29279%_
                                     (let ((__tmp37236
                                            (+ _%next-id29212%_
                                               _%pending-count29238%_))
                                           (__tmp37235
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                               _%row29272%_)))
                                           (__tmp37234
                                            (reverse _%inputs29270%_)))
                                       (declare (not safe))
                                       (##structure
                                        gerbil-ascent/candidate/provenance#proof-node::t
                                        __tmp37236
                                        'rule
                                        _%name29261%_
                                        __tmp37235
                                        _%label29264%_
                                        __tmp37234)))
                                    (_%members29286%_
                                     (let ((_%$e29281%_
                                            (if _%pending-index29239%_
                                                (let ()
                                                  (declare (not safe))
                                                  (hash-get
                                                   _%pending-index29239%_
                                                   _%name29261%_))
                                                '#f)))
                                       (if _%$e29281%_
                                           _%$e29281%_
                                           (let ((_%table29284%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (make-hash-table__%
                                                     '#f
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value))))
                                             (if _%pending-index29239%_
                                                 '#!void
                                                 (set! _%pending-index29239%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (make-hash-table-eq))))
                                             (let ()
                                               (declare (not safe))
                                               (hash-put!
                                                _%pending-index29239%_
                                                _%name29261%_
                                                _%table29284%_))
                                             _%table29284%_)))))
                               (let ((__tmp37237
                                      (let ()
                                        (declare (not safe))
                                        (##unchecked-structure-ref
                                         _%node29279%_
                                         '4
                                         '#f
                                         '#f))))
                                 (declare (not safe))
                                 (hash-put!
                                  _%members29286%_
                                  __tmp37237
                                  _%node29279%_))
                               (set! _%pending29237%_
                                     (cons _%node29279%_ _%pending29237%_))
                               (set! _%pending-count29238%_
                                     (+ _%pending-count29238%_ '1)))
                             '#!void))))
                 (let* ((_%clause29289%_ (car _%remaining29268%_))
                        (_%clause29291%_ _%clause29289%_))
                   (if (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%clause29291%_
                          '1
                          '#f
                          '#f))
                       (let ((__tmp37239
                              (lambda (_%node29306%_)
                                (if _%bounded?29216%_
                                    '#!void
                                    (begin
                                      (set! _%steps29214%_
                                            (+ _%steps29214%_ '1))
                                      (if (> _%steps29214%_ _%max-steps29195%_)
                                          (set! _%bounded?29216%_ '#t)
                                          (let ((_%next29308%_
                                                 ((let ()
                                                    (declare (not safe))
                                                    (##unchecked-structure-ref
                                                     _%clause29291%_
                                                     '2
                                                     '#f
                                                     '#f))
                                                  (##structure-ref
                                                   _%node29306%_
                                                   '4
                                                   gerbil-ascent/candidate/provenance#proof-node::t
                                                   '#f)
                                                  _%bindings29269%_)))
                                            (if _%next29308%_
                                                (_%walk29266%_
                                                 (cdr _%remaining29268%_)
                                                 _%next29308%_
                                                 (cons (##structure-ref
                                                        _%node29306%_
                                                        '1
                                                        gerbil-ascent/candidate/provenance#proof-node::t
                                                        '#f)
                                                       _%inputs29270%_))
                                                '#!void)))))))
                             (__tmp37238
                              (_%facts29219%_
                               (let ()
                                 (declare (not safe))
                                 (##unchecked-structure-ref
                                  _%clause29291%_
                                  '1
                                  '#f
                                  '#f)))))
                         (declare (not safe))
                         (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                          _%active?29220%_
                          __tmp37239
                          __tmp37238))
                       (begin
                         (set! _%steps29214%_ (+ _%steps29214%_ '1))
                         (if (> _%steps29214%_ _%max-steps29195%_)
                             (set! _%bounded?29216%_ '#t)
                             (let ((_%next29304%_
                                    ((let ()
                                       (declare (not safe))
                                       (##unchecked-structure-ref
                                        _%clause29291%_
                                        '2
                                        '#f
                                        '#f))
                                     _%bindings29269%_)))
                               (if _%next29304%_
                                   (_%walk29266%_
                                    (cdr _%remaining29268%_)
                                    _%next29304%_
                                    _%inputs29270%_)
                                   '#!void)))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                       (_%walk29266%_
                                        _%body29263%_
                                        '()
                                        '())))))))
                          (declare (not safe))
                          (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                           _%active?29220%_
                           __tmp37233
                           _%plans29209%_))
                        (if _%bounded?29216%_
                            (_%result29200%_ 'bounded '() '())
                            (if (null? _%pending29237%_)
                                (let* ((_%matching29312%_
                                        (filter (lambda (_%node29310%_)
                                                  (_%query-match29210%_
                                                   (##structure-ref
                                                    _%node29310%_
                                                    '4
                                                    gerbil-ascent/candidate/provenance#proof-node::t
                                                    '#f)
                                                   '()))
                                                (_%facts29219%_
                                                 (car _%query29198%_))))
                                       (_%rows29314%_
                                        (let ()
                                          (declare (not safe))
                                          (##map gerbil-ascent/candidate/provenance#proof-node-row
                                                 _%matching29312%_)))
                                       (_%roots29316%_
                                        (let ()
                                          (declare (not safe))
                                          (##map gerbil-ascent/candidate/provenance#proof-node-id
                                                 _%matching29312%_))))
                                  (if (and (pair? _%roots29316%_)
                                           (let ()
                                             (declare (not safe))
                                             (gerbil-ascent/candidate/funs#candidate-same-row-set?
                                              _%rows29314%_
                                              _%native-rows29194%_)))
                                      (_%result29200%_
                                       'complete
                                       (let ()
                                         (declare (not safe))
                                         (##reverse _%nodes29211%_))
                                       _%roots29316%_)
                                      (if (and _%retain-closed-absence?29196%_
                                               (null? _%roots29316%_)
                                               (null? _%native-rows29194%_))
                                          (_%result29200%_
                                           'closed-absent
                                           (let ()
                                             (declare (not safe))
                                             (##reverse _%nodes29211%_))
                                           '())
                                          (_%result29200%_
                                           'unsupported
                                           '()
                                           '()))))
                                (begin
                                  (let ((__tmp37240
                                         (let ()
                                           (declare (not safe))
                                           (##reverse _%pending29237%_))))
                                    (declare (not safe))
                                    (##for-each _%install!29223%_ __tmp37240))
                                  (set! _%next-id29212%_
                                        (+ _%next-id29212%_
                                           _%pending-count29238%_))
                                  (set! _%derived-count29213%_
                                        (+ _%derived-count29213%_
                                           _%pending-count29238%_))
                                  (_%saturate29234%_)))))))))))))
    (define gerbil-ascent/candidate/provenance#candidate-positive-proof
      (lambda (_%snapshot29183%_
               _%spec29184%_
               _%candidate-digest29185%_
               _%native-status29186%_
               _%native-rows29187%_
               _%max-steps29188%_)
        (gerbil-ascent/candidate/provenance#candidate-positive-proof/option
         _%snapshot29183%_
         _%spec29184%_
         _%candidate-digest29185%_
         _%native-status29186%_
         _%native-rows29187%_
         _%max-steps29188%_
         '#f)))
    (define gerbil-ascent/candidate/provenance#candidate-positive-closed-absence
      (lambda (_%snapshot29176%_
               _%spec29177%_
               _%candidate-digest29178%_
               _%native-status29179%_
               _%native-rows29180%_
               _%max-steps29181%_)
        (gerbil-ascent/candidate/provenance#candidate-positive-proof/option
         _%snapshot29176%_
         _%spec29177%_
         _%candidate-digest29178%_
         _%native-status29179%_
         _%native-rows29180%_
         _%max-steps29181%_
         '#t)))
    (define gerbil-ascent/candidate/provenance#proof-metadata-lookup
      (lambda (_%entries29124%_)
        (let* ((_%$%entries2912529135%_ _%entries29124%_)
               (_%$%else2912829149%_
                (lambda ()
                  (let ((_%index29143%_
                         (let ()
                           (declare (not safe))
                           (make-hash-table__%
                            '#f
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value))))
                    (for-each
                     (lambda (_%entry29145%_)
                       (if (let ((__tmp37241 (car _%entry29145%_)))
                             (declare (not safe))
                             (__hash-get _%index29143%_ __tmp37241))
                           '#!void
                           (let ((__tmp37243 (car _%entry29145%_))
                                 (__tmp37242 (cdr _%entry29145%_)))
                             (declare (not safe))
                             (__hash-put!
                              _%index29143%_
                              __tmp37243
                              __tmp37242))))
                     _%entries29124%_)
                    (lambda (_%key29147%_)
                      (let ()
                        (declare (not safe))
                        (__hash-get _%index29143%_ _%key29147%_)))))))
          (let ((_%$%K2913329173%_ (lambda () (lambda (_%_29171%_) '#f)))
                (_%$%K2913029157%_
                 (lambda (_%entry29153%_)
                   (lambda (_%key29155%_)
                     (if (equal? _%key29155%_ (car _%entry29153%_))
                         (cdr _%entry29153%_)
                         '#f)))))
            (let ((_%$%try-match2912729167%_
                   (lambda ()
                     (if (pair? _%$%entries2912529135%_)
                         (let ((_%$%tl2913229162%_
                                (let ()
                                  (declare (not safe))
                                  (##cdr _%$%entries2912529135%_)))
                               (_%$%hd2913129160%_
                                (let ()
                                  (declare (not safe))
                                  (##car _%$%entries2912529135%_))))
                           (if (null? _%$%tl2913229162%_)
                               (let ((_%entry29165%_ _%$%hd2913129160%_))
                                 (_%$%K2913029157%_ _%entry29165%_))
                               (_%$%else2912829149%_)))
                         (_%$%else2912829149%_)))))
              (if (null? _%$%entries2912529135%_)
                  (_%$%K2913329173%_)
                  (_%$%try-match2912729167%_)))))))
    (define gerbil-ascent/candidate/provenance#candidate-verify-positive-proof
      (lambda (_%snapshot29037%_
               _%spec29038%_
               _%candidate-digest29039%_
               _%native-status29040%_
               _%native-rows29041%_
               _%proof29042%_
               _%max-nodes29043%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%proof29042%_
               'gerbil-ascent/candidate/provenance#positive-proof::t))
            (if (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                   _%snapshot29037%_))
                (if (eq? (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%proof29042%_
                            '1
                            '#f
                            '#f))
                         'complete)
                    (if (eq? _%native-status29040%_ 'complete)
                        (if (gerbil-ascent/candidate/provenance#positive-rules?
                             _%spec29038%_)
                            (if (exact-integer? _%max-nodes29043%_)
                                (if (> _%max-nodes29043%_ '0)
                                    (if (equal? (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%proof29042%_
                                                   '2
                                                   '#f
                                                   '#f))
                                                (##structure-ref
                                                 _%snapshot29037%_
                                                 '1
                                                 gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                 '#f))
                                        (if (equal? (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%proof29042%_
                                                       '3
                                                       '#f
                                                       '#f))
                                                    (##structure-ref
                                                     _%snapshot29037%_
                                                     '2
                                                     gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                     '#f))
                                            (if (equal? (let ()
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           _%proof29042%_
                                                           '4
                                                           '#f
                                                           '#f))
                                                        (##structure-ref
                                                         _%snapshot29037%_
                                                         '3
                                                         gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                         '#f))
                                                (if (equal? (let ()
                                                              (declare
                                                                (not safe))
                                                              (##unchecked-structure-ref
                                                               _%proof29042%_
                                                               '5
                                                               '#f
                                                               '#f))
                                                            _%candidate-digest29039%_)
                                                    (if (equal? (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%proof29042%_
                           '6
                           '#f
                           '#f))
                        (vector-ref
                         (##structure-ref
                          _%spec29038%_
                          '4
                          gerbil-ascent/candidate/types#reasoning-candidate::t
                          '#f)
                         '0))
                (let* ((_%nodes29045%_
                        (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%proof29042%_
                           '8
                           '#f
                           '#f)))
                       (_%node-count29047%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                           _%nodes29045%_
                           _%max-nodes29043%_))))
                  (if _%node-count29047%_
                      (if (let ((__tmp37244
                                 (let ()
                                   (declare (not safe))
                                   (##unchecked-structure-ref
                                    _%proof29042%_
                                    '9
                                    '#f
                                    '#f))))
                            (declare (not safe))
                            (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                             __tmp37244
                             _%node-count29047%_))
                          (let* ((_%by-id29050%_
                                  (make-vector _%node-count29047%_ '#f))
                                 (_%arities29052%_
                                  (gerbil-ascent/candidate/provenance#proof-metadata-lookup
                                   (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/funs#candidate-schema-of
                                      _%snapshot29037%_
                                      _%spec29038%_))))
                                 (_%source29054%_
                                  (##structure-ref
                                   _%snapshot29037%_
                                   '4
                                   gerbil-ascent/candidate/types#reasoning-snapshot::t
                                   '#f))
                                 (_%facts29056%_
                                  (##structure-ref
                                   _%spec29038%_
                                   '2
                                   gerbil-ascent/candidate/types#reasoning-candidate::t
                                   '#f))
                                 (_%rules29058%_
                                  (##structure-ref
                                   _%spec29038%_
                                   '3
                                   gerbil-ascent/candidate/types#reasoning-candidate::t
                                   '#f))
                                 (_%query29060%_
                                  (let ()
                                    (declare (not safe))
                                    (##unchecked-structure-ref
                                     _%proof29042%_
                                     '6
                                     '#f
                                     '#f)))
                                 (_%source-rows29064%_
                                  (gerbil-ascent/candidate/provenance#proof-metadata-lookup
                                   (map (lambda (_%entry29062%_)
                                          (cons (car _%entry29062%_)
                                                (list->vector
                                                 (caddr _%entry29062%_))))
                                        _%source29054%_)))
                                 (_%fact-keys29066%_
                                  (if (pair? _%facts29056%_)
                                      (let ()
                                        (declare (not safe))
                                        (make-hash-table__%
                                         '#f
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value))
                                      '#f))
                                 (_%rule-labels29070%_
                                  (gerbil-ascent/candidate/provenance#proof-metadata-lookup
                                   (map (lambda (_%rule29068%_)
                                          (cons (vector-ref _%rule29068%_ '2)
                                                (cons _%rule29068%_
                                                      (let ((__tmp37245
                                                             (filter gerbil-ascent/candidate/provenance#positive-atom?
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (vector-ref _%rule29068%_ '1))))
                (declare (not safe))
                (##length __tmp37245)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        _%rules29058%_))))
                            (for-each
                             (lambda (_%fact29073%_)
                               (let ((__tmp37246
                                      (list (vector-ref _%fact29073%_ '2)
                                            (vector-ref _%fact29073%_ '0)
                                            (vector-ref _%fact29073%_ '1))))
                                 (declare (not safe))
                                 (hash-put!
                                  _%fact-keys29066%_
                                  __tmp37246
                                  '#t)))
                             _%facts29056%_)
                            (letrec ((_%existing-input?29075%_
                                      (lambda (_%id29121%_ _%before29122%_)
                                        (if (exact-integer? _%id29121%_)
                                            (if (<= '0 _%id29121%_)
                                                (< _%id29121%_ _%before29122%_)
                                                '#f)
                                            '#f)))
                                     (_%node-valid?29076%_
                                      (lambda (_%node29090%_ _%index29091%_)
                                        (if (let ()
                                              (declare (not safe))
                                              (##structure-instance-of?
                                               _%node29090%_
                                               'gerbil-ascent/candidate/provenance#proof-node::t))
                                            (if (exact-integer?
                                                 (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%node29090%_
                                                    '1
                                                    '#f
                                                    '#f)))
                                                (if (= (let ()
                                                         (declare (not safe))
                                                         (##unchecked-structure-ref
                                                          _%node29090%_
                                                          '1
                                                          '#f
                                                          '#f))
                                                       _%index29091%_)
                                                    (if (symbol? (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%node29090%_
                            '3
                            '#f
                            '#f)))
                (if (let ((_%arity29093%_
                           (let ((__tmp37247
                                  (let ()
                                    (declare (not safe))
                                    (##unchecked-structure-ref
                                     _%node29090%_
                                     '3
                                     '#f
                                     '#f))))
                             (declare (not safe))
                             (_%arities29052%_ __tmp37247))))
                      (and _%arity29093%_
                           (equal? (let ((__tmp37248
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%node29090%_
                                             '4
                                             '#f
                                             '#f))))
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                                      __tmp37248
                                      _%arity29093%_))
                                   _%arity29093%_)))
                    (let ((_%$e29095%_
                           (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%node29090%_
                              '2
                              '#f
                              '#f))))
                      (if (eq? 'source _%$e29095%_)
                          (if (null? (let ()
                                       (declare (not safe))
                                       (##unchecked-structure-ref
                                        _%node29090%_
                                        '6
                                        '#f
                                        '#f)))
                              (let ((_%rows29098%_
                                     (let ((__tmp37249
                                            (let ()
                                              (declare (not safe))
                                              (##unchecked-structure-ref
                                               _%node29090%_
                                               '3
                                               '#f
                                               '#f))))
                                       (declare (not safe))
                                       (_%source-rows29064%_ __tmp37249))))
                                (if _%rows29098%_
                                    (if (exact-integer?
                                         (let ()
                                           (declare (not safe))
                                           (##unchecked-structure-ref
                                            _%node29090%_
                                            '5
                                            '#f
                                            '#f)))
                                        (if (<= '1
                                                (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%node29090%_
                                                   '5
                                                   '#f
                                                   '#f)))
                                            (if (<= (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%node29090%_
                                                       '5
                                                       '#f
                                                       '#f))
                                                    (vector-length
                                                     _%rows29098%_))
                                                (equal? (let ()
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           _%node29090%_
                                                           '4
                                                           '#f
                                                           '#f))
                                                        (vector-ref
                                                         _%rows29098%_
                                                         (- (let ()
                                                              (declare
                                                                (not safe))
                                                              (##unchecked-structure-ref
                                                               _%node29090%_
                                                               '5
                                                               '#f
                                                               '#f))
                                                            '1)))
                                                '#f)
                                            '#f)
                                        '#f)
                                    '#f))
                              '#f)
                          (if (eq? 'candidate _%$e29095%_)
                              (if (null? (let ()
                                           (declare (not safe))
                                           (##unchecked-structure-ref
                                            _%node29090%_
                                            '6
                                            '#f
                                            '#f)))
                                  (if _%fact-keys29066%_
                                      (let ((__tmp37250
                                             (list (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%node29090%_
                                                      '5
                                                      '#f
                                                      '#f))
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%node29090%_
                                                      '3
                                                      '#f
                                                      '#f))
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%node29090%_
                                                      '4
                                                      '#f
                                                      '#f)))))
                                        (declare (not safe))
                                        (__hash-get
                                         _%fact-keys29066%_
                                         __tmp37250))
                                      '#f)
                                  '#f)
                              (if (eq? 'rule _%$e29095%_)
                                  (let* ((_%entry29100%_
                                          (let ((__tmp37251
                                                 (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%node29090%_
                                                    '5
                                                    '#f
                                                    '#f))))
                                            (declare (not safe))
                                            (_%rule-labels29070%_ __tmp37251)))
                                         (_%rule29102%_
                                          (if _%entry29100%_
                                              (car _%entry29100%_)
                                              '#f)))
                                    (if _%rule29102%_
                                        (if (eq? (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%node29090%_
                                                    '3
                                                    '#f
                                                    '#f))
                                                 (car (vector-ref
                                                       _%rule29102%_
                                                       '0)))
                                            (if (equal? (let ((__tmp37253
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (##unchecked-structure-ref _%node29090%_ '6 '#f '#f)))
                      (__tmp37252 (cdr _%entry29100%_)))
                  (declare (not safe))
                  (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                   __tmp37253
                   __tmp37252))
                (cdr _%entry29100%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (let _%loop29105%_ ((_%clauses29107%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (vector-ref _%rule29102%_ '1))
                            (_%inputs29108%_
                             (let ()
                               (declare (not safe))
                               (##unchecked-structure-ref
                                _%node29090%_
                                '6
                                '#f
                                '#f)))
                            (_%bindings29109%_ '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (null? _%clauses29107%_)
                                                      (if (null? _%inputs29108%_)
                                                          (equal? (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (declare (not safe))
                            (##unchecked-structure-ref
                             _%node29090%_
                             '4
                             '#f
                             '#f))
                          (gerbil-ascent/candidate/provenance#instantiate-head
                           (vector-ref _%rule29102%_ '0)
                           _%bindings29109%_))
                  '#f)
              (let ((_%clause29111%_ (car _%clauses29107%_)))
                (if (gerbil-ascent/candidate/provenance#positive-fixed-clause?
                     _%clause29111%_)
                    (let ((_%next29113%_
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/candidate/funs#candidate-fixed-clause
                              _%clause29111%_
                              _%bindings29109%_))))
                      (if _%next29113%_
                          (_%loop29105%_
                           (cdr _%clauses29107%_)
                           _%inputs29108%_
                           _%next29113%_)
                          '#f))
                    (let ((_%id29115%_ (car _%inputs29108%_)))
                      (if (_%existing-input?29075%_ _%id29115%_ _%index29091%_)
                          (let ((_%input29117%_
                                 (vector-ref _%by-id29050%_ _%id29115%_)))
                            (if (eq? (##structure-ref
                                      _%input29117%_
                                      '3
                                      gerbil-ascent/candidate/provenance#proof-node::t
                                      '#f)
                                     (car _%clause29111%_))
                                (let ((_%next29119%_
                                       (let ((__tmp37254
                                              (##structure-ref
                                               _%input29117%_
                                               '4
                                               gerbil-ascent/candidate/provenance#proof-node::t
                                               '#f)))
                                         (declare (not safe))
                                         (gerbil-ascent/candidate/funs#candidate-bind-atom
                                          _%clause29111%_
                                          __tmp37254
                                          _%bindings29109%_))))
                                  (if _%next29119%_
                                      (_%loop29105%_
                                       (cdr _%clauses29107%_)
                                       (cdr _%inputs29108%_)
                                       _%next29119%_)
                                      '#f))
                                '#f))
                          '#f))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                '#f)
                                            '#f)
                                        '#f))
                                  '#f))))
                    '#f)
                '#f)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '#f)
                                                '#f)
                                            '#f))))
                              (if (let _%loop29078%_ ((_%remaining29080%_
                                                       _%nodes29045%_)
                                                      (_%index29081%_ '0))
                                    (or (null? _%remaining29080%_)
                                        (and (_%node-valid?29076%_
                                              (car _%remaining29080%_)
                                              _%index29081%_)
                                             (begin
                                               (vector-set!
                                                _%by-id29050%_
                                                _%index29081%_
                                                (car _%remaining29080%_))
                                               (_%loop29078%_
                                                (cdr _%remaining29080%_)
                                                (+ _%index29081%_ '1))))))
                                  (if (let ((__tmp37256
                                             (lambda (_%id29086%_)
                                               (and (_%existing-input?29075%_
                                                     _%id29086%_
                                                     _%node-count29047%_)
                                                    (eq? (##structure-ref
                                                          (vector-ref
                                                           _%by-id29050%_
                                                           _%id29086%_)
                                                          '3
                                                          gerbil-ascent/candidate/provenance#proof-node::t
                                                          '#f)
                                                         (car _%query29060%_))
                                                    (let ((__tmp37257
                                                           (##structure-ref
                                                            (vector-ref
                                                             _%by-id29050%_
                                                             _%id29086%_)
                                                            '4
                                                            gerbil-ascent/candidate/provenance#proof-node::t
                                                            '#f)))
                                                      (declare (not safe))
                                                      (gerbil-ascent/candidate/funs#candidate-bind-atom
                                                       _%query29060%_
                                                       __tmp37257
                                                       '())))))
                                            (__tmp37255
                                             (let ()
                                               (declare (not safe))
                                               (##unchecked-structure-ref
                                                _%proof29042%_
                                                '9
                                                '#f
                                                '#f))))
                                        (declare (not safe))
                                        (andmap__0 __tmp37256 __tmp37255))
                                      (let ((__tmp37258
                                             (map (lambda (_%id29088%_)
                                                    (##structure-ref
                                                     (vector-ref
                                                      _%by-id29050%_
                                                      _%id29088%_)
                                                     '4
                                                     gerbil-ascent/candidate/provenance#proof-node::t
                                                     '#f))
                                                  (let ()
                                                    (declare (not safe))
                                                    (##unchecked-structure-ref
                                                     _%proof29042%_
                                                     '9
                                                     '#f
                                                     '#f)))))
                                        (declare (not safe))
                                        (gerbil-ascent/candidate/funs#candidate-same-row-set?
                                         __tmp37258
                                         _%native-rows29041%_))
                                      '#f)
                                  '#f)))
                          '#f)
                      '#f))
                '#f)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '#f)
                                                '#f)
                                            '#f)
                                        '#f)
                                    '#f)
                                '#f)
                            '#f)
                        '#f)
                    '#f)
                '#f)
            '#f)))))
