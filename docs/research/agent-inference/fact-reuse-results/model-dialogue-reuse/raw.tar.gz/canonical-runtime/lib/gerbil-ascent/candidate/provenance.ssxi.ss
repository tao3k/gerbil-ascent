prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/candidate

(begin
  (declare-class
   gerbil-ascent/candidate/provenance#positive-proof::t
   (@class gerbil-ascent/candidate/provenance#positive-proof::t
           ()
           (object::t t::t)
           (status snapshot-identity
                   snapshot-generation
                   snapshot-digest
                   candidate-digest
                   query
                   work-budget
                   nodes
                   roots)
           (status snapshot-identity
                   snapshot-generation
                   snapshot-digest
                   candidate-digest
                   query
                   work-budget
                   nodes
                   roots)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/provenance#positive-proof::t)
    'class::t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof?
   (@predicate gerbil-ascent/candidate/provenance#positive-proof::t))
  (declare-type
   gerbil-ascent/candidate/provenance#make-positive-proof
   (@constructor gerbil-ascent/candidate/provenance#positive-proof::t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof-status
   (@accessor gerbil-ascent/candidate/provenance#positive-proof::t status #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof-snapshot-identity
   (@accessor
    gerbil-ascent/candidate/provenance#positive-proof::t
    snapshot-identity
    #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof-snapshot-generation
   (@accessor
    gerbil-ascent/candidate/provenance#positive-proof::t
    snapshot-generation
    #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof-snapshot-digest
   (@accessor
    gerbil-ascent/candidate/provenance#positive-proof::t
    snapshot-digest
    #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof-candidate-digest
   (@accessor
    gerbil-ascent/candidate/provenance#positive-proof::t
    candidate-digest
    #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof-query
   (@accessor gerbil-ascent/candidate/provenance#positive-proof::t query #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof-work-budget
   (@accessor
    gerbil-ascent/candidate/provenance#positive-proof::t
    work-budget
    #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof-nodes
   (@accessor gerbil-ascent/candidate/provenance#positive-proof::t nodes #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof-roots
   (@accessor gerbil-ascent/candidate/provenance#positive-proof::t roots #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof-status-set!
   (@mutator gerbil-ascent/candidate/provenance#positive-proof::t status #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof-snapshot-identity-set!
   (@mutator
    gerbil-ascent/candidate/provenance#positive-proof::t
    snapshot-identity
    #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof-snapshot-generation-set!
   (@mutator
    gerbil-ascent/candidate/provenance#positive-proof::t
    snapshot-generation
    #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof-snapshot-digest-set!
   (@mutator
    gerbil-ascent/candidate/provenance#positive-proof::t
    snapshot-digest
    #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof-candidate-digest-set!
   (@mutator
    gerbil-ascent/candidate/provenance#positive-proof::t
    candidate-digest
    #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof-query-set!
   (@mutator gerbil-ascent/candidate/provenance#positive-proof::t query #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof-work-budget-set!
   (@mutator
    gerbil-ascent/candidate/provenance#positive-proof::t
    work-budget
    #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof-nodes-set!
   (@mutator gerbil-ascent/candidate/provenance#positive-proof::t nodes #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-proof-roots-set!
   (@mutator gerbil-ascent/candidate/provenance#positive-proof::t roots #t))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-proof-status
   (@accessor gerbil-ascent/candidate/provenance#positive-proof::t status #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-proof-snapshot-identity
   (@accessor
    gerbil-ascent/candidate/provenance#positive-proof::t
    snapshot-identity
    #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-proof-snapshot-generation
   (@accessor
    gerbil-ascent/candidate/provenance#positive-proof::t
    snapshot-generation
    #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-proof-snapshot-digest
   (@accessor
    gerbil-ascent/candidate/provenance#positive-proof::t
    snapshot-digest
    #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-proof-candidate-digest
   (@accessor
    gerbil-ascent/candidate/provenance#positive-proof::t
    candidate-digest
    #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-proof-query
   (@accessor gerbil-ascent/candidate/provenance#positive-proof::t query #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-proof-work-budget
   (@accessor
    gerbil-ascent/candidate/provenance#positive-proof::t
    work-budget
    #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-proof-nodes
   (@accessor gerbil-ascent/candidate/provenance#positive-proof::t nodes #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-proof-roots
   (@accessor gerbil-ascent/candidate/provenance#positive-proof::t roots #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-proof-status-set!
   (@mutator gerbil-ascent/candidate/provenance#positive-proof::t status #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-proof-snapshot-identity-set!
   (@mutator
    gerbil-ascent/candidate/provenance#positive-proof::t
    snapshot-identity
    #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-proof-snapshot-generation-set!
   (@mutator
    gerbil-ascent/candidate/provenance#positive-proof::t
    snapshot-generation
    #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-proof-snapshot-digest-set!
   (@mutator
    gerbil-ascent/candidate/provenance#positive-proof::t
    snapshot-digest
    #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-proof-candidate-digest-set!
   (@mutator
    gerbil-ascent/candidate/provenance#positive-proof::t
    candidate-digest
    #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-proof-query-set!
   (@mutator gerbil-ascent/candidate/provenance#positive-proof::t query #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-proof-work-budget-set!
   (@mutator
    gerbil-ascent/candidate/provenance#positive-proof::t
    work-budget
    #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-proof-nodes-set!
   (@mutator gerbil-ascent/candidate/provenance#positive-proof::t nodes #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-proof-roots-set!
   (@mutator gerbil-ascent/candidate/provenance#positive-proof::t roots #f))
  (declare-class
   gerbil-ascent/candidate/provenance#proof-node::t
   (@class gerbil-ascent/candidate/provenance#proof-node::t
           ()
           (object::t t::t)
           (id kind relation row label inputs)
           (id kind relation row label inputs)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-node::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/provenance#proof-node::t)
    'class::t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-node?
   (@predicate gerbil-ascent/candidate/provenance#proof-node::t))
  (declare-type
   gerbil-ascent/candidate/provenance#make-proof-node
   (@constructor gerbil-ascent/candidate/provenance#proof-node::t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-node-id
   (@accessor gerbil-ascent/candidate/provenance#proof-node::t id #t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-node-kind
   (@accessor gerbil-ascent/candidate/provenance#proof-node::t kind #t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-node-relation
   (@accessor gerbil-ascent/candidate/provenance#proof-node::t relation #t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-node-row
   (@accessor gerbil-ascent/candidate/provenance#proof-node::t row #t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-node-label
   (@accessor gerbil-ascent/candidate/provenance#proof-node::t label #t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-node-inputs
   (@accessor gerbil-ascent/candidate/provenance#proof-node::t inputs #t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-node-id-set!
   (@mutator gerbil-ascent/candidate/provenance#proof-node::t id #t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-node-kind-set!
   (@mutator gerbil-ascent/candidate/provenance#proof-node::t kind #t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-node-relation-set!
   (@mutator gerbil-ascent/candidate/provenance#proof-node::t relation #t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-node-row-set!
   (@mutator gerbil-ascent/candidate/provenance#proof-node::t row #t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-node-label-set!
   (@mutator gerbil-ascent/candidate/provenance#proof-node::t label #t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-node-inputs-set!
   (@mutator gerbil-ascent/candidate/provenance#proof-node::t inputs #t))
  (declare-type
   gerbil-ascent/candidate/provenance#&proof-node-id
   (@accessor gerbil-ascent/candidate/provenance#proof-node::t id #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&proof-node-kind
   (@accessor gerbil-ascent/candidate/provenance#proof-node::t kind #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&proof-node-relation
   (@accessor gerbil-ascent/candidate/provenance#proof-node::t relation #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&proof-node-row
   (@accessor gerbil-ascent/candidate/provenance#proof-node::t row #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&proof-node-label
   (@accessor gerbil-ascent/candidate/provenance#proof-node::t label #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&proof-node-inputs
   (@accessor gerbil-ascent/candidate/provenance#proof-node::t inputs #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&proof-node-id-set!
   (@mutator gerbil-ascent/candidate/provenance#proof-node::t id #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&proof-node-kind-set!
   (@mutator gerbil-ascent/candidate/provenance#proof-node::t kind #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&proof-node-relation-set!
   (@mutator gerbil-ascent/candidate/provenance#proof-node::t relation #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&proof-node-row-set!
   (@mutator gerbil-ascent/candidate/provenance#proof-node::t row #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&proof-node-label-set!
   (@mutator gerbil-ascent/candidate/provenance#proof-node::t label #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&proof-node-inputs-set!
   (@mutator gerbil-ascent/candidate/provenance#proof-node::t inputs #f))
  (declare-class
   gerbil-ascent/candidate/provenance#proof-relation::t
   (@class gerbil-ascent/candidate/provenance#proof-relation::t
           ()
           (object::t t::t)
           (nodes tail members)
           (nodes tail members)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-relation::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/provenance#proof-relation::t)
    'class::t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-relation?
   (@predicate gerbil-ascent/candidate/provenance#proof-relation::t))
  (declare-type
   gerbil-ascent/candidate/provenance#make-proof-relation
   (@constructor gerbil-ascent/candidate/provenance#proof-relation::t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-relation-nodes
   (@accessor gerbil-ascent/candidate/provenance#proof-relation::t nodes #t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-relation-tail
   (@accessor gerbil-ascent/candidate/provenance#proof-relation::t tail #t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-relation-members
   (@accessor gerbil-ascent/candidate/provenance#proof-relation::t members #t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-relation-nodes-set!
   (@mutator gerbil-ascent/candidate/provenance#proof-relation::t nodes #t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-relation-tail-set!
   (@mutator gerbil-ascent/candidate/provenance#proof-relation::t tail #t))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-relation-members-set!
   (@mutator gerbil-ascent/candidate/provenance#proof-relation::t members #t))
  (declare-type
   gerbil-ascent/candidate/provenance#&proof-relation-nodes
   (@accessor gerbil-ascent/candidate/provenance#proof-relation::t nodes #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&proof-relation-tail
   (@accessor gerbil-ascent/candidate/provenance#proof-relation::t tail #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&proof-relation-members
   (@accessor gerbil-ascent/candidate/provenance#proof-relation::t members #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&proof-relation-nodes-set!
   (@mutator gerbil-ascent/candidate/provenance#proof-relation::t nodes #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&proof-relation-tail-set!
   (@mutator gerbil-ascent/candidate/provenance#proof-relation::t tail #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&proof-relation-members-set!
   (@mutator gerbil-ascent/candidate/provenance#proof-relation::t members #f))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-atom?
   (@lambda 1
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/provenance)))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-fixed-clause?
   (@lambda 1
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/provenance)))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-rule-body?
   (@lambda 1
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/provenance)))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-rules?
   (@lambda 1
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/provenance)))
  (declare-type
   gerbil-ascent/candidate/provenance#candidate-positive-proof/option
   (@lambda 7
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/provenance)))
  (declare-type
   gerbil-ascent/candidate/provenance#candidate-positive-proof
   (@lambda 6
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/provenance)))
  (declare-type
   gerbil-ascent/candidate/provenance#candidate-positive-closed-absence
   (@lambda 6
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/provenance)))
  (declare-type
   gerbil-ascent/candidate/provenance#proof-metadata-lookup
   (@lambda 1
            #f
            signature:
            (return:
             procedure::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/provenance)))
  (declare-class
   gerbil-ascent/candidate/provenance#positive-rule-replay::t
   (@class gerbil-ascent/candidate/provenance#positive-rule-replay::t
           ()
           (object::t t::t)
           (relation input-count execute)
           (relation input-count execute)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-rule-replay::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/provenance#positive-rule-replay::t)
    'class::t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-rule-replay?
   (@predicate gerbil-ascent/candidate/provenance#positive-rule-replay::t))
  (declare-type
   gerbil-ascent/candidate/provenance#make-positive-rule-replay
   (@constructor gerbil-ascent/candidate/provenance#positive-rule-replay::t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-rule-replay-relation
   (@accessor
    gerbil-ascent/candidate/provenance#positive-rule-replay::t
    relation
    #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-rule-replay-input-count
   (@accessor
    gerbil-ascent/candidate/provenance#positive-rule-replay::t
    input-count
    #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-rule-replay-execute
   (@accessor
    gerbil-ascent/candidate/provenance#positive-rule-replay::t
    execute
    #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-rule-replay-relation-set!
   (@mutator
    gerbil-ascent/candidate/provenance#positive-rule-replay::t
    relation
    #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-rule-replay-input-count-set!
   (@mutator
    gerbil-ascent/candidate/provenance#positive-rule-replay::t
    input-count
    #t))
  (declare-type
   gerbil-ascent/candidate/provenance#positive-rule-replay-execute-set!
   (@mutator
    gerbil-ascent/candidate/provenance#positive-rule-replay::t
    execute
    #t))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-rule-replay-relation
   (@accessor
    gerbil-ascent/candidate/provenance#positive-rule-replay::t
    relation
    #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-rule-replay-input-count
   (@accessor
    gerbil-ascent/candidate/provenance#positive-rule-replay::t
    input-count
    #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-rule-replay-execute
   (@accessor
    gerbil-ascent/candidate/provenance#positive-rule-replay::t
    execute
    #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-rule-replay-relation-set!
   (@mutator
    gerbil-ascent/candidate/provenance#positive-rule-replay::t
    relation
    #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-rule-replay-input-count-set!
   (@mutator
    gerbil-ascent/candidate/provenance#positive-rule-replay::t
    input-count
    #f))
  (declare-type
   gerbil-ascent/candidate/provenance#&positive-rule-replay-execute-set!
   (@mutator
    gerbil-ascent/candidate/provenance#positive-rule-replay::t
    execute
    #f))
  (declare-type
   gerbil-ascent/candidate/provenance#prepare-positive-rule-replay
   (@lambda 1
            #f
            signature:
            (return:
             gerbil-ascent/candidate/provenance#positive-rule-replay::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/provenance)))
  (declare-type
   gerbil-ascent/candidate/provenance#candidate-verify-positive-proof
   (@lambda 7
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/provenance))))
