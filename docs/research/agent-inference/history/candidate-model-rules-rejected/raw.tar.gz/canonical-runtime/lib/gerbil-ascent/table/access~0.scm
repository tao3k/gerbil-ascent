(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/access::timestamp 1791687876)
  (begin
    (define gerbil-ascent/table/access#extend-scalar-index!
      (lambda (_%index14199%_ _%rows14200%_ _%column14201%_)
        (let* ((_%target14203%_ _%index14199%_)
               (_%row-slot14206%_ (vector '#f))
               (_%prepend-row14215%_
                (lambda (_%bucket14209%_)
                  (cons (vector-ref _%row-slot14206%_ '0)
                        (let ((_%$e14212%_ _%bucket14209%_))
                          (if _%$e14212%_ _%$e14212%_ '()))))))
          (for-each
           (lambda (_%row14219%_)
             (let ((_%selected14221%_ (list-ref _%row14219%_ _%column14201%_)))
               (vector-set! _%row-slot14206%_ '0 _%row14219%_)
               (let ()
                 (declare (not safe))
                 (hash-update!__%
                  _%target14203%_
                  _%selected14221%_
                  _%prepend-row14215%_
                  '#f))))
           _%rows14200%_)
          _%target14203%_)))
    (define gerbil-ascent/table/access#gerbil-ascent-physical-index-single-rows
      (lambda (_%index14193%_ _%value14194%_)
        (let ((_%$e14196%_
               (let ()
                 (declare (not safe))
                 (hash-get _%index14193%_ _%value14194%_))))
          (if _%$e14196%_ _%$e14196%_ '()))))
    (define gerbil-ascent/table/access#gerbil-ascent-physical-index-build
      (lambda (_%provider14189%_ _%rows14190%_ _%columns14191%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
               _%provider14189%_))
            (if (and (pair? _%columns14191%_)
                     (null? (let ()
                              (declare (not safe))
                              (##cdr _%columns14191%_))))
                (let ((__tmp34836
                       (gerbil-ascent/table/access#extend-scalar-index!
                        (let ()
                          (declare (not safe))
                          (make-hash-table__%
                           '#f
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value))
                        _%rows14190%_
                        (car _%columns14191%_))))
                  (declare (not safe))
                  (gerbil-ascent/table/funs#gerbil-ascent-index-order!
                   __tmp34836))
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/table/funs#gerbil-ascent-index-build
                   _%rows14190%_
                   _%columns14191%_)))
            (let ((__tmp34838
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/table/funs#gerbil-ascent-index-row-snapshot
                      _%rows14190%_)))
                  (__tmp34837 (map values _%columns14191%_)))
              (declare (not safe))
              (gerbil-ascent/table/provider#gerbil-ascent-index-provider-build
               _%provider14189%_
               __tmp34838
               __tmp34837)))))
    (define gerbil-ascent/table/access#gerbil-ascent-physical-index-extend!
      (lambda (_%provider14184%_ _%index14185%_ _%rows14186%_ _%columns14187%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
               _%provider14184%_))
            (if (and (pair? _%columns14187%_)
                     (null? (let ()
                              (declare (not safe))
                              (##cdr _%columns14187%_))))
                (gerbil-ascent/table/access#extend-scalar-index!
                 _%index14185%_
                 _%rows14186%_
                 (car _%columns14187%_))
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/table/funs#gerbil-ascent-index-extend!
                   _%index14185%_
                   _%rows14186%_
                   _%columns14187%_)))
            (let ((__tmp34840
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/table/funs#gerbil-ascent-index-row-snapshot
                      _%rows14186%_)))
                  (__tmp34839 (map values _%columns14187%_)))
              (declare (not safe))
              (gerbil-ascent/table/provider#gerbil-ascent-index-provider-extend!
               _%provider14184%_
               _%index14185%_
               __tmp34840
               __tmp34839)))))
    (define gerbil-ascent/table/access#gerbil-ascent-physical-index-rows
      (lambda (_%provider14175%_ _%index14176%_ _%key14177%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
               _%provider14175%_))
            (if (and (pair? _%key14177%_)
                     (null? (let ()
                              (declare (not safe))
                              (##cdr _%key14177%_))))
                (gerbil-ascent/table/access#gerbil-ascent-physical-index-single-rows
                 _%index14176%_
                 (car _%key14177%_))
                (let ((_%$e14179%_
                       (let ()
                         (declare (not safe))
                         (hash-get _%index14176%_ _%key14177%_))))
                  (if _%$e14179%_ _%$e14179%_ '())))
            (let ((_%matched14182%_
                   (let ((__tmp34841 (map values _%key14177%_)))
                     (declare (not safe))
                     (gerbil-ascent/table/provider#gerbil-ascent-index-provider-lookup
                      _%provider14175%_
                      _%index14176%_
                      __tmp34841))))
              (if (list? _%matched14182%_)
                  '#!void
                  (let ()
                    (declare (not safe))
                    (error '"ASCENT index provider returned non-list rows"
                           _%matched14182%_)))
              _%matched14182%_))))))
