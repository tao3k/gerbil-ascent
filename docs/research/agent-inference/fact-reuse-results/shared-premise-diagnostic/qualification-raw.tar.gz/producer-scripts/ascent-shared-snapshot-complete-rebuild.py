import importlib.util,json,os,shutil,subprocess,time,hashlib
from pathlib import Path
origin=Path.cwd();root=origin/'.cache/ascent/shared-premise/source-snapshot';base=origin/'.cache/ascent/candidate-interaction';rt=base/'runtime';out=base/'shared-premise-snapshot-complete-rebuild';out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def run(label,cmd,env,cwd=root):
 began=time.monotonic()
 with (out/(label+'.log')).open('w') as log:
  try:
   p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
   p.wait(timeout=240)
  except subprocess.TimeoutExpired:
   p.terminate();p.wait(timeout=5);save(out/(label+'.json'),{'command':cmd,'exit':p.returncode,'timeout':True,'seconds':time.monotonic()-began});raise
 save(out/(label+'.json'),{'command':cmd,'exit':p.returncode,'seconds':time.monotonic()-began})
 print(label,p.returncode,round(time.monotonic()-began,2),flush=True)
 assert p.returncode==0,label
capture=json.loads((rt/'source-capture.json').read_text());names=list(capture['sourceSha256']);names=list(dict.fromkeys(names+['candidate/proof-frame.ss','candidate/stratified-plan.ss','candidate/reduction-plan.ss','program/execution-publication.ss']))
changed=[n for n in names if n not in capture['sourceSha256'] or sha(root/n)!=capture['sourceSha256'][n]]
save(out/'source-binding.json',{'head':json.loads((root/'.research-source.json').read_text())['head'],'changes':changed,'sourceSha256':{n:sha(root/n) for n in names}})
shutil.copytree(base/'canonical-runtime',out/'previous-canonical-runtime');shutil.copy2(rt/'bin/candidate-interaction',out/'previous-binary');shutil.copy2(rt/'source-capture.json',out/'previous-source-capture.json')
for n in names:
 p=base/'canonical-source'/n;p.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(root/n,p)
env=os.environ.copy();env.update(PATH='/usr/bin:/bin:/opt/homebrew/bin:/usr/sbin:/sbin',GERBIL_PATH=str(base/'canonical-runtime'),GERBIL_LOADPATH=f'{base}/canonical-runtime/lib:{base.parent}/evidence-interaction/runtime/lib',LIBRARY_PATH='/opt/homebrew/opt/openssl@3/lib:/opt/homebrew/opt/zlib/lib:/opt/homebrew/opt/sqlite/lib')
for k in ['CC','CFLAGS','CPPFLAGS','CXXFLAGS','LDFLAGS','NIX_CFLAGS_COMPILE','NIX_LDFLAGS','CPATH','SDKROOT']:env.pop(k,None)
cmd=json.loads((base/'reuse-make.json').read_text())['command'];cmd[-1]=cmd[-1].replace('"candidate/provenance"','"candidate/proof-frame" "candidate/provenance"')
cmd[-1]=cmd[-1].replace('"candidate/stratified-proof"','"candidate/stratified-plan" "candidate/stratified-proof"');cmd[-1]=cmd[-1].replace('"candidate/finite-plan"','"candidate/reduction-plan" "candidate/finite-plan"');cmd[-1]=cmd[-1].replace('"program/evaluate"','"program/execution-publication" "program/evaluate"');run('make',cmd,env)
run('fixture',json.loads((base/'reuse-fixture-compile-support.json').read_text())['command'],env)
static=base/'canonical-runtime/lib/static';obj=rt/'native-objects'
gsc=json.loads((base/'reuse-c-gerbil-ascent__candidate__evidence-store.json').read_text())['command'][:2]
old_sources=json.loads((rt/'native-object-sources.json').read_text());proof_static=static/'gerbil-ascent__candidate__proof-frame.c';plan_static=static/'gerbil-ascent__candidate__stratified-plan.c';reduction_static=static/'gerbil-ascent__candidate__reduction-plan.c';publication_static=static/'gerbil-ascent__program__execution-publication.c';new_static=[p for p in [proof_static,plan_static,reduction_static,publication_static] if str(p) not in old_sources];old_hash={str(Path(p)):sha(Path(p)) for p in old_sources if Path(p).exists()}
# All Library C translations must correspond to the newly compiled Scheme.
for n in names:
 if n=='gerbil.pkg':continue
 stem='gerbil-ascent__'+n[:-3].replace('/','__')
 run('c-'+stem,gsc+['-c','-module-ref',stem,'-linker-name',stem,'-o',str(static/(stem+'.c')),str(static/(stem+'.scm'))],env)
stem='gerbil-ascent__tools__research__candidate-interaction'
run('c-fixture',gsc+['-c','-module-ref',stem,'-linker-name',stem,'-o',str(static/(stem+'.c')),str(static/(stem+'.scm'))],env)
for c in [Path(p) for p in old_sources]+new_static:
 if str(c) not in old_hash or sha(c)!=old_hash[str(c)]:
  run('obj-'+c.stem,gsc+['-obj','-o',str(obj/(c.stem+'.o')),'-cc-options','-O0 -fPIC',str(c)],env)
cmd=json.loads((base/'reuse-link-0-support.json').read_text())['command'];cmd.insert(-1,str(proof_static));cmd.insert(-1,str(plan_static));cmd.insert(-1,str(reduction_static));cmd.insert(-1,str(publication_static));run('link-0',cmd,env)
run('link-1',json.loads((base/'reuse-link-1-support.json').read_text())['command'],env)
cmd=json.loads((base/'reuse-link-2-support.json').read_text())['command'];cmd.insert(-1,str(obj/(proof_static.stem+'.o')));cmd.insert(-1,str(obj/(plan_static.stem+'.o')));cmd.insert(-1,str(obj/(reduction_static.stem+'.o')));cmd.insert(-1,str(obj/(publication_static.stem+'.o')));run('link-2',cmd,env)
# The existing linker receipt writes candidate-native; publish after success.
shutil.copy2(rt/'bin/candidate-native',rt/'bin/candidate-interaction')
binding=json.loads((out/'source-binding.json').read_text());assert all(sha(root/n)==s for n,s in binding['sourceSha256'].items()),'source changed during build'
save(rt/'source-capture.json',{'head':binding['head'],'sourceSha256':binding['sourceSha256'],'scope':'Current Library capture for bounded transport qualification','buildReceipt':str(out)})
for n in names:
 p=rt/'current-source'/n;p.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(root/n,p)
save(rt/'native-object-sources.json',list(dict.fromkeys(old_sources+[str(p) for p in new_static])))
save(out/'result.json',{'passed':True,'binarySha256':sha(rt/'bin/candidate-interaction'),'sourceCount':len(names),'changes':changed})
print('CURRENT_LIBRARY_BUILD_OK',flush=True)
