prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/program

(begin
  (declare-type
   gerbil-ascent/program/analysis#+program-analysis-cache+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/analysis#+program-analysis-cache+)
    'HashTable::t))
  (declare-type
   gerbil-ascent/program/analysis#+program-schema-cache+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/analysis#+program-schema-cache+)
    'HashTable::t))
  (declare-type
   gerbil-ascent/program/analysis#gerbil-ascent-program-analysis
   (@lambda 4
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/analysis)))
  (declare-type
   gerbil-ascent/program/analysis#gerbil-ascent-program-schema
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/analysis))))
