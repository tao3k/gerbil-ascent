(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37619_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37621_|
    (##structure
     gx#syntax-quote::t
     'make-finite-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37623_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37625_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37626_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37627_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37628_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37629_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37630_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-program
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37631_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37632_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37633_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-closure
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37635_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37636_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37637_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37638_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37639_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37640_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-program-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37641_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37642_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37643_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-closure-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37645_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37646_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37647_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37648_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37649_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37650_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-program
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37651_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37652_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37653_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-closure
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37655_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37656_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37657_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37658_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37659_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37660_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-program-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37661_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37662_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37663_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-closure-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37665_|
    (##structure
     gx#syntax-quote::t
     'replay-relation::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37667_|
    (##structure
     gx#syntax-quote::t
     'make-replay-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37669_|
    (##structure
     gx#syntax-quote::t
     'replay-relation?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37671_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-arity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37672_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-reversed
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37673_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-present
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37674_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-frontier
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37675_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-dirty?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37677_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-arity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37678_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-reversed-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37679_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-present-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37680_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-frontier-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37681_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-dirty?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37683_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-arity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37684_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-reversed
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37685_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-present
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37686_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-frontier
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37687_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-dirty?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37689_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-arity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37690_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-reversed-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37691_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-present-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37692_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-frontier-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g37693_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-dirty?-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/finite-evidence[:0:]#finite-evidence|
      (let ((__obj37465
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37465
           'gerbil-ascent/candidate/finite-evidence#finite-evidence::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37465 'finite-evidence '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37465
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    program
                    query
                    work-budget
                    closure)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37465
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    program
                    query
                    work-budget
                    closure)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37465 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37465 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37465 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37465 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37465 '#f '13 '#f '#f))
        (let ((__tmp37618
               |gerbil-ascent/candidate/finite-evidence[1]#_g37619_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37465 __tmp37618 '4 '#f '#f))
        (let ((__tmp37620
               |gerbil-ascent/candidate/finite-evidence[1]#_g37621_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37465 __tmp37620 '14 '#f '#f))
        (let ((__tmp37622
               |gerbil-ascent/candidate/finite-evidence[1]#_g37623_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37465 __tmp37622 '15 '#f '#f))
        (let ((__tmp37624
               (cons (cons 'status
                           |gerbil-ascent/candidate/finite-evidence[1]#_g37625_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g37626_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g37627_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g37628_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37629_|)
                                             (cons (cons 'program
                                                         |gerbil-ascent/candidate/finite-evidence[1]#_g37630_|)
                                                   (cons (cons 'query
                                                               |gerbil-ascent/candidate/finite-evidence[1]#_g37631_|)
                                                         (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/finite-evidence[1]#_g37632_|)
                       (cons (cons 'closure
                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37633_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37465 __tmp37624 '16 '#f '#f))
        (let ((__tmp37634
               (cons (cons 'status
                           |gerbil-ascent/candidate/finite-evidence[1]#_g37635_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g37636_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g37637_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g37638_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37639_|)
                                             (cons (cons 'program
                                                         |gerbil-ascent/candidate/finite-evidence[1]#_g37640_|)
                                                   (cons (cons 'query
                                                               |gerbil-ascent/candidate/finite-evidence[1]#_g37641_|)
                                                         (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/finite-evidence[1]#_g37642_|)
                       (cons (cons 'closure
                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37643_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37465 __tmp37634 '17 '#f '#f))
        (let ((__tmp37644
               (cons (cons 'status
                           |gerbil-ascent/candidate/finite-evidence[1]#_g37645_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g37646_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g37647_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g37648_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37649_|)
                                             (cons (cons 'program
                                                         |gerbil-ascent/candidate/finite-evidence[1]#_g37650_|)
                                                   (cons (cons 'query
                                                               |gerbil-ascent/candidate/finite-evidence[1]#_g37651_|)
                                                         (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/finite-evidence[1]#_g37652_|)
                       (cons (cons 'closure
                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37653_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37465 __tmp37644 '18 '#f '#f))
        (let ((__tmp37654
               (cons (cons 'status
                           |gerbil-ascent/candidate/finite-evidence[1]#_g37655_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g37656_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g37657_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g37658_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37659_|)
                                             (cons (cons 'program
                                                         |gerbil-ascent/candidate/finite-evidence[1]#_g37660_|)
                                                   (cons (cons 'query
                                                               |gerbil-ascent/candidate/finite-evidence[1]#_g37661_|)
                                                         (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/finite-evidence[1]#_g37662_|)
                       (cons (cons 'closure
                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37663_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37465 __tmp37654 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37465 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37465 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37465 '() '21 '#f '#f))
        __obj37465))
    (define |gerbil-ascent/candidate/finite-evidence[:0:]#replay-relation|
      (let ((__obj37466
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37466
           'gerbil-ascent/candidate/finite-evidence#replay-relation::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37466 'replay-relation '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37466
           '(arity reversed present frontier dirty?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37466
           '(arity reversed present frontier dirty?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37466 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37466 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37466 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37466 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37466 '#f '13 '#f '#f))
        (let ((__tmp37664
               |gerbil-ascent/candidate/finite-evidence[1]#_g37665_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37466 __tmp37664 '4 '#f '#f))
        (let ((__tmp37666
               |gerbil-ascent/candidate/finite-evidence[1]#_g37667_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37466 __tmp37666 '14 '#f '#f))
        (let ((__tmp37668
               |gerbil-ascent/candidate/finite-evidence[1]#_g37669_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37466 __tmp37668 '15 '#f '#f))
        (let ((__tmp37670
               (cons (cons 'arity
                           |gerbil-ascent/candidate/finite-evidence[1]#_g37671_|)
                     (cons (cons 'reversed
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g37672_|)
                           (cons (cons 'present
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g37673_|)
                                 (cons (cons 'frontier
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g37674_|)
                                       (cons (cons 'dirty?
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37675_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37466 __tmp37670 '16 '#f '#f))
        (let ((__tmp37676
               (cons (cons 'arity
                           |gerbil-ascent/candidate/finite-evidence[1]#_g37677_|)
                     (cons (cons 'reversed
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g37678_|)
                           (cons (cons 'present
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g37679_|)
                                 (cons (cons 'frontier
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g37680_|)
                                       (cons (cons 'dirty?
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37681_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37466 __tmp37676 '17 '#f '#f))
        (let ((__tmp37682
               (cons (cons 'arity
                           |gerbil-ascent/candidate/finite-evidence[1]#_g37683_|)
                     (cons (cons 'reversed
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g37684_|)
                           (cons (cons 'present
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g37685_|)
                                 (cons (cons 'frontier
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g37686_|)
                                       (cons (cons 'dirty?
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37687_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37466 __tmp37682 '18 '#f '#f))
        (let ((__tmp37688
               (cons (cons 'arity
                           |gerbil-ascent/candidate/finite-evidence[1]#_g37689_|)
                     (cons (cons 'reversed
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g37690_|)
                           (cons (cons 'present
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g37691_|)
                                 (cons (cons 'frontier
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g37692_|)
                                       (cons (cons 'dirty?
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g37693_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37466 __tmp37688 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37466 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37466 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37466 '() '21 '#f '#f))
        __obj37466))))
