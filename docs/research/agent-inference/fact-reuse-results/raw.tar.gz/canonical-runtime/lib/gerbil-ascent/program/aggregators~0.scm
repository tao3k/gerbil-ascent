(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/aggregators::timestamp 1791690984)
  (begin
    (define gerbil-ascent/program/aggregators#single-column-value
      (lambda (_%$%e1007910081%_)
        (let* ((_%$%$%e100791008310092%_ _%$%e1007910081%_)
               (_%$%E1008610096%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%$%e100791008310092%_
                           '([value])
                           '(tuple)))
                  '#!void)))
          (let ((_%$%K1008810112%_ (lambda (_%value10110%_) _%value10110%_))
                (_%$%K1008710102%_
                 (lambda (_%tuple10100%_)
                   (let ()
                     (declare (not safe))
                     (error '"ASCENT aggregator expects one input column"
                            _%tuple10100%_)))))
            (if (pair? _%$%$%e100791008310092%_)
                (let ((_%$%tl1009010117%_
                       (let ()
                         (declare (not safe))
                         (##cdr _%$%$%e100791008310092%_)))
                      (_%$%hd1008910115%_
                       (let ()
                         (declare (not safe))
                         (##car _%$%$%e100791008310092%_))))
                  (if (null? _%$%tl1009010117%_)
                      (let ((_%value10120%_ _%$%hd1008910115%_))
                        (_%$%K1008810112%_ _%value10120%_))
                      (let ((_%tuple10105%_ _%$%$%e100791008310092%_))
                        (_%$%K1008710102%_ _%tuple10105%_))))
                (let ((_%tuple10105%_ _%$%$%e100791008310092%_))
                  (_%$%K1008710102%_ _%tuple10105%_)))))))
    (define gerbil-ascent/program/aggregators#gerbil-ascent-count
      (lambda (_%tuples10076%_)
        (for-each
         (lambda (_%tuple10078%_)
           (if (null? _%tuple10078%_)
               '#!void
               (let ()
                 (declare (not safe))
                 (error '"ASCENT count expects no input columns"
                        _%tuple10078%_))))
         _%tuples10076%_)
        (list (length _%tuples10076%_))))
    (define gerbil-ascent/program/aggregators#gerbil-ascent-sum
      (lambda (_%tuples10069%_)
        (let ((_%input10071%_ _%tuples10069%_))
          (for-each
           gerbil-ascent/program/aggregators#single-column-value
           _%input10071%_)
          (list (let ((__tmp33987
                       (lambda (_%tuple10073%_ _%sum10074%_)
                         (+ (car _%tuple10073%_) _%sum10074%_))))
                  (declare (not safe))
                  (foldl__0 __tmp33987 '0 _%input10071%_))))))
    (define gerbil-ascent/program/aggregators#gerbil-ascent-min
      (lambda (_%tuples10065%_)
        (let ((_%values10067%_
               (map gerbil-ascent/program/aggregators#single-column-value
                    _%tuples10065%_)))
          (if (null? _%values10067%_)
              '()
              (list (let ()
                      (declare (not safe))
                      (##apply min _%values10067%_)))))))
    (define gerbil-ascent/program/aggregators#gerbil-ascent-max
      (lambda (_%tuples10061%_)
        (let ((_%values10063%_
               (map gerbil-ascent/program/aggregators#single-column-value
                    _%tuples10061%_)))
          (if (null? _%values10063%_)
              '()
              (list (let ()
                      (declare (not safe))
                      (##apply max _%values10063%_)))))))
    (define gerbil-ascent/program/aggregators#gerbil-ascent-mean
      (lambda (_%tuples10050%_)
        (let ((_%input10052%_ _%tuples10050%_))
          (for-each
           gerbil-ascent/program/aggregators#single-column-value
           _%input10052%_)
          (if (null? _%input10052%_)
              '()
              (let* ((_%count10054%_ '0)
                     (_%sum10059%_
                      (let ((__tmp33988
                             (lambda (_%tuple10056%_ _%prior10057%_)
                               (set! _%count10054%_ (+ _%count10054%_ '1))
                               (+ (car _%tuple10056%_) _%prior10057%_))))
                        (declare (not safe))
                        (foldl__0 __tmp33988 '0 _%input10052%_))))
                (list (/ (exact->inexact _%sum10059%_) _%count10054%_)))))))))
