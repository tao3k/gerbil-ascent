(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/program/scheme-admit")
    (load-module "gerbil-ascent/program/scheme-query")
    (load-module "gerbil-ascent/program/scheme-session"))
  (begin))
