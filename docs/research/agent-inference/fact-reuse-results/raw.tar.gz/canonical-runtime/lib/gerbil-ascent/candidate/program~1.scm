(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/program[1]#_g37171_|
    (##structure
     gx#syntax-quote::t
     'candidate-declaration::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g37173_|
    (##structure
     gx#syntax-quote::t
     'make-candidate-declaration
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g37175_|
    (##structure
     gx#syntax-quote::t
     'candidate-declaration?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g37177_|
    (##structure
     gx#syntax-quote::t
     'candidate-declaration-arity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g37178_|
    (##structure
     gx#syntax-quote::t
     'candidate-declaration-source?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g37180_|
    (##structure
     gx#syntax-quote::t
     'candidate-declaration-arity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g37181_|
    (##structure
     gx#syntax-quote::t
     'candidate-declaration-source?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g37183_|
    (##structure
     gx#syntax-quote::t
     '&candidate-declaration-arity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g37184_|
    (##structure
     gx#syntax-quote::t
     '&candidate-declaration-source?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g37186_|
    (##structure
     gx#syntax-quote::t
     '&candidate-declaration-arity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g37187_|
    (##structure
     gx#syntax-quote::t
     '&candidate-declaration-source?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[:0:]#candidate-declaration|
    (let ((__obj37009
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj37009
         'gerbil-ascent/candidate/program#candidate-declaration::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj37009
         'candidate-declaration
         '3
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37009 '(arity source?) '6 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37009 '(arity source?) '8 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37009 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37009 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37009 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37009 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37009 '#f '13 '#f '#f))
      (let ((__tmp37170 |gerbil-ascent/candidate/program[1]#_g37171_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj37009 __tmp37170 '4 '#f '#f))
      (let ((__tmp37172 |gerbil-ascent/candidate/program[1]#_g37173_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj37009 __tmp37172 '14 '#f '#f))
      (let ((__tmp37174 |gerbil-ascent/candidate/program[1]#_g37175_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj37009 __tmp37174 '15 '#f '#f))
      (let ((__tmp37176
             (cons (cons 'arity |gerbil-ascent/candidate/program[1]#_g37177_|)
                   (cons (cons 'source?
                               |gerbil-ascent/candidate/program[1]#_g37178_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj37009 __tmp37176 '16 '#f '#f))
      (let ((__tmp37179
             (cons (cons 'arity |gerbil-ascent/candidate/program[1]#_g37180_|)
                   (cons (cons 'source?
                               |gerbil-ascent/candidate/program[1]#_g37181_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj37009 __tmp37179 '17 '#f '#f))
      (let ((__tmp37182
             (cons (cons 'arity |gerbil-ascent/candidate/program[1]#_g37183_|)
                   (cons (cons 'source?
                               |gerbil-ascent/candidate/program[1]#_g37184_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj37009 __tmp37182 '18 '#f '#f))
      (let ((__tmp37185
             (cons (cons 'arity |gerbil-ascent/candidate/program[1]#_g37186_|)
                   (cons (cons 'source?
                               |gerbil-ascent/candidate/program[1]#_g37187_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj37009 __tmp37185 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37009 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37009 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37009 '() '21 '#f '#f))
      __obj37009)))
