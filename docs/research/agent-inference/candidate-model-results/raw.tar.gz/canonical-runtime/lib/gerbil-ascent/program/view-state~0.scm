(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/view-state::timestamp 1791689693)
  (begin
    (define gerbil-ascent/program/view-state#staged-frontier-count::t
      (let ((__tmp35768 (list)) (__tmp35767 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/view-state#staged-frontier-count::t
         'staged-frontier-count
         __tmp35768
         '(count)
         __tmp35767
         '#f)))
    (define gerbil-ascent/program/view-state#staged-frontier-count?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/view-state#staged-frontier-count::t)))
    (define gerbil-ascent/program/view-state#make-staged-frontier-count
      (lambda _%$args18542%_
        (apply make-instance
               gerbil-ascent/program/view-state#staged-frontier-count::t
               _%$args18542%_)))
    (define gerbil-ascent/program/view-state#staged-frontier-count-count
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#staged-frontier-count::t
         'count)))
    (define gerbil-ascent/program/view-state#staged-frontier-count-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#staged-frontier-count::t
         'count)))
    (define gerbil-ascent/program/view-state#&staged-frontier-count-count
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#staged-frontier-count::t
         'count)))
    (define gerbil-ascent/program/view-state#&staged-frontier-count-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#staged-frontier-count::t
         'count)))
    (define gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
      (lambda (_%frontier18540%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%frontier18540%_
               'gerbil-ascent/program/view-state#staged-frontier-count::t))
            (let ()
              (declare (not safe))
              (##unchecked-structure-ref _%frontier18540%_ '1 '#f '#f))
            (let ()
              (declare (not safe))
              (gerbil-ascent/core/relation-view#gerbil-ascent-row-count
               _%frontier18540%_)))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-empty-view
      (let ()
        (declare (not safe))
        (gerbil-ascent/core/relation-view#gerbil-ascent-explicit-view '() '0)))
    (define gerbil-ascent/program/view-state#view-routing-state::t
      (let ((__tmp35770 (list)) (__tmp35769 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/view-state#view-routing-state::t
         'view-routing-state
         __tmp35770
         '(storage all delta versions names generation journals routing)
         __tmp35769
         '#f)))
    (define gerbil-ascent/program/view-state#view-routing-state?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/view-state#view-routing-state::t)))
    (define gerbil-ascent/program/view-state#make-view-routing-state
      (lambda _%$args18537%_
        (apply make-instance
               gerbil-ascent/program/view-state#view-routing-state::t
               _%$args18537%_)))
    (define gerbil-ascent/program/view-state#view-routing-state-storage
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'storage)))
    (define gerbil-ascent/program/view-state#view-routing-state-all
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'all)))
    (define gerbil-ascent/program/view-state#view-routing-state-delta
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'delta)))
    (define gerbil-ascent/program/view-state#view-routing-state-versions
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'versions)))
    (define gerbil-ascent/program/view-state#view-routing-state-names
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'names)))
    (define gerbil-ascent/program/view-state#view-routing-state-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'generation)))
    (define gerbil-ascent/program/view-state#view-routing-state-journals
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'journals)))
    (define gerbil-ascent/program/view-state#view-routing-state-routing
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'routing)))
    (define gerbil-ascent/program/view-state#view-routing-state-storage-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'storage)))
    (define gerbil-ascent/program/view-state#view-routing-state-all-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'all)))
    (define gerbil-ascent/program/view-state#view-routing-state-delta-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'delta)))
    (define gerbil-ascent/program/view-state#view-routing-state-versions-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'versions)))
    (define gerbil-ascent/program/view-state#view-routing-state-names-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'names)))
    (define gerbil-ascent/program/view-state#view-routing-state-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'generation)))
    (define gerbil-ascent/program/view-state#view-routing-state-journals-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'journals)))
    (define gerbil-ascent/program/view-state#view-routing-state-routing-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'routing)))
    (define gerbil-ascent/program/view-state#&view-routing-state-storage
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'storage)))
    (define gerbil-ascent/program/view-state#&view-routing-state-all
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'all)))
    (define gerbil-ascent/program/view-state#&view-routing-state-delta
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'delta)))
    (define gerbil-ascent/program/view-state#&view-routing-state-versions
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'versions)))
    (define gerbil-ascent/program/view-state#&view-routing-state-names
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'names)))
    (define gerbil-ascent/program/view-state#&view-routing-state-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'generation)))
    (define gerbil-ascent/program/view-state#&view-routing-state-journals
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'journals)))
    (define gerbil-ascent/program/view-state#&view-routing-state-routing
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-routing-state::t
         'routing)))
    (define gerbil-ascent/program/view-state#&view-routing-state-storage-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'storage)))
    (define gerbil-ascent/program/view-state#&view-routing-state-all-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'all)))
    (define gerbil-ascent/program/view-state#&view-routing-state-delta-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'delta)))
    (define gerbil-ascent/program/view-state#&view-routing-state-versions-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'versions)))
    (define gerbil-ascent/program/view-state#&view-routing-state-names-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'names)))
    (define gerbil-ascent/program/view-state#&view-routing-state-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'generation)))
    (define gerbil-ascent/program/view-state#&view-routing-state-journals-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'journals)))
    (define gerbil-ascent/program/view-state#&view-routing-state-routing-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-routing-state::t
         'routing)))
    (define gerbil-ascent/program/view-state#initial-delta
      (lambda (_%view18531%_
               _%name18532%_
               _%generation18533%_
               _%revision18534%_)
        (let ((__tmp35772
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/core/relation-view#gerbil-ascent-view-bind
                  _%view18531%_
                  _%name18532%_
                  _%generation18533%_
                  _%revision18534%_
                  'delta)))
              (__tmp35771
               (lambda ()
                 (reverse (let ()
                            (declare (not safe))
                            (gerbil-ascent/core/relation-view#gerbil-ascent-view-rows
                             _%view18531%_))))))
          (declare (not safe))
          (gerbil-ascent/core/relation-view#gerbil-ascent-view-with-export
           __tmp35772
           __tmp35771))))
    (define gerbil-ascent/program/view-state#publish-source-cut!
      (lambda (_%state18517%_ _%index18518%_ _%view18519%_ _%revision18520%_)
        (let* ((_%name18522%_
                (vector-ref
                 (##structure-ref
                  _%state18517%_
                  '5
                  gerbil-ascent/program/view-state#view-routing-state::t
                  '#f)
                 _%index18518%_))
               (_%generation18524%_
                (##structure-ref
                 _%state18517%_
                 '6
                 gerbil-ascent/program/view-state#view-routing-state::t
                 '#f))
               (_%frozen18526%_
                (gerbil-ascent/program/view-state#gerbil-ascent-view-export-cut__%
                 _%view18519%_
                 (vector-ref
                  (##structure-ref
                   _%state18517%_
                   '7
                   gerbil-ascent/program/view-state#view-routing-state::t
                   '#f)
                  _%index18518%_)
                 (let ((__tmp35773
                        (vector-ref
                         (##structure-ref
                          _%state18517%_
                          '1
                          gerbil-ascent/program/view-state#view-routing-state::t
                          '#f)
                         _%index18518%_)))
                   (declare (not safe))
                   (gerbil-ascent/table/storage#gerbil-ascent-storage-eqrel-state?
                    __tmp35773))))
               (_%total18528%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/core/relation-view#gerbil-ascent-view-bind
                   _%frozen18526%_
                   _%name18522%_
                   _%generation18524%_
                   _%revision18520%_
                   'total))))
          (vector-set!
           (##structure-ref
            _%state18517%_
            '2
            gerbil-ascent/program/view-state#view-routing-state::t
            '#f)
           _%index18518%_
           _%total18528%_)
          (vector-set!
           (##structure-ref
            _%state18517%_
            '3
            gerbil-ascent/program/view-state#view-routing-state::t
            '#f)
           _%index18518%_
           (gerbil-ascent/program/view-state#initial-delta
            _%frozen18526%_
            _%name18522%_
            _%generation18524%_
            _%revision18520%_)))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-initialize-view-cuts!
      (lambda (_%relations18507%_ _%eligible?18508%_ _%state18509%_)
        (let ((_%all18511%_
               (##structure-ref
                _%state18509%_
                '2
                gerbil-ascent/program/view-state#view-routing-state::t
                '#f))
              (_%journals18512%_
               (##structure-ref
                _%state18509%_
                '7
                gerbil-ascent/program/view-state#view-routing-state::t
                '#f)))
          (for-each
           (lambda (_%relation18514%_ _%index18515%_)
             (if (_%eligible?18508%_ _%index18515%_)
                 (begin
                   (vector-set!
                    _%journals18512%_
                    _%index18515%_
                    (list (gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event__0
                           'source
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref _%relation18514%_ 'rows)))))
                   (gerbil-ascent/program/view-state#publish-source-cut!
                    _%state18509%_
                    _%index18515%_
                    (if (let ((__tmp35774
                               (vector-ref _%all18511%_ _%index18515%_)))
                          (declare (not safe))
                          (##structure-instance-of?
                           __tmp35774
                           'gerbil-ascent/core/relation-view#relation-view::t))
                        (vector-ref _%all18511%_ _%index18515%_)
                        gerbil-ascent/program/view-state#gerbil-ascent-empty-view)
                    '0))
                 '#!void))
           _%relations18507%_
           (let ((__tmp35775 (vector-length _%all18511%_)))
             (declare (not safe))
             (##iota __tmp35775))))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-route-view-sources!
      (lambda (_%rule-plans18485%_ _%eligible?18486%_ _%state18487%_)
        (let ((_%all18489%_
               (##structure-ref
                _%state18487%_
                '2
                gerbil-ascent/program/view-state#view-routing-state::t
                '#f))
              (_%routing18490%_
               (##structure-ref
                _%state18487%_
                '8
                gerbil-ascent/program/view-state#view-routing-state::t
                '#f))
              (_%storage18491%_
               (##structure-ref
                _%state18487%_
                '1
                gerbil-ascent/program/view-state#view-routing-state::t
                '#f))
              (_%versions18492%_
               (##structure-ref
                _%state18487%_
                '4
                gerbil-ascent/program/view-state#view-routing-state::t
                '#f)))
          (for-each
           (lambda (_%rule18494%_)
             (for-each
              (lambda (_%clause18496%_)
                (if (eq? (vector-ref _%clause18496%_ '0) 'atom)
                    (let* ((_%atom18498%_ (vector-ref _%clause18496%_ '1))
                           (_%index18500%_ (vector-ref _%atom18498%_ '0)))
                      (if (and (_%eligible?18486%_ _%index18500%_)
                               (let ((__tmp35777
                                      (lambda (_%term18503%_)
                                        (not (eq? (car _%term18503%_)
                                                  'literal))))
                                     (__tmp35776
                                      (vector-ref _%atom18498%_ '4)))
                                 (declare (not safe))
                                 (ormap__0 __tmp35777 __tmp35776)))
                          (vector-set! _%routing18490%_ _%index18500%_ '#t)
                          '#!void))
                    '#!void))
              (vector-ref _%rule18494%_ '1)))
           _%rule-plans18485%_)
          (let ((__tmp35780
                 (lambda (_%index18505%_)
                   (if (vector-ref _%routing18490%_ _%index18505%_)
                       (gerbil-ascent/program/view-state#publish-source-cut!
                        _%state18487%_
                        _%index18505%_
                        (let ((__tmp35781
                               (vector-ref _%storage18491%_ _%index18505%_)))
                          (declare (not safe))
                          (gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__%
                           __tmp35781
                           '#t))
                        (vector-ref _%versions18492%_ _%index18505%_))
                       '#!void)))
                (__tmp35778
                 (let ((__tmp35779 (vector-length _%all18489%_)))
                   (declare (not safe))
                   (##iota __tmp35779))))
            (declare (not safe))
            (##for-each __tmp35780 __tmp35778)))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-view-relation?
      (lambda (_%storage18482%_ _%index18483%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/table/storage#gerbil-ascent-canonical-view-storage-provider?
               _%storage18482%_))
            (let ()
              (declare (not safe))
              (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
               _%index18483%_))
            '#f)))
    (define gerbil-ascent/program/view-state#gerbil-ascent-add-frontier
      (lambda (_%old18472%_ _%frontier18473%_)
        (if (= (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                _%frontier18473%_)
               '0)
            _%old18472%_
            (if (= (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                    _%old18472%_)
                   '0)
                _%frontier18473%_
                (if (or (let ()
                          (declare (not safe))
                          (##structure-instance-of?
                           _%old18472%_
                           'gerbil-ascent/program/view-state#staged-frontier-count::t))
                        (let ()
                          (declare (not safe))
                          (##structure-instance-of?
                           _%frontier18473%_
                           'gerbil-ascent/program/view-state#staged-frontier-count::t)))
                    (let ((__tmp35782
                           (+ (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                               _%old18472%_)
                              (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                               _%frontier18473%_))))
                      (declare (not safe))
                      (##structure
                       gerbil-ascent/program/view-state#staged-frontier-count::t
                       __tmp35782))
                    (let ()
                      (declare (not safe))
                      (gerbil-ascent/core/relation-view#gerbil-ascent-view-union
                       _%old18472%_
                       _%frontier18473%_)))))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-stage-view!
      (lambda (_%state18465%_ _%row18466%_ _%budget18467%_ _%check18468%_)
        (let ((_%frontier18470%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/table/storage#gerbil-ascent-storage-view-extension!
                  _%state18465%_
                  _%row18466%_
                  _%budget18467%_))))
          (if _%check18468%_
              (let ()
                (declare (not safe))
                (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
                 _%check18468%_
                 _%frontier18470%_))
              '#!void)
          (if (let ()
                (declare (not safe))
                (gerbil-ascent/table/storage#gerbil-ascent-storage-eqrel-state?
                 _%state18465%_))
              (let ((__tmp35783
                     (let ()
                       (declare (not safe))
                       (gerbil-ascent/core/relation-view#gerbil-ascent-row-count
                        _%frontier18470%_))))
                (declare (not safe))
                (##structure
                 gerbil-ascent/program/view-state#staged-frontier-count::t
                 __tmp35783))
              _%frontier18470%_))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-commit-view!__%
      (lambda (_%index18405%_
               _%state18406%_
               _%frontier18407%_
               _%all18408%_
               _%delta18409%_
               _%all-size18410%_
               _%delta-size18411%_
               _%all-version18412%_
               _%delta-version18413%_
               _%name18414%_
               _%generation18415%_
               _%events18416%_
               _%indexed?18417%_)
        (let ((__tmp35788
               (lambda ()
                 (let ((__tmp35789
                        (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                         _%frontier18407%_)))
                   (declare (not safe))
                   (gerbil-ascent/table/storage#gerbil-ascent-storage-publish-view!
                    _%state18406%_
                    _%frontier18407%_
                    __tmp35789
                    _%indexed?18417%_))))
              (__tmp35784
               (lambda (_%carrier18420%_ _%change-carrier18421%_)
                 (let* ((_%revision18423%_
                         (+ '1
                            (vector-ref _%all-version18412%_ _%index18405%_)))
                        (_%eqrel?18425%_
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/table/storage#gerbil-ascent-storage-eqrel-state?
                            _%state18406%_)))
                        (_%total18427%_
                         (gerbil-ascent/program/view-state#gerbil-ascent-view-export-cut__%
                          (let ()
                            (declare (not safe))
                            (gerbil-ascent/core/relation-view#gerbil-ascent-view-bind
                             _%carrier18420%_
                             _%name18414%_
                             _%generation18415%_
                             _%revision18423%_
                             'total))
                          _%events18416%_
                          _%eqrel?18425%_))
                        (_%change18430%_
                         (let ((__tmp35787
                                (let ()
                                  (declare (not safe))
                                  (gerbil-ascent/core/relation-view#gerbil-ascent-view-bind
                                   _%change-carrier18421%_
                                   _%name18414%_
                                   _%generation18415%_
                                   _%revision18423%_
                                   'delta)))
                               (__tmp35785
                                (lambda ()
                                  (let ((__tmp35786
                                         (gerbil-ascent/program/view-state#export-events__%
                                          _%events18416%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%total18427%_
                                             '5
                                             '#f
                                             '#f))
                                          (- (let ()
                                               (declare (not safe))
                                               (##unchecked-structure-ref
                                                _%total18427%_
                                                '5
                                                '#f
                                                '#f))
                                             (##structure-ref
                                              _%change-carrier18421%_
                                              '5
                                              gerbil-ascent/core/relation-view#relation-view::t
                                              '#f))
                                          '#t
                                          _%eqrel?18425%_)))
                                    (declare (not safe))
                                    (##reverse __tmp35786)))))
                           (declare (not safe))
                           (gerbil-ascent/core/relation-view#gerbil-ascent-view-with-export
                            __tmp35787
                            __tmp35785))))
                   (vector-set! _%all18408%_ _%index18405%_ _%total18427%_)
                   (vector-set! _%delta18409%_ _%index18405%_ _%change18430%_)
                   (vector-set!
                    _%all-size18410%_
                    _%index18405%_
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-ref _%total18427%_ '5 '#f '#f)))
                   (vector-set!
                    _%delta-size18411%_
                    _%index18405%_
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-ref _%change18430%_ '5 '#f '#f)))
                   (vector-set!
                    _%all-version18412%_
                    _%index18405%_
                    _%revision18423%_)
                   (vector-set!
                    _%delta-version18413%_
                    _%index18405%_
                    (+ '1
                       (vector-ref _%delta-version18413%_ _%index18405%_)))))))
          (declare (not safe))
          (##call-with-values __tmp35788 __tmp35784))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-commit-view!__0
      (lambda (_%index18436%_
               _%state18437%_
               _%frontier18438%_
               _%all18439%_
               _%delta18440%_
               _%all-size18441%_
               _%delta-size18442%_
               _%all-version18443%_
               _%delta-version18444%_
               _%name18445%_
               _%generation18446%_
               _%events18447%_)
        (let ((_%indexed?18449%_ '#f))
          (gerbil-ascent/program/view-state#gerbil-ascent-commit-view!__%
           _%index18436%_
           _%state18437%_
           _%frontier18438%_
           _%all18439%_
           _%delta18440%_
           _%all-size18441%_
           _%delta-size18442%_
           _%all-version18443%_
           _%delta-version18444%_
           _%name18445%_
           _%generation18446%_
           _%events18447%_
           _%indexed?18449%_))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-commit-view!
      (lambda _g35790_
        (let ((_g35791_ (let () (declare (not safe)) (##length _g35790_))))
          (cond ((let () (declare (not safe)) (##fx= _g35791_ 12))
                 (apply gerbil-ascent/program/view-state#gerbil-ascent-commit-view!__0
                        _g35790_))
                ((let () (declare (not safe)) (##fx= _g35791_ 13))
                 (apply gerbil-ascent/program/view-state#gerbil-ascent-commit-view!__%
                        _g35790_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/view-state#gerbil-ascent-commit-view!
                  _g35790_))))))
    (define gerbil-ascent/program/view-state#view-event::t
      (let ((__tmp35793 (list)) (__tmp35792 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/view-state#view-event::t
         'view-event
         __tmp35793
         '(kind rows eqrel?)
         __tmp35792
         '#f)))
    (define gerbil-ascent/program/view-state#view-event?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/view-state#view-event::t)))
    (define gerbil-ascent/program/view-state#make-view-event
      (lambda _%$args18401%_
        (apply make-instance
               gerbil-ascent/program/view-state#view-event::t
               _%$args18401%_)))
    (define gerbil-ascent/program/view-state#view-event-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-event::t
         'kind)))
    (define gerbil-ascent/program/view-state#view-event-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-event::t
         'rows)))
    (define gerbil-ascent/program/view-state#view-event-eqrel?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/view-state#view-event::t
         'eqrel?)))
    (define gerbil-ascent/program/view-state#view-event-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-event::t
         'kind)))
    (define gerbil-ascent/program/view-state#view-event-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-event::t
         'rows)))
    (define gerbil-ascent/program/view-state#view-event-eqrel?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/view-state#view-event::t
         'eqrel?)))
    (define gerbil-ascent/program/view-state#&view-event-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-event::t
         'kind)))
    (define gerbil-ascent/program/view-state#&view-event-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-event::t
         'rows)))
    (define gerbil-ascent/program/view-state#&view-event-eqrel?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/view-state#view-event::t
         'eqrel?)))
    (define gerbil-ascent/program/view-state#&view-event-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-event::t
         'kind)))
    (define gerbil-ascent/program/view-state#&view-event-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-event::t
         'rows)))
    (define gerbil-ascent/program/view-state#&view-event-eqrel?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/view-state#view-event::t
         'eqrel?)))
    (define gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event__%
      (lambda (_%kind18383%_ _%rows18384%_ _%eqrel?18385%_)
        (let ((__tmp35794
               (map (lambda (_%row18387%_) (map values _%row18387%_))
                    _%rows18384%_)))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/view-state#view-event::t
           _%kind18383%_
           __tmp35794
           _%eqrel?18385%_))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event__0
      (lambda (_%kind18392%_ _%rows18393%_)
        (let ((_%eqrel?18395%_ '#f))
          (gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event__%
           _%kind18392%_
           _%rows18393%_
           _%eqrel?18395%_))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event
      (lambda _g35795_
        (let ((_g35796_ (let () (declare (not safe)) (##length _g35795_))))
          (cond ((let () (declare (not safe)) (##fx= _g35796_ 2))
                 (apply gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event__0
                        _g35795_))
                ((let () (declare (not safe)) (##fx= _g35796_ 3))
                 (apply gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event__%
                        _g35795_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event
                  _g35795_))))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-view-export-cut__%
      (lambda (_%view18362%_ _%events18363%_ _%eqrel?18364%_)
        (let ((__tmp35797
               (lambda ()
                 (gerbil-ascent/program/view-state#export-events__%
                  _%events18363%_
                  (##structure-ref
                   _%view18362%_
                   '5
                   gerbil-ascent/core/relation-view#relation-view::t
                   '#f)
                  '0
                  '#f
                  (let ((_%$e18367%_ _%eqrel?18364%_))
                    (if _%$e18367%_
                        _%$e18367%_
                        (if (pair? _%events18363%_)
                            (##structure-ref
                             (let ()
                               (declare (not safe))
                               (##car _%events18363%_))
                             '3
                             gerbil-ascent/program/view-state#view-event::t
                             '#f)
                            '#f)))))))
          (declare (not safe))
          (gerbil-ascent/core/relation-view#gerbil-ascent-view-with-export
           _%view18362%_
           __tmp35797))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-view-export-cut__0
      (lambda (_%view18373%_ _%events18374%_)
        (let ((_%eqrel?18376%_ '#f))
          (gerbil-ascent/program/view-state#gerbil-ascent-view-export-cut__%
           _%view18373%_
           _%events18374%_
           _%eqrel?18376%_))))
    (define gerbil-ascent/program/view-state#gerbil-ascent-view-export-cut
      (lambda _g35798_
        (let ((_g35799_ (let () (declare (not safe)) (##length _g35798_))))
          (cond ((let () (declare (not safe)) (##fx= _g35799_ 2))
                 (apply gerbil-ascent/program/view-state#gerbil-ascent-view-export-cut__0
                        _g35798_))
                ((let () (declare (not safe)) (##fx= _g35799_ 3))
                 (apply gerbil-ascent/program/view-state#gerbil-ascent-view-export-cut__%
                        _g35798_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/view-state#gerbil-ascent-view-export-cut
                  _g35798_))))))
    (define gerbil-ascent/program/view-state#export-events__%
      (lambda (_%events18328%_
               _%budget18329%_
               _%skip18330%_
               _%delta?18331%_
               _%eqrel?18332%_)
        (let ((_%$e18334%_
               (if _%eqrel?18332%_
                   '#f
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/program/view-replay#gerbil-ascent-small-journal-export
                      _%events18328%_
                      gerbil-ascent/program/view-state#view-event-kind
                      gerbil-ascent/program/view-state#view-event-rows
                      _%budget18329%_
                      _%skip18330%_
                      _%delta?18331%_)))))
          (if _%$e18334%_
              _%$e18334%_
              (gerbil-ascent/program/view-state#replay-events
               _%events18328%_
               _%budget18329%_
               _%skip18330%_
               _%delta?18331%_
               _%eqrel?18332%_)))))
    (define gerbil-ascent/program/view-state#export-events__0
      (lambda (_%events18340%_ _%budget18341%_ _%skip18342%_)
        (let* ((_%delta?18344%_ '#f) (_%eqrel?18346%_ '#f))
          (gerbil-ascent/program/view-state#export-events__%
           _%events18340%_
           _%budget18341%_
           _%skip18342%_
           _%delta?18344%_
           _%eqrel?18346%_))))
    (define gerbil-ascent/program/view-state#export-events__1
      (lambda (_%events18348%_ _%budget18349%_ _%skip18350%_ _%delta?18351%_)
        (let ((_%eqrel?18353%_ '#f))
          (gerbil-ascent/program/view-state#export-events__%
           _%events18348%_
           _%budget18349%_
           _%skip18350%_
           _%delta?18351%_
           _%eqrel?18353%_))))
    (define gerbil-ascent/program/view-state#export-events
      (lambda _g35800_
        (let ((_g35801_ (let () (declare (not safe)) (##length _g35800_))))
          (cond ((let () (declare (not safe)) (##fx= _g35801_ 3))
                 (apply gerbil-ascent/program/view-state#export-events__0
                        _g35800_))
                ((let () (declare (not safe)) (##fx= _g35801_ 4))
                 (apply gerbil-ascent/program/view-state#export-events__1
                        _g35800_))
                ((let () (declare (not safe)) (##fx= _g35801_ 5))
                 (apply gerbil-ascent/program/view-state#export-events__%
                        _g35800_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/view-state#export-events
                  _g35800_))))))
    (define gerbil-ascent/program/view-state#replay-events
      (lambda (_%events18299%_
               _%budget18300%_
               _%skip18301%_
               _%delta?18302%_
               _%eqrel?18303%_)
        (let ((_%state18305%_
               (if _%eqrel?18303%_
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-state))
                   (let ()
                     (declare (not safe))
                     (make-hash-table__%
                      '#f
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value))))
              (_%output18306%_ '())
              (_%admitted18307%_ '0))
          (let ((__tmp35803
                 (lambda (_%event18309%_)
                   (let ((_%batch18311%_ '())
                         (_%derived?18312%_
                          (if _%delta?18302%_
                              '#f
                              (eq? (##structure-ref
                                    _%event18309%_
                                    '1
                                    gerbil-ascent/program/view-state#view-event::t
                                    '#f)
                                   'derived))))
                     (for-each
                      (lambda (_%row18314%_)
                        (let* ((_%frontier18316%_
                                ((if _%eqrel?18303%_
                                     gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-insert!
                                     gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-insert!)
                                 _%state18305%_
                                 _%row18314%_
                                 _%budget18300%_))
                               (_%next18318%_
                                (+ _%admitted18307%_
                                   (let ()
                                     (declare (not safe))
                                     (##unchecked-structure-ref
                                      _%frontier18316%_
                                      '5
                                      '#f
                                      '#f)))))
                          (if (> _%next18318%_ _%skip18301%_)
                              (begin
                                (if (> _%skip18301%_ _%admitted18307%_)
                                    (let ()
                                      (declare (not safe))
                                      (error '"ASCENT ordered delta splits an injection frontier"))
                                    '#!void)
                                (let ((__tmp35804
                                       (if _%derived?18312%_
                                           (lambda (_%stored18321%_)
                                             (set! _%batch18311%_
                                                   (cons _%stored18321%_
                                                         _%batch18311%_)))
                                           (lambda (_%stored18323%_)
                                             (set! _%output18306%_
                                                   (cons _%stored18323%_
                                                         _%output18306%_))))))
                                  (declare (not safe))
                                  (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
                                   __tmp35804
                                   _%frontier18316%_)))
                              '#!void)
                          (set! _%admitted18307%_ _%next18318%_)))
                      (##structure-ref
                       _%event18309%_
                       '2
                       gerbil-ascent/program/view-state#view-event::t
                       '#f))
                     (if _%derived?18312%_
                         (let ((__tmp35805
                                (lambda (_%row18325%_)
                                  (set! _%output18306%_
                                        (cons _%row18325%_ _%output18306%_)))))
                           (declare (not safe))
                           (##for-each __tmp35805 _%batch18311%_))
                         '#!void))))
                (__tmp35802 (reverse _%events18299%_)))
            (declare (not safe))
            (##for-each __tmp35803 __tmp35802))
          (let () (declare (not safe)) (##reverse _%output18306%_)))))))
