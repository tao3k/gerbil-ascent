(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/index-sharing::timestamp 1791689666)
  (begin
    (define gerbil-ascent/table/index-sharing#gerbil-ascent-index-sharing-certificate?
      (lambda (_%sets14615%_ _%left14616%_ _%right14617%_)
        (let ((__tmp33552
               (lambda (_%reject14619%_)
                 (if (and (vector? _%sets14615%_)
                          (vector? _%left14616%_)
                          (vector? _%right14617%_)
                          (= (let ()
                               (declare (not safe))
                               (##vector-length _%sets14615%_))
                             (let ()
                               (declare (not safe))
                               (##vector-length _%left14616%_))
                             (let ()
                               (declare (not safe))
                               (##vector-length _%right14617%_))))
                     '#!void
                     (_%reject14619%_ '#f))
                 (let* ((_%count14621%_ (vector-length _%sets14615%_))
                        (_%ids14623%_
                         (let () (declare (not safe)) (##iota _%count14621%_)))
                        (_%widths14625%_ (vector-map length _%sets14615%_))
                        (_%members14627%_
                         (let ()
                           (declare (not safe))
                           (##make-vector _%count14621%_ '#f)))
                        (_%seen-left14629%_
                         (let ()
                           (declare (not safe))
                           (##make-vector _%count14621%_ '#f)))
                        (_%seen-right14631%_
                         (let ()
                           (declare (not safe))
                           (##make-vector _%count14621%_ '#f)))
                        (_%pending14633%_ '())
                        (_%matched14635%_ '0)
                        (_%cover-count14637%_ '0))
                   (letrec ((_%membership14640%_
                             (lambda (_%j14676%_)
                               (let ((_%$e14678%_
                                      (vector-ref
                                       _%members14627%_
                                       _%j14676%_)))
                                 (if _%$e14678%_
                                     _%$e14678%_
                                     (let ((_%table14681%_
                                            (let ()
                                              (declare (not safe))
                                              (make-hash-table__%
                                               '#f
                                               absent-value
                                               absent-value
                                               absent-value
                                               absent-value
                                               absent-value
                                               absent-value
                                               absent-value
                                               absent-value))))
                                       (for-each
                                        (lambda (_%$%g1468214684%_)
                                          (let ()
                                            (declare (not safe))
                                            (__hash-put!
                                             _%table14681%_
                                             _%$%g1468214684%_
                                             '#t)))
                                        (vector-ref _%sets14615%_ _%j14676%_))
                                       (vector-set!
                                        _%members14627%_
                                        _%j14676%_
                                        _%table14681%_)
                                       _%table14681%_)))))
                            (_%below?14641%_
                             (lambda (_%i14667%_ _%j14668%_)
                               (if (< (vector-ref _%widths14625%_ _%i14667%_)
                                      (vector-ref _%widths14625%_ _%j14668%_))
                                   (let ((_%table14670%_
                                          (_%membership14640%_ _%j14668%_)))
                                     (let ((__tmp33554
                                            (lambda (_%$%g1467114673%_)
                                              (let ()
                                                (declare (not safe))
                                                (hash-key?
                                                 _%table14670%_
                                                 _%$%g1467114673%_))))
                                           (__tmp33553
                                            (vector-ref
                                             _%sets14615%_
                                             _%i14667%_)))
                                       (declare (not safe))
                                       (andmap__0 __tmp33554 __tmp33553)))
                                   '#f)))
                            (_%index?14642%_
                             (lambda (_%x14662%_)
                               (let ((_%$e14664%_ (eq? _%x14662%_ '#f)))
                                 (if _%$e14664%_
                                     _%$e14664%_
                                     (if (exact-integer? _%x14662%_)
                                         (if (<= '0 _%x14662%_)
                                             (< _%x14662%_ _%count14621%_)
                                             '#f)
                                         '#f))))))
                     (if (and (let ((__tmp33555 (vector->list _%left14616%_)))
                                (declare (not safe))
                                (andmap__0 _%index?14642%_ __tmp33555))
                              (let ((__tmp33556 (vector->list _%right14617%_)))
                                (declare (not safe))
                                (andmap__0 _%index?14642%_ __tmp33556)))
                         '#!void
                         (_%reject14619%_ '#f))
                     (let ((__tmp33557
                            (lambda (_%i14644%_)
                              (let ((_%j14646%_
                                     (vector-ref _%left14616%_ _%i14644%_))
                                    (_%owner14647%_
                                     (vector-ref _%right14617%_ _%i14644%_)))
                                (if _%j14646%_
                                    (begin
                                      (if (and (eqv? (vector-ref
                                                      _%right14617%_
                                                      _%j14646%_)
                                                     _%i14644%_)
                                               (_%below?14641%_
                                                _%i14644%_
                                                _%j14646%_))
                                          '#!void
                                          (_%reject14619%_ '#f))
                                      (set! _%matched14635%_
                                            (+ _%matched14635%_ '1)))
                                    '#!void)
                                (if _%owner14647%_
                                    (if (eqv? (vector-ref
                                               _%left14616%_
                                               _%owner14647%_)
                                              _%i14644%_)
                                        '#!void
                                        (_%reject14619%_ '#f))
                                    '#!void)
                                (if _%j14646%_
                                    '#!void
                                    (begin
                                      (vector-set!
                                       _%seen-left14629%_
                                       _%i14644%_
                                       '#t)
                                      (set! _%pending14633%_
                                            (cons _%i14644%_
                                                  _%pending14633%_))))))))
                       (declare (not safe))
                       (##for-each __tmp33557 _%ids14623%_))
                     (let _%traverse14649%_ ()
                       (if (pair? _%pending14633%_)
                           (begin
                             (let ((_%i14652%_ (car _%pending14633%_)))
                               (set! _%pending14633%_ (cdr _%pending14633%_))
                               (let ((__tmp33558
                                      (lambda (_%j14654%_)
                                        (if (and (_%below?14641%_
                                                  _%i14652%_
                                                  _%j14654%_)
                                                 (not (vector-ref
                                                       _%seen-right14631%_
                                                       _%j14654%_)))
                                            (begin
                                              (vector-set!
                                               _%seen-right14631%_
                                               _%j14654%_
                                               '#t)
                                              (let ((_%owner14656%_
                                                     (vector-ref
                                                      _%right14617%_
                                                      _%j14654%_)))
                                                (if _%owner14656%_
                                                    '#!void
                                                    (_%reject14619%_ '#f))
                                                (if (vector-ref
                                                     _%seen-left14629%_
                                                     _%owner14656%_)
                                                    '#!void
                                                    (begin
                                                      (vector-set!
                                                       _%seen-left14629%_
                                                       _%owner14656%_
                                                       '#t)
                                                      (set! _%pending14633%_
                                                            (cons _%owner14656%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          _%pending14633%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            '#!void))))
                                 (declare (not safe))
                                 (##for-each __tmp33558 _%ids14623%_)))
                             (_%traverse14649%_))
                           '#!void))
                     (let ((__tmp33559
                            (lambda (_%i14658%_)
                              (if (vector-ref _%seen-left14629%_ _%i14658%_)
                                  '#!void
                                  (set! _%cover-count14637%_
                                        (+ _%cover-count14637%_ '1)))
                              (if (vector-ref _%seen-right14631%_ _%i14658%_)
                                  (set! _%cover-count14637%_
                                        (+ _%cover-count14637%_ '1))
                                  '#!void)
                              (let ((__tmp33560
                                     (lambda (_%j14660%_)
                                       (if (and (_%below?14641%_
                                                 _%i14658%_
                                                 _%j14660%_)
                                                (vector-ref
                                                 _%seen-left14629%_
                                                 _%i14658%_)
                                                (not (vector-ref
                                                      _%seen-right14631%_
                                                      _%j14660%_)))
                                           (_%reject14619%_ '#f)
                                           '#!void))))
                                (declare (not safe))
                                (##for-each __tmp33560 _%ids14623%_)))))
                       (declare (not safe))
                       (##for-each __tmp33559 _%ids14623%_))
                     (= _%matched14635%_ _%cover-count14637%_))))))
          (declare (not safe))
          (##call-with-current-continuation __tmp33552))))
    (define gerbil-ascent/table/index-sharing#ordered-subset?
      (lambda (_%selected14607%_ _%available14608%_)
        (if (null? _%selected14607%_)
            '#t
            (if (null? _%available14608%_)
                '#f
                (if (= (car _%selected14607%_) (car _%available14608%_))
                    (gerbil-ascent/table/index-sharing#ordered-subset?
                     (cdr _%selected14607%_)
                     (cdr _%available14608%_))
                    (if (> (car _%selected14607%_) (car _%available14608%_))
                        (gerbil-ascent/table/index-sharing#ordered-subset?
                         _%selected14607%_
                         (cdr _%available14608%_))
                        '#f))))))
    (define gerbil-ascent/table/index-sharing#column-order::t
      (let ((__tmp33562 (list))
            (__tmp33561
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/index-sharing#column-order::t
         'column-order
         __tmp33562
         '(sets successors)
         __tmp33561
         '#f)))
    (define gerbil-ascent/table/index-sharing#column-order?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/table/index-sharing#column-order::t)))
    (define gerbil-ascent/table/index-sharing#make-column-order
      (lambda _%$args14604%_
        (apply make-instance
               gerbil-ascent/table/index-sharing#column-order::t
               _%$args14604%_)))
    (define gerbil-ascent/table/index-sharing#column-order-sets
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#column-order::t
         'sets)))
    (define gerbil-ascent/table/index-sharing#column-order-successors
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#column-order::t
         'successors)))
    (define gerbil-ascent/table/index-sharing#column-order-sets-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#column-order::t
         'sets)))
    (define gerbil-ascent/table/index-sharing#column-order-successors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#column-order::t
         'successors)))
    (define gerbil-ascent/table/index-sharing#&column-order-sets
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#column-order::t
         'sets)))
    (define gerbil-ascent/table/index-sharing#&column-order-successors
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#column-order::t
         'successors)))
    (define gerbil-ascent/table/index-sharing#&column-order-sets-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#column-order::t
         'sets)))
    (define gerbil-ascent/table/index-sharing#&column-order-successors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#column-order::t
         'successors)))
    (define gerbil-ascent/table/index-sharing#compile-column-order
      (lambda (_%sets14595%_)
        (let ((_%widths14597%_ (vector-map length _%sets14595%_))
              (_%ids14598%_
               (let ((__tmp33563 (vector-length _%sets14595%_)))
                 (declare (not safe))
                 (##iota __tmp33563))))
          (let ((__tmp33564
                 (list->vector
                  (let ((__tmp33565
                         (lambda (_%i14600%_)
                           (let ((__tmp33566
                                  (lambda (_%j14602%_)
                                    (if (< (vector-ref
                                            _%widths14597%_
                                            _%i14600%_)
                                           (vector-ref
                                            _%widths14597%_
                                            _%j14602%_))
                                        (gerbil-ascent/table/index-sharing#ordered-subset?
                                         (vector-ref _%sets14595%_ _%i14600%_)
                                         (vector-ref _%sets14595%_ _%j14602%_))
                                        '#f))))
                             (declare (not safe))
                             (##filter __tmp33566 _%ids14598%_)))))
                    (declare (not safe))
                    (##map __tmp33565 _%ids14598%_)))))
            (declare (not safe))
            (##structure
             gerbil-ascent/table/index-sharing#column-order::t
             _%sets14595%_
             __tmp33564)))))
    (define gerbil-ascent/table/index-sharing#distinct-ordered-columns?
      (lambda (_%columns14555%_)
        (let* ((_%$%columns1455614566%_ _%columns14555%_)
               (_%$%else1455814574%_ (lambda () '#t))
               (_%$%K1456014580%_
                (lambda (_%right14577%_ _%left14578%_)
                  (if (< _%left14578%_ _%right14577%_)
                      (gerbil-ascent/table/index-sharing#distinct-ordered-columns?
                       (cdr _%columns14555%_))
                      '#f))))
          (if (pair? _%$%columns1455614566%_)
              (let ((_%$%hd1456114583%_
                     (let ()
                       (declare (not safe))
                       (##car _%$%columns1455614566%_)))
                    (_%$%tl1456214585%_
                     (let ()
                       (declare (not safe))
                       (##cdr _%$%columns1455614566%_))))
                (let ((_%left14588%_ _%$%hd1456114583%_))
                  (if (pair? _%$%tl1456214585%_)
                      (let* ((_%$%hd1456314590%_
                              (let ()
                                (declare (not safe))
                                (##car _%$%tl1456214585%_)))
                             (_%right14593%_ _%$%hd1456314590%_))
                        (_%$%K1456014580%_ _%right14593%_ _%left14588%_))
                      (_%$%else1455814574%_))))
              (_%$%else1455814574%_)))))
    (define gerbil-ascent/table/index-sharing#columns-lexicographic<?
      (lambda (_%left14547%_ _%right14548%_)
        (if (null? _%left14547%_)
            (pair? _%right14548%_)
            (if (null? _%right14548%_)
                '#f
                (if (< (car _%left14547%_) (car _%right14548%_))
                    '#t
                    (if (> (car _%left14547%_) (car _%right14548%_))
                        '#f
                        (gerbil-ascent/table/index-sharing#columns-lexicographic<?
                         (cdr _%left14547%_)
                         (cdr _%right14548%_))))))))
    (define gerbil-ascent/table/index-sharing#normalize-column-requirements
      (lambda (_%requirements14537%_)
        (let ((_%unique14539%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (for-each
           (lambda (_%columns14541%_)
             (if (and (list? _%columns14541%_)
                      (let ((__tmp33567
                             (lambda (_%n14543%_)
                               (and (exact-integer? _%n14543%_)
                                    (>= _%n14543%_ '0)))))
                        (declare (not safe))
                        (andmap__0 __tmp33567 _%columns14541%_)))
                 '#!void
                 (let ()
                   (declare (not safe))
                   (error '"invalid index sharing columns" _%columns14541%_)))
             (let ((_%ordered14545%_ (list-sort < _%columns14541%_)))
               (if (gerbil-ascent/table/index-sharing#distinct-ordered-columns?
                    _%ordered14545%_)
                   '#!void
                   (let ()
                     (declare (not safe))
                     (error '"repeated index sharing columns"
                            _%columns14541%_)))
               (if (null? _%ordered14545%_)
                   '#!void
                   (let ()
                     (declare (not safe))
                     (__hash-put! _%unique14539%_ _%ordered14545%_ '#t)))))
           _%requirements14537%_)
          (list->vector
           (let ((__tmp33568
                  (let () (declare (not safe)) (__hash-keys _%unique14539%_))))
             (declare (not safe))
             (##list-sort
              gerbil-ascent/table/index-sharing#columns-lexicographic<?
              __tmp33568))))))
    (define gerbil-ascent/table/index-sharing#gerbil-ascent-index-sharing-layout
      (lambda (_%requirements14484%_)
        (let* ((_%sets14486%_
                (gerbil-ascent/table/index-sharing#normalize-column-requirements
                 _%requirements14484%_))
               (_%order14488%_
                (gerbil-ascent/table/index-sharing#compile-column-order
                 _%sets14486%_))
               (_%successors14490%_
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-ref _%order14488%_ '2 '#f '#f)))
               (_%count14492%_
                (vector-length
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%order14488%_ '1 '#f '#f))))
               (_%left14494%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count14492%_ '#f)))
               (_%right14496%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count14492%_ '#f)))
               (_%layout14498%_
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value))))
          (letrec* ((_%augment!14501%_
                     (lambda (_%i14527%_ _%visited14528%_)
                       (let ((__tmp33570
                              (lambda (_%j14530%_)
                                (if (vector-ref _%visited14528%_ _%j14530%_)
                                    '#f
                                    (begin
                                      (vector-set!
                                       _%visited14528%_
                                       _%j14530%_
                                       '#t)
                                      (let ((_%prior14532%_
                                             (vector-ref
                                              _%right14496%_
                                              _%j14530%_)))
                                        (if (or (not _%prior14532%_)
                                                (_%augment!14501%_
                                                 _%prior14532%_
                                                 _%visited14528%_))
                                            (begin
                                              (vector-set!
                                               _%left14494%_
                                               _%i14527%_
                                               _%j14530%_)
                                              (vector-set!
                                               _%right14496%_
                                               _%j14530%_
                                               _%i14527%_)
                                              '#t)
                                            '#f))))))
                             (__tmp33569
                              (vector-ref _%successors14490%_ _%i14527%_)))
                         (declare (not safe))
                         (ormap__0 __tmp33570 __tmp33569))))
                    (_g33571_
                     (let ((_g33572_
                            (let ((__tmp33575
                                   (lambda (_%i14503%_)
                                     (_%augment!14501%_
                                      _%i14503%_
                                      (let ()
                                        (declare (not safe))
                                        (##make-vector _%count14492%_ '#f)))))
                                  (__tmp33574
                                   (let ()
                                     (declare (not safe))
                                     (##iota _%count14492%_))))
                              (declare (not safe))
                              (##for-each __tmp33575 __tmp33574))))
                       #!void
                       _g33572_))
                    (_g33576_
                     (let ((_g33577_
                            (if (gerbil-ascent/table/index-sharing#gerbil-ascent-index-sharing-certificate?
                                 _%sets14486%_
                                 _%left14494%_
                                 _%right14496%_)
                                '#!void
                                (let ()
                                  (declare (not safe))
                                  (error '"invalid index sharing maximum matching certificate")))))
                       #!void
                       _g33577_))
                    (_%visited14504%_
                     (let ()
                       (declare (not safe))
                       (##make-vector _%count14492%_ '#f))))
            (begin
              (let ((__tmp33580
                     (lambda (_%i14506%_)
                       (if (vector-ref _%right14496%_ _%i14506%_)
                           '#!void
                           (let _%chain14508%_ ((_%j14510%_ _%i14506%_)
                                                (_%members14511%_ '())
                                                (_%permutation14512%_ '()))
                             (if (vector-ref _%visited14504%_ _%j14510%_)
                                 (let ()
                                   (declare (not safe))
                                   (error '"index sharing chain repeats a requirement"))
                                 '#!void)
                             (vector-set! _%visited14504%_ _%j14510%_ '#t)
                             (let* ((_%columns14514%_
                                     (vector-ref _%sets14486%_ _%j14510%_))
                                    (_%next14516%_
                                     (vector-ref _%left14494%_ _%j14510%_))
                                    (_%extended14520%_
                                     (let ((__tmp33581
                                            (filter (lambda (_%c14518%_)
                                                      (not (member _%c14518%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           _%permutation14512%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    _%columns14514%_)))
                                       (declare (not safe))
                                       (##append
                                        _%permutation14512%_
                                        __tmp33581)))
                                    (_%covered14522%_
                                     (cons _%columns14514%_ _%members14511%_)))
                               (if _%next14516%_
                                   (_%chain14508%_
                                    _%next14516%_
                                    _%covered14522%_
                                    _%extended14520%_)
                                   (if (pair? (let ()
                                                (declare (not safe))
                                                (##cdr _%covered14522%_)))
                                       (let ((__tmp33582
                                              (lambda (_%c14525%_)
                                                (let ()
                                                  (declare (not safe))
                                                  (__hash-put!
                                                   _%layout14498%_
                                                   _%c14525%_
                                                   _%extended14520%_)))))
                                         (declare (not safe))
                                         (##for-each
                                          __tmp33582
                                          _%covered14522%_))
                                       '#!void)))))))
                    (__tmp33579
                     (let () (declare (not safe)) (##iota _%count14492%_))))
                (declare (not safe))
                (##for-each __tmp33580 __tmp33579))
              (if (let ((__tmp33583
                         (let ()
                           (declare (not safe))
                           (##vector->list _%visited14504%_))))
                    (declare (not safe))
                    (andmap__0 values __tmp33583))
                  '#!void
                  (let ()
                    (declare (not safe))
                    (error '"index sharing chains omit a requirement")))
              _%layout14498%_)))))
    (define gerbil-ascent/table/index-sharing#shared-index::t
      (let ((__tmp33585 (list)) (__tmp33584 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/index-sharing#shared-index::t
         'shared-index
         __tmp33585
         '(columns root ordinal views projection key-plans)
         __tmp33584
         '#f)))
    (define gerbil-ascent/table/index-sharing#shared-index?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/table/index-sharing#shared-index::t)))
    (define gerbil-ascent/table/index-sharing#make-shared-index
      (lambda _%$args14481%_
        (apply make-instance
               gerbil-ascent/table/index-sharing#shared-index::t
               _%$args14481%_)))
    (define gerbil-ascent/table/index-sharing#shared-index-columns
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'columns)))
    (define gerbil-ascent/table/index-sharing#shared-index-root
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'root)))
    (define gerbil-ascent/table/index-sharing#shared-index-ordinal
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'ordinal)))
    (define gerbil-ascent/table/index-sharing#shared-index-views
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'views)))
    (define gerbil-ascent/table/index-sharing#shared-index-projection
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'projection)))
    (define gerbil-ascent/table/index-sharing#shared-index-key-plans
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'key-plans)))
    (define gerbil-ascent/table/index-sharing#shared-index-columns-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'columns)))
    (define gerbil-ascent/table/index-sharing#shared-index-root-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'root)))
    (define gerbil-ascent/table/index-sharing#shared-index-ordinal-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'ordinal)))
    (define gerbil-ascent/table/index-sharing#shared-index-views-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'views)))
    (define gerbil-ascent/table/index-sharing#shared-index-projection-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'projection)))
    (define gerbil-ascent/table/index-sharing#shared-index-key-plans-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'key-plans)))
    (define gerbil-ascent/table/index-sharing#&shared-index-columns
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'columns)))
    (define gerbil-ascent/table/index-sharing#&shared-index-root
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'root)))
    (define gerbil-ascent/table/index-sharing#&shared-index-ordinal
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'ordinal)))
    (define gerbil-ascent/table/index-sharing#&shared-index-views
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'views)))
    (define gerbil-ascent/table/index-sharing#&shared-index-projection
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'projection)))
    (define gerbil-ascent/table/index-sharing#&shared-index-key-plans
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'key-plans)))
    (define gerbil-ascent/table/index-sharing#&shared-index-columns-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'columns)))
    (define gerbil-ascent/table/index-sharing#&shared-index-root-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'root)))
    (define gerbil-ascent/table/index-sharing#&shared-index-ordinal-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'ordinal)))
    (define gerbil-ascent/table/index-sharing#&shared-index-views-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'views)))
    (define gerbil-ascent/table/index-sharing#&shared-index-projection-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'projection)))
    (define gerbil-ascent/table/index-sharing#&shared-index-key-plans-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'key-plans)))
    (define gerbil-ascent/table/index-sharing#column-projection::t
      (let ((__tmp33587 (list)) (__tmp33586 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/index-sharing#column-projection::t
         'column-projection
         __tmp33587
         '(columns writes frame)
         __tmp33586
         '#f)))
    (define gerbil-ascent/table/index-sharing#column-projection?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/table/index-sharing#column-projection::t)))
    (define gerbil-ascent/table/index-sharing#make-column-projection
      (lambda _%$args14478%_
        (apply make-instance
               gerbil-ascent/table/index-sharing#column-projection::t
               _%$args14478%_)))
    (define gerbil-ascent/table/index-sharing#column-projection-columns
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#column-projection::t
         'columns)))
    (define gerbil-ascent/table/index-sharing#column-projection-writes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#column-projection::t
         'writes)))
    (define gerbil-ascent/table/index-sharing#column-projection-frame
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#column-projection::t
         'frame)))
    (define gerbil-ascent/table/index-sharing#column-projection-columns-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#column-projection::t
         'columns)))
    (define gerbil-ascent/table/index-sharing#column-projection-writes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#column-projection::t
         'writes)))
    (define gerbil-ascent/table/index-sharing#column-projection-frame-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#column-projection::t
         'frame)))
    (define gerbil-ascent/table/index-sharing#&column-projection-columns
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#column-projection::t
         'columns)))
    (define gerbil-ascent/table/index-sharing#&column-projection-writes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#column-projection::t
         'writes)))
    (define gerbil-ascent/table/index-sharing#&column-projection-frame
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#column-projection::t
         'frame)))
    (define gerbil-ascent/table/index-sharing#&column-projection-columns-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#column-projection::t
         'columns)))
    (define gerbil-ascent/table/index-sharing#&column-projection-writes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#column-projection::t
         'writes)))
    (define gerbil-ascent/table/index-sharing#&column-projection-frame-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#column-projection::t
         'frame)))
    (define gerbil-ascent/table/index-sharing#key-projection::t
      (let ((__tmp33589 (list))
            (__tmp33588
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/index-sharing#key-projection::t
         'key-projection
         __tmp33589
         '(physical writes frame)
         __tmp33588
         '#f)))
    (define gerbil-ascent/table/index-sharing#key-projection?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/table/index-sharing#key-projection::t)))
    (define gerbil-ascent/table/index-sharing#make-key-projection
      (lambda _%$args14475%_
        (apply make-instance
               gerbil-ascent/table/index-sharing#key-projection::t
               _%$args14475%_)))
    (define gerbil-ascent/table/index-sharing#key-projection-physical
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#key-projection::t
         'physical)))
    (define gerbil-ascent/table/index-sharing#key-projection-writes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#key-projection::t
         'writes)))
    (define gerbil-ascent/table/index-sharing#key-projection-frame
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#key-projection::t
         'frame)))
    (define gerbil-ascent/table/index-sharing#key-projection-physical-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#key-projection::t
         'physical)))
    (define gerbil-ascent/table/index-sharing#key-projection-writes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#key-projection::t
         'writes)))
    (define gerbil-ascent/table/index-sharing#key-projection-frame-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#key-projection::t
         'frame)))
    (define gerbil-ascent/table/index-sharing#&key-projection-physical
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#key-projection::t
         'physical)))
    (define gerbil-ascent/table/index-sharing#&key-projection-writes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#key-projection::t
         'writes)))
    (define gerbil-ascent/table/index-sharing#&key-projection-frame
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#key-projection::t
         'frame)))
    (define gerbil-ascent/table/index-sharing#&key-projection-physical-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#key-projection::t
         'physical)))
    (define gerbil-ascent/table/index-sharing#&key-projection-writes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#key-projection::t
         'writes)))
    (define gerbil-ascent/table/index-sharing#&key-projection-frame-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#key-projection::t
         'frame)))
    (define gerbil-ascent/table/index-sharing#key-sequence=?
      (lambda (_%left14472%_ _%right14473%_)
        (if (null? _%left14472%_)
            (null? _%right14473%_)
            (if (pair? _%right14473%_)
                (if (equal? (car _%left14472%_)
                            (let ()
                              (declare (not safe))
                              (##car _%right14473%_)))
                    (gerbil-ascent/table/index-sharing#key-sequence=?
                     (cdr _%left14472%_)
                     (let () (declare (not safe)) (##cdr _%right14473%_)))
                    '#f)
                '#f))))
    (define gerbil-ascent/table/index-sharing#gerbil-ascent-shared-index-build
      (lambda (_%rows14467%_ _%columns14468%_)
        (let ((_%index14470%_
               (let ((__tmp33591
                      (let ()
                        (declare (not safe))
                        (make-hash-table__%
                         '#f
                         absent-value
                         absent-value
                         absent-value
                         absent-value
                         absent-value
                         absent-value
                         absent-value
                         absent-value)))
                     (__tmp33590
                      (let ()
                        (declare (not safe))
                        (make-hash-table__%
                         '#f
                         absent-value
                         absent-value
                         gerbil-ascent/table/index-sharing#key-sequence=?
                         equal?-hash
                         absent-value
                         absent-value
                         absent-value
                         absent-value))))
                 (declare (not safe))
                 (##structure
                  gerbil-ascent/table/index-sharing#shared-index::t
                  _%columns14468%_
                  __tmp33591
                  '0
                  __tmp33590
                  '#f
                  '#f))))
          (gerbil-ascent/table/index-sharing#gerbil-ascent-shared-index-extend!
           _%index14470%_
           (reverse _%rows14467%_))
          _%index14470%_)))
    (define gerbil-ascent/table/index-sharing#gerbil-ascent-shared-index-extend!
      (lambda (_%index14430%_ _%rows14431%_)
        (if (pair? _%rows14431%_)
            (begin
              (##structure-set!
               _%index14430%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  gerbil-ascent/table/index-sharing#key-sequence=?
                  equal?-hash
                  absent-value
                  absent-value
                  absent-value
                  absent-value))
               '4
               gerbil-ascent/table/index-sharing#shared-index::t
               '#f)
              (let* ((_%columns14433%_
                      (##structure-ref
                       _%index14430%_
                       '1
                       gerbil-ascent/table/index-sharing#shared-index::t
                       '#f))
                     (_%width14435%_ (length _%columns14433%_))
                     (_%projection14437%_
                      (gerbil-ascent/table/index-sharing#column-projection-for!
                       _%index14430%_
                       _%columns14433%_
                       _%width14435%_))
                     (_%writes14439%_
                      (##structure-ref
                       _%projection14437%_
                       '2
                       gerbil-ascent/table/index-sharing#column-projection::t
                       '#f))
                     (_%frame14441%_
                      (##structure-ref
                       _%projection14437%_
                       '3
                       gerbil-ascent/table/index-sharing#column-projection::t
                       '#f)))
                (letrec ((_%insert!14444%_
                          (lambda (_%node14450%_
                                   _%depth14451%_
                                   _%row14452%_
                                   _%ordinal14453%_)
                            (let ((_%key14455%_
                                   (vector-ref _%frame14441%_ _%depth14451%_)))
                              (if (= (+ _%depth14451%_ '1) _%width14435%_)
                                  (let ((__tmp33592
                                         (cons (cons _%ordinal14453%_
                                                     _%row14452%_)
                                               (let ((_%$e14457%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (hash-get
                                                         _%node14450%_
                                                         _%key14455%_))))
                                                 (if _%$e14457%_
                                                     _%$e14457%_
                                                     '())))))
                                    (declare (not safe))
                                    (hash-put!
                                     _%node14450%_
                                     _%key14455%_
                                     __tmp33592))
                                  (let ((_%child14465%_
                                         (let ((_%$e14460%_
                                                (let ()
                                                  (declare (not safe))
                                                  (hash-get
                                                   _%node14450%_
                                                   _%key14455%_))))
                                           (if _%$e14460%_
                                               _%$e14460%_
                                               (let ((_%fresh14463%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (make-hash-table__%
                                                         '#f
                                                         absent-value
                                                         absent-value
                                                         absent-value
                                                         absent-value
                                                         absent-value
                                                         absent-value
                                                         absent-value
                                                         absent-value))))
                                                 (let ()
                                                   (declare (not safe))
                                                   (hash-put!
                                                    _%node14450%_
                                                    _%key14455%_
                                                    _%fresh14463%_))
                                                 _%fresh14463%_)))))
                                    (_%insert!14444%_
                                     _%child14465%_
                                     (+ _%depth14451%_ '1)
                                     _%row14452%_
                                     _%ordinal14453%_)))))))
                  (let ((__tmp33593
                         (lambda (_%row14446%_)
                           (let ((_%ordinal14448%_
                                  (+ (##structure-ref
                                      _%index14430%_
                                      '3
                                      gerbil-ascent/table/index-sharing#shared-index::t
                                      '#f)
                                     '1)))
                             (gerbil-ascent/table/index-sharing#fill-column-frame!
                              _%row14446%_
                              _%writes14439%_
                              _%frame14441%_)
                             (_%insert!14444%_
                              (##structure-ref
                               _%index14430%_
                               '2
                               gerbil-ascent/table/index-sharing#shared-index::t
                               '#f)
                              '0
                              _%row14446%_
                              _%ordinal14448%_)
                             (##structure-set!
                              _%index14430%_
                              _%ordinal14448%_
                              '3
                              gerbil-ascent/table/index-sharing#shared-index::t
                              '#f)))))
                    (declare (not safe))
                    (##for-each __tmp33593 _%rows14431%_)))))
            '#!void)
        _%index14430%_))
    (define gerbil-ascent/table/index-sharing#column-projection-for!
      (lambda (_%index14422%_ _%columns14423%_ _%width14424%_)
        (let ((_%prior14426%_
               (##structure-ref
                _%index14422%_
                '5
                gerbil-ascent/table/index-sharing#shared-index::t
                '#f)))
          (if (and _%prior14426%_
                   (gerbil-ascent/table/index-sharing#same-columns?
                    _%columns14423%_
                    (##structure-ref
                     _%prior14426%_
                     '1
                     gerbil-ascent/table/index-sharing#column-projection::t
                     '#f)))
              _%prior14426%_
              (let ((_%fresh14428%_
                     (let ((__tmp33596 (list->vector _%columns14423%_))
                           (__tmp33595
                            (gerbil-ascent/table/index-sharing#column-writes
                             _%columns14423%_))
                           (__tmp33594 (make-vector _%width14424%_ '#f)))
                       (declare (not safe))
                       (##structure
                        gerbil-ascent/table/index-sharing#column-projection::t
                        __tmp33596
                        __tmp33595
                        __tmp33594))))
                (##structure-set!
                 _%index14422%_
                 _%fresh14428%_
                 '5
                 gerbil-ascent/table/index-sharing#shared-index::t
                 '#f)
                _%fresh14428%_)))))
    (define gerbil-ascent/table/index-sharing#same-columns?
      (lambda (_%columns14414%_ _%snapshot14415%_)
        (let _%compare14417%_ ((_%remaining14419%_ _%columns14414%_)
                               (_%slot14420%_ '0))
          (if (null? _%remaining14419%_)
              (= _%slot14420%_ (vector-length _%snapshot14415%_))
              (if (< _%slot14420%_ (vector-length _%snapshot14415%_))
                  (if (equal? (car _%remaining14419%_)
                              (vector-ref _%snapshot14415%_ _%slot14420%_))
                      (_%compare14417%_
                       (cdr _%remaining14419%_)
                       (+ _%slot14420%_ '1))
                      '#f)
                  '#f)))))
    (define gerbil-ascent/table/index-sharing#column-writes
      (lambda (_%columns14393%_)
        (let _%gather14395%_ ((_%remaining14397%_ _%columns14393%_)
                              (_%slot14398%_ '0)
                              (_%entries14399%_ '()))
          (if (null? _%remaining14397%_)
              (let ((_%ordered14404%_
                     (list-sort!
                      (lambda (_%a14401%_ _%b14402%_)
                        (< (car _%a14401%_) (car _%b14402%_)))
                      _%entries14399%_)))
                (let _%steps14406%_ ((_%remaining14408%_ _%ordered14404%_)
                                     (_%position14409%_ '0)
                                     (_%writes14410%_ '()))
                  (if (null? _%remaining14408%_)
                      (reverse! _%writes14410%_)
                      (let ((_%entry14412%_ (car _%remaining14408%_)))
                        (_%steps14406%_
                         (cdr _%remaining14408%_)
                         (+ (car _%entry14412%_) '1)
                         (cons (cons (- (car _%entry14412%_) _%position14409%_)
                                     (cdr _%entry14412%_))
                               _%writes14410%_))))))
              (_%gather14395%_
               (cdr _%remaining14397%_)
               (+ _%slot14398%_ '1)
               (cons (cons (car _%remaining14397%_) _%slot14398%_)
                     _%entries14399%_))))))
    (define gerbil-ascent/table/index-sharing#fill-column-frame!
      (lambda (_%row14384%_ _%writes14385%_ _%frame14386%_)
        (if (null? _%writes14385%_)
            '#!void
            (let* ((_%instruction14388%_ (car _%writes14385%_))
                   (_%selected14390%_
                    (list-tail _%row14384%_ (car _%instruction14388%_))))
              (vector-set!
               _%frame14386%_
               (cdr _%instruction14388%_)
               (car _%selected14390%_))
              (gerbil-ascent/table/index-sharing#fill-column-frame!
               (cdr _%selected14390%_)
               (cdr _%writes14385%_)
               _%frame14386%_)))))
    (define gerbil-ascent/table/index-sharing#compile-key-projection
      (lambda (_%logical14361%_ _%physical14362%_)
        (let ((_%width14364%_ (length _%logical14361%_)))
          (letrec ((_%position-of14366%_
                    (lambda (_%column14377%_)
                      (let _%seek14379%_ ((_%remaining14381%_ _%logical14361%_)
                                          (_%position14382%_ '0))
                        (if (pair? _%remaining14381%_)
                            (if (= _%column14377%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%remaining14381%_)))
                                _%position14382%_
                                (_%seek14379%_
                                 (let ()
                                   (declare (not safe))
                                   (##cdr _%remaining14381%_))
                                 (+ _%position14382%_ '1)))
                            '#f)))))
            (let _%gather14368%_ ((_%remaining14370%_ _%physical14362%_)
                                  (_%left14371%_ _%width14364%_)
                                  (_%selected14372%_ '())
                                  (_%prefix14373%_ '()))
              (if (zero? _%left14371%_)
                  (let ((__tmp33599 (list->vector (reverse! _%prefix14373%_)))
                        (__tmp33598
                         (gerbil-ascent/table/index-sharing#column-writes
                          (reverse! _%selected14372%_)))
                        (__tmp33597
                         (let ()
                           (declare (not safe))
                           (##make-vector _%width14364%_ '#f))))
                    (declare (not safe))
                    (##structure
                     gerbil-ascent/table/index-sharing#key-projection::t
                     __tmp33599
                     __tmp33598
                     __tmp33597))
                  (let ((_%position14375%_
                         (if (pair? _%remaining14370%_)
                             (_%position-of14366%_
                              (let ()
                                (declare (not safe))
                                (##car _%remaining14370%_)))
                             '#f)))
                    (if _%position14375%_
                        '#!void
                        (let ()
                          (declare (not safe))
                          (error '"logical index is not a physical prefix"
                                 _%logical14361%_
                                 _%physical14362%_)))
                    (_%gather14368%_
                     (cdr _%remaining14370%_)
                     (- _%left14371%_ '1)
                     (cons _%position14375%_ _%selected14372%_)
                     (cons (car _%remaining14370%_) _%prefix14373%_)))))))))
    (define gerbil-ascent/table/index-sharing#same-physical-prefix?
      (lambda (_%physical14350%_ _%snapshot14351%_)
        (let _%compare14353%_ ((_%remaining14355%_ _%physical14350%_)
                               (_%slot14356%_ '0))
          (let ((_%$e14358%_
                 (= _%slot14356%_ (vector-length _%snapshot14351%_))))
            (if _%$e14358%_
                _%$e14358%_
                (if (pair? _%remaining14355%_)
                    (if (equal? (let ()
                                  (declare (not safe))
                                  (##car _%remaining14355%_))
                                (vector-ref _%snapshot14351%_ _%slot14356%_))
                        (_%compare14353%_
                         (let ()
                           (declare (not safe))
                           (##cdr _%remaining14355%_))
                         (+ _%slot14356%_ '1))
                        '#f)
                    '#f))))))
    (define gerbil-ascent/table/index-sharing#column-sequence=?
      (lambda (_%left14347%_ _%right14348%_)
        (if (null? _%left14347%_)
            (null? _%right14348%_)
            (if (pair? _%right14348%_)
                (if (= (car _%left14347%_)
                       (let () (declare (not safe)) (##car _%right14348%_)))
                    (gerbil-ascent/table/index-sharing#column-sequence=?
                     (cdr _%left14347%_)
                     (let () (declare (not safe)) (##cdr _%right14348%_)))
                    '#f)
                '#f))))
    (define gerbil-ascent/table/index-sharing#project-lookup-key
      (lambda (_%index14329%_ _%logical14330%_ _%physical14331%_ _%key14332%_)
        (let* ((_%plans14334%_
                (##structure-ref
                 _%index14329%_
                 '6
                 gerbil-ascent/table/index-sharing#shared-index::t
                 '#f))
               (_%prior14336%_
                (if _%plans14334%_
                    (let ()
                      (declare (not safe))
                      (hash-get _%plans14334%_ _%logical14330%_))
                    '#f))
               (_%plan14340%_
                (if (and _%prior14336%_
                         (gerbil-ascent/table/index-sharing#same-physical-prefix?
                          _%physical14331%_
                          (##direct-structure-ref
                           _%prior14336%_
                           '1
                           gerbil-ascent/table/index-sharing#key-projection::t
                           '#f)))
                    _%prior14336%_
                    (let ((_%fresh14338%_
                           (gerbil-ascent/table/index-sharing#compile-key-projection
                            _%logical14330%_
                            _%physical14331%_)))
                      (if _%plans14334%_
                          '#!void
                          (begin
                            (set! _%plans14334%_
                                  (let ()
                                    (declare (not safe))
                                    (make-hash-table__%
                                     '#f
                                     absent-value
                                     absent-value
                                     gerbil-ascent/table/index-sharing#column-sequence=?
                                     equal?-hash
                                     absent-value
                                     absent-value
                                     absent-value
                                     absent-value)))
                            (##structure-set!
                             _%index14329%_
                             _%plans14334%_
                             '6
                             gerbil-ascent/table/index-sharing#shared-index::t
                             '#f)))
                      (let ((__tmp33600
                             (let ()
                               (declare (not safe))
                               (##append _%logical14330%_ '()))))
                        (declare (not safe))
                        (hash-put! _%plans14334%_ __tmp33600 _%fresh14338%_))
                      _%fresh14338%_)))
               (_%frame14342%_
                (##direct-structure-ref
                 _%plan14340%_
                 '3
                 gerbil-ascent/table/index-sharing#key-projection::t
                 '#f)))
          (gerbil-ascent/table/index-sharing#fill-column-frame!
           _%key14332%_
           (##direct-structure-ref
            _%plan14340%_
            '2
            gerbil-ascent/table/index-sharing#key-projection::t
            '#f)
           _%frame14342%_)
          (let ((_%owned14345%_ (vector->list _%frame14342%_)))
            (vector-fill! _%frame14342%_ '#f)
            _%owned14345%_))))
    (define gerbil-ascent/table/index-sharing#adapt-lookup-key
      (lambda (_%index14284%_ _%logical14285%_ _%physical14286%_ _%key14287%_)
        (let* ((_%$%logical1428814298%_ _%logical14285%_)
               (_%$%else1429014306%_
                (lambda ()
                  (gerbil-ascent/table/index-sharing#project-lookup-key
                   _%index14284%_
                   _%logical14285%_
                   _%physical14286%_
                   _%key14287%_)))
               (_%$%K1429214312%_
                (lambda (_%right14309%_ _%left14310%_)
                  (if (and (pair? _%physical14286%_)
                           (pair? (let ()
                                    (declare (not safe))
                                    (##cdr _%physical14286%_)))
                           (= _%left14310%_ (cadr _%physical14286%_))
                           (= _%right14309%_
                              (let ()
                                (declare (not safe))
                                (##car _%physical14286%_))))
                      '#!void
                      (let ()
                        (declare (not safe))
                        (error '"logical index is not a physical prefix"
                               _%logical14285%_
                               _%physical14286%_)))
                  (list (cadr _%key14287%_) (car _%key14287%_)))))
          (if (pair? _%$%logical1428814298%_)
              (let ((_%$%hd1429314315%_
                     (let ()
                       (declare (not safe))
                       (##car _%$%logical1428814298%_)))
                    (_%$%tl1429414317%_
                     (let ()
                       (declare (not safe))
                       (##cdr _%$%logical1428814298%_))))
                (let ((_%left14320%_ _%$%hd1429314315%_))
                  (if (pair? _%$%tl1429414317%_)
                      (let ((_%$%hd1429514322%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%tl1429414317%_)))
                            (_%$%tl1429614324%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%tl1429414317%_))))
                        (let ((_%right14327%_ _%$%hd1429514322%_))
                          (if (null? _%$%tl1429614324%_)
                              (_%$%K1429214312%_ _%right14327%_ _%left14320%_)
                              (_%$%else1429014306%_))))
                      (_%$%else1429014306%_))))
              (_%$%else1429014306%_)))))
    (define gerbil-ascent/table/index-sharing#gerbil-ascent-shared-index-rows
      (lambda (_%index14243%_ _%columns14244%_ _%key14245%_)
        (let ((_%physical14247%_
               (##structure-ref
                _%index14243%_
                '1
                gerbil-ascent/table/index-sharing#shared-index::t
                '#f)))
          (if (= (length _%columns14244%_) (length _%key14245%_))
              '#!void
              (let ()
                (declare (not safe))
                (error '"shared index key arity mismatch")))
          (letrec ((_%already-ordered?14249%_
                    (lambda (_%logical14278%_ _%remaining14279%_)
                      (let ((_%$e14281%_ (null? _%logical14278%_)))
                        (if _%$e14281%_
                            _%$e14281%_
                            (if (pair? _%remaining14279%_)
                                (if (= (car _%logical14278%_)
                                       (let ()
                                         (declare (not safe))
                                         (##car _%remaining14279%_)))
                                    (_%already-ordered?14249%_
                                     (cdr _%logical14278%_)
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%remaining14279%_)))
                                    '#f)
                                '#f)))))
                   (_%collect14250%_
                    (lambda (_%node14270%_ _%remaining14271%_ _%tail14272%_)
                      (let ((__tmp33601
                             (lambda (_%_14274%_
                                      _%child14275%_
                                      _%records14276%_)
                               (if (null? (cdr _%remaining14271%_))
                                   (append _%child14275%_ _%records14276%_)
                                   (_%collect14250%_
                                    _%child14275%_
                                    (cdr _%remaining14271%_)
                                    _%records14276%_)))))
                        (declare (not safe))
                        (hash-fold __tmp33601 _%tail14272%_ _%node14270%_)))))
            (let* ((_%physical-key14252%_
                    (if (_%already-ordered?14249%_
                         _%columns14244%_
                         _%physical14247%_)
                        _%key14245%_
                        (gerbil-ascent/table/index-sharing#adapt-lookup-key
                         _%index14243%_
                         _%columns14244%_
                         _%physical14247%_
                         _%key14245%_)))
                   (_%cached14254%_
                    (let ((__tmp33602
                           (##structure-ref
                            _%index14243%_
                            '4
                            gerbil-ascent/table/index-sharing#shared-index::t
                            '#f)))
                      (declare (not safe))
                      (hash-get __tmp33602 _%physical-key14252%_))))
              (if _%cached14254%_
                  (cdr _%cached14254%_)
                  (let ((_%rows14268%_
                         (let _%lookup14257%_ ((_%node14259%_
                                                (##structure-ref
                                                 _%index14243%_
                                                 '2
                                                 gerbil-ascent/table/index-sharing#shared-index::t
                                                 '#f))
                                               (_%remaining14260%_
                                                _%physical14247%_)
                                               (_%key14261%_
                                                _%physical-key14252%_))
                           (if (null? _%key14261%_)
                               (let ((__tmp33603
                                      (list-sort
                                       (lambda (_%a14263%_ _%b14264%_)
                                         (> (car _%a14263%_) (car _%b14264%_)))
                                       (_%collect14250%_
                                        _%node14259%_
                                        _%remaining14260%_
                                        '()))))
                                 (declare (not safe))
                                 (##map cdr __tmp33603))
                               (let ((_%child14266%_
                                      (let ((__tmp33604 (car _%key14261%_)))
                                        (declare (not safe))
                                        (hash-get _%node14259%_ __tmp33604))))
                                 (if _%child14266%_
                                     (if (null? (cdr _%remaining14260%_))
                                         (map cdr _%child14266%_)
                                         (_%lookup14257%_
                                          _%child14266%_
                                          (cdr _%remaining14260%_)
                                          (cdr _%key14261%_)))
                                     '()))))))
                    (let ((__tmp33607
                           (##structure-ref
                            _%index14243%_
                            '4
                            gerbil-ascent/table/index-sharing#shared-index::t
                            '#f))
                          (__tmp33606
                           (let ()
                             (declare (not safe))
                             (##append _%physical-key14252%_ '())))
                          (__tmp33605 (cons '#t _%rows14268%_)))
                      (declare (not safe))
                      (hash-put! __tmp33607 __tmp33606 __tmp33605))
                    _%rows14268%_)))))))))
