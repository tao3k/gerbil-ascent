(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/source-log::timestamp 1791687856)
  (begin
    (define gerbil-ascent/program/source-log#gerbil-ascent-source-log-rows
      (lambda (_%base11905%_ _%additions11906%_)
        (if (null? _%additions11906%_)
            _%base11905%_
            (let ((__tmp33528 (reverse _%additions11906%_)))
              (declare (not safe))
              (##append _%base11905%_ __tmp33528)))))
    (define gerbil-ascent/program/source-log#gerbil-ascent-source-log-equal?
      (lambda (_%base11896%_ _%additions11897%_ _%rows11898%_)
        (if (null? _%additions11897%_)
            (equal? _%base11896%_ _%rows11898%_)
            (let ((_%tail11903%_
                   (let ((__tmp33529
                          (lambda (_%row11900%_ _%remaining11901%_)
                            (if (pair? _%remaining11901%_)
                                (if (equal? _%row11900%_
                                            (let ()
                                              (declare (not safe))
                                              (##car _%remaining11901%_)))
                                    (let ()
                                      (declare (not safe))
                                      (##cdr _%remaining11901%_))
                                    '#f)
                                '#f))))
                     (declare (not safe))
                     (foldl__0 __tmp33529 _%rows11898%_ _%base11896%_))))
              (if _%tail11903%_
                  (equal? (reverse _%additions11897%_) _%tail11903%_)
                  '#f)))))))
