(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/core/rule-semantics[1]#_g35069_|
    (##structure
     gx#syntax-quote::t
     'rule-read::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35071_|
    (##structure
     gx#syntax-quote::t
     'make-rule-read
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35073_|
    (##structure
     gx#syntax-quote::t
     'rule-read?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35075_|
    (##structure
     gx#syntax-quote::t
     'rule-read-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35076_|
    (##structure
     gx#syntax-quote::t
     'rule-read-source
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35078_|
    (##structure
     gx#syntax-quote::t
     'rule-read-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35079_|
    (##structure
     gx#syntax-quote::t
     'rule-read-source-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35081_|
    (##structure
     gx#syntax-quote::t
     '&rule-read-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35082_|
    (##structure
     gx#syntax-quote::t
     '&rule-read-source
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35084_|
    (##structure
     gx#syntax-quote::t
     '&rule-read-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35085_|
    (##structure
     gx#syntax-quote::t
     '&rule-read-source-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/core/rule-semantics[:0:]#rule-read|
      (let ((__obj34842
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34842
           'gerbil-ascent/core/rule-semantics#rule-read::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34842 'rule-read '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34842 '(kind source) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34842 '(kind source) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34842 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34842 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34842 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34842 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34842 '#f '13 '#f '#f))
        (let ((__tmp35068 |gerbil-ascent/core/rule-semantics[1]#_g35069_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34842 __tmp35068 '4 '#f '#f))
        (let ((__tmp35070 |gerbil-ascent/core/rule-semantics[1]#_g35071_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34842 __tmp35070 '14 '#f '#f))
        (let ((__tmp35072 |gerbil-ascent/core/rule-semantics[1]#_g35073_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34842 __tmp35072 '15 '#f '#f))
        (let ((__tmp35074
               (cons (cons 'kind
                           |gerbil-ascent/core/rule-semantics[1]#_g35075_|)
                     (cons (cons 'source
                                 |gerbil-ascent/core/rule-semantics[1]#_g35076_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34842 __tmp35074 '16 '#f '#f))
        (let ((__tmp35077
               (cons (cons 'kind
                           |gerbil-ascent/core/rule-semantics[1]#_g35078_|)
                     (cons (cons 'source
                                 |gerbil-ascent/core/rule-semantics[1]#_g35079_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34842 __tmp35077 '17 '#f '#f))
        (let ((__tmp35080
               (cons (cons 'kind
                           |gerbil-ascent/core/rule-semantics[1]#_g35081_|)
                     (cons (cons 'source
                                 |gerbil-ascent/core/rule-semantics[1]#_g35082_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34842 __tmp35080 '18 '#f '#f))
        (let ((__tmp35083
               (cons (cons 'kind
                           |gerbil-ascent/core/rule-semantics[1]#_g35084_|)
                     (cons (cons 'source
                                 |gerbil-ascent/core/rule-semantics[1]#_g35085_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34842 __tmp35083 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34842 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34842 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34842 '() '21 '#f '#f))
        __obj34842))
    (define |gerbil-ascent/core/rule-semantics[:0:]#for-rule-reads|
      (lambda (_%$stx7389%_)
        (let* ((_%$%g73937428%_
                (lambda (_%$%g73947424%_)
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%$%g73947424%_))))
               (_%$%g73927552%_
                (lambda (_%$%g73947432%_)
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-pair? _%$%g73947432%_))
                      (let ((_%$%e73997435%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-e _%$%g73947432%_))))
                        (let ((_%$%hd74007439%_
                               (let ()
                                 (declare (not safe))
                                 (##car _%$%e73997435%_)))
                              (_%$%tl74017442%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%$%e73997435%_))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair? _%$%tl74017442%_))
                              (let ((_%$%e74027445%_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-e _%$%tl74017442%_))))
                                (let ((_%$%hd74037449%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%$%e74027445%_)))
                                      (_%$%tl74047452%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%e74027445%_))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%tl74047452%_))
                                      (let ((_%$%e74057455%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%tl74047452%_))))
                                        (let ((_%$%hd74067459%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e74057455%_)))
                                              (_%$%tl74077462%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e74057455%_))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair?
                                                 _%$%hd74067459%_))
                                              (let ((_%$%e74087465%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-e
                                                        _%$%hd74067459%_))))
                                                (let ((_%$%hd74097469%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##car _%$%e74087465%_)))
                                                      (_%$%tl74107472%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##cdr _%$%e74087465%_))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair?
                                                         _%$%tl74107472%_))
                                                      (let ((_%$%e74117475%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-e _%$%tl74107472%_))))
                (let ((_%$%hd74127479%_
                       (let () (declare (not safe)) (##car _%$%e74117475%_)))
                      (_%$%tl74137482%_
                       (let () (declare (not safe)) (##cdr _%$%e74117475%_))))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-null? _%$%tl74137482%_))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl74077462%_))
                          (let ((_g35086_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice
                                    _%$%tl74077462%_
                                    '0))))
                            (begin
                              (let ((_g35087_
                                     (let ()
                                       (declare (not safe))
                                       (if (##values? _g35086_)
                                           (##values-length _g35086_)
                                           1))))
                                (if (not (let ()
                                           (declare (not safe))
                                           (##fx= _g35087_ 2)))
                                    (error "Context expects 2 values"
                                           _g35087_)))
                              (let ((_%$%target74147485%_
                                     (let ()
                                       (declare (not safe))
                                       (##values-ref _g35086_ 0)))
                                    (_%$%tl74167488%_
                                     (let ()
                                       (declare (not safe))
                                       (##values-ref _g35086_ 1))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl74167488%_))
                                    (letrec ((_%$%loop74177491%_
                                              (lambda (_%$%hd74157495%_
                                                       _%$%body74217498%_)
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair?
                                                       _%$%hd74157495%_))
                                                    (let ((_%$%e74187500%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-e
                                                              _%$%hd74157495%_))))
                                                      (let ((_%$%lp-hd74197504%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##car _%$%e74187500%_)))
                    (_%$%lp-tl74207507%_
                     (let () (declare (not safe)) (##cdr _%$%e74187500%_))))
                (_%$%loop74177491%_
                 _%$%lp-tl74207507%_
                 (cons _%$%lp-hd74197504%_ _%$%body74217498%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (let ((_%$%body74227510%_
                                                           (reverse _%$%body74217498%_)))
                                                      (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'for-each))
                                                            (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                  (declare (not safe))
                                  (gx#datum->syntax__0 '#f 'lambda))
                                (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'clause))
                                            '())
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'let))
                                                  (cons (cons _%$%hd74097469%_
                                                              (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                    (declare (not safe))
                                    (gx#datum->syntax__0 '#f 'vector-ref))
                                  (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'clause))
                                        (cons '0 '())))
                            '()))
                (cons (cons (let ()
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'when))
                            (cons (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'memq))
                                        (cons _%$%hd74097469%_
                                              (cons (cons (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#datum->syntax__0
                                                             '#f
                                                             'quote))
                                                          (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                (declare (not safe))
                                (gx#datum->syntax__0 '#f 'atom))
                              (cons (let ()
                                      (declare (not safe))
                                      (gx#datum->syntax__0 '#f 'negation))
                                    (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0
                                             '#f
                                             'aggregate))
                                          '())))
                        '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '())))
                                  (cons (cons (let ()
                                                (declare (not safe))
                                                (gx#datum->syntax__0 '#f 'let))
                                              (cons (cons _%$%hd74127479%_
                                                          (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                (declare (not safe))
                                (gx#datum->syntax__0 '#f 'vector-ref))
                              (cons (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0
                                             '#f
                                             'vector-ref))
                                          (cons (let ()
                                                  (declare (not safe))
                                                  (gx#datum->syntax__0
                                                   '#f
                                                   'clause))
                                                (cons '1 '())))
                                    (cons '0 '())))
                        '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (let ((__tmp35088
                                                           (lambda (_%$%g75437546%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%$%g75447549%_)
                     (cons _%$%g75437546%_ _%$%g75447549%_))))
              (declare (not safe))
              (foldr__0 __tmp35088 '() _%$%body74227510%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        '())))
                      '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            '())))
                          (cons _%$%hd74037449%_ '()))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                      (_%$%loop74177491%_
                                       _%$%target74147485%_
                                       '()))
                                    (_%$%g73937428%_ _%$%g73947432%_)))))
                          (_%$%g73937428%_ _%$%g73947432%_))
                      (_%$%g73937428%_ _%$%g73947432%_))))
              (_%$%g73937428%_ _%$%g73947432%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%$%g73937428%_
                                               _%$%g73947432%_))))
                                      (_%$%g73937428%_ _%$%g73947432%_))))
                              (_%$%g73937428%_ _%$%g73947432%_))))
                      (_%$%g73937428%_ _%$%g73947432%_)))))
          (_%$%g73927552%_ _%$stx7389%_))))
    (define |gerbil-ascent/core/rule-semantics[:0:]#with-rule-reads|
      (lambda (_%$stx7557%_)
        (let* ((_%$%g75617596%_
                (lambda (_%$%g75627592%_)
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%$%g75627592%_))))
               (_%$%g75607719%_
                (lambda (_%$%g75627600%_)
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-pair? _%$%g75627600%_))
                      (let ((_%$%e75677603%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-e _%$%g75627600%_))))
                        (let ((_%$%hd75687607%_
                               (let ()
                                 (declare (not safe))
                                 (##car _%$%e75677603%_)))
                              (_%$%tl75697610%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%$%e75677603%_))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair? _%$%tl75697610%_))
                              (let ((_%$%e75707613%_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-e _%$%tl75697610%_))))
                                (let ((_%$%hd75717617%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%$%e75707613%_)))
                                      (_%$%tl75727620%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%e75707613%_))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%tl75727620%_))
                                      (let ((_%$%e75737623%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%tl75727620%_))))
                                        (let ((_%$%hd75747627%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e75737623%_)))
                                              (_%$%tl75757630%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e75737623%_))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair?
                                                 _%$%hd75747627%_))
                                              (let ((_%$%e75767633%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-e
                                                        _%$%hd75747627%_))))
                                                (let ((_%$%hd75777637%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##car _%$%e75767633%_)))
                                                      (_%$%tl75787640%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##cdr _%$%e75767633%_))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair?
                                                         _%$%tl75787640%_))
                                                      (let ((_%$%e75797643%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-e _%$%tl75787640%_))))
                (let ((_%$%hd75807647%_
                       (let () (declare (not safe)) (##car _%$%e75797643%_)))
                      (_%$%tl75817650%_
                       (let () (declare (not safe)) (##cdr _%$%e75797643%_))))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-null? _%$%tl75817650%_))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl75757630%_))
                          (let ((_g35089_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice
                                    _%$%tl75757630%_
                                    '0))))
                            (begin
                              (let ((_g35090_
                                     (let ()
                                       (declare (not safe))
                                       (if (##values? _g35089_)
                                           (##values-length _g35089_)
                                           1))))
                                (if (not (let ()
                                           (declare (not safe))
                                           (##fx= _g35090_ 2)))
                                    (error "Context expects 2 values"
                                           _g35090_)))
                              (let ((_%$%target75827653%_
                                     (let ()
                                       (declare (not safe))
                                       (##values-ref _g35089_ 0)))
                                    (_%$%tl75847656%_
                                     (let ()
                                       (declare (not safe))
                                       (##values-ref _g35089_ 1))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl75847656%_))
                                    (letrec ((_%$%loop75857659%_
                                              (lambda (_%$%hd75837663%_
                                                       _%$%body75897666%_)
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair?
                                                       _%$%hd75837663%_))
                                                    (let ((_%$%e75867668%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-e
                                                              _%$%hd75837663%_))))
                                                      (let ((_%$%lp-hd75877672%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##car _%$%e75867668%_)))
                    (_%$%lp-tl75887675%_
                     (let () (declare (not safe)) (##cdr _%$%e75867668%_))))
                (_%$%loop75857659%_
                 _%$%lp-tl75887675%_
                 (cons _%$%lp-hd75877672%_ _%$%body75897666%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (let ((_%$%body75907678%_
                                                           (reverse _%$%body75897666%_)))
                                                      (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'let))
                                                            (cons (cons (cons _%$%hd75777637%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'vector-ref))
                                                  (cons _%$%hd75717617%_
                                                        (cons '0 '())))
                                            '()))
                                (cons (cons _%$%hd75807647%_
                                            (cons (cons (let ()
                                                          (declare (not safe))
                                                          (gx#datum->syntax__0
                                                           '#f
                                                           'prepare-rule-reads))
                                                        (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'vector-ref))
                            (cons _%$%hd75717617%_ (cons '1 '())))
                      '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  '()))
                                      '()))
                          (let ((__tmp35091
                                 (lambda (_%$%g77107713%_ _%$%g77117716%_)
                                   (cons _%$%g77107713%_ _%$%g77117716%_))))
                            (declare (not safe))
                            (foldr__0
                             __tmp35091
                             '()
                             _%$%body75907678%_)))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                      (_%$%loop75857659%_
                                       _%$%target75827653%_
                                       '()))
                                    (_%$%g75617596%_ _%$%g75627600%_)))))
                          (_%$%g75617596%_ _%$%g75627600%_))
                      (_%$%g75617596%_ _%$%g75627600%_))))
              (_%$%g75617596%_ _%$%g75627600%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%$%g75617596%_
                                               _%$%g75627600%_))))
                                      (_%$%g75617596%_ _%$%g75627600%_))))
                              (_%$%g75617596%_ _%$%g75627600%_))))
                      (_%$%g75617596%_ _%$%g75627600%_)))))
          (_%$%g75607719%_ _%$stx7557%_))))))
