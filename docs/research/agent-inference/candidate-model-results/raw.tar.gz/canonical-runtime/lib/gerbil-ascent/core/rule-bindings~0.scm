(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/core/rule-bindings::timestamp 1791689683)
  (begin
    (define gerbil-ascent/core/rule-bindings#binding-value
      (lambda (_%name7023%_ _%environment7024%_ _%diagnostic7025%_)
        (let ((_%binding7027%_ (assq _%name7023%_ _%environment7024%_)))
          (if _%binding7027%_
              '#!void
              (let ()
                (declare (not safe))
                (error _%diagnostic7025%_ _%name7023%_)))
          (cdr _%binding7027%_))))
    (define gerbil-ascent/core/rule-bindings#gerbil-ascent-binding-values
      (lambda (_%names7017%_ _%environment7018%_ _%diagnostic7019%_)
        (map (lambda (_%name7021%_)
               (gerbil-ascent/core/rule-bindings#binding-value
                _%name7021%_
                _%environment7018%_
                _%diagnostic7019%_))
             _%names7017%_)))
    (define gerbil-ascent/core/rule-bindings#gerbil-ascent-call-with-bindings
      (lambda (_%procedure6786%_
               _%names6787%_
               _%environment6788%_
               _%diagnostic6789%_)
        (let* ((_%$%names67906824%_ _%names6787%_)
               (_%$%else67966834%_
                (lambda ()
                  (apply _%procedure6786%_
                         (map (lambda (_%name6832%_)
                                (gerbil-ascent/core/rule-bindings#binding-value
                                 _%name6832%_
                                 _%environment6788%_
                                 _%diagnostic6789%_))
                              _%names6787%_)))))
          (let ((_%$%K68227014%_ (lambda () (_%procedure6786%_)))
                (_%$%K68197000%_
                 (lambda (_%one6992%_)
                   (let* ((_%name6994%_ _%one6992%_)
                          (_%next6996%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6994%_
                            _%environment6788%_
                            _%diagnostic6789%_)))
                     (_%procedure6786%_ _%next6996%_))))
                (_%$%K68146971%_
                 (lambda (_%two6956%_ _%one6957%_)
                   (let* ((_%name6959%_ _%one6957%_)
                          (_%next6961%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6959%_
                            _%environment6788%_
                            _%diagnostic6789%_))
                          (_%name6965%_ _%two6956%_)
                          (_%next6967%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6965%_
                            _%environment6788%_
                            _%diagnostic6789%_)))
                     (_%procedure6786%_ _%next6961%_ _%next6967%_))))
                (_%$%K68076928%_
                 (lambda (_%three6906%_ _%two6907%_ _%one6908%_)
                   (let* ((_%name6910%_ _%one6908%_)
                          (_%next6912%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6910%_
                            _%environment6788%_
                            _%diagnostic6789%_))
                          (_%name6916%_ _%two6907%_)
                          (_%next6918%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6916%_
                            _%environment6788%_
                            _%diagnostic6789%_))
                          (_%name6922%_ _%three6906%_)
                          (_%next6924%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6922%_
                            _%environment6788%_
                            _%diagnostic6789%_)))
                     (_%procedure6786%_
                      _%next6912%_
                      _%next6918%_
                      _%next6924%_))))
                (_%$%K67986871%_
                 (lambda (_%four6838%_ _%three6840%_ _%two6842%_ _%one6844%_)
                   (let* ((_%name6847%_ _%one6844%_)
                          (_%next6849%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6847%_
                            _%environment6788%_
                            _%diagnostic6789%_))
                          (_%name6853%_ _%two6842%_)
                          (_%next6855%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6853%_
                            _%environment6788%_
                            _%diagnostic6789%_))
                          (_%name6859%_ _%three6840%_)
                          (_%next6861%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6859%_
                            _%environment6788%_
                            _%diagnostic6789%_))
                          (_%name6865%_ _%four6838%_)
                          (_%next6867%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6865%_
                            _%environment6788%_
                            _%diagnostic6789%_)))
                     (_%procedure6786%_
                      _%next6849%_
                      _%next6855%_
                      _%next6861%_
                      _%next6867%_)))))
            (let ((_%$%try-match67927010%_
                   (lambda ()
                     (if (pair? _%$%names67906824%_)
                         (let ((_%$%tl68217005%_
                                (let ()
                                  (declare (not safe))
                                  (##cdr _%$%names67906824%_)))
                               (_%$%hd68207003%_
                                (let ()
                                  (declare (not safe))
                                  (##car _%$%names67906824%_))))
                           (if (null? _%$%tl68217005%_)
                               (let ((_%one7008%_ _%$%hd68207003%_))
                                 (_%$%K68197000%_ _%one7008%_))
                               (if (pair? _%$%tl68217005%_)
                                   (let ((_%$%tl68186983%_
                                          (let ()
                                            (declare (not safe))
                                            (##cdr _%$%tl68217005%_)))
                                         (_%$%hd68176981%_
                                          (let ()
                                            (declare (not safe))
                                            (##car _%$%tl68217005%_))))
                                     (if (null? _%$%tl68186983%_)
                                         (let ((_%one6979%_ _%$%hd68207003%_)
                                               (_%two6986%_ _%$%hd68176981%_))
                                           (_%$%K68146971%_
                                            _%two6986%_
                                            _%one6979%_))
                                         (if (pair? _%$%tl68186983%_)
                                             (let ((_%$%tl68136947%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##cdr _%$%tl68186983%_)))
                                                   (_%$%hd68126945%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##car _%$%tl68186983%_))))
                                               (if (null? _%$%tl68136947%_)
                                                   (let ((_%one6936%_
                                                          _%$%hd68207003%_)
                                                         (_%two6943%_
                                                          _%$%hd68176981%_)
                                                         (_%three6950%_
                                                          _%$%hd68126945%_))
                                                     (_%$%K68076928%_
                                                      _%three6950%_
                                                      _%two6943%_
                                                      _%one6936%_))
                                                   (if (pair? _%$%tl68136947%_)
                                                       (let ((_%$%tl68066897%_
                                                              (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (##cdr _%$%tl68136947%_)))
                     (_%$%hd68056895%_
                      (let () (declare (not safe)) (##car _%$%tl68136947%_))))
                 (if (null? _%$%tl68066897%_)
                     (let ((_%one6879%_ _%$%hd68207003%_)
                           (_%two6886%_ _%$%hd68176981%_)
                           (_%three6893%_ _%$%hd68126945%_)
                           (_%four6900%_ _%$%hd68056895%_))
                       (_%$%K67986871%_
                        _%four6900%_
                        _%three6893%_
                        _%two6886%_
                        _%one6879%_))
                     (_%$%else67966834%_)))
               (_%$%else67966834%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%$%else67966834%_))))
                                   (_%$%else67966834%_))))
                         (_%$%else67966834%_)))))
              (if (null? _%$%names67906824%_)
                  (let () (declare (not safe)) (_%procedure6786%_))
                  (_%$%try-match67927010%_)))))))
    (define gerbil-ascent/core/rule-bindings#gerbil-ascent-expression-value
      (lambda (_%payload6783%_ _%environment6784%_)
        (gerbil-ascent/core/rule-bindings#gerbil-ascent-call-with-bindings
         (vector-ref _%payload6783%_ '1)
         (vector-ref _%payload6783%_ '0)
         _%environment6784%_
         '"unbound ASCENT expression variable")))
    (define gerbil-ascent/core/rule-bindings#gerbil-ascent-extend-pattern
      (lambda (_%outputs6716%_
               _%matched6717%_
               _%environment6718%_
               _%diagnostic6719%_)
        (let _%extend6721%_ ((_%names6723%_ _%outputs6716%_)
                             (_%values6724%_ _%matched6717%_))
          (let ((_%$%names67256738%_ _%names6723%_)
                (_%$%values67266739%_ _%values6724%_))
            (let ((_%$%else67296746%_
                   (lambda ()
                     (let ()
                       (declare (not safe))
                       (error _%diagnostic6719%_
                              _%matched6717%_
                              _%outputs6716%_)))))
              (let ((_%$%K67366780%_ (lambda () _%environment6718%_))
                    (_%$%K67316755%_
                     (lambda (_%remaining6750%_
                              _%name6751%_
                              _%rest6752%_
                              _%value6753%_)
                       (cons (cons _%name6751%_ _%value6753%_)
                             (_%extend6721%_
                              _%remaining6750%_
                              _%rest6752%_)))))
                (let ((_%$%try-match67286776%_
                       (lambda ()
                         (if (pair? _%$%names67256738%_)
                             (let ((_%$%tl67356760%_
                                    (let ()
                                      (declare (not safe))
                                      (##cdr _%$%names67256738%_)))
                                   (_%$%hd67346758%_
                                    (let ()
                                      (declare (not safe))
                                      (##car _%$%names67256738%_))))
                               (if (pair? _%$%values67266739%_)
                                   (let ((_%$%tl67336769%_
                                          (let ()
                                            (declare (not safe))
                                            (##cdr _%$%values67266739%_)))
                                         (_%$%hd67326767%_
                                          (let ()
                                            (declare (not safe))
                                            (##car _%$%values67266739%_))))
                                     (let ((_%name6763%_ _%$%hd67346758%_)
                                           (_%remaining6765%_ _%$%tl67356760%_)
                                           (_%value6772%_ _%$%hd67326767%_)
                                           (_%rest6774%_ _%$%tl67336769%_))
                                       (_%$%K67316755%_
                                        _%remaining6765%_
                                        _%name6763%_
                                        _%rest6774%_
                                        _%value6772%_)))
                                   (_%$%else67296746%_)))
                             (_%$%else67296746%_)))))
                  (if (null? _%$%names67256738%_)
                      (if (null? _%$%values67266739%_)
                          (_%$%K67366780%_)
                          (_%$%else67296746%_))
                      (_%$%try-match67286776%_)))))))))
    (define gerbil-ascent/core/rule-bindings#gerbil-ascent-bind-row
      (lambda (_%terms6462%_ _%row6463%_ _%environment6464%_)
        (let _%loop6466%_ ((_%patterns6468%_ _%terms6462%_)
                           (_%values6469%_ _%row6463%_)
                           (_%bindings6470%_ _%environment6464%_))
          (let* ((_%$%patterns64716480%_ _%patterns6468%_)
                 (_%$%E64746484%_
                  (lambda ()
                    (let ()
                      (declare (not safe))
                      (error '"No clause matching"
                             _%$%patterns64716480%_
                             '([])
                             '([term . _])))
                    '#!void)))
            (let ((_%$%K64786713%_ (lambda () _%bindings6470%_))
                  (_%$%K64756701%_
                   (lambda (_%term6488%_)
                     (letrec* ((_%value6490%_ (car _%values6469%_)))
                       (let* ((_%$%term65736600%_ _%term6488%_)
                              (_%$%E65806604%_
                               (lambda ()
                                 (let ()
                                   (declare (not safe))
                                   (error '"No clause matching"
                                          _%$%term65736600%_
                                          '(['wildcard . _])
                                          '(['fresh-variable . name])
                                          '(['pattern . payload])
                                          '(['literal . expected])
                                          '(['expression . payload])
                                          '([_ . name])))
                                 '#!void)))
                         (let ((_%$%K65966695%_
                                (lambda ()
                                  (_%loop6466%_
                                   (cdr _%patterns6468%_)
                                   (cdr _%values6469%_)
                                   _%bindings6470%_)))
                               (_%$%K65936681%_
                                (lambda (_%name6679%_)
                                  (_%loop6466%_
                                   (cdr _%patterns6468%_)
                                   (cdr _%values6469%_)
                                   (cons (cons _%name6679%_ _%value6490%_)
                                         _%bindings6470%_))))
                               (_%$%K65906665%_
                                (lambda (_%payload6660%_)
                                  (letrec* ((_%matched6662%_
                                             ((vector-ref _%payload6660%_ '1)
                                              _%value6490%_))
                                            (_%outputs6663%_
                                             (vector-ref _%payload6660%_ '0)))
                                    (if _%matched6662%_
                                        (_%loop6466%_
                                         (cdr _%patterns6468%_)
                                         (cdr _%values6469%_)
                                         (gerbil-ascent/core/rule-bindings#gerbil-ascent-extend-pattern
                                          _%outputs6663%_
                                          _%matched6662%_
                                          _%bindings6470%_
                                          '"ASCENT pattern returned invalid bindings"))
                                        '#f))))
                               (_%$%K65876646%_
                                (lambda (_%expected6644%_)
                                  (if (equal? _%expected6644%_ _%value6490%_)
                                      (_%loop6466%_
                                       (cdr _%patterns6468%_)
                                       (cdr _%values6469%_)
                                       _%bindings6470%_)
                                      '#f)))
                               (_%$%K65846630%_
                                (lambda (_%payload6628%_)
                                  (if (equal? (gerbil-ascent/core/rule-bindings#gerbil-ascent-expression-value
                                               _%payload6628%_
                                               _%bindings6470%_)
                                              _%value6490%_)
                                      (_%loop6466%_
                                       (cdr _%patterns6468%_)
                                       (cdr _%values6469%_)
                                       _%bindings6470%_)
                                      '#f)))
                               (_%$%K65816616%_
                                (lambda (_%name6608%_)
                                  (let ((_%$e6610%_
                                         (assq _%name6608%_ _%bindings6470%_)))
                                    (if _%$e6610%_
                                        (if (equal? (cdr _%$e6610%_)
                                                    _%value6490%_)
                                            (_%loop6466%_
                                             (cdr _%patterns6468%_)
                                             (cdr _%values6469%_)
                                             _%bindings6470%_)
                                            '#f)
                                        (_%loop6466%_
                                         (cdr _%patterns6468%_)
                                         (cdr _%values6469%_)
                                         (cons (cons _%name6608%_
                                                     _%value6490%_)
                                               _%bindings6470%_)))))))
                           (if (pair? _%$%term65736600%_)
                               (let ((_%$%hd65976698%_
                                      (let ()
                                        (declare (not safe))
                                        (##car _%$%term65736600%_))))
                                 (if (let ()
                                       (declare (not safe))
                                       (##eq? _%$%hd65976698%_ 'wildcard))
                                     (_%$%K65966695%_)
                                     (let ((_%$%tl65956686%_
                                            (let ()
                                              (declare (not safe))
                                              (##cdr _%$%term65736600%_))))
                                       (if (let ()
                                             (declare (not safe))
                                             (##eq? _%$%hd65976698%_
                                                    'fresh-variable))
                                           (let ((_%name6689%_
                                                  _%$%tl65956686%_))
                                             (_%$%K65936681%_ _%name6689%_))
                                           (if (let ()
                                                 (declare (not safe))
                                                 (##eq? _%$%hd65976698%_
                                                        'pattern))
                                               (let ((_%payload6673%_
                                                      _%$%tl65956686%_))
                                                 (_%$%K65906665%_
                                                  _%payload6673%_))
                                               (if (let ()
                                                     (declare (not safe))
                                                     (##eq? _%$%hd65976698%_
                                                            'literal))
                                                   (let ((_%expected6654%_
                                                          _%$%tl65956686%_))
                                                     (_%$%K65876646%_
                                                      _%expected6654%_))
                                                   (if (let ()
                                                         (declare (not safe))
                                                         (##eq? _%$%hd65976698%_
                                                                'expression))
                                                       (let ((_%payload6638%_
                                                              _%$%tl65956686%_))
                                                         (_%$%K65846630%_
                                                          _%payload6638%_))
                                                       (let ((_%name6622%_
                                                              _%$%tl65956686%_))
                                                         (_%$%K65816616%_
                                                          _%name6622%_)))))))))
                               (_%$%E65806604%_))))))))
              (let ((_%$%try-match64736709%_
                     (lambda ()
                       (if (pair? _%$%patterns64716480%_)
                           (let* ((_%$%hd64766704%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%patterns64716480%_)))
                                  (_%term6707%_ _%$%hd64766704%_))
                             (_%$%K64756701%_ _%term6707%_))
                           (_%$%E64746484%_)))))
                (if (null? _%$%patterns64716480%_)
                    (_%$%K64786713%_)
                    (_%$%try-match64736709%_))))))))
    (define gerbil-ascent/core/rule-bindings#gerbil-ascent-head-row
      (lambda (_%terms6362%_ _%environment6363%_)
        (map (lambda (_%$%e63646366%_)
               (let* ((_%$%$%e636463686391%_ _%$%e63646366%_)
                      (_%$%E63746395%_
                       (lambda ()
                         (let ()
                           (declare (not safe))
                           (error '"No clause matching"
                                  _%$%$%e636463686391%_
                                  '(['literal . value])
                                  '(['expression . payload])
                                  '(['pattern . _])
                                  '(['wildcard . _])
                                  '([_ . name])))
                         '#!void)))
                 (let ((_%$%K63876452%_ (lambda (_%value6450%_) _%value6450%_))
                       (_%$%K63846437%_
                        (lambda (_%payload6435%_)
                          (gerbil-ascent/core/rule-bindings#gerbil-ascent-expression-value
                           _%payload6435%_
                           _%environment6363%_)))
                       (_%$%K63816425%_
                        (lambda ()
                          (let ()
                            (declare (not safe))
                            (error '"ASCENT pattern is invalid in a rule head"))))
                       (_%$%K63786414%_
                        (lambda ()
                          (let ()
                            (declare (not safe))
                            (error '"ASCENT wildcard is invalid in a rule head"))))
                       (_%$%K63756401%_
                        (lambda (_%name6399%_)
                          (gerbil-ascent/core/rule-bindings#binding-value
                           _%name6399%_
                           _%environment6363%_
                           '"unbound ASCENT head variable"))))
                   (if (pair? _%$%$%e636463686391%_)
                       (let ((_%$%tl63896457%_
                              (let ()
                                (declare (not safe))
                                (##cdr _%$%$%e636463686391%_)))
                             (_%$%hd63886455%_
                              (let ()
                                (declare (not safe))
                                (##car _%$%$%e636463686391%_))))
                         (if (let ()
                               (declare (not safe))
                               (##eq? _%$%hd63886455%_ 'literal))
                             (let ((_%value6460%_ _%$%tl63896457%_))
                               (_%$%K63876452%_ _%value6460%_))
                             (if (let ()
                                   (declare (not safe))
                                   (##eq? _%$%hd63886455%_ 'expression))
                                 (let ((_%payload6445%_ _%$%tl63896457%_))
                                   (_%$%K63846437%_ _%payload6445%_))
                                 (if (let ()
                                       (declare (not safe))
                                       (##eq? _%$%hd63886455%_ 'pattern))
                                     (_%$%K63816425%_)
                                     (if (let ()
                                           (declare (not safe))
                                           (##eq? _%$%hd63886455%_ 'wildcard))
                                         (_%$%K63786414%_)
                                         (let ((_%name6407%_ _%$%tl63896457%_))
                                           (_%$%K63756401%_ _%name6407%_)))))))
                       (_%$%E63746395%_)))))
             _%terms6362%_)))))
