(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/result::timestamp 1791689672)
  (begin
    (define gerbil-ascent/program/result#owned-publication::t
      (let ((__tmp34406 (list))
            (__tmp34405
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/result#owned-publication::t
         'owned-publication
         __tmp34406
         '(result snapshots sizes position-of)
         __tmp34405
         '#f)))
    (define gerbil-ascent/program/result#owned-publication?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/result#owned-publication::t)))
    (define gerbil-ascent/program/result#make-owned-publication
      (lambda _%$args14063%_
        (apply make-instance
               gerbil-ascent/program/result#owned-publication::t
               _%$args14063%_)))
    (define gerbil-ascent/program/result#owned-publication-result
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/result#owned-publication::t
         'result)))
    (define gerbil-ascent/program/result#owned-publication-snapshots
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/result#owned-publication::t
         'snapshots)))
    (define gerbil-ascent/program/result#owned-publication-sizes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/result#owned-publication::t
         'sizes)))
    (define gerbil-ascent/program/result#owned-publication-position-of
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/result#owned-publication::t
         'position-of)))
    (define gerbil-ascent/program/result#owned-publication-result-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/result#owned-publication::t
         'result)))
    (define gerbil-ascent/program/result#owned-publication-snapshots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/result#owned-publication::t
         'snapshots)))
    (define gerbil-ascent/program/result#owned-publication-sizes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/result#owned-publication::t
         'sizes)))
    (define gerbil-ascent/program/result#owned-publication-position-of-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/result#owned-publication::t
         'position-of)))
    (define gerbil-ascent/program/result#&owned-publication-result
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/result#owned-publication::t
         'result)))
    (define gerbil-ascent/program/result#&owned-publication-snapshots
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/result#owned-publication::t
         'snapshots)))
    (define gerbil-ascent/program/result#&owned-publication-sizes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/result#owned-publication::t
         'sizes)))
    (define gerbil-ascent/program/result#&owned-publication-position-of
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/result#owned-publication::t
         'position-of)))
    (define gerbil-ascent/program/result#&owned-publication-result-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/result#owned-publication::t
         'result)))
    (define gerbil-ascent/program/result#&owned-publication-snapshots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/result#owned-publication::t
         'snapshots)))
    (define gerbil-ascent/program/result#&owned-publication-sizes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/result#owned-publication::t
         'sizes)))
    (define gerbil-ascent/program/result#&owned-publication-position-of-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/result#owned-publication::t
         'position-of)))
    (define gerbil-ascent/program/result#gerbil-ascent-publication-size
      (lambda (_%publication14052%_ _%completed14053%_ _%name14054%_)
        (if (let ()
              (declare (not safe))
              (##structure-direct-instance-of?
               _%publication14052%_
               'gerbil-ascent/program/result#owned-publication::t))
            (let ((_%publication14056%_ _%publication14052%_))
              (if (eq? _%completed14053%_
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%publication14056%_
                          '1
                          '#f
                          '#f)))
                  (vector-ref
                   (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref
                      _%publication14056%_
                      '3
                      '#f
                      '#f))
                   ((let ()
                      (declare (not safe))
                      (##unchecked-structure-ref
                       _%publication14056%_
                       '4
                       '#f
                       '#f))
                    _%name14054%_))
                  '#f))
            '#f)))
    (define gerbil-ascent/program/result#gerbil-ascent-publication-reader
      (lambda (_%publication14040%_ _%completed14041%_)
        (if (let ()
              (declare (not safe))
              (##structure-direct-instance-of?
               _%publication14040%_
               'gerbil-ascent/program/result#owned-publication::t))
            (let ((_%publication14043%_ _%publication14040%_))
              (if (eq? _%completed14041%_
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%publication14043%_
                          '1
                          '#f
                          '#f)))
                  (lambda (_%name14050%_)
                    (gerbil-ascent/program/result#gerbil-ascent-snapshot-rows
                     (vector-ref
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%publication14043%_
                         '2
                         '#f
                         '#f))
                      ((let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%publication14043%_
                          '4
                          '#f
                          '#f))
                       _%name14050%_))))
                  '#f))
            '#f)))
    (define gerbil-ascent/program/result#gerbil-ascent-make-owned-result
      (lambda (_%names14028%_
               _%arity14029%_
               _%snapshots14030%_
               _%sizes14031%_
               _%representations14032%_
               _%observation14033%_
               _%position-of14034%_
               _%complete?14035%_
               _%session?14036%_)
        (let ((_%result14038%_
               (gerbil-ascent/program/result#gerbil-ascent-make-published-result
                _%names14028%_
                _%arity14029%_
                _%snapshots14030%_
                _%sizes14031%_
                _%representations14032%_
                _%observation14033%_
                _%position-of14034%_
                _%complete?14035%_
                _%session?14036%_)))
          (values _%result14038%_
                  (if _%session?14036%_
                      (let ()
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/program/result#owned-publication::t
                         _%result14038%_
                         _%snapshots14030%_
                         _%sizes14031%_
                         _%position-of14034%_))
                      '#f)))))
    (define gerbil-ascent/program/result#gerbil-ascent-publication-cache
      (lambda (_%count14026%_)
        (vector '#f
                (make-vector _%count14026%_ '#f)
                (make-vector _%count14026%_ '#f))))
    (define gerbil-ascent/program/result#gerbil-ascent-publish-rows__%
      (lambda (_%all14008%_ _%cache14009%_ _%sizes14010%_)
        (let ((_%snapshots14012%_
               (let ((__tmp34407 (vector-length _%all14008%_)))
                 (declare (not safe))
                 (##make-vector __tmp34407 '()))))
          (gerbil-ascent/program/result#publish-index!
           _%all14008%_
           (vector-ref _%cache14009%_ '1)
           (vector-ref _%cache14009%_ '2)
           _%snapshots14012%_
           '0
           _%sizes14010%_)
          _%snapshots14012%_)))
    (define gerbil-ascent/program/result#gerbil-ascent-publish-rows__0
      (lambda (_%all14017%_ _%cache14018%_)
        (let ((_%sizes14020%_ '#f))
          (gerbil-ascent/program/result#gerbil-ascent-publish-rows__%
           _%all14017%_
           _%cache14018%_
           _%sizes14020%_))))
    (define gerbil-ascent/program/result#gerbil-ascent-publish-rows
      (lambda _g34408_
        (let ((_g34409_ (let () (declare (not safe)) (##length _g34408_))))
          (cond ((let () (declare (not safe)) (##fx= _g34409_ 2))
                 (apply gerbil-ascent/program/result#gerbil-ascent-publish-rows__0
                        _g34408_))
                ((let () (declare (not safe)) (##fx= _g34409_ 3))
                 (apply gerbil-ascent/program/result#gerbil-ascent-publish-rows__%
                        _g34408_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/result#gerbil-ascent-publish-rows
                  _g34408_))))))
    (define gerbil-ascent/program/result#publish-index!
      (lambda (_%all13997%_
               _%roots13998%_
               _%ordered13999%_
               _%snapshots14000%_
               _%index14001%_
               _%sizes14002%_)
        (if (< _%index14001%_ (vector-length _%all13997%_))
            (begin
              (let ((_%rows14004%_ (vector-ref _%all13997%_ _%index14001%_)))
                (if (eq? _%rows14004%_
                         (vector-ref _%roots13998%_ _%index14001%_))
                    '#!void
                    (begin
                      (vector-set!
                       _%ordered13999%_
                       _%index14001%_
                       (if (let ()
                             (declare (not safe))
                             (##structure-instance-of?
                              _%rows14004%_
                              'gerbil-ascent/core/relation-view#relation-view::t))
                           _%rows14004%_
                           (let ((__tmp34411
                                  (let ((__tmp34412
                                         (lambda () (reverse _%rows14004%_))))
                                    (declare (not safe))
                                    (__make-promise __tmp34412)))
                                 (__tmp34410
                                  (if _%sizes14002%_
                                      (vector-ref
                                       _%sizes14002%_
                                       _%index14001%_)
                                      (length _%rows14004%_))))
                             (declare (not safe))
                             (gerbil-ascent/core/relation-view#gerbil-ascent-lazy-explicit-view
                              __tmp34411
                              __tmp34410))))
                      (vector-set!
                       _%roots13998%_
                       _%index14001%_
                       _%rows14004%_)))
                (vector-set!
                 _%snapshots14000%_
                 _%index14001%_
                 (vector-ref _%ordered13999%_ _%index14001%_)))
              (gerbil-ascent/program/result#publish-index!
               _%all13997%_
               _%roots13998%_
               _%ordered13999%_
               _%snapshots14000%_
               (+ _%index14001%_ '1)
               _%sizes14002%_))
            '#!void)))
    (define gerbil-ascent/program/result#gerbil-ascent-snapshot-rows
      (lambda (_%rows13992%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%rows13992%_
               'gerbil-ascent/core/relation-view#relation-view::t))
            (let ()
              (declare (not safe))
              (gerbil-ascent/core/relation-view#gerbil-ascent-view-rows
               _%rows13992%_))
            (if (promise? _%rows13992%_)
                (force _%rows13992%_)
                _%rows13992%_))))
    (define gerbil-ascent/program/result#gerbil-ascent-public-snapshot-rows
      (lambda (_%snapshot13985%_ _%session?13986%_)
        (let ((_%stored13988%_
               (gerbil-ascent/program/result#gerbil-ascent-snapshot-rows
                _%snapshot13985%_)))
          (if (and _%session?13986%_
                   (not (let ()
                          (declare (not safe))
                          (##structure-instance-of?
                           _%snapshot13985%_
                           'gerbil-ascent/core/relation-view#relation-view::t))))
              (map (lambda (_%row13990%_) (map identity _%row13990%_))
                   _%stored13988%_)
              _%stored13988%_))))
    (define gerbil-ascent/program/result#gerbil-ascent-snapshot-sizes
      (lambda (_%names13979%_ _%snapshots13980%_)
        (let ((__tmp34415
               (lambda (_%name13982%_ _%rows13983%_)
                 (cons _%name13982%_
                       (if (let ()
                             (declare (not safe))
                             (##structure-instance-of?
                              _%rows13983%_
                              'gerbil-ascent/core/relation-view#relation-view::t))
                           (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%rows13983%_
                              '5
                              '#f
                              '#f))
                           (length (gerbil-ascent/program/result#gerbil-ascent-snapshot-rows
                                    _%rows13983%_))))))
              (__tmp34414 (vector->list _%names13979%_))
              (__tmp34413 (vector->list _%snapshots13980%_)))
          (declare (not safe))
          (##map __tmp34415 __tmp34414 __tmp34413))))
    (define gerbil-ascent/program/result#gerbil-ascent-result-observation
      (lambda (_%affected13970%_
               _%names13971%_
               _%active13972%_
               _%rule-ticks13973%_)
        (vector (if _%affected13970%_
                    'stratified-dependency-invalidation
                    'stratified-semi-naive)
                (if _%affected13970%_
                    (let ((__tmp34418
                           (lambda (_%index13975%_)
                             (if (vector-ref _%affected13970%_ _%index13975%_)
                                 '#f
                                 (vector-ref _%names13971%_ _%index13975%_))))
                          (__tmp34416
                           (let ((__tmp34417 (vector-length _%names13971%_)))
                             (declare (not safe))
                             (##iota __tmp34417))))
                      (declare (not safe))
                      (filter-map__0 __tmp34418 __tmp34416))
                    '())
                (let ((__tmp34419
                       (let ((__tmp34420 (vector->list _%active13972%_)))
                         (declare (not safe))
                         (##map length __tmp34420))))
                  (declare (not safe))
                  (##apply + __tmp34419))
                (if _%rule-ticks13973%_
                    (let ((__tmp34422
                           (lambda (_%ticks13977%_)
                             (quotient
                              (* _%ticks13977%_ '1000000000)
                              (jiffies-per-second))))
                          (__tmp34421 (vector->list _%rule-ticks13973%_)))
                      (declare (not safe))
                      (##map __tmp34422 __tmp34421))
                    '#f))))
    (define gerbil-ascent/program/result#gerbil-ascent-visit-snapshot!
      (lambda (_%snapshot13957%_
               _%width13958%_
               _%columns13959%_
               _%key13960%_
               _%consume13961%_)
        (if (and (list? _%columns13959%_)
                 (list? _%key13960%_)
                 (= (let () (declare (not safe)) (##length _%columns13959%_))
                    (let () (declare (not safe)) (##length _%key13960%_)))
                 (let ((__tmp34423
                        (lambda (_%column13963%_)
                          (and (exact-integer? _%column13963%_)
                               (<= '0 _%column13963%_)
                               (< _%column13963%_ _%width13958%_)))))
                   (declare (not safe))
                   (andmap__0 __tmp34423 _%columns13959%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"ASCENT result selection requires in-range columns and matching keys")))
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%snapshot13957%_
               'gerbil-ascent/core/relation-view#relation-view::t))
            (let ((__tmp34424
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/core/relation-view#gerbil-ascent-view-select
                      _%snapshot13957%_
                      _%columns13959%_
                      _%key13960%_))))
              (declare (not safe))
              (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
               _%consume13961%_
               __tmp34424))
            (for-each
             (lambda (_%row13965%_)
               (if (let ((__tmp34425
                          (lambda (_%column13967%_ _%value13968%_)
                            (equal? (list-ref _%row13965%_ _%column13967%_)
                                    _%value13968%_))))
                     (declare (not safe))
                     (andmap__1 __tmp34425 _%columns13959%_ _%key13960%_))
                   (_%consume13961%_ (map identity _%row13965%_))
                   '#!void))
             (gerbil-ascent/program/result#gerbil-ascent-snapshot-rows
              _%snapshot13957%_)))))
    (define gerbil-ascent/program/result#gerbil-ascent-make-published-result
      (lambda (_%names13862%_
               _%arity13863%_
               _%snapshots13864%_
               _%sizes13865%_
               _%representations13866%_
               _%observation13867%_
               _%position-of13868%_
               _%complete?13869%_
               _%session?13870%_)
        (let ((__obj34404
               (let ()
                 (declare (not safe))
                 (##structure
                  clan/poo/object#object::t
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f))))
          (let ((__tmp34427
                 (list (cons 'relation-names
                             (let ((__tmp34428
                                    (lambda (_%self13892%_)
                                      (vector->list _%names13862%_))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34428)))
                       (cons 'finished
                             (let ((__tmp34429
                                    (lambda (_%self13899%_)
                                      _%complete?13869%_)))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34429)))
                       (cons 'evaluation-path
                             (let ((__tmp34430
                                    (lambda (_%self13904%_)
                                      (vector-ref _%observation13867%_ '0))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34430)))
                       (cons 'reused-relations
                             (let ((__tmp34431
                                    (lambda (_%self13909%_)
                                      (vector-ref _%observation13867%_ '1))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34431)))
                       (cons 'active-rule-count
                             (let ((__tmp34432
                                    (lambda (_%self13914%_)
                                      (vector-ref _%observation13867%_ '2))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34432)))
                       (cons 'rule-time-nanoseconds
                             (let ((__tmp34433
                                    (lambda (_%self13919%_)
                                      (vector-ref _%observation13867%_ '3))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34433)))
                       (cons 'representation-observation
                             (let ((__tmp34434
                                    (lambda (_%self13924%_)
                                      (lambda ()
                                        (map (lambda (_%row13930%_)
                                               (map values _%row13930%_))
                                             _%representations13866%_)))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34434)))
                       (cons 'relation-sizes
                             (let ((__tmp34435
                                    (lambda (_%self13932%_)
                                      (lambda ()
                                        (let ((__tmp34437
                                               (vector->list _%names13862%_))
                                              (__tmp34436
                                               (vector->list _%sizes13865%_)))
                                          (declare (not safe))
                                          (##map cons
                                                 __tmp34437
                                                 __tmp34436))))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34435)))
                       (cons 'visit-rows
                             (let ((__tmp34438
                                    (lambda (_%self13938%_)
                                      (lambda (_%name13943%_
                                               _%columns13944%_
                                               _%key13945%_
                                               _%consume13946%_)
                                        (let ((_%index13948%_
                                               (_%position-of13868%_
                                                _%name13943%_)))
                                          (gerbil-ascent/program/result#gerbil-ascent-visit-snapshot!
                                           (vector-ref
                                            _%snapshots13864%_
                                            _%index13948%_)
                                           (vector-ref
                                            _%arity13863%_
                                            _%index13948%_)
                                           _%columns13944%_
                                           _%key13945%_
                                           _%consume13946%_))))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34438)))
                       (cons 'rows-of
                             (let ((__tmp34439
                                    (lambda (_%self13950%_)
                                      (lambda (_%name13955%_)
                                        (gerbil-ascent/program/result#gerbil-ascent-public-snapshot-rows
                                         (vector-ref
                                          _%snapshots13864%_
                                          (_%position-of13868%_ _%name13955%_))
                                         _%session?13870%_)))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34439)))))
                (__tmp34426 (list)))
            (declare (not safe))
            (clan/poo/object#object:::init!__%
             '#f
             '()
             __tmp34427
             __tmp34426
             __obj34404))
          __obj34404)))))
