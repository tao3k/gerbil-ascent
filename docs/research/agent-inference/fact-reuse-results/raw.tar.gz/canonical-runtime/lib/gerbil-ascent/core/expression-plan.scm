(declare (block) (standard-bindings) (extended-bindings))
(begin
  (load-module "gerbil-ascent/core/ordered-call")
  (load-module "gerbil-ascent/core/expression-plan~0"))
