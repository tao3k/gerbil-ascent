# SPDX-FileCopyrightText: 2026 tao3k team and Contributors
# SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
"""Deadline and framing regressions for the existing model consumer IO."""
import importlib.util
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('candidate_model', Path(__file__).with_name('candidate-model.py'))
model = importlib.util.module_from_spec(spec)
spec.loader.exec_module(model)


class TransportTest(unittest.TestCase):
    def consumer(self, script):
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        consumer = model.Consumer.__new__(model.Consumer)
        consumer.run = Path(folder.name)
        consumer.trace = []
        consumer.dynamic = False
        consumer.shutdown = None
        consumer._stdout_buffer = bytearray()
        consumer.err = (consumer.run/'native-stderr.log').open('a')
        consumer.p = subprocess.Popen([sys.executable, '-u', '-c', script],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=consumer.err, bufsize=0)
        self.addCleanup(consumer.close)
        return consumer

    def test_partial_line_obeys_deadline(self):
        c = self.consumer('import sys; sys.stdout.write("{\\\"ready\\\":"); sys.stdout.flush(); sys.stdin.read()')
        began = time.monotonic()
        with self.assertRaises(TimeoutError):
            c.receive(.25)
        self.assertLess(time.monotonic()-began, 1)
        self.assertEqual((c.run/'native-partial-output.bin').read_bytes(), b'{"ready":')
        self.assertTrue(c.close()['clean'])

    def test_multiple_frames_are_not_lost_in_buffer(self):
        c = self.consumer('import sys; sys.stdout.write("{\\\"first\\\":1}\\n{\\\"second\\\":2}\\n"); sys.stdout.flush(); sys.stdin.read()')
        self.assertEqual(c.receive(1), {'first':1})
        self.assertEqual(c.receive(.1), {'second':2})

    def test_split_frame(self):
        c = self.consumer('import sys,time; sys.stdout.write("{\\\"ready\\\":"); sys.stdout.flush(); time.sleep(.05); print("true}"); sys.stdin.read()')
        self.assertEqual(c.receive(1), {'ready':True})

    def test_eof_with_partial_frame_is_failure(self):
        c = self.consumer('print("{",end="",flush=True)')
        with self.assertRaisesRegex(RuntimeError, 'before complete response'):
            c.receive(1)
        self.assertEqual((c.run/'native-partial-output.bin').read_bytes(), b'{')

    def test_invalid_frame_is_preserved(self):
        c = self.consumer('print("not-json",flush=True)')
        with self.assertRaises(model.json.JSONDecodeError):
            c.receive(1)
        self.assertEqual((c.run/'native-invalid-output.log').read_bytes(), b'not-json\n')

    def test_silent_peer_times_out(self):
        c = self.consumer('import sys; sys.stdin.read()')
        with self.assertRaises(TimeoutError):
            c.receive(.1)

    def test_broken_stdin_is_recorded(self):
        c = self.consumer('pass')
        c.p.wait(timeout=1)
        with self.assertRaises(BrokenPipeError):
            c.call(op='ignored')
        self.assertIn('failure', model.json.loads((c.run/'native.json').read_text())[0])

    def test_readiness_failure_records_actual_deadline_and_cleans(self):
        with tempfile.TemporaryDirectory() as folder:
            run = Path(folder)
            real_popen = subprocess.Popen
            def launch(*args, **kwargs):
                return real_popen([sys.executable, '-u', '-c', 'import sys; sys.stdin.read()'], **kwargs)
            with patch.object(model.subprocess, 'Popen', side_effect=launch), \
                    patch.object(model.Consumer, 'receive', side_effect=TimeoutError('test readiness timeout')) as receive:
                with self.assertRaises(TimeoutError):
                    model.Consumer(run, dynamic=True)
                receive.assert_called_once_with(60)
            receipt = model.json.loads((run/'native-readiness-failure.json').read_text())
            self.assertEqual(receipt['deadline'], 60)
            self.assertEqual(receipt['pendingBytes'], 0)
            self.assertTrue(model.json.loads((run/'native-shutdown.json').read_text())['clean'])

    def test_spawn_failure_has_receipt(self):
        with tempfile.TemporaryDirectory() as folder:
            run = Path(folder)
            with patch.object(model.subprocess, 'Popen', side_effect=FileNotFoundError('missing executable')):
                with self.assertRaises(FileNotFoundError):
                    model.Consumer(run)
            self.assertEqual(model.json.loads((run/'native-readiness-failure.json').read_text())['phase'], 'spawn')


class BranchRequestTest(unittest.TestCase):
    def setUp(self):
        self.plan={'model':'deepseek-flash','tool':{'type':'function','name':'expand'},
                   'budget':65536,'outputCap':32768,'minimumOutputCap':1024,'inputReservationPadding':256}
        self.context={'task':{'immutable':'raw facts'},'question':'original question',
                      'frontier':[{'parentId':0,'optionIds':[1]}],'incumbent':{'value':3}}

    def test_first_request_preserves_question_and_thinking(self):
        req,reserve=model.branch_request(self.plan,self.context,[],None,0)
        self.assertEqual(model.json.loads(req['input'][0]['content']),self.context)
        self.assertEqual(req['reasoning'],{'effort':'low'})
        self.assertNotIn('instructions',req)
        self.assertLessEqual(reserve,self.plan['budget'])

    def test_continuation_replays_reasoning_and_pairs_tool_result(self):
        history=[{'role':'user','content':'original'},
                 {'type':'reasoning','content':[{'type':'reasoning_text','text':'kept exactly'}]},
                 {'type':'function_call','call_id':'call-1','name':'expand','arguments':'{}'}]
        req,reserve=model.branch_request(self.plan,self.context,history,'call-1',30000,22000)
        self.assertEqual(req['input'][:-1],history)
        self.assertEqual(req['input'][-1]['call_id'],'call-1')
        self.assertNotIn('task',model.json.loads(req['input'][-1]['output']))
        self.assertLess(req['max_output_tokens'],32768)
        self.assertLessEqual(30000+reserve,65536)

    def test_budget_exhaustion_is_censored_without_request(self):
        req,_=model.branch_request(self.plan,self.context,[],'call-1',65000,20000)
        self.assertIsNone(req)

    def test_continuation_requires_recorded_usage(self):
        with self.assertRaisesRegex(AssertionError,'missing_history_usage'):
            model.branch_request(self.plan,self.context,[],'call-1',10000)


if __name__ == '__main__':
    unittest.main()
