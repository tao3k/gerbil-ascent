prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/core

(begin
  (declare-class
   gerbil-ascent/core/rule-semantics#rule-read::t
   (@class gerbil-ascent/core/rule-semantics#rule-read::t
           ()
           (object::t t::t)
           (kind source)
           (kind source)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/core/rule-semantics#rule-read::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/core/rule-semantics#rule-read::t)
    'class::t))
  (declare-type
   gerbil-ascent/core/rule-semantics#rule-read?
   (@predicate gerbil-ascent/core/rule-semantics#rule-read::t))
  (declare-type
   gerbil-ascent/core/rule-semantics#make-rule-read
   (@constructor gerbil-ascent/core/rule-semantics#rule-read::t))
  (declare-type
   gerbil-ascent/core/rule-semantics#rule-read-kind
   (@accessor gerbil-ascent/core/rule-semantics#rule-read::t kind #t))
  (declare-type
   gerbil-ascent/core/rule-semantics#rule-read-source
   (@accessor gerbil-ascent/core/rule-semantics#rule-read::t source #t))
  (declare-type
   gerbil-ascent/core/rule-semantics#rule-read-kind-set!
   (@mutator gerbil-ascent/core/rule-semantics#rule-read::t kind #t))
  (declare-type
   gerbil-ascent/core/rule-semantics#rule-read-source-set!
   (@mutator gerbil-ascent/core/rule-semantics#rule-read::t source #t))
  (declare-type
   gerbil-ascent/core/rule-semantics#&rule-read-kind
   (@accessor gerbil-ascent/core/rule-semantics#rule-read::t kind #f))
  (declare-type
   gerbil-ascent/core/rule-semantics#&rule-read-source
   (@accessor gerbil-ascent/core/rule-semantics#rule-read::t source #f))
  (declare-type
   gerbil-ascent/core/rule-semantics#&rule-read-kind-set!
   (@mutator gerbil-ascent/core/rule-semantics#rule-read::t kind #f))
  (declare-type
   gerbil-ascent/core/rule-semantics#&rule-read-source-set!
   (@mutator gerbil-ascent/core/rule-semantics#rule-read::t source #f))
  (declare-type
   gerbil-ascent/core/rule-semantics#prepare-rule-reads
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/rule-semantics)))
  (declare-type
   gerbil-ascent/core/rule-semantics#gerbil-ascent-rule-successors
   (@lambda 2
            #f
            signature:
            (return:
             vector::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/rule-semantics)))
  (declare-type
   gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-key
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/rule-semantics)))
  (declare-type
   gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-value
   (@lambda 1 last))
  (declare-type
   gerbil-ascent/core/rule-semantics#gerbil-ascent-joined-row
   (@lambda 2
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/rule-semantics)))
  (declare-type
   gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-feeds-relation?
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/rule-semantics)))
  (declare-type
   gerbil-ascent/core/rule-semantics#gerbil-ascent-rule-strata
   (@lambda 3
            #f
            signature:
            (return:
             vector::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/rule-semantics)))
  (declare-type
   gerbil-ascent/core/rule-semantics#gerbil-ascent-delta-positions
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/rule-semantics))))
