(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/update-selection::timestamp 1791687885)
  (begin
    (define gerbil-ascent/program/update-selection#gerbil-ascent-update-eligible?__%
      (lambda (_%candidate13753%_ _%source-cut13754%_)
        (letrec ((_%pure-terms?13756%_
                  (lambda (_%terms13824%_)
                    (let ((__tmp36831
                           (lambda (_%term13826%_)
                             (let ((_%kind13828%_
                                    (let ()
                                      (declare (not safe))
                                      (clan/poo/object#.ref
                                       _%term13826%_
                                       'kind))))
                               (if (let ()
                                     (declare (not safe))
                                     (##memq _%kind13828%_
                                             '(variable wildcard literal)))
                                   (let ((_%$e13830%_
                                          (not (eq? _%kind13828%_ 'literal))))
                                     (if _%$e13830%_
                                         _%$e13830%_
                                         (let ((__tmp36832
                                                (let ()
                                                  (declare (not safe))
                                                  (clan/poo/object#.ref
                                                   _%term13826%_
                                                   'value))))
                                           (declare (not safe))
                                           (gerbil-ascent/program/scheme-checked#relational-scalar?
                                            __tmp36832))))
                                   '#f)))))
                      (declare (not safe))
                      (andmap__0 __tmp36831 _%terms13824%_))))
                 (_%trusted-field?13757%_
                  (lambda (_%predicate13819%_)
                    (let ((_%$e13821%_
                           (eq? _%predicate13819%_
                                gerbil-ascent/program/scheme-checked#relational-scalar?)))
                      (if _%$e13821%_
                          _%$e13821%_
                          (eq? _%predicate13819%_ exact-integer?)))))
                 (_%scalar-source?13758%_
                  (lambda (_%relation13776%_ _%index13777%_)
                    (let ((_%predicates13779%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%relation13776%_
                              'field-predicates))))
                      (if (let ()
                            (declare (not safe))
                            (andmap__0
                             _%trusted-field?13757%_
                             _%predicates13779%_))
                          (let ((_%$e13781%_ (pair? _%predicates13779%_)))
                            (if _%$e13781%_
                                _%$e13781%_
                                (let ((_%$e13814%_
                                       (if _%source-cut13754%_
                                           (let* ((_%snapshot13784%_
                                                   _%source-cut13754%_)
                                                  (_%candidate13787%_
                                                   _%candidate13753%_)
                                                  (_%index13790%_
                                                   _%index13777%_)
                                                  (_%rows13793%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (clan/poo/object#.ref
                                                      _%relation13776%_
                                                      'rows)))
                                                  (_%snapshot13797%_
                                                   _%snapshot13784%_))
                                             (declare (not safe))
                                             (gerbil-ascent/program/source-snapshot#__gerbil-ascent-source-snapshot-scalar?
                                              _%snapshot13797%_
                                              _%candidate13787%_
                                              _%index13790%_
                                              _%rows13793%_))
                                           '#f)))
                                  (if _%$e13814%_
                                      _%$e13814%_
                                      (let ((__tmp36834
                                             (lambda (_%row13817%_)
                                               (let ()
                                                 (declare (not safe))
                                                 (andmap__0
                                                  gerbil-ascent/program/scheme-checked#relational-scalar?
                                                  _%row13817%_))))
                                            (__tmp36833
                                             (let ()
                                               (declare (not safe))
                                               (clan/poo/object#.ref
                                                _%relation13776%_
                                                'rows))))
                                        (declare (not safe))
                                        (andmap__0 __tmp36834 __tmp36833))))))
                          '#f))))
                 (_%stable-clause?13759%_
                  (lambda (_%clause13768%_)
                    (let ((_%$e13770%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%clause13768%_
                              'ascent-clause-kind))))
                      (if (or (eq? 'atom _%$e13770%_)
                              (eq? 'negation _%$e13770%_))
                          (_%pure-terms?13756%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref _%clause13768%_ 'terms)))
                          (if (eq? 'aggregate _%$e13770%_)
                              (if (_%pure-terms?13756%_
                                   (let ()
                                     (declare (not safe))
                                     (clan/poo/object#.ref
                                      _%clause13768%_
                                      'terms)))
                                  (if (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%clause13768%_
                                         'output-pattern))
                                      '#f
                                      (let ((__tmp36835
                                             (let ()
                                               (declare (not safe))
                                               (clan/poo/object#.ref
                                                _%clause13768%_
                                                'aggregate))))
                                        (declare (not safe))
                                        (gerbil-ascent/program/scheme-checked#relational-stable-procedure?
                                         __tmp36835)))
                                  '#f)
                              (if (eq? 'guard _%$e13770%_)
                                  (let ((__tmp36836
                                         (let ()
                                           (declare (not safe))
                                           (clan/poo/object#.ref
                                            _%clause13768%_
                                            'predicate))))
                                    (declare (not safe))
                                    (gerbil-ascent/program/scheme-checked#relational-stable-procedure?
                                     __tmp36836))
                                  (if (eq? 'binding _%$e13770%_)
                                      (let ((__tmp36837
                                             (let ()
                                               (declare (not safe))
                                               (clan/poo/object#.ref
                                                _%clause13768%_
                                                'compute))))
                                        (declare (not safe))
                                        (gerbil-ascent/program/scheme-checked#relational-stable-procedure?
                                         __tmp36837))
                                      '#f))))))))
          (if (let ((__tmp36841
                     (lambda (_%relation13761%_ _%index13762%_)
                       (and (_%scalar-source?13758%_
                             _%relation13761%_
                             _%index13762%_)
                            (let ((__tmp36842
                                   (let ()
                                     (declare (not safe))
                                     (clan/poo/object#.ref
                                      _%relation13761%_
                                      'index-provider))))
                              (declare (not safe))
                              (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                               __tmp36842))
                            (if (eq? (let ()
                                       (declare (not safe))
                                       (clan/poo/object#.ref
                                        _%relation13761%_
                                        'storage-kind))
                                     'lattice)
                                (let ((__tmp36843
                                       (let ()
                                         (declare (not safe))
                                         (clan/poo/object#.ref
                                          _%relation13761%_
                                          'join))))
                                  (declare (not safe))
                                  (gerbil-ascent/program/scheme-checked#relational-stable-procedure?
                                   __tmp36843))
                                (let ((__tmp36844
                                       (let ()
                                         (declare (not safe))
                                         (clan/poo/object#.ref
                                          _%relation13761%_
                                          'storage-provider))))
                                  (declare (not safe))
                                  (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                                   __tmp36844))))))
                    (__tmp36840
                     (let ()
                       (declare (not safe))
                       (clan/poo/object#.ref _%candidate13753%_ 'relations)))
                    (__tmp36838
                     (let ((__tmp36839
                            (length (let ()
                                      (declare (not safe))
                                      (clan/poo/object#.ref
                                       _%candidate13753%_
                                       'relations)))))
                       (declare (not safe))
                       (##iota __tmp36839))))
                (declare (not safe))
                (andmap__1 __tmp36841 __tmp36840 __tmp36838))
              (let ((__tmp36846
                     (lambda (_%rule13764%_)
                       (if (let ((__tmp36848
                                  (lambda (_%head13766%_)
                                    (_%pure-terms?13756%_
                                     (let ()
                                       (declare (not safe))
                                       (clan/poo/object#.ref
                                        _%head13766%_
                                        'terms)))))
                                 (__tmp36847
                                  (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref
                                     _%rule13764%_
                                     'heads))))
                             (declare (not safe))
                             (andmap__0 __tmp36848 __tmp36847))
                           (let ((__tmp36849
                                  (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref
                                     _%rule13764%_
                                     'body))))
                             (declare (not safe))
                             (andmap__0 _%stable-clause?13759%_ __tmp36849))
                           '#f)))
                    (__tmp36845
                     (let ()
                       (declare (not safe))
                       (clan/poo/object#.ref _%candidate13753%_ 'rules))))
                (declare (not safe))
                (andmap__0 __tmp36846 __tmp36845))
              '#f))))
    (define gerbil-ascent/program/update-selection#gerbil-ascent-update-eligible?__0
      (lambda (_%candidate13836%_)
        (let ((_%source-cut13838%_ '#f))
          (gerbil-ascent/program/update-selection#gerbil-ascent-update-eligible?__%
           _%candidate13836%_
           _%source-cut13838%_))))
    (define gerbil-ascent/program/update-selection#gerbil-ascent-update-eligible?
      (lambda _g36850_
        (let ((_g36851_ (let () (declare (not safe)) (##length _g36850_))))
          (cond ((let () (declare (not safe)) (##fx= _g36851_ 1))
                 (apply gerbil-ascent/program/update-selection#gerbil-ascent-update-eligible?__0
                        _g36850_))
                ((let () (declare (not safe)) (##fx= _g36851_ 2))
                 (apply gerbil-ascent/program/update-selection#gerbil-ascent-update-eligible?__%
                        _g36850_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/update-selection#gerbil-ascent-update-eligible?
                  _g36850_))))))
    (define gerbil-ascent/program/update-selection#gerbil-ascent-update-selection__%
      (lambda (_%previous13675%_
               _%candidate13676%_
               _%analysis13677%_
               _%source-cut13678%_)
        (let* ((_%relations13680%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%candidate13676%_ 'relations)))
               (_%old-relations13682%_ (vector->list _%previous13675%_))
               (_%count13684%_ (length _%relations13680%_))
               (_%affected13686%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count13684%_ '#f)))
               (_%eligible?13689%_
                (if (= _%count13684%_
                       (let ()
                         (declare (not safe))
                         (##length _%old-relations13682%_)))
                    (gerbil-ascent/program/update-selection#gerbil-ascent-update-eligible?__%
                     _%candidate13676%_
                     _%source-cut13678%_)
                    '#f)))
          (if _%eligible?13689%_
              (begin
                (let ((__tmp36853
                       (lambda (_%old13691%_ _%new13692%_ _%index13693%_)
                         (let ((_%rows13695%_
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/object#.ref _%new13692%_ 'rows))))
                           (if (or (and _%source-cut13678%_
                                        (let* ((_%snapshot13697%_
                                                _%source-cut13678%_)
                                               (_%candidate13700%_
                                                _%candidate13676%_)
                                               (_%index13703%_ _%index13693%_)
                                               (_%log13706%_ _%old13691%_)
                                               (_%rows13709%_ _%rows13695%_)
                                               (_%snapshot13713%_
                                                _%snapshot13697%_))
                                          (declare (not safe))
                                          (gerbil-ascent/program/source-snapshot#__gerbil-ascent-source-log-snapshot-equal?
                                           _%snapshot13713%_
                                           _%candidate13700%_
                                           _%index13703%_
                                           _%log13706%_
                                           _%rows13709%_)))
                                   (let ((__tmp36855 (car _%old13691%_))
                                         (__tmp36854 (cdr _%old13691%_)))
                                     (declare (not safe))
                                     (gerbil-ascent/program/source-log#gerbil-ascent-source-log-equal?
                                      __tmp36855
                                      __tmp36854
                                      _%rows13695%_)))
                               '#!void
                               (vector-set!
                                _%affected13686%_
                                _%index13693%_
                                '#t)))))
                      (__tmp36852
                       (let () (declare (not safe)) (##iota _%count13684%_))))
                  (declare (not safe))
                  (##for-each
                   __tmp36853
                   _%old-relations13682%_
                   _%relations13680%_
                   __tmp36852))
                (let ((__tmp36856 (vector-ref _%analysis13677%_ '6)))
                  (declare (not safe))
                  (gerbil-ascent/core/dependency-graph#gerbil-ascent-graph-close!
                   __tmp36856
                   _%affected13686%_))
                _%affected13686%_)
              '#f))))
    (define gerbil-ascent/program/update-selection#gerbil-ascent-update-selection__0
      (lambda (_%previous13741%_ _%candidate13742%_ _%analysis13743%_)
        (let ((_%source-cut13745%_ '#f))
          (gerbil-ascent/program/update-selection#gerbil-ascent-update-selection__%
           _%previous13741%_
           _%candidate13742%_
           _%analysis13743%_
           _%source-cut13745%_))))
    (define gerbil-ascent/program/update-selection#gerbil-ascent-update-selection
      (lambda _g36857_
        (let ((_g36858_ (let () (declare (not safe)) (##length _g36857_))))
          (cond ((let () (declare (not safe)) (##fx= _g36858_ 3))
                 (apply gerbil-ascent/program/update-selection#gerbil-ascent-update-selection__0
                        _g36857_))
                ((let () (declare (not safe)) (##fx= _g36858_ 4))
                 (apply gerbil-ascent/program/update-selection#gerbil-ascent-update-selection__%
                        _g36857_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/update-selection#gerbil-ascent-update-selection
                  _g36857_))))))
    (define gerbil-ascent/program/update-selection#gerbil-ascent-select-rule-plans
      (lambda (_%full-active-by-stratum13148%_ _%affected13149%_)
        (vector-map
         (lambda (_%rules13151%_)
           (let ((__tmp36859
                  (lambda (_%rule13153%_)
                    (let ((_%heads13412%_
                           (let ((_%bitmap13155%_ _%affected13149%_)
                                 (_%source13157%_
                                  (vector-ref _%rule13153%_ '0)))
                             (letrec ((_%keep?13160%_
                                       (lambda (_%head13410%_)
                                         (vector-ref
                                          _%bitmap13155%_
                                          (vector-ref _%head13410%_ '0)))))
                               (let _%scan13163%_ ((_%remaining13166%_
                                                    _%source13157%_))
                                 (let* ((_%$%remaining1316813177%_
                                         _%remaining13166%_)
                                        (_%$%E1317113181%_
                                         (lambda ()
                                           (let ()
                                             (declare (not safe))
                                             (error '"No clause matching"
                                                    _%$%remaining1316813177%_
                                                    '([])
                                                    '([head . rest])))
                                           '#!void)))
                                   (let ((_%$%K1317513407%_
                                          (lambda () _%source13157%_))
                                         (_%$%K1317213391%_
                                          (lambda (_%rest13185%_ _%head13187%_)
                                            (if (_%keep?13160%_ _%head13187%_)
                                                (_%scan13163%_ _%rest13185%_)
                                                (if (eq? _%remaining13166%_
                                                         _%source13157%_)
                                                    (filter _%keep?13160%_
                                                            _%rest13185%_)
                                                    (let* ((_%head13192%_
                                                            (cons '#f '()))
                                                           (_%tail13195%_
                                                            _%head13192%_))
                                                      (let _%prefix13377%_ ((_%pending13380%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                     _%source13157%_))
                (if (eq? _%pending13380%_ _%remaining13166%_)
                    '#!void
                    (begin
                      (let ((_%new-tail13383%_
                             (cons (car _%pending13380%_) '())))
                        (let ()
                          (declare (not safe))
                          (##set-cdr! _%tail13195%_ _%new-tail13383%_))
                        (set! _%tail13195%_ _%new-tail13383%_))
                      (_%prefix13377%_ (cdr _%pending13380%_)))))
              (for-each
               (lambda (_%head13386%_)
                 (if (_%keep?13160%_ _%head13386%_)
                     (let ((_%new-tail13388%_ (cons _%head13386%_ '())))
                       (let ()
                         (declare (not safe))
                         (##set-cdr! _%tail13195%_ _%new-tail13388%_))
                       (set! _%tail13195%_ _%new-tail13388%_))
                     '#!void))
               _%rest13185%_)
              (let () (declare (not safe)) (##cdr _%head13192%_))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     (let ((_%$%try-match1317013403%_
                                            (lambda ()
                                              (if (pair? _%$%remaining1316813177%_)
                                                  (let ((_%$%tl1317413396%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%remaining1316813177%_)))
                                                        (_%$%hd1317313394%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%remaining1316813177%_))))
                                                    (let ((_%head13399%_
                                                           _%$%hd1317313394%_)
                                                          (_%rest13401%_
                                                           _%$%tl1317413396%_))
                                                      (_%$%K1317213391%_
                                                       _%rest13401%_
                                                       _%head13399%_)))
                                                  (_%$%E1317113181%_)))))
                                       (if (null? _%$%remaining1316813177%_)
                                           (_%$%K1317513407%_)
                                           (_%$%try-match1317013403%_))))))))))
                      (if (pair? _%heads13412%_)
                          (if (eq? _%heads13412%_
                                   (vector-ref _%rule13153%_ '0))
                              _%rule13153%_
                              (let* ((_%full-plan13414%_
                                      (vector-ref _%rule13153%_ '5))
                                     (_%plan13671%_
                                      (if _%full-plan13414%_
                                          (let ((__tmp36860
                                                 (let ((_%bitmap13416%_
                                                        _%affected13149%_)
                                                       (_%source13418%_
                                                        (vector-ref
                                                         _%full-plan13414%_
                                                         '0)))
                                                   (letrec ((_%keep?13421%_
                                                             (lambda (_%output13669%_)
                                                               (vector-ref
                                                                _%bitmap13416%_
                                                                (vector-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (vector-ref _%output13669%_ '0)
                         '0)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (let _%scan13424%_ ((_%remaining13427%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                  _%source13418%_))
               (let* ((_%$%remaining1342913438%_ _%remaining13427%_)
                      (_%$%E1343213442%_
                       (lambda ()
                         (let ()
                           (declare (not safe))
                           (error '"No clause matching"
                                  _%$%remaining1342913438%_
                                  '([])
                                  '([output . rest])))
                         '#!void)))
                 (let ((_%$%K1343613666%_ (lambda () _%source13418%_))
                       (_%$%K1343313650%_
                        (lambda (_%rest13446%_ _%output13448%_)
                          (if (_%keep?13421%_ _%output13448%_)
                              (_%scan13424%_ _%rest13446%_)
                              (if (eq? _%remaining13427%_ _%source13418%_)
                                  (filter _%keep?13421%_ _%rest13446%_)
                                  (let* ((_%head13453%_ (cons '#f '()))
                                         (_%tail13456%_ _%head13453%_))
                                    (let _%prefix13636%_ ((_%pending13639%_
                                                           _%source13418%_))
                                      (if (eq? _%pending13639%_
                                               _%remaining13427%_)
                                          '#!void
                                          (begin
                                            (let ((_%new-tail13642%_
                                                   (cons (car _%pending13639%_)
                                                         '())))
                                              (let ()
                                                (declare (not safe))
                                                (##set-cdr!
                                                 _%tail13456%_
                                                 _%new-tail13642%_))
                                              (set! _%tail13456%_
                                                    _%new-tail13642%_))
                                            (_%prefix13636%_
                                             (cdr _%pending13639%_)))))
                                    (for-each
                                     (lambda (_%output13645%_)
                                       (if (_%keep?13421%_ _%output13645%_)
                                           (let ((_%new-tail13647%_
                                                  (cons _%output13645%_ '())))
                                             (let ()
                                               (declare (not safe))
                                               (##set-cdr!
                                                _%tail13456%_
                                                _%new-tail13647%_))
                                             (set! _%tail13456%_
                                                   _%new-tail13647%_))
                                           '#!void))
                                     _%rest13446%_)
                                    (let ()
                                      (declare (not safe))
                                      (##cdr _%head13453%_))))))))
                   (let ((_%$%try-match1343113662%_
                          (lambda ()
                            (if (pair? _%$%remaining1342913438%_)
                                (let ((_%$%tl1343513655%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%remaining1342913438%_)))
                                      (_%$%hd1343413653%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%$%remaining1342913438%_))))
                                  (let ((_%output13658%_ _%$%hd1343413653%_)
                                        (_%rest13660%_ _%$%tl1343513655%_))
                                    (_%$%K1343313650%_
                                     _%rest13660%_
                                     _%output13658%_)))
                                (_%$%E1343213442%_)))))
                     (if (null? _%$%remaining1342913438%_)
                         (_%$%K1343613666%_)
                         (_%$%try-match1343113662%_))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (declare (not safe))
                                            (gerbil-ascent/core/positive-plan#gerbil-ascent-positive-plan-with-outputs
                                             _%full-plan13414%_
                                             __tmp36860))
                                          (let ((__tmp36861
                                                 (vector _%heads13412%_
                                                         (vector-ref
                                                          _%rule13153%_
                                                          '1)
                                                         (vector-ref
                                                          _%rule13153%_
                                                          '2)
                                                         (vector-ref
                                                          _%rule13153%_
                                                          '3))))
                                            (declare (not safe))
                                            (gerbil-ascent/core/positive-plan#gerbil-ascent-positive-plan
                                             __tmp36861)))))
                                (vector _%heads13412%_
                                        (vector-ref _%rule13153%_ '1)
                                        (vector-ref _%rule13153%_ '2)
                                        (vector-ref _%rule13153%_ '3)
                                        (vector-ref _%rule13153%_ '4)
                                        _%plan13671%_)))
                          '#f)))))
             (declare (not safe))
             (filter-map__0 __tmp36859 _%rules13151%_)))
         _%full-active-by-stratum13148%_)))
    (define gerbil-ascent/program/update-selection#gerbil-ascent-update-active-plans
      (lambda (_%full-active-by-stratum13141%_ _%affected13142%_)
        (vector-map
         (lambda (_%rules13144%_)
           (map (lambda (_%rule13146%_)
                  (if (= (vector-length _%rule13146%_) '7)
                      _%rule13146%_
                      (let ()
                        (declare (not safe))
                        (gerbil-ascent/program/activation#gerbil-ascent-activate-rule
                         _%rule13146%_))))
                _%rules13144%_))
         (gerbil-ascent/program/update-selection#gerbil-ascent-select-rule-plans
          _%full-active-by-stratum13141%_
          _%affected13142%_))))))
