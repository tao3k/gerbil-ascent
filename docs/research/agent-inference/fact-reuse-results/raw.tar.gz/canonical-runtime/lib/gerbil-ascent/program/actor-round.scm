(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/core/positive-plan")
    (load-module "gerbil-ascent/table/storage")
    (load-module "gerbil-ascent/table/provider"))
  (load-module "gerbil-ascent/program/actor-round~0"))
