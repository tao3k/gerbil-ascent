prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/program

(begin
  (declare-class
   gerbil-ascent/program/lattice-frontier#lattice-round::t
   (@class gerbil-ascent/program/lattice-frontier#lattice-round::t
           ()
           (object::t t::t)
           (table changes sequence ordered?)
           (table changes sequence ordered?)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-round::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/lattice-frontier#lattice-round::t)
    'class::t))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-round?
   (@predicate gerbil-ascent/program/lattice-frontier#lattice-round::t))
  (declare-type
   gerbil-ascent/program/lattice-frontier#make-lattice-round
   (@constructor gerbil-ascent/program/lattice-frontier#lattice-round::t))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-round-table
   (@accessor
    gerbil-ascent/program/lattice-frontier#lattice-round::t
    table
    #t))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-round-changes
   (@accessor
    gerbil-ascent/program/lattice-frontier#lattice-round::t
    changes
    #t))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-round-sequence
   (@accessor
    gerbil-ascent/program/lattice-frontier#lattice-round::t
    sequence
    #t))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-round-ordered?
   (@accessor
    gerbil-ascent/program/lattice-frontier#lattice-round::t
    ordered?
    #t))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-round-table-set!
   (@mutator gerbil-ascent/program/lattice-frontier#lattice-round::t table #t))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-round-changes-set!
   (@mutator
    gerbil-ascent/program/lattice-frontier#lattice-round::t
    changes
    #t))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-round-sequence-set!
   (@mutator
    gerbil-ascent/program/lattice-frontier#lattice-round::t
    sequence
    #t))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-round-ordered?-set!
   (@mutator
    gerbil-ascent/program/lattice-frontier#lattice-round::t
    ordered?
    #t))
  (declare-type
   gerbil-ascent/program/lattice-frontier#&lattice-round-table
   (@accessor
    gerbil-ascent/program/lattice-frontier#lattice-round::t
    table
    #f))
  (declare-type
   gerbil-ascent/program/lattice-frontier#&lattice-round-changes
   (@accessor
    gerbil-ascent/program/lattice-frontier#lattice-round::t
    changes
    #f))
  (declare-type
   gerbil-ascent/program/lattice-frontier#&lattice-round-sequence
   (@accessor
    gerbil-ascent/program/lattice-frontier#lattice-round::t
    sequence
    #f))
  (declare-type
   gerbil-ascent/program/lattice-frontier#&lattice-round-ordered?
   (@accessor
    gerbil-ascent/program/lattice-frontier#lattice-round::t
    ordered?
    #f))
  (declare-type
   gerbil-ascent/program/lattice-frontier#&lattice-round-table-set!
   (@mutator gerbil-ascent/program/lattice-frontier#lattice-round::t table #f))
  (declare-type
   gerbil-ascent/program/lattice-frontier#&lattice-round-changes-set!
   (@mutator
    gerbil-ascent/program/lattice-frontier#lattice-round::t
    changes
    #f))
  (declare-type
   gerbil-ascent/program/lattice-frontier#&lattice-round-sequence-set!
   (@mutator
    gerbil-ascent/program/lattice-frontier#lattice-round::t
    sequence
    #f))
  (declare-type
   gerbil-ascent/program/lattice-frontier#&lattice-round-ordered?-set!
   (@mutator
    gerbil-ascent/program/lattice-frontier#lattice-round::t
    ordered?
    #f))
  (declare-class
   gerbil-ascent/program/lattice-frontier#lattice-change::t
   (@class gerbil-ascent/program/lattice-frontier#lattice-change::t
           ()
           (object::t t::t)
           (row sequence)
           (row sequence)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-change::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/lattice-frontier#lattice-change::t)
    'class::t))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-change?
   (@predicate gerbil-ascent/program/lattice-frontier#lattice-change::t))
  (declare-type
   gerbil-ascent/program/lattice-frontier#make-lattice-change
   (@constructor gerbil-ascent/program/lattice-frontier#lattice-change::t))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-change-row
   (@accessor gerbil-ascent/program/lattice-frontier#lattice-change::t row #t))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-change-sequence
   (@accessor
    gerbil-ascent/program/lattice-frontier#lattice-change::t
    sequence
    #t))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-change-row-set!
   (@mutator gerbil-ascent/program/lattice-frontier#lattice-change::t row #t))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-change-sequence-set!
   (@mutator
    gerbil-ascent/program/lattice-frontier#lattice-change::t
    sequence
    #t))
  (declare-type
   gerbil-ascent/program/lattice-frontier#&lattice-change-row
   (@accessor gerbil-ascent/program/lattice-frontier#lattice-change::t row #f))
  (declare-type
   gerbil-ascent/program/lattice-frontier#&lattice-change-sequence
   (@accessor
    gerbil-ascent/program/lattice-frontier#lattice-change::t
    sequence
    #f))
  (declare-type
   gerbil-ascent/program/lattice-frontier#&lattice-change-row-set!
   (@mutator gerbil-ascent/program/lattice-frontier#lattice-change::t row #f))
  (declare-type
   gerbil-ascent/program/lattice-frontier#&lattice-change-sequence-set!
   (@mutator
    gerbil-ascent/program/lattice-frontier#lattice-change::t
    sequence
    #f))
  (declare-type
   gerbil-ascent/program/lattice-frontier#make-lattice-frontier
   (@lambda 0
            #f
            signature:
            (return:
             gerbil-ascent/program/lattice-frontier#lattice-round::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/lattice-frontier)))
  (declare-type
   gerbil-ascent/program/lattice-frontier#__lattice-frontier-ref
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/lattice-frontier)))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-frontier-ref
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             (t::t t::t)
             unchecked:
             gerbil-ascent/program/lattice-frontier#__lattice-frontier-ref
             origin:
             gerbil-ascent/program/lattice-frontier)))
  (declare-type
   gerbil-ascent/program/lattice-frontier#__lattice-frontier-stage!
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/lattice-frontier)))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-frontier-stage!
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             (t::t t::t t::t)
             unchecked:
             gerbil-ascent/program/lattice-frontier#__lattice-frontier-stage!
             origin:
             gerbil-ascent/program/lattice-frontier)))
  (declare-type
   gerbil-ascent/program/lattice-frontier#__lattice-frontier-rows
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/lattice-frontier)))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-frontier-rows
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             (t::t)
             unchecked:
             gerbil-ascent/program/lattice-frontier#__lattice-frontier-rows
             origin:
             gerbil-ascent/program/lattice-frontier)))
  (declare-type
   gerbil-ascent/program/lattice-frontier#__lattice-frontier-clear!
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/lattice-frontier)))
  (declare-type
   gerbil-ascent/program/lattice-frontier#lattice-frontier-clear!
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             (t::t)
             unchecked:
             gerbil-ascent/program/lattice-frontier#__lattice-frontier-clear!
             origin:
             gerbil-ascent/program/lattice-frontier))))
