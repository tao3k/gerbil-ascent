(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/feedback[1]#_g39405_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39407_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-feedback
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39409_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39411_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39412_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-reason
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39413_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-missing
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39414_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-extra
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39416_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39417_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-reason-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39418_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-missing-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39419_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-extra-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39421_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39422_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-reason
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39423_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-missing
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39424_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-extra
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39426_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39427_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-reason-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39428_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-missing-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39429_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-extra-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[:0:]#reasoning-feedback|
    (let ((__obj39395
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj39395
         'gerbil-ascent/candidate/feedback#reasoning-feedback::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39395 'reasoning-feedback '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj39395
         '(status reason missing extra)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj39395
         '(status reason missing extra)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39395 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39395 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39395 '#t '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39395 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39395 '#f '13 '#f '#f))
      (let ((__tmp39404 |gerbil-ascent/candidate/feedback[1]#_g39405_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj39395 __tmp39404 '4 '#f '#f))
      (let ((__tmp39406 |gerbil-ascent/candidate/feedback[1]#_g39407_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj39395 __tmp39406 '14 '#f '#f))
      (let ((__tmp39408 |gerbil-ascent/candidate/feedback[1]#_g39409_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj39395 __tmp39408 '15 '#f '#f))
      (let ((__tmp39410
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g39411_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g39412_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g39413_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g39414_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj39395 __tmp39410 '16 '#f '#f))
      (let ((__tmp39415
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g39416_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g39417_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g39418_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g39419_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj39395 __tmp39415 '17 '#f '#f))
      (let ((__tmp39420
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g39421_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g39422_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g39423_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g39424_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj39395 __tmp39420 '18 '#f '#f))
      (let ((__tmp39425
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g39426_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g39427_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g39428_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g39429_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj39395 __tmp39425 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39395 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39395 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39395 '() '21 '#f '#f))
      __obj39395)))
