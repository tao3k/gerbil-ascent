prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/program

(begin
  (declare-type
   gerbil-ascent/program/types#slot-contract
   (@lambda 2
            #f
            signature:
            (return:
             clan/poo/object#object::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/types)))
  (declare-type
   gerbil-ascent/program/types#+symbol+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+symbol+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+arity+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+arity+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+fact-budget+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+fact-budget+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+rows+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+rows+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+field-predicates+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+field-predicates+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+provider+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+provider+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+storage-provider+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+storage-provider+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+term-kind+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+term-kind+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+any+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+any+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+plan+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+plan+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#clause-kind-contract
   (@lambda 1
            #f
            signature:
            (return:
             clan/poo/object#object::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/types)))
  (declare-type
   gerbil-ascent/program/types#GerbilAscentRelationContract
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#GerbilAscentRelationContract)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#GerbilAscentLatticeContract
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#GerbilAscentLatticeContract)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#GerbilAscentTermContract
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#GerbilAscentTermContract)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+terms+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+terms+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#GerbilAscentAtomContract
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#GerbilAscentAtomContract)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+variables+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+variables+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+generator-output+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+generator-output+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+procedure+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+procedure+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+optional-procedure+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+optional-procedure+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+checked-operator+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+checked-operator+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#GerbilAscentGuardContract
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#GerbilAscentGuardContract)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#GerbilAscentGeneratorContract
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#GerbilAscentGeneratorContract)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#GerbilAscentBindingContract
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#GerbilAscentBindingContract)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#GerbilAscentNegationContract
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#GerbilAscentNegationContract)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#GerbilAscentAggregateContract
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#GerbilAscentAggregateContract)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+clauses+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+clauses+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+heads+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+heads+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#GerbilAscentRuleContract
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#GerbilAscentRuleContract)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+relations+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+relations+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+rules+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+rules+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+fragment-exports+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+fragment-exports+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#+source-handles+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#+source-handles+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#GerbilAscentFragmentContract
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#GerbilAscentFragmentContract)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#GerbilAscentProgramContract
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#GerbilAscentProgramContract)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/program/types#gerbil-ascent-owned-root-contract
   (@lambda 1
            #f
            signature:
            (return:
             clan/poo/object#object::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/types)))
  (declare-type
   gerbil-ascent/program/types#GerbilAscentSessionContract
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/types#GerbilAscentSessionContract)
    'clan/poo/object#object::t)))
