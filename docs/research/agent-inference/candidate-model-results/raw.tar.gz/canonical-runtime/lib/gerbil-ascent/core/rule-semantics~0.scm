(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/core/rule-semantics::timestamp 1791689688)
  (begin
    (define gerbil-ascent/core/rule-semantics#rule-read::t
      (let ((__tmp34748 (list))
            (__tmp34747
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/core/rule-semantics#rule-read::t
         'rule-read
         __tmp34748
         '(kind source)
         __tmp34747
         '#f)))
    (define gerbil-ascent/core/rule-semantics#rule-read?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/core/rule-semantics#rule-read::t)))
    (define gerbil-ascent/core/rule-semantics#make-rule-read
      (lambda _%$args8046%_
        (apply make-instance
               gerbil-ascent/core/rule-semantics#rule-read::t
               _%$args8046%_)))
    (define gerbil-ascent/core/rule-semantics#rule-read-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/rule-semantics#rule-read::t
         'kind)))
    (define gerbil-ascent/core/rule-semantics#rule-read-source
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/rule-semantics#rule-read::t
         'source)))
    (define gerbil-ascent/core/rule-semantics#rule-read-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/rule-semantics#rule-read::t
         'kind)))
    (define gerbil-ascent/core/rule-semantics#rule-read-source-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/rule-semantics#rule-read::t
         'source)))
    (define gerbil-ascent/core/rule-semantics#&rule-read-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/rule-semantics#rule-read::t
         'kind)))
    (define gerbil-ascent/core/rule-semantics#&rule-read-source
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/rule-semantics#rule-read::t
         'source)))
    (define gerbil-ascent/core/rule-semantics#&rule-read-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/rule-semantics#rule-read::t
         'kind)))
    (define gerbil-ascent/core/rule-semantics#&rule-read-source-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/rule-semantics#rule-read::t
         'source)))
    (define gerbil-ascent/core/rule-semantics#prepare-rule-reads
      (lambda (_%body7872%_)
        (let* ((_%head7874%_ (cons '#f '())) (_%tail7877%_ _%head7874%_))
          (for-each
           (lambda (_%clause8036%_)
             (let ((_%kind8039%_ (vector-ref _%clause8036%_ '0)))
               (if (let ()
                     (declare (not safe))
                     (##memq _%kind8039%_ '(atom negation aggregate)))
                   (let* ((_%source8041%_
                           (vector-ref (vector-ref _%clause8036%_ '1) '0))
                          (_%new-tail8043%_
                           (cons (let ()
                                   (declare (not safe))
                                   (##structure
                                    gerbil-ascent/core/rule-semantics#rule-read::t
                                    _%kind8039%_
                                    _%source8041%_))
                                 '())))
                     (let ()
                       (declare (not safe))
                       (##set-cdr! _%tail7877%_ _%new-tail8043%_))
                     (set! _%tail7877%_ _%new-tail8043%_))
                   '#!void)))
           _%body7872%_)
          (let () (declare (not safe)) (##cdr _%head7874%_)))))
    (define gerbil-ascent/core/rule-semantics#gerbil-ascent-rule-successors
      (lambda (_%plans7854%_ _%count7855%_)
        (let ((_%successors7857%_ (make-vector _%count7855%_ '())))
          (for-each
           (lambda (_%rule7859%_)
             (let ((_%heads7861%_ (vector-ref _%rule7859%_ '0)))
               (for-each
                (lambda (_%clause7863%_)
                  (let ((_%kind7866%_ (vector-ref _%clause7863%_ '0)))
                    (if (let ()
                          (declare (not safe))
                          (##memq _%kind7866%_ '(atom negation aggregate)))
                        (let ((_%source7868%_
                               (vector-ref (vector-ref _%clause7863%_ '1) '0)))
                          (for-each
                           (lambda (_%head7870%_)
                             (vector-set!
                              _%successors7857%_
                              _%source7868%_
                              (cons (vector-ref _%head7870%_ '0)
                                    (vector-ref
                                     _%successors7857%_
                                     _%source7868%_))))
                           _%heads7861%_))
                        '#!void)))
                (vector-ref _%rule7859%_ '1))))
           _%plans7854%_)
          _%successors7857%_)))
    (define gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-key
      (lambda (_%row7852%_)
        (if (pair? _%row7852%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT lattice row" _%row7852%_)))
        (let () (declare (not safe)) (std/list/list#butlast _%row7852%_))))
    (define gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-value
      (lambda (_%row7850%_) (last _%row7850%_)))
    (define gerbil-ascent/core/rule-semantics#gerbil-ascent-joined-row
      (lambda (_%key7847%_ _%value7848%_)
        (let ((__tmp34749 (list _%value7848%_)))
          (declare (not safe))
          (##append _%key7847%_ __tmp34749))))
    (define gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-feeds-relation?
      (lambda (_%rule-plans7838%_ _%kinds7839%_)
        (let ((__tmp34750
               (lambda (_%rule7841%_)
                 (if (let ((__tmp34752
                            (lambda (_%head7843%_)
                              (eq? (vector-ref
                                    _%kinds7839%_
                                    (vector-ref _%head7843%_ '0))
                                   'relation)))
                           (__tmp34751 (vector-ref _%rule7841%_ '0)))
                       (declare (not safe))
                       (ormap__0 __tmp34752 __tmp34751))
                     (let ((__tmp34754
                            (lambda (_%clause7845%_)
                              (if (eq? (vector-ref _%clause7845%_ '0) 'atom)
                                  (eq? (vector-ref
                                        _%kinds7839%_
                                        (vector-ref
                                         (vector-ref _%clause7845%_ '1)
                                         '0))
                                       'lattice)
                                  '#f)))
                           (__tmp34753 (vector-ref _%rule7841%_ '1)))
                       (declare (not safe))
                       (ormap__0 __tmp34754 __tmp34753))
                     '#f))))
          (declare (not safe))
          (ormap__0 __tmp34750 _%rule-plans7838%_))))
    (define gerbil-ascent/core/rule-semantics#gerbil-ascent-rule-strata
      (lambda (_%rule-plans7754%_ _%relation-count7755%_ _%kinds7756%_)
        (let ((_%strata7758%_ (make-vector _%relation-count7755%_ '0))
              (_%dependencies7759%_ '()))
          (if (or (let ((__tmp34755
                         (lambda (_%rule7761%_)
                           (let ((__tmp34757
                                  (lambda (_%clause7763%_)
                                    (let ((__tmp34758
                                           (vector-ref _%clause7763%_ '0)))
                                      (declare (not safe))
                                      (##memq __tmp34758
                                              '(negation aggregate)))))
                                 (__tmp34756 (vector-ref _%rule7761%_ '1)))
                             (declare (not safe))
                             (ormap__0 __tmp34757 __tmp34756)))))
                    (declare (not safe))
                    (ormap__0 __tmp34755 _%rule-plans7754%_))
                  (gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-feeds-relation?
                   _%rule-plans7754%_
                   _%kinds7756%_))
              (begin
                (for-each
                 (lambda (_%rule7768%_)
                   (let ((_%heads7770%_ (vector-ref _%rule7768%_ '0))
                         (_%reads7771%_
                          (gerbil-ascent/core/rule-semantics#prepare-rule-reads
                           (vector-ref _%rule7768%_ '1))))
                     (for-each
                      (lambda (_%head7773%_)
                        (letrec* ((_%head-index7775%_
                                   (vector-ref _%head7773%_ '0)))
                          (for-each
                           (lambda (_%read7777%_)
                             (let* ((_%read7779%_ _%read7777%_)
                                    (_%lattice-projection?7792%_
                                     (if (eq? (let ()
                                                (declare (not safe))
                                                (##unchecked-structure-ref
                                                 _%read7779%_
                                                 '1
                                                 '#f
                                                 '#f))
                                              'atom)
                                         (if (eq? (vector-ref
                                                   _%kinds7756%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%read7779%_
                                                      '2
                                                      '#f
                                                      '#f)))
                                                  'lattice)
                                             (eq? (vector-ref
                                                   _%kinds7756%_
                                                   _%head-index7775%_)
                                                  'relation)
                                             '#f)
                                         '#f))
                                    (_%strict?7797%_
                                     (let ((_%$e7794%_
                                            (not (eq? (let ()
                                                        (declare (not safe))
                                                        (##unchecked-structure-ref
                                                         _%read7779%_
                                                         '1
                                                         '#f
                                                         '#f))
                                                      'atom))))
                                       (if _%$e7794%_
                                           _%$e7794%_
                                           _%lattice-projection?7792%_))))
                               (set! _%dependencies7759%_
                                     (cons (vector _%head-index7775%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%read7779%_
                                                      '2
                                                      '#f
                                                      '#f))
                                                   (if _%strict?7797%_ '1 '0)
                                                   (if _%lattice-projection?7792%_
                                                       'lattice-projection
                                                       (let ()
                                                         (declare (not safe))
                                                         (##unchecked-structure-ref
                                                          _%read7779%_
                                                          '1
                                                          '#f
                                                          '#f))))
                                           _%dependencies7759%_))))
                           _%reads7771%_)))
                      _%heads7770%_)))
                 _%rule-plans7754%_)
                (let ((_%successors7800%_
                       (make-vector _%relation-count7755%_ '()))
                      (_%outgoing7801%_
                       (make-vector _%relation-count7755%_ '()))
                      (_%component-of7802%_
                       (make-vector _%relation-count7755%_ '#f)))
                  (let ((__tmp34759
                         (lambda (_%dependency7804%_)
                           (let ((_%head7806%_
                                  (vector-ref _%dependency7804%_ '0))
                                 (_%body7807%_
                                  (vector-ref _%dependency7804%_ '1)))
                             (vector-set!
                              _%successors7800%_
                              _%body7807%_
                              (cons _%head7806%_
                                    (vector-ref
                                     _%successors7800%_
                                     _%body7807%_)))
                             (vector-set!
                              _%outgoing7801%_
                              _%body7807%_
                              (cons _%dependency7804%_
                                    (vector-ref
                                     _%outgoing7801%_
                                     _%body7807%_)))))))
                    (declare (not safe))
                    (##for-each __tmp34759 _%dependencies7759%_))
                  (let ((_%components7809%_
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/core/dependency-graph#gerbil-ascent-graph-components
                            _%successors7800%_))))
                    (let ((__tmp34760
                           (lambda (_%members7811%_)
                             (for-each
                              (lambda (_%node7813%_)
                                (vector-set!
                                 _%component-of7802%_
                                 _%node7813%_
                                 _%members7811%_))
                              _%members7811%_))))
                      (declare (not safe))
                      (##for-each __tmp34760 _%components7809%_))
                    (let ((__tmp34761
                           (lambda (_%dependency7815%_)
                             (if (and (= (vector-ref _%dependency7815%_ '2) '1)
                                      (eq? (vector-ref
                                            _%component-of7802%_
                                            (vector-ref _%dependency7815%_ '0))
                                           (vector-ref
                                            _%component-of7802%_
                                            (vector-ref
                                             _%dependency7815%_
                                             '1))))
                                 (let ((_%$e7817%_
                                        (vector-ref _%dependency7815%_ '3)))
                                   (if (eq? 'aggregate _%$e7817%_)
                                       (let ()
                                         (declare (not safe))
                                         (error '"unstratifiable ASCENT aggregate cycle"))
                                       (if (eq? 'negation _%$e7817%_)
                                           (let ()
                                             (declare (not safe))
                                             (error '"unstratifiable ASCENT negation cycle"))
                                           (if (eq? 'lattice-projection
                                                    _%$e7817%_)
                                               (let ()
                                                 (declare (not safe))
                                                 (error '"unstratifiable ASCENT lattice projection cycle"))
                                               (let ()
                                                 (declare (not safe))
                                                 (error '"unstratifiable ASCENT dependency cycle"))))))
                                 '#!void))))
                      (declare (not safe))
                      (##for-each __tmp34761 _%dependencies7759%_))
                    (let ((__tmp34762
                           (lambda (_%members7820%_)
                             (let ((_%stratum7825%_
                                    (let ((__tmp34763
                                           (lambda (_%node7822%_ _%prior7823%_)
                                             (max _%prior7823%_
                                                  (vector-ref
                                                   _%strata7758%_
                                                   _%node7822%_)))))
                                      (declare (not safe))
                                      (foldl__0
                                       __tmp34763
                                       '0
                                       _%members7820%_))))
                               (for-each
                                (lambda (_%node7827%_)
                                  (vector-set!
                                   _%strata7758%_
                                   _%node7827%_
                                   _%stratum7825%_))
                                _%members7820%_)
                               (for-each
                                (lambda (_%node7829%_)
                                  (for-each
                                   (lambda (_%dependency7831%_)
                                     (let* ((_%head7833%_
                                             (vector-ref
                                              _%dependency7831%_
                                              '0))
                                            (_%required7835%_
                                             (+ _%stratum7825%_
                                                (vector-ref
                                                 _%dependency7831%_
                                                 '2))))
                                       (vector-set!
                                        _%strata7758%_
                                        _%head7833%_
                                        (max (vector-ref
                                              _%strata7758%_
                                              _%head7833%_)
                                             _%required7835%_))))
                                   (vector-ref _%outgoing7801%_ _%node7829%_)))
                                _%members7820%_)))))
                      (declare (not safe))
                      (##for-each __tmp34762 _%components7809%_)))))
              '#!void)
          _%strata7758%_)))
    (define gerbil-ascent/core/rule-semantics#gerbil-ascent-delta-positions
      (lambda (_%body7742%_ _%strata7743%_ _%stratum7744%_)
        (let _%loop7746%_ ((_%remaining7748%_ _%body7742%_)
                           (_%depth7749%_ '0)
                           (_%selected7750%_ '()))
          (if (null? _%remaining7748%_)
              (reverse _%selected7750%_)
              (let ((_%clause7752%_ (car _%remaining7748%_)))
                (if (eq? (vector-ref _%clause7752%_ '0) 'atom)
                    (_%loop7746%_
                     (cdr _%remaining7748%_)
                     (+ _%depth7749%_ '1)
                     (if (= (vector-ref
                             _%strata7743%_
                             (vector-ref (vector-ref _%clause7752%_ '1) '0))
                            _%stratum7744%_)
                         (cons _%depth7749%_ _%selected7750%_)
                         _%selected7750%_))
                    (_%loop7746%_
                     (cdr _%remaining7748%_)
                     _%depth7749%_
                     _%selected7750%_)))))))))
