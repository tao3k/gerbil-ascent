(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/types[1]#_g34765_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34767_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34769_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34771_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34772_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34773_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34774_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-relations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34776_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34777_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34778_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34779_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-relations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34781_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34782_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34783_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34784_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-relations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34786_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34787_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34788_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34789_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-relations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34791_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34793_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-diagnostic
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34795_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34797_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic-code
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34798_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic-path
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34799_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic-detail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34801_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic-code-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34802_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic-path-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34803_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic-detail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34805_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-diagnostic-code
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34806_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-diagnostic-path
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34807_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-diagnostic-detail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34809_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-diagnostic-code-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34810_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-diagnostic-path-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34811_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-diagnostic-detail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34813_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34815_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-candidate
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34817_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34819_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-relations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34820_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-facts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34821_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-rules
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34822_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34823_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-limits
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34825_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-relations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34826_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-facts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34827_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-rules-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34828_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34829_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-limits-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34831_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-relations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34832_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-facts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34833_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-rules
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34834_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34835_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-limits
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34837_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-relations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34838_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-facts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34839_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-rules-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34840_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34841_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-limits-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34843_|
    (##structure
     gx#syntax-quote::t
     'candidate-rejection::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34845_|
    (##structure
     gx#syntax-quote::t
     'make-candidate-rejection
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34847_|
    (##structure
     gx#syntax-quote::t
     'candidate-rejection?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34849_|
    (##structure
     gx#syntax-quote::t
     'candidate-rejection-diagnostic
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34851_|
    (##structure
     gx#syntax-quote::t
     'candidate-rejection-diagnostic-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34853_|
    (##structure
     gx#syntax-quote::t
     '&candidate-rejection-diagnostic
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34855_|
    (##structure
     gx#syntax-quote::t
     '&candidate-rejection-diagnostic-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/types[:0:]#reasoning-snapshot|
      (let ((__obj34708
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34708
           'gerbil-ascent/candidate/types#reasoning-snapshot::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34708
           'reasoning-snapshot
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34708
           '(identity generation digest relations)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34708
           '(identity generation digest relations)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34708 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34708 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34708 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34708 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34708 '#f '13 '#f '#f))
        (let ((__tmp34764 |gerbil-ascent/candidate/types[1]#_g34765_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34708 __tmp34764 '4 '#f '#f))
        (let ((__tmp34766 |gerbil-ascent/candidate/types[1]#_g34767_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34708 __tmp34766 '14 '#f '#f))
        (let ((__tmp34768 |gerbil-ascent/candidate/types[1]#_g34769_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34708 __tmp34768 '15 '#f '#f))
        (let ((__tmp34770
               (cons (cons 'identity
                           |gerbil-ascent/candidate/types[1]#_g34771_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/candidate/types[1]#_g34772_|)
                           (cons (cons 'digest
                                       |gerbil-ascent/candidate/types[1]#_g34773_|)
                                 (cons (cons 'relations
                                             |gerbil-ascent/candidate/types[1]#_g34774_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34708 __tmp34770 '16 '#f '#f))
        (let ((__tmp34775
               (cons (cons 'identity
                           |gerbil-ascent/candidate/types[1]#_g34776_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/candidate/types[1]#_g34777_|)
                           (cons (cons 'digest
                                       |gerbil-ascent/candidate/types[1]#_g34778_|)
                                 (cons (cons 'relations
                                             |gerbil-ascent/candidate/types[1]#_g34779_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34708 __tmp34775 '17 '#f '#f))
        (let ((__tmp34780
               (cons (cons 'identity
                           |gerbil-ascent/candidate/types[1]#_g34781_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/candidate/types[1]#_g34782_|)
                           (cons (cons 'digest
                                       |gerbil-ascent/candidate/types[1]#_g34783_|)
                                 (cons (cons 'relations
                                             |gerbil-ascent/candidate/types[1]#_g34784_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34708 __tmp34780 '18 '#f '#f))
        (let ((__tmp34785
               (cons (cons 'identity
                           |gerbil-ascent/candidate/types[1]#_g34786_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/candidate/types[1]#_g34787_|)
                           (cons (cons 'digest
                                       |gerbil-ascent/candidate/types[1]#_g34788_|)
                                 (cons (cons 'relations
                                             |gerbil-ascent/candidate/types[1]#_g34789_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34708 __tmp34785 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34708 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34708 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34708 '() '21 '#f '#f))
        __obj34708))
    (define |gerbil-ascent/candidate/types[:0:]#reasoning-diagnostic|
      (let ((__obj34709
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34709
           'gerbil-ascent/candidate/types#reasoning-diagnostic::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34709
           'reasoning-diagnostic
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34709
           '(code path detail)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34709
           '(code path detail)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34709 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34709 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34709 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34709 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34709 '#f '13 '#f '#f))
        (let ((__tmp34790 |gerbil-ascent/candidate/types[1]#_g34791_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34709 __tmp34790 '4 '#f '#f))
        (let ((__tmp34792 |gerbil-ascent/candidate/types[1]#_g34793_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34709 __tmp34792 '14 '#f '#f))
        (let ((__tmp34794 |gerbil-ascent/candidate/types[1]#_g34795_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34709 __tmp34794 '15 '#f '#f))
        (let ((__tmp34796
               (cons (cons 'code |gerbil-ascent/candidate/types[1]#_g34797_|)
                     (cons (cons 'path
                                 |gerbil-ascent/candidate/types[1]#_g34798_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/candidate/types[1]#_g34799_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34709 __tmp34796 '16 '#f '#f))
        (let ((__tmp34800
               (cons (cons 'code |gerbil-ascent/candidate/types[1]#_g34801_|)
                     (cons (cons 'path
                                 |gerbil-ascent/candidate/types[1]#_g34802_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/candidate/types[1]#_g34803_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34709 __tmp34800 '17 '#f '#f))
        (let ((__tmp34804
               (cons (cons 'code |gerbil-ascent/candidate/types[1]#_g34805_|)
                     (cons (cons 'path
                                 |gerbil-ascent/candidate/types[1]#_g34806_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/candidate/types[1]#_g34807_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34709 __tmp34804 '18 '#f '#f))
        (let ((__tmp34808
               (cons (cons 'code |gerbil-ascent/candidate/types[1]#_g34809_|)
                     (cons (cons 'path
                                 |gerbil-ascent/candidate/types[1]#_g34810_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/candidate/types[1]#_g34811_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34709 __tmp34808 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34709 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34709 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34709 '() '21 '#f '#f))
        __obj34709))
    (define |gerbil-ascent/candidate/types[:0:]#reasoning-candidate|
      (let ((__obj34710
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34710
           'gerbil-ascent/candidate/types#reasoning-candidate::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34710
           'reasoning-candidate
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34710
           '(relations facts rules query limits)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34710
           '(relations facts rules query limits)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34710 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34710 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34710 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34710 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34710 '#f '13 '#f '#f))
        (let ((__tmp34812 |gerbil-ascent/candidate/types[1]#_g34813_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34710 __tmp34812 '4 '#f '#f))
        (let ((__tmp34814 |gerbil-ascent/candidate/types[1]#_g34815_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34710 __tmp34814 '14 '#f '#f))
        (let ((__tmp34816 |gerbil-ascent/candidate/types[1]#_g34817_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34710 __tmp34816 '15 '#f '#f))
        (let ((__tmp34818
               (cons (cons 'relations
                           |gerbil-ascent/candidate/types[1]#_g34819_|)
                     (cons (cons 'facts
                                 |gerbil-ascent/candidate/types[1]#_g34820_|)
                           (cons (cons 'rules
                                       |gerbil-ascent/candidate/types[1]#_g34821_|)
                                 (cons (cons 'query
                                             |gerbil-ascent/candidate/types[1]#_g34822_|)
                                       (cons (cons 'limits
                                                   |gerbil-ascent/candidate/types[1]#_g34823_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34710 __tmp34818 '16 '#f '#f))
        (let ((__tmp34824
               (cons (cons 'relations
                           |gerbil-ascent/candidate/types[1]#_g34825_|)
                     (cons (cons 'facts
                                 |gerbil-ascent/candidate/types[1]#_g34826_|)
                           (cons (cons 'rules
                                       |gerbil-ascent/candidate/types[1]#_g34827_|)
                                 (cons (cons 'query
                                             |gerbil-ascent/candidate/types[1]#_g34828_|)
                                       (cons (cons 'limits
                                                   |gerbil-ascent/candidate/types[1]#_g34829_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34710 __tmp34824 '17 '#f '#f))
        (let ((__tmp34830
               (cons (cons 'relations
                           |gerbil-ascent/candidate/types[1]#_g34831_|)
                     (cons (cons 'facts
                                 |gerbil-ascent/candidate/types[1]#_g34832_|)
                           (cons (cons 'rules
                                       |gerbil-ascent/candidate/types[1]#_g34833_|)
                                 (cons (cons 'query
                                             |gerbil-ascent/candidate/types[1]#_g34834_|)
                                       (cons (cons 'limits
                                                   |gerbil-ascent/candidate/types[1]#_g34835_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34710 __tmp34830 '18 '#f '#f))
        (let ((__tmp34836
               (cons (cons 'relations
                           |gerbil-ascent/candidate/types[1]#_g34837_|)
                     (cons (cons 'facts
                                 |gerbil-ascent/candidate/types[1]#_g34838_|)
                           (cons (cons 'rules
                                       |gerbil-ascent/candidate/types[1]#_g34839_|)
                                 (cons (cons 'query
                                             |gerbil-ascent/candidate/types[1]#_g34840_|)
                                       (cons (cons 'limits
                                                   |gerbil-ascent/candidate/types[1]#_g34841_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34710 __tmp34836 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34710 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34710 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34710 '() '21 '#f '#f))
        __obj34710))
    (define |gerbil-ascent/candidate/types[:0:]#candidate-rejection|
      (let ((__obj34711
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34711
           'gerbil-ascent/candidate/types#candidate-rejection::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34711
           'candidate-rejection
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34711 '(diagnostic) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34711 '(diagnostic) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34711 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34711 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34711 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34711 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34711 '#f '13 '#f '#f))
        (let ((__tmp34842 |gerbil-ascent/candidate/types[1]#_g34843_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34711 __tmp34842 '4 '#f '#f))
        (let ((__tmp34844 |gerbil-ascent/candidate/types[1]#_g34845_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34711 __tmp34844 '14 '#f '#f))
        (let ((__tmp34846 |gerbil-ascent/candidate/types[1]#_g34847_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34711 __tmp34846 '15 '#f '#f))
        (let ((__tmp34848
               (cons (cons 'diagnostic
                           |gerbil-ascent/candidate/types[1]#_g34849_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj34711 __tmp34848 '16 '#f '#f))
        (let ((__tmp34850
               (cons (cons 'diagnostic
                           |gerbil-ascent/candidate/types[1]#_g34851_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj34711 __tmp34850 '17 '#f '#f))
        (let ((__tmp34852
               (cons (cons 'diagnostic
                           |gerbil-ascent/candidate/types[1]#_g34853_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj34711 __tmp34852 '18 '#f '#f))
        (let ((__tmp34854
               (cons (cons 'diagnostic
                           |gerbil-ascent/candidate/types[1]#_g34855_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj34711 __tmp34854 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34711 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34711 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34711 '() '21 '#f '#f))
        __obj34711))))
