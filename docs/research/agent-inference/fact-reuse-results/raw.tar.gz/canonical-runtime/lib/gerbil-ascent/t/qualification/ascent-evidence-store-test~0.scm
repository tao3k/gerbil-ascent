(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/t/qualification/ascent-evidence-store-test::timestamp
    1791691197)
  (begin
    (define gerbil-ascent/t/qualification/ascent-evidence-store-test#field
      (lambda (_%name4995%_ _%answer4996%_)
        (cadr (assq _%name4995%_ _%answer4996%_))))
    (define gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
      '(candidate
        (relation path 2)
        (relation ready 1)
        (rule (path ?x ?y) (edge ?x ?y))
        (rule (path ?x ?z) (path ?x ?y) (edge ?y ?z))
        (rule (ready ?f) (need ?f ?u ?v ?x ?y) (path ?u ?v) (path ?x ?y))
        (query ready ?f)
        (limits 16 128 128)))
    (define gerbil-ascent/t/qualification/ascent-evidence-store-test#source__%
      (lambda (_%generation4977%_ _%edges4978%_)
        (let ((__tmp7882
               (list (list 'edge '2 _%edges4978%_)
                     (list 'need '5 '((0 0 2 3 4) (1 0 2 4 3))))))
          (declare (not safe))
          (gerbil-ascent/candidate/reasoning#reasoning-source-snapshot
           'search
           _%generation4977%_
           __tmp7882))))
    (define gerbil-ascent/t/qualification/ascent-evidence-store-test#source__0
      (lambda ()
        (let* ((_%generation4984%_ '0) (_%edges4986%_ '((0 1) (1 2) (3 4))))
          (gerbil-ascent/t/qualification/ascent-evidence-store-test#source__%
           _%generation4984%_
           _%edges4986%_))))
    (define gerbil-ascent/t/qualification/ascent-evidence-store-test#source__1
      (lambda (_%generation4988%_)
        (let ((_%edges4990%_ '((0 1) (1 2) (3 4))))
          (gerbil-ascent/t/qualification/ascent-evidence-store-test#source__%
           _%generation4988%_
           _%edges4990%_))))
    (define gerbil-ascent/t/qualification/ascent-evidence-store-test#source
      (lambda _g7883_
        (let ((_g7884_ (let () (declare (not safe)) (##length _g7883_))))
          (cond ((let () (declare (not safe)) (##fx= _g7884_ 0))
                 (apply gerbil-ascent/t/qualification/ascent-evidence-store-test#source__0
                        _g7883_))
                ((let () (declare (not safe)) (##fx= _g7884_ 1))
                 (apply gerbil-ascent/t/qualification/ascent-evidence-store-test#source__1
                        _g7883_))
                ((let () (declare (not safe)) (##fx= _g7884_ 2))
                 (apply gerbil-ascent/t/qualification/ascent-evidence-store-test#source__%
                        _g7883_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/t/qualification/ascent-evidence-store-test#source
                  _g7883_))))))
    (define gerbil-ascent/t/qualification/ascent-evidence-store-test#ascent-evidence-store-test
      (let ((__obj7881
             (let ()
               (declare (not safe))
               (##structure std/test/base#TestSuite::t '#f '#f '#f '#f '#f))))
        (let ((__tmp7885
               (lambda ()
                 (let* ((_%tc2366%_
                         (let ((__obj7827
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp7886
                                  (lambda ()
                                    (let* ((_%store1920%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__0)))
                                           (_%snapshot1922%_
                                            (gerbil-ascent/t/qualification/ascent-evidence-store-test#source__0))
                                           (_%answer1924%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                                               _%store1920%_
                                               _%snapshot1922%_
                                               gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate)))
                                           (_%h1926%_
                                            (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                             'handle
                                             _%answer1924%_))
                                           (_%a1928%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-evidence-fragment
                                               _%store1920%_
                                               _%snapshot1922%_
                                               gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
                                               _%h1926%_
                                               '(path 0 2))))
                                           (_%b1930%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-evidence-fragment
                                               _%store1920%_
                                               _%snapshot1922%_
                                               gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
                                               _%h1926%_
                                               '(ready 0))))
                                           (_%nodes1932%_
                                            (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                             'nodes
                                             _%b1930%_)))
                                      (let* ((_%desc1935%_ '(field 'status a))
                                             (_%where1938%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@26.23-26.40")
                                             (_%thunk1949%_
                                              (lambda ()
                                                (let* ((_%expected1942%_
                                                        'verified)
                                                       (_%result1945%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         _%a1928%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected1942%_
                                                         _%result1945%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7887
                                                               (let ((__obj7819
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7888
                                (cons '(field 'status a)
                                      (cons 'test:
                                            (cons '(field 'status a)
                                                  (cons 'result:
                                                        (cons _%result1945%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected1942%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7819
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@26.23-26.40"
                            'irritants:
                            __tmp7888))
                         __obj7819)))
                  (declare (not safe))
                  (raise __tmp7887))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc1954%_ _%desc1935%_)
                                             (_%where1977%_ _%where1938%_)
                                             (_%thunk1987%_ _%thunk1949%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc1954%_
                                         _%where1977%_
                                         _%thunk1987%_))
                                      (let* ((_%desc1997%_ '(field 'status b))
                                             (_%where2000%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@27.23-27.40")
                                             (_%thunk2011%_
                                              (lambda ()
                                                (let* ((_%expected2004%_
                                                        'verified)
                                                       (_%result2007%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         _%b1930%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected2004%_
                                                         _%result2007%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7889
                                                               (let ((__obj7820
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7890
                                (cons '(field 'status b)
                                      (cons 'test:
                                            (cons '(field 'status b)
                                                  (cons 'result:
                                                        (cons _%result2007%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected2004%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7820
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@27.23-27.40"
                            'irritants:
                            __tmp7890))
                         __obj7820)))
                  (declare (not safe))
                  (raise __tmp7889))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc2016%_ _%desc1997%_)
                                             (_%where2028%_ _%where2000%_)
                                             (_%thunk2038%_ _%thunk2011%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc2016%_
                                         _%where2028%_
                                         _%thunk2038%_))
                                      (for-each
                                       (lambda (_%n2048%_)
                                         (let* ((_%desc2050%_
                                                 '(and (assoc (car n) nodes)
                                                       #t))
                                                (_%where2053%_
                                                 '"\"t/qualification/ascent-evidence-store-test.ss\"@29.35-29.65")
                                                (_%thunk2064%_
                                                 (lambda ()
                                                   (let* ((_%expected2057%_
                                                           '#t)
                                                          (_%result2060%_
                                                           (if (assoc (car _%n2048%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              _%nodes1932%_)
                       '#t
                       '#f)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (if (let ()
                                                           (declare (not safe))
                                                           (std/test/unit#equal-values?
                                                            _%expected2057%_
                                                            _%result2060%_))
                                                         '#!void
                                                         (begin
                                                           (let ((__tmp7891
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (let ((__obj7821
                                 (let ()
                                   (declare (not safe))
                                   (##structure
                                    std/test/base#TestError::t
                                    '#f
                                    '#f
                                    '#f
                                    '#f))))
                            (let ((__tmp7892
                                   (cons '(and (assoc (car n) nodes) #t)
                                         (cons 'test:
                                               (cons '(and (assoc (car n)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          nodes)
                   #t)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (cons 'result:
                                                           (cons _%result2060%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (cons 'expectation:
                               (cons _%expected2057%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                              (declare (not safe))
                              (std/test/base#TestError:::init!
                               __obj7821
                               '"result does not match expectation"
                               'where:
                               '"\"t/qualification/ascent-evidence-store-test.ss\"@29.35-29.65"
                               'irritants:
                               __tmp7892))
                            __obj7821)))
                     (declare (not safe))
                     (raise __tmp7891))
                   '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (_%desc2069%_ _%desc2050%_)
                                                (_%where2082%_ _%where2053%_)
                                                (_%thunk2092%_ _%thunk2064%_))
                                           (declare (not safe))
                                           (std/test/base#__test-check!
                                            _%desc2069%_
                                            _%where2082%_
                                            _%thunk2092%_))
                                         (for-each
                                          (lambda (_%id2102%_)
                                            (let* ((_%desc2104%_
                                                    '(and (assoc id nodes) #t))
                                                   (_%where2107%_
                                                    '"\"t/qualification/ascent-evidence-store-test.ss\"@30.58-30.83")
                                                   (_%thunk2118%_
                                                    (lambda ()
                                                      (let* ((_%expected2111%_
                                                              '#t)
                                                             (_%result2114%_
                                                              (if (assoc _%id2102%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                 _%nodes1932%_)
                          '#t
                          '#f)))
                (if (let ()
                      (declare (not safe))
                      (std/test/unit#equal-values?
                       _%expected2111%_
                       _%result2114%_))
                    '#!void
                    (begin
                      (let ((__tmp7893
                             (let ((__obj7822
                                    (let ()
                                      (declare (not safe))
                                      (##structure
                                       std/test/base#TestError::t
                                       '#f
                                       '#f
                                       '#f
                                       '#f))))
                               (let ((__tmp7894
                                      (cons '(and (assoc id nodes) #t)
                                            (cons 'test:
                                                  (cons '(and (assoc id nodes)
                                                              #t)
                                                        (cons 'result:
                                                              (cons _%result2114%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons 'expectation:
                                  (cons _%expected2111%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                 (declare (not safe))
                                 (std/test/base#TestError:::init!
                                  __obj7822
                                  '"result does not match expectation"
                                  'where:
                                  '"\"t/qualification/ascent-evidence-store-test.ss\"@30.58-30.83"
                                  'irritants:
                                  __tmp7894))
                               __obj7822)))
                        (declare (not safe))
                        (raise __tmp7893))
                      '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (_%desc2123%_ _%desc2104%_)
                                                   (_%where2136%_
                                                    _%where2107%_)
                                                   (_%thunk2146%_
                                                    _%thunk2118%_))
                                              (declare (not safe))
                                              (std/test/base#__test-check!
                                               _%desc2123%_
                                               _%where2136%_
                                               _%thunk2146%_)))
                                          (list-ref _%n2048%_ '5)))
                                       (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                        'nodes
                                        _%a1928%_))
                                      (for-each
                                       (lambda (_%n2156%_)
                                         (for-each
                                          (lambda (_%id2158%_)
                                            (let* ((_%desc2160%_
                                                    '(and (assoc id nodes) #t))
                                                   (_%where2163%_
                                                    '"\"t/qualification/ascent-evidence-store-test.ss\"@33.36-33.61")
                                                   (_%thunk2174%_
                                                    (lambda ()
                                                      (let* ((_%expected2167%_
                                                              '#t)
                                                             (_%result2170%_
                                                              (if (assoc _%id2158%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                 _%nodes1932%_)
                          '#t
                          '#f)))
                (if (let ()
                      (declare (not safe))
                      (std/test/unit#equal-values?
                       _%expected2167%_
                       _%result2170%_))
                    '#!void
                    (begin
                      (let ((__tmp7895
                             (let ((__obj7823
                                    (let ()
                                      (declare (not safe))
                                      (##structure
                                       std/test/base#TestError::t
                                       '#f
                                       '#f
                                       '#f
                                       '#f))))
                               (let ((__tmp7896
                                      (cons '(and (assoc id nodes) #t)
                                            (cons 'test:
                                                  (cons '(and (assoc id nodes)
                                                              #t)
                                                        (cons 'result:
                                                              (cons _%result2170%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons 'expectation:
                                  (cons _%expected2167%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                 (declare (not safe))
                                 (std/test/base#TestError:::init!
                                  __obj7823
                                  '"result does not match expectation"
                                  'where:
                                  '"\"t/qualification/ascent-evidence-store-test.ss\"@33.36-33.61"
                                  'irritants:
                                  __tmp7896))
                               __obj7823)))
                        (declare (not safe))
                        (raise __tmp7895))
                      '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (_%desc2179%_ _%desc2160%_)
                                                   (_%where2193%_
                                                    _%where2163%_)
                                                   (_%thunk2203%_
                                                    _%thunk2174%_))
                                              (declare (not safe))
                                              (std/test/base#__test-check!
                                               _%desc2179%_
                                               _%where2193%_
                                               _%thunk2203%_)))
                                          (list-ref _%n2156%_ '5)))
                                       _%nodes1932%_)
                                      (let* ((_%desc2213%_
                                              '(field 'status
                                                      (reasoning-evidence-fragment
                                                       store
                                                       (source 1)
                                                       candidate
                                                       h
                                                       '(ready 0))))
                                             (_%where2216%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@34.23-34.108")
                                             (_%thunk2227%_
                                              (lambda ()
                                                (let* ((_%expected2220%_
                                                        'unknown)
                                                       (_%result2223%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         (let ((__tmp7897
                                                                (gerbil-ascent/t/qualification/ascent-evidence-store-test#source__1
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '1)))
                   (declare (not safe))
                   (gerbil-ascent/candidate/evidence-store#reasoning-evidence-fragment
                    _%store1920%_
                    __tmp7897
                    gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
                    _%h1926%_
                    '(ready 0))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected2220%_
                                                         _%result2223%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7898
                                                               (let ((__obj7824
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7899
                                (cons '(field 'status
                                              (reasoning-evidence-fragment
                                               store
                                               (source 1)
                                               candidate
                                               h
                                               '(ready 0)))
                                      (cons 'test:
                                            (cons '(field 'status
                                                          (reasoning-evidence-fragment
                                                           store
                                                           (source 1)
                                                           candidate
                                                           h
                                                           '(ready 0)))
                                                  (cons 'result:
                                                        (cons _%result2223%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected2220%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7824
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@34.23-34.108"
                            'irritants:
                            __tmp7899))
                         __obj7824)))
                  (declare (not safe))
                  (raise __tmp7898))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc2232%_ _%desc2213%_)
                                             (_%where2244%_ _%where2216%_)
                                             (_%thunk2254%_ _%thunk2227%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc2232%_
                                         _%where2244%_
                                         _%thunk2254%_))
                                      (let* ((_%desc2264%_
                                              '(field 'status
                                                      (reasoning-evidence-fragment
                                                       store
                                                       snapshot
                                                       candidate
                                                       h
                                                       '(path 4 3))))
                                             (_%where2267%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@35.23-35.107")
                                             (_%thunk2278%_
                                              (lambda ()
                                                (let* ((_%expected2271%_
                                                        'finite-absent)
                                                       (_%result2274%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/candidate/evidence-store#reasoning-evidence-fragment
                                                            _%store1920%_
                                                            _%snapshot1922%_
                                                            gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
                                                            _%h1926%_
                                                            '(path 4 3))))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected2271%_
                                                         _%result2274%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7900
                                                               (let ((__obj7825
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7901
                                (cons '(field 'status
                                              (reasoning-evidence-fragment
                                               store
                                               snapshot
                                               candidate
                                               h
                                               '(path 4 3)))
                                      (cons 'test:
                                            (cons '(field 'status
                                                          (reasoning-evidence-fragment
                                                           store
                                                           snapshot
                                                           candidate
                                                           h
                                                           '(path 4 3)))
                                                  (cons 'result:
                                                        (cons _%result2274%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected2271%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7825
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@35.23-35.107"
                            'irritants:
                            __tmp7901))
                         __obj7825)))
                  (declare (not safe))
                  (raise __tmp7900))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc2283%_ _%desc2264%_)
                                             (_%where2295%_ _%where2267%_)
                                             (_%thunk2305%_ _%thunk2278%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc2283%_
                                         _%where2295%_
                                         _%thunk2305%_))
                                      (let* ((_%desc2315%_
                                              '(field 'proof-builds
                                                      (reasoning-evidence-store-stats
                                                       store)))
                                             (_%where2318%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@36.23-36.83")
                                             (_%thunk2329%_
                                              (lambda ()
                                                (let* ((_%expected2322%_ '1)
                                                       (_%result2325%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'proof-builds
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-stats
                                                            _%store1920%_)))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected2322%_
                                                         _%result2325%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7902
                                                               (let ((__obj7826
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7903
                                (cons '(field 'proof-builds
                                              (reasoning-evidence-store-stats
                                               store))
                                      (cons 'test:
                                            (cons '(field 'proof-builds
                                                          (reasoning-evidence-store-stats
                                                           store))
                                                  (cons 'result:
                                                        (cons _%result2325%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected2322%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7826
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@36.23-36.83"
                            'irritants:
                            __tmp7903))
                         __obj7826)))
                  (declare (not safe))
                  (raise __tmp7902))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc2334%_ _%desc2315%_)
                                             (_%where2346%_ _%where2318%_)
                                             (_%thunk2356%_ _%thunk2329%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc2334%_
                                         _%where2346%_
                                         _%thunk2356%_))))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj7827
                              '"Fact fragments close over shared support and reject stale generations"
                              __tmp7886))
                           __obj7827))
                        (_%tc2371%_ _%tc2366%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc2371%_))
                 (let* ((_%tc2969%_
                         (let ((__obj7839
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp7904
                                  (lambda ()
                                    (let* ((_%store2382%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__0)))
                                           (_%snapshot2384%_
                                            (gerbil-ascent/t/qualification/ascent-evidence-store-test#source__0))
                                           (_%a2386%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                                               _%store2382%_
                                               _%snapshot2384%_
                                               gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate)))
                                           (_%b2388%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                                               _%store2382%_
                                               _%snapshot2384%_
                                               gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate))))
                                      (let* ((_%desc2391%_ '(field 'status a))
                                             (_%where2394%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@41.23-41.40")
                                             (_%thunk2405%_
                                              (lambda ()
                                                (let* ((_%expected2398%_
                                                        'verified)
                                                       (_%result2401%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         _%a2386%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected2398%_
                                                         _%result2401%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7905
                                                               (let ((__obj7828
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7906
                                (cons '(field 'status a)
                                      (cons 'test:
                                            (cons '(field 'status a)
                                                  (cons 'result:
                                                        (cons _%result2401%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected2398%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7828
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@41.23-41.40"
                            'irritants:
                            __tmp7906))
                         __obj7828)))
                  (declare (not safe))
                  (raise __tmp7905))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc2410%_ _%desc2391%_)
                                             (_%where2428%_ _%where2394%_)
                                             (_%thunk2438%_ _%thunk2405%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc2410%_
                                         _%where2428%_
                                         _%thunk2438%_))
                                      (let* ((_%desc2448%_ '(field 'reused a))
                                             (_%where2451%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@42.23-42.40")
                                             (_%thunk2462%_
                                              (lambda ()
                                                (let* ((_%expected2455%_ '#f)
                                                       (_%result2458%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'reused
                                                         _%a2386%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected2455%_
                                                         _%result2458%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7907
                                                               (let ((__obj7829
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7908
                                (cons '(field 'reused a)
                                      (cons 'test:
                                            (cons '(field 'reused a)
                                                  (cons 'result:
                                                        (cons _%result2458%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected2455%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7829
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@42.23-42.40"
                            'irritants:
                            __tmp7908))
                         __obj7829)))
                  (declare (not safe))
                  (raise __tmp7907))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc2467%_ _%desc2448%_)
                                             (_%where2479%_ _%where2451%_)
                                             (_%thunk2489%_ _%thunk2462%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc2467%_
                                         _%where2479%_
                                         _%thunk2489%_))
                                      (let* ((_%desc2499%_ '(field 'reused b))
                                             (_%where2502%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@43.23-43.40")
                                             (_%thunk2513%_
                                              (lambda ()
                                                (let* ((_%expected2506%_ '#t)
                                                       (_%result2509%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'reused
                                                         _%b2388%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected2506%_
                                                         _%result2509%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7909
                                                               (let ((__obj7830
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7910
                                (cons '(field 'reused b)
                                      (cons 'test:
                                            (cons '(field 'reused b)
                                                  (cons 'result:
                                                        (cons _%result2509%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected2506%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7830
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@43.23-43.40"
                            'irritants:
                            __tmp7910))
                         __obj7830)))
                  (declare (not safe))
                  (raise __tmp7909))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc2518%_ _%desc2499%_)
                                             (_%where2530%_ _%where2502%_)
                                             (_%thunk2540%_ _%thunk2513%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc2518%_
                                         _%where2530%_
                                         _%thunk2540%_))
                                      (let* ((_%desc2550%_ '(field 'handle a))
                                             (_%where2553%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@44.23-44.40")
                                             (_%thunk2564%_
                                              (lambda ()
                                                (let* ((_%expected2557%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'handle
                                                         _%b2388%_))
                                                       (_%result2560%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'handle
                                                         _%a2386%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected2557%_
                                                         _%result2560%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7911
                                                               (let ((__obj7831
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7912
                                (cons '(field 'handle a)
                                      (cons 'test:
                                            (cons '(field 'handle a)
                                                  (cons 'result:
                                                        (cons _%result2560%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected2557%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7831
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@44.23-44.40"
                            'irritants:
                            __tmp7912))
                         __obj7831)))
                  (declare (not safe))
                  (raise __tmp7911))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc2569%_ _%desc2550%_)
                                             (_%where2581%_ _%where2553%_)
                                             (_%thunk2591%_ _%thunk2564%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc2569%_
                                         _%where2581%_
                                         _%thunk2591%_))
                                      (let* ((_%desc2601%_
                                              '(field 'proof-builds
                                                      (reasoning-evidence-store-stats
                                                       store)))
                                             (_%where2604%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@45.23-45.83")
                                             (_%thunk2615%_
                                              (lambda ()
                                                (let* ((_%expected2608%_ '1)
                                                       (_%result2611%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'proof-builds
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-stats
                                                            _%store2382%_)))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected2608%_
                                                         _%result2611%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7913
                                                               (let ((__obj7832
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7914
                                (cons '(field 'proof-builds
                                              (reasoning-evidence-store-stats
                                               store))
                                      (cons 'test:
                                            (cons '(field 'proof-builds
                                                          (reasoning-evidence-store-stats
                                                           store))
                                                  (cons 'result:
                                                        (cons _%result2611%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected2608%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7832
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@45.23-45.83"
                            'irritants:
                            __tmp7914))
                         __obj7832)))
                  (declare (not safe))
                  (raise __tmp7913))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc2620%_ _%desc2601%_)
                                             (_%where2632%_ _%where2604%_)
                                             (_%thunk2642%_ _%thunk2615%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc2620%_
                                         _%where2632%_
                                         _%thunk2642%_))
                                      (let* ((_%desc2652%_
                                              '(field 'hits
                                                      (reasoning-evidence-store-stats
                                                       store)))
                                             (_%where2655%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@46.23-46.75")
                                             (_%thunk2666%_
                                              (lambda ()
                                                (let* ((_%expected2659%_ '1)
                                                       (_%result2662%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'hits
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-stats
                                                            _%store2382%_)))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected2659%_
                                                         _%result2662%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7915
                                                               (let ((__obj7833
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7916
                                (cons '(field 'hits
                                              (reasoning-evidence-store-stats
                                               store))
                                      (cons 'test:
                                            (cons '(field 'hits
                                                          (reasoning-evidence-store-stats
                                                           store))
                                                  (cons 'result:
                                                        (cons _%result2662%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected2659%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7833
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@46.23-46.75"
                            'irritants:
                            __tmp7916))
                         __obj7833)))
                  (declare (not safe))
                  (raise __tmp7915))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc2671%_ _%desc2652%_)
                                             (_%where2683%_ _%where2655%_)
                                             (_%thunk2693%_ _%thunk2666%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc2671%_
                                         _%where2683%_
                                         _%thunk2693%_))
                                      (let* ((_%h2703%_
                                              (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                               'handle
                                               _%a2386%_))
                                             (_%left2705%_
                                              (let ()
                                                (declare (not safe))
                                                (gerbil-ascent/candidate/evidence-store#reasoning-evidence-partition
                                                 _%store2382%_
                                                 _%snapshot2384%_
                                                 gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
                                                 _%h2703%_
                                                 '((10 ((ready 0)))
                                                   (11 ((ready 1)))))))
                                             (_%right2707%_
                                              (let ()
                                                (declare (not safe))
                                                (gerbil-ascent/candidate/evidence-store#reasoning-evidence-partition
                                                 _%store2382%_
                                                 _%snapshot2384%_
                                                 gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
                                                 _%h2703%_
                                                 '((20 ((path 0 2) (path 3 4)))
                                                   (21 ((path 4 3))))))))
                                        (let* ((_%desc2710%_
                                                '(field 'allowed left))
                                               (_%where2713%_
                                                '"\"t/qualification/ascent-evidence-store-test.ss\"@50.25-50.46")
                                               (_%thunk2724%_
                                                (lambda ()
                                                  (let* ((_%expected2717%_
                                                          '(10))
                                                         (_%result2720%_
                                                          (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                           'allowed
                                                           _%left2705%_)))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (std/test/unit#equal-values?
                                                           _%expected2717%_
                                                           _%result2720%_))
                                                        '#!void
                                                        (begin
                                                          (let ((__tmp7917
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ((__obj7834
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestError::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp7918
                                  (cons '(field 'allowed left)
                                        (cons 'test:
                                              (cons '(field 'allowed left)
                                                    (cons 'result:
                                                          (cons _%result2720%_
                                                                (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%expected2717%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                             (declare (not safe))
                             (std/test/base#TestError:::init!
                              __obj7834
                              '"result does not match expectation"
                              'where:
                              '"\"t/qualification/ascent-evidence-store-test.ss\"@50.25-50.46"
                              'irritants:
                              __tmp7918))
                           __obj7834)))
                    (declare (not safe))
                    (raise __tmp7917))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%desc2729%_ _%desc2710%_)
                                               (_%where2745%_ _%where2713%_)
                                               (_%thunk2755%_ _%thunk2724%_))
                                          (declare (not safe))
                                          (std/test/base#__test-check!
                                           _%desc2729%_
                                           _%where2745%_
                                           _%thunk2755%_))
                                        (let* ((_%desc2765%_
                                                '(field 'pruned left))
                                               (_%where2768%_
                                                '"\"t/qualification/ascent-evidence-store-test.ss\"@51.25-51.45")
                                               (_%thunk2779%_
                                                (lambda ()
                                                  (let* ((_%expected2772%_
                                                          '(11))
                                                         (_%result2775%_
                                                          (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                           'pruned
                                                           _%left2705%_)))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (std/test/unit#equal-values?
                                                           _%expected2772%_
                                                           _%result2775%_))
                                                        '#!void
                                                        (begin
                                                          (let ((__tmp7919
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ((__obj7835
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestError::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp7920
                                  (cons '(field 'pruned left)
                                        (cons 'test:
                                              (cons '(field 'pruned left)
                                                    (cons 'result:
                                                          (cons _%result2775%_
                                                                (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%expected2772%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                             (declare (not safe))
                             (std/test/base#TestError:::init!
                              __obj7835
                              '"result does not match expectation"
                              'where:
                              '"\"t/qualification/ascent-evidence-store-test.ss\"@51.25-51.45"
                              'irritants:
                              __tmp7920))
                           __obj7835)))
                    (declare (not safe))
                    (raise __tmp7919))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%desc2784%_ _%desc2765%_)
                                               (_%where2796%_ _%where2768%_)
                                               (_%thunk2806%_ _%thunk2779%_))
                                          (declare (not safe))
                                          (std/test/base#__test-check!
                                           _%desc2784%_
                                           _%where2796%_
                                           _%thunk2806%_))
                                        (let* ((_%desc2816%_
                                                '(field 'allowed right))
                                               (_%where2819%_
                                                '"\"t/qualification/ascent-evidence-store-test.ss\"@52.25-52.47")
                                               (_%thunk2830%_
                                                (lambda ()
                                                  (let* ((_%expected2823%_
                                                          '(20))
                                                         (_%result2826%_
                                                          (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                           'allowed
                                                           _%right2707%_)))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (std/test/unit#equal-values?
                                                           _%expected2823%_
                                                           _%result2826%_))
                                                        '#!void
                                                        (begin
                                                          (let ((__tmp7921
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ((__obj7836
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestError::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp7922
                                  (cons '(field 'allowed right)
                                        (cons 'test:
                                              (cons '(field 'allowed right)
                                                    (cons 'result:
                                                          (cons _%result2826%_
                                                                (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%expected2823%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                             (declare (not safe))
                             (std/test/base#TestError:::init!
                              __obj7836
                              '"result does not match expectation"
                              'where:
                              '"\"t/qualification/ascent-evidence-store-test.ss\"@52.25-52.47"
                              'irritants:
                              __tmp7922))
                           __obj7836)))
                    (declare (not safe))
                    (raise __tmp7921))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%desc2835%_ _%desc2816%_)
                                               (_%where2847%_ _%where2819%_)
                                               (_%thunk2857%_ _%thunk2830%_))
                                          (declare (not safe))
                                          (std/test/base#__test-check!
                                           _%desc2835%_
                                           _%where2847%_
                                           _%thunk2857%_))
                                        (let* ((_%desc2867%_
                                                '(field 'pruned right))
                                               (_%where2870%_
                                                '"\"t/qualification/ascent-evidence-store-test.ss\"@53.25-53.46")
                                               (_%thunk2881%_
                                                (lambda ()
                                                  (let* ((_%expected2874%_
                                                          '(21))
                                                         (_%result2877%_
                                                          (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                           'pruned
                                                           _%right2707%_)))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (std/test/unit#equal-values?
                                                           _%expected2874%_
                                                           _%result2877%_))
                                                        '#!void
                                                        (begin
                                                          (let ((__tmp7923
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ((__obj7837
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestError::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp7924
                                  (cons '(field 'pruned right)
                                        (cons 'test:
                                              (cons '(field 'pruned right)
                                                    (cons 'result:
                                                          (cons _%result2877%_
                                                                (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%expected2874%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                             (declare (not safe))
                             (std/test/base#TestError:::init!
                              __obj7837
                              '"result does not match expectation"
                              'where:
                              '"\"t/qualification/ascent-evidence-store-test.ss\"@53.25-53.46"
                              'irritants:
                              __tmp7924))
                           __obj7837)))
                    (declare (not safe))
                    (raise __tmp7923))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%desc2886%_ _%desc2867%_)
                                               (_%where2898%_ _%where2870%_)
                                               (_%thunk2908%_ _%thunk2881%_))
                                          (declare (not safe))
                                          (std/test/base#__test-check!
                                           _%desc2886%_
                                           _%where2898%_
                                           _%thunk2908%_))
                                        (let* ((_%desc2918%_
                                                '(field 'proof-builds
                                                        (reasoning-evidence-store-stats
                                                         store)))
                                               (_%where2921%_
                                                '"\"t/qualification/ascent-evidence-store-test.ss\"@54.25-54.85")
                                               (_%thunk2932%_
                                                (lambda ()
                                                  (let* ((_%expected2925%_ '1)
                                                         (_%result2928%_
                                                          (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                           'proof-builds
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-stats
                                                              _%store2382%_)))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (std/test/unit#equal-values?
                                                           _%expected2925%_
                                                           _%result2928%_))
                                                        '#!void
                                                        (begin
                                                          (let ((__tmp7925
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ((__obj7838
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestError::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp7926
                                  (cons '(field 'proof-builds
                                                (reasoning-evidence-store-stats
                                                 store))
                                        (cons 'test:
                                              (cons '(field 'proof-builds
                                                            (reasoning-evidence-store-stats
                                                             store))
                                                    (cons 'result:
                                                          (cons _%result2928%_
                                                                (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%expected2925%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                             (declare (not safe))
                             (std/test/base#TestError:::init!
                              __obj7838
                              '"result does not match expectation"
                              'where:
                              '"\"t/qualification/ascent-evidence-store-test.ss\"@54.25-54.85"
                              'irritants:
                              __tmp7926))
                           __obj7838)))
                    (declare (not safe))
                    (raise __tmp7925))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%desc2937%_ _%desc2918%_)
                                               (_%where2949%_ _%where2921%_)
                                               (_%thunk2959%_ _%thunk2932%_))
                                          (declare (not safe))
                                          (std/test/base#__test-check!
                                           _%desc2937%_
                                           _%where2949%_
                                           _%thunk2959%_)))))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj7839
                              '"one proof build across distinct branch paths; no model hint needed"
                              __tmp7904))
                           __obj7839))
                        (_%tc2974%_ _%tc2969%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc2974%_))
                 (let* ((_%tc3263%_
                         (let ((__obj7845
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp7927
                                  (lambda ()
                                    (let* ((_%store2985%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__0)))
                                           (_%snapshot2987%_
                                            (gerbil-ascent/t/qualification/ascent-evidence-store-test#source__0))
                                           (_%a2990%_
                                            (thread-start!
                                             (make-thread
                                              (lambda ()
                                                (let ()
                                                  (declare (not safe))
                                                  (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                                                   _%store2985%_
                                                   _%snapshot2987%_
                                                   gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate))))))
                                           (_%b2993%_
                                            (thread-start!
                                             (make-thread
                                              (lambda ()
                                                (let ()
                                                  (declare (not safe))
                                                  (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                                                   _%store2985%_
                                                   _%snapshot2987%_
                                                   gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate))))))
                                           (_%left2995%_
                                            (thread-join! _%a2990%_))
                                           (_%right2997%_
                                            (thread-join! _%b2993%_)))
                                      (let* ((_%desc3000%_
                                              '(field 'status left))
                                             (_%where3003%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@60.23-60.43")
                                             (_%thunk3014%_
                                              (lambda ()
                                                (let* ((_%expected3007%_
                                                        'verified)
                                                       (_%result3010%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         _%left2995%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3007%_
                                                         _%result3010%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7928
                                                               (let ((__obj7840
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7929
                                (cons '(field 'status left)
                                      (cons 'test:
                                            (cons '(field 'status left)
                                                  (cons 'result:
                                                        (cons _%result3010%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3007%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7840
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@60.23-60.43"
                            'irritants:
                            __tmp7929))
                         __obj7840)))
                  (declare (not safe))
                  (raise __tmp7928))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3019%_ _%desc3000%_)
                                             (_%where3039%_ _%where3003%_)
                                             (_%thunk3049%_ _%thunk3014%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3019%_
                                         _%where3039%_
                                         _%thunk3049%_))
                                      (let* ((_%desc3059%_
                                              '(field 'status right))
                                             (_%where3062%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@61.23-61.44")
                                             (_%thunk3073%_
                                              (lambda ()
                                                (let* ((_%expected3066%_
                                                        'verified)
                                                       (_%result3069%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         _%right2997%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3066%_
                                                         _%result3069%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7930
                                                               (let ((__obj7841
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7931
                                (cons '(field 'status right)
                                      (cons 'test:
                                            (cons '(field 'status right)
                                                  (cons 'result:
                                                        (cons _%result3069%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3066%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7841
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@61.23-61.44"
                            'irritants:
                            __tmp7931))
                         __obj7841)))
                  (declare (not safe))
                  (raise __tmp7930))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3078%_ _%desc3059%_)
                                             (_%where3090%_ _%where3062%_)
                                             (_%thunk3100%_ _%thunk3073%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3078%_
                                         _%where3090%_
                                         _%thunk3100%_))
                                      (let* ((_%desc3110%_
                                              '(field 'handle left))
                                             (_%where3113%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@62.23-62.43")
                                             (_%thunk3124%_
                                              (lambda ()
                                                (let* ((_%expected3117%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'handle
                                                         _%right2997%_))
                                                       (_%result3120%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'handle
                                                         _%left2995%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3117%_
                                                         _%result3120%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7932
                                                               (let ((__obj7842
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7933
                                (cons '(field 'handle left)
                                      (cons 'test:
                                            (cons '(field 'handle left)
                                                  (cons 'result:
                                                        (cons _%result3120%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3117%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7842
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@62.23-62.43"
                            'irritants:
                            __tmp7933))
                         __obj7842)))
                  (declare (not safe))
                  (raise __tmp7932))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3129%_ _%desc3110%_)
                                             (_%where3141%_ _%where3113%_)
                                             (_%thunk3151%_ _%thunk3124%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3129%_
                                         _%where3141%_
                                         _%thunk3151%_))
                                      (let* ((_%desc3161%_
                                              '(field 'proof-builds
                                                      (reasoning-evidence-store-stats
                                                       store)))
                                             (_%where3164%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@63.23-63.83")
                                             (_%thunk3175%_
                                              (lambda ()
                                                (let* ((_%expected3168%_ '1)
                                                       (_%result3171%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'proof-builds
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-stats
                                                            _%store2985%_)))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3168%_
                                                         _%result3171%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7934
                                                               (let ((__obj7843
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7935
                                (cons '(field 'proof-builds
                                              (reasoning-evidence-store-stats
                                               store))
                                      (cons 'test:
                                            (cons '(field 'proof-builds
                                                          (reasoning-evidence-store-stats
                                                           store))
                                                  (cons 'result:
                                                        (cons _%result3171%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3168%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7843
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@63.23-63.83"
                            'irritants:
                            __tmp7935))
                         __obj7843)))
                  (declare (not safe))
                  (raise __tmp7934))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3180%_ _%desc3161%_)
                                             (_%where3192%_ _%where3164%_)
                                             (_%thunk3202%_ _%thunk3175%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3180%_
                                         _%where3192%_
                                         _%thunk3202%_))
                                      (let* ((_%desc3212%_
                                              '(field 'hits
                                                      (reasoning-evidence-store-stats
                                                       store)))
                                             (_%where3215%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@64.23-64.75")
                                             (_%thunk3226%_
                                              (lambda ()
                                                (let* ((_%expected3219%_ '1)
                                                       (_%result3222%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'hits
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-stats
                                                            _%store2985%_)))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3219%_
                                                         _%result3222%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7936
                                                               (let ((__obj7844
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7937
                                (cons '(field 'hits
                                              (reasoning-evidence-store-stats
                                               store))
                                      (cons 'test:
                                            (cons '(field 'hits
                                                          (reasoning-evidence-store-stats
                                                           store))
                                                  (cons 'result:
                                                        (cons _%result3222%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3219%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7844
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@64.23-64.75"
                            'irritants:
                            __tmp7937))
                         __obj7844)))
                  (declare (not safe))
                  (raise __tmp7936))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3231%_ _%desc3212%_)
                                             (_%where3243%_ _%where3215%_)
                                             (_%thunk3253%_ _%thunk3226%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3231%_
                                         _%where3243%_
                                         _%thunk3253%_))))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj7845
                              '"concurrent callers share one serialized admitted build"
                              __tmp7927))
                           __obj7845))
                        (_%tc3268%_ _%tc3263%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc3268%_))
                 (let* ((_%tc3561%_
                         (let ((__obj7851
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp7938
                                  (lambda ()
                                    (let* ((_%store3279%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__0)))
                                           (_%snapshot3281%_
                                            (gerbil-ascent/t/qualification/ascent-evidence-store-test#source__0))
                                           (_%a3283%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                                               _%store3279%_
                                               _%snapshot3281%_
                                               gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate)))
                                           (_%h3285%_
                                            (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                             'handle
                                             _%a3283%_))
                                           (_%changed3287%_
                                            (gerbil-ascent/t/qualification/ascent-evidence-store-test#source__%
                                             '0
                                             '((0 1) (3 4))))
                                           (_%revision3289%_
                                            (gerbil-ascent/t/qualification/ascent-evidence-store-test#source__1
                                             '1)))
                                      (let* ((_%desc3292%_
                                              '(field 'status
                                                      (reasoning-evidence-claim
                                                       store
                                                       changed
                                                       candidate
                                                       h
                                                       '(0))))
                                             (_%where3295%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@70.23-70.96")
                                             (_%thunk3306%_
                                              (lambda ()
                                                (let* ((_%expected3299%_
                                                        'unknown)
                                                       (_%result3302%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/candidate/evidence-store#reasoning-evidence-claim
                                                            _%store3279%_
                                                            _%changed3287%_
                                                            gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
                                                            _%h3285%_
                                                            '(0))))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3299%_
                                                         _%result3302%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7939
                                                               (let ((__obj7846
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7940
                                (cons '(field 'status
                                              (reasoning-evidence-claim
                                               store
                                               changed
                                               candidate
                                               h
                                               '(0)))
                                      (cons 'test:
                                            (cons '(field 'status
                                                          (reasoning-evidence-claim
                                                           store
                                                           changed
                                                           candidate
                                                           h
                                                           '(0)))
                                                  (cons 'result:
                                                        (cons _%result3302%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3299%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7846
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@70.23-70.96"
                            'irritants:
                            __tmp7940))
                         __obj7846)))
                  (declare (not safe))
                  (raise __tmp7939))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3311%_ _%desc3292%_)
                                             (_%where3331%_ _%where3295%_)
                                             (_%thunk3341%_ _%thunk3306%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3311%_
                                         _%where3331%_
                                         _%thunk3341%_))
                                      (let* ((_%desc3351%_
                                              '(field 'status
                                                      (reasoning-evidence-claim
                                                       store
                                                       revision
                                                       candidate
                                                       h
                                                       '(0))))
                                             (_%where3354%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@71.23-71.97")
                                             (_%thunk3365%_
                                              (lambda ()
                                                (let* ((_%expected3358%_
                                                        'unknown)
                                                       (_%result3361%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/candidate/evidence-store#reasoning-evidence-claim
                                                            _%store3279%_
                                                            _%revision3289%_
                                                            gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
                                                            _%h3285%_
                                                            '(0))))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3358%_
                                                         _%result3361%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7941
                                                               (let ((__obj7847
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7942
                                (cons '(field 'status
                                              (reasoning-evidence-claim
                                               store
                                               revision
                                               candidate
                                               h
                                               '(0)))
                                      (cons 'test:
                                            (cons '(field 'status
                                                          (reasoning-evidence-claim
                                                           store
                                                           revision
                                                           candidate
                                                           h
                                                           '(0)))
                                                  (cons 'result:
                                                        (cons _%result3361%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3358%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7847
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@71.23-71.97"
                            'irritants:
                            __tmp7942))
                         __obj7847)))
                  (declare (not safe))
                  (raise __tmp7941))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3370%_ _%desc3351%_)
                                             (_%where3382%_ _%where3354%_)
                                             (_%thunk3392%_ _%thunk3365%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3370%_
                                         _%where3382%_
                                         _%thunk3392%_))
                                      (let ((_%changed-answer3402%_
                                             (let ()
                                               (declare (not safe))
                                               (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                                                _%store3279%_
                                                _%changed3287%_
                                                gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate))))
                                        (let* ((_%desc3404%_
                                                '(field 'status
                                                        changed-answer))
                                               (_%where3407%_
                                                '"\"t/qualification/ascent-evidence-store-test.ss\"@73.25-73.55")
                                               (_%thunk3418%_
                                                (lambda ()
                                                  (let* ((_%expected3411%_
                                                          'verified)
                                                         (_%result3414%_
                                                          (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                           'status
                                                           _%changed-answer3402%_)))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (std/test/unit#equal-values?
                                                           _%expected3411%_
                                                           _%result3414%_))
                                                        '#!void
                                                        (begin
                                                          (let ((__tmp7943
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ((__obj7848
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestError::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp7944
                                  (cons '(field 'status changed-answer)
                                        (cons 'test:
                                              (cons '(field 'status
                                                            changed-answer)
                                                    (cons 'result:
                                                          (cons _%result3414%_
                                                                (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%expected3411%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                             (declare (not safe))
                             (std/test/base#TestError:::init!
                              __obj7848
                              '"result does not match expectation"
                              'where:
                              '"\"t/qualification/ascent-evidence-store-test.ss\"@73.25-73.55"
                              'irritants:
                              __tmp7944))
                           __obj7848)))
                    (declare (not safe))
                    (raise __tmp7943))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%desc3423%_ _%desc3404%_)
                                               (_%where3436%_ _%where3407%_)
                                               (_%thunk3446%_ _%thunk3418%_))
                                          (declare (not safe))
                                          (std/test/base#__test-check!
                                           _%desc3423%_
                                           _%where3436%_
                                           _%thunk3446%_))
                                        (let* ((_%desc3456%_
                                                '(field 'status
                                                        (reasoning-evidence-claim
                                                         store
                                                         changed
                                                         candidate
                                                         (field 'handle
                                                                changed-answer)
                                                         '(0))))
                                               (_%where3459%_
                                                '"\"t/qualification/ascent-evidence-store-test.ss\"@74.25-74.127")
                                               (_%thunk3470%_
                                                (lambda ()
                                                  (let* ((_%expected3463%_
                                                          'finite-absent)
                                                         (_%result3466%_
                                                          (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                           'status
                                                           (let ((__tmp7945
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                           'handle
                           _%changed-answer3402%_)))
                     (declare (not safe))
                     (gerbil-ascent/candidate/evidence-store#reasoning-evidence-claim
                      _%store3279%_
                      _%changed3287%_
                      gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
                      __tmp7945
                      '(0))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (std/test/unit#equal-values?
                                                           _%expected3463%_
                                                           _%result3466%_))
                                                        '#!void
                                                        (begin
                                                          (let ((__tmp7946
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ((__obj7849
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestError::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp7947
                                  (cons '(field 'status
                                                (reasoning-evidence-claim
                                                 store
                                                 changed
                                                 candidate
                                                 (field 'handle changed-answer)
                                                 '(0)))
                                        (cons 'test:
                                              (cons '(field 'status
                                                            (reasoning-evidence-claim
                                                             store
                                                             changed
                                                             candidate
                                                             (field 'handle
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            changed-answer)
                     '(0)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (cons 'result:
                                                          (cons _%result3466%_
                                                                (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%expected3463%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                             (declare (not safe))
                             (std/test/base#TestError:::init!
                              __obj7849
                              '"result does not match expectation"
                              'where:
                              '"\"t/qualification/ascent-evidence-store-test.ss\"@74.25-74.127"
                              'irritants:
                              __tmp7947))
                           __obj7849)))
                    (declare (not safe))
                    (raise __tmp7946))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%desc3475%_ _%desc3456%_)
                                               (_%where3487%_ _%where3459%_)
                                               (_%thunk3497%_ _%thunk3470%_))
                                          (declare (not safe))
                                          (std/test/base#__test-check!
                                           _%desc3475%_
                                           _%where3487%_
                                           _%thunk3497%_)))
                                      (let* ((_%restricted3507%_
                                              '(candidate
                                                (relation path 2)
                                                (rule (path ?x ?y)
                                                      (edge ?x ?y))
                                                (query path 0 1)
                                                (limits 16 128 128)))
                                             (_%desc3509%_
                                              '(field 'status
                                                      (reasoning-evidence-claim
                                                       store
                                                       snapshot
                                                       restricted
                                                       h
                                                       '(0 1))))
                                             (_%where3512%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@77.25-77.102")
                                             (_%thunk3523%_
                                              (lambda ()
                                                (let* ((_%expected3516%_
                                                        'unknown)
                                                       (_%result3519%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/candidate/evidence-store#reasoning-evidence-claim
                                                            _%store3279%_
                                                            _%snapshot3281%_
                                                            _%restricted3507%_
                                                            _%h3285%_
                                                            '(0 1))))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3516%_
                                                         _%result3519%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7948
                                                               (let ((__obj7850
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7949
                                (cons '(field 'status
                                              (reasoning-evidence-claim
                                               store
                                               snapshot
                                               restricted
                                               h
                                               '(0 1)))
                                      (cons 'test:
                                            (cons '(field 'status
                                                          (reasoning-evidence-claim
                                                           store
                                                           snapshot
                                                           restricted
                                                           h
                                                           '(0 1)))
                                                  (cons 'result:
                                                        (cons _%result3519%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3516%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7850
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@77.25-77.102"
                            'irritants:
                            __tmp7949))
                         __obj7850)))
                  (declare (not safe))
                  (raise __tmp7948))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3528%_ _%desc3509%_)
                                             (_%where3541%_ _%where3512%_)
                                             (_%thunk3551%_ _%thunk3523%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3528%_
                                         _%where3541%_
                                         _%thunk3551%_))))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj7851
                              '"generation, content and query changes refuse old handles"
                              __tmp7938))
                           __obj7851))
                        (_%tc3566%_ _%tc3561%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc3566%_))
                 (let* ((_%tc3847%_
                         (let ((__obj7857
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp7950
                                  (lambda ()
                                    (let* ((_%store3577%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__%
                                               '4
                                               '1
                                               '1)))
                                           (_%snapshot3579%_
                                            (gerbil-ascent/t/qualification/ascent-evidence-store-test#source__0))
                                           (_%answer3581%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                                               _%store3577%_
                                               _%snapshot3579%_
                                               gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate)))
                                           (_%partition3583%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-evidence-partition
                                               _%store3577%_
                                               _%snapshot3579%_
                                               gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
                                               '#f
                                               '((10 ((ready 0)))
                                                 (11 ((ready 1))))))))
                                      (let* ((_%desc3586%_
                                              '(field 'status answer))
                                             (_%where3589%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@82.23-82.45")
                                             (_%thunk3600%_
                                              (lambda ()
                                                (let* ((_%expected3593%_
                                                        'unknown)
                                                       (_%result3596%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         _%answer3581%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3593%_
                                                         _%result3596%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7951
                                                               (let ((__obj7852
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7952
                                (cons '(field 'status answer)
                                      (cons 'test:
                                            (cons '(field 'status answer)
                                                  (cons 'result:
                                                        (cons _%result3596%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3593%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7852
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@82.23-82.45"
                            'irritants:
                            __tmp7952))
                         __obj7852)))
                  (declare (not safe))
                  (raise __tmp7951))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3605%_ _%desc3586%_)
                                             (_%where3623%_ _%where3589%_)
                                             (_%thunk3633%_ _%thunk3600%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3605%_
                                         _%where3623%_
                                         _%thunk3633%_))
                                      (let* ((_%desc3643%_
                                              '(field 'entries
                                                      (reasoning-evidence-store-stats
                                                       store)))
                                             (_%where3646%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@83.23-83.78")
                                             (_%thunk3657%_
                                              (lambda ()
                                                (let* ((_%expected3650%_ '0)
                                                       (_%result3653%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'entries
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-stats
                                                            _%store3577%_)))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3650%_
                                                         _%result3653%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7953
                                                               (let ((__obj7853
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7954
                                (cons '(field 'entries
                                              (reasoning-evidence-store-stats
                                               store))
                                      (cons 'test:
                                            (cons '(field 'entries
                                                          (reasoning-evidence-store-stats
                                                           store))
                                                  (cons 'result:
                                                        (cons _%result3653%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3650%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7853
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@83.23-83.78"
                            'irritants:
                            __tmp7954))
                         __obj7853)))
                  (declare (not safe))
                  (raise __tmp7953))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3662%_ _%desc3643%_)
                                             (_%where3674%_ _%where3646%_)
                                             (_%thunk3684%_ _%thunk3657%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3662%_
                                         _%where3674%_
                                         _%thunk3684%_))
                                      (let* ((_%desc3694%_
                                              '(field 'pruned partition))
                                             (_%where3697%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@84.23-84.48")
                                             (_%thunk3708%_
                                              (lambda ()
                                                (let* ((_%expected3701%_ '())
                                                       (_%result3704%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'pruned
                                                         _%partition3583%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3701%_
                                                         _%result3704%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7955
                                                               (let ((__obj7854
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7956
                                (cons '(field 'pruned partition)
                                      (cons 'test:
                                            (cons '(field 'pruned partition)
                                                  (cons 'result:
                                                        (cons _%result3704%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3701%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7854
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@84.23-84.48"
                            'irritants:
                            __tmp7956))
                         __obj7854)))
                  (declare (not safe))
                  (raise __tmp7955))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3713%_ _%desc3694%_)
                                             (_%where3725%_ _%where3697%_)
                                             (_%thunk3735%_ _%thunk3708%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3713%_
                                         _%where3725%_
                                         _%thunk3735%_))
                                      (let* ((_%desc3745%_
                                              '(field 'unresolved partition))
                                             (_%where3748%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@85.23-85.52")
                                             (_%thunk3759%_
                                              (lambda ()
                                                (let* ((_%expected3752%_
                                                        '(10 11))
                                                       (_%result3755%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'unresolved
                                                         _%partition3583%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3752%_
                                                         _%result3755%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7957
                                                               (let ((__obj7855
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7958
                                (cons '(field 'unresolved partition)
                                      (cons 'test:
                                            (cons '(field 'unresolved
                                                          partition)
                                                  (cons 'result:
                                                        (cons _%result3755%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3752%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7855
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@85.23-85.52"
                            'irritants:
                            __tmp7958))
                         __obj7855)))
                  (declare (not safe))
                  (raise __tmp7957))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3764%_ _%desc3745%_)
                                             (_%where3776%_ _%where3748%_)
                                             (_%thunk3786%_ _%thunk3759%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3764%_
                                         _%where3776%_
                                         _%thunk3786%_))
                                      (let* ((_%desc3796%_
                                              '(field 'allowed partition))
                                             (_%where3799%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@86.23-86.49")
                                             (_%thunk3810%_
                                              (lambda ()
                                                (let* ((_%expected3803%_
                                                        '(10 11))
                                                       (_%result3806%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'allowed
                                                         _%partition3583%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3803%_
                                                         _%result3806%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7959
                                                               (let ((__obj7856
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7960
                                (cons '(field 'allowed partition)
                                      (cons 'test:
                                            (cons '(field 'allowed partition)
                                                  (cons 'result:
                                                        (cons _%result3806%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3803%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7856
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@86.23-86.49"
                            'irritants:
                            __tmp7960))
                         __obj7856)))
                  (declare (not safe))
                  (raise __tmp7959))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3815%_ _%desc3796%_)
                                             (_%where3827%_ _%where3799%_)
                                             (_%thunk3837%_ _%thunk3810%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3815%_
                                         _%where3827%_
                                         _%thunk3837%_))))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj7857
                              '"bounded evidence remains unresolved and is not cached as false"
                              __tmp7950))
                           __obj7857))
                        (_%tc3852%_ _%tc3847%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc3852%_))
                 (let* ((_%tc4295%_
                         (let ((__obj7866
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp7961
                                  (lambda ()
                                    (let* ((_%store3863%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__0)))
                                           (_%snapshot3865%_
                                            (gerbil-ascent/t/qualification/ascent-evidence-store-test#source__0))
                                           (_%answer3867%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                                               _%store3863%_
                                               _%snapshot3865%_
                                               gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate)))
                                           (_%h3869%_
                                            (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                             'handle
                                             _%answer3867%_))
                                           (_%a3871%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-evidence-fact
                                               _%store3863%_
                                               _%snapshot3865%_
                                               gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
                                               _%h3869%_
                                               '(path 0 2))))
                                           (_%b3873%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-evidence-fact
                                               _%store3863%_
                                               _%snapshot3865%_
                                               gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
                                               _%h3869%_
                                               '(path 0 2))))
                                           (_%partition3875%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-evidence-partition
                                               _%store3863%_
                                               _%snapshot3865%_
                                               gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
                                               _%h3869%_
                                               '((10 ((path 0 2) (missing 7)))
                                                 (11
                                                  ((path 4 3)
                                                   (missing 7))))))))
                                      (let* ((_%desc3878%_ '(field 'status a))
                                             (_%where3881%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@94.23-94.40")
                                             (_%thunk3892%_
                                              (lambda ()
                                                (let* ((_%expected3885%_
                                                        'verified)
                                                       (_%result3888%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         _%a3871%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3885%_
                                                         _%result3888%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7962
                                                               (let ((__obj7858
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7963
                                (cons '(field 'status a)
                                      (cons 'test:
                                            (cons '(field 'status a)
                                                  (cons 'result:
                                                        (cons _%result3888%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3885%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7858
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@94.23-94.40"
                            'irritants:
                            __tmp7963))
                         __obj7858)))
                  (declare (not safe))
                  (raise __tmp7962))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3897%_ _%desc3878%_)
                                             (_%where3918%_ _%where3881%_)
                                             (_%thunk3928%_ _%thunk3892%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3897%_
                                         _%where3918%_
                                         _%thunk3928%_))
                                      (let* ((_%desc3938%_
                                              '(pair? (field 'support-nodes
                                                             a)))
                                             (_%where3941%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@95.23-95.55")
                                             (_%thunk3952%_
                                              (lambda ()
                                                (let* ((_%expected3945%_ '#t)
                                                       (_%result3948%_
                                                        (pair? (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                                'support-nodes
                                                                _%a3871%_))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3945%_
                                                         _%result3948%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7964
                                                               (let ((__obj7859
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7965
                                (cons '(pair? (field 'support-nodes a))
                                      (cons 'test:
                                            (cons '(pair? (field 'support-nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         a))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons 'result:
                                                        (cons _%result3948%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3945%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7859
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@95.23-95.55"
                            'irritants:
                            __tmp7965))
                         __obj7859)))
                  (declare (not safe))
                  (raise __tmp7964))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3957%_ _%desc3938%_)
                                             (_%where3969%_ _%where3941%_)
                                             (_%thunk3979%_ _%thunk3952%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3957%_
                                         _%where3969%_
                                         _%thunk3979%_))
                                      (let* ((_%desc3989%_
                                              '(field 'support-nodes a))
                                             (_%where3992%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@96.23-96.47")
                                             (_%thunk4003%_
                                              (lambda ()
                                                (let* ((_%expected3996%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'support-nodes
                                                         _%b3873%_))
                                                       (_%result3999%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'support-nodes
                                                         _%a3871%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3996%_
                                                         _%result3999%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7966
                                                               (let ((__obj7860
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7967
                                (cons '(field 'support-nodes a)
                                      (cons 'test:
                                            (cons '(field 'support-nodes a)
                                                  (cons 'result:
                                                        (cons _%result3999%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3996%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7860
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@96.23-96.47"
                            'irritants:
                            __tmp7967))
                         __obj7860)))
                  (declare (not safe))
                  (raise __tmp7966))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4008%_ _%desc3989%_)
                                             (_%where4020%_ _%where3992%_)
                                             (_%thunk4030%_ _%thunk4003%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4008%_
                                         _%where4020%_
                                         _%thunk4030%_))
                                      (let* ((_%desc4040%_
                                              '(field 'status
                                                      (reasoning-evidence-fact
                                                       store
                                                       snapshot
                                                       candidate
                                                       h
                                                       '(missing 7))))
                                             (_%where4043%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@97.23-97.104")
                                             (_%thunk4054%_
                                              (lambda ()
                                                (let* ((_%expected4047%_
                                                        'unknown)
                                                       (_%result4050%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/candidate/evidence-store#reasoning-evidence-fact
                                                            _%store3863%_
                                                            _%snapshot3865%_
                                                            gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
                                                            _%h3869%_
                                                            '(missing 7))))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4047%_
                                                         _%result4050%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7968
                                                               (let ((__obj7861
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7969
                                (cons '(field 'status
                                              (reasoning-evidence-fact
                                               store
                                               snapshot
                                               candidate
                                               h
                                               '(missing 7)))
                                      (cons 'test:
                                            (cons '(field 'status
                                                          (reasoning-evidence-fact
                                                           store
                                                           snapshot
                                                           candidate
                                                           h
                                                           '(missing 7)))
                                                  (cons 'result:
                                                        (cons _%result4050%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4047%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7861
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@97.23-97.104"
                            'irritants:
                            __tmp7969))
                         __obj7861)))
                  (declare (not safe))
                  (raise __tmp7968))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4059%_ _%desc4040%_)
                                             (_%where4071%_ _%where4043%_)
                                             (_%thunk4081%_ _%thunk4054%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4059%_
                                         _%where4071%_
                                         _%thunk4081%_))
                                      (let* ((_%desc4091%_
                                              '(field 'allowed partition))
                                             (_%where4094%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@98.23-98.49")
                                             (_%thunk4105%_
                                              (lambda ()
                                                (let* ((_%expected4098%_ '(10))
                                                       (_%result4101%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'allowed
                                                         _%partition3875%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4098%_
                                                         _%result4101%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7970
                                                               (let ((__obj7862
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7971
                                (cons '(field 'allowed partition)
                                      (cons 'test:
                                            (cons '(field 'allowed partition)
                                                  (cons 'result:
                                                        (cons _%result4101%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4098%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7862
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@98.23-98.49"
                            'irritants:
                            __tmp7971))
                         __obj7862)))
                  (declare (not safe))
                  (raise __tmp7970))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4110%_ _%desc4091%_)
                                             (_%where4122%_ _%where4094%_)
                                             (_%thunk4132%_ _%thunk4105%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4110%_
                                         _%where4122%_
                                         _%thunk4132%_))
                                      (let* ((_%desc4142%_
                                              '(field 'unresolved partition))
                                             (_%where4145%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@99.23-99.52")
                                             (_%thunk4156%_
                                              (lambda ()
                                                (let* ((_%expected4149%_ '(10))
                                                       (_%result4152%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'unresolved
                                                         _%partition3875%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4149%_
                                                         _%result4152%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7972
                                                               (let ((__obj7863
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7973
                                (cons '(field 'unresolved partition)
                                      (cons 'test:
                                            (cons '(field 'unresolved
                                                          partition)
                                                  (cons 'result:
                                                        (cons _%result4152%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4149%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7863
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@99.23-99.52"
                            'irritants:
                            __tmp7973))
                         __obj7863)))
                  (declare (not safe))
                  (raise __tmp7972))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4161%_ _%desc4142%_)
                                             (_%where4173%_ _%where4145%_)
                                             (_%thunk4183%_ _%thunk4156%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4161%_
                                         _%where4173%_
                                         _%thunk4183%_))
                                      (let* ((_%desc4193%_
                                              '(field 'pruned partition))
                                             (_%where4196%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@100.23-100.48")
                                             (_%thunk4207%_
                                              (lambda ()
                                                (let* ((_%expected4200%_ '(11))
                                                       (_%result4203%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'pruned
                                                         _%partition3875%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4200%_
                                                         _%result4203%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7974
                                                               (let ((__obj7864
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7975
                                (cons '(field 'pruned partition)
                                      (cons 'test:
                                            (cons '(field 'pruned partition)
                                                  (cons 'result:
                                                        (cons _%result4203%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4200%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7864
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@100.23-100.48"
                            'irritants:
                            __tmp7975))
                         __obj7864)))
                  (declare (not safe))
                  (raise __tmp7974))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4212%_ _%desc4193%_)
                                             (_%where4224%_ _%where4196%_)
                                             (_%thunk4234%_ _%thunk4207%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4212%_
                                         _%where4224%_
                                         _%thunk4234%_))
                                      (let* ((_%desc4244%_
                                              '(field 'proof-builds
                                                      (reasoning-evidence-store-stats
                                                       store)))
                                             (_%where4247%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@101.23-101.83")
                                             (_%thunk4258%_
                                              (lambda ()
                                                (let* ((_%expected4251%_ '1)
                                                       (_%result4254%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'proof-builds
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-stats
                                                            _%store3863%_)))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4251%_
                                                         _%result4254%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7976
                                                               (let ((__obj7865
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7977
                                (cons '(field 'proof-builds
                                              (reasoning-evidence-store-stats
                                               store))
                                      (cons 'test:
                                            (cons '(field 'proof-builds
                                                          (reasoning-evidence-store-stats
                                                           store))
                                                  (cons 'result:
                                                        (cons _%result4254%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4251%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7865
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@101.23-101.83"
                            'irritants:
                            __tmp7977))
                         __obj7865)))
                  (declare (not safe))
                  (raise __tmp7976))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4263%_ _%desc4244%_)
                                             (_%where4275%_ _%where4247%_)
                                             (_%thunk4285%_ _%thunk4258%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4263%_
                                         _%where4275%_
                                         _%thunk4285%_))))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj7866
                              '"individual intermediate Facts and shared support nodes are reusable"
                              __tmp7961))
                           __obj7866))
                        (_%tc4300%_ _%tc4295%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc4300%_))
                 (let* ((_%tc4536%_
                         (let ((__obj7871
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp7978
                                  (lambda ()
                                    (let* ((_%store4311%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__0)))
                                           (_%snapshot4313%_
                                            (gerbil-ascent/t/qualification/ascent-evidence-store-test#source__0))
                                           (_%ground4315%_
                                            '(candidate
                                              (relation path 2)
                                              (rule (path ?x ?y) (edge ?x ?y))
                                              (query path 0 1)
                                              (limits 16 128 128)))
                                           (_%same4317%_
                                            '(candidate
                                              (relation path 2)
                                              (rule (path ?x ?y) (edge ?x ?y))
                                              (query path ?x ?x)
                                              (limits 16 128 128)))
                                           (_%a4319%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                                               _%store4311%_
                                               _%snapshot4313%_
                                               _%ground4315%_)))
                                           (_%b4321%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                                               _%store4311%_
                                               _%snapshot4313%_
                                               _%same4317%_))))
                                      (let* ((_%desc4324%_
                                              '(field 'status
                                                      (reasoning-evidence-claim
                                                       store
                                                       snapshot
                                                       ground
                                                       (field 'handle a)
                                                       '(0 1))))
                                             (_%where4327%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@110.23-110.112")
                                             (_%thunk4338%_
                                              (lambda ()
                                                (let* ((_%expected4331%_
                                                        'verified)
                                                       (_%result4334%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         (let ((__tmp7979
                                                                (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         'handle
                         _%a4319%_)))
                   (declare (not safe))
                   (gerbil-ascent/candidate/evidence-store#reasoning-evidence-claim
                    _%store4311%_
                    _%snapshot4313%_
                    _%ground4315%_
                    __tmp7979
                    '(0 1))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4331%_
                                                         _%result4334%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7980
                                                               (let ((__obj7867
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7981
                                (cons '(field 'status
                                              (reasoning-evidence-claim
                                               store
                                               snapshot
                                               ground
                                               (field 'handle a)
                                               '(0 1)))
                                      (cons 'test:
                                            (cons '(field 'status
                                                          (reasoning-evidence-claim
                                                           store
                                                           snapshot
                                                           ground
                                                           (field 'handle a)
                                                           '(0 1)))
                                                  (cons 'result:
                                                        (cons _%result4334%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4331%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7867
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@110.23-110.112"
                            'irritants:
                            __tmp7981))
                         __obj7867)))
                  (declare (not safe))
                  (raise __tmp7980))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4343%_ _%desc4324%_)
                                             (_%where4363%_ _%where4327%_)
                                             (_%thunk4373%_ _%thunk4338%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4343%_
                                         _%where4363%_
                                         _%thunk4373%_))
                                      (let* ((_%desc4383%_
                                              '(field 'status
                                                      (reasoning-evidence-claim
                                                       store
                                                       snapshot
                                                       ground
                                                       (field 'handle a)
                                                       '(1 2))))
                                             (_%where4386%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@111.23-111.112")
                                             (_%thunk4397%_
                                              (lambda ()
                                                (let* ((_%expected4390%_
                                                        'unknown)
                                                       (_%result4393%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         (let ((__tmp7982
                                                                (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         'handle
                         _%a4319%_)))
                   (declare (not safe))
                   (gerbil-ascent/candidate/evidence-store#reasoning-evidence-claim
                    _%store4311%_
                    _%snapshot4313%_
                    _%ground4315%_
                    __tmp7982
                    '(1 2))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4390%_
                                                         _%result4393%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7983
                                                               (let ((__obj7868
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7984
                                (cons '(field 'status
                                              (reasoning-evidence-claim
                                               store
                                               snapshot
                                               ground
                                               (field 'handle a)
                                               '(1 2)))
                                      (cons 'test:
                                            (cons '(field 'status
                                                          (reasoning-evidence-claim
                                                           store
                                                           snapshot
                                                           ground
                                                           (field 'handle a)
                                                           '(1 2)))
                                                  (cons 'result:
                                                        (cons _%result4393%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4390%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7868
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@111.23-111.112"
                            'irritants:
                            __tmp7984))
                         __obj7868)))
                  (declare (not safe))
                  (raise __tmp7983))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4402%_ _%desc4383%_)
                                             (_%where4414%_ _%where4386%_)
                                             (_%thunk4424%_ _%thunk4397%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4402%_
                                         _%where4414%_
                                         _%thunk4424%_))
                                      (let* ((_%desc4434%_
                                              '(field 'status
                                                      (reasoning-evidence-claim
                                                       store
                                                       snapshot
                                                       same
                                                       (field 'handle b)
                                                       '(0 1))))
                                             (_%where4437%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@112.23-112.110")
                                             (_%thunk4448%_
                                              (lambda ()
                                                (let* ((_%expected4441%_
                                                        'unknown)
                                                       (_%result4444%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         (let ((__tmp7985
                                                                (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         'handle
                         _%b4321%_)))
                   (declare (not safe))
                   (gerbil-ascent/candidate/evidence-store#reasoning-evidence-claim
                    _%store4311%_
                    _%snapshot4313%_
                    _%same4317%_
                    __tmp7985
                    '(0 1))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4441%_
                                                         _%result4444%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7986
                                                               (let ((__obj7869
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7987
                                (cons '(field 'status
                                              (reasoning-evidence-claim
                                               store
                                               snapshot
                                               same
                                               (field 'handle b)
                                               '(0 1)))
                                      (cons 'test:
                                            (cons '(field 'status
                                                          (reasoning-evidence-claim
                                                           store
                                                           snapshot
                                                           same
                                                           (field 'handle b)
                                                           '(0 1)))
                                                  (cons 'result:
                                                        (cons _%result4444%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4441%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7869
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@112.23-112.110"
                            'irritants:
                            __tmp7987))
                         __obj7869)))
                  (declare (not safe))
                  (raise __tmp7986))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4453%_ _%desc4434%_)
                                             (_%where4465%_ _%where4437%_)
                                             (_%thunk4475%_ _%thunk4448%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4453%_
                                         _%where4465%_
                                         _%thunk4475%_))
                                      (let* ((_%desc4485%_
                                              '(field 'status
                                                      (reasoning-evidence-claim
                                                       store
                                                       snapshot
                                                       same
                                                       (field 'handle b)
                                                       '(0 0))))
                                             (_%where4488%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@113.23-113.110")
                                             (_%thunk4499%_
                                              (lambda ()
                                                (let* ((_%expected4492%_
                                                        'finite-absent)
                                                       (_%result4495%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         (let ((__tmp7988
                                                                (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         'handle
                         _%b4321%_)))
                   (declare (not safe))
                   (gerbil-ascent/candidate/evidence-store#reasoning-evidence-claim
                    _%store4311%_
                    _%snapshot4313%_
                    _%same4317%_
                    __tmp7988
                    '(0 0))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4492%_
                                                         _%result4495%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7989
                                                               (let ((__obj7870
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7990
                                (cons '(field 'status
                                              (reasoning-evidence-claim
                                               store
                                               snapshot
                                               same
                                               (field 'handle b)
                                               '(0 0)))
                                      (cons 'test:
                                            (cons '(field 'status
                                                          (reasoning-evidence-claim
                                                           store
                                                           snapshot
                                                           same
                                                           (field 'handle b)
                                                           '(0 0)))
                                                  (cons 'result:
                                                        (cons _%result4495%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4492%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7870
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@113.23-113.110"
                            'irritants:
                            __tmp7990))
                         __obj7870)))
                  (declare (not safe))
                  (raise __tmp7989))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4504%_ _%desc4485%_)
                                             (_%where4516%_ _%where4488%_)
                                             (_%thunk4526%_ _%thunk4499%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4504%_
                                         _%where4516%_
                                         _%thunk4526%_))))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj7871
                              '"constant and repeated query variables cannot authorize out-of-query absence"
                              __tmp7978))
                           __obj7871))
                        (_%tc4541%_ _%tc4536%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc4541%_))
                 (let* ((_%tc4723%_
                         (let ((__obj7875
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp7991
                                  (lambda ()
                                    (let* ((_%store4552%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__0)))
                                           (_%snapshot4554%_
                                            (gerbil-ascent/t/qualification/ascent-evidence-store-test#source__0))
                                           (_%answer4556%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                                               _%store4552%_
                                               _%snapshot4554%_
                                               gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate)))
                                           (_%h4558%_
                                            (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                             'handle
                                             _%answer4556%_))
                                           (_%proof4560%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-evidence-certificate
                                               _%store4552%_
                                               _%snapshot4554%_
                                               gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
                                               _%h4558%_))))
                                      (set-car!
                                       (car (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                             'rows
                                             _%answer4556%_))
                                       '999)
                                      (set-car!
                                       (car (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                             'nodes
                                             _%proof4560%_))
                                       '999)
                                      (let* ((_%desc4563%_
                                              '(field 'rows
                                                      (reasoning-resolve-evidence
                                                       store
                                                       snapshot
                                                       candidate)))
                                             (_%where4566%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@120.23-120.90")
                                             (_%thunk4577%_
                                              (lambda ()
                                                (let* ((_%expected4570%_
                                                        '((0)))
                                                       (_%result4573%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'rows
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                                                            _%store4552%_
                                                            _%snapshot4554%_
                                                            gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate)))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4570%_
                                                         _%result4573%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7992
                                                               (let ((__obj7872
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7993
                                (cons '(field 'rows
                                              (reasoning-resolve-evidence
                                               store
                                               snapshot
                                               candidate))
                                      (cons 'test:
                                            (cons '(field 'rows
                                                          (reasoning-resolve-evidence
                                                           store
                                                           snapshot
                                                           candidate))
                                                  (cons 'result:
                                                        (cons _%result4573%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4570%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7872
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@120.23-120.90"
                            'irritants:
                            __tmp7993))
                         __obj7872)))
                  (declare (not safe))
                  (raise __tmp7992))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4582%_ _%desc4563%_)
                                             (_%where4601%_ _%where4566%_)
                                             (_%thunk4611%_ _%thunk4577%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4582%_
                                         _%where4601%_
                                         _%thunk4611%_))
                                      (let* ((_%desc4621%_
                                              '(field 'status
                                                      (reasoning-evidence-claim
                                                       store
                                                       snapshot
                                                       candidate
                                                       h
                                                       '(0))))
                                             (_%where4624%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@121.23-121.97")
                                             (_%thunk4635%_
                                              (lambda ()
                                                (let* ((_%expected4628%_
                                                        'verified)
                                                       (_%result4631%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/candidate/evidence-store#reasoning-evidence-claim
                                                            _%store4552%_
                                                            _%snapshot4554%_
                                                            gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
                                                            _%h4558%_
                                                            '(0))))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4628%_
                                                         _%result4631%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7994
                                                               (let ((__obj7873
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7995
                                (cons '(field 'status
                                              (reasoning-evidence-claim
                                               store
                                               snapshot
                                               candidate
                                               h
                                               '(0)))
                                      (cons 'test:
                                            (cons '(field 'status
                                                          (reasoning-evidence-claim
                                                           store
                                                           snapshot
                                                           candidate
                                                           h
                                                           '(0)))
                                                  (cons 'result:
                                                        (cons _%result4631%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4628%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7873
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@121.23-121.97"
                            'irritants:
                            __tmp7995))
                         __obj7873)))
                  (declare (not safe))
                  (raise __tmp7994))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4640%_ _%desc4621%_)
                                             (_%where4652%_ _%where4624%_)
                                             (_%thunk4662%_ _%thunk4635%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4640%_
                                         _%where4652%_
                                         _%thunk4662%_))
                                      (let* ((_%desc4672%_
                                              '(= (caar (field 'nodes
                                                               (reasoning-evidence-certificate
                                                                store
                                                                snapshot
                                                                candidate
                                                                h)))
                                                  999))
                                             (_%where4675%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@122.23-122.112")
                                             (_%thunk4686%_
                                              (lambda ()
                                                (let* ((_%expected4679%_ '#f)
                                                       (_%result4682%_
                                                        (= (caar (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          'nodes
                          (let ()
                            (declare (not safe))
                            (gerbil-ascent/candidate/evidence-store#reasoning-evidence-certificate
                             _%store4552%_
                             _%snapshot4554%_
                             gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
                             _%h4558%_))))
                   '999)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4679%_
                                                         _%result4682%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp7996
                                                               (let ((__obj7874
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp7997
                                (cons '(= (caar (field 'nodes
                                                       (reasoning-evidence-certificate
                                                        store
                                                        snapshot
                                                        candidate
                                                        h)))
                                          999)
                                      (cons 'test:
                                            (cons '(= (caar (field 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (reasoning-evidence-certificate
                            store
                            snapshot
                            candidate
                            h)))
              999)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons 'result:
                                                        (cons _%result4682%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4679%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7874
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@122.23-122.112"
                            'irritants:
                            __tmp7997))
                         __obj7874)))
                  (declare (not safe))
                  (raise __tmp7996))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4691%_ _%desc4672%_)
                                             (_%where4703%_ _%where4675%_)
                                             (_%thunk4713%_ _%thunk4686%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4691%_
                                         _%where4703%_
                                         _%thunk4713%_))))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj7875
                              '"published rows and certificates do not mutate the stored proof"
                              __tmp7991))
                           __obj7875))
                        (_%tc4728%_ _%tc4723%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc4728%_))
                 (let* ((_%tc4961%_
                         (let ((__obj7880
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp7998
                                  (lambda ()
                                    (let* ((_%store4739%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__1
                                               '1)))
                                           (_%snapshot4741%_
                                            (gerbil-ascent/t/qualification/ascent-evidence-store-test#source__0))
                                           (_%a4743%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                                               _%store4739%_
                                               _%snapshot4741%_
                                               gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate)))
                                           (_%h4745%_
                                            (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                             'handle
                                             _%a4743%_)))
                                      (let ((__tmp7999
                                             (gerbil-ascent/t/qualification/ascent-evidence-store-test#source__1
                                              '1)))
                                        (declare (not safe))
                                        (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                                         _%store4739%_
                                         __tmp7999
                                         gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate))
                                      (let* ((_%desc4748%_
                                              '(field 'status
                                                      (reasoning-evidence-certificate
                                                       store
                                                       snapshot
                                                       candidate
                                                       h)))
                                             (_%where4751%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@127.23-127.98")
                                             (_%thunk4762%_
                                              (lambda ()
                                                (let* ((_%expected4755%_
                                                        'unknown)
                                                       (_%result4758%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'status
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/candidate/evidence-store#reasoning-evidence-certificate
                                                            _%store4739%_
                                                            _%snapshot4741%_
                                                            gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate
                                                            _%h4745%_)))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4755%_
                                                         _%result4758%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8000
                                                               (let ((__obj7876
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8001
                                (cons '(field 'status
                                              (reasoning-evidence-certificate
                                               store
                                               snapshot
                                               candidate
                                               h))
                                      (cons 'test:
                                            (cons '(field 'status
                                                          (reasoning-evidence-certificate
                                                           store
                                                           snapshot
                                                           candidate
                                                           h))
                                                  (cons 'result:
                                                        (cons _%result4758%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4755%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7876
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@127.23-127.98"
                            'irritants:
                            __tmp8001))
                         __obj7876)))
                  (declare (not safe))
                  (raise __tmp8000))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4767%_ _%desc4748%_)
                                             (_%where4785%_ _%where4751%_)
                                             (_%thunk4795%_ _%thunk4762%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4767%_
                                         _%where4785%_
                                         _%thunk4795%_))
                                      (let* ((_%desc4805%_
                                              '(field 'evictions
                                                      (reasoning-evidence-store-stats
                                                       store)))
                                             (_%where4808%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@128.23-128.80")
                                             (_%thunk4819%_
                                              (lambda ()
                                                (let* ((_%expected4812%_ '1)
                                                       (_%result4815%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'evictions
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-stats
                                                            _%store4739%_)))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4812%_
                                                         _%result4815%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8002
                                                               (let ((__obj7877
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8003
                                (cons '(field 'evictions
                                              (reasoning-evidence-store-stats
                                               store))
                                      (cons 'test:
                                            (cons '(field 'evictions
                                                          (reasoning-evidence-store-stats
                                                           store))
                                                  (cons 'result:
                                                        (cons _%result4815%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4812%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7877
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@128.23-128.80"
                            'irritants:
                            __tmp8003))
                         __obj7877)))
                  (declare (not safe))
                  (raise __tmp8002))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4824%_ _%desc4805%_)
                                             (_%where4836%_ _%where4808%_)
                                             (_%thunk4846%_ _%thunk4819%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4824%_
                                         _%where4836%_
                                         _%thunk4846%_))
                                      (let ()
                                        (declare (not safe))
                                        (gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-clear!
                                         _%store4739%_))
                                      (let* ((_%desc4856%_
                                              '(field 'entries
                                                      (reasoning-evidence-store-stats
                                                       store)))
                                             (_%where4859%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@130.23-130.78")
                                             (_%thunk4870%_
                                              (lambda ()
                                                (let* ((_%expected4863%_ '0)
                                                       (_%result4866%_
                                                        (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                         'entries
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-stats
                                                            _%store4739%_)))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4863%_
                                                         _%result4866%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8004
                                                               (let ((__obj7878
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8005
                                (cons '(field 'entries
                                              (reasoning-evidence-store-stats
                                               store))
                                      (cons 'test:
                                            (cons '(field 'entries
                                                          (reasoning-evidence-store-stats
                                                           store))
                                                  (cons 'result:
                                                        (cons _%result4866%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4863%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7878
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@130.23-130.78"
                            'irritants:
                            __tmp8005))
                         __obj7878)))
                  (declare (not safe))
                  (raise __tmp8004))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4875%_ _%desc4856%_)
                                             (_%where4887%_ _%where4859%_)
                                             (_%thunk4897%_ _%thunk4870%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4875%_
                                         _%where4887%_
                                         _%thunk4897%_))
                                      (let* ((_%b4907%_
                                              (let ()
                                                (declare (not safe))
                                                (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                                                 _%store4739%_
                                                 _%snapshot4741%_
                                                 gerbil-ascent/t/qualification/ascent-evidence-store-test#candidate)))
                                             (_%desc4909%_
                                              '(> (field 'handle b) h))
                                             (_%where4912%_
                                              '"\"t/qualification/ascent-evidence-store-test.ss\"@132.25-132.48")
                                             (_%thunk4923%_
                                              (lambda ()
                                                (let* ((_%expected4916%_ '#t)
                                                       (_%result4919%_
                                                        (> (gerbil-ascent/t/qualification/ascent-evidence-store-test#field
                                                            'handle
                                                            _%b4907%_)
                                                           _%h4745%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4916%_
                                                         _%result4919%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8006
                                                               (let ((__obj7879
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8007
                                (cons '(> (field 'handle b) h)
                                      (cons 'test:
                                            (cons '(> (field 'handle b) h)
                                                  (cons 'result:
                                                        (cons _%result4919%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4916%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj7879
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-evidence-store-test.ss\"@132.25-132.48"
                            'irritants:
                            __tmp8007))
                         __obj7879)))
                  (declare (not safe))
                  (raise __tmp8006))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4928%_ _%desc4909%_)
                                             (_%where4941%_ _%where4912%_)
                                             (_%thunk4951%_ _%thunk4923%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4928%_
                                         _%where4941%_
                                         _%thunk4951%_))))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj7880
                              '"eviction and clearing refuse references without reusing handle IDs"
                              __tmp7998))
                           __obj7880))
                        (_%tc4966%_ _%tc4961%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc4966%_)))))
          (declare (not safe))
          (std/test/base#TestSuite:::init!
           __obj7881
           '"native evidence store and deterministic obligations"
           __tmp7885))
        __obj7881))))
