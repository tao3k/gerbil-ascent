(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/reasoning::timestamp 1791691039)
  (begin
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt::t
      (let ((__tmp39642 (list)) (__tmp39641 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'reasoning-receipt
         __tmp39642
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  query
                  rows
                  diagnostics
                  evidence
                  proof
                  nonmembership
                  stratified)
         __tmp39641
         '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t)))
    (define gerbil-ascent/candidate/reasoning#make-reasoning-receipt
      (lambda _%$args30225%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#reasoning-receipt::t
               _%$args30225%_)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-query
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'query)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-diagnostics
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'diagnostics)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-evidence
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-proof
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-nonmembership
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'nonmembership)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-stratified
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'stratified)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'query)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-diagnostics-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'diagnostics)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-evidence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-proof-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-nonmembership-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'nonmembership)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-stratified-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'stratified)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-query
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'query)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-diagnostics
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'diagnostics)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-evidence
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-proof
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-nonmembership
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'nonmembership)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-stratified
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'stratified)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'query)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-diagnostics-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'diagnostics)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-evidence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-proof-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-nonmembership-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'nonmembership)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-stratified-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'stratified)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence::t
      (let ((__tmp39644 (list)) (__tmp39643 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reasoning-evidence
         __tmp39644
         '(kind support reachable)
         __tmp39643
         '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t)))
    (define gerbil-ascent/candidate/reasoning#make-reasoning-evidence
      (lambda _%$args30222%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#reasoning-evidence::t
               _%$args30222%_)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'kind)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-support
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'support)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-reachable
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reachable)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'kind)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-support-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'support)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-reachable-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reachable)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'kind)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-support
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'support)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-reachable
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reachable)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'kind)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-support-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'support)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-reachable-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reachable)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
      (let ((__tmp39646 (list)) (__tmp39645 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'reasoning-stratified-evidence
         __tmp39646
         '(status finite proof work-budget)
         __tmp39645
         '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t)))
    (define gerbil-ascent/candidate/reasoning#make-reasoning-stratified-evidence
      (lambda _%$args30219%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
               _%$args30219%_)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-finite
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'finite)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-proof
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-finite-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'finite)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-proof-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-finite
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'finite)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-proof
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-finite-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'finite)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-proof-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/reasoning#copy-row
      (lambda (_%row30216%_ _%arity30217%_)
        (if (list? _%row30216%_)
            (if (= (let () (declare (not safe)) (##length _%row30216%_))
                   _%arity30217%_)
                (if (let ()
                      (declare (not safe))
                      (andmap__0
                       gerbil-ascent/candidate/program#scalar?
                       _%row30216%_))
                    (let () (declare (not safe)) (##map identity _%row30216%_))
                    '#f)
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/reasoning#digest-datum
      (lambda (_%datum30147%_)
        (let* ((_%bytes30167%_
                (let* ((_%bytes30151%_
                        (let ((__tmp39647
                               (call-with-output-string
                                '""
                                (lambda (_%port30149%_)
                                  (write _%datum30147%_ _%port30149%_)))))
                          (declare (not safe))
                          (##string->utf8 __tmp39647)))
                       (_%bytes30156%_ _%bytes30151%_))
                  (declare (not safe))
                  (std/crypto/digest#__sha256 _%bytes30156%_)))
               (_%start30170%_ '0)
               (_%end30173%_
                (let ()
                  (declare (not safe))
                  (##u8vector-length _%bytes30167%_)))
               (_%bytes30178%_ _%bytes30167%_))
          (if (and (let () (declare (not safe)) (##fx>= _%start30170%_ '0))
                   (let ((__tmp39648
                          (let ((__tmp39649
                                 (let ()
                                   (declare (not safe))
                                   (##u8vector-length _%bytes30178%_))))
                            (declare (not safe))
                            (##fxmax __tmp39649 '1))))
                     (declare (not safe))
                     (##fx< _%start30170%_ __tmp39648)))
              (let ((_%start30193%_ _%start30170%_))
                (if (let ((__tmp39650
                           (let ()
                             (declare (not safe))
                             (##u8vector-length _%bytes30178%_))))
                      (declare (not safe))
                      (##fx<= _%start30193%_ _%end30173%_ __tmp39650))
                    (let ((_%end30206%_ _%end30173%_))
                      (declare (not safe))
                      (std/encoding/hex#__hex-encode__%
                       _%bytes30178%_
                       _%start30193%_
                       _%end30206%_))
                    (begin
                      (raise-contract-violation-error
                       '"contract violation"
                       'context:
                       'gerbil-ascent/candidate/reasoning
                       'contract:
                       '(in-range-inclusive? start (u8vector-length bytes))
                       'value:
                       _%end30173%_)
                      '#!void)))
              (begin
                (raise-contract-violation-error
                 '"contract violation"
                 'context:
                 'gerbil-ascent/candidate/reasoning
                 'contract:
                 '(in-range? 0 (fxmax (u8vector-length bytes) 1))
                 'value:
                 _%start30170%_)
                '#!void)))))
    (define gerbil-ascent/candidate/reasoning#candidate-content-digest
      (lambda (_%candidate30145%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/datum#reasoning-bounded-data?
               _%candidate30145%_
               '16384
               '128))
            (gerbil-ascent/candidate/reasoning#digest-datum
             (list 'reasoning-candidate-v1 _%candidate30145%_))
            '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
      (lambda (_%receipt30139%_ _%snapshot30140%_ _%candidate30141%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%receipt30139%_
               'gerbil-ascent/candidate/reasoning#reasoning-receipt::t))
            (if (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                   _%snapshot30140%_))
                (if (equal? (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%receipt30139%_
                               '2
                               '#f
                               '#f))
                            (##structure-ref
                             _%snapshot30140%_
                             '1
                             gerbil-ascent/candidate/types#reasoning-snapshot::t
                             '#f))
                    (if (equal? (let ()
                                  (declare (not safe))
                                  (##unchecked-structure-ref
                                   _%receipt30139%_
                                   '3
                                   '#f
                                   '#f))
                                (##structure-ref
                                 _%snapshot30140%_
                                 '2
                                 gerbil-ascent/candidate/types#reasoning-snapshot::t
                                 '#f))
                        (if (equal? (let ()
                                      (declare (not safe))
                                      (##unchecked-structure-ref
                                       _%receipt30139%_
                                       '4
                                       '#f
                                       '#f))
                                    (##structure-ref
                                     _%snapshot30140%_
                                     '3
                                     gerbil-ascent/candidate/types#reasoning-snapshot::t
                                     '#f))
                            (let ((_%digest30143%_
                                   (gerbil-ascent/candidate/reasoning#candidate-content-digest
                                    _%candidate30141%_)))
                              (if _%digest30143%_
                                  (equal? _%digest30143%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%receipt30139%_
                                             '5
                                             '#f
                                             '#f)))
                                  '#f))
                            '#f)
                        '#f)
                    '#f)
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-source-snapshot
      (lambda (_%identity30105%_ _%generation30106%_ _%declarations30107%_)
        (if (and (or (symbol? _%identity30105%_) (string? _%identity30105%_))
                 (exact-integer? _%generation30106%_)
                 (<= '0 _%generation30106%_)
                 (let ()
                   (declare (not safe))
                   (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                    _%declarations30107%_
                    '131072
                    '128))
                 (list? _%declarations30107%_)
                 (<= (let ()
                       (declare (not safe))
                       (##length _%declarations30107%_))
                     gerbil-ascent/candidate/types#+max-relations+))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid reasoning source snapshot")))
        (let _%loop30112%_ ((_%remaining30114%_ _%declarations30107%_)
                            (_%seen30115%_ '())
                            (_%copied30116%_ '())
                            (_%facts30117%_ '0))
          (if (null? _%remaining30114%_)
              (let* ((_%relations30119%_ (reverse _%copied30116%_))
                     (__tmp39651
                      (let ()
                        (declare (not safe))
                        (gerbil-ascent/candidate/types#reasoning-snapshot-content-digest
                         _%identity30105%_
                         _%generation30106%_
                         _%relations30119%_))))
                (declare (not safe))
                (##structure
                 gerbil-ascent/candidate/types#reasoning-snapshot::t
                 _%identity30105%_
                 _%generation30106%_
                 __tmp39651
                 _%relations30119%_))
              (let ((_%entry30121%_ (car _%remaining30114%_)))
                (if (and (list? _%entry30121%_)
                         (= (let ()
                              (declare (not safe))
                              (##length _%entry30121%_))
                            '3)
                         (symbol? (car _%entry30121%_))
                         (exact-integer? (cadr _%entry30121%_))
                         (<= '0 (cadr _%entry30121%_))
                         (list? (caddr _%entry30121%_))
                         (not (memq (car _%entry30121%_) _%seen30115%_)))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"invalid or duplicate reasoning source declaration"
                             _%entry30121%_)))
                (let* ((_%name30123%_ (car _%entry30121%_))
                       (_%arity30125%_ (cadr _%entry30121%_))
                       (_%rows30127%_ (caddr _%entry30121%_))
                       (_%next-facts30129%_
                        (+ _%facts30117%_ (length _%rows30127%_))))
                  (if (> _%next-facts30129%_
                         gerbil-ascent/candidate/types#+max-input-facts+)
                      (let ()
                        (declare (not safe))
                        (error '"reasoning source snapshot exceeds input cap"))
                      '#!void)
                  (let ((_%owned30137%_
                         (map (lambda (_%row30132%_)
                                (let ((_%$e30134%_
                                       (gerbil-ascent/candidate/reasoning#copy-row
                                        _%row30132%_
                                        _%arity30125%_)))
                                  (if _%$e30134%_
                                      _%$e30134%_
                                      (let ()
                                        (declare (not safe))
                                        (error '"invalid reasoning source row"
                                               _%name30123%_
                                               _%row30132%_)))))
                              _%rows30127%_)))
                    (_%loop30112%_
                     (cdr _%remaining30114%_)
                     (cons _%name30123%_ _%seen30115%_)
                     (cons (list _%name30123%_ _%arity30125%_ _%owned30137%_)
                           _%copied30116%_)
                     _%next-facts30129%_))))))))
    (define gerbil-ascent/candidate/reasoning#query-row-matches?
      (lambda (_%terms30088%_ _%row30089%_)
        (let _%loop30091%_ ((_%terms30093%_ _%terms30088%_)
                            (_%values30094%_ _%row30089%_)
                            (_%bindings30095%_ '()))
          (if (null? _%terms30093%_)
              '#t
              (let ((_%term30097%_ (car _%terms30093%_))
                    (_%value30098%_ (car _%values30094%_)))
                (if (eq? _%term30097%_ '?_)
                    (_%loop30091%_
                     (cdr _%terms30093%_)
                     (cdr _%values30094%_)
                     _%bindings30095%_)
                    (if (let ()
                          (declare (not safe))
                          (gerbil-ascent/candidate/program#candidate-variable?
                           _%term30097%_))
                        (let ((_%binding30102%_
                               (assq _%term30097%_ _%bindings30095%_)))
                          (if _%binding30102%_
                              (if (equal? (cdr _%binding30102%_)
                                          _%value30098%_)
                                  (_%loop30091%_
                                   (cdr _%terms30093%_)
                                   (cdr _%values30094%_)
                                   _%bindings30095%_)
                                  '#f)
                              (_%loop30091%_
                               (cdr _%terms30093%_)
                               (cdr _%values30094%_)
                               (cons (cons _%term30097%_ _%value30098%_)
                                     _%bindings30095%_))))
                        (if (equal? _%term30097%_ _%value30098%_)
                            (_%loop30091%_
                             (cdr _%terms30093%_)
                             (cdr _%values30094%_)
                             _%bindings30095%_)
                            '#f))))))))
    (define gerbil-ascent/candidate/reasoning#candidate-graph-case?
      (lambda (_%snapshot30076%_ _%spec30077%_ _%query30078%_)
        (let ((_%source30080%_
               (##structure-ref
                _%snapshot30076%_
                '4
                gerbil-ascent/candidate/types#reasoning-snapshot::t
                '#f))
              (_%derived30081%_
               (##structure-ref
                _%spec30077%_
                '1
                gerbil-ascent/candidate/types#reasoning-candidate::t
                '#f))
              (_%rules30082%_
               (##structure-ref
                _%spec30077%_
                '3
                gerbil-ascent/candidate/types#reasoning-candidate::t
                '#f)))
          (if (= (length _%source30080%_) '1)
              (if (eq? (caar _%source30080%_) 'edge)
                  (if (= (cadar _%source30080%_) '2)
                      (if (equal? _%derived30081%_ '((path . 2)))
                          (if (= (length _%rules30082%_) '2)
                              (if (let ((_%forms30086%_
                                         (map (lambda (_%rule30084%_)
                                                (cons (vector-ref
                                                       _%rule30084%_
                                                       '0)
                                                      (vector-ref
                                                       _%rule30084%_
                                                       '1)))
                                              _%rules30082%_)))
                                    (and (let ()
                                           (declare (not safe))
                                           (##member
                                            '((path ?x ?y) (edge ?x ?y))
                                            _%forms30086%_))
                                         (let ()
                                           (declare (not safe))
                                           (##member
                                            '((path ?x ?z)
                                              (path ?x ?y)
                                              (edge ?y ?z))
                                            _%forms30086%_))))
                                  (if (= (length _%query30078%_) '3)
                                      (if (eq? (car _%query30078%_) 'path)
                                          (if (exact-integer?
                                               (cadr _%query30078%_))
                                              (exact-integer?
                                               (caddr _%query30078%_))
                                              '#f)
                                          '#f)
                                      '#f)
                                  '#f)
                              '#f)
                          '#f)
                      '#f)
                  '#f)
              '#f))))
    (define gerbil-ascent/candidate/reasoning#candidate-edge-records
      (lambda (_%snapshot30068%_ _%spec30069%_)
        (let ((__tmp39653
               (map (lambda (_%row30071%_ _%index30072%_)
                      (list 'source _%index30072%_ _%row30071%_))
                    (caddar (##structure-ref
                             _%snapshot30068%_
                             '4
                             gerbil-ascent/candidate/types#reasoning-snapshot::t
                             '#f))
                    (let ((__tmp39654
                           (length (caddar (##structure-ref
                                            _%snapshot30068%_
                                            '4
                                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                                            '#f)))))
                      (declare (not safe))
                      (##iota __tmp39654 '1))))
              (__tmp39652
               (map (lambda (_%fact30074%_)
                      (list 'candidate
                            (vector-ref _%fact30074%_ '2)
                            (vector-ref _%fact30074%_ '1)))
                    (##structure-ref
                     _%spec30069%_
                     '2
                     gerbil-ascent/candidate/types#reasoning-candidate::t
                     '#f))))
          (declare (not safe))
          (##append __tmp39653 __tmp39652))))
    (define gerbil-ascent/candidate/reasoning#candidate-edge-index
      (lambda (_%records30060%_)
        (let ((_%index30062%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (for-each
           (lambda (_%record30064%_)
             (let* ((_%origin30066%_ (caaddr _%record30064%_))
                    (__tmp39655
                     (cons _%record30064%_
                           (let ()
                             (declare (not safe))
                             (__hash-ref__%
                              _%index30062%_
                              _%origin30066%_
                              '())))))
               (declare (not safe))
               (__hash-put! _%index30062%_ _%origin30066%_ __tmp39655)))
           _%records30060%_)
          _%index30062%_)))
    (define gerbil-ascent/candidate/reasoning#candidate-graph-walk
      (lambda (_%records29985%_ _%origin29986%_ _%target29987%_)
        (let ((_%index29989%_
               (gerbil-ascent/candidate/reasoning#candidate-edge-index
                _%records29985%_))
              (_%visited29990%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value)))
              (_%reachable29991%_ (list _%origin29986%_))
              (_%support29992%_ '#f))
          (let ()
            (declare (not safe))
            (__hash-put! _%visited29990%_ _%origin29986%_ '#t))
          (let _%loop29994%_ ((_%front29996%_
                               (list (cons _%origin29986%_ '())))
                              (_%back29997%_ '()))
            (if (null? _%front29996%_)
                (if (null? _%back29997%_)
                    (values _%support29992%_
                            (let ()
                              (declare (not safe))
                              (##reverse _%reachable29991%_)))
                    (_%loop29994%_ (reverse _%back29997%_) '()))
                (let* ((_%state30001%_ (car _%front29996%_))
                       (_%node30003%_ (car _%state30001%_))
                       (_%path30005%_ (cdr _%state30001%_))
                       (_%next30007%_ _%back29997%_))
                  (let ((__tmp39657
                         (lambda (_%record30010%_)
                           (let* ((_%$%record3001130026%_ _%record30010%_)
                                  (_%$%E3001330029%_
                                   (lambda ()
                                     (let ()
                                       (declare (not safe))
                                       (error '"No clause matching"
                                              _%$%record3001130026%_
                                              '([_ _ [_ neighbor]])))
                                     '#!void))
                                  (_%$%K3001430036%_
                                   (lambda (_%neighbor30032%_)
                                     (let ((_%extended30034%_
                                            (cons _%record30010%_
                                                  _%path30005%_)))
                                       (if (if _%support29992%_
                                               '#f
                                               (equal? _%neighbor30032%_
                                                       _%target29987%_))
                                           (set! _%support29992%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##reverse
                                                    _%extended30034%_)))
                                           '#!void)
                                       (if (let ()
                                             (declare (not safe))
                                             (__hash-get
                                              _%visited29990%_
                                              _%neighbor30032%_))
                                           '#!void
                                           (begin
                                             (let ()
                                               (declare (not safe))
                                               (__hash-put!
                                                _%visited29990%_
                                                _%neighbor30032%_
                                                '#t))
                                             (set! _%reachable29991%_
                                                   (cons _%neighbor30032%_
                                                         _%reachable29991%_))
                                             (set! _%next30007%_
                                                   (cons (cons _%neighbor30032%_
                                                               _%extended30034%_)
                                                         _%next30007%_))))))))
                             (if (pair? _%$%record3001130026%_)
                                 (let ((_%$%tl3001630039%_
                                        (let ()
                                          (declare (not safe))
                                          (##cdr _%$%record3001130026%_))))
                                   (if (pair? _%$%tl3001630039%_)
                                       (let ((_%$%tl3001830042%_
                                              (let ()
                                                (declare (not safe))
                                                (##cdr _%$%tl3001630039%_))))
                                         (if (pair? _%$%tl3001830042%_)
                                             (let ((_%$%hd3001930045%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##car _%$%tl3001830042%_)))
                                                   (_%$%tl3002030047%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##cdr _%$%tl3001830042%_))))
                                               (if (pair? _%$%hd3001930045%_)
                                                   (let ((_%$%tl3002230050%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (##cdr _%$%hd3001930045%_))))
                                                     (if (pair? _%$%tl3002230050%_)
                                                         (let ((_%$%hd3002330053%_
                                                                (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##car _%$%tl3002230050%_)))
                       (_%$%tl3002430055%_
                        (let ()
                          (declare (not safe))
                          (##cdr _%$%tl3002230050%_))))
                   (let ((_%neighbor30058%_ _%$%hd3002330053%_))
                     (if (null? _%$%tl3002430055%_)
                         (if (null? _%$%tl3002030047%_)
                             (_%$%K3001430036%_ _%neighbor30058%_)
                             (_%$%E3001330029%_))
                         (_%$%E3001330029%_))))
                 (_%$%E3001330029%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (_%$%E3001330029%_)))
                                             (_%$%E3001330029%_)))
                                       (_%$%E3001330029%_)))
                                 (_%$%E3001330029%_)))))
                        (__tmp39656
                         (reverse (let ()
                                    (declare (not safe))
                                    (__hash-ref__%
                                     _%index29989%_
                                     _%node30003%_
                                     '())))))
                    (declare (not safe))
                    (##for-each __tmp39657 __tmp39656))
                  (_%loop29994%_ (cdr _%front29996%_) _%next30007%_)))))))
    (define gerbil-ascent/candidate/reasoning#candidate-evidence
      (lambda (_%snapshot29973%_ _%spec29974%_ _%query29975%_ _%rows29976%_)
        (if (gerbil-ascent/candidate/reasoning#candidate-graph-case?
             _%snapshot29973%_
             _%spec29974%_
             _%query29975%_)
            (let ((_g39658_
                   (gerbil-ascent/candidate/reasoning#candidate-graph-walk
                    (gerbil-ascent/candidate/reasoning#candidate-edge-records
                     _%snapshot29973%_
                     _%spec29974%_)
                    (cadr _%query29975%_)
                    (caddr _%query29975%_))))
              (begin
                (let ((_g39659_
                       (let ()
                         (declare (not safe))
                         (if (##values? _g39658_)
                             (##values-length _g39658_)
                             1))))
                  (if (not (let () (declare (not safe)) (##fx= _g39659_ 2)))
                      (error "Context expects 2 values" _g39659_)))
                (let ((_%support29978%_
                       (let () (declare (not safe)) (##values-ref _g39658_ 0)))
                      (_%reachable29979%_
                       (let ()
                         (declare (not safe))
                         (##values-ref _g39658_ 1))))
                  (if (and (pair? _%rows29976%_) _%support29978%_)
                      (let ()
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                         'witness
                         _%support29978%_
                         '()))
                      (if (and (null? _%rows29976%_)
                               (if _%support29978%_
                                   '#f
                                   (not (member (caddr _%query29975%_)
                                                _%reachable29979%_))))
                          (let ()
                            (declare (not safe))
                            (##structure
                             gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                             'cut
                             '()
                             _%reachable29979%_))
                          (if (and (null? _%rows29976%_)
                                   (if _%support29978%_
                                       '#f
                                       (equal? (cadr _%query29975%_)
                                               (caddr _%query29975%_))))
                              (let ()
                                (declare (not safe))
                                (##structure
                                 gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                                 'unsupported
                                 '()
                                 '()))
                              '#f))))))
            (let ()
              (declare (not safe))
              (##structure
               gerbil-ascent/candidate/reasoning#reasoning-evidence::t
               'unsupported
               '()
               '())))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
      (lambda (_%snapshot29907%_
               _%digest29908%_
               _%status29909%_
               _%query29910%_
               _%rows29911%_
               _%diagnostics29912%_
               _%evidence29913%_
               _%proof29914%_
               _%nonmembership29915%_
               _%stratified29916%_)
        (let ((__tmp39676
               (##structure-ref
                _%snapshot29907%_
                '1
                gerbil-ascent/candidate/types#reasoning-snapshot::t
                '#f))
              (__tmp39675
               (##structure-ref
                _%snapshot29907%_
                '2
                gerbil-ascent/candidate/types#reasoning-snapshot::t
                '#f))
              (__tmp39674
               (##structure-ref
                _%snapshot29907%_
                '3
                gerbil-ascent/candidate/types#reasoning-snapshot::t
                '#f))
              (__tmp39673
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/datum#candidate-copy-pairs
                  _%query29910%_)))
              (__tmp39672
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/datum#candidate-copy-pairs
                  _%rows29911%_)))
              (__tmp39666
               (map (lambda (_%diagnostic29918%_)
                      (let ((__tmp39671
                             (##structure-ref
                              _%diagnostic29918%_
                              '1
                              gerbil-ascent/candidate/types#reasoning-diagnostic::t
                              '#f))
                            (__tmp39669
                             (let ((__tmp39670
                                    (##structure-ref
                                     _%diagnostic29918%_
                                     '2
                                     gerbil-ascent/candidate/types#reasoning-diagnostic::t
                                     '#f)))
                               (declare (not safe))
                               (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                __tmp39670)))
                            (__tmp39667
                             (let ((__tmp39668
                                    (##structure-ref
                                     _%diagnostic29918%_
                                     '3
                                     gerbil-ascent/candidate/types#reasoning-diagnostic::t
                                     '#f)))
                               (declare (not safe))
                               (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                __tmp39668))))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/types#reasoning-diagnostic::t
                         __tmp39671
                         __tmp39669
                         __tmp39667)))
                    _%diagnostics29912%_))
              (__tmp39660
               (if _%evidence29913%_
                   (let ((__tmp39665
                          (##structure-ref
                           _%evidence29913%_
                           '1
                           gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                           '#f))
                         (__tmp39663
                          (let ((__tmp39664
                                 (##structure-ref
                                  _%evidence29913%_
                                  '2
                                  gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                                  '#f)))
                            (declare (not safe))
                            (gerbil-ascent/candidate/datum#candidate-copy-pairs
                             __tmp39664)))
                         (__tmp39661
                          (let ((__tmp39662
                                 (##structure-ref
                                  _%evidence29913%_
                                  '3
                                  gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                                  '#f)))
                            (declare (not safe))
                            (gerbil-ascent/candidate/datum#candidate-copy-pairs
                             __tmp39662))))
                     (declare (not safe))
                     (##structure
                      gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                      __tmp39665
                      __tmp39663
                      __tmp39661))
                   '#f)))
          (declare (not safe))
          (##structure
           gerbil-ascent/candidate/reasoning#reasoning-receipt::t
           _%status29909%_
           __tmp39676
           __tmp39675
           __tmp39674
           _%digest29908%_
           __tmp39673
           __tmp39672
           __tmp39666
           __tmp39660
           _%proof29914%_
           _%nonmembership29915%_
           _%stratified29916%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
      (lambda (_%snapshot29923%_
               _%digest29924%_
               _%status29925%_
               _%query29926%_
               _%rows29927%_
               _%diagnostics29928%_
               _%evidence29929%_)
        (let* ((_%proof29931%_ '#f)
               (_%nonmembership29933%_ '#f)
               (_%stratified29935%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
           _%snapshot29923%_
           _%digest29924%_
           _%status29925%_
           _%query29926%_
           _%rows29927%_
           _%diagnostics29928%_
           _%evidence29929%_
           _%proof29931%_
           _%nonmembership29933%_
           _%stratified29935%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for__1
      (lambda (_%snapshot29937%_
               _%digest29938%_
               _%status29939%_
               _%query29940%_
               _%rows29941%_
               _%diagnostics29942%_
               _%evidence29943%_
               _%proof29944%_)
        (let* ((_%nonmembership29946%_ '#f) (_%stratified29948%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
           _%snapshot29937%_
           _%digest29938%_
           _%status29939%_
           _%query29940%_
           _%rows29941%_
           _%diagnostics29942%_
           _%evidence29943%_
           _%proof29944%_
           _%nonmembership29946%_
           _%stratified29948%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for__2
      (lambda (_%snapshot29950%_
               _%digest29951%_
               _%status29952%_
               _%query29953%_
               _%rows29954%_
               _%diagnostics29955%_
               _%evidence29956%_
               _%proof29957%_
               _%nonmembership29958%_)
        (let ((_%stratified29960%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
           _%snapshot29950%_
           _%digest29951%_
           _%status29952%_
           _%query29953%_
           _%rows29954%_
           _%diagnostics29955%_
           _%evidence29956%_
           _%proof29957%_
           _%nonmembership29958%_
           _%stratified29960%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for
      (lambda _g39677_
        (let ((_g39678_ (let () (declare (not safe)) (##length _g39677_))))
          (cond ((let () (declare (not safe)) (##fx= _g39678_ 7))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
                        _g39677_))
                ((let () (declare (not safe)) (##fx= _g39678_ 8))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-receipt-for__1
                        _g39677_))
                ((let () (declare (not safe)) (##fx= _g39678_ 9))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-receipt-for__2
                        _g39677_))
                ((let () (declare (not safe)) (##fx= _g39678_ 10))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
                        _g39677_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/candidate/reasoning#reasoning-receipt-for
                  _g39677_))))))
    (define gerbil-ascent/candidate/reasoning#captured-stage::t
      (let ((__tmp39680 (list)) (__tmp39679 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#captured-stage::t
         'captured-stage
         __tmp39680
         '(ok? value)
         __tmp39679
         '#f)))
    (define gerbil-ascent/candidate/reasoning#captured-stage?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#captured-stage::t)))
    (define gerbil-ascent/candidate/reasoning#make-captured-stage
      (lambda _%$args29903%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#captured-stage::t
               _%$args29903%_)))
    (define gerbil-ascent/candidate/reasoning#captured-stage-ok?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'ok?)))
    (define gerbil-ascent/candidate/reasoning#captured-stage-value
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'value)))
    (define gerbil-ascent/candidate/reasoning#captured-stage-ok?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'ok?)))
    (define gerbil-ascent/candidate/reasoning#captured-stage-value-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'value)))
    (define gerbil-ascent/candidate/reasoning#&captured-stage-ok?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'ok?)))
    (define gerbil-ascent/candidate/reasoning#&captured-stage-value
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'value)))
    (define gerbil-ascent/candidate/reasoning#&captured-stage-ok?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'ok?)))
    (define gerbil-ascent/candidate/reasoning#&captured-stage-value-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'value)))
    (define gerbil-ascent/candidate/reasoning#capture
      (lambda (_%thunk29898%_)
        (let ((__tmp39683
               (lambda (_%failure29900%_)
                 (let ()
                   (declare (not safe))
                   (##structure
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#f
                    _%failure29900%_))))
              (__tmp39681
               (lambda ()
                 (let ((__tmp39682 (_%thunk29898%_)))
                   (declare (not safe))
                   (##structure
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#t
                    __tmp39682)))))
          (declare (not safe))
          (__with-catch __tmp39683 __tmp39681))))
    (define gerbil-ascent/candidate/reasoning#failure-detail
      (lambda (_%failure29894%_)
        (let ((_%message29896%_
               (let ()
                 (declare (not safe))
                 (std/error#exception->string _%failure29894%_))))
          (if (> (let ()
                   (declare (not safe))
                   (##string-length _%message29896%_))
                 '240)
              (substring _%message29896%_ '0 '240)
              _%message29896%_))))
    (define gerbil-ascent/candidate/reasoning#produce-receipt-stratified
      (lambda (_%snapshot29883%_
               _%spec29884%_
               _%digest29885%_
               _%rows29886%_
               _%work-budget29887%_)
        (let ((_%finite29889%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/finite-evidence#candidate-finite-evidence
                  _%snapshot29883%_
                  _%spec29884%_
                  _%digest29885%_
                  'complete
                  _%rows29886%_
                  _%work-budget29887%_))))
          (if (eq? (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref _%finite29889%_ '1 '#f '#f))
                   'complete)
              (let ((_g39684_
                     (let ()
                       (declare (not safe))
                       (gerbil-ascent/candidate/stratified-producer#candidate-produce-stratified-proof
                        _%snapshot29883%_
                        _%spec29884%_
                        _%digest29885%_
                        'complete
                        _%rows29886%_
                        _%finite29889%_
                        _%work-budget29887%_
                        _%work-budget29887%_))))
                (begin
                  (let ((_g39685_
                         (let ()
                           (declare (not safe))
                           (if (##values? _g39684_)
                               (##values-length _g39684_)
                               1))))
                    (if (not (let () (declare (not safe)) (##fx= _g39685_ 2)))
                        (error "Context expects 2 values" _g39685_)))
                  (let ((_%status29891%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g39684_ 0)))
                        (_%proof29892%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g39684_ 1))))
                    (let ()
                      (declare (not safe))
                      (##structure
                       gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                       _%status29891%_
                       _%finite29889%_
                       _%proof29892%_
                       _%work-budget29887%_)))))
              (let ((__tmp39686
                     (let ()
                       (declare (not safe))
                       (##unchecked-structure-ref
                        _%finite29889%_
                        '1
                        '#f
                        '#f))))
                (declare (not safe))
                (##structure
                 gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                 __tmp39686
                 _%finite29889%_
                 '()
                 _%work-budget29887%_))))))
    (define gerbil-ascent/candidate/reasoning#reasoning-verify-finite-receipt
      (lambda (_%receipt29875%_
               _%snapshot29876%_
               _%candidate29877%_
               _%work-budget29878%_)
        (if (and (exact-integer? _%work-budget29878%_)
                 (> _%work-budget29878%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"finite receipt verification needs positive work budget"
                     _%work-budget29878%_)))
        (if (and (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                  _%receipt29875%_
                  _%snapshot29876%_
                  _%candidate29877%_)
                 (eq? (##structure-ref
                       _%receipt29875%_
                       '1
                       gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                       '#f)
                      'complete)
                 (let ((__tmp39687
                        (##structure-ref
                         _%receipt29875%_
                         '12
                         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                         '#f)))
                   (declare (not safe))
                   (##structure-instance-of?
                    __tmp39687
                    'gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t)))
            (let ((_%checked29881%_
                   (gerbil-ascent/candidate/reasoning#capture
                    (lambda ()
                      (let ((__tmp39691
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program#candidate-inspect
                                _%snapshot29876%_
                                _%candidate29877%_)))
                            (__tmp39690
                             (##structure-ref
                              _%receipt29875%_
                              '5
                              gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                              '#f))
                            (__tmp39689
                             (##structure-ref
                              _%receipt29875%_
                              '7
                              gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                              '#f))
                            (__tmp39688
                             (##structure-ref
                              (##structure-ref
                               _%receipt29875%_
                               '12
                               gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                               '#f)
                              '2
                              gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                              '#f)))
                        (declare (not safe))
                        (gerbil-ascent/candidate/finite-evidence#candidate-verify-finite-evidence
                         _%snapshot29876%_
                         __tmp39691
                         __tmp39690
                         'complete
                         __tmp39689
                         __tmp39688
                         _%work-budget29878%_))))))
              (if (##structure-ref
                   _%checked29881%_
                   '1
                   gerbil-ascent/candidate/reasoning#captured-stage::t
                   '#f)
                  (##structure-ref
                   _%checked29881%_
                   '2
                   gerbil-ascent/candidate/reasoning#captured-stage::t
                   '#f)
                  'invalid))
            'invalid)))
    (define gerbil-ascent/candidate/reasoning#reasoning-verify-stratified-receipt
      (lambda (_%receipt29862%_
               _%snapshot29863%_
               _%candidate29864%_
               _%work-budget29865%_)
        (if (and (exact-integer? _%work-budget29865%_)
                 (> _%work-budget29865%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"stratified receipt verification needs positive work budget"
                     _%work-budget29865%_)))
        (if (and (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                  _%receipt29862%_
                  _%snapshot29863%_
                  _%candidate29864%_)
                 (eq? (##structure-ref
                       _%receipt29862%_
                       '1
                       gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                       '#f)
                      'complete)
                 (let ((__tmp39692
                        (##structure-ref
                         _%receipt29862%_
                         '12
                         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                         '#f)))
                   (declare (not safe))
                   (##structure-instance-of?
                    __tmp39692
                    'gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t)))
            (let* ((_%evidence29867%_
                    (##structure-ref
                     _%receipt29862%_
                     '12
                     gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                     '#f))
                   (_%$e29869%_
                    (##structure-ref
                     _%evidence29867%_
                     '1
                     gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                     '#f)))
              (if (eq? 'complete _%$e29869%_)
                  (let ((_%checked29873%_
                         (gerbil-ascent/candidate/reasoning#capture
                          (lambda ()
                            (let ((__tmp39697
                                   (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/program#candidate-inspect
                                      _%snapshot29863%_
                                      _%candidate29864%_)))
                                  (__tmp39696
                                   (##structure-ref
                                    _%receipt29862%_
                                    '5
                                    gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                    '#f))
                                  (__tmp39695
                                   (##structure-ref
                                    _%receipt29862%_
                                    '7
                                    gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                    '#f))
                                  (__tmp39694
                                   (##structure-ref
                                    _%evidence29867%_
                                    '2
                                    gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                                    '#f))
                                  (__tmp39693
                                   (##structure-ref
                                    _%evidence29867%_
                                    '3
                                    gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                                    '#f)))
                              (declare (not safe))
                              (gerbil-ascent/candidate/stratified-proof#candidate-verify-stratified-proof
                               _%snapshot29863%_
                               __tmp39697
                               __tmp39696
                               'complete
                               __tmp39695
                               __tmp39694
                               _%work-budget29865%_
                               __tmp39693
                               _%work-budget29865%_))))))
                    (if (##structure-ref
                         _%checked29873%_
                         '1
                         gerbil-ascent/candidate/reasoning#captured-stage::t
                         '#f)
                        (##structure-ref
                         _%checked29873%_
                         '2
                         gerbil-ascent/candidate/reasoning#captured-stage::t
                         '#f)
                        'invalid))
                  (if (eq? 'bounded _%$e29869%_)
                      'bounded
                      (if (eq? 'unsupported _%$e29869%_)
                          'unsupported
                          'invalid))))
            'invalid)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation::t
      (let ((__tmp39699 (list)) (__tmp39698 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#attempt-observation::t
         'attempt-observation
         __tmp39699
         '(rows evidence)
         __tmp39698
         '#f)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#attempt-observation::t)))
    (define gerbil-ascent/candidate/reasoning#make-attempt-observation
      (lambda _%$args29859%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#attempt-observation::t
               _%$args29859%_)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation-evidence
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation-evidence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#&attempt-observation-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#&attempt-observation-evidence
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#&attempt-observation-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#&attempt-observation-evidence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#attempt-failure
      (lambda (_%snapshot29851%_
               _%digest29852%_
               _%status29853%_
               _%query29854%_
               _%code29855%_
               _%path29856%_
               _%failure29857%_)
        (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
         _%snapshot29851%_
         _%digest29852%_
         _%status29853%_
         _%query29854%_
         '()
         (list (let ((__tmp39700
                      (gerbil-ascent/candidate/reasoning#failure-detail
                       _%failure29857%_)))
                 (declare (not safe))
                 (##structure
                  gerbil-ascent/candidate/types#reasoning-diagnostic::t
                  _%code29855%_
                  _%path29856%_
                  __tmp39700)))
         '#f)))
    (define gerbil-ascent/candidate/reasoning#attempt-proof-diagnostics
      (lambda (_%result29845%_ _%code29846%_)
        (if (or (not _%result29845%_)
                (##structure-ref
                 _%result29845%_
                 '1
                 gerbil-ascent/candidate/reasoning#captured-stage::t
                 '#f))
            '()
            (list (let ((__tmp39701
                         (gerbil-ascent/candidate/reasoning#failure-detail
                          (##structure-ref
                           _%result29845%_
                           '2
                           gerbil-ascent/candidate/reasoning#captured-stage::t
                           '#f))))
                    (declare (not safe))
                    (##structure
                     gerbil-ascent/candidate/types#reasoning-diagnostic::t
                     _%code29846%_
                     '(explain)
                     __tmp39701))))))
    (define gerbil-ascent/candidate/reasoning#attempt-proof-value
      (lambda (_%result29843%_)
        (if _%result29843%_
            (if (##structure-ref
                 _%result29843%_
                 '1
                 gerbil-ascent/candidate/reasoning#captured-stage::t
                 '#f)
                (##structure-ref
                 _%result29843%_
                 '2
                 gerbil-ascent/candidate/reasoning#captured-stage::t
                 '#f)
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/reasoning#attempt-publish
      (lambda (_%snapshot29797%_
               _%spec29798%_
               _%digest29799%_
               _%query29800%_
               _%observation29801%_
               _%proof-steps29802%_
               _%stratified-steps29803%_)
        (let* ((_%$%observation2980429811%_ _%observation29801%_)
               (_%$%E2980629814%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%observation2980429811%_
                           '((attempt-observation rows evidence))))
                  '#!void))
               (_%$%K2980729830%_
                (lambda (_%evidence29817%_ _%rows29818%_)
                  (let* ((_%proof29821%_
                          (gerbil-ascent/candidate/reasoning#capture
                           (lambda ()
                             (if _%proof-steps29802%_
                                 (let ()
                                   (declare (not safe))
                                   (gerbil-ascent/candidate/provenance#candidate-positive-proof
                                    _%snapshot29797%_
                                    _%spec29798%_
                                    _%digest29799%_
                                    'complete
                                    _%rows29818%_
                                    _%proof-steps29802%_))
                                 '#f))))
                         (_%absence29824%_
                          (gerbil-ascent/candidate/reasoning#capture
                           (lambda ()
                             (if _%proof-steps29802%_
                                 (let ()
                                   (declare (not safe))
                                   (gerbil-ascent/candidate/nonmembership#candidate-positive-nonmembership
                                    _%snapshot29797%_
                                    _%spec29798%_
                                    _%digest29799%_
                                    'complete
                                    _%rows29818%_
                                    _%proof-steps29802%_))
                                 '#f))))
                         (_%stratified29827%_
                          (if _%stratified-steps29803%_
                              (gerbil-ascent/candidate/reasoning#capture
                               (lambda ()
                                 (gerbil-ascent/candidate/reasoning#produce-receipt-stratified
                                  _%snapshot29797%_
                                  _%spec29798%_
                                  _%digest29799%_
                                  _%rows29818%_
                                  _%stratified-steps29803%_)))
                              '#f)))
                    (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
                     _%snapshot29797%_
                     _%digest29799%_
                     'complete
                     _%query29800%_
                     _%rows29818%_
                     (let ((__tmp39704
                            (gerbil-ascent/candidate/reasoning#attempt-proof-diagnostics
                             _%proof29821%_
                             'proof-failed))
                           (__tmp39703
                            (gerbil-ascent/candidate/reasoning#attempt-proof-diagnostics
                             _%absence29824%_
                             'nonmembership-failed))
                           (__tmp39702
                            (gerbil-ascent/candidate/reasoning#attempt-proof-diagnostics
                             _%stratified29827%_
                             'stratified-evidence-failed)))
                       (declare (not safe))
                       (##append __tmp39704 __tmp39703 __tmp39702))
                     _%evidence29817%_
                     (gerbil-ascent/candidate/reasoning#attempt-proof-value
                      _%proof29821%_)
                     (gerbil-ascent/candidate/reasoning#attempt-proof-value
                      _%absence29824%_)
                     (gerbil-ascent/candidate/reasoning#attempt-proof-value
                      _%stratified29827%_))))))
          (if (let ()
                (declare (not safe))
                (##structure-instance-of?
                 _%$%observation2980429811%_
                 'gerbil-ascent/candidate/reasoning#attempt-observation::t))
              (let* ((_%$%e2980829833%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%observation2980429811%_
                         '1
                         '#f
                         '#f)))
                     (_%rows29836%_ _%$%e2980829833%_)
                     (_%$%e2980929838%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%observation2980429811%_
                         '2
                         '#f
                         '#f)))
                     (_%evidence29841%_ _%$%e2980929838%_))
                (_%$%K2980729830%_ _%evidence29841%_ _%rows29836%_))
              (_%$%E2980629814%_)))))
    (define gerbil-ascent/candidate/reasoning#attempt-observe
      (lambda (_%snapshot29774%_
               _%spec29775%_
               _%digest29776%_
               _%query29777%_
               _%solved29778%_
               _%proof-steps29779%_
               _%stratified-steps29780%_)
        (let ((_%observed29792%_
               (gerbil-ascent/candidate/reasoning#capture
                (lambda ()
                  (let* ((_%all29783%_
                          (let ((__tmp39705 (car _%query29777%_)))
                            (declare (not safe))
                            (gerbil-ascent/program/scheme-query#relational-query-name
                             _%solved29778%_
                             __tmp39705)))
                         (_%rows29789%_
                          (let ((__tmp39706
                                 (lambda (_%$%g2978429786%_)
                                   (gerbil-ascent/candidate/reasoning#query-row-matches?
                                    (cdr _%query29777%_)
                                    _%$%g2978429786%_))))
                            (declare (not safe))
                            (##filter __tmp39706 _%all29783%_)))
                         (__tmp39707
                          (gerbil-ascent/candidate/reasoning#candidate-evidence
                           _%snapshot29774%_
                           _%spec29775%_
                           _%query29777%_
                           _%rows29789%_)))
                    (declare (not safe))
                    (##structure
                     gerbil-ascent/candidate/reasoning#attempt-observation::t
                     _%rows29789%_
                     __tmp39707))))))
          (if (##structure-ref
               _%observed29792%_
               '1
               gerbil-ascent/candidate/reasoning#captured-stage::t
               '#f)
              (if (##structure-ref
                   (##structure-ref
                    _%observed29792%_
                    '2
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#f)
                   '2
                   gerbil-ascent/candidate/reasoning#attempt-observation::t
                   '#f)
                  (gerbil-ascent/candidate/reasoning#attempt-publish
                   _%snapshot29774%_
                   _%spec29775%_
                   _%digest29776%_
                   _%query29777%_
                   (##structure-ref
                    _%observed29792%_
                    '2
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#f)
                   _%proof-steps29779%_
                   _%stratified-steps29780%_)
                  (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
                   _%snapshot29774%_
                   _%digest29776%_
                   'unknown
                   _%query29777%_
                   '()
                   (list (let ()
                           (declare (not safe))
                           (##structure
                            gerbil-ascent/candidate/types#reasoning-diagnostic::t
                            'evidence-mismatch
                            '(explain)
                            _%query29777%_)))
                   '#f))
              (gerbil-ascent/candidate/reasoning#attempt-failure
               _%snapshot29774%_
               _%digest29776%_
               'unknown
               _%query29777%_
               'query-failed
               '(query)
               (##structure-ref
                _%observed29792%_
                '2
                gerbil-ascent/candidate/reasoning#captured-stage::t
                '#f))))))
    (define gerbil-ascent/candidate/reasoning#attempt-solve
      (lambda (_%snapshot29761%_
               _%spec29762%_
               _%digest29763%_
               _%query29764%_
               _%report29765%_
               _%proof-steps29766%_
               _%stratified-steps29767%_)
        (let ((_%diagnostic29769%_
               (##structure-ref
                _%report29765%_
                '2
                gerbil-ascent/program/scheme-admit#relational-admission-report::t
                '#f)))
          (if _%diagnostic29769%_
              (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
               _%snapshot29761%_
               _%digest29763%_
               'rejected
               _%query29764%_
               '()
               (list (let ((__tmp39711
                            (##structure-ref
                             _%diagnostic29769%_
                             '1
                             gerbil-ascent/program/scheme-admit#relational-diagnostic::t
                             '#f))
                           (__tmp39709
                            (let ((__tmp39710
                                   (##structure-ref
                                    _%diagnostic29769%_
                                    '2
                                    gerbil-ascent/program/scheme-admit#relational-diagnostic::t
                                    '#f)))
                              (declare (not safe))
                              (gerbil-ascent/candidate/program#candidate-planner-path
                               _%spec29762%_
                               __tmp39710)))
                           (__tmp39708
                            (##structure-ref
                             _%diagnostic29769%_
                             '3
                             gerbil-ascent/program/scheme-admit#relational-diagnostic::t
                             '#f)))
                       (declare (not safe))
                       (##structure
                        gerbil-ascent/candidate/types#reasoning-diagnostic::t
                        __tmp39711
                        __tmp39709
                        __tmp39708)))
               '#f)
              (let ((_%solved29772%_
                     (gerbil-ascent/candidate/reasoning#capture
                      (lambda ()
                        (let ((__tmp39712
                               (##structure-ref
                                _%report29765%_
                                '1
                                gerbil-ascent/program/scheme-admit#relational-admission-report::t
                                '#f)))
                          (declare (not safe))
                          (gerbil-ascent/program/scheme-admit#relational-solve
                           __tmp39712))))))
                (if (##structure-ref
                     _%solved29772%_
                     '1
                     gerbil-ascent/candidate/reasoning#captured-stage::t
                     '#f)
                    (gerbil-ascent/candidate/reasoning#attempt-observe
                     _%snapshot29761%_
                     _%spec29762%_
                     _%digest29763%_
                     _%query29764%_
                     (##structure-ref
                      _%solved29772%_
                      '2
                      gerbil-ascent/candidate/reasoning#captured-stage::t
                      '#f)
                     _%proof-steps29766%_
                     _%stratified-steps29767%_)
                    (gerbil-ascent/candidate/reasoning#attempt-failure
                     _%snapshot29761%_
                     _%digest29763%_
                     'unknown
                     _%query29764%_
                     'solve-failed
                     '(solve)
                     (##structure-ref
                      _%solved29772%_
                      '2
                      gerbil-ascent/candidate/reasoning#captured-stage::t
                      '#f))))))))
    (define gerbil-ascent/candidate/reasoning#attempt-prepare
      (lambda (_%snapshot29749%_
               _%spec29750%_
               _%digest29751%_
               _%proof-steps29752%_
               _%stratified-steps29753%_)
        (let* ((_%query29755%_
                (vector-ref
                 (##structure-ref
                  _%spec29750%_
                  '4
                  gerbil-ascent/candidate/types#reasoning-candidate::t
                  '#f)
                 '0))
               (_%prepared29758%_
                (gerbil-ascent/candidate/reasoning#capture
                 (lambda ()
                   (let ((__tmp39713
                          (let ()
                            (declare (not safe))
                            (gerbil-ascent/candidate/program#candidate-program
                             _%snapshot29749%_
                             _%spec29750%_))))
                     (declare (not safe))
                     (gerbil-ascent/program/scheme-admit#relational-admit/report
                      __tmp39713))))))
          (if (##structure-ref
               _%prepared29758%_
               '1
               gerbil-ascent/candidate/reasoning#captured-stage::t
               '#f)
              (gerbil-ascent/candidate/reasoning#attempt-solve
               _%snapshot29749%_
               _%spec29750%_
               _%digest29751%_
               _%query29755%_
               (##structure-ref
                _%prepared29758%_
                '2
                gerbil-ascent/candidate/reasoning#captured-stage::t
                '#f)
               _%proof-steps29752%_
               _%stratified-steps29753%_)
              (gerbil-ascent/candidate/reasoning#attempt-failure
               _%snapshot29749%_
               _%digest29751%_
               'rejected
               _%query29755%_
               'planner-rejected
               '(program)
               (##structure-ref
                _%prepared29758%_
                '2
                gerbil-ascent/candidate/reasoning#captured-stage::t
                '#f))))))
    (define gerbil-ascent/candidate/reasoning#reasoning-attempt__%
      (lambda (_%snapshot29708%_
               _%candidate29709%_
               _%proof-steps29710%_
               _%stratified-steps29711%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
               _%snapshot29708%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"reasoning attempt requires a current valid source snapshot"
                     _%snapshot29708%_)))
        (if (or (not _%proof-steps29710%_)
                (and (exact-integer? _%proof-steps29710%_)
                     (> _%proof-steps29710%_ '0)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"reasoning attempt requires positive proof work budget or #f"
                     _%proof-steps29710%_)))
        (if (or (not _%stratified-steps29711%_)
                (and (exact-integer? _%stratified-steps29711%_)
                     (> _%stratified-steps29711%_ '0)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"reasoning attempt requires positive stratified work budget"
                     _%stratified-steps29711%_)))
        (let* ((_%digest29719%_
                (gerbil-ascent/candidate/reasoning#candidate-content-digest
                 _%candidate29709%_))
               (_%inspection29722%_
                (gerbil-ascent/candidate/reasoning#capture
                 (lambda ()
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/program#candidate-inspect
                      _%snapshot29708%_
                      _%candidate29709%_))))))
          (if (##structure-ref
               _%inspection29722%_
               '1
               gerbil-ascent/candidate/reasoning#captured-stage::t
               '#f)
              (gerbil-ascent/candidate/reasoning#attempt-prepare
               _%snapshot29708%_
               (##structure-ref
                _%inspection29722%_
                '2
                gerbil-ascent/candidate/reasoning#captured-stage::t
                '#f)
               _%digest29719%_
               _%proof-steps29710%_
               _%stratified-steps29711%_)
              (if (let ((__tmp39714
                         (##structure-ref
                          _%inspection29722%_
                          '2
                          gerbil-ascent/candidate/reasoning#captured-stage::t
                          '#f)))
                    (declare (not safe))
                    (##structure-instance-of?
                     __tmp39714
                     'gerbil-ascent/candidate/types#candidate-rejection::t))
                  (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
                   _%snapshot29708%_
                   _%digest29719%_
                   'rejected
                   '#f
                   '()
                   (list (##structure-ref
                          (##structure-ref
                           _%inspection29722%_
                           '2
                           gerbil-ascent/candidate/reasoning#captured-stage::t
                           '#f)
                          '1
                          gerbil-ascent/candidate/types#candidate-rejection::t
                          '#f))
                   '#f)
                  (gerbil-ascent/candidate/reasoning#attempt-failure
                   _%snapshot29708%_
                   _%digest29719%_
                   'unknown
                   '#f
                   'inspector-failed
                   '(candidate)
                   (##structure-ref
                    _%inspection29722%_
                    '2
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#f)))))))
    (define gerbil-ascent/candidate/reasoning#reasoning-attempt__0
      (lambda (_%snapshot29731%_ _%candidate29732%_)
        (let* ((_%proof-steps29734%_ '100000) (_%stratified-steps29736%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-attempt__%
           _%snapshot29731%_
           _%candidate29732%_
           _%proof-steps29734%_
           _%stratified-steps29736%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-attempt__1
      (lambda (_%snapshot29738%_ _%candidate29739%_ _%proof-steps29740%_)
        (let ((_%stratified-steps29742%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-attempt__%
           _%snapshot29738%_
           _%candidate29739%_
           _%proof-steps29740%_
           _%stratified-steps29742%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-attempt
      (lambda _g39715_
        (let ((_g39716_ (let () (declare (not safe)) (##length _g39715_))))
          (cond ((let () (declare (not safe)) (##fx= _g39716_ 2))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-attempt__0
                        _g39715_))
                ((let () (declare (not safe)) (##fx= _g39716_ 3))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                        _g39715_))
                ((let () (declare (not safe)) (##fx= _g39716_ 4))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-attempt__%
                        _g39715_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/candidate/reasoning#reasoning-attempt
                  _g39715_))))))))
