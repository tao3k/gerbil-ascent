(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/reasoning::timestamp 1791692691)
  (begin
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt::t
      (let ((__tmp34200 (list)) (__tmp34199 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'reasoning-receipt
         __tmp34200
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  query
                  rows
                  diagnostics
                  evidence
                  proof
                  nonmembership
                  stratified)
         __tmp34199
         '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t)))
    (define gerbil-ascent/candidate/reasoning#make-reasoning-receipt
      (lambda _%$args30505%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#reasoning-receipt::t
               _%$args30505%_)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-query
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'query)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-diagnostics
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'diagnostics)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-evidence
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-proof
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-nonmembership
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'nonmembership)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-stratified
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'stratified)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'query)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-diagnostics-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'diagnostics)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-evidence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-proof-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-nonmembership-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'nonmembership)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-stratified-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'stratified)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-query
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'query)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-diagnostics
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'diagnostics)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-evidence
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-proof
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-nonmembership
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'nonmembership)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-stratified
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'stratified)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'query)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-diagnostics-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'diagnostics)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-evidence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-proof-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-nonmembership-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'nonmembership)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-stratified-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'stratified)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence::t
      (let ((__tmp34202 (list)) (__tmp34201 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reasoning-evidence
         __tmp34202
         '(kind support reachable)
         __tmp34201
         '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t)))
    (define gerbil-ascent/candidate/reasoning#make-reasoning-evidence
      (lambda _%$args30502%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#reasoning-evidence::t
               _%$args30502%_)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'kind)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-support
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'support)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-reachable
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reachable)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'kind)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-support-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'support)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-reachable-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reachable)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'kind)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-support
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'support)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-reachable
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reachable)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'kind)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-support-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'support)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-reachable-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reachable)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
      (let ((__tmp34204 (list)) (__tmp34203 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'reasoning-stratified-evidence
         __tmp34204
         '(status finite proof work-budget)
         __tmp34203
         '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t)))
    (define gerbil-ascent/candidate/reasoning#make-reasoning-stratified-evidence
      (lambda _%$args30499%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
               _%$args30499%_)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-finite
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'finite)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-proof
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-finite-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'finite)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-proof-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-finite
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'finite)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-proof
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-finite-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'finite)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-proof-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/reasoning#copy-row
      (lambda (_%row30496%_ _%arity30497%_)
        (if (list? _%row30496%_)
            (if (= (let () (declare (not safe)) (##length _%row30496%_))
                   _%arity30497%_)
                (if (let ()
                      (declare (not safe))
                      (andmap__0
                       gerbil-ascent/candidate/program#scalar?
                       _%row30496%_))
                    (let () (declare (not safe)) (##map identity _%row30496%_))
                    '#f)
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/reasoning#digest-datum
      (lambda (_%datum30427%_)
        (let* ((_%bytes30447%_
                (let* ((_%bytes30431%_
                        (let ((__tmp34205
                               (call-with-output-string
                                '""
                                (lambda (_%port30429%_)
                                  (write _%datum30427%_ _%port30429%_)))))
                          (declare (not safe))
                          (##string->utf8 __tmp34205)))
                       (_%bytes30436%_ _%bytes30431%_))
                  (declare (not safe))
                  (std/crypto/digest#__sha256 _%bytes30436%_)))
               (_%start30450%_ '0)
               (_%end30453%_
                (let ()
                  (declare (not safe))
                  (##u8vector-length _%bytes30447%_)))
               (_%bytes30458%_ _%bytes30447%_))
          (if (and (let () (declare (not safe)) (##fx>= _%start30450%_ '0))
                   (let ((__tmp34206
                          (let ((__tmp34207
                                 (let ()
                                   (declare (not safe))
                                   (##u8vector-length _%bytes30458%_))))
                            (declare (not safe))
                            (##fxmax __tmp34207 '1))))
                     (declare (not safe))
                     (##fx< _%start30450%_ __tmp34206)))
              (let ((_%start30473%_ _%start30450%_))
                (if (let ((__tmp34208
                           (let ()
                             (declare (not safe))
                             (##u8vector-length _%bytes30458%_))))
                      (declare (not safe))
                      (##fx<= _%start30473%_ _%end30453%_ __tmp34208))
                    (let ((_%end30486%_ _%end30453%_))
                      (declare (not safe))
                      (std/encoding/hex#__hex-encode__%
                       _%bytes30458%_
                       _%start30473%_
                       _%end30486%_))
                    (begin
                      (raise-contract-violation-error
                       '"contract violation"
                       'context:
                       'gerbil-ascent/candidate/reasoning
                       'contract:
                       '(in-range-inclusive? start (u8vector-length bytes))
                       'value:
                       _%end30453%_)
                      '#!void)))
              (begin
                (raise-contract-violation-error
                 '"contract violation"
                 'context:
                 'gerbil-ascent/candidate/reasoning
                 'contract:
                 '(in-range? 0 (fxmax (u8vector-length bytes) 1))
                 'value:
                 _%start30450%_)
                '#!void)))))
    (define gerbil-ascent/candidate/reasoning#candidate-content-digest
      (lambda (_%candidate30425%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/datum#reasoning-bounded-data?
               _%candidate30425%_
               '16384
               '128))
            (gerbil-ascent/candidate/reasoning#digest-datum
             (list 'reasoning-candidate-v1 _%candidate30425%_))
            '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
      (lambda (_%receipt30419%_ _%snapshot30420%_ _%candidate30421%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%receipt30419%_
               'gerbil-ascent/candidate/reasoning#reasoning-receipt::t))
            (if (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                   _%snapshot30420%_))
                (if (equal? (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%receipt30419%_
                               '2
                               '#f
                               '#f))
                            (##structure-ref
                             _%snapshot30420%_
                             '1
                             gerbil-ascent/candidate/types#reasoning-snapshot::t
                             '#f))
                    (if (equal? (let ()
                                  (declare (not safe))
                                  (##unchecked-structure-ref
                                   _%receipt30419%_
                                   '3
                                   '#f
                                   '#f))
                                (##structure-ref
                                 _%snapshot30420%_
                                 '2
                                 gerbil-ascent/candidate/types#reasoning-snapshot::t
                                 '#f))
                        (if (equal? (let ()
                                      (declare (not safe))
                                      (##unchecked-structure-ref
                                       _%receipt30419%_
                                       '4
                                       '#f
                                       '#f))
                                    (##structure-ref
                                     _%snapshot30420%_
                                     '3
                                     gerbil-ascent/candidate/types#reasoning-snapshot::t
                                     '#f))
                            (let ((_%digest30423%_
                                   (gerbil-ascent/candidate/reasoning#candidate-content-digest
                                    _%candidate30421%_)))
                              (if _%digest30423%_
                                  (equal? _%digest30423%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%receipt30419%_
                                             '5
                                             '#f
                                             '#f)))
                                  '#f))
                            '#f)
                        '#f)
                    '#f)
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-source-snapshot
      (lambda (_%identity30385%_ _%generation30386%_ _%declarations30387%_)
        (if (and (or (symbol? _%identity30385%_) (string? _%identity30385%_))
                 (exact-integer? _%generation30386%_)
                 (<= '0 _%generation30386%_)
                 (let ()
                   (declare (not safe))
                   (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                    _%declarations30387%_
                    '131072
                    '128))
                 (list? _%declarations30387%_)
                 (<= (let ()
                       (declare (not safe))
                       (##length _%declarations30387%_))
                     gerbil-ascent/candidate/types#+max-relations+))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid reasoning source snapshot")))
        (let _%loop30392%_ ((_%remaining30394%_ _%declarations30387%_)
                            (_%seen30395%_ '())
                            (_%copied30396%_ '())
                            (_%facts30397%_ '0))
          (if (null? _%remaining30394%_)
              (let* ((_%relations30399%_ (reverse _%copied30396%_))
                     (__tmp34209
                      (let ()
                        (declare (not safe))
                        (gerbil-ascent/candidate/types#reasoning-snapshot-content-digest
                         _%identity30385%_
                         _%generation30386%_
                         _%relations30399%_))))
                (declare (not safe))
                (##structure
                 gerbil-ascent/candidate/types#reasoning-snapshot::t
                 _%identity30385%_
                 _%generation30386%_
                 __tmp34209
                 _%relations30399%_))
              (let ((_%entry30401%_ (car _%remaining30394%_)))
                (if (and (list? _%entry30401%_)
                         (= (let ()
                              (declare (not safe))
                              (##length _%entry30401%_))
                            '3)
                         (symbol? (car _%entry30401%_))
                         (exact-integer? (cadr _%entry30401%_))
                         (<= '0 (cadr _%entry30401%_))
                         (list? (caddr _%entry30401%_))
                         (not (memq (car _%entry30401%_) _%seen30395%_)))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"invalid or duplicate reasoning source declaration"
                             _%entry30401%_)))
                (let* ((_%name30403%_ (car _%entry30401%_))
                       (_%arity30405%_ (cadr _%entry30401%_))
                       (_%rows30407%_ (caddr _%entry30401%_))
                       (_%next-facts30409%_
                        (+ _%facts30397%_ (length _%rows30407%_))))
                  (if (> _%next-facts30409%_
                         gerbil-ascent/candidate/types#+max-input-facts+)
                      (let ()
                        (declare (not safe))
                        (error '"reasoning source snapshot exceeds input cap"))
                      '#!void)
                  (let ((_%owned30417%_
                         (map (lambda (_%row30412%_)
                                (let ((_%$e30414%_
                                       (gerbil-ascent/candidate/reasoning#copy-row
                                        _%row30412%_
                                        _%arity30405%_)))
                                  (if _%$e30414%_
                                      _%$e30414%_
                                      (let ()
                                        (declare (not safe))
                                        (error '"invalid reasoning source row"
                                               _%name30403%_
                                               _%row30412%_)))))
                              _%rows30407%_)))
                    (_%loop30392%_
                     (cdr _%remaining30394%_)
                     (cons _%name30403%_ _%seen30395%_)
                     (cons (list _%name30403%_ _%arity30405%_ _%owned30417%_)
                           _%copied30396%_)
                     _%next-facts30409%_))))))))
    (define gerbil-ascent/candidate/reasoning#query-row-matches?
      (lambda (_%terms30368%_ _%row30369%_)
        (let _%loop30371%_ ((_%terms30373%_ _%terms30368%_)
                            (_%values30374%_ _%row30369%_)
                            (_%bindings30375%_ '()))
          (if (null? _%terms30373%_)
              '#t
              (let ((_%term30377%_ (car _%terms30373%_))
                    (_%value30378%_ (car _%values30374%_)))
                (if (eq? _%term30377%_ '?_)
                    (_%loop30371%_
                     (cdr _%terms30373%_)
                     (cdr _%values30374%_)
                     _%bindings30375%_)
                    (if (let ()
                          (declare (not safe))
                          (gerbil-ascent/candidate/program#candidate-variable?
                           _%term30377%_))
                        (let ((_%binding30382%_
                               (assq _%term30377%_ _%bindings30375%_)))
                          (if _%binding30382%_
                              (if (equal? (cdr _%binding30382%_)
                                          _%value30378%_)
                                  (_%loop30371%_
                                   (cdr _%terms30373%_)
                                   (cdr _%values30374%_)
                                   _%bindings30375%_)
                                  '#f)
                              (_%loop30371%_
                               (cdr _%terms30373%_)
                               (cdr _%values30374%_)
                               (cons (cons _%term30377%_ _%value30378%_)
                                     _%bindings30375%_))))
                        (if (equal? _%term30377%_ _%value30378%_)
                            (_%loop30371%_
                             (cdr _%terms30373%_)
                             (cdr _%values30374%_)
                             _%bindings30375%_)
                            '#f))))))))
    (define gerbil-ascent/candidate/reasoning#candidate-graph-case?
      (lambda (_%snapshot30356%_ _%spec30357%_ _%query30358%_)
        (let ((_%source30360%_
               (##structure-ref
                _%snapshot30356%_
                '4
                gerbil-ascent/candidate/types#reasoning-snapshot::t
                '#f))
              (_%derived30361%_
               (##structure-ref
                _%spec30357%_
                '1
                gerbil-ascent/candidate/types#reasoning-candidate::t
                '#f))
              (_%rules30362%_
               (##structure-ref
                _%spec30357%_
                '3
                gerbil-ascent/candidate/types#reasoning-candidate::t
                '#f)))
          (if (= (length _%source30360%_) '1)
              (if (eq? (caar _%source30360%_) 'edge)
                  (if (= (cadar _%source30360%_) '2)
                      (if (equal? _%derived30361%_ '((path . 2)))
                          (if (= (length _%rules30362%_) '2)
                              (if (let ((_%forms30366%_
                                         (map (lambda (_%rule30364%_)
                                                (cons (vector-ref
                                                       _%rule30364%_
                                                       '0)
                                                      (vector-ref
                                                       _%rule30364%_
                                                       '1)))
                                              _%rules30362%_)))
                                    (and (let ()
                                           (declare (not safe))
                                           (##member
                                            '((path ?x ?y) (edge ?x ?y))
                                            _%forms30366%_))
                                         (let ()
                                           (declare (not safe))
                                           (##member
                                            '((path ?x ?z)
                                              (path ?x ?y)
                                              (edge ?y ?z))
                                            _%forms30366%_))))
                                  (if (= (length _%query30358%_) '3)
                                      (if (eq? (car _%query30358%_) 'path)
                                          (if (exact-integer?
                                               (cadr _%query30358%_))
                                              (exact-integer?
                                               (caddr _%query30358%_))
                                              '#f)
                                          '#f)
                                      '#f)
                                  '#f)
                              '#f)
                          '#f)
                      '#f)
                  '#f)
              '#f))))
    (define gerbil-ascent/candidate/reasoning#candidate-edge-records
      (lambda (_%snapshot30348%_ _%spec30349%_)
        (let ((__tmp34211
               (map (lambda (_%row30351%_ _%index30352%_)
                      (list 'source _%index30352%_ _%row30351%_))
                    (caddar (##structure-ref
                             _%snapshot30348%_
                             '4
                             gerbil-ascent/candidate/types#reasoning-snapshot::t
                             '#f))
                    (let ((__tmp34212
                           (length (caddar (##structure-ref
                                            _%snapshot30348%_
                                            '4
                                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                                            '#f)))))
                      (declare (not safe))
                      (##iota __tmp34212 '1))))
              (__tmp34210
               (map (lambda (_%fact30354%_)
                      (list 'candidate
                            (vector-ref _%fact30354%_ '2)
                            (vector-ref _%fact30354%_ '1)))
                    (##structure-ref
                     _%spec30349%_
                     '2
                     gerbil-ascent/candidate/types#reasoning-candidate::t
                     '#f))))
          (declare (not safe))
          (##append __tmp34211 __tmp34210))))
    (define gerbil-ascent/candidate/reasoning#candidate-edge-index
      (lambda (_%records30340%_)
        (let ((_%index30342%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (for-each
           (lambda (_%record30344%_)
             (let* ((_%origin30346%_ (caaddr _%record30344%_))
                    (__tmp34213
                     (cons _%record30344%_
                           (let ()
                             (declare (not safe))
                             (__hash-ref__%
                              _%index30342%_
                              _%origin30346%_
                              '())))))
               (declare (not safe))
               (__hash-put! _%index30342%_ _%origin30346%_ __tmp34213)))
           _%records30340%_)
          _%index30342%_)))
    (define gerbil-ascent/candidate/reasoning#candidate-graph-walk
      (lambda (_%records30265%_ _%origin30266%_ _%target30267%_)
        (let ((_%index30269%_
               (gerbil-ascent/candidate/reasoning#candidate-edge-index
                _%records30265%_))
              (_%visited30270%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value)))
              (_%reachable30271%_ (list _%origin30266%_))
              (_%support30272%_ '#f))
          (let ()
            (declare (not safe))
            (__hash-put! _%visited30270%_ _%origin30266%_ '#t))
          (let _%loop30274%_ ((_%front30276%_
                               (list (cons _%origin30266%_ '())))
                              (_%back30277%_ '()))
            (if (null? _%front30276%_)
                (if (null? _%back30277%_)
                    (values _%support30272%_
                            (let ()
                              (declare (not safe))
                              (##reverse _%reachable30271%_)))
                    (_%loop30274%_ (reverse _%back30277%_) '()))
                (let* ((_%state30281%_ (car _%front30276%_))
                       (_%node30283%_ (car _%state30281%_))
                       (_%path30285%_ (cdr _%state30281%_))
                       (_%next30287%_ _%back30277%_))
                  (let ((__tmp34215
                         (lambda (_%record30290%_)
                           (let* ((_%$%record3029130306%_ _%record30290%_)
                                  (_%$%E3029330309%_
                                   (lambda ()
                                     (let ()
                                       (declare (not safe))
                                       (error '"No clause matching"
                                              _%$%record3029130306%_
                                              '([_ _ [_ neighbor]])))
                                     '#!void))
                                  (_%$%K3029430316%_
                                   (lambda (_%neighbor30312%_)
                                     (let ((_%extended30314%_
                                            (cons _%record30290%_
                                                  _%path30285%_)))
                                       (if (if _%support30272%_
                                               '#f
                                               (equal? _%neighbor30312%_
                                                       _%target30267%_))
                                           (set! _%support30272%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##reverse
                                                    _%extended30314%_)))
                                           '#!void)
                                       (if (let ()
                                             (declare (not safe))
                                             (__hash-get
                                              _%visited30270%_
                                              _%neighbor30312%_))
                                           '#!void
                                           (begin
                                             (let ()
                                               (declare (not safe))
                                               (__hash-put!
                                                _%visited30270%_
                                                _%neighbor30312%_
                                                '#t))
                                             (set! _%reachable30271%_
                                                   (cons _%neighbor30312%_
                                                         _%reachable30271%_))
                                             (set! _%next30287%_
                                                   (cons (cons _%neighbor30312%_
                                                               _%extended30314%_)
                                                         _%next30287%_))))))))
                             (if (pair? _%$%record3029130306%_)
                                 (let ((_%$%tl3029630319%_
                                        (let ()
                                          (declare (not safe))
                                          (##cdr _%$%record3029130306%_))))
                                   (if (pair? _%$%tl3029630319%_)
                                       (let ((_%$%tl3029830322%_
                                              (let ()
                                                (declare (not safe))
                                                (##cdr _%$%tl3029630319%_))))
                                         (if (pair? _%$%tl3029830322%_)
                                             (let ((_%$%hd3029930325%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##car _%$%tl3029830322%_)))
                                                   (_%$%tl3030030327%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##cdr _%$%tl3029830322%_))))
                                               (if (pair? _%$%hd3029930325%_)
                                                   (let ((_%$%tl3030230330%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (##cdr _%$%hd3029930325%_))))
                                                     (if (pair? _%$%tl3030230330%_)
                                                         (let ((_%$%hd3030330333%_
                                                                (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##car _%$%tl3030230330%_)))
                       (_%$%tl3030430335%_
                        (let ()
                          (declare (not safe))
                          (##cdr _%$%tl3030230330%_))))
                   (let ((_%neighbor30338%_ _%$%hd3030330333%_))
                     (if (null? _%$%tl3030430335%_)
                         (if (null? _%$%tl3030030327%_)
                             (_%$%K3029430316%_ _%neighbor30338%_)
                             (_%$%E3029330309%_))
                         (_%$%E3029330309%_))))
                 (_%$%E3029330309%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (_%$%E3029330309%_)))
                                             (_%$%E3029330309%_)))
                                       (_%$%E3029330309%_)))
                                 (_%$%E3029330309%_)))))
                        (__tmp34214
                         (reverse (let ()
                                    (declare (not safe))
                                    (__hash-ref__%
                                     _%index30269%_
                                     _%node30283%_
                                     '())))))
                    (declare (not safe))
                    (##for-each __tmp34215 __tmp34214))
                  (_%loop30274%_ (cdr _%front30276%_) _%next30287%_)))))))
    (define gerbil-ascent/candidate/reasoning#candidate-evidence
      (lambda (_%snapshot30253%_ _%spec30254%_ _%query30255%_ _%rows30256%_)
        (if (gerbil-ascent/candidate/reasoning#candidate-graph-case?
             _%snapshot30253%_
             _%spec30254%_
             _%query30255%_)
            (let ((_g34216_
                   (gerbil-ascent/candidate/reasoning#candidate-graph-walk
                    (gerbil-ascent/candidate/reasoning#candidate-edge-records
                     _%snapshot30253%_
                     _%spec30254%_)
                    (cadr _%query30255%_)
                    (caddr _%query30255%_))))
              (begin
                (let ((_g34217_
                       (let ()
                         (declare (not safe))
                         (if (##values? _g34216_)
                             (##values-length _g34216_)
                             1))))
                  (if (not (let () (declare (not safe)) (##fx= _g34217_ 2)))
                      (error "Context expects 2 values" _g34217_)))
                (let ((_%support30258%_
                       (let () (declare (not safe)) (##values-ref _g34216_ 0)))
                      (_%reachable30259%_
                       (let ()
                         (declare (not safe))
                         (##values-ref _g34216_ 1))))
                  (if (and (pair? _%rows30256%_) _%support30258%_)
                      (let ()
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                         'witness
                         _%support30258%_
                         '()))
                      (if (and (null? _%rows30256%_)
                               (if _%support30258%_
                                   '#f
                                   (not (member (caddr _%query30255%_)
                                                _%reachable30259%_))))
                          (let ()
                            (declare (not safe))
                            (##structure
                             gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                             'cut
                             '()
                             _%reachable30259%_))
                          (if (and (null? _%rows30256%_)
                                   (if _%support30258%_
                                       '#f
                                       (equal? (cadr _%query30255%_)
                                               (caddr _%query30255%_))))
                              (let ()
                                (declare (not safe))
                                (##structure
                                 gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                                 'unsupported
                                 '()
                                 '()))
                              '#f))))))
            (let ()
              (declare (not safe))
              (##structure
               gerbil-ascent/candidate/reasoning#reasoning-evidence::t
               'unsupported
               '()
               '())))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
      (lambda (_%snapshot30187%_
               _%digest30188%_
               _%status30189%_
               _%query30190%_
               _%rows30191%_
               _%diagnostics30192%_
               _%evidence30193%_
               _%proof30194%_
               _%nonmembership30195%_
               _%stratified30196%_)
        (let ((__tmp34234
               (##structure-ref
                _%snapshot30187%_
                '1
                gerbil-ascent/candidate/types#reasoning-snapshot::t
                '#f))
              (__tmp34233
               (##structure-ref
                _%snapshot30187%_
                '2
                gerbil-ascent/candidate/types#reasoning-snapshot::t
                '#f))
              (__tmp34232
               (##structure-ref
                _%snapshot30187%_
                '3
                gerbil-ascent/candidate/types#reasoning-snapshot::t
                '#f))
              (__tmp34231
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/datum#candidate-copy-pairs
                  _%query30190%_)))
              (__tmp34230
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/datum#candidate-copy-pairs
                  _%rows30191%_)))
              (__tmp34224
               (map (lambda (_%diagnostic30198%_)
                      (let ((__tmp34229
                             (##structure-ref
                              _%diagnostic30198%_
                              '1
                              gerbil-ascent/candidate/types#reasoning-diagnostic::t
                              '#f))
                            (__tmp34227
                             (let ((__tmp34228
                                    (##structure-ref
                                     _%diagnostic30198%_
                                     '2
                                     gerbil-ascent/candidate/types#reasoning-diagnostic::t
                                     '#f)))
                               (declare (not safe))
                               (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                __tmp34228)))
                            (__tmp34225
                             (let ((__tmp34226
                                    (##structure-ref
                                     _%diagnostic30198%_
                                     '3
                                     gerbil-ascent/candidate/types#reasoning-diagnostic::t
                                     '#f)))
                               (declare (not safe))
                               (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                __tmp34226))))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/types#reasoning-diagnostic::t
                         __tmp34229
                         __tmp34227
                         __tmp34225)))
                    _%diagnostics30192%_))
              (__tmp34218
               (if _%evidence30193%_
                   (let ((__tmp34223
                          (##structure-ref
                           _%evidence30193%_
                           '1
                           gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                           '#f))
                         (__tmp34221
                          (let ((__tmp34222
                                 (##structure-ref
                                  _%evidence30193%_
                                  '2
                                  gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                                  '#f)))
                            (declare (not safe))
                            (gerbil-ascent/candidate/datum#candidate-copy-pairs
                             __tmp34222)))
                         (__tmp34219
                          (let ((__tmp34220
                                 (##structure-ref
                                  _%evidence30193%_
                                  '3
                                  gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                                  '#f)))
                            (declare (not safe))
                            (gerbil-ascent/candidate/datum#candidate-copy-pairs
                             __tmp34220))))
                     (declare (not safe))
                     (##structure
                      gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                      __tmp34223
                      __tmp34221
                      __tmp34219))
                   '#f)))
          (declare (not safe))
          (##structure
           gerbil-ascent/candidate/reasoning#reasoning-receipt::t
           _%status30189%_
           __tmp34234
           __tmp34233
           __tmp34232
           _%digest30188%_
           __tmp34231
           __tmp34230
           __tmp34224
           __tmp34218
           _%proof30194%_
           _%nonmembership30195%_
           _%stratified30196%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
      (lambda (_%snapshot30203%_
               _%digest30204%_
               _%status30205%_
               _%query30206%_
               _%rows30207%_
               _%diagnostics30208%_
               _%evidence30209%_)
        (let* ((_%proof30211%_ '#f)
               (_%nonmembership30213%_ '#f)
               (_%stratified30215%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
           _%snapshot30203%_
           _%digest30204%_
           _%status30205%_
           _%query30206%_
           _%rows30207%_
           _%diagnostics30208%_
           _%evidence30209%_
           _%proof30211%_
           _%nonmembership30213%_
           _%stratified30215%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for__1
      (lambda (_%snapshot30217%_
               _%digest30218%_
               _%status30219%_
               _%query30220%_
               _%rows30221%_
               _%diagnostics30222%_
               _%evidence30223%_
               _%proof30224%_)
        (let* ((_%nonmembership30226%_ '#f) (_%stratified30228%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
           _%snapshot30217%_
           _%digest30218%_
           _%status30219%_
           _%query30220%_
           _%rows30221%_
           _%diagnostics30222%_
           _%evidence30223%_
           _%proof30224%_
           _%nonmembership30226%_
           _%stratified30228%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for__2
      (lambda (_%snapshot30230%_
               _%digest30231%_
               _%status30232%_
               _%query30233%_
               _%rows30234%_
               _%diagnostics30235%_
               _%evidence30236%_
               _%proof30237%_
               _%nonmembership30238%_)
        (let ((_%stratified30240%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
           _%snapshot30230%_
           _%digest30231%_
           _%status30232%_
           _%query30233%_
           _%rows30234%_
           _%diagnostics30235%_
           _%evidence30236%_
           _%proof30237%_
           _%nonmembership30238%_
           _%stratified30240%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for
      (lambda _g34235_
        (let ((_g34236_ (let () (declare (not safe)) (##length _g34235_))))
          (cond ((let () (declare (not safe)) (##fx= _g34236_ 7))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
                        _g34235_))
                ((let () (declare (not safe)) (##fx= _g34236_ 8))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-receipt-for__1
                        _g34235_))
                ((let () (declare (not safe)) (##fx= _g34236_ 9))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-receipt-for__2
                        _g34235_))
                ((let () (declare (not safe)) (##fx= _g34236_ 10))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
                        _g34235_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/candidate/reasoning#reasoning-receipt-for
                  _g34235_))))))
    (define gerbil-ascent/candidate/reasoning#captured-stage::t
      (let ((__tmp34238 (list)) (__tmp34237 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#captured-stage::t
         'captured-stage
         __tmp34238
         '(ok? value)
         __tmp34237
         '#f)))
    (define gerbil-ascent/candidate/reasoning#captured-stage?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#captured-stage::t)))
    (define gerbil-ascent/candidate/reasoning#make-captured-stage
      (lambda _%$args30183%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#captured-stage::t
               _%$args30183%_)))
    (define gerbil-ascent/candidate/reasoning#captured-stage-ok?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'ok?)))
    (define gerbil-ascent/candidate/reasoning#captured-stage-value
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'value)))
    (define gerbil-ascent/candidate/reasoning#captured-stage-ok?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'ok?)))
    (define gerbil-ascent/candidate/reasoning#captured-stage-value-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'value)))
    (define gerbil-ascent/candidate/reasoning#&captured-stage-ok?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'ok?)))
    (define gerbil-ascent/candidate/reasoning#&captured-stage-value
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'value)))
    (define gerbil-ascent/candidate/reasoning#&captured-stage-ok?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'ok?)))
    (define gerbil-ascent/candidate/reasoning#&captured-stage-value-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'value)))
    (define gerbil-ascent/candidate/reasoning#capture
      (lambda (_%thunk30178%_)
        (let ((__tmp34241
               (lambda (_%failure30180%_)
                 (let ()
                   (declare (not safe))
                   (##structure
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#f
                    _%failure30180%_))))
              (__tmp34239
               (lambda ()
                 (let ((__tmp34240 (_%thunk30178%_)))
                   (declare (not safe))
                   (##structure
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#t
                    __tmp34240)))))
          (declare (not safe))
          (__with-catch __tmp34241 __tmp34239))))
    (define gerbil-ascent/candidate/reasoning#failure-detail
      (lambda (_%failure30174%_)
        (let ((_%message30176%_
               (let ()
                 (declare (not safe))
                 (std/error#exception->string _%failure30174%_))))
          (if (> (let ()
                   (declare (not safe))
                   (##string-length _%message30176%_))
                 '240)
              (substring _%message30176%_ '0 '240)
              _%message30176%_))))
    (define gerbil-ascent/candidate/reasoning#produce-receipt-stratified
      (lambda (_%snapshot30163%_
               _%spec30164%_
               _%digest30165%_
               _%rows30166%_
               _%work-budget30167%_)
        (let ((_%finite30169%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/finite-evidence#candidate-finite-evidence
                  _%snapshot30163%_
                  _%spec30164%_
                  _%digest30165%_
                  'complete
                  _%rows30166%_
                  _%work-budget30167%_))))
          (if (eq? (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref _%finite30169%_ '1 '#f '#f))
                   'complete)
              (let ((_g34242_
                     (let ()
                       (declare (not safe))
                       (gerbil-ascent/candidate/stratified-producer#candidate-produce-stratified-proof
                        _%snapshot30163%_
                        _%spec30164%_
                        _%digest30165%_
                        'complete
                        _%rows30166%_
                        _%finite30169%_
                        _%work-budget30167%_
                        _%work-budget30167%_))))
                (begin
                  (let ((_g34243_
                         (let ()
                           (declare (not safe))
                           (if (##values? _g34242_)
                               (##values-length _g34242_)
                               1))))
                    (if (not (let () (declare (not safe)) (##fx= _g34243_ 2)))
                        (error "Context expects 2 values" _g34243_)))
                  (let ((_%status30171%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g34242_ 0)))
                        (_%proof30172%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g34242_ 1))))
                    (let ()
                      (declare (not safe))
                      (##structure
                       gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                       _%status30171%_
                       _%finite30169%_
                       _%proof30172%_
                       _%work-budget30167%_)))))
              (let ((__tmp34244
                     (let ()
                       (declare (not safe))
                       (##unchecked-structure-ref
                        _%finite30169%_
                        '1
                        '#f
                        '#f))))
                (declare (not safe))
                (##structure
                 gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                 __tmp34244
                 _%finite30169%_
                 '()
                 _%work-budget30167%_))))))
    (define gerbil-ascent/candidate/reasoning#reasoning-verify-finite-receipt
      (lambda (_%receipt30155%_
               _%snapshot30156%_
               _%candidate30157%_
               _%work-budget30158%_)
        (if (and (exact-integer? _%work-budget30158%_)
                 (> _%work-budget30158%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"finite receipt verification needs positive work budget"
                     _%work-budget30158%_)))
        (if (and (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                  _%receipt30155%_
                  _%snapshot30156%_
                  _%candidate30157%_)
                 (eq? (##structure-ref
                       _%receipt30155%_
                       '1
                       gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                       '#f)
                      'complete)
                 (let ((__tmp34245
                        (##structure-ref
                         _%receipt30155%_
                         '12
                         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                         '#f)))
                   (declare (not safe))
                   (##structure-instance-of?
                    __tmp34245
                    'gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t)))
            (let ((_%checked30161%_
                   (gerbil-ascent/candidate/reasoning#capture
                    (lambda ()
                      (let ((__tmp34249
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program#candidate-inspect
                                _%snapshot30156%_
                                _%candidate30157%_)))
                            (__tmp34248
                             (##structure-ref
                              _%receipt30155%_
                              '5
                              gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                              '#f))
                            (__tmp34247
                             (##structure-ref
                              _%receipt30155%_
                              '7
                              gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                              '#f))
                            (__tmp34246
                             (##structure-ref
                              (##structure-ref
                               _%receipt30155%_
                               '12
                               gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                               '#f)
                              '2
                              gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                              '#f)))
                        (declare (not safe))
                        (gerbil-ascent/candidate/finite-evidence#candidate-verify-finite-evidence
                         _%snapshot30156%_
                         __tmp34249
                         __tmp34248
                         'complete
                         __tmp34247
                         __tmp34246
                         _%work-budget30158%_))))))
              (if (##structure-ref
                   _%checked30161%_
                   '1
                   gerbil-ascent/candidate/reasoning#captured-stage::t
                   '#f)
                  (##structure-ref
                   _%checked30161%_
                   '2
                   gerbil-ascent/candidate/reasoning#captured-stage::t
                   '#f)
                  'invalid))
            'invalid)))
    (define gerbil-ascent/candidate/reasoning#reasoning-verify-stratified-receipt
      (lambda (_%receipt30142%_
               _%snapshot30143%_
               _%candidate30144%_
               _%work-budget30145%_)
        (if (and (exact-integer? _%work-budget30145%_)
                 (> _%work-budget30145%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"stratified receipt verification needs positive work budget"
                     _%work-budget30145%_)))
        (if (and (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                  _%receipt30142%_
                  _%snapshot30143%_
                  _%candidate30144%_)
                 (eq? (##structure-ref
                       _%receipt30142%_
                       '1
                       gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                       '#f)
                      'complete)
                 (let ((__tmp34250
                        (##structure-ref
                         _%receipt30142%_
                         '12
                         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                         '#f)))
                   (declare (not safe))
                   (##structure-instance-of?
                    __tmp34250
                    'gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t)))
            (let* ((_%evidence30147%_
                    (##structure-ref
                     _%receipt30142%_
                     '12
                     gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                     '#f))
                   (_%$e30149%_
                    (##structure-ref
                     _%evidence30147%_
                     '1
                     gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                     '#f)))
              (if (eq? 'complete _%$e30149%_)
                  (let ((_%checked30153%_
                         (gerbil-ascent/candidate/reasoning#capture
                          (lambda ()
                            (let ((__tmp34255
                                   (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/program#candidate-inspect
                                      _%snapshot30143%_
                                      _%candidate30144%_)))
                                  (__tmp34254
                                   (##structure-ref
                                    _%receipt30142%_
                                    '5
                                    gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                    '#f))
                                  (__tmp34253
                                   (##structure-ref
                                    _%receipt30142%_
                                    '7
                                    gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                    '#f))
                                  (__tmp34252
                                   (##structure-ref
                                    _%evidence30147%_
                                    '2
                                    gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                                    '#f))
                                  (__tmp34251
                                   (##structure-ref
                                    _%evidence30147%_
                                    '3
                                    gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                                    '#f)))
                              (declare (not safe))
                              (gerbil-ascent/candidate/stratified-proof#candidate-verify-stratified-proof
                               _%snapshot30143%_
                               __tmp34255
                               __tmp34254
                               'complete
                               __tmp34253
                               __tmp34252
                               _%work-budget30145%_
                               __tmp34251
                               _%work-budget30145%_))))))
                    (if (##structure-ref
                         _%checked30153%_
                         '1
                         gerbil-ascent/candidate/reasoning#captured-stage::t
                         '#f)
                        (##structure-ref
                         _%checked30153%_
                         '2
                         gerbil-ascent/candidate/reasoning#captured-stage::t
                         '#f)
                        'invalid))
                  (if (eq? 'bounded _%$e30149%_)
                      'bounded
                      (if (eq? 'unsupported _%$e30149%_)
                          'unsupported
                          'invalid))))
            'invalid)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation::t
      (let ((__tmp34257 (list)) (__tmp34256 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#attempt-observation::t
         'attempt-observation
         __tmp34257
         '(rows evidence)
         __tmp34256
         '#f)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#attempt-observation::t)))
    (define gerbil-ascent/candidate/reasoning#make-attempt-observation
      (lambda _%$args30139%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#attempt-observation::t
               _%$args30139%_)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation-evidence
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation-evidence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#&attempt-observation-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#&attempt-observation-evidence
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#&attempt-observation-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#&attempt-observation-evidence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#attempt-failure
      (lambda (_%snapshot30131%_
               _%digest30132%_
               _%status30133%_
               _%query30134%_
               _%code30135%_
               _%path30136%_
               _%failure30137%_)
        (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
         _%snapshot30131%_
         _%digest30132%_
         _%status30133%_
         _%query30134%_
         '()
         (list (let ((__tmp34258
                      (gerbil-ascent/candidate/reasoning#failure-detail
                       _%failure30137%_)))
                 (declare (not safe))
                 (##structure
                  gerbil-ascent/candidate/types#reasoning-diagnostic::t
                  _%code30135%_
                  _%path30136%_
                  __tmp34258)))
         '#f)))
    (define gerbil-ascent/candidate/reasoning#attempt-proof-diagnostics
      (lambda (_%result30125%_ _%code30126%_)
        (if (or (not _%result30125%_)
                (##structure-ref
                 _%result30125%_
                 '1
                 gerbil-ascent/candidate/reasoning#captured-stage::t
                 '#f))
            '()
            (list (let ((__tmp34259
                         (gerbil-ascent/candidate/reasoning#failure-detail
                          (##structure-ref
                           _%result30125%_
                           '2
                           gerbil-ascent/candidate/reasoning#captured-stage::t
                           '#f))))
                    (declare (not safe))
                    (##structure
                     gerbil-ascent/candidate/types#reasoning-diagnostic::t
                     _%code30126%_
                     '(explain)
                     __tmp34259))))))
    (define gerbil-ascent/candidate/reasoning#attempt-proof-value
      (lambda (_%result30123%_)
        (if _%result30123%_
            (if (##structure-ref
                 _%result30123%_
                 '1
                 gerbil-ascent/candidate/reasoning#captured-stage::t
                 '#f)
                (##structure-ref
                 _%result30123%_
                 '2
                 gerbil-ascent/candidate/reasoning#captured-stage::t
                 '#f)
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/reasoning#attempt-publish
      (lambda (_%snapshot30077%_
               _%spec30078%_
               _%digest30079%_
               _%query30080%_
               _%observation30081%_
               _%proof-steps30082%_
               _%stratified-steps30083%_)
        (let* ((_%$%observation3008430091%_ _%observation30081%_)
               (_%$%E3008630094%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%observation3008430091%_
                           '((attempt-observation rows evidence))))
                  '#!void))
               (_%$%K3008730110%_
                (lambda (_%evidence30097%_ _%rows30098%_)
                  (let* ((_%proof30101%_
                          (gerbil-ascent/candidate/reasoning#capture
                           (lambda ()
                             (if _%proof-steps30082%_
                                 (let ()
                                   (declare (not safe))
                                   (gerbil-ascent/candidate/provenance#candidate-positive-proof
                                    _%snapshot30077%_
                                    _%spec30078%_
                                    _%digest30079%_
                                    'complete
                                    _%rows30098%_
                                    _%proof-steps30082%_))
                                 '#f))))
                         (_%absence30104%_
                          (gerbil-ascent/candidate/reasoning#capture
                           (lambda ()
                             (if _%proof-steps30082%_
                                 (let ()
                                   (declare (not safe))
                                   (gerbil-ascent/candidate/nonmembership#candidate-positive-nonmembership
                                    _%snapshot30077%_
                                    _%spec30078%_
                                    _%digest30079%_
                                    'complete
                                    _%rows30098%_
                                    _%proof-steps30082%_))
                                 '#f))))
                         (_%stratified30107%_
                          (if _%stratified-steps30083%_
                              (gerbil-ascent/candidate/reasoning#capture
                               (lambda ()
                                 (gerbil-ascent/candidate/reasoning#produce-receipt-stratified
                                  _%snapshot30077%_
                                  _%spec30078%_
                                  _%digest30079%_
                                  _%rows30098%_
                                  _%stratified-steps30083%_)))
                              '#f)))
                    (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
                     _%snapshot30077%_
                     _%digest30079%_
                     'complete
                     _%query30080%_
                     _%rows30098%_
                     (let ((__tmp34262
                            (gerbil-ascent/candidate/reasoning#attempt-proof-diagnostics
                             _%proof30101%_
                             'proof-failed))
                           (__tmp34261
                            (gerbil-ascent/candidate/reasoning#attempt-proof-diagnostics
                             _%absence30104%_
                             'nonmembership-failed))
                           (__tmp34260
                            (gerbil-ascent/candidate/reasoning#attempt-proof-diagnostics
                             _%stratified30107%_
                             'stratified-evidence-failed)))
                       (declare (not safe))
                       (##append __tmp34262 __tmp34261 __tmp34260))
                     _%evidence30097%_
                     (gerbil-ascent/candidate/reasoning#attempt-proof-value
                      _%proof30101%_)
                     (gerbil-ascent/candidate/reasoning#attempt-proof-value
                      _%absence30104%_)
                     (gerbil-ascent/candidate/reasoning#attempt-proof-value
                      _%stratified30107%_))))))
          (if (let ()
                (declare (not safe))
                (##structure-instance-of?
                 _%$%observation3008430091%_
                 'gerbil-ascent/candidate/reasoning#attempt-observation::t))
              (let* ((_%$%e3008830113%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%observation3008430091%_
                         '1
                         '#f
                         '#f)))
                     (_%rows30116%_ _%$%e3008830113%_)
                     (_%$%e3008930118%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%observation3008430091%_
                         '2
                         '#f
                         '#f)))
                     (_%evidence30121%_ _%$%e3008930118%_))
                (_%$%K3008730110%_ _%evidence30121%_ _%rows30116%_))
              (_%$%E3008630094%_)))))
    (define gerbil-ascent/candidate/reasoning#attempt-observe
      (lambda (_%snapshot30054%_
               _%spec30055%_
               _%digest30056%_
               _%query30057%_
               _%solved30058%_
               _%proof-steps30059%_
               _%stratified-steps30060%_)
        (let ((_%observed30072%_
               (gerbil-ascent/candidate/reasoning#capture
                (lambda ()
                  (let* ((_%all30063%_
                          (let ((__tmp34263 (car _%query30057%_)))
                            (declare (not safe))
                            (gerbil-ascent/program/scheme-query#relational-query-name
                             _%solved30058%_
                             __tmp34263)))
                         (_%rows30069%_
                          (let ((__tmp34264
                                 (lambda (_%$%g3006430066%_)
                                   (gerbil-ascent/candidate/reasoning#query-row-matches?
                                    (cdr _%query30057%_)
                                    _%$%g3006430066%_))))
                            (declare (not safe))
                            (##filter __tmp34264 _%all30063%_)))
                         (__tmp34265
                          (gerbil-ascent/candidate/reasoning#candidate-evidence
                           _%snapshot30054%_
                           _%spec30055%_
                           _%query30057%_
                           _%rows30069%_)))
                    (declare (not safe))
                    (##structure
                     gerbil-ascent/candidate/reasoning#attempt-observation::t
                     _%rows30069%_
                     __tmp34265))))))
          (if (##structure-ref
               _%observed30072%_
               '1
               gerbil-ascent/candidate/reasoning#captured-stage::t
               '#f)
              (if (##structure-ref
                   (##structure-ref
                    _%observed30072%_
                    '2
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#f)
                   '2
                   gerbil-ascent/candidate/reasoning#attempt-observation::t
                   '#f)
                  (gerbil-ascent/candidate/reasoning#attempt-publish
                   _%snapshot30054%_
                   _%spec30055%_
                   _%digest30056%_
                   _%query30057%_
                   (##structure-ref
                    _%observed30072%_
                    '2
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#f)
                   _%proof-steps30059%_
                   _%stratified-steps30060%_)
                  (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
                   _%snapshot30054%_
                   _%digest30056%_
                   'unknown
                   _%query30057%_
                   '()
                   (list (let ()
                           (declare (not safe))
                           (##structure
                            gerbil-ascent/candidate/types#reasoning-diagnostic::t
                            'evidence-mismatch
                            '(explain)
                            _%query30057%_)))
                   '#f))
              (gerbil-ascent/candidate/reasoning#attempt-failure
               _%snapshot30054%_
               _%digest30056%_
               'unknown
               _%query30057%_
               'query-failed
               '(query)
               (##structure-ref
                _%observed30072%_
                '2
                gerbil-ascent/candidate/reasoning#captured-stage::t
                '#f))))))
    (define gerbil-ascent/candidate/reasoning#attempt-solve
      (lambda (_%snapshot30041%_
               _%spec30042%_
               _%digest30043%_
               _%query30044%_
               _%report30045%_
               _%proof-steps30046%_
               _%stratified-steps30047%_)
        (let ((_%diagnostic30049%_
               (##structure-ref
                _%report30045%_
                '2
                gerbil-ascent/program/scheme-admit#relational-admission-report::t
                '#f)))
          (if _%diagnostic30049%_
              (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
               _%snapshot30041%_
               _%digest30043%_
               'rejected
               _%query30044%_
               '()
               (list (let ((__tmp34269
                            (##structure-ref
                             _%diagnostic30049%_
                             '1
                             gerbil-ascent/program/scheme-admit#relational-diagnostic::t
                             '#f))
                           (__tmp34267
                            (let ((__tmp34268
                                   (##structure-ref
                                    _%diagnostic30049%_
                                    '2
                                    gerbil-ascent/program/scheme-admit#relational-diagnostic::t
                                    '#f)))
                              (declare (not safe))
                              (gerbil-ascent/candidate/program#candidate-planner-path
                               _%spec30042%_
                               __tmp34268)))
                           (__tmp34266
                            (##structure-ref
                             _%diagnostic30049%_
                             '3
                             gerbil-ascent/program/scheme-admit#relational-diagnostic::t
                             '#f)))
                       (declare (not safe))
                       (##structure
                        gerbil-ascent/candidate/types#reasoning-diagnostic::t
                        __tmp34269
                        __tmp34267
                        __tmp34266)))
               '#f)
              (let ((_%solved30052%_
                     (gerbil-ascent/candidate/reasoning#capture
                      (lambda ()
                        (let ((__tmp34270
                               (##structure-ref
                                _%report30045%_
                                '1
                                gerbil-ascent/program/scheme-admit#relational-admission-report::t
                                '#f)))
                          (declare (not safe))
                          (gerbil-ascent/program/scheme-admit#relational-solve
                           __tmp34270))))))
                (if (##structure-ref
                     _%solved30052%_
                     '1
                     gerbil-ascent/candidate/reasoning#captured-stage::t
                     '#f)
                    (gerbil-ascent/candidate/reasoning#attempt-observe
                     _%snapshot30041%_
                     _%spec30042%_
                     _%digest30043%_
                     _%query30044%_
                     (##structure-ref
                      _%solved30052%_
                      '2
                      gerbil-ascent/candidate/reasoning#captured-stage::t
                      '#f)
                     _%proof-steps30046%_
                     _%stratified-steps30047%_)
                    (gerbil-ascent/candidate/reasoning#attempt-failure
                     _%snapshot30041%_
                     _%digest30043%_
                     'unknown
                     _%query30044%_
                     'solve-failed
                     '(solve)
                     (##structure-ref
                      _%solved30052%_
                      '2
                      gerbil-ascent/candidate/reasoning#captured-stage::t
                      '#f))))))))
    (define gerbil-ascent/candidate/reasoning#attempt-prepare
      (lambda (_%snapshot30029%_
               _%spec30030%_
               _%digest30031%_
               _%proof-steps30032%_
               _%stratified-steps30033%_)
        (let* ((_%query30035%_
                (vector-ref
                 (##structure-ref
                  _%spec30030%_
                  '4
                  gerbil-ascent/candidate/types#reasoning-candidate::t
                  '#f)
                 '0))
               (_%prepared30038%_
                (gerbil-ascent/candidate/reasoning#capture
                 (lambda ()
                   (let ((__tmp34271
                          (let ()
                            (declare (not safe))
                            (gerbil-ascent/candidate/program#candidate-program
                             _%snapshot30029%_
                             _%spec30030%_))))
                     (declare (not safe))
                     (gerbil-ascent/program/scheme-admit#relational-admit/report
                      __tmp34271))))))
          (if (##structure-ref
               _%prepared30038%_
               '1
               gerbil-ascent/candidate/reasoning#captured-stage::t
               '#f)
              (gerbil-ascent/candidate/reasoning#attempt-solve
               _%snapshot30029%_
               _%spec30030%_
               _%digest30031%_
               _%query30035%_
               (##structure-ref
                _%prepared30038%_
                '2
                gerbil-ascent/candidate/reasoning#captured-stage::t
                '#f)
               _%proof-steps30032%_
               _%stratified-steps30033%_)
              (gerbil-ascent/candidate/reasoning#attempt-failure
               _%snapshot30029%_
               _%digest30031%_
               'rejected
               _%query30035%_
               'planner-rejected
               '(program)
               (##structure-ref
                _%prepared30038%_
                '2
                gerbil-ascent/candidate/reasoning#captured-stage::t
                '#f))))))
    (define gerbil-ascent/candidate/reasoning#reasoning-attempt__%
      (lambda (_%snapshot29988%_
               _%candidate29989%_
               _%proof-steps29990%_
               _%stratified-steps29991%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
               _%snapshot29988%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"reasoning attempt requires a current valid source snapshot"
                     _%snapshot29988%_)))
        (if (or (not _%proof-steps29990%_)
                (and (exact-integer? _%proof-steps29990%_)
                     (> _%proof-steps29990%_ '0)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"reasoning attempt requires positive proof work budget or #f"
                     _%proof-steps29990%_)))
        (if (or (not _%stratified-steps29991%_)
                (and (exact-integer? _%stratified-steps29991%_)
                     (> _%stratified-steps29991%_ '0)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"reasoning attempt requires positive stratified work budget"
                     _%stratified-steps29991%_)))
        (let* ((_%digest29999%_
                (gerbil-ascent/candidate/reasoning#candidate-content-digest
                 _%candidate29989%_))
               (_%inspection30002%_
                (gerbil-ascent/candidate/reasoning#capture
                 (lambda ()
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/program#candidate-inspect
                      _%snapshot29988%_
                      _%candidate29989%_))))))
          (if (##structure-ref
               _%inspection30002%_
               '1
               gerbil-ascent/candidate/reasoning#captured-stage::t
               '#f)
              (gerbil-ascent/candidate/reasoning#attempt-prepare
               _%snapshot29988%_
               (##structure-ref
                _%inspection30002%_
                '2
                gerbil-ascent/candidate/reasoning#captured-stage::t
                '#f)
               _%digest29999%_
               _%proof-steps29990%_
               _%stratified-steps29991%_)
              (if (let ((__tmp34272
                         (##structure-ref
                          _%inspection30002%_
                          '2
                          gerbil-ascent/candidate/reasoning#captured-stage::t
                          '#f)))
                    (declare (not safe))
                    (##structure-instance-of?
                     __tmp34272
                     'gerbil-ascent/candidate/types#candidate-rejection::t))
                  (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
                   _%snapshot29988%_
                   _%digest29999%_
                   'rejected
                   '#f
                   '()
                   (list (##structure-ref
                          (##structure-ref
                           _%inspection30002%_
                           '2
                           gerbil-ascent/candidate/reasoning#captured-stage::t
                           '#f)
                          '1
                          gerbil-ascent/candidate/types#candidate-rejection::t
                          '#f))
                   '#f)
                  (gerbil-ascent/candidate/reasoning#attempt-failure
                   _%snapshot29988%_
                   _%digest29999%_
                   'unknown
                   '#f
                   'inspector-failed
                   '(candidate)
                   (##structure-ref
                    _%inspection30002%_
                    '2
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#f)))))))
    (define gerbil-ascent/candidate/reasoning#reasoning-attempt__0
      (lambda (_%snapshot30011%_ _%candidate30012%_)
        (let* ((_%proof-steps30014%_ '100000) (_%stratified-steps30016%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-attempt__%
           _%snapshot30011%_
           _%candidate30012%_
           _%proof-steps30014%_
           _%stratified-steps30016%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-attempt__1
      (lambda (_%snapshot30018%_ _%candidate30019%_ _%proof-steps30020%_)
        (let ((_%stratified-steps30022%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-attempt__%
           _%snapshot30018%_
           _%candidate30019%_
           _%proof-steps30020%_
           _%stratified-steps30022%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-attempt
      (lambda _g34273_
        (let ((_g34274_ (let () (declare (not safe)) (##length _g34273_))))
          (cond ((let () (declare (not safe)) (##fx= _g34274_ 2))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-attempt__0
                        _g34273_))
                ((let () (declare (not safe)) (##fx= _g34274_ 3))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                        _g34273_))
                ((let () (declare (not safe)) (##fx= _g34274_ 4))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-attempt__%
                        _g34273_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/candidate/reasoning#reasoning-attempt
                  _g34273_))))))))
