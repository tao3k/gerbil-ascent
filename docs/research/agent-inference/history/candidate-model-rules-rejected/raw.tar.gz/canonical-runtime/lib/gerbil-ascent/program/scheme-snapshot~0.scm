(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/scheme-snapshot::timestamp 1791687883)
  (begin
    (define gerbil-ascent/program/scheme-snapshot#relational-copy-term
      (lambda (_%term20223%_)
        (let ((_%$e20225%_
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%term20223%_ 'kind))))
          (if (eq? 'variable _%$e20225%_)
              (let ((__tmp36585
                     (let ()
                       (declare (not safe))
                       (clan/poo/object#.ref _%term20223%_ 'value))))
                (declare (not safe))
                (gerbil-ascent/program/objects#gerbil-ascent-variable
                 __tmp36585))
              (if (eq? 'wildcard _%$e20225%_)
                  (let ()
                    (declare (not safe))
                    (gerbil-ascent/program/objects#gerbil-ascent-wildcard))
                  (if (eq? 'literal _%$e20225%_)
                      (let ((_%value20228%_
                             (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref _%term20223%_ 'value))))
                        (if (let ()
                              (declare (not safe))
                              (gerbil-ascent/program/scheme-checked#relational-scalar?
                               _%value20228%_))
                            '#!void
                            (let ()
                              (declare (not safe))
                              (error '"non-scalar relational literal"
                                     _%value20228%_)))
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/program/objects#gerbil-ascent-literal
                           _%value20228%_)))
                      (let ((__tmp36586
                             (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref _%term20223%_ 'kind))))
                        (declare (not safe))
                        (error '"unsupported relational term"
                               __tmp36586))))))))
    (define gerbil-ascent/program/scheme-snapshot#relational-copy-atom
      (lambda (_%atom20221%_)
        (if (eq? (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%atom20221%_ 'ascent-clause-kind))
                 'atom)
            '#!void
            (let ()
              (declare (not safe))
              (error '"unsupported relational clause")))
        (let ((__tmp36588
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%atom20221%_ 'relation)))
              (__tmp36587
               (map gerbil-ascent/program/scheme-snapshot#relational-copy-term
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%atom20221%_ 'terms)))))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-atom
           __tmp36588
           __tmp36587))))
    (define gerbil-ascent/program/scheme-snapshot#relational-copy-clause
      (lambda (_%clause20209%_)
        (let ((_%$e20211%_
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%clause20209%_ 'ascent-clause-kind))))
          (if (eq? 'atom _%$e20211%_)
              (gerbil-ascent/program/scheme-snapshot#relational-copy-atom
               _%clause20209%_)
              (if (eq? 'negation _%$e20211%_)
                  (let ((__tmp36590
                         (let ()
                           (declare (not safe))
                           (clan/poo/object#.ref _%clause20209%_ 'relation)))
                        (__tmp36589
                         (map gerbil-ascent/program/scheme-snapshot#relational-copy-term
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%clause20209%_
                                 'terms)))))
                    (declare (not safe))
                    (gerbil-ascent/program/objects#gerbil-ascent-negation
                     __tmp36590
                     __tmp36589))
                  (if (eq? 'aggregate _%$e20211%_)
                      (let ((_%descriptor20214%_
                             (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref
                                _%clause20209%_
                                'checked-operator)))
                            (_%terms20215%_
                             (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref _%clause20209%_ 'terms))))
                        (if (and (vector? _%descriptor20214%_)
                                 (= (let ()
                                      (declare (not safe))
                                      (##vector-length _%descriptor20214%_))
                                    '6)
                                 (eq? (vector-ref _%descriptor20214%_ '0)
                                      'reduce)
                                 (eq? (vector-ref _%descriptor20214%_ '2)
                                      (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%clause20209%_
                                         'variable)))
                                 (eq? (vector-ref _%descriptor20214%_ '3)
                                      (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%clause20209%_
                                         'relation)))
                                 (equal? (vector-ref _%descriptor20214%_ '4)
                                         (let ()
                                           (declare (not safe))
                                           (clan/poo/object#.ref
                                            _%clause20209%_
                                            'variables)))
                                 (equal? (vector-ref _%descriptor20214%_ '5)
                                         (let ()
                                           (declare (not safe))
                                           (gerbil-ascent/program/scheme-checked#relational-term-fingerprint
                                            _%terms20215%_)))
                                 (not (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%clause20209%_
                                         'output-pattern))))
                            '#!void
                            (let ()
                              (declare (not safe))
                              (error '"untrusted relational reduction")))
                        (let ((__tmp36595 (vector-ref _%descriptor20214%_ '2))
                              (__tmp36594 (vector-ref _%descriptor20214%_ '1))
                              (__tmp36593 (vector-ref _%descriptor20214%_ '4))
                              (__tmp36592 (vector-ref _%descriptor20214%_ '3))
                              (__tmp36591
                               (map gerbil-ascent/program/scheme-snapshot#relational-copy-term
                                    _%terms20215%_)))
                          (declare (not safe))
                          (gerbil-ascent/program/scheme-checked#relational-reducer
                           __tmp36595
                           __tmp36594
                           __tmp36593
                           __tmp36592
                           __tmp36591)))
                      (if (eq? 'guard _%$e20211%_)
                          (let ((_%descriptor20217%_
                                 (let ()
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    _%clause20209%_
                                    'checked-operator))))
                            (if (and (vector? _%descriptor20217%_)
                                     (= (let ()
                                          (declare (not safe))
                                          (##vector-length
                                           _%descriptor20217%_))
                                        '3)
                                     (eq? (vector-ref _%descriptor20217%_ '0)
                                          'where)
                                     (equal? (let ((__tmp36596
                                                    (vector-ref
                                                     _%descriptor20217%_
                                                     '2)))
                                               (declare (not safe))
                                               (gerbil-ascent/program/scheme-checked#relational-operand-variables
                                                __tmp36596))
                                             (let ()
                                               (declare (not safe))
                                               (clan/poo/object#.ref
                                                _%clause20209%_
                                                'variables))))
                                '#!void
                                (let ()
                                  (declare (not safe))
                                  (error '"untrusted relational filter")))
                            (let ((__tmp36598
                                   (vector-ref _%descriptor20217%_ '1))
                                  (__tmp36597
                                   (vector-ref _%descriptor20217%_ '2)))
                              (declare (not safe))
                              (gerbil-ascent/program/scheme-checked#relational-where
                               __tmp36598
                               __tmp36597)))
                          (if (eq? 'binding _%$e20211%_)
                              (let ((_%descriptor20219%_
                                     (let ()
                                       (declare (not safe))
                                       (clan/poo/object#.ref
                                        _%clause20209%_
                                        'checked-operator))))
                                (if (and (vector? _%descriptor20219%_)
                                         (= (let ()
                                              (declare (not safe))
                                              (##vector-length
                                               _%descriptor20219%_))
                                            '4)
                                         (eq? (vector-ref
                                               _%descriptor20219%_
                                               '0)
                                              'compute)
                                         (equal? (let ((__tmp36599
                                                        (vector-ref
                                                         _%descriptor20219%_
                                                         '2)))
                                                   (declare (not safe))
                                                   (gerbil-ascent/program/scheme-checked#relational-operand-variables
                                                    __tmp36599))
                                                 (let ()
                                                   (declare (not safe))
                                                   (clan/poo/object#.ref
                                                    _%clause20209%_
                                                    'variables)))
                                         (eq? (vector-ref
                                               _%descriptor20219%_
                                               '3)
                                              (let ()
                                                (declare (not safe))
                                                (clan/poo/object#.ref
                                                 _%clause20209%_
                                                 'variable))))
                                    '#!void
                                    (let ()
                                      (declare (not safe))
                                      (error '"untrusted relational projection")))
                                (let ((__tmp36602
                                       (vector-ref _%descriptor20219%_ '3))
                                      (__tmp36601
                                       (vector-ref _%descriptor20219%_ '1))
                                      (__tmp36600
                                       (vector-ref _%descriptor20219%_ '2)))
                                  (declare (not safe))
                                  (gerbil-ascent/program/scheme-checked#relational-compute
                                   __tmp36602
                                   __tmp36601
                                   __tmp36600)))
                              (let ((__tmp36603
                                     (let ()
                                       (declare (not safe))
                                       (clan/poo/object#.ref
                                        _%clause20209%_
                                        'ascent-clause-kind))))
                                (declare (not safe))
                                (error '"unsupported relational clause"
                                       __tmp36603))))))))))
    (define gerbil-ascent/program/scheme-snapshot#relational-copy-rule
      (lambda (_%rule20207%_)
        (let ((__tmp36605
               (map gerbil-ascent/program/scheme-snapshot#relational-copy-atom
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%rule20207%_ 'heads))))
              (__tmp36604
               (map gerbil-ascent/program/scheme-snapshot#relational-copy-clause
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%rule20207%_ 'body)))))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-rule
           __tmp36605
           __tmp36604))))
    (define gerbil-ascent/program/scheme-snapshot#relational-snapshot-program
      (lambda (_%program20187%_)
        (let ()
          (declare (not safe))
          (clan/poo/mop#validate
           gerbil-ascent/program/types#GerbilAscentProgramContract
           _%program20187%_))
        (let ((__tmp36611
               (map (lambda (_%relation20189%_)
                      (let* ((_%domain20191%_
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%relation20189%_
                                 'checked-domain)))
                             (_%domains20193%_
                              (if _%domain20191%_
                                  (begin
                                    (if (and (vector? _%domain20191%_)
                                             (= (let ()
                                                  (declare (not safe))
                                                  (##vector-length
                                                   _%domain20191%_))
                                                '2)
                                             (eq? (vector-ref
                                                   _%domain20191%_
                                                   '0)
                                                  'finite-domain))
                                        '#!void
                                        (let ()
                                          (declare (not safe))
                                          (error '"untrusted finite domain descriptor")))
                                    (vector-ref _%domain20191%_ '1))
                                  '#f))
                             (_%name20195%_
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%relation20189%_
                                 'name)))
                             (_%arity20197%_
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%relation20189%_
                                 'arity)))
                             (_%rows20199%_
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%relation20189%_
                                 'rows)))
                             (_%$e20202%_
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%relation20189%_
                                 'storage-kind))))
                        (if (eq? 'relation _%$e20202%_)
                            (if _%domain20191%_
                                (let ()
                                  (declare (not safe))
                                  (gerbil-ascent/program/scheme-checked#relational-finite-source
                                   _%name20195%_
                                   _%arity20197%_
                                   _%rows20199%_
                                   _%domains20193%_))
                                (let ()
                                  (declare (not safe))
                                  (gerbil-ascent/program/scheme-checked#relational-source
                                   _%name20195%_
                                   _%arity20197%_
                                   _%rows20199%_)))
                            (if (eq? 'lattice _%$e20202%_)
                                (let ((_%descriptor20205%_
                                       (let ()
                                         (declare (not safe))
                                         (clan/poo/object#.ref
                                          _%relation20189%_
                                          'checked-operator))))
                                  (if (and (vector? _%descriptor20205%_)
                                           (= (let ()
                                                (declare (not safe))
                                                (##vector-length
                                                 _%descriptor20205%_))
                                              '2)
                                           (eq? (vector-ref
                                                 _%descriptor20205%_
                                                 '0)
                                                'lattice))
                                      '#!void
                                      (let ()
                                        (declare (not safe))
                                        (error '"untrusted relational lattice")))
                                  (if _%domain20191%_
                                      (let ((__tmp36612
                                             (vector-ref
                                              _%descriptor20205%_
                                              '1)))
                                        (declare (not safe))
                                        (gerbil-ascent/program/scheme-checked#relational-finite-lattice
                                         _%name20195%_
                                         _%arity20197%_
                                         _%rows20199%_
                                         __tmp36612
                                         _%domains20193%_))
                                      (let ((__tmp36613
                                             (vector-ref
                                              _%descriptor20205%_
                                              '1)))
                                        (declare (not safe))
                                        (gerbil-ascent/program/scheme-checked#relational-checked-lattice
                                         _%name20195%_
                                         _%arity20197%_
                                         _%rows20199%_
                                         __tmp36613))))
                                (let ()
                                  (declare (not safe))
                                  (error '"unsupported relational storage kind"))))))
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%program20187%_ 'relations))))
              (__tmp36610
               (map gerbil-ascent/program/scheme-snapshot#relational-copy-rule
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%program20187%_ 'rules))))
              (__tmp36609
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%program20187%_ 'max-input-facts)))
              (__tmp36608
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%program20187%_ 'max-derived-facts)))
              (__tmp36607
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%program20187%_ 'max-output-facts)))
              (__tmp36606
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%program20187%_ 'source-handles))))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-program__%
           __tmp36611
           __tmp36610
           __tmp36609
           __tmp36608
           __tmp36607
           __tmp36606))))))
