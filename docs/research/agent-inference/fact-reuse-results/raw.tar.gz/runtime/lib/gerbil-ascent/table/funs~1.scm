(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/funs[:0:]#gerbil-ascent-index-batch!|
    (lambda (_%$stx8621%_)
      (let* ((_%$%g86258651%_
              (lambda (_%$%g86268647%_)
                (let ()
                  (declare (not safe))
                  (gx#raise-syntax-error
                   '#f
                   '"Bad syntax; invalid match target"
                   _%$%g86268647%_))))
             (_%$%g86248737%_
              (lambda (_%$%g86268655%_)
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair? _%$%g86268655%_))
                    (let ((_%$%e86318658%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%$%g86268655%_))))
                      (let ((_%$%hd86328662%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e86318658%_)))
                            (_%$%tl86338665%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e86318658%_))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair? _%$%tl86338665%_))
                            (let ((_%$%e86348668%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-e _%$%tl86338665%_))))
                              (let ((_%$%hd86358672%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e86348668%_)))
                                    (_%$%tl86368675%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e86348668%_))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%tl86368675%_))
                                    (let ((_%$%e86378678%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e _%$%tl86368675%_))))
                                      (let ((_%$%hd86388682%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e86378678%_)))
                                            (_%$%tl86398685%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e86378678%_))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair? _%$%tl86398685%_))
                                            (let ((_%$%e86408688%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl86398685%_))))
                                              (let ((_%$%hd86418692%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e86408688%_)))
                                                    (_%$%tl86428695%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e86408688%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair?
                                                       _%$%tl86428695%_))
                                                    (let ((_%$%e86438698%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-e
                                                              _%$%tl86428695%_))))
                                                      (let ((_%$%hd86448702%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##car _%$%e86438698%_)))
                    (_%$%tl86458705%_
                     (let () (declare (not safe)) (##cdr _%$%e86438698%_))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl86458705%_))
                    (cons (let ()
                            (declare (not safe))
                            (gx#datum->syntax__0 '#f 'let*))
                          (cons (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'target))
                                            (cons _%$%hd86358672%_ '()))
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'row-slot))
                                                  (cons (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'vector))
                      (cons '#f '()))
                '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (cons (cons (let ()
                                                          (declare (not safe))
                                                          (gx#datum->syntax__0
                                                           '#f
                                                           'prepend-row))
                                                        (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'lambda))
                            (cons (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'bucket))
                                        '())
                                  (cons (cons (let ()
                                                (declare (not safe))
                                                (gx#datum->syntax__0
                                                 '#f
                                                 'cons))
                                              (cons (cons (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#datum->syntax__0
                                                             '#f
                                                             'vector-ref))
                                                          (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'row-slot))
                        (cons '0 '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'or))
                        (cons (let ()
                                (declare (not safe))
                                (gx#datum->syntax__0 '#f 'bucket))
                              (cons (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0 '#f '@list))
                                          '())
                                    '())))
                  '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        '())))
                      '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  '())))
                                (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'for-each))
                                            (cons (cons (let ()
                                                          (declare (not safe))
                                                          (gx#datum->syntax__0
                                                           '#f
                                                           'lambda))
                                                        (cons (cons _%$%hd86418692%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            '())
                      (cons (cons (let ()
                                    (declare (not safe))
                                    (gx#datum->syntax__0 '#f 'let))
                                  (cons (cons (let ()
                                                (declare (not safe))
                                                (gx#datum->syntax__0
                                                 '#f
                                                 'selected))
                                              (cons _%$%hd86448702%_ '()))
                                        (cons (cons (let ()
                                                      (declare (not safe))
                                                      (gx#datum->syntax__0
                                                       '#f
                                                       'vector-set!))
                                                    (cons (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#datum->syntax__0
                                                             '#f
                                                             'row-slot))
                                                          (cons '0
                                                                (cons _%$%hd86418692%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (cons (cons (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#datum->syntax__0
                                                             '#f
                                                             'hash-update!))
                                                          (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'target))
                        (cons (let ()
                                (declare (not safe))
                                (gx#datum->syntax__0 '#f 'selected))
                              (cons (let ()
                                      (declare (not safe))
                                      (gx#datum->syntax__0 '#f 'prepend-row))
                                    (cons '#f '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '()))))
                            '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons _%$%hd86388682%_ '())))
                                      (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'target))
                                            '()))))
                    (_%$%g86258651%_ _%$%g86268655%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%g86258651%_
                                                     _%$%g86268655%_))))
                                            (_%$%g86258651%_
                                             _%$%g86268655%_))))
                                    (_%$%g86258651%_ _%$%g86268655%_))))
                            (_%$%g86258651%_ _%$%g86268655%_))))
                    (_%$%g86258651%_ _%$%g86268655%_)))))
        (_%$%g86248737%_ _%$stx8621%_))))
  (define |gerbil-ascent/table/funs[:0:]#forward-key-step|
    (lambda (_%$stx8741%_)
      (let* ((_%$%g87458786%_
              (lambda (_%$%g87468782%_)
                (let ()
                  (declare (not safe))
                  (gx#raise-syntax-error
                   '#f
                   '"Bad syntax; invalid match target"
                   _%$%g87468782%_))))
             (_%$%g87448923%_
              (lambda (_%$%g87468790%_)
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair? _%$%g87468790%_))
                    (let ((_%$%e87548793%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%$%g87468790%_))))
                      (let ((_%$%hd87558797%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e87548793%_)))
                            (_%$%tl87568800%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e87548793%_))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair? _%$%tl87568800%_))
                            (let ((_%$%e87578803%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-e _%$%tl87568800%_))))
                              (let ((_%$%hd87588807%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e87578803%_)))
                                    (_%$%tl87598810%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e87578803%_))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%tl87598810%_))
                                    (let ((_%$%e87608813%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e _%$%tl87598810%_))))
                                      (let ((_%$%hd87618817%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e87608813%_)))
                                            (_%$%tl87628820%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e87608813%_))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair? _%$%tl87628820%_))
                                            (let ((_%$%e87638823%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl87628820%_))))
                                              (let ((_%$%hd87648827%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e87638823%_)))
                                                    (_%$%tl87658830%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e87638823%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair?
                                                       _%$%hd87648827%_))
                                                    (let ((_%$%e87668833%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-e
                                                              _%$%hd87648827%_))))
                                                      (let ((_%$%hd87678837%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##car _%$%e87668833%_)))
                    (_%$%tl87688840%_
                     (let () (declare (not safe)) (##cdr _%$%e87668833%_))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair? _%$%tl87688840%_))
                    (let ((_%$%e87698843%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%$%tl87688840%_))))
                      (let ((_%$%hd87708847%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e87698843%_)))
                            (_%$%tl87718850%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e87698843%_))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair? _%$%tl87718850%_))
                            (let ((_%$%e87728853%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-e _%$%tl87718850%_))))
                              (let ((_%$%hd87738857%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e87728853%_)))
                                    (_%$%tl87748860%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e87728853%_))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl87748860%_))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%tl87658830%_))
                                        (let ((_%$%e87758863%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%tl87658830%_))))
                                          (let ((_%$%hd87768867%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e87758863%_)))
                                                (_%$%tl87778870%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e87758863%_))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair?
                                                   _%$%tl87778870%_))
                                                (let ((_%$%e87788873%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-e
                                                          _%$%tl87778870%_))))
                                                  (let ((_%$%hd87798877%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e87788873%_)))
                                                        (_%$%tl87808880%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e87788873%_))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl87808880%_))
                                                        (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'match))
                      (cons _%$%hd87618817%_
                            (cons (cons (cons (let ()
                                                (declare (not safe))
                                                (gx#datum->syntax__0
                                                 '#f
                                                 '@list))
                                              '())
                                        (cons (cons (let ()
                                                      (declare (not safe))
                                                      (gx#datum->syntax__0
                                                       '#f
                                                       '@list))
                                                    '())
                                              '()))
                                  (cons (cons (cons (let ()
                                                      (declare (not safe))
                                                      (gx#datum->syntax__0
                                                       '#f
                                                       '@list))
                                                    (cons _%$%hd87678837%_
                                                          _%$%hd87708847%_))
                                              (cons (cons (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#datum->syntax__0
                                                             '#f
                                                             'let))
                                                          (cons (cons _%$%hd87738857%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0
                                             '#f
                                             'list-tail))
                                          (cons _%$%hd87588807%_
                                                (cons _%$%hd87768867%_ '())))
                                    '()))
                        (cons (cons (let ()
                                      (declare (not safe))
                                      (gx#datum->syntax__0 '#f 'cons))
                                    (cons (cons (let ()
                                                  (declare (not safe))
                                                  (gx#datum->syntax__0
                                                   '#f
                                                   'car))
                                                (cons _%$%hd87738857%_ '()))
                                          (cons _%$%hd87798877%_ '())))
                              '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '()))
                                        '()))))
                (_%$%g87458786%_ _%$%g87468790%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (_%$%g87458786%_
                                                 _%$%g87468790%_))))
                                        (_%$%g87458786%_ _%$%g87468790%_))
                                    (_%$%g87458786%_ _%$%g87468790%_))))
                            (_%$%g87458786%_ _%$%g87468790%_))))
                    (_%$%g87458786%_ _%$%g87468790%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%g87458786%_
                                                     _%$%g87468790%_))))
                                            (_%$%g87458786%_
                                             _%$%g87468790%_))))
                                    (_%$%g87458786%_ _%$%g87468790%_))))
                            (_%$%g87458786%_ _%$%g87468790%_))))
                    (_%$%g87458786%_ _%$%g87468790%_)))))
        (_%$%g87448923%_ _%$stx8741%_)))))
