(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/provider::timestamp 1791690991)
  (begin
    (define gerbil-ascent/table/provider#+procedure+
      (let ((__tmp34888 (lambda (_%_value4286%_ _%_context4287%_) '())))
        (declare (not safe))
        (core/types#poo-flow-predicate-contract
         'ascent/index-provider-procedure
         procedure?
         __tmp34888)))
    (define gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
      (let ((__obj34885
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp34890
               (list (cons 'sexp
                           (let ((__tmp34891
                                  (lambda (_%@4226%_)
                                    'GerbilAscentIndexProviderContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34891)))
                     (cons 'identity
                           (let ((__tmp34892
                                  (lambda (_%@4232%_) 'ascent/index-provider)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34892)))
                     (cons 'proto
                           (let ((__tmp34893
                                  (lambda (_%@4237%_)
                                    (let ((__obj34883
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp34895 (list))
                                            (__tmp34894 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp34895
                                         __tmp34894
                                         __obj34883))
                                      __obj34883))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34893)))
                     (cons 'responsibilities
                           (let ((__tmp34896
                                  (lambda (_%@4251%_)
                                    (let ((__obj34884
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp34898
                                             (list (cons '.build-index
                                                         (let ((__tmp34899
                                                                (lambda (_%self4269%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/table/provider#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp34899)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.extend-index!
                                                         (let ((__tmp34900
                                                                (lambda (_%self4276%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/table/provider#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp34900)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.lookup-index
                                                         (let ((__tmp34901
                                                                (lambda (_%self4281%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/table/provider#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp34901)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp34897 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp34898
                                         __tmp34897
                                         __obj34884))
                                      __obj34884))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34896)))))
              (__tmp34889 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp34890
           __tmp34889
           __obj34885))
        __obj34885))
    (define gerbil-ascent/table/provider#IndexProvider.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
         'proto)))
    (define gerbil-ascent/table/provider#gerbil-ascent-index-provider-build
      (lambda (_%provider4209%_ _%rows4210%_ _%columns4211%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%provider4209%_ '.build-index))
         _%rows4210%_
         _%columns4211%_)))
    (define gerbil-ascent/table/provider#gerbil-ascent-index-provider-extend!
      (lambda (_%provider4204%_ _%index4205%_ _%rows4206%_ _%columns4207%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%provider4204%_ '.extend-index!))
         _%index4205%_
         _%rows4206%_
         _%columns4207%_)))
    (define gerbil-ascent/table/provider#gerbil-ascent-index-provider-lookup
      (lambda (_%provider4200%_ _%index4201%_ _%key4202%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%provider4200%_ '.lookup-index))
         _%index4201%_
         _%key4202%_)))
    (define gerbil-ascent/table/provider#+canonical-hash-index-provider+
      (let ((__tmp34902
             (let ((__obj34886
                    (let ()
                      (declare (not safe))
                      (##structure
                       clan/poo/object#object::t
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f))))
               (let ((__tmp34904
                      (list (cons '.build-index
                                  (let ((__tmp34905
                                         (lambda (_%@4178%_)
                                           gerbil-ascent/table/funs#gerbil-ascent-index-build)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp34905)))
                            (cons '.extend-index!
                                  (let ((__tmp34906
                                         (lambda (_%@4184%_)
                                           gerbil-ascent/table/funs#gerbil-ascent-index-extend!)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp34906)))
                            (cons '.lookup-index
                                  (let ((__tmp34907
                                         (lambda (_%@4189%_)
                                           (lambda (_%index4194%_ _%key4195%_)
                                             (let ((_%$e4197%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (hash-get
                                                       _%index4194%_
                                                       _%key4195%_))))
                                               (if _%$e4197%_
                                                   _%$e4197%_
                                                   '()))))))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp34907)))))
                     (__tmp34903 (list)))
                 (declare (not safe))
                 (clan/poo/object#object:::init!__%
                  '#f
                  gerbil-ascent/table/provider#IndexProvider.
                  __tmp34904
                  __tmp34903
                  __obj34886))
               __obj34886)))
        (declare (not safe))
        (clan/poo/mop#validate
         gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
         __tmp34902)))
    (define gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider
      gerbil-ascent/table/provider#+canonical-hash-index-provider+)
    (define gerbil-ascent/table/provider#+curried-index-provider+
      (let ((__tmp34908
             (let ((__obj34887
                    (let ()
                      (declare (not safe))
                      (##structure
                       clan/poo/object#object::t
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f))))
               (let ((__tmp34910
                      (list (cons '.build-index
                                  (let ((__tmp34911
                                         (lambda (_%@4144%_)
                                           gerbil-ascent/table/funs#gerbil-ascent-index-build)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp34911)))
                            (cons '.extend-index!
                                  (let ((__tmp34912
                                         (lambda (_%@4150%_)
                                           gerbil-ascent/table/funs#gerbil-ascent-index-extend!)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp34912)))
                            (cons '.lookup-index
                                  (let ((__tmp34913
                                         (lambda (_%@4155%_)
                                           (lambda (_%index4160%_ _%key4161%_)
                                             (let ((_%$e4163%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (hash-get
                                                       _%index4160%_
                                                       _%key4161%_))))
                                               (if _%$e4163%_
                                                   _%$e4163%_
                                                   '()))))))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp34913)))))
                     (__tmp34909 (list)))
                 (declare (not safe))
                 (clan/poo/object#object:::init!__%
                  '#f
                  gerbil-ascent/table/provider#IndexProvider.
                  __tmp34910
                  __tmp34909
                  __obj34887))
               __obj34887)))
        (declare (not safe))
        (clan/poo/mop#validate
         gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
         __tmp34908)))
    (define gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider
      gerbil-ascent/table/provider#+curried-index-provider+)
    (define gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider?
      (lambda (_%value4129%_)
        (eq? _%value4129%_
             gerbil-ascent/table/provider#+curried-index-provider+)))
    (define gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
      (lambda (_%value4124%_)
        (let ((_%$e4126%_
               (eq? _%value4124%_
                    gerbil-ascent/table/provider#+canonical-hash-index-provider+)))
          (if _%$e4126%_
              _%$e4126%_
              (eq? _%value4124%_
                   gerbil-ascent/table/provider#+curried-index-provider+)))))))
