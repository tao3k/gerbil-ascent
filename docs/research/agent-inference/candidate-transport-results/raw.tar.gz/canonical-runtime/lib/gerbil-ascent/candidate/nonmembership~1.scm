(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34149_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34151_|
    (##structure
     gx#syntax-quote::t
     'make-positive-nonmembership
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34153_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34155_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34156_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34157_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34158_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34159_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34160_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-program-fingerprint
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34161_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34162_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34163_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-closure
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34165_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34166_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34167_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34168_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34169_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34170_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-program-fingerprint-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34171_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34172_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34173_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-closure-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34175_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34176_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34177_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34178_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34179_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34180_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-program-fingerprint
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34181_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34182_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34183_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-closure
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34185_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34186_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34187_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34188_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34189_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34190_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-program-fingerprint-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34191_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34192_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34193_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-closure-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[:0:]#positive-nonmembership|
    (let ((__obj34103
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34103
         'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34103
         'positive-nonmembership
         '3
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34103
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  program-fingerprint
                  query
                  work-budget
                  closure)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34103
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  program-fingerprint
                  query
                  work-budget
                  closure)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34103 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34103 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34103 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34103 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34103 '#f '13 '#f '#f))
      (let ((__tmp34148 |gerbil-ascent/candidate/nonmembership[1]#_g34149_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34103 __tmp34148 '4 '#f '#f))
      (let ((__tmp34150 |gerbil-ascent/candidate/nonmembership[1]#_g34151_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34103 __tmp34150 '14 '#f '#f))
      (let ((__tmp34152 |gerbil-ascent/candidate/nonmembership[1]#_g34153_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34103 __tmp34152 '15 '#f '#f))
      (let ((__tmp34154
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g34155_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g34156_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g34157_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g34158_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g34159_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g34160_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g34161_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g34162_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g34163_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj34103 __tmp34154 '16 '#f '#f))
      (let ((__tmp34164
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g34165_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g34166_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g34167_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g34168_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g34169_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g34170_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g34171_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g34172_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g34173_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj34103 __tmp34164 '17 '#f '#f))
      (let ((__tmp34174
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g34175_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g34176_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g34177_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g34178_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g34179_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g34180_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g34181_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g34182_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g34183_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj34103 __tmp34174 '18 '#f '#f))
      (let ((__tmp34184
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g34185_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g34186_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g34187_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g34188_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g34189_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g34190_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g34191_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g34192_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g34193_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj34103 __tmp34184 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34103 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34103 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34103 '() '21 '#f '#f))
      __obj34103)))
