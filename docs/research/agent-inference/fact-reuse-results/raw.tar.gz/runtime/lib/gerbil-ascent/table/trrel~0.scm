(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/trrel::timestamp 1791687544)
  (begin
    (define gerbil-ascent/table/trrel#trrel-state::t
      (let ((__tmp5749 (list)) (__tmp5748 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/trrel#trrel-state::t
         'trrel-state
         __tmp5749
         '(known predecessors successors)
         __tmp5748
         '#f)))
    (define gerbil-ascent/table/trrel#trrel-state?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/trrel#trrel-state::t)))
    (define gerbil-ascent/table/trrel#make-trrel-state
      (lambda _%$args5745%_
        (apply make-instance
               gerbil-ascent/table/trrel#trrel-state::t
               _%$args5745%_)))
    (define gerbil-ascent/table/trrel#trrel-state-known
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel#trrel-state::t
         'known)))
    (define gerbil-ascent/table/trrel#trrel-state-predecessors
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel#trrel-state::t
         'predecessors)))
    (define gerbil-ascent/table/trrel#trrel-state-successors
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel#trrel-state::t
         'successors)))
    (define gerbil-ascent/table/trrel#trrel-state-known-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel#trrel-state::t
         'known)))
    (define gerbil-ascent/table/trrel#trrel-state-predecessors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel#trrel-state::t
         'predecessors)))
    (define gerbil-ascent/table/trrel#trrel-state-successors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel#trrel-state::t
         'successors)))
    (define gerbil-ascent/table/trrel#&trrel-state-known
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel#trrel-state::t
         'known)))
    (define gerbil-ascent/table/trrel#&trrel-state-predecessors
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel#trrel-state::t
         'predecessors)))
    (define gerbil-ascent/table/trrel#&trrel-state-successors
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel#trrel-state::t
         'successors)))
    (define gerbil-ascent/table/trrel#&trrel-state-known-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel#trrel-state::t
         'known)))
    (define gerbil-ascent/table/trrel#&trrel-state-predecessors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel#trrel-state::t
         'predecessors)))
    (define gerbil-ascent/table/trrel#&trrel-state-successors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel#trrel-state::t
         'successors)))
    (define gerbil-ascent/table/trrel#gerbil-ascent-trrel-state
      (lambda ()
        (let ((__tmp5752
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value)))
              (__tmp5751
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value)))
              (__tmp5750
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (declare (not safe))
          (##structure
           gerbil-ascent/table/trrel#trrel-state::t
           __tmp5752
           __tmp5751
           __tmp5750))))
    (define gerbil-ascent/table/trrel#gerbil-ascent-trrel-extend
      (lambda (_%state5369%_ _%row5370%_ _%budget5371%_ _%reflexive?5372%_)
        (let* ((_%width5374%_ (length _%row5370%_))
               (_%_5376%_
                (if (let () (declare (not safe)) (##memq _%width5374%_ '(2 3)))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"ASCENT trrel requires two or three columns"
                             _%row5370%_))))
               (_%group5378%_ (if (= _%width5374%_ '3) (car _%row5370%_) '#f))
               (_%pair5380%_
                (if (= _%width5374%_ '3) (cdr _%row5370%_) _%row5370%_))
               (_%left5382%_ (car _%pair5380%_))
               (_%right5384%_ (cadr _%pair5380%_))
               (_%known5386%_
                (##structure-ref
                 _%state5369%_
                 '1
                 gerbil-ascent/table/trrel#trrel-state::t
                 '#f))
               (_%new-edge?5416%_
                (not (let* ((_%h5388%_ _%known5386%_)
                            (_%key5391%_ _%row5370%_)
                            (_%h5395%_
                             (let ()
                               (declare (not safe))
                               (cast HashTable::interface _%h5388%_)))
                            (_%h5397%_ _%h5395%_))
                       (declare (not safe))
                       (__hash-get _%h5397%_ _%key5391%_))))
               (_%predecessors5418%_
                (##structure-ref
                 _%state5369%_
                 '2
                 gerbil-ascent/table/trrel#trrel-state::t
                 '#f))
               (_%successors5420%_
                (##structure-ref
                 _%state5369%_
                 '3
                 gerbil-ascent/table/trrel#trrel-state::t
                 '#f))
               (_%added5422%_ '())
               (_%planned5424%_ '#f)
               (_%planned-count5426%_ '0)
               (_%safe-budget?5428%_ '#f))
          (letrec ((_%node-key5431%_
                    (lambda (_%node5742%_)
                      (if (= _%width5374%_ '3)
                          (cons _%group5378%_ _%node5742%_)
                          _%node5742%_)))
                   (_%fact5432%_
                    (lambda (_%from5739%_ _%to5740%_)
                      (if (= _%width5374%_ '3)
                          (list _%group5378%_ _%from5739%_ _%to5740%_)
                          (list _%from5739%_ _%to5740%_))))
                   (_%with-root5433%_
                    (lambda (_%node5715%_ _%neighbors5716%_)
                      (if (let* ((_%h5718%_ _%known5386%_)
                                 (_%key5721%_
                                  (_%fact5432%_ _%node5715%_ _%node5715%_))
                                 (_%h5725%_
                                  (let ()
                                    (declare (not safe))
                                    (cast HashTable::interface _%h5718%_)))
                                 (_%h5727%_ _%h5725%_))
                            (declare (not safe))
                            (__hash-get _%h5727%_ _%key5721%_))
                          _%neighbors5716%_
                          (cons _%node5715%_ _%neighbors5716%_))))
                   (_%commit-fact!5434%_
                    (lambda (_%row5577%_)
                      (let* ((_%pair5579%_
                              (if (= _%width5374%_ '3)
                                  (cdr _%row5577%_)
                                  _%row5577%_))
                             (_%from5581%_ (car _%pair5579%_))
                             (_%to5583%_ (cadr _%pair5579%_))
                             (_%from-key5585%_ (_%node-key5431%_ _%from5581%_))
                             (_%to-key5587%_ (_%node-key5431%_ _%to5583%_)))
                        (let* ((_%h5590%_ _%known5386%_)
                               (_%key5593%_ _%row5577%_)
                               (_%value5596%_ '#t)
                               (_%h5600%_
                                (let ()
                                  (declare (not safe))
                                  (cast HashTable::interface _%h5590%_)))
                               (_%h5602%_ _%h5600%_))
                          (declare (not safe))
                          (__hash-put! _%h5602%_ _%key5593%_ _%value5596%_))
                        (let* ((_%h5621%_ _%successors5420%_)
                               (_%key5624%_ _%from-key5585%_)
                               (_%value5652%_
                                (cons _%to5583%_
                                      (let ((_%$e5649%_
                                             (let* ((_%h5627%_
                                                     _%successors5420%_)
                                                    (_%key5630%_
                                                     _%from-key5585%_)
                                                    (_%h5634%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (cast HashTable::interface
                                                             _%h5627%_)))
                                                    (_%h5636%_ _%h5634%_))
                                               (declare (not safe))
                                               (__hash-get
                                                _%h5636%_
                                                _%key5630%_))))
                                        (if _%$e5649%_ _%$e5649%_ '()))))
                               (_%h5656%_
                                (let ()
                                  (declare (not safe))
                                  (cast HashTable::interface _%h5621%_)))
                               (_%h5658%_ _%h5656%_))
                          (declare (not safe))
                          (__hash-put! _%h5658%_ _%key5624%_ _%value5652%_))
                        (let* ((_%h5668%_ _%predecessors5418%_)
                               (_%key5671%_ _%to-key5587%_)
                               (_%value5699%_
                                (cons _%from5581%_
                                      (let ((_%$e5696%_
                                             (let* ((_%h5674%_
                                                     _%predecessors5418%_)
                                                    (_%key5677%_
                                                     _%to-key5587%_)
                                                    (_%h5681%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (cast HashTable::interface
                                                             _%h5674%_)))
                                                    (_%h5683%_ _%h5681%_))
                                               (declare (not safe))
                                               (__hash-get
                                                _%h5683%_
                                                _%key5677%_))))
                                        (if _%$e5696%_ _%$e5696%_ '()))))
                               (_%h5703%_
                                (let ()
                                  (declare (not safe))
                                  (cast HashTable::interface _%h5668%_)))
                               (_%h5705%_ _%h5703%_))
                          (declare (not safe))
                          (__hash-put! _%h5705%_ _%key5671%_ _%value5699%_)))))
                   (_%emit!5435%_
                    (lambda (_%from5502%_ _%to5503%_)
                      (let ((_%row5505%_
                             (_%fact5432%_ _%from5502%_ _%to5503%_)))
                        (if (or (let* ((_%h5507%_ _%known5386%_)
                                       (_%key5510%_ _%row5505%_)
                                       (_%h5514%_
                                        (let ()
                                          (declare (not safe))
                                          (cast HashTable::interface
                                                _%h5507%_)))
                                       (_%h5516%_ _%h5514%_))
                                  (declare (not safe))
                                  (__hash-get _%h5516%_ _%key5510%_))
                                (and _%planned5424%_
                                     (let* ((_%h5532%_ _%planned5424%_)
                                            (_%key5535%_ _%row5505%_)
                                            (_%h5539%_
                                             (let ()
                                               (declare (not safe))
                                               (cast HashTable::interface
                                                     _%h5532%_)))
                                            (_%h5541%_ _%h5539%_))
                                       (declare (not safe))
                                       (__hash-get _%h5541%_ _%key5535%_))))
                            '#!void
                            (begin
                              (if _%safe-budget?5428%_
                                  '#!void
                                  (begin
                                    (set! _%planned-count5426%_
                                          (+ _%planned-count5426%_ '1))
                                    (if (> _%planned-count5426%_
                                           _%budget5371%_)
                                        (let ()
                                          (declare (not safe))
                                          (error '"ASCENT trrel output fact budget exceeded"))
                                        '#!void)
                                    (let* ((_%h5553%_ _%planned5424%_)
                                           (_%key5556%_ _%row5505%_)
                                           (_%value5559%_ '#t)
                                           (_%h5563%_
                                            (let ()
                                              (declare (not safe))
                                              (cast HashTable::interface
                                                    _%h5553%_)))
                                           (_%h5565%_ _%h5563%_))
                                      (declare (not safe))
                                      (__hash-put!
                                       _%h5565%_
                                       _%key5556%_
                                       _%value5559%_))))
                              (if _%safe-budget?5428%_
                                  (_%commit-fact!5434%_ _%row5505%_)
                                  '#!void)
                              (set! _%added5422%_
                                    (cons _%row5505%_ _%added5422%_))))))))
            (let ((_%from-nodes5492%_
                   (if _%new-edge?5416%_
                       (_%with-root5433%_
                        _%left5382%_
                        (let ((_%$e5466%_
                               (let* ((_%h5437%_ _%predecessors5418%_)
                                      (_%key5440%_
                                       (_%node-key5431%_ _%left5382%_))
                                      (_%h5444%_
                                       (let ()
                                         (declare (not safe))
                                         (cast HashTable::interface
                                               _%h5437%_)))
                                      (_%h5446%_ _%h5444%_))
                                 (declare (not safe))
                                 (__hash-get _%h5446%_ _%key5440%_))))
                          (if _%$e5466%_ _%$e5466%_ '())))
                       '()))
                  (_%to-nodes5493%_
                   (if _%new-edge?5416%_
                       (_%with-root5433%_
                        _%right5384%_
                        (let ((_%$e5489%_
                               (let* ((_%h5469%_ _%successors5420%_)
                                      (_%key5472%_
                                       (_%node-key5431%_ _%right5384%_))
                                      (_%h5476%_
                                       (let ()
                                         (declare (not safe))
                                         (cast HashTable::interface
                                               _%h5469%_)))
                                      (_%h5478%_ _%h5476%_))
                                 (declare (not safe))
                                 (__hash-get _%h5478%_ _%key5472%_))))
                          (if _%$e5489%_ _%$e5489%_ '())))
                       '())))
              (set! _%safe-budget?5428%_
                    (<= (+ (* (length _%from-nodes5492%_)
                              (length _%to-nodes5493%_))
                           (if _%reflexive?5372%_ '2 '0))
                        _%budget5371%_))
              (if _%safe-budget?5428%_
                  '#!void
                  (set! _%planned5424%_
                        (let ()
                          (declare (not safe))
                          (make-hash-table__%
                           '#f
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value))))
              (if _%new-edge?5416%_
                  (for-each
                   (lambda (_%from5495%_)
                     (for-each
                      (lambda (_%to5497%_)
                        (if (or (not (equal? _%from5495%_ _%to5497%_))
                                (and (equal? _%left5382%_ _%right5384%_)
                                     (equal? _%from5495%_ _%left5382%_)))
                            (_%emit!5435%_ _%from5495%_ _%to5497%_)
                            '#!void))
                      _%to-nodes5493%_))
                   _%from-nodes5492%_)
                  '#!void))
            (if _%reflexive?5372%_
                (begin
                  (_%emit!5435%_ _%left5382%_ _%left5382%_)
                  (_%emit!5435%_ _%right5384%_ _%right5384%_))
                '#!void)
            (if _%safe-budget?5428%_
                '#!void
                (let ()
                  (declare (not safe))
                  (##for-each _%commit-fact!5434%_ _%added5422%_)))
            (let () (declare (not safe)) (##reverse _%added5422%_))))))
    (define gerbil-ascent/table/trrel#gerbil-ascent-trrel-extension
      (lambda (_%state5363%_
               _%_all5364%_
               _%_pending5365%_
               _%row5366%_
               _%budget5367%_)
        (gerbil-ascent/table/trrel#gerbil-ascent-trrel-extend
         _%state5363%_
         _%row5366%_
         _%budget5367%_
         '#f)))))
