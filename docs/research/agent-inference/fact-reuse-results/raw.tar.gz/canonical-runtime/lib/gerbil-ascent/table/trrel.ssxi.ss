prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/table

(begin
  (declare-class
   gerbil-ascent/table/trrel#trrel-state::t
   (@class gerbil-ascent/table/trrel#trrel-state::t
           ()
           (object::t t::t)
           (known predecessors successors)
           (known predecessors successors)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/table/trrel#trrel-state::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/trrel#trrel-state::t)
    'class::t))
  (declare-type
   gerbil-ascent/table/trrel#trrel-state?
   (@predicate gerbil-ascent/table/trrel#trrel-state::t))
  (declare-type
   gerbil-ascent/table/trrel#make-trrel-state
   (@constructor gerbil-ascent/table/trrel#trrel-state::t))
  (declare-type
   gerbil-ascent/table/trrel#trrel-state-known
   (@accessor gerbil-ascent/table/trrel#trrel-state::t known #t))
  (declare-type
   gerbil-ascent/table/trrel#trrel-state-predecessors
   (@accessor gerbil-ascent/table/trrel#trrel-state::t predecessors #t))
  (declare-type
   gerbil-ascent/table/trrel#trrel-state-successors
   (@accessor gerbil-ascent/table/trrel#trrel-state::t successors #t))
  (declare-type
   gerbil-ascent/table/trrel#trrel-state-known-set!
   (@mutator gerbil-ascent/table/trrel#trrel-state::t known #t))
  (declare-type
   gerbil-ascent/table/trrel#trrel-state-predecessors-set!
   (@mutator gerbil-ascent/table/trrel#trrel-state::t predecessors #t))
  (declare-type
   gerbil-ascent/table/trrel#trrel-state-successors-set!
   (@mutator gerbil-ascent/table/trrel#trrel-state::t successors #t))
  (declare-type
   gerbil-ascent/table/trrel#&trrel-state-known
   (@accessor gerbil-ascent/table/trrel#trrel-state::t known #f))
  (declare-type
   gerbil-ascent/table/trrel#&trrel-state-predecessors
   (@accessor gerbil-ascent/table/trrel#trrel-state::t predecessors #f))
  (declare-type
   gerbil-ascent/table/trrel#&trrel-state-successors
   (@accessor gerbil-ascent/table/trrel#trrel-state::t successors #f))
  (declare-type
   gerbil-ascent/table/trrel#&trrel-state-known-set!
   (@mutator gerbil-ascent/table/trrel#trrel-state::t known #f))
  (declare-type
   gerbil-ascent/table/trrel#&trrel-state-predecessors-set!
   (@mutator gerbil-ascent/table/trrel#trrel-state::t predecessors #f))
  (declare-type
   gerbil-ascent/table/trrel#&trrel-state-successors-set!
   (@mutator gerbil-ascent/table/trrel#trrel-state::t successors #f))
  (declare-type
   gerbil-ascent/table/trrel#gerbil-ascent-trrel-state
   (@lambda 0
            #f
            signature:
            (return:
             gerbil-ascent/table/trrel#trrel-state::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel)))
  (declare-type
   gerbil-ascent/table/trrel#gerbil-ascent-trrel-extend
   (@lambda 4
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel)))
  (declare-type
   gerbil-ascent/table/trrel#gerbil-ascent-trrel-extension
   (@lambda 5
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel))))
