(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/proof-frame::timestamp 1791693096)
  (begin
    (define gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
      (let ((__tmp33871 (list))
            (__tmp33870
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'proof-binding-flow
         __tmp33871
         '(fresh head clauses)
         __tmp33870
         '#f)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-flow?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t)))
    (define gerbil-ascent/candidate/proof-frame#make-proof-binding-flow
      (lambda _%$args29293%_
        (apply make-instance
               gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
               _%$args29293%_)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-flow-fresh
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'fresh)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-flow-head
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'head)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-flow-clauses
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'clauses)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-flow-fresh-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'fresh)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-flow-head-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'head)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-flow-clauses-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'clauses)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-flow-fresh
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'fresh)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-flow-head
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'head)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-flow-clauses
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'clauses)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-flow-fresh-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'fresh)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-flow-head-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'head)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-flow-clauses-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'clauses)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
      (let ((__tmp33873 (list))
            (__tmp33872
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
         'proof-binding-clause
         __tmp33873
         '(relation apply)
         __tmp33872
         '#f)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-clause?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/proof-frame#proof-binding-clause::t)))
    (define gerbil-ascent/candidate/proof-frame#make-proof-binding-clause
      (lambda _%$args29290%_
        (apply make-instance
               gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
               _%$args29290%_)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-clause-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
         'relation)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-clause-apply
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
         'apply)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-clause-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
         'relation)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-clause-apply-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
         'apply)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-clause-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
         'relation)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-clause-apply
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
         'apply)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-clause-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
         'relation)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-clause-apply-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
         'apply)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-term::t
      (let ((__tmp33875 (list))
            (__tmp33874
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/proof-frame#proof-binding-term::t
         'proof-binding-term
         __tmp33875
         '(kind value)
         __tmp33874
         '#f)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-term?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/proof-frame#proof-binding-term::t)))
    (define gerbil-ascent/candidate/proof-frame#make-proof-binding-term
      (lambda _%$args29287%_
        (apply make-instance
               gerbil-ascent/candidate/proof-frame#proof-binding-term::t
               _%$args29287%_)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-term-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-term::t
         'kind)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-term-value
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-term::t
         'value)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-term-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-term::t
         'kind)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-term-value-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-term::t
         'value)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-term-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-term::t
         'kind)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-term-value
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-term::t
         'value)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-term-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-term::t
         'kind)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-term-value-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-term::t
         'value)))
    (define gerbil-ascent/candidate/proof-frame#prepare-proof-binding-flow
      (lambda (_%head29055%_ _%body29056%_)
        (let ((_%slots29058%_
               (let () (declare (not safe)) (make-hash-table-eq)))
              (_%known29059%_
               (let () (declare (not safe)) (make-hash-table-eq)))
              (_%guards29060%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value)))
              (_%size29061%_ '0)
              (_%unbound29062%_
               (let () (declare (not safe)) (##gensym 'unbound))))
          (letrec ((_%slot29064%_
                    (lambda (_%name29279%_)
                      (let ((_%$e29281%_
                             (let ()
                               (declare (not safe))
                               (__hash-get _%slots29058%_ _%name29279%_))))
                        (if _%$e29281%_
                            (values _%$e29281%_)
                            (let ((_%index29285%_ _%size29061%_))
                              (set! _%size29061%_ (+ _%size29061%_ '1))
                              (let ()
                                (declare (not safe))
                                (__hash-put!
                                 _%slots29058%_
                                 _%name29279%_
                                 _%index29285%_))
                              _%index29285%_)))))
                   (_%bound?29065%_
                    (lambda (_%frame29276%_ _%index29277%_)
                      (not (eq? (vector-ref _%frame29276%_ _%index29277%_)
                                _%unbound29062%_))))
                   (_%prepare-term29066%_
                    (lambda (_%term29269%_)
                      (if (eq? _%term29269%_ '?_)
                          (let ()
                            (declare (not safe))
                            (##structure
                             gerbil-ascent/candidate/proof-frame#proof-binding-term::t
                             'wildcard
                             '#f))
                          (if (let ()
                                (declare (not safe))
                                (gerbil-ascent/candidate/program#candidate-variable?
                                 _%term29269%_))
                              (let ((_%index29273%_
                                     (_%slot29064%_ _%term29269%_)))
                                (if (let ()
                                      (declare (not safe))
                                      (__hash-get
                                       _%known29059%_
                                       _%term29269%_))
                                    (let ()
                                      (declare (not safe))
                                      (##structure
                                       gerbil-ascent/candidate/proof-frame#proof-binding-term::t
                                       'bound
                                       _%index29273%_))
                                    (begin
                                      (let ()
                                        (declare (not safe))
                                        (__hash-put!
                                         _%known29059%_
                                         _%term29269%_
                                         '#t))
                                      (let ()
                                        (declare (not safe))
                                        (##structure
                                         gerbil-ascent/candidate/proof-frame#proof-binding-term::t
                                         'fresh
                                         _%index29273%_)))))
                              (let ()
                                (declare (not safe))
                                (##structure
                                 gerbil-ascent/candidate/proof-frame#proof-binding-term::t
                                 'literal
                                 _%term29269%_))))))
                   (_%prepare-atom29067%_
                    (lambda (_%atom29229%_)
                      (let ((_%actions29231%_
                             (map _%prepare-term29066%_ (cdr _%atom29229%_))))
                        (let ((__tmp33877
                               (lambda (_%action29233%_ _%next29234%_)
                                 (let* ((_%action29237%_ _%action29233%_)
                                        (_%$e29251%_
                                         (let ()
                                           (declare (not safe))
                                           (##unchecked-structure-ref
                                            _%action29237%_
                                            '1
                                            '#f
                                            '#f))))
                                   (if (eq? 'wildcard _%$e29251%_)
                                       (lambda (_%row29254%_ _%frame29255%_)
                                         (_%next29234%_
                                          (cdr _%row29254%_)
                                          _%frame29255%_))
                                       (if (eq? 'fresh _%$e29251%_)
                                           (lambda (_%row29257%_
                                                    _%frame29258%_)
                                             (vector-set!
                                              _%frame29258%_
                                              (let ()
                                                (declare (not safe))
                                                (##unchecked-structure-ref
                                                 _%action29237%_
                                                 '2
                                                 '#f
                                                 '#f))
                                              (car _%row29257%_))
                                             (_%next29234%_
                                              (cdr _%row29257%_)
                                              _%frame29258%_))
                                           (if (eq? 'bound _%$e29251%_)
                                               (lambda (_%row29260%_
                                                        _%frame29261%_)
                                                 (if (equal? (vector-ref
                                                              _%frame29261%_
                                                              (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (##unchecked-structure-ref
                         _%action29237%_
                         '2
                         '#f
                         '#f)))
                     (car _%row29260%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (_%next29234%_
                                                      (cdr _%row29260%_)
                                                      _%frame29261%_)
                                                     '#f))
                                               (if (eq? 'literal _%$e29251%_)
                                                   (lambda (_%row29263%_
                                                            _%frame29264%_)
                                                     (if (equal? (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%action29237%_
                            '2
                            '#f
                            '#f))
                         (car _%row29263%_))
                 (_%next29234%_ (cdr _%row29263%_) _%frame29264%_)
                 '#f))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   '#!void)))))))
                              (__tmp33876
                               (lambda (_%_row29266%_ _%_frame29267%_) '#t)))
                          (declare (not safe))
                          (foldr__0 __tmp33877 __tmp33876 _%actions29231%_)))))
                   (_%prepare-fixed29068%_
                    (lambda (_%clause29097%_)
                      (let* ((_%$%clause2909829105%_ _%clause29097%_)
                             (_%$%E2910029108%_
                              (lambda ()
                                (let ()
                                  (declare (not safe))
                                  (error '"No clause matching"
                                         _%$%clause2909829105%_
                                         '([mode . _])))
                                '#!void))
                             (_%$%K2910129221%_
                              (lambda (_%mode29111%_)
                                (let* ((_%form29113%_
                                        (if (eq? _%mode29111%_ 'where)
                                            (cadr _%clause29097%_)
                                            (caddr _%clause29097%_)))
                                       (_%inputs29115%_
                                        (map _%slot29064%_
                                             (cdr _%form29113%_)))
                                       (_%output29117%_
                                        (if (eq? _%mode29111%_ 'compute)
                                            (_%slot29064%_
                                             (cadr _%clause29097%_))
                                            '#f)))
                                  (letrec ((_%read-one29120%_
                                            (lambda (_%frame29217%_)
                                              (let ((_%index29219%_
                                                     (car _%inputs29115%_)))
                                                (if (_%bound?29065%_
                                                     _%frame29217%_
                                                     _%index29219%_)
                                                    (vector-ref
                                                     _%frame29217%_
                                                     _%index29219%_)
                                                    '#f)))))
                                    (let ((_%$e29122%_ _%mode29111%_))
                                      (if (eq? 'where _%$e29122%_)
                                          (let ((_%$e29125%_
                                                 (car _%form29113%_)))
                                            (if (eq? 'even? _%$e29125%_)
                                                (lambda (_%frame29128%_)
                                                  (let ((_%value29130%_
                                                         (_%read-one29120%_
                                                          _%frame29128%_)))
                                                    (if (exact-integer?
                                                         _%value29130%_)
                                                        (even? _%value29130%_)
                                                        '#f)))
                                                (if (eq? '< _%$e29125%_)
                                                    (let* ((_%$%inputs2913129140%_
                                                            _%inputs29115%_)
                                                           (_%$%E2913329143%_
                                                            (lambda ()
                                                              (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (error '"No clause matching"
                               _%$%inputs2913129140%_
                               '([left right])))
                      '#!void))
                   (_%$%K2913429154%_
                    (lambda (_%right29146%_ _%left29147%_)
                      (lambda (_%frame29149%_)
                        (let ((_%a29151%_
                               (vector-ref _%frame29149%_ _%left29147%_))
                              (_%b29152%_
                               (vector-ref _%frame29149%_ _%right29146%_)))
                          (if (exact-integer? _%a29151%_)
                              (if (exact-integer? _%b29152%_)
                                  (< _%a29151%_ _%b29152%_)
                                  '#f)
                              '#f))))))
              (if (pair? _%$%inputs2913129140%_)
                  (let ((_%$%hd2913529157%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%inputs2913129140%_)))
                        (_%$%tl2913629159%_
                         (let ()
                           (declare (not safe))
                           (##cdr _%$%inputs2913129140%_))))
                    (let ((_%left29162%_ _%$%hd2913529157%_))
                      (if (pair? _%$%tl2913629159%_)
                          (let ((_%$%hd2913729164%_
                                 (let ()
                                   (declare (not safe))
                                   (##car _%$%tl2913629159%_)))
                                (_%$%tl2913829166%_
                                 (let ()
                                   (declare (not safe))
                                   (##cdr _%$%tl2913629159%_))))
                            (let ((_%right29169%_ _%$%hd2913729164%_))
                              (if (null? _%$%tl2913829166%_)
                                  (_%$%K2913429154%_
                                   _%right29169%_
                                   _%left29162%_)
                                  (_%$%E2913329143%_))))
                          (_%$%E2913329143%_))))
                  (_%$%E2913329143%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '#!void)))
                                          (if (eq? 'compute _%$e29122%_)
                                              (let ((_%$e29171%_
                                                     (car _%form29113%_)))
                                                (if (eq? 'identity _%$e29171%_)
                                                    (let ((_%input29174%_
                                                           (car _%inputs29115%_)))
                                                      (lambda (_%frame29176%_)
                                                        (if (_%bound?29065%_
                                                             _%frame29176%_
                                                             _%input29174%_)
                                                            (if (_%bound?29065%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%frame29176%_
                         _%output29117%_)
                        '#f
                        (begin
                          (vector-set!
                           _%frame29176%_
                           _%output29117%_
                           (vector-ref _%frame29176%_ _%input29174%_))
                          '#t))
                    '#f)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (if (eq? '+ _%$e29171%_)
                                                        (let* ((_%$%inputs2917729186%_
                                                                _%inputs29115%_)
                                                               (_%$%E2917929189%_
                                                                (lambda ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (let ()
                            (declare (not safe))
                            (error '"No clause matching"
                                   _%$%inputs2917729186%_
                                   '([left right])))
                          '#!void))
                       (_%$%K2918029200%_
                        (lambda (_%right29192%_ _%left29193%_)
                          (lambda (_%frame29195%_)
                            (let ((_%a29197%_
                                   (vector-ref _%frame29195%_ _%left29193%_))
                                  (_%b29198%_
                                   (vector-ref _%frame29195%_ _%right29192%_)))
                              (if (_%bound?29065%_
                                   _%frame29195%_
                                   _%output29117%_)
                                  '#f
                                  (if (exact-integer? _%a29197%_)
                                      (if (exact-integer? _%b29198%_)
                                          (begin
                                            (vector-set!
                                             _%frame29195%_
                                             _%output29117%_
                                             (+ _%a29197%_ _%b29198%_))
                                            '#t)
                                          '#f)
                                      '#f)))))))
                  (if (pair? _%$%inputs2917729186%_)
                      (let ((_%$%hd2918129203%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%inputs2917729186%_)))
                            (_%$%tl2918229205%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%inputs2917729186%_))))
                        (let ((_%left29208%_ _%$%hd2918129203%_))
                          (if (pair? _%$%tl2918229205%_)
                              (let ((_%$%hd2918329210%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%tl2918229205%_)))
                                    (_%$%tl2918429212%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%tl2918229205%_))))
                                (let ((_%right29215%_ _%$%hd2918329210%_))
                                  (if (null? _%$%tl2918429212%_)
                                      (_%$%K2918029200%_
                                       _%right29215%_
                                       _%left29208%_)
                                      (_%$%E2917929189%_))))
                              (_%$%E2917929189%_))))
                      (_%$%E2917929189%_)))
                '#!void)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              '#!void))))))))
                        (if (pair? _%$%clause2909829105%_)
                            (let* ((_%$%hd2910229224%_
                                    (let ()
                                      (declare (not safe))
                                      (##car _%$%clause2909829105%_)))
                                   (_%mode29227%_ _%$%hd2910229224%_))
                              (_%$%K2910129221%_ _%mode29227%_))
                            (_%$%E2910029108%_))))))
            (let* ((_%clauses29077%_
                    (let ((__tmp33878
                           (map (lambda (_%clause29070%_)
                                  (let ((_%$e29072%_ (car _%clause29070%_)))
                                    (if (eq? 'where _%$e29072%_)
                                        (if (let ()
                                              (declare (not safe))
                                              (__hash-get
                                               _%guards29060%_
                                               _%clause29070%_))
                                            '#f
                                            (begin
                                              (let ()
                                                (declare (not safe))
                                                (__hash-put!
                                                 _%guards29060%_
                                                 _%clause29070%_
                                                 '#t))
                                              (let ((__tmp33879
                                                     (_%prepare-fixed29068%_
                                                      _%clause29070%_)))
                                                (declare (not safe))
                                                (##structure
                                                 gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
                                                 '#f
                                                 __tmp33879))))
                                        (if (eq? 'compute _%$e29072%_)
                                            (let ((_%evaluate29075%_
                                                   (_%prepare-fixed29068%_
                                                    _%clause29070%_)))
                                              (let ((__tmp33880
                                                     (cadr _%clause29070%_)))
                                                (declare (not safe))
                                                (__hash-put!
                                                 _%known29059%_
                                                 __tmp33880
                                                 '#t))
                                              (let ()
                                                (declare (not safe))
                                                (##structure
                                                 gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
                                                 '#f
                                                 _%evaluate29075%_)))
                                            (let ((__tmp33882
                                                   (car _%clause29070%_))
                                                  (__tmp33881
                                                   (_%prepare-atom29067%_
                                                    _%clause29070%_)))
                                              (declare (not safe))
                                              (##structure
                                               gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
                                               __tmp33882
                                               __tmp33881))))))
                                _%body29056%_)))
                      (declare (not safe))
                      (##filter values __tmp33878)))
                   (_%getters29087%_
                    (map (lambda (_%term29079%_)
                           (if (let ()
                                 (declare (not safe))
                                 (gerbil-ascent/candidate/program#candidate-variable?
                                  _%term29079%_))
                               (let ((_%index29081%_
                                      (_%slot29064%_ _%term29079%_)))
                                 (lambda (_%frame29083%_)
                                   (if (_%bound?29065%_
                                        _%frame29083%_
                                        _%index29081%_)
                                       '#!void
                                       (let ()
                                         (declare (not safe))
                                         (error '"unbound positive proof head"
                                                _%term29079%_)))
                                   (vector-ref _%frame29083%_ _%index29081%_)))
                               (lambda (_%_frame29085%_) _%term29079%_)))
                         (cdr _%head29055%_))))
              (let ((__tmp33885
                     (lambda () (make-vector _%size29061%_ _%unbound29062%_)))
                    (__tmp33883
                     (lambda (_%frame29091%_)
                       (let ((__tmp33884
                              (lambda (_%$%g2909229094%_)
                                (_%$%g2909229094%_ _%frame29091%_))))
                         (declare (not safe))
                         (##map __tmp33884 _%getters29087%_)))))
                (declare (not safe))
                (##structure
                 gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
                 __tmp33885
                 __tmp33883
                 _%clauses29077%_)))))))))
