(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/core/dependency-graph[1]#_g33360_|
    (##structure
     gx#syntax-quote::t
     'graph-frame::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33362_|
    (##structure
     gx#syntax-quote::t
     'make-graph-frame
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33364_|
    (##structure
     gx#syntax-quote::t
     'graph-frame?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33366_|
    (##structure
     gx#syntax-quote::t
     'graph-frame-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33367_|
    (##structure
     gx#syntax-quote::t
     'graph-frame-remaining
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33368_|
    (##structure
     gx#syntax-quote::t
     'graph-frame-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33370_|
    (##structure
     gx#syntax-quote::t
     'graph-frame-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33371_|
    (##structure
     gx#syntax-quote::t
     'graph-frame-remaining-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33372_|
    (##structure
     gx#syntax-quote::t
     'graph-frame-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33374_|
    (##structure
     gx#syntax-quote::t
     '&graph-frame-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33375_|
    (##structure
     gx#syntax-quote::t
     '&graph-frame-remaining
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33376_|
    (##structure
     gx#syntax-quote::t
     '&graph-frame-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33378_|
    (##structure
     gx#syntax-quote::t
     '&graph-frame-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33379_|
    (##structure
     gx#syntax-quote::t
     '&graph-frame-remaining-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33380_|
    (##structure
     gx#syntax-quote::t
     '&graph-frame-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[:0:]#graph-frame|
    (let ((__obj33355
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj33355
         'gerbil-ascent/core/dependency-graph#graph-frame::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33355 'graph-frame '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj33355
         '(node remaining parent)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj33355
         '(node remaining parent)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33355 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33355 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33355 '#t '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33355 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33355 '#f '13 '#f '#f))
      (let ((__tmp33359 |gerbil-ascent/core/dependency-graph[1]#_g33360_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj33355 __tmp33359 '4 '#f '#f))
      (let ((__tmp33361 |gerbil-ascent/core/dependency-graph[1]#_g33362_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj33355 __tmp33361 '14 '#f '#f))
      (let ((__tmp33363 |gerbil-ascent/core/dependency-graph[1]#_g33364_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj33355 __tmp33363 '15 '#f '#f))
      (let ((__tmp33365
             (cons (cons 'node
                         |gerbil-ascent/core/dependency-graph[1]#_g33366_|)
                   (cons (cons 'remaining
                               |gerbil-ascent/core/dependency-graph[1]#_g33367_|)
                         (cons (cons 'parent
                                     |gerbil-ascent/core/dependency-graph[1]#_g33368_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33355 __tmp33365 '16 '#f '#f))
      (let ((__tmp33369
             (cons (cons 'node
                         |gerbil-ascent/core/dependency-graph[1]#_g33370_|)
                   (cons (cons 'remaining
                               |gerbil-ascent/core/dependency-graph[1]#_g33371_|)
                         (cons (cons 'parent
                                     |gerbil-ascent/core/dependency-graph[1]#_g33372_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33355 __tmp33369 '17 '#f '#f))
      (let ((__tmp33373
             (cons (cons 'node
                         |gerbil-ascent/core/dependency-graph[1]#_g33374_|)
                   (cons (cons 'remaining
                               |gerbil-ascent/core/dependency-graph[1]#_g33375_|)
                         (cons (cons 'parent
                                     |gerbil-ascent/core/dependency-graph[1]#_g33376_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33355 __tmp33373 '18 '#f '#f))
      (let ((__tmp33377
             (cons (cons 'node
                         |gerbil-ascent/core/dependency-graph[1]#_g33378_|)
                   (cons (cons 'remaining
                               |gerbil-ascent/core/dependency-graph[1]#_g33379_|)
                         (cons (cons 'parent
                                     |gerbil-ascent/core/dependency-graph[1]#_g33380_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33355 __tmp33377 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33355 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33355 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33355 '() '21 '#f '#f))
      __obj33355)))
