(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/evidence-store::timestamp 1791692692)
  (begin
    (define gerbil-ascent/candidate/evidence-store#evidence-entry::t
      (let ((__tmp34433 (list))
            (__tmp34432
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'evidence-entry
         __tmp34433
         '(snapshot candidate receipt handle)
         __tmp34432
         '#f)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/evidence-store#evidence-entry::t)))
    (define gerbil-ascent/candidate/evidence-store#make-evidence-entry
      (lambda _%$args31011%_
        (apply make-instance
               gerbil-ascent/candidate/evidence-store#evidence-entry::t
               _%$args31011%_)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-snapshot
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'snapshot)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-candidate
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'candidate)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-receipt
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'receipt)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-handle
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'handle)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-snapshot-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'snapshot)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-candidate-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'candidate)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-receipt-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'receipt)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-handle-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'handle)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-snapshot
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'snapshot)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-candidate
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'candidate)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-receipt
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'receipt)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-handle
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'handle)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-snapshot-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'snapshot)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-candidate-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'candidate)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-receipt-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'receipt)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-handle-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'handle)))
    (define gerbil-ascent/candidate/evidence-store#evidence-operations?
      (lambda (_%owner31007%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%owner31007%_
               'clan/poo/object#object::t))
            (let ((__tmp34434
                   (lambda (_%slot31009%_)
                     (if (let ()
                           (declare (not safe))
                           (clan/poo/object#.slot?
                            _%owner31007%_
                            _%slot31009%_))
                         (procedure?
                          (let ()
                            (declare (not safe))
                            (clan/poo/object#.ref
                             _%owner31007%_
                             _%slot31009%_)))
                         '#f))))
              (declare (not safe))
              (andmap__0
               __tmp34434
               '(.resolve
                 .claim
                 .fact
                 .fragment
                 .certificate
                 .partition
                 .stats
                 .clear)))
            '#f)))
    (define gerbil-ascent/candidate/evidence-store#GerbilAscentEvidenceStoreContract
      (let ((__obj34429
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp34436
               (list (cons 'sexp
                           (let ((__tmp34437
                                  (lambda (_%@30956%_)
                                    'GerbilAscentEvidenceStoreContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34437)))
                     (cons 'identity
                           (let ((__tmp34438
                                  (lambda (_%@30962%_)
                                    'ascent/computational-evidence-store)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34438)))
                     (cons 'proto
                           (let ((__tmp34439
                                  (lambda (_%@30967%_)
                                    (let ((__obj34427
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp34441 (list))
                                            (__tmp34440 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp34441
                                         __tmp34440
                                         __obj34427))
                                      __obj34427))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34439)))
                     (cons 'responsibilities
                           (let ((__tmp34442
                                  (lambda (_%@30981%_)
                                    (let ((__obj34428
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp34444
                                             (list (cons '.operations
                                                         (let ((__tmp34445
                                                                (lambda (_%self30997%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (let ((__tmp34446
                                 (lambda (_%_v31004%_ _%_c31005%_) '())))
                            (declare (not safe))
                            (core/types#poo-flow-predicate-contract
                             'ascent/evidence-operations
                             gerbil-ascent/candidate/evidence-store#evidence-operations?
                             __tmp34446)))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp34445)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp34443 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp34444
                                         __tmp34443
                                         __obj34428))
                                      __obj34428))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34442)))))
              (__tmp34435 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp34436
           __tmp34435
           __obj34429))
        __obj34429))
    (define gerbil-ascent/candidate/evidence-store#detached
      (lambda (_%value30938%_)
        (if (pair? _%value30938%_)
            (cons (gerbil-ascent/candidate/evidence-store#detached
                   (let () (declare (not safe)) (##car _%value30938%_)))
                  (gerbil-ascent/candidate/evidence-store#detached
                   (let () (declare (not safe)) (##cdr _%value30938%_))))
            (if (string? _%value30938%_)
                (let () (declare (not safe)) (##string-copy _%value30938%_))
                _%value30938%_))))
    (define gerbil-ascent/candidate/evidence-store#scope-key
      (lambda (_%snapshot30933%_ _%candidate30934%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
               _%snapshot30933%_))
            (let ((_%digest30936%_
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/reasoning#candidate-content-digest
                      _%candidate30934%_))))
              (if _%digest30936%_
                  (list (##structure-ref
                         _%snapshot30933%_
                         '1
                         gerbil-ascent/candidate/types#reasoning-snapshot::t
                         '#f)
                        (##structure-ref
                         _%snapshot30933%_
                         '2
                         gerbil-ascent/candidate/types#reasoning-snapshot::t
                         '#f)
                        (##structure-ref
                         _%snapshot30933%_
                         '3
                         gerbil-ascent/candidate/types#reasoning-snapshot::t
                         '#f)
                        _%digest30936%_)
                  '#f))
            '#f)))
    (define gerbil-ascent/candidate/evidence-store#scope-description
      (lambda (_%entry30928%_)
        (let ((_%snapshot30930%_
               (##direct-structure-ref
                _%entry30928%_
                '1
                gerbil-ascent/candidate/evidence-store#evidence-entry::t
                '#f))
              (_%receipt30931%_
               (##direct-structure-ref
                _%entry30928%_
                '3
                gerbil-ascent/candidate/evidence-store#evidence-entry::t
                '#f)))
          (list (list 'source-identity
                      (##structure-ref
                       _%snapshot30930%_
                       '1
                       gerbil-ascent/candidate/types#reasoning-snapshot::t
                       '#f))
                (list 'generation
                      (##structure-ref
                       _%snapshot30930%_
                       '2
                       gerbil-ascent/candidate/types#reasoning-snapshot::t
                       '#f))
                (list 'source-digest
                      (##structure-ref
                       _%snapshot30930%_
                       '3
                       gerbil-ascent/candidate/types#reasoning-snapshot::t
                       '#f))
                (list 'candidate-digest
                      (##structure-ref
                       _%receipt30931%_
                       '5
                       gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                       '#f))
                (list 'query
                      (##structure-ref
                       _%receipt30931%_
                       '6
                       gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                       '#f))))))
    (define gerbil-ascent/candidate/evidence-store#describe-entry
      (lambda (_%entry30925%_ _%reused?30926%_)
        (gerbil-ascent/candidate/evidence-store#detached
         (list (list 'status 'verified)
               (list 'finite-complete '#t)
               (list 'handle
                     (##direct-structure-ref
                      _%entry30925%_
                      '4
                      gerbil-ascent/candidate/evidence-store#evidence-entry::t
                      '#f))
               (list 'reused _%reused?30926%_)
               (list 'scope
                     (gerbil-ascent/candidate/evidence-store#scope-description
                      _%entry30925%_))
               (list 'rows
                     (##structure-ref
                      (##direct-structure-ref
                       _%entry30925%_
                       '3
                       gerbil-ascent/candidate/evidence-store#evidence-entry::t
                       '#f)
                      '7
                      gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                      '#f))))))
    (define gerbil-ascent/candidate/evidence-store#unknown
      (lambda (_%reason30923%_)
        (list (list 'status 'unknown) (list 'reason _%reason30923%_))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__%
      (lambda (_%max-entries30639%_ _%proof-steps30640%_ _%work-steps30641%_)
        (if (let ((__tmp34448
                   (lambda (_%v30643%_)
                     (and (exact-integer? _%v30643%_) (> _%v30643%_ '0))))
                  (__tmp34447
                   (list _%max-entries30639%_
                         _%proof-steps30640%_
                         _%work-steps30641%_)))
              (declare (not safe))
              (andmap__0 __tmp34448 __tmp34447))
            '#!void
            (let ()
              (declare (not safe))
              (error '"evidence store requires positive bounds")))
        (let ((_%entries30645%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value)))
              (_%handles30646%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value)))
              (_%order30647%_ '())
              (_%serial30648%_ '0)
              (_%builds30649%_ '0)
              (_%hits30650%_ '0)
              (_%attempts30651%_ '0)
              (_%evictions30652%_ '0)
              (_%gate30653%_ (make-mutex 'ascent-evidence-owner)))
          (letrec ((_%serialized30655%_
                    (lambda (_%call30896%_)
                      (if (eq? (mutex-state _%gate30653%_) (current-thread))
                          (let ()
                            (declare (not safe))
                            (error '"reentrant evidence owner call"))
                          '#!void)
                      (let ()
                        (declare (not safe))
                        (with-dynamic-lock _%gate30653%_ _%call30896%_))))
                   (_%bound-entry30656%_
                    (lambda (_%snapshot30890%_
                             _%candidate30891%_
                             _%handle30892%_)
                      (let ((_%entry30894%_
                             (if (exact-integer? _%handle30892%_)
                                 (let ()
                                   (declare (not safe))
                                   (__hash-get
                                    _%handles30646%_
                                    _%handle30892%_))
                                 '#f)))
                        (if _%entry30894%_
                            (if (let ((__tmp34449
                                       (##direct-structure-ref
                                        _%entry30894%_
                                        '3
                                        gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                        '#f)))
                                  (declare (not safe))
                                  (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                                   __tmp34449
                                   _%snapshot30890%_
                                   _%candidate30891%_))
                                _%entry30894%_
                                '#f)
                            '#f))))
                   (_%resolve30657%_
                    (lambda (_%snapshot30854%_ _%candidate30855%_)
                      (let* ((_%key30857%_
                              (gerbil-ascent/candidate/evidence-store#scope-key
                               _%snapshot30854%_
                               _%candidate30855%_))
                             (_%entry30859%_
                              (if _%key30857%_
                                  (let ()
                                    (declare (not safe))
                                    (__hash-get _%entries30645%_ _%key30857%_))
                                  '#f)))
                        (if _%key30857%_
                            (if (and _%entry30859%_
                                     (let ((__tmp34450
                                            (##direct-structure-ref
                                             _%entry30859%_
                                             '3
                                             gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                             '#f)))
                                       (declare (not safe))
                                       (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                                        __tmp34450
                                        _%snapshot30854%_
                                        _%candidate30855%_)))
                                (let ()
                                  (set! _%hits30650%_ (+ _%hits30650%_ '1))
                                  (gerbil-ascent/candidate/evidence-store#describe-entry
                                   _%entry30859%_
                                   '#t))
                                (let ()
                                  (set! _%attempts30651%_
                                        (+ _%attempts30651%_ '1))
                                  (let ((__tmp34464
                                         (lambda (_%$%g3086430866%_)
                                           (let ((_%e30870%_
                                                  _%$%g3086430866%_))
                                             (gerbil-ascent/candidate/evidence-store#unknown
                                              (let ()
                                                (declare (not safe))
                                                (std/error#exception->string
                                                 _%e30870%_))))))
                                        (__tmp34451
                                         (lambda ()
                                           (let* ((_%owned-source30874%_
                                                   (let ((__tmp34454
                                                          (gerbil-ascent/candidate/evidence-store#detached
                                                           (##structure-ref
                                                            _%snapshot30854%_
                                                            '1
                                                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                            '#f)))
                                                         (__tmp34453
                                                          (##structure-ref
                                                           _%snapshot30854%_
                                                           '2
                                                           gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                           '#f))
                                                         (__tmp34452
                                                          (##structure-ref
                                                           _%snapshot30854%_
                                                           '4
                                                           gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                           '#f)))
                                                     (declare (not safe))
                                                     (gerbil-ascent/candidate/reasoning#reasoning-source-snapshot
                                                      __tmp34454
                                                      __tmp34453
                                                      __tmp34452)))
                                                  (_%owned-candidate30876%_
                                                   (gerbil-ascent/candidate/evidence-store#detached
                                                    _%candidate30855%_))
                                                  (_%receipt30878%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gerbil-ascent/candidate/reasoning#reasoning-attempt__%
                                                      _%owned-source30874%_
                                                      _%owned-candidate30876%_
                                                      _%proof-steps30640%_
                                                      _%work-steps30641%_)))
                                                  (_%rows30880%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%receipt30878%_
                                                      '7
                                                      '#f
                                                      '#f))))
                                             (if (and (let ()
                                                        (declare (not safe))
                                                        (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                                                         _%receipt30878%_
                                                         _%snapshot30854%_
                                                         _%candidate30855%_))
                                                      (eq? (let ()
                                                             (declare
                                                               (not safe))
                                                             (##unchecked-structure-ref
                                                              _%receipt30878%_
                                                              '1
                                                              '#f
                                                              '#f))
                                                           'complete)
                                                      (let ((__tmp34455
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##unchecked-structure-ref
                        _%receipt30878%_
                        '10
                        '#f
                        '#f))))
                (declare (not safe))
                (##structure-instance-of?
                 __tmp34455
                 'gerbil-ascent/candidate/provenance#positive-proof::t))
              (or (null? _%rows30880%_)
                  (let ((__tmp34458
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/program#candidate-inspect
                            _%owned-source30874%_
                            _%owned-candidate30876%_)))
                        (__tmp34457
                         (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%receipt30878%_
                            '5
                            '#f
                            '#f)))
                        (__tmp34456
                         (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%receipt30878%_
                            '10
                            '#f
                            '#f))))
                    (declare (not safe))
                    (gerbil-ascent/candidate/provenance#candidate-verify-positive-proof
                     _%owned-source30874%_
                     __tmp34458
                     __tmp34457
                     'complete
                     _%rows30880%_
                     __tmp34456
                     _%proof-steps30640%_)))
              (eq? (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/reasoning#reasoning-verify-finite-receipt
                      _%receipt30878%_
                      _%owned-source30874%_
                      _%owned-candidate30876%_
                      _%work-steps30641%_))
                   'valid))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (begin
                                                   (if (>= (let ()
                                                             (declare
                                                               (not safe))
                                                             (__hash-length
                                                              _%entries30645%_))
                                                           _%max-entries30639%_)
                                                       (begin
                                                         (let ((_%old30886%_
                                                                (let ((__tmp34459
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               (car _%order30647%_)))
                          (declare (not safe))
                          (hash-ref__0 _%entries30645%_ __tmp34459))))
                   (let ((__tmp34460
                          (##direct-structure-ref
                           _%old30886%_
                           '4
                           gerbil-ascent/candidate/evidence-store#evidence-entry::t
                           '#f)))
                     (declare (not safe))
                     (__hash-remove! _%handles30646%_ __tmp34460))
                   (let ((__tmp34461 (car _%order30647%_)))
                     (declare (not safe))
                     (__hash-remove! _%entries30645%_ __tmp34461)))
                 (set! _%order30647%_ (cdr _%order30647%_))
                 (set! _%evictions30652%_ (+ _%evictions30652%_ '1)))
               '#!void)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (set! _%serial30648%_
                                                         (+ _%serial30648%_
                                                            '1))
                                                   (set! _%builds30649%_
                                                         (+ _%builds30649%_
                                                            '1))
                                                   (let ((_%admitted30888%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (##structure
                                                             gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                                             _%owned-source30874%_
                                                             _%owned-candidate30876%_
                                                             _%receipt30878%_
                                                             _%serial30648%_))))
                                                     (let ((__tmp34462
                                                            (gerbil-ascent/candidate/evidence-store#detached
                                                             _%key30857%_)))
                                                       (declare (not safe))
                                                       (__hash-put!
                                                        _%entries30645%_
                                                        __tmp34462
                                                        _%admitted30888%_))
                                                     (let ()
                                                       (declare (not safe))
                                                       (__hash-put!
                                                        _%handles30646%_
                                                        _%serial30648%_
                                                        _%admitted30888%_))
                                                     (set! _%order30647%_
                                                           (let ((__tmp34463
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (list (gerbil-ascent/candidate/evidence-store#detached
                                 _%key30857%_))))
                     (declare (not safe))
                     (##append _%order30647%_ __tmp34463)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (gerbil-ascent/candidate/evidence-store#describe-entry
                                                      _%admitted30888%_
                                                      '#f)))
                                                 (gerbil-ascent/candidate/evidence-store#unknown
                                                  'unverified-receipt))))))
                                    (declare (not safe))
                                    (__with-catch __tmp34464 __tmp34451))))
                            (gerbil-ascent/candidate/evidence-store#unknown
                             'invalid-scope)))))
                   (_%claim30658%_
                    (lambda (_%snapshot30842%_
                             _%candidate30843%_
                             _%handle30844%_
                             _%row30845%_)
                      (let ((_%entry30847%_
                             (_%bound-entry30656%_
                              _%snapshot30842%_
                              _%candidate30843%_
                              _%handle30844%_)))
                        (if _%entry30847%_
                            (if (and (let ()
                                       (declare (not safe))
                                       (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                                        _%row30845%_
                                        '16384
                                        '128))
                                     (list? _%row30845%_)
                                     (= (let ()
                                          (declare (not safe))
                                          (##length _%row30845%_))
                                        (length (cdr (##structure-ref
                                                      (##direct-structure-ref
                                                       _%entry30847%_
                                                       '3
                                                       gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                                       '#f)
                                                      '6
                                                      gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                                      '#f))))
                                     (let ()
                                       (declare (not safe))
                                       (andmap__0
                                        gerbil-ascent/candidate/program#scalar?
                                        _%row30845%_))
                                     (let ((__tmp34465
                                            (##structure-ref
                                             (##direct-structure-ref
                                              _%entry30847%_
                                              '3
                                              gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                              '#f)
                                             '6
                                             gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                             '#f)))
                                       (declare (not safe))
                                       (gerbil-ascent/candidate/funs#candidate-bind-atom
                                        __tmp34465
                                        _%row30845%_
                                        '())))
                                (let ((_%present30852%_
                                       (if (member _%row30845%_
                                                   (##structure-ref
                                                    (##direct-structure-ref
                                                     _%entry30847%_
                                                     '3
                                                     gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                                     '#f)
                                                    '7
                                                    gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                                    '#f))
                                           '#t
                                           '#f)))
                                  (gerbil-ascent/candidate/evidence-store#detached
                                   (list (list 'status
                                               (if _%present30852%_
                                                   'verified
                                                   'finite-absent))
                                         (list 'present _%present30852%_)
                                         (list 'row _%row30845%_)
                                         (list 'handle _%handle30844%_)
                                         (list 'scope
                                               (gerbil-ascent/candidate/evidence-store#scope-description
                                                _%entry30847%_)))))
                                (gerbil-ascent/candidate/evidence-store#unknown
                                 'invalid-query-row))
                            (gerbil-ascent/candidate/evidence-store#unknown
                             'stale-or-unknown-handle)))))
                   (_%certificate30659%_
                    (lambda (_%snapshot30829%_
                             _%candidate30830%_
                             _%handle30831%_)
                      (let ((_%entry30833%_
                             (_%bound-entry30656%_
                              _%snapshot30829%_
                              _%candidate30830%_
                              _%handle30831%_)))
                        (if _%entry30833%_
                            (let* ((_%receipt30835%_
                                    (##direct-structure-ref
                                     _%entry30833%_
                                     '3
                                     gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                     '#f))
                                   (_%proof30837%_
                                    (##structure-ref
                                     _%receipt30835%_
                                     '10
                                     gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                     '#f)))
                              (gerbil-ascent/candidate/evidence-store#detached
                               (list (list 'status 'verified)
                                     (list 'handle _%handle30831%_)
                                     (list 'scope
                                           (gerbil-ascent/candidate/evidence-store#scope-description
                                            _%entry30833%_))
                                     (list 'finite-closure
                                           (##structure-ref
                                            (##structure-ref
                                             (##structure-ref
                                              _%receipt30835%_
                                              '12
                                              gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                              '#f)
                                             '2
                                             gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                                             '#f)
                                            '9
                                            gerbil-ascent/candidate/finite-evidence#finite-evidence::t
                                            '#f))
                                     (list 'positive-proof-status
                                           (##structure-ref
                                            _%proof30837%_
                                            '1
                                            gerbil-ascent/candidate/provenance#positive-proof::t
                                            '#f))
                                     (list 'roots
                                           (##structure-ref
                                            _%proof30837%_
                                            '9
                                            gerbil-ascent/candidate/provenance#positive-proof::t
                                            '#f))
                                     (list 'nodes
                                           (map (lambda (_%n30840%_)
                                                  (list (##structure-ref
                                                         _%n30840%_
                                                         '1
                                                         gerbil-ascent/candidate/provenance#proof-node::t
                                                         '#f)
                                                        (##structure-ref
                                                         _%n30840%_
                                                         '2
                                                         gerbil-ascent/candidate/provenance#proof-node::t
                                                         '#f)
                                                        (##structure-ref
                                                         _%n30840%_
                                                         '3
                                                         gerbil-ascent/candidate/provenance#proof-node::t
                                                         '#f)
                                                        (##structure-ref
                                                         _%n30840%_
                                                         '4
                                                         gerbil-ascent/candidate/provenance#proof-node::t
                                                         '#f)
                                                        (##structure-ref
                                                         _%n30840%_
                                                         '5
                                                         gerbil-ascent/candidate/provenance#proof-node::t
                                                         '#f)
                                                        (##structure-ref
                                                         _%n30840%_
                                                         '6
                                                         gerbil-ascent/candidate/provenance#proof-node::t
                                                         '#f)))
                                                (##structure-ref
                                                 _%proof30837%_
                                                 '8
                                                 gerbil-ascent/candidate/provenance#positive-proof::t
                                                 '#f))))))
                            (gerbil-ascent/candidate/evidence-store#unknown
                             'stale-or-unknown-handle)))))
                   (_%fact30660%_
                    (lambda (_%snapshot30805%_
                             _%candidate30806%_
                             _%handle30807%_
                             _%atom30808%_)
                      (let ((_%entry30810%_
                             (_%bound-entry30656%_
                              _%snapshot30805%_
                              _%candidate30806%_
                              _%handle30807%_)))
                        (if _%entry30810%_
                            (if (and (let ()
                                       (declare (not safe))
                                       (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                                        _%atom30808%_
                                        '16384
                                        '128))
                                     (list? _%atom30808%_)
                                     (pair? _%atom30808%_)
                                     (symbol? (let ()
                                                (declare (not safe))
                                                (##car _%atom30808%_)))
                                     (let ((__tmp34466
                                            (let ()
                                              (declare (not safe))
                                              (##cdr _%atom30808%_))))
                                       (declare (not safe))
                                       (andmap__0
                                        gerbil-ascent/candidate/program#scalar?
                                        __tmp34466)))
                                (let* ((_%receipt30815%_
                                        (##direct-structure-ref
                                         _%entry30810%_
                                         '3
                                         gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                         '#f))
                                       (_%closure30817%_
                                        (##structure-ref
                                         (##structure-ref
                                          (##structure-ref
                                           _%receipt30815%_
                                           '12
                                           gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                           '#f)
                                          '2
                                          gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                                          '#f)
                                         '9
                                         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
                                         '#f))
                                       (_%relation30819%_
                                        (assq (car _%atom30808%_)
                                              _%closure30817%_)))
                                  (if (and _%relation30819%_
                                           (= (length (cdr _%atom30808%_))
                                              (cadr _%relation30819%_)))
                                      (let* ((_%present30822%_
                                              (if (member (cdr _%atom30808%_)
                                                          (caddr _%relation30819%_))
                                                  '#t
                                                  '#f))
                                             (_%support30826%_
                                              (filter (lambda (_%node30824%_)
                                                        (if (eq? (##structure-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          _%node30824%_
                          '3
                          gerbil-ascent/candidate/provenance#proof-node::t
                          '#f)
                         (car _%atom30808%_))
                    (equal? (##structure-ref
                             _%node30824%_
                             '4
                             gerbil-ascent/candidate/provenance#proof-node::t
                             '#f)
                            (cdr _%atom30808%_))
                    '#f))
              (##structure-ref
               (##structure-ref
                _%receipt30815%_
                '10
                gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                '#f)
               '8
               gerbil-ascent/candidate/provenance#positive-proof::t
               '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        (gerbil-ascent/candidate/evidence-store#detached
                                         (list (list 'status
                                                     (if _%present30822%_
                                                         'verified
                                                         'finite-absent))
                                               (list 'present _%present30822%_)
                                               (list 'atom _%atom30808%_)
                                               (list 'handle _%handle30807%_)
                                               (list 'basis
                                                     'verified-finite-closure)
                                               (list 'support-nodes
                                                     (let ()
                                                       (declare (not safe))
                                                       (##map gerbil-ascent/candidate/provenance#proof-node-id
                                                              _%support30826%_)))
                                               (list 'scope
                                                     (gerbil-ascent/candidate/evidence-store#scope-description
                                                      _%entry30810%_)))))
                                      (gerbil-ascent/candidate/evidence-store#unknown
                                       'unknown-relation-or-arity)))
                                (gerbil-ascent/candidate/evidence-store#unknown
                                 'invalid-atom))
                            (gerbil-ascent/candidate/evidence-store#unknown
                             'stale-or-unknown-handle)))))
                   (_%fragment30661%_
                    (lambda (_%snapshot30781%_
                             _%candidate30782%_
                             _%handle30783%_
                             _%atom30784%_)
                      (let ((_%answer30786%_
                             (_%fact30660%_
                              _%snapshot30781%_
                              _%candidate30782%_
                              _%handle30783%_
                              _%atom30784%_)))
                        (if (eq? (cadr (assq 'status _%answer30786%_))
                                 'verified)
                            (let* ((_%proof30788%_
                                    (_%certificate30659%_
                                     _%snapshot30781%_
                                     _%candidate30782%_
                                     _%handle30783%_))
                                   (_%nodes30790%_
                                    (cadr (assq 'nodes _%proof30788%_)))
                                   (_%roots30792%_
                                    (cadr (assq 'support-nodes
                                                _%answer30786%_)))
                                   (_%seen30794%_ '())
                                   (_%selected30796%_ '()))
                              (letrec ((_%visit30799%_
                                        (lambda (_%id30801%_)
                                          (if (let ()
                                                (declare (not safe))
                                                (##member
                                                 _%id30801%_
                                                 _%seen30794%_))
                                              '#!void
                                              (let ((_%node30803%_
                                                     (assoc _%id30801%_
                                                            _%nodes30790%_)))
                                                (if _%node30803%_
                                                    '#!void
                                                    (let ()
                                                      (declare (not safe))
                                                      (error '"verified proof has missing support"
                                                             _%id30801%_)))
                                                (set! _%seen30794%_
                                                      (cons _%id30801%_
                                                            _%seen30794%_))
                                                (for-each
                                                 _%visit30799%_
                                                 (list-ref _%node30803%_ '5))
                                                (set! _%selected30796%_
                                                      (cons _%node30803%_
                                                            _%selected30796%_)))))))
                                (for-each _%visit30799%_ _%roots30792%_)
                                (gerbil-ascent/candidate/evidence-store#detached
                                 (list (list 'status 'verified)
                                       (list 'fact _%answer30786%_)
                                       (list 'roots _%roots30792%_)
                                       (list 'nodes
                                             (let ()
                                               (declare (not safe))
                                               (##reverse
                                                _%selected30796%_)))))))
                            _%answer30786%_)))))
            (let ((__tmp34467
                   (let ((__obj34431
                          (let ()
                            (declare (not safe))
                            (##structure
                             clan/poo/object#object::t
                             '#f
                             '#f
                             '#f
                             '#f
                             '#f
                             '#f
                             '#f))))
                     (let ((__tmp34481
                            (let ()
                              (declare (not safe))
                              (clan/poo/object#.ref
                               gerbil-ascent/candidate/evidence-store#GerbilAscentEvidenceStoreContract
                               'proto)))
                           (__tmp34469
                            (list (cons '.operations
                                        (let ((__tmp34470
                                               (lambda (_%@30676%_)
                                                 (let ((__obj34430
                                                        (let ()
                                                          (declare (not safe))
                                                          (##structure
                                                           clan/poo/object#object::t
                                                           '#f
                                                           '#f
                                                           '#f
                                                           '#f
                                                           '#f
                                                           '#f
                                                           '#f))))
                                                   (let ((__tmp34472
                                                          (list (cons '.resolve
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ((__tmp34473
                                     (lambda (_%self30700%_)
                                       (lambda (_%snapshot30707%_
                                                _%candidate30708%_)
                                         (_%serialized30655%_
                                          (lambda ()
                                            (_%resolve30657%_
                                             _%snapshot30707%_
                                             _%candidate30708%_)))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp34473)))
                        (cons '.claim
                              (let ((__tmp34474
                                     (lambda (_%self30711%_)
                                       (lambda (_%snapshot30716%_
                                                _%candidate30717%_
                                                _%handle30718%_
                                                _%row30719%_)
                                         (_%serialized30655%_
                                          (lambda ()
                                            (_%claim30658%_
                                             _%snapshot30716%_
                                             _%candidate30717%_
                                             _%handle30718%_
                                             _%row30719%_)))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp34474)))
                        (cons '.fact
                              (let ((__tmp34475
                                     (lambda (_%self30722%_)
                                       (lambda (_%snapshot30727%_
                                                _%candidate30728%_
                                                _%handle30729%_
                                                _%atom30730%_)
                                         (_%serialized30655%_
                                          (lambda ()
                                            (_%fact30660%_
                                             _%snapshot30727%_
                                             _%candidate30728%_
                                             _%handle30729%_
                                             _%atom30730%_)))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp34475)))
                        (cons '.fragment
                              (let ((__tmp34476
                                     (lambda (_%self30733%_)
                                       (lambda (_%snapshot30738%_
                                                _%candidate30739%_
                                                _%handle30740%_
                                                _%atom30741%_)
                                         (_%serialized30655%_
                                          (lambda ()
                                            (_%fragment30661%_
                                             _%snapshot30738%_
                                             _%candidate30739%_
                                             _%handle30740%_
                                             _%atom30741%_)))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp34476)))
                        (cons '.certificate
                              (let ((__tmp34477
                                     (lambda (_%self30744%_)
                                       (lambda (_%snapshot30749%_
                                                _%candidate30750%_
                                                _%handle30751%_)
                                         (_%serialized30655%_
                                          (lambda ()
                                            (_%certificate30659%_
                                             _%snapshot30749%_
                                             _%candidate30750%_
                                             _%handle30751%_)))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp34477)))
                        (cons '.partition
                              (let ((__tmp34478
                                     (lambda (_%self30754%_)
                                       (lambda (_%snapshot30759%_
                                                _%candidate30760%_
                                                _%handle30761%_
                                                _%alternatives30762%_)
                                         (_%serialized30655%_
                                          (lambda ()
                                            (gerbil-ascent/candidate/evidence-store#partition-obligations
                                             (lambda (_%atom30765%_)
                                               (_%fact30660%_
                                                _%snapshot30759%_
                                                _%candidate30760%_
                                                _%handle30761%_
                                                _%atom30765%_))
                                             _%alternatives30762%_)))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp34478)))
                        (cons '.stats
                              (let ((__tmp34479
                                     (lambda (_%self30767%_)
                                       (lambda ()
                                         (_%serialized30655%_
                                          (lambda ()
                                            (list (list 'entries
                                                        (let ()
                                                          (declare (not safe))
                                                          (__hash-length
                                                           _%entries30645%_)))
                                                  (list 'attempts
                                                        _%attempts30651%_)
                                                  (list 'proof-builds
                                                        _%builds30649%_)
                                                  (list 'hits _%hits30650%_)
                                                  (list 'evictions
                                                        _%evictions30652%_))))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp34479)))
                        (cons '.clear
                              (let ((__tmp34480
                                     (lambda (_%self30774%_)
                                       (lambda ()
                                         (_%serialized30655%_
                                          (lambda ()
                                            (set! _%entries30645%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (make-hash-table__%
                                                     '#f
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value)))
                                            (set! _%handles30646%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (make-hash-table__%
                                                     '#f
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value)))
                                            (set! _%order30647%_ '())
                                            '#t))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp34480)))))
                 (__tmp34471 (list)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (declare (not safe))
                                                     (clan/poo/object#object:::init!__%
                                                      '#f
                                                      '()
                                                      __tmp34472
                                                      __tmp34471
                                                      __obj34430))
                                                   __obj34430))))
                                          (declare (not safe))
                                          (##structure
                                           clan/poo/object#$self-slot-spec::t
                                           __tmp34470)))))
                           (__tmp34468 (list)))
                       (declare (not safe))
                       (clan/poo/object#object:::init!__%
                        '#f
                        __tmp34481
                        __tmp34469
                        __tmp34468
                        __obj34431))
                     __obj34431)))
              (declare (not safe))
              (clan/poo/mop#validate
               gerbil-ascent/candidate/evidence-store#GerbilAscentEvidenceStoreContract
               __tmp34467))))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__0
      (lambda ()
        (let* ((_%max-entries30902%_ '64)
               (_%proof-steps30904%_ '100000)
               (_%work-steps30906%_ '100000))
          (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__%
           _%max-entries30902%_
           _%proof-steps30904%_
           _%work-steps30906%_))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__1
      (lambda (_%max-entries30908%_)
        (let* ((_%proof-steps30910%_ '100000) (_%work-steps30912%_ '100000))
          (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__%
           _%max-entries30908%_
           _%proof-steps30910%_
           _%work-steps30912%_))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__2
      (lambda (_%max-entries30914%_ _%proof-steps30915%_)
        (let ((_%work-steps30917%_ '100000))
          (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__%
           _%max-entries30914%_
           _%proof-steps30915%_
           _%work-steps30917%_))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store
      (lambda _g34482_
        (let ((_g34483_ (let () (declare (not safe)) (##length _g34482_))))
          (cond ((let () (declare (not safe)) (##fx= _g34483_ 0))
                 (apply gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__0
                        _g34482_))
                ((let () (declare (not safe)) (##fx= _g34483_ 1))
                 (apply gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__1
                        _g34482_))
                ((let () (declare (not safe)) (##fx= _g34483_ 2))
                 (apply gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__2
                        _g34482_))
                ((let () (declare (not safe)) (##fx= _g34483_ 3))
                 (apply gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__%
                        _g34482_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store
                  _g34482_))))))
    (define gerbil-ascent/candidate/evidence-store#operation
      (lambda (_%store30635%_ _%name30636%_)
        (let ((__tmp34484
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%store30635%_ '.operations))))
          (declare (not safe))
          (clan/poo/object#.ref __tmp34484 _%name30636%_))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
      (lambda (_%store30631%_ _%snapshot30632%_ _%candidate30633%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30631%_
          '.resolve)
         _%snapshot30632%_
         _%candidate30633%_)))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-claim
      (lambda (_%store30625%_
               _%snapshot30626%_
               _%candidate30627%_
               _%handle30628%_
               _%row30629%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30625%_
          '.claim)
         _%snapshot30626%_
         _%candidate30627%_
         _%handle30628%_
         _%row30629%_)))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-fact
      (lambda (_%store30619%_
               _%snapshot30620%_
               _%candidate30621%_
               _%handle30622%_
               _%atom30623%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30619%_
          '.fact)
         _%snapshot30620%_
         _%candidate30621%_
         _%handle30622%_
         _%atom30623%_)))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-fragment
      (lambda (_%store30613%_
               _%snapshot30614%_
               _%candidate30615%_
               _%handle30616%_
               _%atom30617%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30613%_
          '.fragment)
         _%snapshot30614%_
         _%candidate30615%_
         _%handle30616%_
         _%atom30617%_)))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-certificate
      (lambda (_%store30608%_
               _%snapshot30609%_
               _%candidate30610%_
               _%handle30611%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30608%_
          '.certificate)
         _%snapshot30609%_
         _%candidate30610%_
         _%handle30611%_)))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-stats
      (lambda (_%store30606%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30606%_
          '.stats))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-clear!
      (lambda (_%store30604%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30604%_
          '.clear))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-partition
      (lambda (_%store30598%_
               _%snapshot30599%_
               _%candidate30600%_
               _%handle30601%_
               _%alternatives30602%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30598%_
          '.partition)
         _%snapshot30599%_
         _%candidate30600%_
         _%handle30601%_
         _%alternatives30602%_)))
    (define gerbil-ascent/candidate/evidence-store#partition-obligations
      (lambda (_%fact30572%_ _%alternatives30573%_)
        (if (and (let ()
                   (declare (not safe))
                   (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                    _%alternatives30573%_
                    '16384
                    '128))
                 (list? _%alternatives30573%_)
                 (let ((__tmp34485
                        (lambda (_%a30575%_)
                          (and (list? _%a30575%_)
                               (= (let ()
                                    (declare (not safe))
                                    (##length _%a30575%_))
                                  '2)
                               (let ((__tmp34486 (car _%a30575%_)))
                                 (declare (not safe))
                                 (gerbil-ascent/candidate/program#scalar?
                                  __tmp34486))
                               (list? (cadr _%a30575%_))))))
                   (declare (not safe))
                   (andmap__0 __tmp34485 _%alternatives30573%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid branch obligations")))
        (let ((_%seen30577%_ '())
              (_%eligible30578%_ '())
              (_%pruned30579%_ '())
              (_%unresolved30580%_ '())
              (_%allowed30581%_ '())
              (_%claims30582%_ '()))
          (for-each
           (lambda (_%alternative30584%_)
             (let* ((_%id30586%_ (car _%alternative30584%_))
                    (_%answers30588%_
                     (map _%fact30572%_ (cadr _%alternative30584%_)))
                    (_%statuses30592%_
                     (let ((__tmp34487
                            (lambda (_%answer30590%_)
                              (cadr (assq 'status _%answer30590%_)))))
                       (declare (not safe))
                       (##map __tmp34487 _%answers30588%_))))
               (if (let ()
                     (declare (not safe))
                     (##member _%id30586%_ _%seen30577%_))
                   (let ()
                     (declare (not safe))
                     (error '"duplicate branch ID" _%id30586%_))
                   '#!void)
               (set! _%seen30577%_ (cons _%id30586%_ _%seen30577%_))
               (set! _%claims30582%_
                     (cons (list _%id30586%_ _%answers30588%_)
                           _%claims30582%_))
               (if (let ()
                     (declare (not safe))
                     (##memq 'finite-absent _%statuses30592%_))
                   (set! _%pruned30579%_ (cons _%id30586%_ _%pruned30579%_))
                   (if (let ()
                         (declare (not safe))
                         (##memq 'unknown _%statuses30592%_))
                       (let ()
                         (set! _%unresolved30580%_
                               (cons _%id30586%_ _%unresolved30580%_))
                         (set! _%allowed30581%_
                               (cons _%id30586%_ _%allowed30581%_)))
                       (let ()
                         (set! _%eligible30578%_
                               (cons _%id30586%_ _%eligible30578%_))
                         (set! _%allowed30581%_
                               (cons _%id30586%_ _%allowed30581%_)))))))
           _%alternatives30573%_)
          (list (list 'eligible
                      (let ()
                        (declare (not safe))
                        (##reverse _%eligible30578%_)))
                (list 'pruned
                      (let ()
                        (declare (not safe))
                        (##reverse _%pruned30579%_)))
                (list 'unresolved
                      (let ()
                        (declare (not safe))
                        (##reverse _%unresolved30580%_)))
                (list 'allowed
                      (let ()
                        (declare (not safe))
                        (##reverse _%allowed30581%_)))
                (list 'claims
                      (let ()
                        (declare (not safe))
                        (##reverse _%claims30582%_)))))))))
