(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/reasoning[1]#_g34276_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34278_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-receipt
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34280_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34282_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34283_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34284_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34285_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34286_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34287_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34288_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34289_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-diagnostics
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34290_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34291_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34292_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-nonmembership
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34293_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-stratified
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34295_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34296_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34297_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34298_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34299_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34300_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34301_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34302_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-diagnostics-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34303_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34304_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34305_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-nonmembership-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34306_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-stratified-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34308_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34309_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34310_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34311_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34312_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34313_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34314_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34315_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-diagnostics
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34316_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34317_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34318_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-nonmembership
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34319_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-stratified
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34321_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34322_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34323_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34324_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34325_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34326_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34327_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34328_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-diagnostics-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34329_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34330_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34331_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-nonmembership-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34332_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-stratified-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34334_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34336_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34338_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34340_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34341_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-support
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34342_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-reachable
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34344_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34345_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-support-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34346_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-reachable-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34348_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34349_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-support
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34350_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-reachable
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34352_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34353_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-support-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34354_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-reachable-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34356_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34358_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-stratified-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34360_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34362_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34363_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-finite
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34364_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34365_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34367_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34368_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-finite-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34369_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34370_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34372_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34373_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-finite
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34374_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34375_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34377_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34378_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-finite-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34379_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34380_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34382_|
    (##structure
     gx#syntax-quote::t
     'captured-stage::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34384_|
    (##structure
     gx#syntax-quote::t
     'make-captured-stage
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34386_|
    (##structure
     gx#syntax-quote::t
     'captured-stage?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34388_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-ok?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34389_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34391_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-ok?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34392_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34394_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-ok?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34395_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34397_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-ok?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34398_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34400_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34402_|
    (##structure
     gx#syntax-quote::t
     'make-attempt-observation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34404_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34406_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34407_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34409_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34410_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34412_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34413_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34415_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34416_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/reasoning[:0:]#reasoning-receipt|
      (let ((__obj34194
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34194
           'gerbil-ascent/candidate/reasoning#reasoning-receipt::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34194
           'reasoning-receipt
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34194
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    rows
                    diagnostics
                    evidence
                    proof
                    nonmembership
                    stratified)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34194
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    rows
                    diagnostics
                    evidence
                    proof
                    nonmembership
                    stratified)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34194 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34194 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34194 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34194 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34194 '#f '13 '#f '#f))
        (let ((__tmp34275 |gerbil-ascent/candidate/reasoning[1]#_g34276_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34194 __tmp34275 '4 '#f '#f))
        (let ((__tmp34277 |gerbil-ascent/candidate/reasoning[1]#_g34278_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34194 __tmp34277 '14 '#f '#f))
        (let ((__tmp34279 |gerbil-ascent/candidate/reasoning[1]#_g34280_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34194 __tmp34279 '15 '#f '#f))
        (let ((__tmp34281
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g34282_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g34283_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g34284_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g34285_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g34286_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g34287_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g34288_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g34289_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g34290_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g34291_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g34292_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g34293_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj34194 __tmp34281 '16 '#f '#f))
        (let ((__tmp34294
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g34295_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g34296_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g34297_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g34298_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g34299_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g34300_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g34301_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g34302_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g34303_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g34304_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g34305_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g34306_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj34194 __tmp34294 '17 '#f '#f))
        (let ((__tmp34307
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g34308_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g34309_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g34310_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g34311_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g34312_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g34313_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g34314_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g34315_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g34316_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g34317_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g34318_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g34319_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj34194 __tmp34307 '18 '#f '#f))
        (let ((__tmp34320
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g34321_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g34322_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g34323_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g34324_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g34325_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g34326_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g34327_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g34328_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g34329_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g34330_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g34331_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g34332_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj34194 __tmp34320 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34194 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34194 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34194 '() '21 '#f '#f))
        __obj34194))
    (define |gerbil-ascent/candidate/reasoning[:0:]#reasoning-evidence|
      (let ((__obj34195
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34195
           'gerbil-ascent/candidate/reasoning#reasoning-evidence::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34195
           'reasoning-evidence
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34195
           '(kind support reachable)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34195
           '(kind support reachable)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34195 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34195 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34195 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34195 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34195 '#f '13 '#f '#f))
        (let ((__tmp34333 |gerbil-ascent/candidate/reasoning[1]#_g34334_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34195 __tmp34333 '4 '#f '#f))
        (let ((__tmp34335 |gerbil-ascent/candidate/reasoning[1]#_g34336_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34195 __tmp34335 '14 '#f '#f))
        (let ((__tmp34337 |gerbil-ascent/candidate/reasoning[1]#_g34338_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34195 __tmp34337 '15 '#f '#f))
        (let ((__tmp34339
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g34340_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g34341_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g34342_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34195 __tmp34339 '16 '#f '#f))
        (let ((__tmp34343
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g34344_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g34345_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g34346_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34195 __tmp34343 '17 '#f '#f))
        (let ((__tmp34347
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g34348_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g34349_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g34350_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34195 __tmp34347 '18 '#f '#f))
        (let ((__tmp34351
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g34352_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g34353_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g34354_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34195 __tmp34351 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34195 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34195 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34195 '() '21 '#f '#f))
        __obj34195))
    (define |gerbil-ascent/candidate/reasoning[:0:]#reasoning-stratified-evidence|
      (let ((__obj34196
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34196
           'gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34196
           'reasoning-stratified-evidence
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34196
           '(status finite proof work-budget)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34196
           '(status finite proof work-budget)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34196 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34196 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34196 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34196 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34196 '#f '13 '#f '#f))
        (let ((__tmp34355 |gerbil-ascent/candidate/reasoning[1]#_g34356_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34196 __tmp34355 '4 '#f '#f))
        (let ((__tmp34357 |gerbil-ascent/candidate/reasoning[1]#_g34358_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34196 __tmp34357 '14 '#f '#f))
        (let ((__tmp34359 |gerbil-ascent/candidate/reasoning[1]#_g34360_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34196 __tmp34359 '15 '#f '#f))
        (let ((__tmp34361
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g34362_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g34363_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g34364_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g34365_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34196 __tmp34361 '16 '#f '#f))
        (let ((__tmp34366
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g34367_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g34368_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g34369_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g34370_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34196 __tmp34366 '17 '#f '#f))
        (let ((__tmp34371
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g34372_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g34373_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g34374_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g34375_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34196 __tmp34371 '18 '#f '#f))
        (let ((__tmp34376
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g34377_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g34378_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g34379_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g34380_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34196 __tmp34376 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34196 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34196 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34196 '() '21 '#f '#f))
        __obj34196))
    (define |gerbil-ascent/candidate/reasoning[:0:]#captured-stage|
      (let ((__obj34197
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34197
           'gerbil-ascent/candidate/reasoning#captured-stage::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34197 'captured-stage '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34197 '(ok? value) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34197 '(ok? value) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34197 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34197 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34197 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34197 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34197 '#f '13 '#f '#f))
        (let ((__tmp34381 |gerbil-ascent/candidate/reasoning[1]#_g34382_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34197 __tmp34381 '4 '#f '#f))
        (let ((__tmp34383 |gerbil-ascent/candidate/reasoning[1]#_g34384_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34197 __tmp34383 '14 '#f '#f))
        (let ((__tmp34385 |gerbil-ascent/candidate/reasoning[1]#_g34386_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34197 __tmp34385 '15 '#f '#f))
        (let ((__tmp34387
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g34388_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g34389_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34197 __tmp34387 '16 '#f '#f))
        (let ((__tmp34390
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g34391_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g34392_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34197 __tmp34390 '17 '#f '#f))
        (let ((__tmp34393
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g34394_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g34395_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34197 __tmp34393 '18 '#f '#f))
        (let ((__tmp34396
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g34397_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g34398_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34197 __tmp34396 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34197 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34197 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34197 '() '21 '#f '#f))
        __obj34197))
    (define |gerbil-ascent/candidate/reasoning[:0:]#attempt-observation|
      (let ((__obj34198
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34198
           'gerbil-ascent/candidate/reasoning#attempt-observation::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34198
           'attempt-observation
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34198 '(rows evidence) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34198 '(rows evidence) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34198 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34198 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34198 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34198 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34198 '#f '13 '#f '#f))
        (let ((__tmp34399 |gerbil-ascent/candidate/reasoning[1]#_g34400_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34198 __tmp34399 '4 '#f '#f))
        (let ((__tmp34401 |gerbil-ascent/candidate/reasoning[1]#_g34402_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34198 __tmp34401 '14 '#f '#f))
        (let ((__tmp34403 |gerbil-ascent/candidate/reasoning[1]#_g34404_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34198 __tmp34403 '15 '#f '#f))
        (let ((__tmp34405
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g34406_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g34407_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34198 __tmp34405 '16 '#f '#f))
        (let ((__tmp34408
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g34409_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g34410_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34198 __tmp34408 '17 '#f '#f))
        (let ((__tmp34411
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g34412_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g34413_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34198 __tmp34411 '18 '#f '#f))
        (let ((__tmp34414
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g34415_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g34416_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34198 __tmp34414 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34198 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34198 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34198 '() '21 '#f '#f))
        __obj34198))))
