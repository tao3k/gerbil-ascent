(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/storage[1]#_g35163_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35165_|
    (##structure
     gx#syntax-quote::t
     'make-storage-state-owner
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35167_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35169_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35170_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner-phase
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35172_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35173_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner-phase-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35175_|
    (##structure
     gx#syntax-quote::t
     '&storage-state-owner-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35176_|
    (##structure
     gx#syntax-quote::t
     '&storage-state-owner-phase
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35178_|
    (##structure
     gx#syntax-quote::t
     '&storage-state-owner-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35179_|
    (##structure
     gx#syntax-quote::t
     '&storage-state-owner-phase-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[:0:]#storage-state-owner|
    (let ((__obj35117
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj35117
         'gerbil-ascent/table/storage#storage-state-owner::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj35117
         'storage-state-owner
         '3
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35117 '(value phase) '6 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35117 '(value phase) '8 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35117 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35117 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35117 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35117 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35117 '#f '13 '#f '#f))
      (let ((__tmp35162 |gerbil-ascent/table/storage[1]#_g35163_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35117 __tmp35162 '4 '#f '#f))
      (let ((__tmp35164 |gerbil-ascent/table/storage[1]#_g35165_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35117 __tmp35164 '14 '#f '#f))
      (let ((__tmp35166 |gerbil-ascent/table/storage[1]#_g35167_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35117 __tmp35166 '15 '#f '#f))
      (let ((__tmp35168
             (cons (cons 'value |gerbil-ascent/table/storage[1]#_g35169_|)
                   (cons (cons 'phase
                               |gerbil-ascent/table/storage[1]#_g35170_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35117 __tmp35168 '16 '#f '#f))
      (let ((__tmp35171
             (cons (cons 'value |gerbil-ascent/table/storage[1]#_g35172_|)
                   (cons (cons 'phase
                               |gerbil-ascent/table/storage[1]#_g35173_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35117 __tmp35171 '17 '#f '#f))
      (let ((__tmp35174
             (cons (cons 'value |gerbil-ascent/table/storage[1]#_g35175_|)
                   (cons (cons 'phase
                               |gerbil-ascent/table/storage[1]#_g35176_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35117 __tmp35174 '18 '#f '#f))
      (let ((__tmp35177
             (cons (cons 'value |gerbil-ascent/table/storage[1]#_g35178_|)
                   (cons (cons 'phase
                               |gerbil-ascent/table/storage[1]#_g35179_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35117 __tmp35177 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35117 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35117 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35117 '() '21 '#f '#f))
      __obj35117)))
