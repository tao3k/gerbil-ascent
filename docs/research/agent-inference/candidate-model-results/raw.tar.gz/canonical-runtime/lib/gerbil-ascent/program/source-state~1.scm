(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/source-state[1]#_g36884_|
    (##structure
     gx#syntax-quote::t
     'source-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36886_|
    (##structure
     gx#syntax-quote::t
     'make-source-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36888_|
    (##structure
     gx#syntax-quote::t
     'source-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36890_|
    (##structure
     gx#syntax-quote::t
     'source-state-originals
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36891_|
    (##structure
     gx#syntax-quote::t
     'source-state-additions
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36892_|
    (##structure
     gx#syntax-quote::t
     'source-state-overrides
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36893_|
    (##structure
     gx#syntax-quote::t
     'source-state-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36895_|
    (##structure
     gx#syntax-quote::t
     'source-state-originals-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36896_|
    (##structure
     gx#syntax-quote::t
     'source-state-additions-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36897_|
    (##structure
     gx#syntax-quote::t
     'source-state-overrides-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36898_|
    (##structure
     gx#syntax-quote::t
     'source-state-snapshot-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36900_|
    (##structure
     gx#syntax-quote::t
     '&source-state-originals
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36901_|
    (##structure
     gx#syntax-quote::t
     '&source-state-additions
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36902_|
    (##structure
     gx#syntax-quote::t
     '&source-state-overrides
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36903_|
    (##structure
     gx#syntax-quote::t
     '&source-state-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36905_|
    (##structure
     gx#syntax-quote::t
     '&source-state-originals-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36906_|
    (##structure
     gx#syntax-quote::t
     '&source-state-additions-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36907_|
    (##structure
     gx#syntax-quote::t
     '&source-state-overrides-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36908_|
    (##structure
     gx#syntax-quote::t
     '&source-state-snapshot-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36910_|
    (gx#core-deserialize-mark
     '(0
       ($%arg16930 . _%$%arg1693017001%_)
       ($%arg16929 . _%$%arg1692916987%_)
       (id . _%id16954%_)
       (arg . _%arg17017%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-state[1]#_g36911_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g36910_|)))
  (define |gerbil-ascent/program/source-state[1]#_g36914_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-state[1]#_g36915_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g36914_|)))
  (define |gerbil-ascent/program/source-state[1]#_g36917_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g36914_|)))
  (define |gerbil-ascent/program/source-state[1]#_g36919_|
    (gx#core-deserialize-mark
     '(0
       ($%arg17051 . _%$%arg1705117121%_)
       ($%arg17050 . _%$%arg1705017107%_)
       (id . _%id17074%_)
       (arg . _%arg17137%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-state[1]#_g36920_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g36919_|)))
  (define |gerbil-ascent/program/source-state[1]#_g36923_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-state[1]#_g36924_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g36923_|)))
  (define |gerbil-ascent/program/source-state[1]#_g36926_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g36923_|)))
  (define |gerbil-ascent/program/source-state[1]#_g36928_|
    (gx#core-deserialize-mark
     '(0
       ($%arg17171 . _%$%arg1717117241%_)
       (id . _%id17194%_)
       ($%arg17170 . _%$%arg1717017227%_)
       (arg . _%arg17257%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-state[1]#_g36929_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g36928_|)))
  (define |gerbil-ascent/program/source-state[1]#_g36932_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-state[1]#_g36933_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g36932_|)))
  (define |gerbil-ascent/program/source-state[1]#_g36935_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g36932_|)))
  (begin
    (define |gerbil-ascent/program/source-state[:0:]#source-state|
      (let ((__obj36823
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36823
           'gerbil-ascent/program/source-state#source-state::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36823 'source-state '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36823
           '(originals additions overrides snapshot)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36823
           '(originals additions overrides snapshot)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36823 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36823 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36823 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36823 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36823 '#f '13 '#f '#f))
        (let ((__tmp36883 |gerbil-ascent/program/source-state[1]#_g36884_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36823 __tmp36883 '4 '#f '#f))
        (let ((__tmp36885 |gerbil-ascent/program/source-state[1]#_g36886_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36823 __tmp36885 '14 '#f '#f))
        (let ((__tmp36887 |gerbil-ascent/program/source-state[1]#_g36888_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36823 __tmp36887 '15 '#f '#f))
        (let ((__tmp36889
               (cons (cons 'originals
                           |gerbil-ascent/program/source-state[1]#_g36890_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-state[1]#_g36891_|)
                           (cons (cons 'overrides
                                       |gerbil-ascent/program/source-state[1]#_g36892_|)
                                 (cons (cons 'snapshot
                                             |gerbil-ascent/program/source-state[1]#_g36893_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36823 __tmp36889 '16 '#f '#f))
        (let ((__tmp36894
               (cons (cons 'originals
                           |gerbil-ascent/program/source-state[1]#_g36895_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-state[1]#_g36896_|)
                           (cons (cons 'overrides
                                       |gerbil-ascent/program/source-state[1]#_g36897_|)
                                 (cons (cons 'snapshot
                                             |gerbil-ascent/program/source-state[1]#_g36898_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36823 __tmp36894 '17 '#f '#f))
        (let ((__tmp36899
               (cons (cons 'originals
                           |gerbil-ascent/program/source-state[1]#_g36900_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-state[1]#_g36901_|)
                           (cons (cons 'overrides
                                       |gerbil-ascent/program/source-state[1]#_g36902_|)
                                 (cons (cons 'snapshot
                                             |gerbil-ascent/program/source-state[1]#_g36903_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36823 __tmp36899 '18 '#f '#f))
        (let ((__tmp36904
               (cons (cons 'originals
                           |gerbil-ascent/program/source-state[1]#_g36905_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-state[1]#_g36906_|)
                           (cons (cons 'overrides
                                       |gerbil-ascent/program/source-state[1]#_g36907_|)
                                 (cons (cons 'snapshot
                                             |gerbil-ascent/program/source-state[1]#_g36908_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36823 __tmp36904 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36823 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36823 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36823 '() '21 '#f '#f))
        __obj36823))
    (define |gerbil-ascent/program/source-state[:0:]#@gerbil-ascent-source-state-rows|
      (lambda (_%$stx16911%_)
        (let* ((_%__stx3674636747%_ _%$stx16911%_)
               (_%$%g1691616937%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3674636747%_)))))
          (let ((_%__kont3674936750%_
                 (lambda (_%$%g1691817003%_)
                   (cons (let ((__tmp36909
                                |gerbil-ascent/program/source-state[1]#_g36911_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp36909
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'state))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'index))
                                                 '()))
                                     (cons (let ((__tmp36912
                                                  (lambda (_%$%g1701817021%_
                                                           _%$%g1701917024%_)
                                                    (cons _%$%g1701817021%_
                                                          _%$%g1701917024%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp36912
                                              '()
                                              _%$%g1691817003%_))
                                           '()))
                               (cons (cons (let ((__tmp36913
                                                  |gerbil-ascent/program/source-state[1]#_g36915_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp36913
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'state))
                     (cons (let ((__tmp36916
                                  |gerbil-ascent/program/source-state[1]#_g36917_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp36916 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'source-state))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0
                        '#f
                        '__gerbil-ascent-source-state-rows))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'state))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'index))
                                 '())))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3675336754%_
                 (lambda (_%$%g1693116944%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0
                      '#f
                      'gerbil-ascent-source-state-rows)))))
            (let* ((_%$%g1691516956%_
                    (lambda ()
                      (let ((_%$%g1693116944%_ _%__stx3674636747%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1693116944%_))
                            (_%__kont3675336754%_ _%$%g1693116944%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1691616937%_))))))
                   (_%__match3676936770%_
                    (lambda (_%$%e1691916963%_
                             _%$%hd1692016967%_
                             _%$%tl1692116970%_
                             _%__splice3675136752%_
                             _%$%target1692216973%_
                             _%$%tl1692416976%_)
                      (letrec ((_%$%loop1692516979%_
                                (lambda (_%$%hd1692316983%_
                                         _%$%arg1692916986%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1692316983%_))
                                      (let ((_%$%e1692616989%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1692316983%_))))
                                        (let ((_%$%lp-tl1692816996%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1692616989%_)))
                                              (_%$%lp-hd1692716993%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1692616989%_))))
                                          (_%$%loop1692516979%_
                                           _%$%lp-tl1692816996%_
                                           (cons _%$%lp-hd1692716993%_
                                                 _%$%arg1692916986%_))))
                                      (let ((_%$%arg1693016999%_
                                             (reverse _%$%arg1692916986%_)))
                                        (_%__kont3674936750%_
                                         _%$%arg1693016999%_))))))
                        (_%$%loop1692516979%_ _%$%target1692216973%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3674636747%_))
                  (let ((_%$%e1691916963%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3674636747%_))))
                    (let ((_%$%tl1692116970%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1691916963%_)))
                          (_%$%hd1692016967%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1691916963%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1692116970%_))
                          (let ((_%__splice3675136752%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1692116970%_
                                    '0))))
                            (let ((_%$%tl1692416976%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3675136752%_ '1)))
                                  (_%$%target1692216973%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3675136752%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1692416976%_))
                                  (_%__match3676936770%_
                                   _%$%e1691916963%_
                                   _%$%hd1692016967%_
                                   _%$%tl1692116970%_
                                   _%__splice3675136752%_
                                   _%$%target1692216973%_
                                   _%$%tl1692416976%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1691516956%_)))))
                          (let () (declare (not safe)) (_%$%g1691516956%_)))))
                  (let () (declare (not safe)) (_%$%g1691516956%_))))))))
    (define |gerbil-ascent/program/source-state[:0:]#@gerbil-ascent-prepare-source-replacement|
      (lambda (_%$stx17032%_)
        (let* ((_%__stx3677236773%_ _%$stx17032%_)
               (_%$%g1703717058%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3677236773%_)))))
          (let ((_%__kont3677536776%_
                 (lambda (_%$%g1703917123%_)
                   (cons (let ((__tmp36918
                                |gerbil-ascent/program/source-state[1]#_g36920_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp36918
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'state))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'index))
                                                 (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'rows))
                                                       '())))
                                     (cons (let ((__tmp36921
                                                  (lambda (_%$%g1713817141%_
                                                           _%$%g1713917144%_)
                                                    (cons _%$%g1713817141%_
                                                          _%$%g1713917144%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp36921
                                              '()
                                              _%$%g1703917123%_))
                                           '()))
                               (cons (cons (let ((__tmp36922
                                                  |gerbil-ascent/program/source-state[1]#_g36924_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp36922
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'state))
                     (cons (let ((__tmp36925
                                  |gerbil-ascent/program/source-state[1]#_g36926_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp36925 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'source-state))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0
                        '#f
                        '__gerbil-ascent-prepare-source-replacement))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'state))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'index))
                                 (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'rows))
                                       '()))))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3677936780%_
                 (lambda (_%$%g1705217065%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0
                      '#f
                      'gerbil-ascent-prepare-source-replacement)))))
            (let* ((_%$%g1703617076%_
                    (lambda ()
                      (let ((_%$%g1705217065%_ _%__stx3677236773%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1705217065%_))
                            (_%__kont3677936780%_ _%$%g1705217065%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1703717058%_))))))
                   (_%__match3679536796%_
                    (lambda (_%$%e1704017083%_
                             _%$%hd1704117087%_
                             _%$%tl1704217090%_
                             _%__splice3677736778%_
                             _%$%target1704317093%_
                             _%$%tl1704517096%_)
                      (letrec ((_%$%loop1704617099%_
                                (lambda (_%$%hd1704417103%_
                                         _%$%arg1705017106%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1704417103%_))
                                      (let ((_%$%e1704717109%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1704417103%_))))
                                        (let ((_%$%lp-tl1704917116%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1704717109%_)))
                                              (_%$%lp-hd1704817113%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1704717109%_))))
                                          (_%$%loop1704617099%_
                                           _%$%lp-tl1704917116%_
                                           (cons _%$%lp-hd1704817113%_
                                                 _%$%arg1705017106%_))))
                                      (let ((_%$%arg1705117119%_
                                             (reverse _%$%arg1705017106%_)))
                                        (_%__kont3677536776%_
                                         _%$%arg1705117119%_))))))
                        (_%$%loop1704617099%_ _%$%target1704317093%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3677236773%_))
                  (let ((_%$%e1704017083%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3677236773%_))))
                    (let ((_%$%tl1704217090%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1704017083%_)))
                          (_%$%hd1704117087%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1704017083%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1704217090%_))
                          (let ((_%__splice3677736778%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1704217090%_
                                    '0))))
                            (let ((_%$%tl1704517096%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3677736778%_ '1)))
                                  (_%$%target1704317093%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3677736778%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1704517096%_))
                                  (_%__match3679536796%_
                                   _%$%e1704017083%_
                                   _%$%hd1704117087%_
                                   _%$%tl1704217090%_
                                   _%__splice3677736778%_
                                   _%$%target1704317093%_
                                   _%$%tl1704517096%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1703617076%_)))))
                          (let () (declare (not safe)) (_%$%g1703617076%_)))))
                  (let () (declare (not safe)) (_%$%g1703617076%_))))))))
    (define |gerbil-ascent/program/source-state[:0:]#@gerbil-ascent-commit-source-replacement!|
      (lambda (_%$stx17152%_)
        (let* ((_%__stx3679836799%_ _%$stx17152%_)
               (_%$%g1715717178%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3679836799%_)))))
          (let ((_%__kont3680136802%_
                 (lambda (_%$%g1715917243%_)
                   (cons (let ((__tmp36927
                                |gerbil-ascent/program/source-state[1]#_g36929_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp36927
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'state))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'index))
                                                 (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'rows))
                                                       (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'cut))
                     '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     (cons (let ((__tmp36930
                                                  (lambda (_%$%g1725817261%_
                                                           _%$%g1725917264%_)
                                                    (cons _%$%g1725817261%_
                                                          _%$%g1725917264%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp36930
                                              '()
                                              _%$%g1715917243%_))
                                           '()))
                               (cons (cons (let ((__tmp36931
                                                  |gerbil-ascent/program/source-state[1]#_g36933_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp36931
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'state))
                     (cons (let ((__tmp36934
                                  |gerbil-ascent/program/source-state[1]#_g36935_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp36934 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'source-state))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0
                        '#f
                        '__gerbil-ascent-commit-source-replacement!))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'state))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'index))
                                 (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'rows))
                                       (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f 'cut))
                                             '())))))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3680536806%_
                 (lambda (_%$%g1717217185%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0
                      '#f
                      'gerbil-ascent-commit-source-replacement!)))))
            (let* ((_%$%g1715617196%_
                    (lambda ()
                      (let ((_%$%g1717217185%_ _%__stx3679836799%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1717217185%_))
                            (_%__kont3680536806%_ _%$%g1717217185%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1715717178%_))))))
                   (_%__match3682136822%_
                    (lambda (_%$%e1716017203%_
                             _%$%hd1716117207%_
                             _%$%tl1716217210%_
                             _%__splice3680336804%_
                             _%$%target1716317213%_
                             _%$%tl1716517216%_)
                      (letrec ((_%$%loop1716617219%_
                                (lambda (_%$%hd1716417223%_
                                         _%$%arg1717017226%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1716417223%_))
                                      (let ((_%$%e1716717229%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1716417223%_))))
                                        (let ((_%$%lp-tl1716917236%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1716717229%_)))
                                              (_%$%lp-hd1716817233%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1716717229%_))))
                                          (_%$%loop1716617219%_
                                           _%$%lp-tl1716917236%_
                                           (cons _%$%lp-hd1716817233%_
                                                 _%$%arg1717017226%_))))
                                      (let ((_%$%arg1717117239%_
                                             (reverse _%$%arg1717017226%_)))
                                        (_%__kont3680136802%_
                                         _%$%arg1717117239%_))))))
                        (_%$%loop1716617219%_ _%$%target1716317213%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3679836799%_))
                  (let ((_%$%e1716017203%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3679836799%_))))
                    (let ((_%$%tl1716217210%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1716017203%_)))
                          (_%$%hd1716117207%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1716017203%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1716217210%_))
                          (let ((_%__splice3680336804%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1716217210%_
                                    '0))))
                            (let ((_%$%tl1716517216%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3680336804%_ '1)))
                                  (_%$%target1716317213%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3680336804%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1716517216%_))
                                  (_%__match3682136822%_
                                   _%$%e1716017203%_
                                   _%$%hd1716117207%_
                                   _%$%tl1716217210%_
                                   _%__splice3680336804%_
                                   _%$%target1716317213%_
                                   _%$%tl1716517216%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1715617196%_)))))
                          (let () (declare (not safe)) (_%$%g1715617196%_)))))
                  (let () (declare (not safe)) (_%$%g1715617196%_))))))))))
