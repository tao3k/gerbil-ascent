import importlib.util,json
from pathlib import Path
p=Path.cwd()/'tools/research/candidate-model.py';spec=importlib.util.spec_from_file_location('m',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
out=m.RUNTIME.parent/'structured-branch-turn-qualification';out.mkdir(exist_ok=False)
question='Choose one available parentId and optionId to expand while searching for the highest-value feasible complete selection.'
tool={'type':'function','name':'expand','description':'Expand one available child from the frontier.','parameters':{'type':'object','properties':{'parentId':{'type':'integer'},'optionId':{'type':'integer'}},'required':['parentId','optionId'],'additionalProperties':False}}
plan={'model':'deepseek-flash','tool':tool,'budget':8192,'outputCap':2048,'minimumOutputCap':1024,'inputReservationPadding':256}
context={'task':{'stages':2,'options':[{'id':0,'stage':0,'value':1},{'id':1,'stage':1,'value':2}],'objective':'Maximize sum value, one option per stage.'},'frontier':[{'parentId':0,'selection':[],'optionIds':[0]}],'incumbent':None,'question':question}
m.save(out/'plan.json',{'budget':8192,'question':question,'firstContext':context,'tool':tool,'textFormat':{'type':'json_schema','name':'branch_action','schema':tool['parameters']},'scope':'Synthetic two-extension structured decoding control; same ordinary question, low thinking and action schema on each extension. No instruction added. Separate from research trajectories.'})
history=[];pending=None;spent=0;history_tokens=None;rows=[]
for turn in range(2):
 req,reserve=m.branch_request(plan,context,history,pending,spent,history_tokens)
 if turn:
  if pending is not None:req['input'].append({'role':'user','content':json.dumps({'question':question})})
  else:
   req['input'][-1]['content']=json.dumps({'extensionResult':{k:v for k,v in context.items() if k not in ('task','question')},'question':question})
 req['text']={'format':{'type':'json_schema','name':'branch_action','schema':tool['parameters']}}
 d=out/str(turn);d.mkdir();m.save(d/'request.json',req)
 _,meta=m.provider(req,m.provider_key(),d/'response.json');term=meta.get('terminal') or {};u=term.get('usage');r={'turn':turn,'status':term.get('status'),'usage':u,'failure':meta.get('error')};rows.append(r);m.save(out/'receipt.json',rows)
 assert not meta.get('error') and term.get('status')=='completed'
 action,encoding,pending=m.branch_action(term);r.update(action=action,wireEncoding=encoding)
 assert action=={'parentId':turn,'optionId':turn}
 history_tokens=u['input_tokens']+u['output_tokens'];spent+=history_tokens;assert spent<=8192
 history=req['input']+term['output'];context['frontier']=[{'parentId':1,'selection':[0],'optionIds':[1]}]
 m.save(out/'receipt.json',rows)
print('\nBRANCH_TURN_CONTROL_OK',spent,flush=True)
