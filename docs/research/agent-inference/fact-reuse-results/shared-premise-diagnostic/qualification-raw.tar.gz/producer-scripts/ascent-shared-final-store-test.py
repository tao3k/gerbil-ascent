import importlib.util,json,subprocess,time
from pathlib import Path
p=Path.cwd()/'tools/research/candidate-model.py';spec=importlib.util.spec_from_file_location('m',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
out=m.RUNTIME.parent/'shared-premise-final-qualification';cmd=json.loads((m.RUNTIME.parent/'reuse-store-test.json').read_text())['command'];began=time.monotonic()
with (out/'evidence-store-test.log').open('w') as log:r=subprocess.run(cmd,env=m.environment(),cwd=m.ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=120)
m.save(out/'evidence-store-test.json',{'command':cmd,'exit':r.returncode,'passed':r.returncode==0 and 'EVIDENCE-STORE-REGRESSION-OK' in (out/'evidence-store-test.log').read_text(),'seconds':time.monotonic()-began,'sourceCaptureSha256':m.digest(m.RUNTIME/'source-capture.json')})
assert r.returncode==0;print('LATEST_EVIDENCE_STORE_OK',flush=True)
