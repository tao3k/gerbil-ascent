(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/storage::timestamp 1791687545)
  (begin
    (define gerbil-ascent/table/storage#+make-state+
      (let ((__tmp8560 (lambda (_%_value8550%_ _%_context8551%_) '())))
        (declare (not safe))
        (core/types#poo-flow-predicate-contract
         'ascent/storage-make-state
         procedure?
         __tmp8560)))
    (define gerbil-ascent/table/storage#+extend+
      (let ((__tmp8561 (lambda (_%_value8547%_ _%_context8548%_) '())))
        (declare (not safe))
        (core/types#poo-flow-predicate-contract
         'ascent/storage-extend
         procedure?
         __tmp8561)))
    (define gerbil-ascent/table/storage#GerbilAscentStorageProviderContract
      (let ((__obj8554
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp8563
               (list (cons 'sexp
                           (let ((__tmp8564
                                  (lambda (_%@8493%_)
                                    'GerbilAscentStorageProviderContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp8564)))
                     (cons 'identity
                           (let ((__tmp8565
                                  (lambda (_%@8499%_)
                                    'ascent/storage-provider)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp8565)))
                     (cons 'proto
                           (let ((__tmp8566
                                  (lambda (_%@8504%_)
                                    (let ((__obj8552
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp8568 (list))
                                            (__tmp8567 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp8568
                                         __tmp8567
                                         __obj8552))
                                      __obj8552))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp8566)))
                     (cons 'responsibilities
                           (let ((__tmp8569
                                  (lambda (_%@8518%_)
                                    (let ((__obj8553
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp8571
                                             (list (cons '.make-state
                                                         (let ((__tmp8572
                                                                (lambda (_%self8535%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/table/storage#+make-state+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp8572)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.extend-rows
                                                         (let ((__tmp8573
                                                                (lambda (_%self8542%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/table/storage#+extend+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp8573)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp8570 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp8571
                                         __tmp8570
                                         __obj8553))
                                      __obj8553))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp8569)))))
              (__tmp8562 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp8563
           __tmp8562
           __obj8554))
        __obj8554))
    (define gerbil-ascent/table/storage#StorageProvider.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/table/storage#GerbilAscentStorageProviderContract
         'proto)))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-make-state
      (lambda (_%provider8478%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%provider8478%_ '.make-state)))))
    (define gerbil-ascent/table/storage#gerbil-ascent-set-batch-admit!
      (lambda (_%source-log8304%_
               _%count8305%_
               _%seen8306%_
               _%share-source?8307%_)
        (letrec ((_%admit8309%_
                  (lambda (_%present8412%_)
                    (let ((_%source-order8420%_
                           (let _%collect8414%_ ((_%cursor8416%_
                                                  _%source-log8304%_)
                                                 (_%left8417%_ _%count8305%_)
                                                 (_%ordered8418%_ '()))
                             (if (= _%left8417%_ '0)
                                 _%ordered8418%_
                                 (_%collect8414%_
                                  (cdr _%cursor8416%_)
                                  (let ()
                                    (declare (not safe))
                                    (##fx- _%left8417%_ '1))
                                  (cons (car _%cursor8416%_)
                                        _%ordered8418%_))))))
                      (let _%deduplicate8422%_ ((_%remaining8424%_
                                                 _%source-order8420%_)
                                                (_%accepted8425%_ '()))
                        (if (null? _%remaining8424%_)
                            (values _%accepted8425%_ _%present8412%_)
                            (let ((_%row8427%_ (car _%remaining8424%_)))
                              (if (let* ((_%h8429%_ _%present8412%_)
                                         (_%key8432%_ _%row8427%_)
                                         (_%h8436%_
                                          (let ()
                                            (declare (not safe))
                                            (cast HashTable::interface
                                                  _%h8429%_)))
                                         (_%h8438%_ _%h8436%_))
                                    (declare (not safe))
                                    (__hash-get _%h8438%_ _%key8432%_))
                                  (_%deduplicate8422%_
                                   (cdr _%remaining8424%_)
                                   _%accepted8425%_)
                                  (begin
                                    (let* ((_%h8454%_ _%present8412%_)
                                           (_%key8457%_ _%row8427%_)
                                           (_%value8460%_ '#t)
                                           (_%h8464%_
                                            (let ()
                                              (declare (not safe))
                                              (cast HashTable::interface
                                                    _%h8454%_)))
                                           (_%h8466%_ _%h8464%_))
                                      (declare (not safe))
                                      (__hash-put!
                                       _%h8466%_
                                       _%key8457%_
                                       _%value8460%_))
                                    (_%deduplicate8422%_
                                     (cdr _%remaining8424%_)
                                     (cons _%row8427%_
                                           _%accepted8425%_)))))))))))
          (if (and _%share-source?8307%_
                   (= (let* ((_%h8311%_ _%seen8306%_)
                             (_%h8315%_
                              (let ()
                                (declare (not safe))
                                (cast HashTable::interface _%h8311%_)))
                             (_%h8317%_ _%h8315%_))
                        (declare (not safe))
                        (__hash-length _%h8317%_))
                      '0))
              (let ((_%present8329%_
                     (let ()
                       (declare (not safe))
                       (make-hash-table__%
                        '#f
                        _%count8305%_
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value))))
                (let _%scan8331%_ ((_%cursor8333%_ _%source-log8304%_)
                                   (_%left8334%_ _%count8305%_)
                                   (_%next-size8335%_ '1))
                  (if (= _%left8334%_ '0)
                      (if (null? _%cursor8333%_)
                          (values _%source-log8304%_ _%present8329%_)
                          (begin
                            (let* ((_%h8337%_ _%present8329%_)
                                   (_%h8341%_ _%h8337%_)
                                   (_%h8343%_ _%h8341%_))
                              (declare (not safe))
                              (__hash-clear! _%h8343%_))
                            (_%admit8309%_ _%present8329%_)))
                      (begin
                        (let* ((_%h8356%_ _%present8329%_)
                               (_%key8359%_ (car _%cursor8333%_))
                               (_%value8362%_ '#t)
                               (_%h8366%_ _%h8356%_)
                               (_%h8368%_ _%h8366%_))
                          (declare (not safe))
                          (__hash-put! _%h8368%_ _%key8359%_ _%value8362%_))
                        (if (= (let* ((_%h8380%_ _%present8329%_)
                                      (_%h8384%_ _%h8380%_)
                                      (_%h8386%_ _%h8384%_))
                                 (declare (not safe))
                                 (__hash-length _%h8386%_))
                               _%next-size8335%_)
                            (_%scan8331%_
                             (cdr _%cursor8333%_)
                             (let ()
                               (declare (not safe))
                               (##fx- _%left8334%_ '1))
                             (let ()
                               (declare (not safe))
                               (##fx+ _%next-size8335%_ '1)))
                            (begin
                              (let* ((_%h8396%_ _%present8329%_)
                                     (_%h8400%_ _%h8396%_)
                                     (_%h8402%_ _%h8400%_))
                                (declare (not safe))
                                (__hash-clear! _%h8402%_))
                              (_%admit8309%_ _%present8329%_)))))))
              (_%admit8309%_ _%seen8306%_)))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-extend
      (lambda (_%provider8297%_
               _%state8298%_
               _%all8299%_
               _%pending8300%_
               _%row8301%_
               _%budget8302%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%provider8297%_ '.extend-rows))
         _%state8298%_
         _%all8299%_
         _%pending8300%_
         _%row8301%_
         _%budget8302%_)))
    (define gerbil-ascent/table/storage#+canonical-set-storage-provider+
      (let ((__tmp8574
             (let ((__obj8555
                    (let ()
                      (declare (not safe))
                      (##structure
                       clan/poo/object#object::t
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f))))
               (let ((__tmp8576
                      (list (cons '.make-state
                                  (let ((__tmp8577
                                         (lambda (_%@8279%_) (lambda () '#f))))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp8577)))
                            (cons '.extend-rows
                                  (let ((__tmp8578
                                         (lambda (_%@8286%_)
                                           (lambda (_%_state8291%_
                                                    _%_all8292%_
                                                    _%_pending8293%_
                                                    _%row8294%_
                                                    _%_budget8295%_)
                                             (list _%row8294%_)))))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp8578)))))
                     (__tmp8575 (list)))
                 (declare (not safe))
                 (clan/poo/object#object:::init!__%
                  '#f
                  gerbil-ascent/table/storage#StorageProvider.
                  __tmp8576
                  __tmp8575
                  __obj8555))
               __obj8555)))
        (declare (not safe))
        (clan/poo/mop#validate
         gerbil-ascent/table/storage#GerbilAscentStorageProviderContract
         __tmp8574)))
    (define gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider
      gerbil-ascent/table/storage#+canonical-set-storage-provider+)
    (define gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
      (lambda (_%value8266%_)
        (eq? _%value8266%_
             gerbil-ascent/table/storage#+canonical-set-storage-provider+)))
    (define gerbil-ascent/table/storage#gerbil-ascent-eqrel-storage-provider
      (let ((__tmp8579
             (let ((__obj8556
                    (let ()
                      (declare (not safe))
                      (##structure
                       clan/poo/object#object::t
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f))))
               (let ((__tmp8581
                      (list (cons '.make-state
                                  (let ((__tmp8582
                                         (lambda (_%@8255%_)
                                           gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-state)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp8582)))
                            (cons '.extend-rows
                                  (let ((__tmp8583
                                         (lambda (_%@8261%_)
                                           gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-extension)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp8583)))))
                     (__tmp8580 (list)))
                 (declare (not safe))
                 (clan/poo/object#object:::init!__%
                  '#f
                  gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider
                  __tmp8581
                  __tmp8580
                  __obj8556))
               __obj8556)))
        (declare (not safe))
        (clan/poo/mop#validate
         gerbil-ascent/table/storage#GerbilAscentStorageProviderContract
         __tmp8579)))
    (define gerbil-ascent/table/storage#gerbil-ascent-trrel-storage-provider
      (let ((__tmp8584
             (let ((__obj8557
                    (let ()
                      (declare (not safe))
                      (##structure
                       clan/poo/object#object::t
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f))))
               (let ((__tmp8586
                      (list (cons '.make-state
                                  (let ((__tmp8587
                                         (lambda (_%@8233%_)
                                           gerbil-ascent/table/trrel#gerbil-ascent-trrel-state)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp8587)))
                            (cons '.extend-rows
                                  (let ((__tmp8588
                                         (lambda (_%@8239%_)
                                           gerbil-ascent/table/trrel#gerbil-ascent-trrel-extension)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp8588)))))
                     (__tmp8585 (list)))
                 (declare (not safe))
                 (clan/poo/object#object:::init!__%
                  '#f
                  gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider
                  __tmp8586
                  __tmp8585
                  __obj8557))
               __obj8557)))
        (declare (not safe))
        (clan/poo/mop#validate
         gerbil-ascent/table/storage#GerbilAscentStorageProviderContract
         __tmp8584)))
    (define gerbil-ascent/table/storage#gerbil-ascent-trrel-uf-storage-provider
      (let ((__tmp8589
             (let ((__obj8558
                    (let ()
                      (declare (not safe))
                      (##structure
                       clan/poo/object#object::t
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f))))
               (let ((__tmp8591
                      (list (cons '.make-state
                                  (let ((__tmp8592
                                         (lambda (_%@8211%_)
                                           gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-state)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp8592)))
                            (cons '.extend-rows
                                  (let ((__tmp8593
                                         (lambda (_%@8217%_)
                                           gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-extension)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp8593)))))
                     (__tmp8590 (list)))
                 (declare (not safe))
                 (clan/poo/object#object:::init!__%
                  '#f
                  gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider
                  __tmp8591
                  __tmp8590
                  __obj8558))
               __obj8558)))
        (declare (not safe))
        (clan/poo/mop#validate
         gerbil-ascent/table/storage#GerbilAscentStorageProviderContract
         __tmp8589)))
    (define gerbil-ascent/table/storage#+native-storage-providers+
      (list gerbil-ascent/table/storage#+canonical-set-storage-provider+
            gerbil-ascent/table/storage#gerbil-ascent-eqrel-storage-provider
            gerbil-ascent/table/storage#gerbil-ascent-trrel-storage-provider
            gerbil-ascent/table/storage#gerbil-ascent-trrel-uf-storage-provider))
    (define gerbil-ascent/table/storage#storage-state-owner::t
      (let ((__tmp8595 (list)) (__tmp8594 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/storage#storage-state-owner::t
         'storage-state-owner
         __tmp8595
         '(value phase)
         __tmp8594
         '#f)))
    (define gerbil-ascent/table/storage#storage-state-owner?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/table/storage#storage-state-owner::t)))
    (define gerbil-ascent/table/storage#make-storage-state-owner
      (lambda _%$args8197%_
        (apply make-instance
               gerbil-ascent/table/storage#storage-state-owner::t
               _%$args8197%_)))
    (define gerbil-ascent/table/storage#storage-state-owner-value
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/storage#storage-state-owner::t
         'value)))
    (define gerbil-ascent/table/storage#storage-state-owner-phase
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/storage#storage-state-owner::t
         'phase)))
    (define gerbil-ascent/table/storage#storage-state-owner-value-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/storage#storage-state-owner::t
         'value)))
    (define gerbil-ascent/table/storage#storage-state-owner-phase-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/storage#storage-state-owner::t
         'phase)))
    (define gerbil-ascent/table/storage#&storage-state-owner-value
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/storage#storage-state-owner::t
         'value)))
    (define gerbil-ascent/table/storage#&storage-state-owner-phase
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/storage#storage-state-owner::t
         'phase)))
    (define gerbil-ascent/table/storage#&storage-state-owner-value-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/storage#storage-state-owner::t
         'value)))
    (define gerbil-ascent/table/storage#&storage-state-owner-phase-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/storage#storage-state-owner::t
         'phase)))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-engine-state
      (lambda (_%provider8193%_)
        (let ((_%state8195%_
               (gerbil-ascent/table/storage#gerbil-ascent-storage-make-state
                _%provider8193%_)))
          (if (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
               _%provider8193%_)
              _%state8195%_
              (let ()
                (declare (not safe))
                (##structure
                 gerbil-ascent/table/storage#storage-state-owner::t
                 _%state8195%_
                 'ready))))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-owned-states
      (lambda (_%states8191%_)
        (let ((__tmp8596 (vector->list _%states8191%_)))
          (declare (not safe))
          (##filter
           gerbil-ascent/table/storage#storage-state-owner?
           __tmp8596))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-check-state!
      (lambda (_%state8189%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-instance-of?
                    _%state8189%_
                    'gerbil-ascent/table/storage#storage-state-owner::t))
                 (not (eq? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%state8189%_
                              '2
                              '#f
                              '#f))
                           'ready)))
            (let ()
              (declare (not safe))
              (error '"ASCENT storage state requires source replay"))
            '#!void)))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-admit-state!
      (lambda (_%state8187%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%state8187%_
               'gerbil-ascent/table/storage#storage-state-owner::t))
            (let ()
              (declare (not safe))
              (##unchecked-structure-set! _%state8187%_ 'ready '2 '#f '#f))
            '#!void)))
    (define gerbil-ascent/table/storage#owned-storage-rows
      (lambda (_%rows8183%_)
        (map (lambda (_%row8185%_) (map values _%row8185%_)) _%rows8183%_)))
    (define gerbil-ascent/table/storage#call-with-storage-state
      (lambda (_%state8147%_ _%invoke8148%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%state8147%_
               'gerbil-ascent/table/storage#storage-state-owner::t))
            (begin
              (if (eq? (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref _%state8147%_ '2 '#f '#f))
                       'failed)
                  (let ()
                    (declare (not safe))
                    (error '"ASCENT storage state requires source replay"))
                  '#!void)
              (let ()
                (declare (not safe))
                (##unchecked-structure-set!
                 _%state8147%_
                 'pending
                 '2
                 '#f
                 '#f)))
            '#!void)
        (let* ((_%handler8152%_
                (lambda (_%failure8150%_)
                  (if (let ()
                        (declare (not safe))
                        (##structure-instance-of?
                         _%state8147%_
                         'gerbil-ascent/table/storage#storage-state-owner::t))
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-set!
                         _%state8147%_
                         'failed
                         '2
                         '#f
                         '#f))
                      '#!void)
                  (let () (declare (not safe)) (raise _%failure8150%_))))
               (_%thunk8156%_
                (lambda ()
                  (_%invoke8148%_
                   (if (let ()
                         (declare (not safe))
                         (##structure-instance-of?
                          _%state8147%_
                          'gerbil-ascent/table/storage#storage-state-owner::t))
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref _%state8147%_ '1 '#f '#f))
                       _%state8147%_))))
               (_%handler8161%_ _%handler8152%_)
               (_%thunk8173%_ _%thunk8156%_))
          (declare (not safe))
          (__with-catch _%handler8161%_ _%thunk8173%_))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-extension
      (lambda (_%provider8120%_ _%width8121%_)
        (let ((_%extend8123%_
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%provider8120%_ '.extend-rows))))
          (if (let ()
                (declare (not safe))
                (##memq _%provider8120%_
                        gerbil-ascent/table/storage#+native-storage-providers+))
              _%extend8123%_
              (lambda (_%state8125%_
                       _%all8126%_
                       _%pending8127%_
                       _%row8128%_
                       _%budget8129%_)
                (gerbil-ascent/table/storage#call-with-storage-state
                 _%state8125%_
                 (lambda (_%raw-state8131%_)
                   (let* ((_%owned-all8133%_
                           (gerbil-ascent/table/storage#owned-storage-rows
                            _%all8126%_))
                          (_%owned-pending8135%_
                           (if (eq? _%all8126%_ _%pending8127%_)
                               _%owned-all8133%_
                               (gerbil-ascent/table/storage#owned-storage-rows
                                _%pending8127%_)))
                          (_%expanded8137%_
                           (_%extend8123%_
                            _%raw-state8131%_
                            _%owned-all8133%_
                            _%owned-pending8135%_
                            (map values _%row8128%_)
                            _%budget8129%_)))
                     (if (list? _%expanded8137%_)
                         '#!void
                         (let ()
                           (declare (not safe))
                           (error '"ASCENT storage provider returned non-list rows")))
                     (for-each
                      (lambda (_%stored8140%_)
                        (let _%loop8142%_ ((_%remaining8144%_ _%stored8140%_)
                                           (_%left8145%_ _%width8121%_))
                          (if (= _%left8145%_ '0)
                              (if (null? _%remaining8144%_)
                                  '#!void
                                  (let ()
                                    (declare (not safe))
                                    (error '"invalid ASCENT storage provider row")))
                              (if (pair? _%remaining8144%_)
                                  (_%loop8142%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%remaining8144%_))
                                   (- _%left8145%_ '1))
                                  (let ()
                                    (declare (not safe))
                                    (error '"invalid ASCENT storage provider row"))))))
                      _%expanded8137%_)
                     (gerbil-ascent/table/storage#owned-storage-rows
                      _%expanded8137%_)))))))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-engine-extension
      (lambda (_%provider8107%_ _%width8108%_)
        (if (and (let ()
                   (declare (not safe))
                   (##memq _%provider8107%_
                           gerbil-ascent/table/storage#+native-storage-providers+))
                 (not (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                       _%provider8107%_)))
            (let ((_%extend8110%_
                   (let ()
                     (declare (not safe))
                     (clan/poo/object#.ref _%provider8107%_ '.extend-rows))))
              (lambda (_%state8112%_
                       _%all8113%_
                       _%pending8114%_
                       _%row8115%_
                       _%budget8116%_)
                (gerbil-ascent/table/storage#call-with-storage-state
                 _%state8112%_
                 (lambda (_%raw-state8118%_)
                   (_%extend8110%_
                    _%raw-state8118%_
                    _%all8113%_
                    _%pending8114%_
                    _%row8115%_
                    _%budget8116%_)))))
            (gerbil-ascent/table/storage#gerbil-ascent-storage-extension
             _%provider8107%_
             _%width8108%_))))
    (define gerbil-ascent/table/storage#gerbil-ascent-canonical-view-storage-provider?
      (lambda (_%provider8102%_)
        (let ((_%$e8104%_
               (eq? _%provider8102%_
                    gerbil-ascent/table/storage#+canonical-eqrel-storage-provider+)))
          (if _%$e8104%_
              _%$e8104%_
              (gerbil-ascent/table/storage#gerbil-ascent-canonical-uf-storage-provider?
               _%provider8102%_)))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-eqrel-state?
      (lambda (_%state8100%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%state8100%_
               'gerbil-ascent/table/storage#storage-state-owner::t))
            (let ((__tmp8597
                   (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref _%state8100%_ '1 '#f '#f))))
              (declare (not safe))
              (##structure-instance-of?
               __tmp8597
               'gerbil-ascent/table/eqrel#eqrel-state::t))
            '#f)))
    (define gerbil-ascent/table/storage#+canonical-eqrel-storage-provider+
      gerbil-ascent/table/storage#gerbil-ascent-eqrel-storage-provider)
    (define gerbil-ascent/table/storage#+canonical-uf-storage-provider+
      gerbil-ascent/table/storage#gerbil-ascent-trrel-uf-storage-provider)
    (define gerbil-ascent/table/storage#gerbil-ascent-canonical-uf-storage-provider?
      (lambda (_%provider8098%_)
        (eq? _%provider8098%_
             gerbil-ascent/table/storage#+canonical-uf-storage-provider+)))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-view-extension!
      (lambda (_%state8092%_ _%row8093%_ _%budget8094%_)
        (gerbil-ascent/table/storage#call-with-storage-state
         _%state8092%_
         (lambda (_%raw8096%_)
           (if (let ()
                 (declare (not safe))
                 (##structure-instance-of?
                  _%raw8096%_
                  'gerbil-ascent/table/eqrel#eqrel-state::t))
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-insert!
                  _%raw8096%_
                  _%row8093%_
                  _%budget8094%_))
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-insert!
                  _%raw8096%_
                  _%row8093%_
                  _%budget8094%_)))))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__%
      (lambda (_%state8077%_ _%indexed?8078%_)
        (if (eq? (##structure-ref
                  _%state8077%_
                  '2
                  gerbil-ascent/table/storage#storage-state-owner::t
                  '#f)
                 'failed)
            (let ()
              (declare (not safe))
              (error '"ASCENT storage state requires source replay"))
            '#!void)
        (let ((_%raw8080%_
               (##structure-ref
                _%state8077%_
                '1
                gerbil-ascent/table/storage#storage-state-owner::t
                '#f)))
          (if (let ()
                (declare (not safe))
                (##structure-instance-of?
                 _%raw8080%_
                 'gerbil-ascent/table/eqrel#eqrel-state::t))
              (let ()
                (declare (not safe))
                (gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze__%
                 _%raw8080%_
                 _%indexed?8078%_))
              (let ()
                (declare (not safe))
                (gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__%
                 _%raw8080%_
                 _%indexed?8078%_))))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__0
      (lambda (_%state8085%_)
        (let ((_%indexed?8087%_ '#t))
          (gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__%
           _%state8085%_
           _%indexed?8087%_))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view
      (lambda _g8598_
        (let ((_g8599_ (let () (declare (not safe)) (##length _g8598_))))
          (cond ((let () (declare (not safe)) (##fx= _g8599_ 1))
                 (apply gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__0
                        _g8598_))
                ((let () (declare (not safe)) (##fx= _g8599_ 2))
                 (apply gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__%
                        _g8598_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view
                  _g8598_))))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-publish-view!
      (lambda (_%state8071%_ _%frontier8072%_ _%count8073%_ _%indexed?8074%_)
        (if (eq? (##structure-ref
                  _%state8071%_
                  '2
                  gerbil-ascent/table/storage#storage-state-owner::t
                  '#f)
                 'failed)
            (let ()
              (declare (not safe))
              (error '"ASCENT storage state requires source replay"))
            '#!void)
        (if (gerbil-ascent/table/storage#gerbil-ascent-storage-eqrel-state?
             _%state8071%_)
            (let ((__tmp8600
                   (##structure-ref
                    _%state8071%_
                    '1
                    gerbil-ascent/table/storage#storage-state-owner::t
                    '#f)))
              (declare (not safe))
              (gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!__%
               __tmp8600
               _%count8073%_
               _%indexed?8074%_))
            (begin
              (if (= _%count8073%_
                     (let ()
                       (declare (not safe))
                       (gerbil-ascent/core/relation-view#gerbil-ascent-row-count
                        _%frontier8072%_)))
                  '#!void
                  (let ()
                    (declare (not safe))
                    (error '"ASCENT UF frontier count mismatch")))
              (values (gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__%
                       _%state8071%_
                       _%indexed?8074%_)
                      _%frontier8072%_)))))))
