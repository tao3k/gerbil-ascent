(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/aggregators::timestamp 1791687856)
  (begin
    (define gerbil-ascent/program/aggregators#single-column-value
      (lambda (_%$%e1006110063%_)
        (let* ((_%$%$%e100611006510074%_ _%$%e1006110063%_)
               (_%$%E1006810078%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%$%e100611006510074%_
                           '([value])
                           '(tuple)))
                  '#!void)))
          (let ((_%$%K1007010094%_ (lambda (_%value10092%_) _%value10092%_))
                (_%$%K1006910084%_
                 (lambda (_%tuple10082%_)
                   (let ()
                     (declare (not safe))
                     (error '"ASCENT aggregator expects one input column"
                            _%tuple10082%_)))))
            (if (pair? _%$%$%e100611006510074%_)
                (let ((_%$%tl1007210099%_
                       (let ()
                         (declare (not safe))
                         (##cdr _%$%$%e100611006510074%_)))
                      (_%$%hd1007110097%_
                       (let ()
                         (declare (not safe))
                         (##car _%$%$%e100611006510074%_))))
                  (if (null? _%$%tl1007210099%_)
                      (let ((_%value10102%_ _%$%hd1007110097%_))
                        (_%$%K1007010094%_ _%value10102%_))
                      (let ((_%tuple10087%_ _%$%$%e100611006510074%_))
                        (_%$%K1006910084%_ _%tuple10087%_))))
                (let ((_%tuple10087%_ _%$%$%e100611006510074%_))
                  (_%$%K1006910084%_ _%tuple10087%_)))))))
    (define gerbil-ascent/program/aggregators#gerbil-ascent-count
      (lambda (_%tuples10058%_)
        (for-each
         (lambda (_%tuple10060%_)
           (if (null? _%tuple10060%_)
               '#!void
               (let ()
                 (declare (not safe))
                 (error '"ASCENT count expects no input columns"
                        _%tuple10060%_))))
         _%tuples10058%_)
        (list (length _%tuples10058%_))))
    (define gerbil-ascent/program/aggregators#gerbil-ascent-sum
      (lambda (_%tuples10051%_)
        (let ((_%input10053%_ _%tuples10051%_))
          (for-each
           gerbil-ascent/program/aggregators#single-column-value
           _%input10053%_)
          (list (let ((__tmp33526
                       (lambda (_%tuple10055%_ _%sum10056%_)
                         (+ (car _%tuple10055%_) _%sum10056%_))))
                  (declare (not safe))
                  (foldl__0 __tmp33526 '0 _%input10053%_))))))
    (define gerbil-ascent/program/aggregators#gerbil-ascent-min
      (lambda (_%tuples10047%_)
        (let ((_%values10049%_
               (map gerbil-ascent/program/aggregators#single-column-value
                    _%tuples10047%_)))
          (if (null? _%values10049%_)
              '()
              (list (let ()
                      (declare (not safe))
                      (##apply min _%values10049%_)))))))
    (define gerbil-ascent/program/aggregators#gerbil-ascent-max
      (lambda (_%tuples10043%_)
        (let ((_%values10045%_
               (map gerbil-ascent/program/aggregators#single-column-value
                    _%tuples10043%_)))
          (if (null? _%values10045%_)
              '()
              (list (let ()
                      (declare (not safe))
                      (##apply max _%values10045%_)))))))
    (define gerbil-ascent/program/aggregators#gerbil-ascent-mean
      (lambda (_%tuples10032%_)
        (let ((_%input10034%_ _%tuples10032%_))
          (for-each
           gerbil-ascent/program/aggregators#single-column-value
           _%input10034%_)
          (if (null? _%input10034%_)
              '()
              (let* ((_%count10036%_ '0)
                     (_%sum10041%_
                      (let ((__tmp33527
                             (lambda (_%tuple10038%_ _%prior10039%_)
                               (set! _%count10036%_ (+ _%count10036%_ '1))
                               (+ (car _%tuple10038%_) _%prior10039%_))))
                        (declare (not safe))
                        (foldl__0 __tmp33527 '0 _%input10034%_))))
                (list (/ (exact->inexact _%sum10041%_) _%count10036%_)))))))))
