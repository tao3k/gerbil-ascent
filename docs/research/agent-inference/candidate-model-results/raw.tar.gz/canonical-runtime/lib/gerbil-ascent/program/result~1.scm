(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/result[1]#_g34683_|
    (##structure
     gx#syntax-quote::t
     'owned-publication::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34685_|
    (##structure
     gx#syntax-quote::t
     'make-owned-publication
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34687_|
    (##structure
     gx#syntax-quote::t
     'owned-publication?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34689_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34690_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-snapshots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34691_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-sizes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34692_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-position-of
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34694_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34695_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-snapshots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34696_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-sizes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34697_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-position-of-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34699_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34700_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-snapshots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34701_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-sizes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34702_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-position-of
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34704_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34705_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-snapshots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34706_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-sizes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34707_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-position-of-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[:0:]#owned-publication|
    (let ((__obj34403
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34403
         'gerbil-ascent/program/result#owned-publication::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34403 'owned-publication '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34403
         '(result snapshots sizes position-of)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34403
         '(result snapshots sizes position-of)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34403 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34403 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34403 '#t '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34403 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34403 '#f '13 '#f '#f))
      (let ((__tmp34682 |gerbil-ascent/program/result[1]#_g34683_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34403 __tmp34682 '4 '#f '#f))
      (let ((__tmp34684 |gerbil-ascent/program/result[1]#_g34685_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34403 __tmp34684 '14 '#f '#f))
      (let ((__tmp34686 |gerbil-ascent/program/result[1]#_g34687_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34403 __tmp34686 '15 '#f '#f))
      (let ((__tmp34688
             (cons (cons 'result |gerbil-ascent/program/result[1]#_g34689_|)
                   (cons (cons 'snapshots
                               |gerbil-ascent/program/result[1]#_g34690_|)
                         (cons (cons 'sizes
                                     |gerbil-ascent/program/result[1]#_g34691_|)
                               (cons (cons 'position-of
                                           |gerbil-ascent/program/result[1]#_g34692_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34403 __tmp34688 '16 '#f '#f))
      (let ((__tmp34693
             (cons (cons 'result |gerbil-ascent/program/result[1]#_g34694_|)
                   (cons (cons 'snapshots
                               |gerbil-ascent/program/result[1]#_g34695_|)
                         (cons (cons 'sizes
                                     |gerbil-ascent/program/result[1]#_g34696_|)
                               (cons (cons 'position-of
                                           |gerbil-ascent/program/result[1]#_g34697_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34403 __tmp34693 '17 '#f '#f))
      (let ((__tmp34698
             (cons (cons 'result |gerbil-ascent/program/result[1]#_g34699_|)
                   (cons (cons 'snapshots
                               |gerbil-ascent/program/result[1]#_g34700_|)
                         (cons (cons 'sizes
                                     |gerbil-ascent/program/result[1]#_g34701_|)
                               (cons (cons 'position-of
                                           |gerbil-ascent/program/result[1]#_g34702_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34403 __tmp34698 '18 '#f '#f))
      (let ((__tmp34703
             (cons (cons 'result |gerbil-ascent/program/result[1]#_g34704_|)
                   (cons (cons 'snapshots
                               |gerbil-ascent/program/result[1]#_g34705_|)
                         (cons (cons 'sizes
                                     |gerbil-ascent/program/result[1]#_g34706_|)
                               (cons (cons 'position-of
                                           |gerbil-ascent/program/result[1]#_g34707_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34403 __tmp34703 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34403 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34403 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34403 '() '21 '#f '#f))
      __obj34403)))
