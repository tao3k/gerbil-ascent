(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "clan/poo/object")
    (load-module "std/iter")
    (load-module "gerbil-ascent/program/source-log")
    (load-module "gerbil-ascent/program/source-snapshot"))
  (load-module "gerbil-ascent/program/source-state~0"))
