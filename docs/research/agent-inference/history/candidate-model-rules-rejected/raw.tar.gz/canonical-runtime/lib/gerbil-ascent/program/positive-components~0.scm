(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/positive-components::timestamp 1791687883)
  (define gerbil-ascent/program/positive-components#gerbil-ascent-run-positive-components!
    (lambda (_%analysis18019%_
             _%schema18020%_
             _%initial18021%_
             _%workers18022%_
             _%merge18023%_
             _%canceled?18024%_)
      (let* ((_%components18026%_
              (let ()
                (declare (not safe))
                (gerbil-ascent/program/component-plan#gerbil-ascent-positive-components
                 _%analysis18019%_)))
             (_%frontier18028%_ (vector-copy _%initial18021%_))
             (_%sizes18030%_ (vector-map length _%frontier18028%_))
             (_%known18032%_
              (let ((__tmp36377 (vector-length _%initial18021%_)))
                (declare (not safe))
                (##make-vector __tmp36377 '#f)))
             (_%done18034%_
              (let ((__tmp36378 (length _%components18026%_)))
                (declare (not safe))
                (##make-vector __tmp36378 '#f)))
             (_%snapshots18036%_
              (let ((__tmp36379 (length _%components18026%_)))
                (declare (not safe))
                (##make-vector __tmp36379 '#f))))
        (for-each
         (lambda (_%component18039%_)
           (if (null? (##structure-ref
                       _%component18039%_
                       '3
                       gerbil-ascent/program/component-plan#positive-component::t
                       '#f))
               (vector-set!
                _%done18034%_
                (##structure-ref
                 _%component18039%_
                 '1
                 gerbil-ascent/program/component-plan#positive-component::t
                 '#f)
                '#t)
               (for-each
                (lambda (_%index18041%_)
                  (let ((_%table18043%_
                         (let ()
                           (declare (not safe))
                           (make-hash-table__%
                            '#f
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value))))
                    (for-each
                     (lambda (_%row18045%_)
                       (let ()
                         (declare (not safe))
                         (__hash-put! _%table18043%_ _%row18045%_ '#t)))
                     (vector-ref _%frontier18028%_ _%index18041%_))
                    (vector-set!
                     _%known18032%_
                     _%index18041%_
                     _%table18043%_)))
                (##structure-ref
                 _%component18039%_
                 '2
                 gerbil-ascent/program/component-plan#positive-component::t
                 '#f))))
         _%components18026%_)
        (let ((__tmp36389
               (vector _%analysis18019%_ _%initial18021%_ 'components))
              (__tmp36388
               (filter (lambda (_%component18047%_)
                         (pair? (##structure-ref
                                 _%component18047%_
                                 '3
                                 gerbil-ascent/program/component-plan#positive-component::t
                                 '#f)))
                       _%components18026%_))
              (__tmp36387
               (lambda (_%component18049%_ _%emit!18050%_ _%checkpoint!18051%_)
                 (let* ((_%id18053%_
                         (##structure-ref
                          _%component18049%_
                          '1
                          gerbil-ascent/program/component-plan#positive-component::t
                          '#f))
                        (_%snapshot18055%_
                         (vector-ref _%snapshots18036%_ _%id18053%_)))
                   (declare (not safe))
                   (gerbil-ascent/program/component-worker#gerbil-ascent-run-positive-component!
                    _%component18049%_
                    _%schema18020%_
                    _%snapshot18055%_
                    _%emit!18050%_
                    _%checkpoint!18051%_))))
              (__tmp36386
               (lambda (_%atom18058%_ _%row18059%_)
                 (let* ((_%index18061%_ (vector-ref _%atom18058%_ '0))
                        (_%table18063%_
                         (vector-ref _%known18032%_ _%index18061%_)))
                   (if (let ()
                         (declare (not safe))
                         (hash-get _%table18063%_ _%row18059%_))
                       '#!void
                       (begin
                         (_%merge18023%_ _%atom18058%_ _%row18059%_)
                         (let ()
                           (declare (not safe))
                           (hash-put! _%table18063%_ _%row18059%_ '#t))
                         (vector-set!
                          _%frontier18028%_
                          _%index18061%_
                          (cons _%row18059%_
                                (vector-ref _%frontier18028%_ _%index18061%_)))
                         (vector-set!
                          _%sizes18030%_
                          _%index18061%_
                          (+ '1
                             (vector-ref _%sizes18030%_ _%index18061%_))))))))
              (__tmp36381
               (lambda (_%component18066%_)
                 (if (let ((__tmp36383
                            (lambda (_%id18068%_)
                              (vector-ref _%done18034%_ _%id18068%_)))
                           (__tmp36382
                            (##structure-ref
                             _%component18066%_
                             '4
                             gerbil-ascent/program/component-plan#positive-component::t
                             '#f)))
                       (declare (not safe))
                       (andmap__0 __tmp36383 __tmp36382))
                     (begin
                       (vector-set!
                        _%snapshots18036%_
                        (##structure-ref
                         _%component18066%_
                         '1
                         gerbil-ascent/program/component-plan#positive-component::t
                         '#f)
                        (let ((__tmp36385
                               (let ()
                                 (declare (not safe))
                                 (##vector-copy _%frontier18028%_)))
                              (__tmp36384
                               (let ()
                                 (declare (not safe))
                                 (##vector-copy _%sizes18030%_))))
                          (declare (not safe))
                          (##structure
                           gerbil-ascent/program/component-worker#component-snapshot::t
                           __tmp36385
                           __tmp36384)))
                       '#t)
                     '#f)))
              (__tmp36380
               (lambda (_%component18070%_)
                 (let ((_%id18072%_
                        (##structure-ref
                         _%component18070%_
                         '1
                         gerbil-ascent/program/component-plan#positive-component::t
                         '#f)))
                   (vector-set! _%snapshots18036%_ _%id18072%_ '#f)
                   (vector-set! _%done18034%_ _%id18072%_ '#t)))))
          (declare (not safe))
          (gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__%
           __tmp36389
           __tmp36388
           _%workers18022%_
           __tmp36387
           __tmp36386
           _%canceled?18024%_
           __tmp36381
           __tmp36380))))))
