(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(define |gerbil-ascent/program/scheme-checked[:0:]#checked-call|
  (lambda (_%$stx11268%_)
    (let* ((_%$%g1127211299%_
            (lambda (_%$%g1127311295%_)
              (let ()
                (declare (not safe))
                (gx#raise-syntax-error
                 '#f
                 '"Bad syntax; invalid match target"
                 _%$%g1127311295%_))))
           (_%$%g1127111395%_
            (lambda (_%$%g1127311303%_)
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%$%g1127311303%_))
                  (let ((_%$%e1127611306%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%$%g1127311303%_))))
                    (let ((_%$%hd1127711310%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1127611306%_)))
                          (_%$%tl1127811313%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1127611306%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl1127811313%_))
                          (let ((_%$%e1127911316%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl1127811313%_))))
                            (let ((_%$%hd1128011320%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e1127911316%_)))
                                  (_%$%tl1128111323%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e1127911316%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair/null? _%$%hd1128011320%_))
                                  (let ((_g36374_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-split-splice
                                            _%$%hd1128011320%_
                                            '0))))
                                    (begin
                                      (let ((_g36375_
                                             (let ()
                                               (declare (not safe))
                                               (if (##values? _g36374_)
                                                   (##values-length _g36374_)
                                                   1))))
                                        (if (not (let ()
                                                   (declare (not safe))
                                                   (##fx= _g36375_ 2)))
                                            (error "Context expects 2 values"
                                                   _g36375_)))
                                      (let ((_%$%target1128211326%_
                                             (let ()
                                               (declare (not safe))
                                               (##values-ref _g36374_ 0)))
                                            (_%$%tl1128411329%_
                                             (let ()
                                               (declare (not safe))
                                               (##values-ref _g36374_ 1))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-null?
                                               _%$%tl1128411329%_))
                                            (letrec ((_%$%loop1128511332%_
                                                      (lambda (_%$%hd1128311336%_
                                                               _%$%parameter1128911339%_)
                                                        (if (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#stx-pair?
                                                               _%$%hd1128311336%_))
                                                            (let ((_%$%e1128611341%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%$%hd1128311336%_))))
                      (let ((_%$%lp-hd1128711345%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e1128611341%_)))
                            (_%$%lp-tl1128811348%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e1128611341%_))))
                        (_%$%loop1128511332%_
                         _%$%lp-tl1128811348%_
                         (cons _%$%lp-hd1128711345%_
                               _%$%parameter1128911339%_))))
                    (let ((_%$%parameter1129011351%_
                           (reverse _%$%parameter1128911339%_)))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl1128111323%_))
                          (let ((_%$%e1129111354%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl1128111323%_))))
                            (let ((_%$%hd1129211358%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e1129111354%_)))
                                  (_%$%tl1129311361%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e1129111354%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1129311361%_))
                                  (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'lambda))
                                        (cons (let ()
                                                (declare (not safe))
                                                (gx#datum->syntax__0
                                                 '#f
                                                 'values))
                                              (cons (cons (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#datum->syntax__0
                                                             '#f
                                                             'match))
                                                          (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'values))
                        (cons (cons (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0 '#f '@list))
                                          (let ((__tmp36376
                                                 (lambda (_%$%g1138611389%_
                                                          _%$%g1138711392%_)
                                                   (cons _%$%g1138611389%_
                                                         _%$%g1138711392%_))))
                                            (declare (not safe))
                                            (foldr__0
                                             __tmp36376
                                             '()
                                             _%$%parameter1129011351%_)))
                                    (cons _%$%hd1129211358%_ '()))
                              (cons (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0 '#f '_))
                                          (cons (cons (let ()
                                                        (declare (not safe))
                                                        (gx#datum->syntax__0
                                                         '#f
                                                         'error))
                                                      (cons '"relational operator argument mismatch"
                                                            '()))
                                                '()))
                                    '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '())))
                                  (_%$%g1127211299%_ _%$%g1127311303%_))))
                          (_%$%g1127211299%_ _%$%g1127311303%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%$%loop1128511332%_
                                               _%$%target1128211326%_
                                               '()))
                                            (_%$%g1127211299%_
                                             _%$%g1127311303%_)))))
                                  (_%$%g1127211299%_ _%$%g1127311303%_))))
                          (_%$%g1127211299%_ _%$%g1127311303%_))))
                  (_%$%g1127211299%_ _%$%g1127311303%_)))))
      (_%$%g1127111395%_ _%$stx11268%_))))
