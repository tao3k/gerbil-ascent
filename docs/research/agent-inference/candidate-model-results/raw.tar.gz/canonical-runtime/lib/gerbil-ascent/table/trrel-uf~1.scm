(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/trrel-uf[1]#_g34204_|
    (##structure
     gx#syntax-quote::t
     'uf-node::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34206_|
    (##structure
     gx#syntax-quote::t
     'make-uf-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34208_|
    (##structure
     gx#syntax-quote::t
     'uf-node?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34210_|
    (##structure
     gx#syntax-quote::t
     'uf-node-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34211_|
    (##structure
     gx#syntax-quote::t
     'uf-node-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34212_|
    (##structure
     gx#syntax-quote::t
     'uf-node-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34213_|
    (##structure
     gx#syntax-quote::t
     'uf-node-reach
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34214_|
    (##structure
     gx#syntax-quote::t
     'uf-node-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34215_|
    (##structure
     gx#syntax-quote::t
     'uf-node-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34217_|
    (##structure
     gx#syntax-quote::t
     'uf-node-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34218_|
    (##structure
     gx#syntax-quote::t
     'uf-node-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34219_|
    (##structure
     gx#syntax-quote::t
     'uf-node-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34220_|
    (##structure
     gx#syntax-quote::t
     'uf-node-reach-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34221_|
    (##structure
     gx#syntax-quote::t
     'uf-node-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34222_|
    (##structure
     gx#syntax-quote::t
     'uf-node-order-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34224_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34225_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34226_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34227_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-reach
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34228_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34229_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34231_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34232_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34233_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34234_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-reach-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34235_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34236_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-order-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34238_|
    (##structure
     gx#syntax-quote::t
     'uf-group::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34240_|
    (##structure
     gx#syntax-quote::t
     'make-uf-group
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34242_|
    (##structure
     gx#syntax-quote::t
     'uf-group?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34244_|
    (##structure
     gx#syntax-quote::t
     'uf-group-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34245_|
    (##structure
     gx#syntax-quote::t
     'uf-group-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34246_|
    (##structure
     gx#syntax-quote::t
     'uf-group-next-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34247_|
    (##structure
     gx#syntax-quote::t
     'uf-group-indexed?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34249_|
    (##structure
     gx#syntax-quote::t
     'uf-group-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34250_|
    (##structure
     gx#syntax-quote::t
     'uf-group-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34251_|
    (##structure
     gx#syntax-quote::t
     'uf-group-next-order-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34252_|
    (##structure
     gx#syntax-quote::t
     'uf-group-indexed?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34254_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34255_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34256_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-next-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34257_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-indexed?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34259_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34260_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34261_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-next-order-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34262_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-indexed?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34264_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34266_|
    (##structure
     gx#syntax-quote::t
     'make-uf-insertion
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34268_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34270_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-group-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34271_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-group
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34272_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34273_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-left-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34274_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-right-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34275_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-a
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34276_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-b
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34278_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-group-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34279_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-group-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34280_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34281_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-left-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34282_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-right-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34283_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-a-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34284_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-b-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34286_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-group-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34287_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-group
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34288_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34289_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-left-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34290_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-right-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34291_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-a
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34292_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-b
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34294_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-group-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34295_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-group-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34296_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34297_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-left-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34298_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-right-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34299_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-a-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34300_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-b-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34302_|
    (##structure
     gx#syntax-quote::t
     'frozen-members::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34304_|
    (##structure
     gx#syntax-quote::t
     'make-frozen-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34306_|
    (##structure
     gx#syntax-quote::t
     'frozen-members?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34308_|
    (##structure
     gx#syntax-quote::t
     'frozen-members-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34309_|
    (##structure
     gx#syntax-quote::t
     'frozen-members-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34311_|
    (##structure
     gx#syntax-quote::t
     'frozen-members-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34312_|
    (##structure
     gx#syntax-quote::t
     'frozen-members-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34314_|
    (##structure
     gx#syntax-quote::t
     '&frozen-members-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34315_|
    (##structure
     gx#syntax-quote::t
     '&frozen-members-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34317_|
    (##structure
     gx#syntax-quote::t
     '&frozen-members-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34318_|
    (##structure
     gx#syntax-quote::t
     '&frozen-members-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/table/trrel-uf[:0:]#uf-node|
      (let ((__obj34042
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34042
           'gerbil-ascent/table/trrel-uf#uf-node::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34042 'uf-node '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34042
           '(parent members size reach predecessors order)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34042
           '(parent members size reach predecessors order)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34042 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34042 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34042 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34042 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34042 '#f '13 '#f '#f))
        (let ((__tmp34203 |gerbil-ascent/table/trrel-uf[1]#_g34204_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34042 __tmp34203 '4 '#f '#f))
        (let ((__tmp34205 |gerbil-ascent/table/trrel-uf[1]#_g34206_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34042 __tmp34205 '14 '#f '#f))
        (let ((__tmp34207 |gerbil-ascent/table/trrel-uf[1]#_g34208_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34042 __tmp34207 '15 '#f '#f))
        (let ((__tmp34209
               (cons (cons 'parent |gerbil-ascent/table/trrel-uf[1]#_g34210_|)
                     (cons (cons 'members
                                 |gerbil-ascent/table/trrel-uf[1]#_g34211_|)
                           (cons (cons 'size
                                       |gerbil-ascent/table/trrel-uf[1]#_g34212_|)
                                 (cons (cons 'reach
                                             |gerbil-ascent/table/trrel-uf[1]#_g34213_|)
                                       (cons (cons 'predecessors
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34214_|)
                                             (cons (cons 'order
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34215_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34042 __tmp34209 '16 '#f '#f))
        (let ((__tmp34216
               (cons (cons 'parent |gerbil-ascent/table/trrel-uf[1]#_g34217_|)
                     (cons (cons 'members
                                 |gerbil-ascent/table/trrel-uf[1]#_g34218_|)
                           (cons (cons 'size
                                       |gerbil-ascent/table/trrel-uf[1]#_g34219_|)
                                 (cons (cons 'reach
                                             |gerbil-ascent/table/trrel-uf[1]#_g34220_|)
                                       (cons (cons 'predecessors
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34221_|)
                                             (cons (cons 'order
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34222_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34042 __tmp34216 '17 '#f '#f))
        (let ((__tmp34223
               (cons (cons 'parent |gerbil-ascent/table/trrel-uf[1]#_g34224_|)
                     (cons (cons 'members
                                 |gerbil-ascent/table/trrel-uf[1]#_g34225_|)
                           (cons (cons 'size
                                       |gerbil-ascent/table/trrel-uf[1]#_g34226_|)
                                 (cons (cons 'reach
                                             |gerbil-ascent/table/trrel-uf[1]#_g34227_|)
                                       (cons (cons 'predecessors
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34228_|)
                                             (cons (cons 'order
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34229_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34042 __tmp34223 '18 '#f '#f))
        (let ((__tmp34230
               (cons (cons 'parent |gerbil-ascent/table/trrel-uf[1]#_g34231_|)
                     (cons (cons 'members
                                 |gerbil-ascent/table/trrel-uf[1]#_g34232_|)
                           (cons (cons 'size
                                       |gerbil-ascent/table/trrel-uf[1]#_g34233_|)
                                 (cons (cons 'reach
                                             |gerbil-ascent/table/trrel-uf[1]#_g34234_|)
                                       (cons (cons 'predecessors
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34235_|)
                                             (cons (cons 'order
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34236_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34042 __tmp34230 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34042 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34042 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34042 '() '21 '#f '#f))
        __obj34042))
    (define |gerbil-ascent/table/trrel-uf[:0:]#uf-group|
      (let ((__obj34043
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34043
           'gerbil-ascent/table/trrel-uf#uf-group::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34043 'uf-group '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34043
           '(nodes roots next-order indexed?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34043
           '(nodes roots next-order indexed?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34043 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34043 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34043 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34043 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34043 '#f '13 '#f '#f))
        (let ((__tmp34237 |gerbil-ascent/table/trrel-uf[1]#_g34238_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34043 __tmp34237 '4 '#f '#f))
        (let ((__tmp34239 |gerbil-ascent/table/trrel-uf[1]#_g34240_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34043 __tmp34239 '14 '#f '#f))
        (let ((__tmp34241 |gerbil-ascent/table/trrel-uf[1]#_g34242_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34043 __tmp34241 '15 '#f '#f))
        (let ((__tmp34243
               (cons (cons 'nodes |gerbil-ascent/table/trrel-uf[1]#_g34244_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/table/trrel-uf[1]#_g34245_|)
                           (cons (cons 'next-order
                                       |gerbil-ascent/table/trrel-uf[1]#_g34246_|)
                                 (cons (cons 'indexed?
                                             |gerbil-ascent/table/trrel-uf[1]#_g34247_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34043 __tmp34243 '16 '#f '#f))
        (let ((__tmp34248
               (cons (cons 'nodes |gerbil-ascent/table/trrel-uf[1]#_g34249_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/table/trrel-uf[1]#_g34250_|)
                           (cons (cons 'next-order
                                       |gerbil-ascent/table/trrel-uf[1]#_g34251_|)
                                 (cons (cons 'indexed?
                                             |gerbil-ascent/table/trrel-uf[1]#_g34252_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34043 __tmp34248 '17 '#f '#f))
        (let ((__tmp34253
               (cons (cons 'nodes |gerbil-ascent/table/trrel-uf[1]#_g34254_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/table/trrel-uf[1]#_g34255_|)
                           (cons (cons 'next-order
                                       |gerbil-ascent/table/trrel-uf[1]#_g34256_|)
                                 (cons (cons 'indexed?
                                             |gerbil-ascent/table/trrel-uf[1]#_g34257_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34043 __tmp34253 '18 '#f '#f))
        (let ((__tmp34258
               (cons (cons 'nodes |gerbil-ascent/table/trrel-uf[1]#_g34259_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/table/trrel-uf[1]#_g34260_|)
                           (cons (cons 'next-order
                                       |gerbil-ascent/table/trrel-uf[1]#_g34261_|)
                                 (cons (cons 'indexed?
                                             |gerbil-ascent/table/trrel-uf[1]#_g34262_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34043 __tmp34258 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34043 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34043 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34043 '() '21 '#f '#f))
        __obj34043))
    (define |gerbil-ascent/table/trrel-uf[:0:]#uf-insertion|
      (let ((__obj34044
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34044
           'gerbil-ascent/table/trrel-uf#uf-insertion::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34044 'uf-insertion '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34044
           '(group-key group row left-node right-node a b)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34044
           '(group-key group row left-node right-node a b)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34044 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34044 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34044 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34044 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34044 '#f '13 '#f '#f))
        (let ((__tmp34263 |gerbil-ascent/table/trrel-uf[1]#_g34264_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34044 __tmp34263 '4 '#f '#f))
        (let ((__tmp34265 |gerbil-ascent/table/trrel-uf[1]#_g34266_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34044 __tmp34265 '14 '#f '#f))
        (let ((__tmp34267 |gerbil-ascent/table/trrel-uf[1]#_g34268_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34044 __tmp34267 '15 '#f '#f))
        (let ((__tmp34269
               (cons (cons 'group-key
                           |gerbil-ascent/table/trrel-uf[1]#_g34270_|)
                     (cons (cons 'group
                                 |gerbil-ascent/table/trrel-uf[1]#_g34271_|)
                           (cons (cons 'row
                                       |gerbil-ascent/table/trrel-uf[1]#_g34272_|)
                                 (cons (cons 'left-node
                                             |gerbil-ascent/table/trrel-uf[1]#_g34273_|)
                                       (cons (cons 'right-node
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34274_|)
                                             (cons (cons 'a
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34275_|)
                                                   (cons (cons 'b
                                                               |gerbil-ascent/table/trrel-uf[1]#_g34276_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34044 __tmp34269 '16 '#f '#f))
        (let ((__tmp34277
               (cons (cons 'group-key
                           |gerbil-ascent/table/trrel-uf[1]#_g34278_|)
                     (cons (cons 'group
                                 |gerbil-ascent/table/trrel-uf[1]#_g34279_|)
                           (cons (cons 'row
                                       |gerbil-ascent/table/trrel-uf[1]#_g34280_|)
                                 (cons (cons 'left-node
                                             |gerbil-ascent/table/trrel-uf[1]#_g34281_|)
                                       (cons (cons 'right-node
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34282_|)
                                             (cons (cons 'a
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34283_|)
                                                   (cons (cons 'b
                                                               |gerbil-ascent/table/trrel-uf[1]#_g34284_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34044 __tmp34277 '17 '#f '#f))
        (let ((__tmp34285
               (cons (cons 'group-key
                           |gerbil-ascent/table/trrel-uf[1]#_g34286_|)
                     (cons (cons 'group
                                 |gerbil-ascent/table/trrel-uf[1]#_g34287_|)
                           (cons (cons 'row
                                       |gerbil-ascent/table/trrel-uf[1]#_g34288_|)
                                 (cons (cons 'left-node
                                             |gerbil-ascent/table/trrel-uf[1]#_g34289_|)
                                       (cons (cons 'right-node
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34290_|)
                                             (cons (cons 'a
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34291_|)
                                                   (cons (cons 'b
                                                               |gerbil-ascent/table/trrel-uf[1]#_g34292_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34044 __tmp34285 '18 '#f '#f))
        (let ((__tmp34293
               (cons (cons 'group-key
                           |gerbil-ascent/table/trrel-uf[1]#_g34294_|)
                     (cons (cons 'group
                                 |gerbil-ascent/table/trrel-uf[1]#_g34295_|)
                           (cons (cons 'row
                                       |gerbil-ascent/table/trrel-uf[1]#_g34296_|)
                                 (cons (cons 'left-node
                                             |gerbil-ascent/table/trrel-uf[1]#_g34297_|)
                                       (cons (cons 'right-node
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34298_|)
                                             (cons (cons 'a
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34299_|)
                                                   (cons (cons 'b
                                                               |gerbil-ascent/table/trrel-uf[1]#_g34300_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34044 __tmp34293 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34044 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34044 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34044 '() '21 '#f '#f))
        __obj34044))
    (define |gerbil-ascent/table/trrel-uf[:0:]#frozen-members|
      (let ((__obj34045
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34045
           'gerbil-ascent/table/trrel-uf#frozen-members::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34045 'frozen-members '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34045 '(rows count) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34045 '(rows count) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34045 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34045 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34045 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34045 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34045 '#f '13 '#f '#f))
        (let ((__tmp34301 |gerbil-ascent/table/trrel-uf[1]#_g34302_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34045 __tmp34301 '4 '#f '#f))
        (let ((__tmp34303 |gerbil-ascent/table/trrel-uf[1]#_g34304_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34045 __tmp34303 '14 '#f '#f))
        (let ((__tmp34305 |gerbil-ascent/table/trrel-uf[1]#_g34306_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34045 __tmp34305 '15 '#f '#f))
        (let ((__tmp34307
               (cons (cons 'rows |gerbil-ascent/table/trrel-uf[1]#_g34308_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/trrel-uf[1]#_g34309_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34045 __tmp34307 '16 '#f '#f))
        (let ((__tmp34310
               (cons (cons 'rows |gerbil-ascent/table/trrel-uf[1]#_g34311_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/trrel-uf[1]#_g34312_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34045 __tmp34310 '17 '#f '#f))
        (let ((__tmp34313
               (cons (cons 'rows |gerbil-ascent/table/trrel-uf[1]#_g34314_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/trrel-uf[1]#_g34315_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34045 __tmp34313 '18 '#f '#f))
        (let ((__tmp34316
               (cons (cons 'rows |gerbil-ascent/table/trrel-uf[1]#_g34317_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/trrel-uf[1]#_g34318_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34045 __tmp34316 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34045 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34045 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34045 '() '21 '#f '#f))
        __obj34045))))
