(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37066_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37068_|
    (##structure
     gx#syntax-quote::t
     'make-grounding-rule
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37070_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37072_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-name
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37073_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-head
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37074_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-body
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37075_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-label
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37077_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-name-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37078_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-head-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37079_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-body-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37080_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-label-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37082_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-name
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37083_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-head
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37084_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-body
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37085_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-label
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37087_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-name-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37088_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-head-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37089_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-body-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37090_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-label-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37092_|
    (##structure
     gx#syntax-quote::t
     'grounding-clause::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37094_|
    (##structure
     gx#syntax-quote::t
     'make-grounding-clause
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37096_|
    (##structure
     gx#syntax-quote::t
     'grounding-clause?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37098_|
    (##structure
     gx#syntax-quote::t
     'grounding-clause-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37099_|
    (##structure
     gx#syntax-quote::t
     'grounding-clause-apply
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37101_|
    (##structure
     gx#syntax-quote::t
     'grounding-clause-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37102_|
    (##structure
     gx#syntax-quote::t
     'grounding-clause-apply-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37104_|
    (##structure
     gx#syntax-quote::t
     '&grounding-clause-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37105_|
    (##structure
     gx#syntax-quote::t
     '&grounding-clause-apply
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37107_|
    (##structure
     gx#syntax-quote::t
     '&grounding-clause-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37108_|
    (##structure
     gx#syntax-quote::t
     '&grounding-clause-apply-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/grounding-plan[:0:]#grounding-rule|
      (let ((__obj37028
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37028
           'gerbil-ascent/candidate/grounding-plan#grounding-rule::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37028 'grounding-rule '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37028
           '(name head body label)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37028
           '(name head body label)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37028 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37028 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37028 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37028 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37028 '#f '13 '#f '#f))
        (let ((__tmp37065
               |gerbil-ascent/candidate/grounding-plan[1]#_g37066_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37028 __tmp37065 '4 '#f '#f))
        (let ((__tmp37067
               |gerbil-ascent/candidate/grounding-plan[1]#_g37068_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37028 __tmp37067 '14 '#f '#f))
        (let ((__tmp37069
               |gerbil-ascent/candidate/grounding-plan[1]#_g37070_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37028 __tmp37069 '15 '#f '#f))
        (let ((__tmp37071
               (cons (cons 'name
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37072_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37073_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/grounding-plan[1]#_g37074_|)
                                 (cons (cons 'label
                                             |gerbil-ascent/candidate/grounding-plan[1]#_g37075_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37028 __tmp37071 '16 '#f '#f))
        (let ((__tmp37076
               (cons (cons 'name
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37077_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37078_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/grounding-plan[1]#_g37079_|)
                                 (cons (cons 'label
                                             |gerbil-ascent/candidate/grounding-plan[1]#_g37080_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37028 __tmp37076 '17 '#f '#f))
        (let ((__tmp37081
               (cons (cons 'name
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37082_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37083_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/grounding-plan[1]#_g37084_|)
                                 (cons (cons 'label
                                             |gerbil-ascent/candidate/grounding-plan[1]#_g37085_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37028 __tmp37081 '18 '#f '#f))
        (let ((__tmp37086
               (cons (cons 'name
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37087_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37088_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/grounding-plan[1]#_g37089_|)
                                 (cons (cons 'label
                                             |gerbil-ascent/candidate/grounding-plan[1]#_g37090_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37028 __tmp37086 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37028 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37028 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37028 '() '21 '#f '#f))
        __obj37028))
    (define |gerbil-ascent/candidate/grounding-plan[:0:]#grounding-clause|
      (let ((__obj37029
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37029
           'gerbil-ascent/candidate/grounding-plan#grounding-clause::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37029 'grounding-clause '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37029 '(relation apply) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37029 '(relation apply) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37029 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37029 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37029 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37029 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37029 '#f '13 '#f '#f))
        (let ((__tmp37091
               |gerbil-ascent/candidate/grounding-plan[1]#_g37092_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37029 __tmp37091 '4 '#f '#f))
        (let ((__tmp37093
               |gerbil-ascent/candidate/grounding-plan[1]#_g37094_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37029 __tmp37093 '14 '#f '#f))
        (let ((__tmp37095
               |gerbil-ascent/candidate/grounding-plan[1]#_g37096_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37029 __tmp37095 '15 '#f '#f))
        (let ((__tmp37097
               (cons (cons 'relation
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37098_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37099_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37029 __tmp37097 '16 '#f '#f))
        (let ((__tmp37100
               (cons (cons 'relation
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37101_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37102_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37029 __tmp37100 '17 '#f '#f))
        (let ((__tmp37103
               (cons (cons 'relation
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37104_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37105_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37029 __tmp37103 '18 '#f '#f))
        (let ((__tmp37106
               (cons (cons 'relation
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37107_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37108_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37029 __tmp37106 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37029 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37029 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37029 '() '21 '#f '#f))
        __obj37029))))
