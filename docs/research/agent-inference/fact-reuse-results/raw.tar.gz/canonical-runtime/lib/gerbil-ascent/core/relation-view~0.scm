(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/core/relation-view::timestamp 1791690977)
  (begin
    (define gerbil-ascent/core/relation-view#relation-view::t
      (let ((__tmp33557 (list)) (__tmp33556 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/core/relation-view#relation-view::t
         'relation-view
         __tmp33557
         '(identity
           generation
           revision
           lane
           count
           units
           visit
           contains
           export
           parts)
         __tmp33556
         '#f)))
    (define gerbil-ascent/core/relation-view#relation-view?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/core/relation-view#relation-view::t)))
    (define gerbil-ascent/core/relation-view#make-relation-view
      (lambda _%$args927%_
        (apply make-instance
               gerbil-ascent/core/relation-view#relation-view::t
               _%$args927%_)))
    (define gerbil-ascent/core/relation-view#relation-view-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'identity)))
    (define gerbil-ascent/core/relation-view#relation-view-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'generation)))
    (define gerbil-ascent/core/relation-view#relation-view-revision
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'revision)))
    (define gerbil-ascent/core/relation-view#relation-view-lane
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'lane)))
    (define gerbil-ascent/core/relation-view#relation-view-count
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'count)))
    (define gerbil-ascent/core/relation-view#relation-view-units
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'units)))
    (define gerbil-ascent/core/relation-view#relation-view-visit
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'visit)))
    (define gerbil-ascent/core/relation-view#relation-view-contains
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'contains)))
    (define gerbil-ascent/core/relation-view#relation-view-export
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'export)))
    (define gerbil-ascent/core/relation-view#relation-view-parts
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'parts)))
    (define gerbil-ascent/core/relation-view#relation-view-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'identity)))
    (define gerbil-ascent/core/relation-view#relation-view-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'generation)))
    (define gerbil-ascent/core/relation-view#relation-view-revision-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'revision)))
    (define gerbil-ascent/core/relation-view#relation-view-lane-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'lane)))
    (define gerbil-ascent/core/relation-view#relation-view-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'count)))
    (define gerbil-ascent/core/relation-view#relation-view-units-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'units)))
    (define gerbil-ascent/core/relation-view#relation-view-visit-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'visit)))
    (define gerbil-ascent/core/relation-view#relation-view-contains-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'contains)))
    (define gerbil-ascent/core/relation-view#relation-view-export-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'export)))
    (define gerbil-ascent/core/relation-view#relation-view-parts-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'parts)))
    (define gerbil-ascent/core/relation-view#&relation-view-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'identity)))
    (define gerbil-ascent/core/relation-view#&relation-view-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'generation)))
    (define gerbil-ascent/core/relation-view#&relation-view-revision
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'revision)))
    (define gerbil-ascent/core/relation-view#&relation-view-lane
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'lane)))
    (define gerbil-ascent/core/relation-view#&relation-view-count
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'count)))
    (define gerbil-ascent/core/relation-view#&relation-view-units
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'units)))
    (define gerbil-ascent/core/relation-view#&relation-view-visit
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'visit)))
    (define gerbil-ascent/core/relation-view#&relation-view-contains
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'contains)))
    (define gerbil-ascent/core/relation-view#&relation-view-export
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'export)))
    (define gerbil-ascent/core/relation-view#&relation-view-parts
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'parts)))
    (define gerbil-ascent/core/relation-view#&relation-view-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'identity)))
    (define gerbil-ascent/core/relation-view#&relation-view-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'generation)))
    (define gerbil-ascent/core/relation-view#&relation-view-revision-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'revision)))
    (define gerbil-ascent/core/relation-view#&relation-view-lane-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'lane)))
    (define gerbil-ascent/core/relation-view#&relation-view-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'count)))
    (define gerbil-ascent/core/relation-view#&relation-view-units-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'units)))
    (define gerbil-ascent/core/relation-view#&relation-view-visit-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'visit)))
    (define gerbil-ascent/core/relation-view#&relation-view-contains-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'contains)))
    (define gerbil-ascent/core/relation-view#&relation-view-export-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'export)))
    (define gerbil-ascent/core/relation-view#&relation-view-parts-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'parts)))
    (define gerbil-ascent/core/relation-view#part-visitors::t
      (let ((__tmp33559 (list)) (__tmp33558 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/core/relation-view#part-visitors::t
         'part-visitors
         __tmp33559
         '(checked admitted)
         __tmp33558
         '#f)))
    (define gerbil-ascent/core/relation-view#part-visitors?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/core/relation-view#part-visitors::t)))
    (define gerbil-ascent/core/relation-view#make-part-visitors
      (lambda _%$args924%_
        (apply make-instance
               gerbil-ascent/core/relation-view#part-visitors::t
               _%$args924%_)))
    (define gerbil-ascent/core/relation-view#part-visitors-checked
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#part-visitors::t
         'checked)))
    (define gerbil-ascent/core/relation-view#part-visitors-admitted
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#part-visitors::t
         'admitted)))
    (define gerbil-ascent/core/relation-view#part-visitors-checked-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#part-visitors::t
         'checked)))
    (define gerbil-ascent/core/relation-view#part-visitors-admitted-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#part-visitors::t
         'admitted)))
    (define gerbil-ascent/core/relation-view#&part-visitors-checked
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#part-visitors::t
         'checked)))
    (define gerbil-ascent/core/relation-view#&part-visitors-admitted
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#part-visitors::t
         'admitted)))
    (define gerbil-ascent/core/relation-view#&part-visitors-checked-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#part-visitors::t
         'checked)))
    (define gerbil-ascent/core/relation-view#&part-visitors-admitted-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#part-visitors::t
         'admitted)))
    (define gerbil-ascent/core/relation-view#row-stream::t
      (let ((__tmp33561 (list)) (__tmp33560 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/core/relation-view#row-stream::t
         'row-stream
         __tmp33561
         '(view columns key)
         __tmp33560
         '#f)))
    (define gerbil-ascent/core/relation-view#row-stream?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/core/relation-view#row-stream::t)))
    (define gerbil-ascent/core/relation-view#make-row-stream
      (lambda _%$args921%_
        (apply make-instance
               gerbil-ascent/core/relation-view#row-stream::t
               _%$args921%_)))
    (define gerbil-ascent/core/relation-view#row-stream-view
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#row-stream::t
         'view)))
    (define gerbil-ascent/core/relation-view#row-stream-columns
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#row-stream::t
         'columns)))
    (define gerbil-ascent/core/relation-view#row-stream-key
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#row-stream::t
         'key)))
    (define gerbil-ascent/core/relation-view#row-stream-view-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#row-stream::t
         'view)))
    (define gerbil-ascent/core/relation-view#row-stream-columns-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#row-stream::t
         'columns)))
    (define gerbil-ascent/core/relation-view#row-stream-key-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#row-stream::t
         'key)))
    (define gerbil-ascent/core/relation-view#&row-stream-view
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#row-stream::t
         'view)))
    (define gerbil-ascent/core/relation-view#&row-stream-columns
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#row-stream::t
         'columns)))
    (define gerbil-ascent/core/relation-view#&row-stream-key
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#row-stream::t
         'key)))
    (define gerbil-ascent/core/relation-view#&row-stream-view-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#row-stream::t
         'view)))
    (define gerbil-ascent/core/relation-view#&row-stream-columns-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#row-stream::t
         'columns)))
    (define gerbil-ascent/core/relation-view#&row-stream-key-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#row-stream::t
         'key)))
    (define gerbil-ascent/core/relation-view#rectangle::t
      (let ((__tmp33563 (list)) (__tmp33562 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/core/relation-view#rectangle::t
         'rectangle
         __tmp33563
         '(prefix left right)
         __tmp33562
         '#f)))
    (define gerbil-ascent/core/relation-view#rectangle?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/core/relation-view#rectangle::t)))
    (define gerbil-ascent/core/relation-view#make-rectangle
      (lambda _%$args918%_
        (apply make-instance
               gerbil-ascent/core/relation-view#rectangle::t
               _%$args918%_)))
    (define gerbil-ascent/core/relation-view#rectangle-prefix
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#rectangle::t
         'prefix)))
    (define gerbil-ascent/core/relation-view#rectangle-left
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#rectangle::t
         'left)))
    (define gerbil-ascent/core/relation-view#rectangle-right
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#rectangle::t
         'right)))
    (define gerbil-ascent/core/relation-view#rectangle-prefix-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#rectangle::t
         'prefix)))
    (define gerbil-ascent/core/relation-view#rectangle-left-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#rectangle::t
         'left)))
    (define gerbil-ascent/core/relation-view#rectangle-right-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#rectangle::t
         'right)))
    (define gerbil-ascent/core/relation-view#&rectangle-prefix
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#rectangle::t
         'prefix)))
    (define gerbil-ascent/core/relation-view#&rectangle-left
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#rectangle::t
         'left)))
    (define gerbil-ascent/core/relation-view#&rectangle-right
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#rectangle::t
         'right)))
    (define gerbil-ascent/core/relation-view#&rectangle-prefix-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#rectangle::t
         'prefix)))
    (define gerbil-ascent/core/relation-view#&rectangle-left-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#rectangle::t
         'left)))
    (define gerbil-ascent/core/relation-view#&rectangle-right-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#rectangle::t
         'right)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket::t
      (let ((__tmp33565 (list))
            (__tmp33564
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/core/relation-view#rectangle-bucket::t
         'rectangle-bucket
         __tmp33565
         '(members blocks count plain)
         __tmp33564
         '#f)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/core/relation-view#rectangle-bucket::t)))
    (define gerbil-ascent/core/relation-view#make-rectangle-bucket
      (lambda _%$args915%_
        (apply make-instance
               gerbil-ascent/core/relation-view#rectangle-bucket::t
               _%$args915%_)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'members)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket-blocks
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'blocks)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket-count
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'count)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket-plain
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'plain)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'members)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket-blocks-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'blocks)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'count)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket-plain-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'plain)))
    (define gerbil-ascent/core/relation-view#&rectangle-bucket-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'members)))
    (define gerbil-ascent/core/relation-view#&rectangle-bucket-blocks
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'blocks)))
    (define gerbil-ascent/core/relation-view#&rectangle-bucket-count
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'count)))
    (define gerbil-ascent/core/relation-view#&rectangle-bucket-plain
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'plain)))
    (define gerbil-ascent/core/relation-view#&rectangle-bucket-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'members)))
    (define gerbil-ascent/core/relation-view#&rectangle-bucket-blocks-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'blocks)))
    (define gerbil-ascent/core/relation-view#&rectangle-bucket-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'count)))
    (define gerbil-ascent/core/relation-view#&rectangle-bucket-plain-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'plain)))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-view-bind
      (lambda (_%view909%_
               _%identity910%_
               _%generation911%_
               _%revision912%_
               _%lane913%_)
        (let ((__tmp33571
               (##structure-ref
                _%view909%_
                '5
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp33570
               (##structure-ref
                _%view909%_
                '6
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp33569
               (##structure-ref
                _%view909%_
                '7
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp33568
               (##structure-ref
                _%view909%_
                '8
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp33567
               (##structure-ref
                _%view909%_
                '9
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp33566
               (##structure-ref
                _%view909%_
                '10
                gerbil-ascent/core/relation-view#relation-view::t
                '#f)))
          (declare (not safe))
          (##structure
           gerbil-ascent/core/relation-view#relation-view::t
           _%identity910%_
           _%generation911%_
           _%revision912%_
           _%lane913%_
           __tmp33571
           __tmp33570
           __tmp33569
           __tmp33568
           __tmp33567
           __tmp33566))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-view-with-export
      (lambda (_%view906%_ _%export907%_)
        (let ((__tmp33580
               (##structure-ref
                _%view906%_
                '1
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp33579
               (##structure-ref
                _%view906%_
                '2
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp33578
               (##structure-ref
                _%view906%_
                '3
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp33577
               (##structure-ref
                _%view906%_
                '4
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp33576
               (##structure-ref
                _%view906%_
                '5
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp33575
               (##structure-ref
                _%view906%_
                '6
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp33574
               (##structure-ref
                _%view906%_
                '7
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp33573
               (##structure-ref
                _%view906%_
                '8
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp33572
               (##structure-ref
                _%view906%_
                '10
                gerbil-ascent/core/relation-view#relation-view::t
                '#f)))
          (declare (not safe))
          (##structure
           gerbil-ascent/core/relation-view#relation-view::t
           __tmp33580
           __tmp33579
           __tmp33578
           __tmp33577
           __tmp33576
           __tmp33575
           __tmp33574
           __tmp33573
           _%export907%_
           __tmp33572))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
      (lambda (_%consume900%_ _%rows901%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%rows901%_
               'gerbil-ascent/core/relation-view#relation-view::t))
            ((let ()
               (declare (not safe))
               (##unchecked-structure-ref _%rows901%_ '7 '#f '#f))
             '()
             '()
             _%consume900%_)
            (if (let ()
                  (declare (not safe))
                  (##structure-instance-of?
                   _%rows901%_
                   'gerbil-ascent/core/relation-view#row-stream::t))
                ((##structure-ref
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%rows901%_ '1 '#f '#f))
                  '7
                  gerbil-ascent/core/relation-view#relation-view::t
                  '#f)
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%rows901%_ '2 '#f '#f))
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%rows901%_ '3 '#f '#f))
                 _%consume900%_)
                (for-each _%consume900%_ _%rows901%_)))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-any-row?
      (lambda (_%predicate893%_ _%rows894%_)
        (let ((__tmp33581
               (lambda (_%done896%_)
                 (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
                  (lambda (_%row898%_)
                    (if (_%predicate893%_ _%row898%_)
                        (_%done896%_ '#t)
                        '#!void))
                  _%rows894%_)
                 '#f)))
          (declare (not safe))
          (##call-with-current-continuation __tmp33581))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-row-count
      (lambda (_%rows891%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%rows891%_
               'gerbil-ascent/core/relation-view#relation-view::t))
            (let ()
              (declare (not safe))
              (##unchecked-structure-ref _%rows891%_ '5 '#f '#f))
            (length _%rows891%_))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-view-select
      (lambda (_%view887%_ _%columns888%_ _%key889%_)
        (if (and (null? _%columns888%_) (null? _%key889%_))
            _%view887%_
            (let ()
              (declare (not safe))
              (##structure
               gerbil-ascent/core/relation-view#row-stream::t
               _%view887%_
               _%columns888%_
               _%key889%_)))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-row-parts?
      (lambda (_%rows882%_)
        (if (if (let ()
                  (declare (not safe))
                  (##structure-instance-of?
                   _%rows882%_
                   'gerbil-ascent/core/relation-view#relation-view::t))
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-ref _%rows882%_ '10 '#f '#f))
                (and (let ()
                       (declare (not safe))
                       (##structure-instance-of?
                        _%rows882%_
                        'gerbil-ascent/core/relation-view#row-stream::t))
                     (##structure-ref
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref _%rows882%_ '1 '#f '#f))
                      '10
                      gerbil-ascent/core/relation-view#relation-view::t
                      '#f)))
            '#t
            '#f)))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-admitted-row-parts?
      (lambda (_%view878%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%view878%_
               'gerbil-ascent/core/relation-view#relation-view::t))
            (let ((_%parts880%_
                   (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref _%view878%_ '10 '#f '#f))))
              (if (let ()
                    (declare (not safe))
                    (##structure-instance-of?
                     _%parts880%_
                     'gerbil-ascent/core/relation-view#part-visitors::t))
                  (if (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref _%parts880%_ '2 '#f '#f))
                      '#t
                      '#f)
                  '#f))
            '#f)))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row-parts
      (lambda (_%consume875%_ _%rows876%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%rows876%_
               'gerbil-ascent/core/relation-view#relation-view::t))
            (gerbil-ascent/core/relation-view#gerbil-ascent-visit-view-parts!
             _%rows876%_
             '()
             '()
             _%consume875%_)
            (gerbil-ascent/core/relation-view#gerbil-ascent-visit-view-parts!
             (##structure-ref
              _%rows876%_
              '1
              gerbil-ascent/core/relation-view#row-stream::t
              '#f)
             (##structure-ref
              _%rows876%_
              '2
              gerbil-ascent/core/relation-view#row-stream::t
              '#f)
             (##structure-ref
              _%rows876%_
              '3
              gerbil-ascent/core/relation-view#row-stream::t
              '#f)
             _%consume875%_))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-visit-view-parts!
      (lambda (_%view868%_ _%columns869%_ _%key870%_ _%consume871%_)
        (let ((_%parts873%_
               (##structure-ref
                _%view868%_
                '10
                gerbil-ascent/core/relation-view#relation-view::t
                '#f)))
          ((if (let ()
                 (declare (not safe))
                 (##structure-instance-of?
                  _%parts873%_
                  'gerbil-ascent/core/relation-view#part-visitors::t))
               (let ()
                 (declare (not safe))
                 (##unchecked-structure-ref _%parts873%_ '1 '#f '#f))
               _%parts873%_)
           _%columns869%_
           _%key870%_
           _%consume871%_))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-visit-admitted-view-parts!
      (lambda (_%view863%_ _%columns864%_ _%key865%_ _%consume866%_)
        (if (gerbil-ascent/core/relation-view#gerbil-ascent-admitted-row-parts?
             _%view863%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"ASCENT view lacks admitted parts")))
        ((##structure-ref
          (##structure-ref
           _%view863%_
           '10
           gerbil-ascent/core/relation-view#relation-view::t
           '#f)
          '2
          gerbil-ascent/core/relation-view#part-visitors::t
          '#f)
         _%columns864%_
         _%key865%_
         _%consume866%_)))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-view-contains?
      (lambda (_%view860%_ _%row861%_)
        ((##structure-ref
          _%view860%_
          '8
          gerbil-ascent/core/relation-view#relation-view::t
          '#f)
         _%row861%_)))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-view-rows
      (lambda (_%view854%_)
        (if (##structure-ref
             _%view854%_
             '9
             gerbil-ascent/core/relation-view#relation-view::t
             '#f)
            ((##structure-ref
              _%view854%_
              '9
              gerbil-ascent/core/relation-view#relation-view::t
              '#f))
            (let ((_%rows856%_ '()))
              (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
               (lambda (_%row858%_)
                 (set! _%rows856%_ (cons _%row858%_ _%rows856%_)))
               _%view854%_)
              (let () (declare (not safe)) (##reverse _%rows856%_))))))
    (define gerbil-ascent/core/relation-view#matches-key?
      (lambda (_%row847%_ _%columns848%_ _%key849%_)
        (let ((__tmp33582
               (lambda (_%column851%_ _%value852%_)
                 (equal? (list-ref _%row847%_ _%column851%_) _%value852%_))))
          (declare (not safe))
          (andmap__1 __tmp33582 _%columns848%_ _%key849%_))))
    (define gerbil-ascent/core/relation-view#ordered-key-offsets
      (lambda (_%columns836%_ _%key837%_)
        (if (list? _%columns836%_)
            (if (list? _%key837%_)
                (if (= (let () (declare (not safe)) (##length _%columns836%_))
                       (let () (declare (not safe)) (##length _%key837%_)))
                    (let ((__tmp33583
                           (lambda (_%unordered839%_)
                             (let* ((_%previous841%_ '0)
                                    (__tmp33584
                                     (lambda (_%column843%_)
                                       (if (and (exact-integer? _%column843%_)
                                                (>= _%column843%_
                                                    _%previous841%_))
                                           '#!void
                                           (_%unordered839%_ '#f))
                                       (let ((_%offset845%_
                                              (- _%column843%_
                                                 _%previous841%_)))
                                         (set! _%previous841%_ _%column843%_)
                                         _%offset845%_))))
                               (declare (not safe))
                               (##map __tmp33584 _%columns836%_)))))
                      (declare (not safe))
                      (##call-with-current-continuation __tmp33583))
                    '#f)
                '#f)
            '#f)))
    (define gerbil-ascent/core/relation-view#matches-offset-key?
      (lambda (_%row827%_ _%offsets828%_ _%key829%_)
        (let ((_%$e831%_ (null? _%offsets828%_)))
          (if _%$e831%_
              _%$e831%_
              (let ((_%rest834%_ (list-tail _%row827%_ (car _%offsets828%_))))
                (if (equal? (list-ref _%rest834%_ '0) (car _%key829%_))
                    (gerbil-ascent/core/relation-view#matches-offset-key?
                     _%rest834%_
                     (cdr _%offsets828%_)
                     (cdr _%key829%_))
                    '#f))))))
    (define gerbil-ascent/core/relation-view#compile-explicit-key-match
      (lambda (_%columns814%_ _%key815%_)
        (let ((_%offsets817%_
               (gerbil-ascent/core/relation-view#ordered-key-offsets
                _%columns814%_
                _%key815%_)))
          (if _%offsets817%_
              (lambda (_%$%g818820%_)
                (gerbil-ascent/core/relation-view#matches-offset-key?
                 _%$%g818820%_
                 _%offsets817%_
                 _%key815%_))
              (lambda (_%$%g822824%_)
                (gerbil-ascent/core/relation-view#matches-key?
                 _%$%g822824%_
                 _%columns814%_
                 _%key815%_))))))
    (define gerbil-ascent/core/relation-view#matches-prefix?
      (lambda (_%row808%_ _%prefix809%_)
        (let ((_%$e811%_ (null? _%prefix809%_)))
          (if _%$e811%_
              _%$e811%_
              (if (pair? _%row808%_)
                  (if (equal? (let () (declare (not safe)) (##car _%row808%_))
                              (car _%prefix809%_))
                      (gerbil-ascent/core/relation-view#matches-prefix?
                       (let () (declare (not safe)) (##cdr _%row808%_))
                       (cdr _%prefix809%_))
                      '#f)
                  '#f)))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-explicit-view
      (lambda (_%rows803%_ _%count804%_)
        (gerbil-ascent/core/relation-view#gerbil-ascent-lazy-explicit-view
         (map (lambda (_%row806%_) (map values _%row806%_)) _%rows803%_)
         _%count804%_)))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-lazy-explicit-view
      (lambda (_%snapshot787%_ _%count788%_)
        (letrec ((_%rows790%_
                  (lambda ()
                    (if (promise? _%snapshot787%_)
                        (force _%snapshot787%_)
                        _%snapshot787%_))))
          (let ((__tmp33586
                 (lambda (_%columns792%_ _%key793%_ _%consume794%_)
                   (let ((_%matches?796%_
                          (gerbil-ascent/core/relation-view#compile-explicit-key-match
                           _%columns792%_
                           _%key793%_)))
                     (for-each
                      (lambda (_%row798%_)
                        (if (let ()
                              (declare (not safe))
                              (_%matches?796%_ _%row798%_))
                            (_%consume794%_ (map values _%row798%_))
                            '#!void))
                      (_%rows790%_)))))
                (__tmp33585
                 (lambda (_%row800%_)
                   (if (member _%row800%_ (_%rows790%_)) '#t '#f))))
            (declare (not safe))
            (##structure
             gerbil-ascent/core/relation-view#relation-view::t
             '#f
             '#f
             '0
             'total
             _%count788%_
             _%count788%_
             __tmp33586
             __tmp33585
             '#f
             '#f)))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-view-union
      (lambda (_%left767%_ _%right768%_)
        (let ((__tmp33593
               (+ (##structure-ref
                   _%left767%_
                   '5
                   gerbil-ascent/core/relation-view#relation-view::t
                   '#f)
                  (##structure-ref
                   _%right768%_
                   '5
                   gerbil-ascent/core/relation-view#relation-view::t
                   '#f)))
              (__tmp33592
               (+ (##structure-ref
                   _%left767%_
                   '6
                   gerbil-ascent/core/relation-view#relation-view::t
                   '#f)
                  (##structure-ref
                   _%right768%_
                   '6
                   gerbil-ascent/core/relation-view#relation-view::t
                   '#f)))
              (__tmp33591
               (lambda (_%columns770%_ _%key771%_ _%consume772%_)
                 ((##structure-ref
                   _%left767%_
                   '7
                   gerbil-ascent/core/relation-view#relation-view::t
                   '#f)
                  _%columns770%_
                  _%key771%_
                  _%consume772%_)
                 ((##structure-ref
                   _%right768%_
                   '7
                   gerbil-ascent/core/relation-view#relation-view::t
                   '#f)
                  _%columns770%_
                  _%key771%_
                  _%consume772%_)))
              (__tmp33590
               (lambda (_%row774%_)
                 (let ((_%$e776%_
                        (gerbil-ascent/core/relation-view#gerbil-ascent-view-contains?
                         _%left767%_
                         _%row774%_)))
                   (if _%$e776%_
                       _%$e776%_
                       (gerbil-ascent/core/relation-view#gerbil-ascent-view-contains?
                        _%right768%_
                        _%row774%_)))))
              (__tmp33587
               (if (##structure-ref
                    _%left767%_
                    '10
                    gerbil-ascent/core/relation-view#relation-view::t
                    '#f)
                   (if (##structure-ref
                        _%right768%_
                        '10
                        gerbil-ascent/core/relation-view#relation-view::t
                        '#f)
                       (let ((__tmp33589
                              (lambda (_%columns779%_
                                       _%key780%_
                                       _%consume781%_)
                                (gerbil-ascent/core/relation-view#gerbil-ascent-visit-view-parts!
                                 _%left767%_
                                 _%columns779%_
                                 _%key780%_
                                 _%consume781%_)
                                (gerbil-ascent/core/relation-view#gerbil-ascent-visit-view-parts!
                                 _%right768%_
                                 _%columns779%_
                                 _%key780%_
                                 _%consume781%_)))
                             (__tmp33588
                              (if (gerbil-ascent/core/relation-view#gerbil-ascent-admitted-row-parts?
                                   _%left767%_)
                                  (if (gerbil-ascent/core/relation-view#gerbil-ascent-admitted-row-parts?
                                       _%right768%_)
                                      (lambda (_%columns783%_
                                               _%key784%_
                                               _%consume785%_)
                                        (gerbil-ascent/core/relation-view#gerbil-ascent-visit-admitted-view-parts!
                                         _%left767%_
                                         _%columns783%_
                                         _%key784%_
                                         _%consume785%_)
                                        (gerbil-ascent/core/relation-view#gerbil-ascent-visit-admitted-view-parts!
                                         _%right768%_
                                         _%columns783%_
                                         _%key784%_
                                         _%consume785%_))
                                      '#f)
                                  '#f)))
                         (declare (not safe))
                         (##structure
                          gerbil-ascent/core/relation-view#part-visitors::t
                          __tmp33589
                          __tmp33588))
                       '#f)
                   '#f)))
          (declare (not safe))
          (##structure
           gerbil-ascent/core/relation-view#relation-view::t
           '#f
           '#f
           '0
           'delta
           __tmp33593
           __tmp33592
           __tmp33591
           __tmp33590
           '#f
           __tmp33587))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-view-difference
      (lambda (_%newer722%_ _%older723%_ _%count724%_)
        (if (and (exact-integer? _%count724%_)
                 (>= _%count724%_ '0)
                 (gerbil-ascent/core/relation-view#gerbil-ascent-row-parts?
                  _%newer722%_)
                 (gerbil-ascent/core/relation-view#gerbil-ascent-row-parts?
                  _%older723%_)
                 (= _%count724%_
                    (- (##structure-ref
                        _%newer722%_
                        '5
                        gerbil-ascent/core/relation-view#relation-view::t
                        '#f)
                       (##structure-ref
                        _%older723%_
                        '5
                        gerbil-ascent/core/relation-view#relation-view::t
                        '#f))))
            '#!void
            (let ()
              (declare (not safe))
              (error '"ASCENT view difference requires coherent part cuts")))
        (let ((_%admitted?726%_
               (if (gerbil-ascent/core/relation-view#gerbil-ascent-admitted-row-parts?
                    _%newer722%_)
                   (gerbil-ascent/core/relation-view#gerbil-ascent-admitted-row-parts?
                    _%older723%_)
                   '#f)))
          (letrec ((_%parts728%_
                    (lambda (_%columns748%_
                             _%key749%_
                             _%consume750%_
                             _%admitted?751%_)
                      ((if _%admitted?751%_
                           gerbil-ascent/core/relation-view#gerbil-ascent-visit-admitted-view-parts!
                           gerbil-ascent/core/relation-view#gerbil-ascent-visit-view-parts!)
                       _%newer722%_
                       _%columns748%_
                       _%key749%_
                       (lambda (_%prefix753%_ _%left754%_ _%right755%_)
                         (let ((_%found?757%_ '#f)
                               (_%row758%_
                                (let ((__tmp33594
                                       (list _%left754%_ _%right755%_)))
                                  (declare (not safe))
                                  (##append _%prefix753%_ __tmp33594))))
                           ((if _%admitted?751%_
                                gerbil-ascent/core/relation-view#gerbil-ascent-visit-admitted-view-parts!
                                gerbil-ascent/core/relation-view#gerbil-ascent-visit-view-parts!)
                            _%older723%_
                            (let ((_%$e760%_
                                   (let ()
                                     (declare (not safe))
                                     (##length _%row758%_))))
                              (if (eq? '2 _%$e760%_)
                                  '(0 1)
                                  (if (eq? '3 _%$e760%_)
                                      '(0 1 2)
                                      (let ((__tmp33595
                                             (let ()
                                               (declare (not safe))
                                               (##length _%row758%_))))
                                        (declare (not safe))
                                        (##iota __tmp33595)))))
                            _%row758%_
                            (lambda (_%_prefix763%_ _%_left764%_ _%_right765%_)
                              (set! _%found?757%_ '#t)))
                           (if _%found?757%_
                               '#!void
                               (_%consume750%_
                                _%prefix753%_
                                _%left754%_
                                _%right755%_))))))))
            (let ((__tmp33602
                   (+ (##structure-ref
                       _%newer722%_
                       '6
                       gerbil-ascent/core/relation-view#relation-view::t
                       '#f)
                      (##structure-ref
                       _%older723%_
                       '6
                       gerbil-ascent/core/relation-view#relation-view::t
                       '#f)))
                  (__tmp33600
                   (lambda (_%columns730%_ _%key731%_ _%consume732%_)
                     (_%parts728%_
                      _%columns730%_
                      _%key731%_
                      (lambda (_%prefix734%_ _%left735%_ _%right736%_)
                        (_%consume732%_
                         (let ((__tmp33601 (list _%left735%_ _%right736%_)))
                           (declare (not safe))
                           (##append _%prefix734%_ __tmp33601))))
                      '#f)))
                  (__tmp33599
                   (lambda (_%row738%_)
                     (if (gerbil-ascent/core/relation-view#gerbil-ascent-view-contains?
                          _%newer722%_
                          _%row738%_)
                         (not (gerbil-ascent/core/relation-view#gerbil-ascent-view-contains?
                               _%older723%_
                               _%row738%_))
                         '#f)))
                  (__tmp33596
                   (let ((__tmp33598
                          (lambda (_%columns740%_ _%key741%_ _%consume742%_)
                            (_%parts728%_
                             _%columns740%_
                             _%key741%_
                             _%consume742%_
                             '#f)))
                         (__tmp33597
                          (if _%admitted?726%_
                              (lambda (_%columns744%_
                                       _%key745%_
                                       _%consume746%_)
                                (_%parts728%_
                                 _%columns744%_
                                 _%key745%_
                                 _%consume746%_
                                 '#t))
                              '#f)))
                     (declare (not safe))
                     (##structure
                      gerbil-ascent/core/relation-view#part-visitors::t
                      __tmp33598
                      __tmp33597))))
              (declare (not safe))
              (##structure
               gerbil-ascent/core/relation-view#relation-view::t
               '#f
               '#f
               '0
               'delta
               _%count724%_
               __tmp33602
               __tmp33600
               __tmp33599
               '#f
               __tmp33596))))))
    (define gerbil-ascent/core/relation-view#matches-coordinate?
      (lambda (_%value711%_ _%coordinate712%_ _%columns713%_ _%key714%_)
        (let ((__tmp33603
               (lambda (_%column716%_ _%selected717%_)
                 (let ((_%$e719%_ (not (= _%column716%_ _%coordinate712%_))))
                   (if _%$e719%_
                       _%$e719%_
                       (equal? _%value711%_ _%selected717%_))))))
          (declare (not safe))
          (andmap__1 __tmp33603 _%columns713%_ _%key714%_))))
    (define gerbil-ascent/core/relation-view#captured-member
      (lambda (_%routes699%_ _%members700%_ _%coordinate701%_ _%value702%_)
        (let _%find704%_ ((_%hits706%_
                           (let ((_%$e708%_
                                  (let ((__tmp33604
                                         (vector-ref
                                          _%routes699%_
                                          _%coordinate701%_)))
                                    (declare (not safe))
                                    (hash-get __tmp33604 _%value702%_))))
                             (if _%$e708%_ _%$e708%_ '()))))
          (if (pair? _%hits706%_)
              (if (eq? (##direct-structure-ref
                        (cdar _%hits706%_)
                        '1
                        gerbil-ascent/core/relation-view#rectangle-bucket::t
                        '#f)
                       _%members700%_)
                  (let () (declare (not safe)) (##car _%hits706%_))
                  (_%find704%_
                   (let () (declare (not safe)) (##cdr _%hits706%_))))
              '#f))))
    (define gerbil-ascent/core/relation-view#selected-members
      (lambda (_%members681%_
               _%coordinate682%_
               _%columns683%_
               _%key684%_
               _%routes685%_)
        (let _%find687%_ ((_%remaining689%_ _%columns683%_)
                          (_%values690%_ _%key684%_))
          (if (null? _%remaining689%_)
              _%members681%_
              (if (= (car _%remaining689%_) _%coordinate682%_)
                  (let ((_%present696%_
                         (if _%routes685%_
                             (let ((_%hit694%_
                                    (gerbil-ascent/core/relation-view#captured-member
                                     _%routes685%_
                                     _%members681%_
                                     _%coordinate682%_
                                     (car _%values690%_))))
                               (if _%hit694%_ (car _%hit694%_) '#f))
                             (member (car _%values690%_) _%members681%_))))
                    (if (and _%present696%_
                             (gerbil-ascent/core/relation-view#matches-coordinate?
                              (car _%present696%_)
                              _%coordinate682%_
                              _%columns683%_
                              _%key684%_))
                        (if _%routes685%_
                            _%present696%_
                            (list (car _%present696%_)))
                        '()))
                  (_%find687%_ (cdr _%remaining689%_) (cdr _%values690%_)))))))
    (define gerbil-ascent/core/relation-view#visit-right-members
      (lambda (_%prefix676%_ _%left677%_ _%rights678%_ _%consume679%_)
        (if (null? _%rights678%_)
            '#!void
            (begin
              (_%consume679%_ _%prefix676%_ _%left677%_ (car _%rights678%_))
              (gerbil-ascent/core/relation-view#visit-right-members
               _%prefix676%_
               _%left677%_
               (cdr _%rights678%_)
               _%consume679%_)))))
    (define gerbil-ascent/core/relation-view#visit-left-members
      (lambda (_%prefix671%_ _%lefts672%_ _%rights673%_ _%consume674%_)
        (if (null? _%lefts672%_)
            '#!void
            (begin
              (gerbil-ascent/core/relation-view#visit-right-members
               _%prefix671%_
               (car _%lefts672%_)
               _%rights673%_
               _%consume674%_)
              (gerbil-ascent/core/relation-view#visit-left-members
               _%prefix671%_
               (cdr _%lefts672%_)
               _%rights673%_
               _%consume674%_)))))
    (define gerbil-ascent/core/relation-view#visit-rectangle-parts__%
      (lambda (_%block645%_
               _%columns646%_
               _%key647%_
               _%consume648%_
               _%routes649%_)
        (let ((_%offset651%_
               (length (##structure-ref
                        _%block645%_
                        '1
                        gerbil-ascent/core/relation-view#rectangle::t
                        '#f))))
          (if (let ((__tmp33605
                     (lambda (_%column653%_)
                       (< _%column653%_ (+ _%offset651%_ '2)))))
                (declare (not safe))
                (andmap__0 __tmp33605 _%columns646%_))
              '#!void
              (let ()
                (declare (not safe))
                (error '"invalid ASCENT UF view column"))))
        (gerbil-ascent/core/relation-view#visit-admitted-rectangle-parts
         _%block645%_
         _%columns646%_
         _%key647%_
         _%consume648%_
         _%routes649%_)))
    (define gerbil-ascent/core/relation-view#visit-rectangle-parts__0
      (lambda (_%block658%_ _%columns659%_ _%key660%_ _%consume661%_)
        (let ((_%routes663%_ '#f))
          (gerbil-ascent/core/relation-view#visit-rectangle-parts__%
           _%block658%_
           _%columns659%_
           _%key660%_
           _%consume661%_
           _%routes663%_))))
    (define gerbil-ascent/core/relation-view#visit-rectangle-parts
      (lambda _g33606_
        (let ((_g33607_ (let () (declare (not safe)) (##length _g33606_))))
          (cond ((let () (declare (not safe)) (##fx= _g33607_ 4))
                 (apply gerbil-ascent/core/relation-view#visit-rectangle-parts__0
                        _g33606_))
                ((let () (declare (not safe)) (##fx= _g33607_ 5))
                 (apply gerbil-ascent/core/relation-view#visit-rectangle-parts__%
                        _g33606_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/core/relation-view#visit-rectangle-parts
                  _g33606_))))))
    (define gerbil-ascent/core/relation-view#visit-admitted-rectangle-parts
      (lambda (_%block624%_
               _%columns625%_
               _%key626%_
               _%consume627%_
               _%routes628%_)
        (let* ((_%prefix630%_
                (##structure-ref
                 _%block624%_
                 '1
                 gerbil-ascent/core/relation-view#rectangle::t
                 '#f))
               (_%offset632%_ (length _%prefix630%_)))
          (if (let ((__tmp33608
                     (lambda (_%column635%_ _%value636%_)
                       (or (>= _%column635%_ _%offset632%_)
                           (equal? (list-ref _%prefix630%_ _%column635%_)
                                   _%value636%_)))))
                (declare (not safe))
                (andmap__1 __tmp33608 _%columns625%_ _%key626%_))
              (let ((_%lefts641%_
                     (gerbil-ascent/core/relation-view#selected-members
                      (##structure-ref
                       _%block624%_
                       '2
                       gerbil-ascent/core/relation-view#rectangle::t
                       '#f)
                      _%offset632%_
                      _%columns625%_
                      _%key626%_
                      _%routes628%_))
                    (_%rights642%_
                     (gerbil-ascent/core/relation-view#selected-members
                      (##structure-ref
                       _%block624%_
                       '3
                       gerbil-ascent/core/relation-view#rectangle::t
                       '#f)
                      (+ _%offset632%_ '1)
                      _%columns625%_
                      _%key626%_
                      _%routes628%_)))
                (gerbil-ascent/core/relation-view#visit-left-members
                 _%prefix630%_
                 _%lefts641%_
                 _%rights642%_
                 _%consume627%_))
              '#!void))))
    (define gerbil-ascent/core/relation-view#visit-admitted-blocks
      (lambda (_%blocks618%_
               _%columns619%_
               _%key620%_
               _%consume621%_
               _%routes622%_)
        (if (null? _%blocks618%_)
            '#!void
            (begin
              (gerbil-ascent/core/relation-view#visit-admitted-rectangle-parts
               (car _%blocks618%_)
               _%columns619%_
               _%key620%_
               _%consume621%_
               _%routes622%_)
              (gerbil-ascent/core/relation-view#visit-admitted-blocks
               (cdr _%blocks618%_)
               _%columns619%_
               _%key620%_
               _%consume621%_
               _%routes622%_)))))
    (define gerbil-ascent/core/relation-view#rectangle-routing
      (lambda (_%blocks548%_)
        (let* ((_%arity553%_
                (let ((__tmp33609
                       (lambda (_%block550%_ _%n551%_)
                         (max _%n551%_
                              (+ '2
                                 (length (##structure-ref
                                          _%block550%_
                                          '1
                                          gerbil-ascent/core/relation-view#rectangle::t
                                          '#f)))))))
                  (declare (not safe))
                  (foldl__0 __tmp33609 '0 _%blocks548%_)))
               (_%owners557%_
                (list->vector
                 (let ((__tmp33611
                        (lambda (_%_555%_)
                          (let () (declare (not safe)) (make-hash-table-eq))))
                       (__tmp33610 (iota _%arity553%_)))
                   (declare (not safe))
                   (##map __tmp33611 __tmp33610))))
               (_%routes561%_
                (list->vector
                 (let ((__tmp33613
                        (lambda (_%_559%_)
                          (let ()
                            (declare (not safe))
                            (make-hash-table__%
                             '#f
                             absent-value
                             absent-value
                             absent-value
                             absent-value
                             absent-value
                             absent-value
                             absent-value
                             absent-value))))
                       (__tmp33612 (iota _%arity553%_)))
                   (declare (not safe))
                   (##map __tmp33613 __tmp33612)))))
          (for-each
           (lambda (_%block564%_ _%ordinal565%_)
             (let* ((_%prefix567%_
                     (##structure-ref
                      _%block564%_
                      '1
                      gerbil-ascent/core/relation-view#rectangle::t
                      '#f))
                    (_%offset569%_ (length _%prefix567%_)))
               (letrec ((_%add!572%_
                         (lambda (_%column577%_ _%identity578%_ _%members579%_)
                           (let* ((_%table581%_
                                   (vector-ref _%owners557%_ _%column577%_))
                                  (_%bucket588%_
                                   (let ((_%$e583%_
                                          (let ()
                                            (declare (not safe))
                                            (hash-get
                                             _%table581%_
                                             _%identity578%_))))
                                     (if _%$e583%_
                                         _%$e583%_
                                         (let ((_%fresh586%_
                                                (let ()
                                                  (declare (not safe))
                                                  (##structure
                                                   gerbil-ascent/core/relation-view#rectangle-bucket::t
                                                   _%members579%_
                                                   '()
                                                   '0
                                                   '()))))
                                           (let ()
                                             (declare (not safe))
                                             (hash-put!
                                              _%table581%_
                                              _%identity578%_
                                              _%fresh586%_))
                                           _%fresh586%_)))))
                             (##direct-structure-set!
                              _%bucket588%_
                              (cons (cons _%ordinal565%_ _%block564%_)
                                    (##direct-structure-ref
                                     _%bucket588%_
                                     '2
                                     gerbil-ascent/core/relation-view#rectangle-bucket::t
                                     '#f))
                              '2
                              gerbil-ascent/core/relation-view#rectangle-bucket::t
                              '#f)
                             (##direct-structure-set!
                              _%bucket588%_
                              (+ '1
                                 (##direct-structure-ref
                                  _%bucket588%_
                                  '3
                                  gerbil-ascent/core/relation-view#rectangle-bucket::t
                                  '#f))
                              '3
                              gerbil-ascent/core/relation-view#rectangle-bucket::t
                              '#f)))))
                 (let ((__tmp33615
                        (lambda (_%column574%_ _%value575%_)
                          (_%add!572%_
                           _%column574%_
                           _%prefix567%_
                           (list _%value575%_))))
                       (__tmp33614
                        (let () (declare (not safe)) (##iota _%offset569%_))))
                   (declare (not safe))
                   (##for-each __tmp33615 __tmp33614 _%prefix567%_))
                 (_%add!572%_
                  _%offset569%_
                  (##structure-ref
                   _%block564%_
                   '2
                   gerbil-ascent/core/relation-view#rectangle::t
                   '#f)
                  (##structure-ref
                   _%block564%_
                   '2
                   gerbil-ascent/core/relation-view#rectangle::t
                   '#f))
                 (_%add!572%_
                  (+ _%offset569%_ '1)
                  (##structure-ref
                   _%block564%_
                   '3
                   gerbil-ascent/core/relation-view#rectangle::t
                   '#f)
                  (##structure-ref
                   _%block564%_
                   '3
                   gerbil-ascent/core/relation-view#rectangle::t
                   '#f)))))
           _%blocks548%_
           (let ((__tmp33616 (length _%blocks548%_)))
             (declare (not safe))
             (##iota __tmp33616)))
          (let ((__tmp33618
                 (lambda (_%column591%_)
                   (let ((__tmp33620
                          (lambda (_%_593%_ _%bucket594%_)
                            (let ((_%bucket596%_ _%bucket594%_))
                              (let ((__tmp33621
                                     (reverse (let ()
                                                (declare (not safe))
                                                (##unchecked-structure-ref
                                                 _%bucket596%_
                                                 '2
                                                 '#f
                                                 '#f)))))
                                (declare (not safe))
                                (##unchecked-structure-set!
                                 _%bucket596%_
                                 __tmp33621
                                 '2
                                 '#f
                                 '#f))
                              (let ((__tmp33622
                                     (map cdr
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%bucket596%_
                                             '2
                                             '#f
                                             '#f)))))
                                (declare (not safe))
                                (##unchecked-structure-set!
                                 _%bucket596%_
                                 __tmp33622
                                 '4
                                 '#f
                                 '#f))
                              (let ((_%table609%_
                                     (vector-ref _%routes561%_ _%column591%_)))
                                (for-each
                                 (lambda (_%member611%_)
                                   (let ((_%hits616%_
                                          (let ((_%$e613%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (hash-get
                                                    _%table609%_
                                                    _%member611%_))))
                                            (if _%$e613%_ _%$e613%_ '()))))
                                     (if (and (pair? _%hits616%_)
                                              (eq? (cdar _%hits616%_)
                                                   _%bucket596%_))
                                         '#!void
                                         (let ((__tmp33623
                                                (cons (cons (list _%member611%_)
                                                            _%bucket596%_)
                                                      _%hits616%_)))
                                           (declare (not safe))
                                           (hash-put!
                                            _%table609%_
                                            _%member611%_
                                            __tmp33623)))))
                                 (let ()
                                   (declare (not safe))
                                   (##unchecked-structure-ref
                                    _%bucket596%_
                                    '1
                                    '#f
                                    '#f)))))))
                         (__tmp33619 (vector-ref _%owners557%_ _%column591%_)))
                     (declare (not safe))
                     (hash-for-each __tmp33620 __tmp33619))))
                (__tmp33617 (iota _%arity553%_)))
            (declare (not safe))
            (##for-each __tmp33618 __tmp33617))
          _%routes561%_)))
    (define gerbil-ascent/core/relation-view#routed-rectangles
      (lambda (_%routes518%_ _%blocks519%_ _%columns520%_ _%key521%_)
        (if (null? _%columns520%_)
            _%blocks519%_
            (let ((_%selected523%_ '#f) (_%cost524%_ '+inf.0))
              (for-each
               (lambda (_%column526%_ _%value527%_)
                 (if (>= _%column526%_ (vector-length _%routes518%_))
                     (let ()
                       (declare (not safe))
                       (error '"invalid ASCENT UF view column"))
                     '#!void)
                 (if (> _%cost524%_ '1)
                     (let* ((_%buckets532%_
                             (let ((_%$e529%_
                                    (let ((__tmp33624
                                           (vector-ref
                                            _%routes518%_
                                            _%column526%_)))
                                      (declare (not safe))
                                      (hash-get __tmp33624 _%value527%_))))
                               (if _%$e529%_ _%$e529%_ '())))
                            (_%size537%_
                             (let ((__tmp33625
                                    (lambda (_%hit534%_ _%n535%_)
                                      (+ _%n535%_
                                         (##direct-structure-ref
                                          (cdr _%hit534%_)
                                          '3
                                          gerbil-ascent/core/relation-view#rectangle-bucket::t
                                          '#f)))))
                               (declare (not safe))
                               (foldl__0 __tmp33625 '0 _%buckets532%_))))
                       (if (< _%size537%_ _%cost524%_)
                           (begin
                             (set! _%selected523%_ _%buckets532%_)
                             (set! _%cost524%_ _%size537%_))
                           '#!void))
                     '#!void))
               _%columns520%_
               _%key521%_)
              (if (null? _%selected523%_)
                  '()
                  (if (null? (cdr _%selected523%_))
                      (##direct-structure-ref
                       (cdar _%selected523%_)
                       '4
                       gerbil-ascent/core/relation-view#rectangle-bucket::t
                       '#f)
                      (let ((__tmp33626
                             (let ((__tmp33629
                                    (lambda (_%a543%_ _%b544%_)
                                      (< (car _%a543%_) (car _%b544%_))))
                                   (__tmp33627
                                    (let ((__tmp33628
                                           (map (lambda (_%hit546%_)
                                                  (##direct-structure-ref
                                                   (cdr _%hit546%_)
                                                   '2
                                                   gerbil-ascent/core/relation-view#rectangle-bucket::t
                                                   '#f))
                                                _%selected523%_)))
                                      (declare (not safe))
                                      (##apply append __tmp33628))))
                               (declare (not safe))
                               (##list-sort __tmp33629 __tmp33627))))
                        (declare (not safe))
                        (##map cdr __tmp33626))))))))
    (define gerbil-ascent/core/relation-view#rectangle-contains?
      (lambda (_%block509%_ _%row510%_ _%width511%_)
        (let* ((_%prefix513%_
                (##structure-ref
                 _%block509%_
                 '1
                 gerbil-ascent/core/relation-view#rectangle::t
                 '#f))
               (_%offset515%_ (length _%prefix513%_)))
          (if (= _%width511%_ (+ _%offset515%_ '2))
              (if (gerbil-ascent/core/relation-view#matches-prefix?
                   _%row510%_
                   _%prefix513%_)
                  (if (member (list-ref _%row510%_ _%offset515%_)
                              (##structure-ref
                               _%block509%_
                               '2
                               gerbil-ascent/core/relation-view#rectangle::t
                               '#f))
                      (if (member (list-ref _%row510%_ (+ _%offset515%_ '1))
                                  (##structure-ref
                                   _%block509%_
                                   '3
                                   gerbil-ascent/core/relation-view#rectangle::t
                                   '#f))
                          '#t
                          '#f)
                      '#f)
                  '#f)
              '#f))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__%
      (lambda (_%blocks430%_ _%count431%_ _%units432%_ _%indexed?433%_)
        (let* ((_%routes435%_
                (if _%indexed?433%_
                    (if (pair? _%blocks430%_)
                        (gerbil-ascent/core/relation-view#rectangle-routing
                         _%blocks430%_)
                        '#f)
                    '#f))
               (_%membership-routes437%_
                (if _%routes435%_
                    (if (pair? (cdr _%blocks430%_))
                        (if (pair? (cddr _%blocks430%_)) _%routes435%_ '#f)
                        '#f)
                    '#f))
               (_%query-columns439%_
                (if _%membership-routes437%_
                    (let ((__tmp33630
                           (let ()
                             (declare (not safe))
                             (##vector-length _%membership-routes437%_))))
                      (declare (not safe))
                      (##iota __tmp33630))
                    '#f))
               (_%grouped?441%_
                (if (pair? _%blocks430%_)
                    (= (length (##structure-ref
                                (let ()
                                  (declare (not safe))
                                  (##car _%blocks430%_))
                                '1
                                gerbil-ascent/core/relation-view#rectangle::t
                                '#f))
                       '1)
                    '#f)))
          (letrec ((_%selected444%_
                    (lambda (_%columns492%_ _%key493%_)
                      (if _%routes435%_
                          (gerbil-ascent/core/relation-view#routed-rectangles
                           _%routes435%_
                           _%blocks430%_
                           _%columns492%_
                           _%key493%_)
                          _%blocks430%_)))
                   (_%validate-key!445%_
                    (lambda (_%columns487%_ _%key488%_)
                      (if (and (list? _%columns487%_)
                               (list? _%key488%_)
                               (= (let ()
                                    (declare (not safe))
                                    (##length _%columns487%_))
                                  (let ()
                                    (declare (not safe))
                                    (##length _%key488%_)))
                               (let ((__tmp33631
                                      (lambda (_%column490%_)
                                        (and (exact-integer? _%column490%_)
                                             (>= _%column490%_ '0)))))
                                 (declare (not safe))
                                 (andmap__0 __tmp33631 _%columns487%_)))
                          '#!void
                          (let ()
                            (declare (not safe))
                            (error '"invalid ASCENT UF view key")))))
                   (_%visit-admitted446%_
                    (lambda (_%columns475%_ _%key476%_ _%consume477%_)
                      (if (and _%grouped?441%_
                               _%routes435%_
                               (pair? _%columns475%_)
                               (= (let ()
                                    (declare (not safe))
                                    (##car _%columns475%_))
                                  '0))
                          (let ((_%hits482%_
                                 (let ((_%$e479%_
                                        (let ((__tmp33633
                                               (vector-ref _%routes435%_ '0))
                                              (__tmp33632 (car _%key476%_)))
                                          (declare (not safe))
                                          (hash-get __tmp33633 __tmp33632))))
                                   (if _%$e479%_ _%$e479%_ '()))))
                            (if (null? _%hits482%_)
                                '#!void
                                (if (and (null? (cdr _%hits482%_))
                                         (= (##direct-structure-ref
                                             (cdar _%hits482%_)
                                             '3
                                             gerbil-ascent/core/relation-view#rectangle-bucket::t
                                             '#f)
                                            '1)
                                         (= (length (##structure-ref
                                                     (car (##direct-structure-ref
                                                           (cdar _%hits482%_)
                                                           '4
                                                           gerbil-ascent/core/relation-view#rectangle-bucket::t
                                                           '#f))
                                                     '1
                                                     gerbil-ascent/core/relation-view#rectangle::t
                                                     '#f))
                                            '1))
                                    (gerbil-ascent/core/relation-view#visit-admitted-rectangle-parts
                                     (car (##direct-structure-ref
                                           (cdar _%hits482%_)
                                           '4
                                           gerbil-ascent/core/relation-view#rectangle-bucket::t
                                           '#f))
                                     (cdr _%columns475%_)
                                     (cdr _%key476%_)
                                     _%consume477%_
                                     _%routes435%_)
                                    (gerbil-ascent/core/relation-view#visit-admitted-blocks
                                     (_%selected444%_
                                      _%columns475%_
                                      _%key476%_)
                                     _%columns475%_
                                     _%key476%_
                                     _%consume477%_
                                     _%routes435%_))))
                          (gerbil-ascent/core/relation-view#visit-admitted-blocks
                           (_%selected444%_ _%columns475%_ _%key476%_)
                           _%columns475%_
                           _%key476%_
                           _%consume477%_
                           _%routes435%_)))))
            (let ((__tmp33639
                   (lambda (_%columns448%_ _%key449%_ _%consume450%_)
                     (_%validate-key!445%_ _%columns448%_ _%key449%_)
                     (for-each
                      (lambda (_%block452%_)
                        (gerbil-ascent/core/relation-view#visit-rectangle-parts__%
                         _%block452%_
                         _%columns448%_
                         _%key449%_
                         (lambda (_%prefix454%_ _%left455%_ _%right456%_)
                           (_%consume450%_
                            (let ((__tmp33640 (list _%left455%_ _%right456%_)))
                              (declare (not safe))
                              (##append _%prefix454%_ __tmp33640))))
                         _%routes435%_))
                      (_%selected444%_ _%columns448%_ _%key449%_))))
                  (__tmp33636
                   (lambda (_%row458%_)
                     (let ((_%width460%_ (length _%row458%_)))
                       (if (>= _%width460%_ '2)
                           (if (or (not _%membership-routes437%_)
                                   (<= _%width460%_
                                       (vector-length
                                        _%membership-routes437%_)))
                               (let ((__tmp33638
                                      (lambda (_%$%g464466%_)
                                        (gerbil-ascent/core/relation-view#rectangle-contains?
                                         _%$%g464466%_
                                         _%row458%_
                                         _%width460%_)))
                                     (__tmp33637
                                      (if _%membership-routes437%_
                                          (gerbil-ascent/core/relation-view#routed-rectangles
                                           _%membership-routes437%_
                                           _%blocks430%_
                                           (if (= _%width460%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (##vector-length
                                                     _%membership-routes437%_)))
                                               _%query-columns439%_
                                               (take _%query-columns439%_
                                                     _%width460%_))
                                           _%row458%_)
                                          _%blocks430%_)))
                                 (declare (not safe))
                                 (ormap__0 __tmp33638 __tmp33637))
                               '#f)
                           '#f))))
                  (__tmp33634
                   (let ((__tmp33635
                          (lambda (_%columns469%_ _%key470%_ _%consume471%_)
                            (_%validate-key!445%_ _%columns469%_ _%key470%_)
                            (for-each
                             (lambda (_%block473%_)
                               (gerbil-ascent/core/relation-view#visit-rectangle-parts__%
                                _%block473%_
                                _%columns469%_
                                _%key470%_
                                _%consume471%_
                                _%routes435%_))
                             (_%selected444%_ _%columns469%_ _%key470%_)))))
                     (declare (not safe))
                     (##structure
                      gerbil-ascent/core/relation-view#part-visitors::t
                      __tmp33635
                      _%visit-admitted446%_))))
              (declare (not safe))
              (##structure
               gerbil-ascent/core/relation-view#relation-view::t
               '#f
               '#f
               '0
               'total
               _%count431%_
               _%units432%_
               __tmp33639
               __tmp33636
               '#f
               __tmp33634))))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__0
      (lambda (_%blocks498%_ _%count499%_ _%units500%_)
        (let ((_%indexed?502%_ '#f))
          (gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__%
           _%blocks498%_
           _%count499%_
           _%units500%_
           _%indexed?502%_))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view
      (lambda _g33641_
        (let ((_g33642_ (let () (declare (not safe)) (##length _g33641_))))
          (cond ((let () (declare (not safe)) (##fx= _g33642_ 3))
                 (apply gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__0
                        _g33641_))
                ((let () (declare (not safe)) (##fx= _g33642_ 4))
                 (apply gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__%
                        _g33641_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view
                  _g33641_))))))))
