# SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
"""Portable receipts: native outcome, gross solver cost, and anchored labels."""
import json, collections, tarfile
from pathlib import Path
from .crosspath_search import ROOT, BASE, canonical, sha, save, verify

DOC=ROOT/'docs/research/agent-inference'

def produce():
    plan=json.loads((BASE/'frozen-plan.json').read_text());verify(plan)
    ledger=json.loads((BASE/'ledger.json').read_text())
    labels=json.loads((BASE/'annotation-ledger.json').read_text())
    lookup={x['phaseKey']:x for x in labels['annotations']};table=[];summary={}
    for row in ledger['phases']:
        folder=BASE/'paid'/f"{row['case']}-{row['arm']}-{row['phase']}"
        lab=lookup[str(folder.relative_to(BASE))];episodes=lab['accepted'];tools=row['tools']
        prefixes=[t['arguments']['selection'] for t in tools if t['name']=='inspect' and 'arguments' in t]
        candidates=[t['arguments']['selection'] for t in tools if t['name'] in ('evaluate','submit') and t['result'].get('valid') and 'arguments' in t]
        fragments=[]
        case=next(c for c in plan['cases'] if c['id']==row['case']);byid={o['id']:o for o in case['options']}
        for selection in candidates:
            fragments.append(set(byid[i]['fragment'] for i in selection))
        shares=[len(fragments[i]&fragments[j]) for i in range(len(candidates)) for j in range(i+1,len(candidates)) if candidates[i]!=candidates[j]]
        r={'task':row['case'],'goal':row['phase'],'arm':row['arm'],'solverGrossTokens':row['observedTotalTokens'],
           'usageUnknownCalls':sum(not isinstance(c.get('usage'),dict) for c in row['calls']),
           'thinkingTokens':sum((c.get('usage') or {}).get('output_tokens_details',{}).get('reasoning_tokens',0) for c in row['calls']),
           'submittedValid':bool(row['submitted'] and row['grade']['valid']),'failure':row['failure'],'bestValue':row['bestGrade'].get('value') if row['bestGrade']['valid'] else None,'gap':row['bestGrade'].get('gap') if row['bestGrade']['valid'] else None,
           'uniqueCandidates':len({canonical(x) for x in candidates}),'distinctPrefixes':len({canonical(x) for x in prefixes}),
           'maxPrefixDepth':max([len(x) for x in prefixes],default=0),'maxVerifiedCompleteDepth':max([len(x) for x in candidates],default=0),
           'branchWidth':len({x[0] for x in prefixes if x}),'crossCandidateSharedFragments':shares,
           'annotationEpisodes':len(episodes),'derivationEpisodes':sum(e['kind']=='derive' for e in episodes),
           'repeatedDerivations':sum(e['definiteRepeatedDerivation'] for e in episodes),
           'reuses':sum(e['kind']=='reuse' for e in episodes),'uncertain':sum(e['kind']=='uncertain' for e in episodes),
           'rejectedAnnotations':len(lab['rejected']),'annotationFailure':lab['failure'],
           'packetCoveredRederivations':sum(e['kind']=='derive' and e['nativeTruthMatches'] for e in episodes) if row['packet'] else None,
           'measurementGrossTokens':lab.get('measurementGrossTokens'),
           'nativePacketReused':row['packet']['reused'] if row['packet'] else None,
           'nativeProofBuilds':int(bool(row['packet']) and not row['packet']['reused'])+sum(t['name']=='fragment' and not t.get('nativeReused',False) for t in tools if 'failure' not in t),
           'nativeProofSeconds':(row['packet']['nativeSeconds'] if row['packet'] else 0)+sum(t.get('nativeSeconds',0) for t in tools if t['name']=='fragment')}
        # Each label remains linked to source text. Cross-goal repeats are distinct from within-goal prior links.
        table.append(r)
    for arm in ('baseline','fresh','retained'):
        rows=[r for r in table if r['arm']==arm]
        summary[arm]={'phases':len(rows),'submittedValid':sum(r['submittedValid'] for r in rows),'failures':sum(bool(r['failure']) for r in rows),
                      'grossTokens':sum(r['solverGrossTokens'] for r in rows),'thinkingTokens':sum(r['thinkingTokens'] for r in rows),
                      'uniqueCandidates':sum(r['uniqueCandidates'] for r in rows),'prefixes':sum(r['distinctPrefixes'] for r in rows),
                      'repeatedDerivations':sum(r['repeatedDerivations'] for r in rows),'derivationEpisodes':sum(r['derivationEpisodes'] for r in rows),
                      'reuses':sum(r['reuses'] for r in rows),'nativeProofBuilds':sum(r['nativeProofBuilds'] for r in rows),'nativeProofSeconds':sum(r['nativeProofSeconds'] for r in rows),'gaps':[r['gap'] for r in rows],
                      'annotationFailures':sum(bool(r['annotationFailure']) for r in rows),'usageUnknownCalls':sum(r['usageUnknownCalls'] for r in rows)}
    cross_goal=[]
    for c in plan['cases']:
        for arm in ('baseline','fresh','retained'):
            left=lookup[f"paid/{c['id']}-{arm}-0"]
            right=lookup[f"paid/{c['id']}-{arm}-1"]
            first=[e for e in left['accepted'] if e['kind']=='derive' and e['nativeTruthMatches']]
            second=[e for e in right['accepted'] if e['kind']=='derive' and e['nativeTruthMatches']]
            matches=[{'phase0Episode':a['index'],'phase1Episode':b['index'],'claimKey':a['claimKey']} for a in first for b in second if a['claimKey']==b['claimKey']]
            cross_goal.append({'task':c['id'],'arm':arm,'sourceContextMatches':matches,'interpretation':'Repeated grounded derivation across reset goals; distinct from within-trace prior-link duplication.'})
    raw={}
    for name in ('paid','annotations','qualification-packets'):
        for p in sorted((BASE/name).rglob('*')):
            if p.is_file():raw[str(p.relative_to(BASE))]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
    bundle=DOC/'crosspath-search-raw.tar.gz'
    with tarfile.open(bundle,'w:gz') as archive:
        for name in ('paid','annotations','qualification-packets','development-qualification-failed-limits-packets','development-qualification-before-relink-packets'):
            p=BASE/name
            if p.exists():archive.add(p,arcname=name)
        for p in sorted(BASE.glob('*.log')):archive.add(p,arcname=p.name)
        for name in ('frozen-plan.json','frozen-plan.sha256','qualification.json','post-run-binding.json','ledger.json','annotation-ledger.json'):
            archive.add(BASE/name,arcname=name)
        for name in ('crosspath-search.ss','crosspath-search-oracle.ss','crosspath-search-build.ss'):
            archive.add(ROOT/'tools'/name,arcname='tools/'+name)
    raw_bundle={'file':str(bundle.relative_to(ROOT)),'sha256':sha(bundle.read_bytes()),'bytes':bundle.stat().st_size}
    portable={'schema':'ascent.crosspath.ledger.v1','frozenPlan':plan,'qualification':json.loads((BASE/'qualification.json').read_text()),
              'planSha256':sha((BASE/'frozen-plan.json').read_bytes()),'phases':ledger['phases'],'annotations':labels['annotations'],'rawArtifacts':raw,'rawBundle':raw_bundle}
    save(DOC/'crosspath-search-ledger.json',portable)
    report={'schema':'ascent.crosspath.report.v1','planSha256':portable['planSha256'],'summary':summary,'table':table,'rawBundle':raw_bundle,
            'solverCalls':sum(len(r['calls']) for r in ledger['phases']),'annotationCalls':sum('usage' in x for x in labels['annotations']),
            'crossGoalRepeatedDerivations':cross_goal,
            'measurementGrossTokens':sum(x.get('measurementGrossTokens',0) for x in labels['annotations']),
            'limitations':['Two fixed tasks / four task-goal pairs: descriptive pilot; no statistical or general cognitive claim.',
             'Same packets/control policy in fresh and retained: native cache state alone is not a visible model treatment.',
             'No-evidence baseline may acquire certificates via common fragment tool: initial-packet intervention, not an evidence prohibition.',
             'Same budget ceiling, actual gross input+all output charged; conservative reservation may stop early with unused budget.',
             'Direct annotation is same-provider blinded semantic extraction with exact source spans/native fact truth, not validated exhaustive ground truth or independent-rater agreement.',
             'Arm/outcome metadata are withheld from the annotator, but reasoning content can reveal packet availability; blinding is partial.',
             'Audit instructions identify Fact IDs in every arm and may alter spontaneous reasoning/repetition.',
             'Search depth measures executed prefixes and valid full plans, not an unobserved mental search tree. No hidden reasoning inferred.',
             'Packet-covered rederivation and within-trace duplicates are separate; absent/ambiguous labels do not demonstrate zero repeated thinking.']}
    save(DOC/'crosspath-search-report.json',report)
    md=['# Cross-path fact reuse pilot','',f"Frozen plan: `{report['planSha256']}`. Twelve phases; {report['solverCalls']} solver calls; {report['annotationCalls']} blinded annotation calls. All failures retained.",'',
        'The solver sees seven-stage constrained search. Eligibility requires the conjunction of two graph paths; alternative candidates share these fragments. Two goals reset history and change values, bonuses and resource limits. The native outcome judge independently traverses original edges and exhaustively enumerates plans; it does not read ASCENT proofs or model reasoning.','',
        'Gross solver cost includes every input, all output and thinking, including prefix-cache input. Ceiling: 65,536 per phase; measurement calls are separate overhead. Fresh/retained initial packets are byte-identical; baseline gets raw source without an initial packet.','',
        '| Arm | Valid submit | Gross tokens | Thinking tokens | Unique candidates | Prefixes | Repeated derivations / extracted derivations | Gaps |',
        '|---|---:|---:|---:|---:|---:|---:|---|']
    for arm,s in summary.items():md.append(f"| {arm} | {s['submittedValid']}/{s['phases']} | {s['grossTokens']} | {s['thinkingTokens']} | {s['uniqueCandidates']} | {s['prefixes']} | {s['repeatedDerivations']}/{s['derivationEpisodes']} | {s['gaps']} |")
    md+=['','| Task / goal | Arm | Best gap | Prefix depth / full depth | Prefix first-option width | Failure |','|---|---|---:|---:|---:|---|']
    for r in table:md.append(f"| {r['task']} / {r['goal']} | {r['arm']} | {r['gap']} | {r['maxPrefixDepth']} / {r['maxVerifiedCompleteDepth']} | {r['branchWidth']} | {r['failure'] or 'none'} |")
    md+=['','Direct thinking annotations are in [the span report](crosspath-thinking-annotations.md), including source hashes, character ranges, exact excerpts, prior links and rejected entries. Native fact truth does not prove an annotation’s semantic completeness.','',*report['limitations']]
    (DOC/'crosspath-search-report.md').write_text('\n'.join(md)+'\n')
    spans=['# Direct annotations of returned model reasoning','','Annotations refer to external solver output only. Span ranges are half-open Unicode character offsets in the linked combined text. Each text is blinded to arm and grade during extraction. Repeated derivation counts require a grounded native claim and a prior derivation with matching premise identity.','']
    for lab in labels['annotations']:
        spans +=[f"## {lab['phaseKey']}",'',f"Text SHA256 `{lab['textSha256']}`; measurement failure `{lab['failure']}`. [Raw text]({BASE/'annotations'/lab['blindedId']/'thinking.txt'}).",'']
        for e in lab['accepted']:
            spans +=[f"- Episode {e['index']} / {e['kind']} / F{e['fragment']} / span {e['span']} / prior {e['prior']} / admitted repeat {e['definiteRepeatedDerivation']} / native truth match {e['nativeTruthMatches']}",'', '> '+e['quote'].replace('\n','\n> '),'',e['explanation'],'']
        if lab['rejected']:spans +=['Rejected labels retained:',canonical(lab['rejected']),'']
    (DOC/'crosspath-thinking-annotations.md').write_text('\n'.join(spans)+'\n')
    print(json.dumps({'summary':summary,'calls':report['solverCalls'],'annotationCalls':report['annotationCalls'],'measurementGrossTokens':report['measurementGrossTokens']},indent=2))

if __name__=='__main__':produce()
