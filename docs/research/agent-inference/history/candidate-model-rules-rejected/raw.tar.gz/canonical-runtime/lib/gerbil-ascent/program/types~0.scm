(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/types::timestamp 1791687878)
  (begin
    (define gerbil-ascent/program/types#slot-contract
      (lambda (_%identity5646%_ _%predicate5647%_)
        (let ((__tmp35285 (lambda (_%_value5649%_ _%_context5650%_) '())))
          (declare (not safe))
          (core/types#poo-flow-predicate-contract
           _%identity5646%_
           _%predicate5647%_
           __tmp35285))))
    (define gerbil-ascent/program/types#+symbol+
      (gerbil-ascent/program/types#slot-contract 'ascent/symbol symbol?))
    (define gerbil-ascent/program/types#+arity+
      (gerbil-ascent/program/types#slot-contract
       'ascent/arity
       (lambda (_%value5644%_)
         (if (exact-integer? _%value5644%_) (<= '0 _%value5644%_) '#f))))
    (define gerbil-ascent/program/types#+fact-budget+
      (gerbil-ascent/program/types#slot-contract
       'ascent/fact-budget
       (lambda (_%value5642%_)
         (if (exact-integer? _%value5642%_) (> _%value5642%_ '0) '#f))))
    (define gerbil-ascent/program/types#+rows+
      (gerbil-ascent/program/types#slot-contract 'ascent/rows list?))
    (define gerbil-ascent/program/types#+field-predicates+
      (gerbil-ascent/program/types#slot-contract
       'ascent/field-predicates
       (lambda (_%value5640%_)
         (if (list? _%value5640%_)
             (let () (declare (not safe)) (andmap__0 procedure? _%value5640%_))
             '#f))))
    (define gerbil-ascent/program/types#+provider+
      (gerbil-ascent/program/types#slot-contract
       'ascent/index-provider
       (lambda (_%value5635%_)
         (let ((_%$e5637%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                   _%value5635%_))))
           (if _%$e5637%_
               _%$e5637%_
               (let ()
                 (declare (not safe))
                 (clan/poo/mop#element?
                  gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
                  _%value5635%_)))))))
    (define gerbil-ascent/program/types#+storage-provider+
      (gerbil-ascent/program/types#slot-contract
       'ascent/storage-provider
       (lambda (_%value5630%_)
         (let ((_%$e5632%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                   _%value5630%_))))
           (if _%$e5632%_
               _%$e5632%_
               (let ()
                 (declare (not safe))
                 (clan/poo/mop#element?
                  gerbil-ascent/table/storage#GerbilAscentStorageProviderContract
                  _%value5630%_)))))))
    (define gerbil-ascent/program/types#+term-kind+
      (gerbil-ascent/program/types#slot-contract
       'ascent/term-kind
       (lambda (_%value5628%_)
         (let ()
           (declare (not safe))
           (##memq _%value5628%_
                   '(variable wildcard literal expression pattern))))))
    (define gerbil-ascent/program/types#+any+
      (gerbil-ascent/program/types#slot-contract
       'ascent/value
       (lambda (_%_value5626%_) '#t)))
    (define gerbil-ascent/program/types#+plan+
      (gerbil-ascent/program/types#slot-contract
       'ascent/clause-plan
       procedure?))
    (define gerbil-ascent/program/types#clause-kind-contract
      (lambda (_%kind5622%_)
        (gerbil-ascent/program/types#slot-contract
         'ascent/clause-kind
         (lambda (_%value5624%_) (eq? _%value5624%_ _%kind5622%_)))))
    (define gerbil-ascent/program/types#GerbilAscentRelationContract
      (let ((__obj35242
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35287
               (list (cons 'sexp
                           (let ((__tmp35288
                                  (lambda (_%@5538%_)
                                    'GerbilAscentRelationContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35288)))
                     (cons 'identity
                           (let ((__tmp35289
                                  (lambda (_%@5544%_) 'ascent/relation)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35289)))
                     (cons 'proto
                           (let ((__tmp35290
                                  (lambda (_%@5549%_)
                                    (let ((__obj35240
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35292 (list))
                                            (__tmp35291 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35292
                                         __tmp35291
                                         __obj35240))
                                      __obj35240))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35290)))
                     (cons 'responsibilities
                           (let ((__tmp35293
                                  (lambda (_%@5563%_)
                                    (let ((__obj35241
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35295
                                             (list (cons 'name
                                                         (let ((__tmp35296
                                                                (lambda (_%self5585%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35296)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'arity
                                                         (let ((__tmp35297
                                                                (lambda (_%self5592%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+arity+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35297)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'rows
                                                         (let ((__tmp35298
                                                                (lambda (_%self5597%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+rows+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35298)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'field-predicates
                                                         (let ((__tmp35299
                                                                (lambda (_%self5602%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+field-predicates+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35299)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'storage-kind
                                                         (let ((__tmp35300
                                                                (lambda (_%self5607%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'relation))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35300)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'index-provider
                                                         (let ((__tmp35301
                                                                (lambda (_%self5612%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+provider+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35301)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'storage-provider
                                                         (let ((__tmp35302
                                                                (lambda (_%self5617%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+storage-provider+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35302)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35294 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35295
                                         __tmp35294
                                         __obj35241))
                                      __obj35241))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35293)))))
              (__tmp35286 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35287
           __tmp35286
           __obj35242))
        __obj35242))
    (define gerbil-ascent/program/types#GerbilAscentLatticeContract
      (let ((__obj35245
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35304
               (list (cons 'sexp
                           (let ((__tmp35305
                                  (lambda (_%@5430%_)
                                    'GerbilAscentLatticeContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35305)))
                     (cons 'identity
                           (let ((__tmp35306
                                  (lambda (_%@5436%_) 'ascent/lattice)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35306)))
                     (cons 'proto
                           (let ((__tmp35307
                                  (lambda (_%@5441%_)
                                    (let ((__obj35243
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35309 (list))
                                            (__tmp35308 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35309
                                         __tmp35308
                                         __obj35243))
                                      __obj35243))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35307)))
                     (cons 'responsibilities
                           (let ((__tmp35310
                                  (lambda (_%@5455%_)
                                    (let ((__obj35244
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35312
                                             (list (cons 'name
                                                         (let ((__tmp35313
                                                                (lambda (_%self5478%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35313)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'arity
                                                         (let ((__tmp35314
                                                                (lambda (_%self5485%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+arity+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35314)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'rows
                                                         (let ((__tmp35315
                                                                (lambda (_%self5490%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+rows+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35315)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'field-predicates
                                                         (let ((__tmp35316
                                                                (lambda (_%self5495%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+field-predicates+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35316)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'storage-kind
                                                         (let ((__tmp35317
                                                                (lambda (_%self5500%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'lattice))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35317)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'join
                                                         (let ((__tmp35318
                                                                (lambda (_%self5505%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#slot-contract
                           'ascent/lattice-join
                           procedure?))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35318)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'checked-operator
                                                         (let ((__tmp35319
                                                                (lambda (_%self5510%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#slot-contract
                           'ascent/lattice-checked-operator
                           (lambda (_%value5515%_)
                             (let ((_%$e5517%_ (not _%value5515%_)))
                               (if _%$e5517%_
                                   _%$e5517%_
                                   (vector? _%value5515%_))))))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35319)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'index-provider
                                                         (let ((__tmp35320
                                                                (lambda (_%self5520%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+provider+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35320)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35311 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35312
                                         __tmp35311
                                         __obj35244))
                                      __obj35244))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35310)))))
              (__tmp35303 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35304
           __tmp35303
           __obj35245))
        __obj35245))
    (define gerbil-ascent/program/types#GerbilAscentTermContract
      (let ((__obj35248
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35322
               (list (cons 'sexp
                           (let ((__tmp35323
                                  (lambda (_%@5363%_)
                                    'GerbilAscentTermContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35323)))
                     (cons 'identity
                           (let ((__tmp35324
                                  (lambda (_%@5369%_) 'ascent/term)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35324)))
                     (cons 'proto
                           (let ((__tmp35325
                                  (lambda (_%@5374%_)
                                    (let ((__obj35246
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35327 (list))
                                            (__tmp35326 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35327
                                         __tmp35326
                                         __obj35246))
                                      __obj35246))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35325)))
                     (cons 'responsibilities
                           (let ((__tmp35328
                                  (lambda (_%@5388%_)
                                    (let ((__obj35247
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35330
                                             (list (cons 'kind
                                                         (let ((__tmp35331
                                                                (lambda (_%self5405%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+term-kind+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35331)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'value
                                                         (let ((__tmp35332
                                                                (lambda (_%self5412%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+any+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35332)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35329 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35330
                                         __tmp35329
                                         __obj35247))
                                      __obj35247))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35328)))))
              (__tmp35321 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35322
           __tmp35321
           __obj35248))
        __obj35248))
    (define gerbil-ascent/program/types#+terms+
      (gerbil-ascent/program/types#slot-contract
       'ascent/terms
       (lambda (_%value5346%_)
         (if (list? _%value5346%_)
             (let ((__tmp35333
                    (lambda (_%term5348%_)
                      (let ()
                        (declare (not safe))
                        (clan/poo/mop#element?
                         gerbil-ascent/program/types#GerbilAscentTermContract
                         _%term5348%_)))))
               (declare (not safe))
               (andmap__0 __tmp35333 _%value5346%_))
             '#f))))
    (define gerbil-ascent/program/types#GerbilAscentAtomContract
      (let ((__obj35251
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35335
               (list (cons 'sexp
                           (let ((__tmp35336
                                  (lambda (_%@5280%_)
                                    'GerbilAscentAtomContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35336)))
                     (cons 'identity
                           (let ((__tmp35337
                                  (lambda (_%@5286%_) 'ascent/atom)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35337)))
                     (cons 'proto
                           (let ((__tmp35338
                                  (lambda (_%@5291%_)
                                    (let ((__obj35249
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35340 (list))
                                            (__tmp35339 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35340
                                         __tmp35339
                                         __obj35249))
                                      __obj35249))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35338)))
                     (cons 'responsibilities
                           (let ((__tmp35341
                                  (lambda (_%@5305%_)
                                    (let ((__obj35250
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35343
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp35344
                                                                (lambda (_%self5324%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'atom))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35344)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'relation
                                                         (let ((__tmp35345
                                                                (lambda (_%self5331%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35345)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'terms
                                                         (let ((__tmp35346
                                                                (lambda (_%self5336%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+terms+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35346)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp35347
                                                                (lambda (_%self5341%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35347)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35342 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35343
                                         __tmp35342
                                         __obj35250))
                                      __obj35250))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35341)))))
              (__tmp35334 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35335
           __tmp35334
           __obj35251))
        __obj35251))
    (define gerbil-ascent/program/types#+variables+
      (gerbil-ascent/program/types#slot-contract
       'ascent/variables
       (lambda (_%value5265%_)
         (if (list? _%value5265%_)
             (let () (declare (not safe)) (andmap__0 symbol? _%value5265%_))
             '#f))))
    (define gerbil-ascent/program/types#+generator-output+
      (gerbil-ascent/program/types#slot-contract
       'ascent/generator-output
       (lambda (_%value5252%_)
         (let ((_%$e5254%_ (symbol? _%value5252%_)))
           (if _%$e5254%_
               _%$e5254%_
               (if (pair? _%value5252%_)
                   (let _%loop5257%_ ((_%remaining5259%_ _%value5252%_)
                                      (_%seen5260%_ '()))
                     (let ((_%$e5262%_ (null? _%remaining5259%_)))
                       (if _%$e5262%_
                           _%$e5262%_
                           (if (symbol? (car _%remaining5259%_))
                               (if (memq (car _%remaining5259%_) _%seen5260%_)
                                   '#f
                                   (_%loop5257%_
                                    (cdr _%remaining5259%_)
                                    (cons (car _%remaining5259%_)
                                          _%seen5260%_)))
                               '#f))))
                   '#f))))))
    (define gerbil-ascent/program/types#+procedure+
      (gerbil-ascent/program/types#slot-contract 'ascent/procedure procedure?))
    (define gerbil-ascent/program/types#+optional-procedure+
      (gerbil-ascent/program/types#slot-contract
       'ascent/optional-procedure
       (lambda (_%value5247%_)
         (let ((_%$e5249%_ (not _%value5247%_)))
           (if _%$e5249%_ _%$e5249%_ (procedure? _%value5247%_))))))
    (define gerbil-ascent/program/types#+checked-operator+
      (gerbil-ascent/program/types#slot-contract
       'ascent/checked-operator
       (lambda (_%value5242%_)
         (let ((_%$e5244%_ (not _%value5242%_)))
           (if _%$e5244%_ _%$e5244%_ (vector? _%value5242%_))))))
    (define gerbil-ascent/program/types#GerbilAscentGuardContract
      (let ((__obj35254
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35349
               (list (cons 'sexp
                           (let ((__tmp35350
                                  (lambda (_%@5170%_)
                                    'GerbilAscentGuardContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35350)))
                     (cons 'identity
                           (let ((__tmp35351
                                  (lambda (_%@5176%_) 'ascent/guard)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35351)))
                     (cons 'proto
                           (let ((__tmp35352
                                  (lambda (_%@5181%_)
                                    (let ((__obj35252
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35354 (list))
                                            (__tmp35353 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35354
                                         __tmp35353
                                         __obj35252))
                                      __obj35252))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35352)))
                     (cons 'responsibilities
                           (let ((__tmp35355
                                  (lambda (_%@5195%_)
                                    (let ((__obj35253
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35357
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp35358
                                                                (lambda (_%self5215%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'guard))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35358)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variables
                                                         (let ((__tmp35359
                                                                (lambda (_%self5222%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+variables+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35359)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'predicate
                                                         (let ((__tmp35360
                                                                (lambda (_%self5227%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35360)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'checked-operator
                                                         (let ((__tmp35361
                                                                (lambda (_%self5232%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+checked-operator+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35361)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp35362
                                                                (lambda (_%self5237%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35362)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35356 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35357
                                         __tmp35356
                                         __obj35253))
                                      __obj35253))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35355)))))
              (__tmp35348 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35349
           __tmp35348
           __obj35254))
        __obj35254))
    (define gerbil-ascent/program/types#GerbilAscentGeneratorContract
      (let ((__obj35257
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35364
               (list (cons 'sexp
                           (let ((__tmp35365
                                  (lambda (_%@5085%_)
                                    'GerbilAscentGeneratorContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35365)))
                     (cons 'identity
                           (let ((__tmp35366
                                  (lambda (_%@5091%_) 'ascent/generator)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35366)))
                     (cons 'proto
                           (let ((__tmp35367
                                  (lambda (_%@5096%_)
                                    (let ((__obj35255
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35369 (list))
                                            (__tmp35368 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35369
                                         __tmp35368
                                         __obj35255))
                                      __obj35255))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35367)))
                     (cons 'responsibilities
                           (let ((__tmp35370
                                  (lambda (_%@5110%_)
                                    (let ((__obj35256
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35372
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp35373
                                                                (lambda (_%self5130%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'generator))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35373)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variable
                                                         (let ((__tmp35374
                                                                (lambda (_%self5137%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+generator-output+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35374)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variables
                                                         (let ((__tmp35375
                                                                (lambda (_%self5142%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+variables+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35375)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'generate
                                                         (let ((__tmp35376
                                                                (lambda (_%self5147%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35376)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp35377
                                                                (lambda (_%self5152%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35377)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35371 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35372
                                         __tmp35371
                                         __obj35256))
                                      __obj35256))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35370)))))
              (__tmp35363 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35364
           __tmp35363
           __obj35257))
        __obj35257))
    (define gerbil-ascent/program/types#GerbilAscentBindingContract
      (let ((__obj35260
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35379
               (list (cons 'sexp
                           (let ((__tmp35380
                                  (lambda (_%@4994%_)
                                    'GerbilAscentBindingContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35380)))
                     (cons 'identity
                           (let ((__tmp35381
                                  (lambda (_%@5000%_) 'ascent/binding)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35381)))
                     (cons 'proto
                           (let ((__tmp35382
                                  (lambda (_%@5005%_)
                                    (let ((__obj35258
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35384 (list))
                                            (__tmp35383 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35384
                                         __tmp35383
                                         __obj35258))
                                      __obj35258))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35382)))
                     (cons 'responsibilities
                           (let ((__tmp35385
                                  (lambda (_%@5019%_)
                                    (let ((__obj35259
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35387
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp35388
                                                                (lambda (_%self5040%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'binding))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35388)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variable
                                                         (let ((__tmp35389
                                                                (lambda (_%self5047%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35389)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variables
                                                         (let ((__tmp35390
                                                                (lambda (_%self5052%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+variables+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35390)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'checked-operator
                                                         (let ((__tmp35391
                                                                (lambda (_%self5057%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+checked-operator+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35391)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'compute
                                                         (let ((__tmp35392
                                                                (lambda (_%self5062%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35392)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp35393
                                                                (lambda (_%self5067%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35393)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35386 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35387
                                         __tmp35386
                                         __obj35259))
                                      __obj35259))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35385)))))
              (__tmp35378 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35379
           __tmp35378
           __obj35260))
        __obj35260))
    (define gerbil-ascent/program/types#GerbilAscentNegationContract
      (let ((__obj35263
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35395
               (list (cons 'sexp
                           (let ((__tmp35396
                                  (lambda (_%@4915%_)
                                    'GerbilAscentNegationContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35396)))
                     (cons 'identity
                           (let ((__tmp35397
                                  (lambda (_%@4921%_) 'ascent/negation)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35397)))
                     (cons 'proto
                           (let ((__tmp35398
                                  (lambda (_%@4926%_)
                                    (let ((__obj35261
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35400 (list))
                                            (__tmp35399 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35400
                                         __tmp35399
                                         __obj35261))
                                      __obj35261))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35398)))
                     (cons 'responsibilities
                           (let ((__tmp35401
                                  (lambda (_%@4940%_)
                                    (let ((__obj35262
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35403
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp35404
                                                                (lambda (_%self4959%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'negation))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35404)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'relation
                                                         (let ((__tmp35405
                                                                (lambda (_%self4966%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35405)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'terms
                                                         (let ((__tmp35406
                                                                (lambda (_%self4971%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+terms+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35406)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp35407
                                                                (lambda (_%self4976%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35407)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35402 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35403
                                         __tmp35402
                                         __obj35262))
                                      __obj35262))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35401)))))
              (__tmp35394 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35395
           __tmp35394
           __obj35263))
        __obj35263))
    (define gerbil-ascent/program/types#GerbilAscentAggregateContract
      (let ((__obj35266
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35409
               (list (cons 'sexp
                           (let ((__tmp35410
                                  (lambda (_%@4806%_)
                                    'GerbilAscentAggregateContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35410)))
                     (cons 'identity
                           (let ((__tmp35411
                                  (lambda (_%@4812%_) 'ascent/aggregate)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35411)))
                     (cons 'proto
                           (let ((__tmp35412
                                  (lambda (_%@4817%_)
                                    (let ((__obj35264
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35414 (list))
                                            (__tmp35413 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35414
                                         __tmp35413
                                         __obj35264))
                                      __obj35264))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35412)))
                     (cons 'responsibilities
                           (let ((__tmp35415
                                  (lambda (_%@4831%_)
                                    (let ((__obj35265
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35417
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp35418
                                                                (lambda (_%self4855%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'aggregate))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35418)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variable
                                                         (let ((__tmp35419
                                                                (lambda (_%self4862%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+generator-output+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35419)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'relation
                                                         (let ((__tmp35420
                                                                (lambda (_%self4867%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35420)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'terms
                                                         (let ((__tmp35421
                                                                (lambda (_%self4872%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+terms+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35421)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variables
                                                         (let ((__tmp35422
                                                                (lambda (_%self4877%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+variables+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35422)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'aggregate
                                                         (let ((__tmp35423
                                                                (lambda (_%self4882%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35423)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'checked-operator
                                                         (let ((__tmp35424
                                                                (lambda (_%self4887%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+checked-operator+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35424)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'output-pattern
                                                         (let ((__tmp35425
                                                                (lambda (_%self4892%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+optional-procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35425)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp35426
                                                                (lambda (_%self4897%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35426)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35416 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35417
                                         __tmp35416
                                         __obj35265))
                                      __obj35265))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35415)))))
              (__tmp35408 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35409
           __tmp35408
           __obj35266))
        __obj35266))
    (define gerbil-ascent/program/types#+clauses+
      (gerbil-ascent/program/types#slot-contract
       'ascent/clauses
       (lambda (_%value4774%_)
         (if (list? _%value4774%_)
             (let ((__tmp35427
                    (lambda (_%clause4776%_)
                      (let ((_%$e4778%_
                             (let ()
                               (declare (not safe))
                               (clan/poo/mop#element?
                                gerbil-ascent/program/types#GerbilAscentAtomContract
                                _%clause4776%_))))
                        (if _%$e4778%_
                            _%$e4778%_
                            (let ((_%$e4781%_
                                   (let ()
                                     (declare (not safe))
                                     (clan/poo/mop#element?
                                      gerbil-ascent/program/types#GerbilAscentGuardContract
                                      _%clause4776%_))))
                              (if _%$e4781%_
                                  _%$e4781%_
                                  (let ((_%$e4784%_
                                         (let ()
                                           (declare (not safe))
                                           (clan/poo/mop#element?
                                            gerbil-ascent/program/types#GerbilAscentGeneratorContract
                                            _%clause4776%_))))
                                    (if _%$e4784%_
                                        _%$e4784%_
                                        (let ((_%$e4787%_
                                               (let ()
                                                 (declare (not safe))
                                                 (clan/poo/mop#element?
                                                  gerbil-ascent/program/types#GerbilAscentBindingContract
                                                  _%clause4776%_))))
                                          (if _%$e4787%_
                                              _%$e4787%_
                                              (let ((_%$e4790%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (clan/poo/mop#element?
                                                        gerbil-ascent/program/types#GerbilAscentNegationContract
                                                        _%clause4776%_))))
                                                (if _%$e4790%_
                                                    _%$e4790%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (clan/poo/mop#element?
                                                       gerbil-ascent/program/types#GerbilAscentAggregateContract
                                                       _%clause4776%_)))))))))))))))
               (declare (not safe))
               (andmap__0 __tmp35427 _%value4774%_))
             '#f))))
    (define gerbil-ascent/program/types#+heads+
      (gerbil-ascent/program/types#slot-contract
       'ascent/heads
       (lambda (_%value4770%_)
         (if (pair? _%value4770%_)
             (let ((__tmp35428
                    (lambda (_%head4772%_)
                      (let ()
                        (declare (not safe))
                        (clan/poo/mop#element?
                         gerbil-ascent/program/types#GerbilAscentAtomContract
                         _%head4772%_)))))
               (declare (not safe))
               (andmap__0 __tmp35428 _%value4770%_))
             '#f))))
    (define gerbil-ascent/program/types#GerbilAscentRuleContract
      (let ((__obj35269
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35430
               (list (cons 'sexp
                           (let ((__tmp35431
                                  (lambda (_%@4716%_)
                                    'GerbilAscentRuleContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35431)))
                     (cons 'identity
                           (let ((__tmp35432
                                  (lambda (_%@4722%_) 'ascent/rule)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35432)))
                     (cons 'proto
                           (let ((__tmp35433
                                  (lambda (_%@4727%_)
                                    (let ((__obj35267
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35435 (list))
                                            (__tmp35434 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35435
                                         __tmp35434
                                         __obj35267))
                                      __obj35267))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35433)))
                     (cons 'responsibilities
                           (let ((__tmp35436
                                  (lambda (_%@4741%_)
                                    (let ((__obj35268
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35438
                                             (list (cons 'heads
                                                         (let ((__tmp35439
                                                                (lambda (_%self4758%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+heads+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35439)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'body
                                                         (let ((__tmp35440
                                                                (lambda (_%self4765%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+clauses+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35440)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35437 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35438
                                         __tmp35437
                                         __obj35268))
                                      __obj35268))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35436)))))
              (__tmp35429 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35430
           __tmp35429
           __obj35269))
        __obj35269))
    (define gerbil-ascent/program/types#+relations+
      (gerbil-ascent/program/types#slot-contract
       'ascent/relations
       (lambda (_%value4696%_)
         (if (list? _%value4696%_)
             (let ((__tmp35441
                    (lambda (_%relation4698%_)
                      (let ((_%$e4700%_
                             (let ()
                               (declare (not safe))
                               (clan/poo/mop#element?
                                gerbil-ascent/program/types#GerbilAscentRelationContract
                                _%relation4698%_))))
                        (if _%$e4700%_
                            _%$e4700%_
                            (let ()
                              (declare (not safe))
                              (clan/poo/mop#element?
                               gerbil-ascent/program/types#GerbilAscentLatticeContract
                               _%relation4698%_)))))))
               (declare (not safe))
               (andmap__0 __tmp35441 _%value4696%_))
             '#f))))
    (define gerbil-ascent/program/types#+rules+
      (gerbil-ascent/program/types#slot-contract
       'ascent/rules
       (lambda (_%value4692%_)
         (if (list? _%value4692%_)
             (let ((__tmp35442
                    (lambda (_%rule4694%_)
                      (let ()
                        (declare (not safe))
                        (clan/poo/mop#element?
                         gerbil-ascent/program/types#GerbilAscentRuleContract
                         _%rule4694%_)))))
               (declare (not safe))
               (andmap__0 __tmp35442 _%value4692%_))
             '#f))))
    (define gerbil-ascent/program/types#+fragment-exports+
      (gerbil-ascent/program/types#slot-contract
       'ascent/fragment-exports
       procedure?))
    (define gerbil-ascent/program/types#+source-handles+
      (gerbil-ascent/program/types#slot-contract
       'ascent/source-handles
       (lambda (_%value4690%_)
         (if (list? _%value4690%_)
             (let () (declare (not safe)) (andmap__0 symbol? _%value4690%_))
             '#f))))
    (define gerbil-ascent/program/types#GerbilAscentFragmentContract
      (let ((__obj35272
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35444
               (list (cons 'sexp
                           (let ((__tmp35445
                                  (lambda (_%@4624%_)
                                    'GerbilAscentFragmentContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35445)))
                     (cons 'identity
                           (let ((__tmp35446
                                  (lambda (_%@4630%_) 'ascent/fragment)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35446)))
                     (cons 'proto
                           (let ((__tmp35447
                                  (lambda (_%@4635%_)
                                    (let ((__obj35270
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35449 (list))
                                            (__tmp35448 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35449
                                         __tmp35448
                                         __obj35270))
                                      __obj35270))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35447)))
                     (cons 'responsibilities
                           (let ((__tmp35450
                                  (lambda (_%@4649%_)
                                    (let ((__obj35271
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35452
                                             (list (cons 'relations
                                                         (let ((__tmp35453
                                                                (lambda (_%self4668%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+relations+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35453)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'rules
                                                         (let ((__tmp35454
                                                                (lambda (_%self4675%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+rules+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35454)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'exports
                                                         (let ((__tmp35455
                                                                (lambda (_%self4680%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+fragment-exports+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35455)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'source-handles
                                                         (let ((__tmp35456
                                                                (lambda (_%self4685%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+source-handles+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35456)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35451 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35452
                                         __tmp35451
                                         __obj35271))
                                      __obj35271))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35450)))))
              (__tmp35443 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35444
           __tmp35443
           __obj35272))
        __obj35272))
    (define gerbil-ascent/program/types#GerbilAscentProgramContract
      (let ((__obj35275
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35458
               (list (cons 'sexp
                           (let ((__tmp35459
                                  (lambda (_%@4533%_)
                                    'GerbilAscentProgramContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35459)))
                     (cons 'identity
                           (let ((__tmp35460
                                  (lambda (_%@4539%_) 'ascent/program)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35460)))
                     (cons 'proto
                           (let ((__tmp35461
                                  (lambda (_%@4544%_)
                                    (let ((__obj35273
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35463 (list))
                                            (__tmp35462 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35463
                                         __tmp35462
                                         __obj35273))
                                      __obj35273))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35461)))
                     (cons 'responsibilities
                           (let ((__tmp35464
                                  (lambda (_%@4558%_)
                                    (let ((__obj35274
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35466
                                             (list (cons 'relations
                                                         (let ((__tmp35467
                                                                (lambda (_%self4579%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+relations+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35467)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'rules
                                                         (let ((__tmp35468
                                                                (lambda (_%self4586%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+rules+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35468)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'source-handles
                                                         (let ((__tmp35469
                                                                (lambda (_%self4591%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+source-handles+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35469)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'max-input-facts
                                                         (let ((__tmp35470
                                                                (lambda (_%self4596%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+fact-budget+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35470)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'max-derived-facts
                                                         (let ((__tmp35471
                                                                (lambda (_%self4601%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+fact-budget+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35471)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'max-output-facts
                                                         (let ((__tmp35472
                                                                (lambda (_%self4606%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+fact-budget+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35472)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35465 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35466
                                         __tmp35465
                                         __obj35274))
                                      __obj35274))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35464)))))
              (__tmp35457 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35458
           __tmp35457
           __obj35275))
        __obj35275))
    (define gerbil-ascent/program/types#gerbil-ascent-owned-root-contract
      (lambda (_%root4363%_)
        (let* ((_%accepted4365%_
                (let () (declare (not safe)) (make-hash-table-eq)))
               (_%owned-terms4374%_
                (gerbil-ascent/program/types#slot-contract
                 'ascent/terms
                 (lambda (_%value4367%_)
                   (if (list? _%value4367%_)
                       (let ((__tmp35473
                              (lambda (_%term4369%_)
                                (let ((_%$e4371%_
                                       (let ()
                                         (declare (not safe))
                                         (__hash-get
                                          _%accepted4365%_
                                          _%term4369%_))))
                                  (if _%$e4371%_
                                      _%$e4371%_
                                      (if (let ()
                                            (declare (not safe))
                                            (clan/poo/mop#element?
                                             gerbil-ascent/program/types#GerbilAscentTermContract
                                             _%term4369%_))
                                          (begin
                                            (let ()
                                              (declare (not safe))
                                              (__hash-put!
                                               _%accepted4365%_
                                               _%term4369%_
                                               '#t))
                                            '#t)
                                          '#f))))))
                         (declare (not safe))
                         (andmap__0 __tmp35473 _%value4367%_))
                       '#f))))
               (_%owned-atom4412%_
                (let ((__obj35277
                       (let ()
                         (declare (not safe))
                         (##structure
                          clan/poo/object#object::t
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f))))
                  (let ((__tmp35475
                         (list (cons 'responsibilities
                                     (let ((__tmp35476
                                            (lambda (_%@4389%_)
                                              (let ((__obj35276
                                                     (let ()
                                                       (declare (not safe))
                                                       (##structure
                                                        clan/poo/object#object::t
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f))))
                                                (let ((__tmp35480
                                                       (let ()
                                                         (declare (not safe))
                                                         (clan/poo/object#.ref
                                                          gerbil-ascent/program/types#GerbilAscentAtomContract
                                                          'responsibilities)))
                                                      (__tmp35478
                                                       (list (cons 'terms
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ((__tmp35479
                                  (lambda (_%@4406%_) _%owned-terms4374%_)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35479)))))
              (__tmp35477 (list)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (declare (not safe))
                                                  (clan/poo/object#object:::init!__%
                                                   '#f
                                                   __tmp35480
                                                   __tmp35478
                                                   __tmp35477
                                                   __obj35276))
                                                __obj35276))))
                                       (declare (not safe))
                                       (##structure
                                        clan/poo/object#$self-slot-spec::t
                                        __tmp35476)))))
                        (__tmp35474 (list)))
                    (declare (not safe))
                    (clan/poo/object#object:::init!__%
                     '#f
                     gerbil-ascent/program/types#GerbilAscentAtomContract
                     __tmp35475
                     __tmp35474
                     __obj35277))
                  __obj35277))
               (_%owned-heads4420%_
                (gerbil-ascent/program/types#slot-contract
                 'ascent/heads
                 (lambda (_%value4414%_)
                   (if (pair? _%value4414%_)
                       (let ((__tmp35481
                              (lambda (_%$%g44154417%_)
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/mop#element?
                                   _%owned-atom4412%_
                                   _%$%g44154417%_)))))
                         (declare (not safe))
                         (andmap__0 __tmp35481 _%value4414%_))
                       '#f))))
               (_%owned-body4429%_
                (gerbil-ascent/program/types#slot-contract
                 'ascent/clauses
                 (lambda (_%value4422%_)
                   (if (list? _%value4422%_)
                       (let ((__tmp35482
                              (lambda (_%clause4424%_)
                                (let ((_%$e4426%_
                                       (let ()
                                         (declare (not safe))
                                         (clan/poo/mop#element?
                                          _%owned-atom4412%_
                                          _%clause4424%_))))
                                  (if _%$e4426%_
                                      _%$e4426%_
                                      (let ((__tmp35483 (list _%clause4424%_)))
                                        (declare (not safe))
                                        (clan/poo/mop#element?
                                         gerbil-ascent/program/types#+clauses+
                                         __tmp35483)))))))
                         (declare (not safe))
                         (andmap__0 __tmp35482 _%value4422%_))
                       '#f))))
               (_%owned-rule4473%_
                (let ((__obj35279
                       (let ()
                         (declare (not safe))
                         (##structure
                          clan/poo/object#object::t
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f))))
                  (let ((__tmp35485
                         (list (cons 'responsibilities
                                     (let ((__tmp35486
                                            (lambda (_%@4444%_)
                                              (let ((__obj35278
                                                     (let ()
                                                       (declare (not safe))
                                                       (##structure
                                                        clan/poo/object#object::t
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f))))
                                                (let ((__tmp35491
                                                       (let ()
                                                         (declare (not safe))
                                                         (clan/poo/object#.ref
                                                          gerbil-ascent/program/types#GerbilAscentRuleContract
                                                          'responsibilities)))
                                                      (__tmp35488
                                                       (list (cons 'heads
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ((__tmp35489
                                  (lambda (_%@4462%_) _%owned-heads4420%_)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35489)))
                     (cons 'body
                           (let ((__tmp35490
                                  (lambda (_%@4468%_) _%owned-body4429%_)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35490)))))
              (__tmp35487 (list)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (declare (not safe))
                                                  (clan/poo/object#object:::init!__%
                                                   '#f
                                                   __tmp35491
                                                   __tmp35488
                                                   __tmp35487
                                                   __obj35278))
                                                __obj35278))))
                                       (declare (not safe))
                                       (##structure
                                        clan/poo/object#$self-slot-spec::t
                                        __tmp35486)))))
                        (__tmp35484 (list)))
                    (declare (not safe))
                    (clan/poo/object#object:::init!__%
                     '#f
                     gerbil-ascent/program/types#GerbilAscentRuleContract
                     __tmp35485
                     __tmp35484
                     __obj35279))
                  __obj35279))
               (_%owned-rules4481%_
                (gerbil-ascent/program/types#slot-contract
                 'ascent/rules
                 (lambda (_%value4475%_)
                   (if (list? _%value4475%_)
                       (let ((__tmp35492
                              (lambda (_%$%g44764478%_)
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/mop#element?
                                   _%owned-rule4473%_
                                   _%$%g44764478%_)))))
                         (declare (not safe))
                         (andmap__0 __tmp35492 _%value4475%_))
                       '#f))))
               (__obj35281
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
          (let ((__tmp35494
                 (list (cons 'responsibilities
                             (let ((__tmp35495
                                    (lambda (_%@4497%_)
                                      (let ((__obj35280
                                             (let ()
                                               (declare (not safe))
                                               (##structure
                                                clan/poo/object#object::t
                                                '#f
                                                '#f
                                                '#f
                                                '#f
                                                '#f
                                                '#f
                                                '#f))))
                                        (let ((__tmp35499
                                               (let ()
                                                 (declare (not safe))
                                                 (clan/poo/object#.ref
                                                  _%root4363%_
                                                  'responsibilities)))
                                              (__tmp35497
                                               (list (cons 'rules
                                                           (let ((__tmp35498
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (lambda (_%@4514%_) _%owned-rules4481%_)))
                     (declare (not safe))
                     (##structure
                      clan/poo/object#$self-slot-spec::t
                      __tmp35498)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (__tmp35496 (list)))
                                          (declare (not safe))
                                          (clan/poo/object#object:::init!__%
                                           '#f
                                           __tmp35499
                                           __tmp35497
                                           __tmp35496
                                           __obj35280))
                                        __obj35280))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp35495)))))
                (__tmp35493 (list)))
            (declare (not safe))
            (clan/poo/object#object:::init!__%
             '#f
             _%root4363%_
             __tmp35494
             __tmp35493
             __obj35281))
          __obj35281)))
    (define gerbil-ascent/program/types#GerbilAscentSessionContract
      (let ((__obj35284
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35501
               (list (cons 'sexp
                           (let ((__tmp35502
                                  (lambda (_%@4303%_)
                                    'GerbilAscentSessionContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35502)))
                     (cons 'identity
                           (let ((__tmp35503
                                  (lambda (_%@4309%_) 'ascent/session)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35503)))
                     (cons 'proto
                           (let ((__tmp35504
                                  (lambda (_%@4314%_)
                                    (let ((__obj35282
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35506 (list))
                                            (__tmp35505 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35506
                                         __tmp35505
                                         __obj35282))
                                      __obj35282))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35504)))
                     (cons 'responsibilities
                           (let ((__tmp35507
                                  (lambda (_%@4328%_)
                                    (let ((__obj35283
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35509
                                             (list (cons '.append-source!
                                                         (let ((__tmp35510
                                                                (lambda (_%self4346%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35510)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.replace-source!
                                                         (let ((__tmp35511
                                                                (lambda (_%self4353%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35511)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.run
                                                         (let ((__tmp35512
                                                                (lambda (_%self4358%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35512)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35508 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35509
                                         __tmp35508
                                         __obj35283))
                                      __obj35283))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35507)))))
              (__tmp35500 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35501
           __tmp35500
           __obj35284))
        __obj35284))))
