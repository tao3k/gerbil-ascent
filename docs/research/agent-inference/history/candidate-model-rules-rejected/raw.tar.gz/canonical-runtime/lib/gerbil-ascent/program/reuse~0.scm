(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/reuse::timestamp 1791687886)
  (begin
    (define gerbil-ascent/program/reuse#native-reuse::t
      (let ((__tmp37049 (list)) (__tmp37048 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/reuse#native-reuse::t
         'native-reuse
         __tmp37049
         '(result affected reader publication source-only)
         __tmp37048
         '#f)))
    (define gerbil-ascent/program/reuse#native-reuse?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/program/reuse#native-reuse::t)))
    (define gerbil-ascent/program/reuse#make-native-reuse
      (lambda _%$args14172%_
        (apply make-instance
               gerbil-ascent/program/reuse#native-reuse::t
               _%$args14172%_)))
    (define gerbil-ascent/program/reuse#native-reuse-result
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'result)))
    (define gerbil-ascent/program/reuse#native-reuse-affected
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'affected)))
    (define gerbil-ascent/program/reuse#native-reuse-reader
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'reader)))
    (define gerbil-ascent/program/reuse#native-reuse-publication
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'publication)))
    (define gerbil-ascent/program/reuse#native-reuse-source-only
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'source-only)))
    (define gerbil-ascent/program/reuse#native-reuse-result-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'result)))
    (define gerbil-ascent/program/reuse#native-reuse-affected-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'affected)))
    (define gerbil-ascent/program/reuse#native-reuse-reader-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'reader)))
    (define gerbil-ascent/program/reuse#native-reuse-publication-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'publication)))
    (define gerbil-ascent/program/reuse#native-reuse-source-only-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'source-only)))
    (define gerbil-ascent/program/reuse#&native-reuse-result
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'result)))
    (define gerbil-ascent/program/reuse#&native-reuse-affected
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'affected)))
    (define gerbil-ascent/program/reuse#&native-reuse-reader
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'reader)))
    (define gerbil-ascent/program/reuse#&native-reuse-publication
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'publication)))
    (define gerbil-ascent/program/reuse#&native-reuse-source-only
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'source-only)))
    (define gerbil-ascent/program/reuse#&native-reuse-result-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'result)))
    (define gerbil-ascent/program/reuse#&native-reuse-affected-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'affected)))
    (define gerbil-ascent/program/reuse#&native-reuse-reader-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'reader)))
    (define gerbil-ascent/program/reuse#&native-reuse-publication-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'publication)))
    (define gerbil-ascent/program/reuse#&native-reuse-source-only-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'source-only)))
    (define gerbil-ascent/program/reuse#source-only-relations
      (lambda (_%analysis14163%_ _%count14164%_)
        (let ((_%source-only14166%_ (make-vector _%count14164%_ '#t)))
          (for-each
           (lambda (_%rule14168%_)
             (for-each
              (lambda (_%head14170%_)
                (vector-set!
                 _%source-only14166%_
                 (vector-ref _%head14170%_ '0)
                 '#f))
              (vector-ref _%rule14168%_ '0)))
           (vector-ref _%analysis14163%_ '2))
          _%source-only14166%_)))
    (define gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__%
      (lambda (_%previous14124%_
               _%candidate14125%_
               _%completed14126%_
               _%analysis14127%_
               _%source-cut14128%_
               _%publication14129%_)
        (if (let ()
              (declare (not safe))
              (clan/poo/object#.ref _%completed14126%_ 'finished))
            '#!void
            (let ()
              (declare (not safe))
              (error '"cannot reuse a partial closure")))
        (let ((_%$%affected1413014132%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/program/update-selection#gerbil-ascent-update-selection__%
                  _%previous14124%_
                  _%candidate14125%_
                  _%analysis14127%_
                  _%source-cut14128%_))))
          (if _%$%affected1413014132%_
              (let ((_%affected14134%_ _%$%affected1413014132%_))
                (let ((__tmp37051
                       (let ()
                         (declare (not safe))
                         (gerbil-ascent/program/result#gerbil-ascent-publication-reader
                          _%publication14129%_
                          _%completed14126%_)))
                      (__tmp37050
                       (gerbil-ascent/program/reuse#source-only-relations
                        _%analysis14127%_
                        (vector-length _%previous14124%_))))
                  (declare (not safe))
                  (##structure
                   gerbil-ascent/program/reuse#native-reuse::t
                   _%completed14126%_
                   _%affected14134%_
                   __tmp37051
                   _%publication14129%_
                   __tmp37050)))
              '#f))))
    (define gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__0
      (lambda (_%previous14139%_
               _%candidate14140%_
               _%completed14141%_
               _%analysis14142%_)
        (let* ((_%source-cut14144%_ '#f) (_%publication14146%_ '#f))
          (gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__%
           _%previous14139%_
           _%candidate14140%_
           _%completed14141%_
           _%analysis14142%_
           _%source-cut14144%_
           _%publication14146%_))))
    (define gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__1
      (lambda (_%previous14148%_
               _%candidate14149%_
               _%completed14150%_
               _%analysis14151%_
               _%source-cut14152%_)
        (let ((_%publication14154%_ '#f))
          (gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__%
           _%previous14148%_
           _%candidate14149%_
           _%completed14150%_
           _%analysis14151%_
           _%source-cut14152%_
           _%publication14154%_))))
    (define gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse
      (lambda _g37052_
        (let ((_g37053_ (let () (declare (not safe)) (##length _g37052_))))
          (cond ((let () (declare (not safe)) (##fx= _g37053_ 4))
                 (apply gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__0
                        _g37052_))
                ((let () (declare (not safe)) (##fx= _g37053_ 5))
                 (apply gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__1
                        _g37052_))
                ((let () (declare (not safe)) (##fx= _g37053_ 6))
                 (apply gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__%
                        _g37052_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse
                  _g37052_))))))
    (define gerbil-ascent/program/reuse#gerbil-ascent-activate-rules
      (lambda (_%x14116%_)
        (let ((__tmp37054 (vector-ref _%x14116%_ '5)))
          (declare (not safe))
          (gerbil-ascent/program/activation#gerbil-ascent-activate-plans
           __tmp37054))))
    (define gerbil-ascent/program/reuse#gerbil-ascent-activate-selected-rules
      (lambda (_%analysis14113%_ _%affected14114%_)
        (let ((__tmp37055
               (let ((__tmp37056 (vector-ref _%analysis14113%_ '5)))
                 (declare (not safe))
                 (gerbil-ascent/program/update-selection#gerbil-ascent-select-rule-plans
                  __tmp37056
                  _%affected14114%_))))
          (declare (not safe))
          (gerbil-ascent/program/activation#gerbil-ascent-activate-plans
           __tmp37055))))
    (define gerbil-ascent/program/reuse#gerbil-ascent-reuse-active-rules
      (lambda (_%full-active-by-stratum14103%_ _%reuse14104%_)
        (if _%reuse14104%_
            (let* ((_%reuse14106%_ _%reuse14104%_)
                   (__tmp37057
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-ref _%reuse14106%_ '2 '#f '#f))))
              (declare (not safe))
              (gerbil-ascent/program/update-selection#gerbil-ascent-update-active-plans
               _%full-active-by-stratum14103%_
               __tmp37057))
            _%full-active-by-stratum14103%_)))
    (define gerbil-ascent/program/reuse#closure-seed-state::t
      (let ((__tmp37059 (list)) (__tmp37058 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/reuse#closure-seed-state::t
         'closure-seed-state
         __tmp37059
         '(all seen delta all-size delta-size lattice-rows)
         __tmp37058
         '#f)))
    (define gerbil-ascent/program/reuse#closure-seed-state?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/reuse#closure-seed-state::t)))
    (define gerbil-ascent/program/reuse#make-closure-seed-state
      (lambda _%$args14100%_
        (apply make-instance
               gerbil-ascent/program/reuse#closure-seed-state::t
               _%$args14100%_)))
    (define gerbil-ascent/program/reuse#closure-seed-state-all
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'all)))
    (define gerbil-ascent/program/reuse#closure-seed-state-seen
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'seen)))
    (define gerbil-ascent/program/reuse#closure-seed-state-delta
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'delta)))
    (define gerbil-ascent/program/reuse#closure-seed-state-all-size
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'all-size)))
    (define gerbil-ascent/program/reuse#closure-seed-state-delta-size
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'delta-size)))
    (define gerbil-ascent/program/reuse#closure-seed-state-lattice-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'lattice-rows)))
    (define gerbil-ascent/program/reuse#closure-seed-state-all-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'all)))
    (define gerbil-ascent/program/reuse#closure-seed-state-seen-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'seen)))
    (define gerbil-ascent/program/reuse#closure-seed-state-delta-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'delta)))
    (define gerbil-ascent/program/reuse#closure-seed-state-all-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'all-size)))
    (define gerbil-ascent/program/reuse#closure-seed-state-delta-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'delta-size)))
    (define gerbil-ascent/program/reuse#closure-seed-state-lattice-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'lattice-rows)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-all
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'all)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-seen
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'seen)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-delta
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'delta)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-all-size
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'all-size)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-delta-size
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'delta-size)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-lattice-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'lattice-rows)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-all-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'all)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-seen-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'seen)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-delta-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'delta)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-all-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'all-size)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-delta-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'delta-size)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-lattice-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'lattice-rows)))
    (define gerbil-ascent/program/reuse#gerbil-ascent-seed-native-reuse!
      (lambda (_%reuse14049%_
               _%schema14050%_
               _%buffers14051%_
               _%source-materialized-count14052%_
               _%derived-limit14053%_
               _%output-limit14054%_)
        (let ((_%names14056%_ (vector-ref _%schema14050%_ '1))
              (_%arity14057%_ (vector-ref _%schema14050%_ '2))
              (_%field-checkers14058%_ (vector-ref _%schema14050%_ '3))
              (_%lattice-joins14059%_ (vector-ref _%schema14050%_ '7))
              (_%all14060%_
               (##structure-ref
                _%buffers14051%_
                '1
                gerbil-ascent/program/reuse#closure-seed-state::t
                '#f))
              (_%seen14061%_
               (##structure-ref
                _%buffers14051%_
                '2
                gerbil-ascent/program/reuse#closure-seed-state::t
                '#f))
              (_%delta14062%_
               (##structure-ref
                _%buffers14051%_
                '3
                gerbil-ascent/program/reuse#closure-seed-state::t
                '#f))
              (_%all-size14063%_
               (##structure-ref
                _%buffers14051%_
                '4
                gerbil-ascent/program/reuse#closure-seed-state::t
                '#f))
              (_%delta-size14064%_
               (##structure-ref
                _%buffers14051%_
                '5
                gerbil-ascent/program/reuse#closure-seed-state::t
                '#f))
              (_%lattice-rows14065%_
               (##structure-ref
                _%buffers14051%_
                '6
                gerbil-ascent/program/reuse#closure-seed-state::t
                '#f))
              (_%count14066%_ (vector-length (vector-ref _%schema14050%_ '1)))
              (_%derived-count14067%_ '0))
          (if _%reuse14049%_
              (begin
                (if (let ()
                      (declare (not safe))
                      (##structure-instance-of?
                       _%reuse14049%_
                       'gerbil-ascent/program/reuse#native-reuse::t))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"invalid native reuse capsule")))
                (let _%seed14069%_ ((_%index14071%_ '0))
                  (if (< _%index14071%_ _%count14066%_)
                      (begin
                        (if (vector-ref
                             (##structure-ref
                              _%reuse14049%_
                              '2
                              gerbil-ascent/program/reuse#native-reuse::t
                              '#f)
                             _%index14071%_)
                            '#!void
                            (if (if (vector-ref
                                     _%lattice-joins14059%_
                                     _%index14071%_)
                                    '#f
                                    (and (vector-ref
                                          (##structure-ref
                                           _%reuse14049%_
                                           '5
                                           gerbil-ascent/program/reuse#native-reuse::t
                                           '#f)
                                          _%index14071%_)
                                         (eqv? (vector-ref
                                                _%all-size14063%_
                                                _%index14071%_)
                                               (let ((__tmp37062
                                                      (##structure-ref
                                                       _%reuse14049%_
                                                       '4
                                                       gerbil-ascent/program/reuse#native-reuse::t
                                                       '#f))
                                                     (__tmp37061
                                                      (##structure-ref
                                                       _%reuse14049%_
                                                       '1
                                                       gerbil-ascent/program/reuse#native-reuse::t
                                                       '#f))
                                                     (__tmp37060
                                                      (vector-ref
                                                       _%names14056%_
                                                       _%index14071%_)))
                                                 (declare (not safe))
                                                 (gerbil-ascent/program/result#gerbil-ascent-publication-size
                                                  __tmp37062
                                                  __tmp37061
                                                  __tmp37060)))))
                                '#!void
                                (let* ((_%rows14076%_
                                        ((let ((_%$e14073%_
                                                (##structure-ref
                                                 _%reuse14049%_
                                                 '3
                                                 gerbil-ascent/program/reuse#native-reuse::t
                                                 '#f)))
                                           (if _%$e14073%_
                                               _%$e14073%_
                                               (let ((__tmp37063
                                                      (##structure-ref
                                                       _%reuse14049%_
                                                       '1
                                                       gerbil-ascent/program/reuse#native-reuse::t
                                                       '#f)))
                                                 (declare (not safe))
                                                 (clan/poo/object#.ref
                                                  __tmp37063
                                                  'rows-of))))
                                         (vector-ref
                                          _%names14056%_
                                          _%index14071%_)))
                                       (_%base14078%_
                                        (vector-ref
                                         _%all14060%_
                                         _%index14071%_))
                                       (_%check14080%_
                                        (vector-ref
                                         _%field-checkers14058%_
                                         _%index14071%_))
                                       (_%base-present14086%_
                                        (if _%check14080%_
                                            '#f
                                            (if (vector-ref
                                                 _%lattice-joins14059%_
                                                 _%index14071%_)
                                                (let ((_%membership14082%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (make-hash-table__%
                                                          '#f
                                                          absent-value
                                                          absent-value
                                                          absent-value
                                                          absent-value
                                                          absent-value
                                                          absent-value
                                                          absent-value
                                                          absent-value))))
                                                  (for-each
                                                   (lambda (_%row14084%_)
                                                     (let ()
                                                       (declare (not safe))
                                                       (__hash-put!
                                                        _%membership14082%_
                                                        _%row14084%_
                                                        '#t)))
                                                   _%base14078%_)
                                                  _%membership14082%_)
                                                (vector-ref
                                                 _%seen14061%_
                                                 _%index14071%_))))
                                       (_%present14088%_
                                        (let ()
                                          (declare (not safe))
                                          (make-hash-table__%
                                           '#f
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value))))
                                  (for-each
                                   (lambda (_%row14091%_)
                                     (if (and (list? _%row14091%_)
                                              (= (let ()
                                                   (declare (not safe))
                                                   (##length _%row14091%_))
                                                 (vector-ref
                                                  _%arity14057%_
                                                  _%index14071%_)))
                                         '#!void
                                         (let ()
                                           (declare (not safe))
                                           (error '"invalid completed reuse row")))
                                     (if _%check14080%_
                                         (_%check14080%_ _%row14091%_)
                                         '#!void)
                                     (if (let ()
                                           (declare (not safe))
                                           (__hash-get
                                            _%present14088%_
                                            _%row14091%_))
                                         '#!void
                                         (begin
                                           (let ()
                                             (declare (not safe))
                                             (__hash-put!
                                              _%present14088%_
                                              _%row14091%_
                                              '#t))
                                           (if (if _%base-present14086%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (hash-get
                                                      _%base-present14086%_
                                                      _%row14091%_))
                                                   (member _%row14091%_
                                                           _%base14078%_))
                                               '#!void
                                               (set! _%derived-count14067%_
                                                     (+ _%derived-count14067%_
                                                        '1))))))
                                   _%rows14076%_)
                                  (if (or (> _%derived-count14067%_
                                             _%derived-limit14053%_)
                                          (> (+ _%source-materialized-count14052%_
                                                _%derived-count14067%_)
                                             _%output-limit14054%_))
                                      (let ()
                                        (declare (not safe))
                                        (error '"ASCENT reused closure fact budget exceeded"))
                                      '#!void)
                                  (if (vector-ref
                                       _%lattice-joins14059%_
                                       _%index14071%_)
                                      (let ((_%keyed14096%_
                                             (let ()
                                               (declare (not safe))
                                               (make-hash-table__%
                                                '#f
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value))))
                                        (for-each
                                         (lambda (_%row14098%_)
                                           (let ((__tmp37064
                                                  (let ()
                                                    (declare (not safe))
                                                    (gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-key
                                                     _%row14098%_))))
                                             (declare (not safe))
                                             (__hash-put!
                                              _%keyed14096%_
                                              __tmp37064
                                              _%row14098%_)))
                                         _%rows14076%_)
                                        (vector-set!
                                         _%lattice-rows14065%_
                                         _%index14071%_
                                         _%keyed14096%_))
                                      '#!void)
                                  (vector-set!
                                   _%all14060%_
                                   _%index14071%_
                                   (reverse _%rows14076%_))
                                  (vector-set!
                                   _%seen14061%_
                                   _%index14071%_
                                   _%present14088%_)
                                  (vector-set!
                                   _%delta14062%_
                                   _%index14071%_
                                   (vector-ref _%all14060%_ _%index14071%_))
                                  (vector-set!
                                   _%all-size14063%_
                                   _%index14071%_
                                   (length _%rows14076%_))
                                  (vector-set!
                                   _%delta-size14064%_
                                   _%index14071%_
                                   (length _%rows14076%_)))))
                        (_%seed14069%_ (+ _%index14071%_ '1)))
                      '#!void)))
              '#!void)
          _%derived-count14067%_)))))
