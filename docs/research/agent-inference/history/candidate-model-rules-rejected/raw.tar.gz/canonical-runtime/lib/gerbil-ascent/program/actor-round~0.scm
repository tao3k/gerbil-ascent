(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/actor-round::timestamp 1791687880)
  (begin
    (define gerbil-ascent/program/actor-round#gerbil-ascent-actor-round-eligible?
      (lambda (_%rules17770%_
               _%storages17771%_
               _%indexes17772%_
               _%joins17773%_
               _%fields17774%_)
        (if (let ((__tmp35857
                   (lambda (_%rule17776%_)
                     (let ((__tmp35858 (vector-ref _%rule17776%_ '5)))
                       (declare (not safe))
                       (gerbil-ascent/core/positive-plan#gerbil-ascent-pure-positive-plan?
                        __tmp35858)))))
              (declare (not safe))
              (andmap__0 __tmp35857 _%rules17770%_))
            (if (let ((__tmp35860
                       (lambda (_%provider17778%_)
                         (or (let ()
                               (declare (not safe))
                               (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                                _%provider17778%_))
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/table/storage#gerbil-ascent-canonical-view-storage-provider?
                                _%provider17778%_)))))
                      (__tmp35859 (vector->list _%storages17771%_)))
                  (declare (not safe))
                  (andmap__0 __tmp35860 __tmp35859))
                (if (let ((__tmp35861 (vector->list _%indexes17772%_)))
                      (declare (not safe))
                      (andmap__0
                       gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                       __tmp35861))
                    (if (let ((__tmp35862 (vector->list _%joins17773%_)))
                          (declare (not safe))
                          (andmap__0 not __tmp35862))
                        (let ((__tmp35863 (vector->list _%fields17774%_)))
                          (declare (not safe))
                          (andmap__0 not __tmp35863))
                        '#f)
                    '#f)
                '#f)
            '#f)))
    (define gerbil-ascent/program/actor-round#run-task
      (lambda (_%owner17743%_ _%key17744%_ _%task17745%_ _%execute17746%_)
        (let ((__tmp35864
               (lambda (_%stop17748%_)
                 (let ((__tmp35866
                        (lambda (_%exception17750%_)
                          (_%stop17748%_ (cons 'failed _%exception17750%_))))
                       (__tmp35865
                        (lambda ()
                          (let ((_%batch17753%_ '())
                                (_%size17754%_ '0)
                                (_%ticks17755%_ '0))
                            (letrec ((_%request!17757%_
                                      (lambda (_%kind17767%_ _%payload17768%_)
                                        (thread-send
                                         _%owner17743%_
                                         (cons _%kind17767%_
                                               (cons _%key17744%_
                                                     (cons (current-thread)
                                                           (cons _%task17745%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (cons _%payload17768%_ '()))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        (if (eq? (thread-receive) 'credit)
                                            '#!void
                                            (_%stop17748%_ 'stopped))))
                                     (_%flush!17758%_
                                      (lambda ()
                                        (if (zero? _%size17754%_)
                                            '#!void
                                            (begin
                                              (_%request!17757%_
                                               'batch
                                               (let ()
                                                 (declare (not safe))
                                                 (##reverse _%batch17753%_)))
                                              (set! _%ticks17755%_ '0)
                                              (set! _%batch17753%_ '())
                                              (set! _%size17754%_ '0)))))
                                     (_%emit!17759%_
                                      (lambda (_%atom17763%_ _%row17764%_)
                                        (set! _%batch17753%_
                                              (cons (cons _%atom17763%_
                                                          _%row17764%_)
                                                    _%batch17753%_))
                                        (set! _%size17754%_
                                              (+ _%size17754%_ '1))
                                        (if (= _%size17754%_ '32)
                                            (_%flush!17758%_)
                                            '#!void)))
                                     (_%checkpoint!17760%_
                                      (lambda ()
                                        (set! _%ticks17755%_
                                              (+ _%ticks17755%_ '1))
                                        (if (= _%ticks17755%_ '64)
                                            (begin
                                              (set! _%ticks17755%_ '0)
                                              (_%request!17757%_
                                               'checkpoint
                                               '#f))
                                            '#!void))))
                              (_%execute17746%_
                               _%task17745%_
                               _%emit!17759%_
                               _%checkpoint!17760%_)
                              (cons 'finished
                                    (let ()
                                      (declare (not safe))
                                      (##reverse _%batch17753%_))))))))
                   (declare (not safe))
                   (__with-exception-handler __tmp35866 __tmp35865)))))
          (declare (not safe))
          (##call-with-current-continuation __tmp35864))))
    (define gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__%
      (lambda (_%key17471%_
               _%tasks17472%_
               _%jobs17473%_
               _%execute17474%_
               _%merge17475%_
               _%canceled?17476%_
               _%ready?17477%_
               _%completed!17478%_)
        (if (and (exact-integer? _%jobs17473%_) (> _%jobs17473%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT worker capacity" _%jobs17473%_)))
        (let ((_%result17685%_
               (thread-join!
                (let ((__tmp35867
                       (lambda ()
                         (let ((__tmp35882
                                (lambda (_%exception17481%_)
                                  (cons 'failed _%exception17481%_)))
                               (__tmp35868
                                (lambda ()
                                  (let ((_%owner17484%_ (current-thread))
                                        (_%pending17485%_
                                         (cons '#f
                                               (map values _%tasks17472%_)))
                                        (_%assigned17486%_
                                         (let ()
                                           (declare (not safe))
                                           (make-hash-table-eq)))
                                        (_%active17487%_
                                         (let ()
                                           (declare (not safe))
                                           (make-hash-table-eq)))
                                        (_%active-count17488%_ '0)
                                        (_%workers17489%_ '())
                                        (_%idle17490%_ '())
                                        (_%awaiting17491%_ '#f)
                                        (_%failed?17492%_ '#f)
                                        (_%failure17493%_ '#f))
                                    (letrec ((_%stop!17495%_
                                              (lambda (_%exception17683%_)
                                                (if _%failed?17492%_
                                                    '#!void
                                                    (begin
                                                      (set! _%failure17493%_
                                                            _%exception17683%_)
                                                      (set! _%failed?17492%_
                                                            '#t)))
                                                (let ()
                                                  (declare (not safe))
                                                  (##set-cdr!
                                                   _%pending17485%_
                                                   '()))))
                                             (_%take-ready!17496%_
                                              (lambda ()
                                                (let _%scan17672%_ ((_%previous17674%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             _%pending17485%_)
                            (_%rest17675%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%pending17485%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (null? _%rest17675%_)
                                                      '#f
                                                      (if (let ((__tmp35869
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (car _%rest17675%_)))
                    (declare (not safe))
                    (__hash-get _%assigned17486%_ __tmp35869))
                  (let ()
                    (set-cdr! _%previous17674%_ (cdr _%rest17675%_))
                    (_%scan17672%_ _%previous17674%_ (cdr _%rest17675%_)))
                  (if (_%ready?17477%_ (car _%rest17675%_))
                      (let ((_%task17680%_ (car _%rest17675%_)))
                        (if _%task17680%_
                            (begin
                              (set-cdr! _%previous17674%_ (cdr _%rest17675%_))
                              (let ()
                                (declare (not safe))
                                (__hash-put!
                                 _%assigned17486%_
                                 _%task17680%_
                                 '#t)))
                            '#!void)
                        _%task17680%_)
                      (_%scan17672%_ _%rest17675%_ (cdr _%rest17675%_))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%make-worker!17497%_
                                              (lambda ()
                                                (let* ((_%worker17660%_
                                                        (let ((__tmp35870
                                                               (lambda ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let _%loop17613%_ ()
                           (let* ((_%$%g1761517626%_ (thread-receive))
                                  (_%$%E1761817630%_
                                   (lambda ()
                                     (let ()
                                       (declare (not safe))
                                       (error '"No clause matching"
                                              _%$%g1761517626%_
                                              '(['task task])
                                              '('stop)))
                                     '#!void)))
                             (let ((_%$%K1762017645%_
                                    (lambda (_%task17641%_)
                                      (let* ((_%result17643%_
                                              (gerbil-ascent/program/actor-round#run-task
                                               _%owner17484%_
                                               _%key17471%_
                                               _%task17641%_
                                               _%execute17474%_))
                                             (__tmp35871
                                              (cons 'done
                                                    (cons _%key17471%_
                                                          (cons (current-thread)
                                                                (cons _%task17641%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%result17643%_ '())))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        (declare (not safe))
                                        (##thread-send
                                         _%owner17484%_
                                         __tmp35871))
                                      (_%loop17613%_)))
                                   (_%$%K1761917635%_ (lambda () 'finished)))
                               (let ((_%$%try-match1761717638%_
                                      (lambda ()
                                        (if (let ()
                                              (declare (not safe))
                                              (##eq? _%$%g1761517626%_ 'stop))
                                            (_%$%K1761917635%_)
                                            (_%$%E1761817630%_)))))
                                 (if (pair? _%$%g1761517626%_)
                                     (let ((_%$%tl1762217650%_
                                            (let ()
                                              (declare (not safe))
                                              (##cdr _%$%g1761517626%_)))
                                           (_%$%hd1762117648%_
                                            (let ()
                                              (declare (not safe))
                                              (##car _%$%g1761517626%_))))
                                       (if (let ()
                                             (declare (not safe))
                                             (##eq? _%$%hd1762117648%_ 'task))
                                           (if (pair? _%$%tl1762217650%_)
                                               (let ((_%$%tl1762417655%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (##cdr _%$%tl1762217650%_)))
                                                     (_%$%hd1762317653%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (##car _%$%tl1762217650%_))))
                                                 (if (null? _%$%tl1762417655%_)
                                                     (let ((_%task17658%_
                                                            _%$%hd1762317653%_))
                                                       (_%$%K1762017645%_
                                                        _%task17658%_))
                                                     (_%$%try-match1761717638%_)))
                                               (_%$%try-match1761717638%_))
                                           (_%$%try-match1761717638%_)))
                                     (_%$%try-match1761717638%_)))))))))
                  (declare (not safe))
                  (__spawn/name 'ascent-round-worker __tmp35870)))
               (_%monitor17668%_
                (let ((__tmp35872
                       (lambda ()
                         (let* ((_%result17666%_
                                 (let ((__tmp35874
                                        (lambda (_%exception17663%_)
                                          (cons 'failed _%exception17663%_)))
                                       (__tmp35873
                                        (lambda ()
                                          (thread-join! _%worker17660%_))))
                                   (declare (not safe))
                                   (__with-catch __tmp35874 __tmp35873)))
                                (__tmp35875
                                 (cons 'exited
                                       (cons _%key17471%_
                                             (cons _%worker17660%_
                                                   (cons '#f
                                                         (cons _%result17666%_
                                                               '())))))))
                           (declare (not safe))
                           (##thread-send _%owner17484%_ __tmp35875)))))
                  (declare (not safe))
                  (__spawn/name 'ascent-round-monitor __tmp35872))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (set! _%workers17489%_
                                                        (cons (cons _%worker17660%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%monitor17668%_)
                      _%workers17489%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  _%worker17660%_)))
                                             (_%start!17498%_
                                              (lambda (_%task17605%_)
                                                (let ((_%worker17609%_
                                                       (if (pair? _%idle17490%_)
                                                           (let ((_%worker17607%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (car _%idle17490%_)))
                     (set! _%idle17490%_ (cdr _%idle17490%_))
                     _%worker17607%_)
                   (_%make-worker!17497%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (let ()
                                                    (declare (not safe))
                                                    (__hash-put!
                                                     _%active17487%_
                                                     _%worker17609%_
                                                     _%task17605%_))
                                                  (set! _%active-count17488%_
                                                        (+ _%active-count17488%_
                                                           '1))
                                                  (thread-send
                                                   _%worker17609%_
                                                   (cons 'task
                                                         (cons _%task17605%_
                                                               '()))))))
                                             (_%run!17499%_
                                              (lambda ()
                                                (let ((__tmp35877
                                                       (lambda (_%exception17510%_)
                                                         (_%stop!17495%_
                                                          _%exception17510%_)
                                                         (if _%awaiting17491%_
                                                             (begin
                                                               (thread-send
                                                                _%awaiting17491%_
                                                                'stop)
                                                               (set! _%awaiting17491%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             '#f))
                     '#!void)
                 (_%run!17499%_)))
              (__tmp35876
               (lambda ()
                 (let _%loop17513%_ ()
                   (if _%failed?17492%_
                       '#!void
                       (begin
                         (if (_%canceled?17476%_)
                             (let ()
                               (declare (not safe))
                               (error '"ASCENT actor round canceled"))
                             '#!void)
                         (let _%admit17516%_ ()
                           (if (and (pair? (let ()
                                             (declare (not safe))
                                             (##cdr _%pending17485%_)))
                                    (< _%active-count17488%_ _%jobs17473%_))
                               (let ((_%task17519%_ (_%take-ready!17496%_)))
                                 (if _%task17519%_
                                     (begin
                                       (_%start!17498%_ _%task17519%_)
                                       (_%admit17516%_))
                                     '#!void))
                               '#!void))))
                   (if (zero? _%active-count17488%_)
                       '#!void
                       (begin
                         (let* ((_%$%g1752017536%_ (thread-receive))
                                (_%$%else1752217544%_ (lambda () '#!void))
                                (_%$%K1752417567%_
                                 (lambda (_%payload17547%_
                                          _%task17548%_
                                          _%worker17549%_
                                          _%received-key17550%_
                                          _%kind17551%_)
                                   (if (eq? _%received-key17550%_ _%key17471%_)
                                       (let ((_%assignment17553%_
                                              (let ()
                                                (declare (not safe))
                                                (__hash-get
                                                 _%active17487%_
                                                 _%worker17549%_))))
                                         (if (eq? _%kind17551%_ 'exited)
                                             (let ()
                                               (if _%assignment17553%_
                                                   (begin
                                                     (let ()
                                                       (declare (not safe))
                                                       (__hash-remove!
                                                        _%active17487%_
                                                        _%worker17549%_))
                                                     (set! _%active-count17488%_
                                                           (- _%active-count17488%_
                                                              '1)))
                                                   '#!void)
                                               (if (and (pair? _%payload17547%_)
                                                        (eq? (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##car _%payload17547%_))
                     'failed))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (_%stop!17495%_
                                                    (cdr _%payload17547%_))
                                                   (let ()
                                                     (declare (not safe))
                                                     (error '"ASCENT worker exited before pool shutdown"))))
                                             (if (and _%assignment17553%_
                                                      (eq? _%task17548%_
                                                           _%assignment17553%_))
                                                 (let ((_%$e17557%_
                                                        _%kind17551%_))
                                                   (if (or (eq? 'batch
                                                                _%$e17557%_)
                                                           (eq? 'checkpoint
                                                                _%$e17557%_))
                                                       (begin
                                                         (set! _%awaiting17491%_
                                                               _%worker17549%_)
                                                         (if _%failed?17492%_
                                                             '#!void
                                                             (begin
                                                               (if (_%canceled?17476%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ()
                             (declare (not safe))
                             (error '"ASCENT actor round canceled"))
                           '#!void)
                       (if (eq? _%kind17551%_ 'batch)
                           (for-each
                            (lambda (_%candidate17563%_)
                              (_%merge17475%_
                               (car _%candidate17563%_)
                               (cdr _%candidate17563%_)))
                            _%payload17547%_)
                           '#!void)))
                 (thread-send
                  _%worker17549%_
                  (if _%failed?17492%_ 'stop 'credit))
                 (set! _%awaiting17491%_ '#f))
               (if (eq? 'done _%$e17557%_)
                   (begin
                     (let ()
                       (declare (not safe))
                       (__hash-remove! _%active17487%_ _%worker17549%_))
                     (set! _%active-count17488%_ (- _%active-count17488%_ '1))
                     (set! _%idle17490%_ (cons _%worker17549%_ _%idle17490%_))
                     (if (and (pair? _%payload17547%_)
                              (eq? (let ()
                                     (declare (not safe))
                                     (##car _%payload17547%_))
                                   'failed))
                         (_%stop!17495%_ (cdr _%payload17547%_))
                         (if _%failed?17492%_
                             '#!void
                             (begin
                               (if (and (pair? _%payload17547%_)
                                        (eq? (let ()
                                               (declare (not safe))
                                               (##car _%payload17547%_))
                                             'finished))
                                   (if (null? (cdr _%payload17547%_))
                                       '#!void
                                       (begin
                                         (if (_%canceled?17476%_)
                                             (let ()
                                               (declare (not safe))
                                               (error '"ASCENT actor round canceled"))
                                             '#!void)
                                         (for-each
                                          (lambda (_%candidate17565%_)
                                            (_%merge17475%_
                                             (car _%candidate17565%_)
                                             (cdr _%candidate17565%_)))
                                          (cdr _%payload17547%_))))
                                   '#!void)
                               (_%completed!17478%_ _%task17548%_)))))
                   '#!void)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 '#!void)))
                                       '#!void))))
                           (if (pair? _%$%g1752017536%_)
                               (let ((_%$%hd1752517570%_
                                      (let ()
                                        (declare (not safe))
                                        (##car _%$%g1752017536%_)))
                                     (_%$%tl1752617572%_
                                      (let ()
                                        (declare (not safe))
                                        (##cdr _%$%g1752017536%_))))
                                 (let ((_%kind17575%_ _%$%hd1752517570%_))
                                   (if (pair? _%$%tl1752617572%_)
                                       (let ((_%$%hd1752717577%_
                                              (let ()
                                                (declare (not safe))
                                                (##car _%$%tl1752617572%_)))
                                             (_%$%tl1752817579%_
                                              (let ()
                                                (declare (not safe))
                                                (##cdr _%$%tl1752617572%_))))
                                         (let ((_%received-key17582%_
                                                _%$%hd1752717577%_))
                                           (if (pair? _%$%tl1752817579%_)
                                               (let ((_%$%hd1752917584%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (##car _%$%tl1752817579%_)))
                                                     (_%$%tl1753017586%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (##cdr _%$%tl1752817579%_))))
                                                 (let ((_%worker17589%_
                                                        _%$%hd1752917584%_))
                                                   (if (pair? _%$%tl1753017586%_)
                                                       (let ((_%$%hd1753117591%_
                                                              (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (##car _%$%tl1753017586%_)))
                     (_%$%tl1753217593%_
                      (let ()
                        (declare (not safe))
                        (##cdr _%$%tl1753017586%_))))
                 (let ((_%task17596%_ _%$%hd1753117591%_))
                   (if (pair? _%$%tl1753217593%_)
                       (let ((_%$%hd1753317598%_
                              (let ()
                                (declare (not safe))
                                (##car _%$%tl1753217593%_)))
                             (_%$%tl1753417600%_
                              (let ()
                                (declare (not safe))
                                (##cdr _%$%tl1753217593%_))))
                         (let ((_%payload17603%_ _%$%hd1753317598%_))
                           (if (null? _%$%tl1753417600%_)
                               (_%$%K1752417567%_
                                _%payload17603%_
                                _%task17596%_
                                _%worker17589%_
                                _%received-key17582%_
                                _%kind17575%_)
                               '#!void)))
                       '#!void)))
               '#!void)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               '#!void)))
                                       '#!void)))
                               '#!void))
                         (_%loop17513%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (declare (not safe))
                                                  (__with-catch
                                                   __tmp35877
                                                   __tmp35876)))))
                                      (let ((__tmp35881
                                             (lambda ()
                                               (_%run!17499%_)
                                               (if _%failed?17492%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (raise _%failure17493%_))
                                                   (if (pair? (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (##cdr _%pending17485%_)))
               (let ()
                 (declare (not safe))
                 (error '"ASCENT ready task dependency deadlock"))
               '#!void))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35878
                                             (lambda ()
                                               (let ((__tmp35879
                                                      (lambda (_%entry17505%_)
                                                        (thread-send
                                                         (car _%entry17505%_)
                                                         'stop))))
                                                 (declare (not safe))
                                                 (##for-each
                                                  __tmp35879
                                                  _%workers17489%_))
                                               (let ((__tmp35880
                                                      (lambda (_%entry17507%_)
                                                        (thread-join!
                                                         (cdr _%entry17507%_)))))
                                                 (declare (not safe))
                                                 (##for-each
                                                  __tmp35880
                                                  _%workers17489%_)))))
                                        (declare (not safe))
                                        (__with-unwind-protect
                                         __tmp35881
                                         __tmp35878)))))))
                           (declare (not safe))
                           (__with-catch __tmp35882 __tmp35868)))))
                  (declare (not safe))
                  (__spawn/name 'ascent-round-owner __tmp35867)))))
          (if (and (pair? _%result17685%_)
                   (eq? (let () (declare (not safe)) (##car _%result17685%_))
                        'failed))
              (let ((__tmp35883 (cdr _%result17685%_)))
                (declare (not safe))
                (raise __tmp35883))
              _%result17685%_))))
    (define gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__0
      (lambda (_%key17690%_
               _%tasks17691%_
               _%jobs17692%_
               _%execute17693%_
               _%merge17694%_)
        (let* ((_%canceled?17697%_ (lambda () '#f))
               (_%ready?17701%_ (lambda (_%_17699%_) '#t))
               (_%completed!17705%_ (lambda (_%_17703%_) '#!void)))
          (gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__%
           _%key17690%_
           _%tasks17691%_
           _%jobs17692%_
           _%execute17693%_
           _%merge17694%_
           _%canceled?17697%_
           _%ready?17701%_
           _%completed!17705%_))))
    (define gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__1
      (lambda (_%key17707%_
               _%tasks17708%_
               _%jobs17709%_
               _%execute17710%_
               _%merge17711%_
               _%canceled?17712%_)
        (let* ((_%ready?17716%_ (lambda (_%_17714%_) '#t))
               (_%completed!17720%_ (lambda (_%_17718%_) '#!void)))
          (gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__%
           _%key17707%_
           _%tasks17708%_
           _%jobs17709%_
           _%execute17710%_
           _%merge17711%_
           _%canceled?17712%_
           _%ready?17716%_
           _%completed!17720%_))))
    (define gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__2
      (lambda (_%key17722%_
               _%tasks17723%_
               _%jobs17724%_
               _%execute17725%_
               _%merge17726%_
               _%canceled?17727%_
               _%ready?17728%_)
        (let ((_%completed!17732%_ (lambda (_%_17730%_) '#!void)))
          (gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__%
           _%key17722%_
           _%tasks17723%_
           _%jobs17724%_
           _%execute17725%_
           _%merge17726%_
           _%canceled?17727%_
           _%ready?17728%_
           _%completed!17732%_))))
    (define gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!
      (lambda _g35884_
        (let ((_g35885_ (let () (declare (not safe)) (##length _g35884_))))
          (cond ((let () (declare (not safe)) (##fx= _g35885_ 5))
                 (apply gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__0
                        _g35884_))
                ((let () (declare (not safe)) (##fx= _g35885_ 6))
                 (apply gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__1
                        _g35884_))
                ((let () (declare (not safe)) (##fx= _g35885_ 7))
                 (apply gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__2
                        _g35884_))
                ((let () (declare (not safe)) (##fx= _g35885_ 8))
                 (apply gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__%
                        _g35884_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!
                  _g35884_))))))))
