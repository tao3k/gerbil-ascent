(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/planning::timestamp 1791687882)
  (begin
    (define gerbil-ascent/program/planning#gerbil-ascent-prepare-program
      (lambda (_%relations15383%_
               _%rules15384%_
               _%schema15385%_
               _%on-plan-error15386%_)
        (let* ((_%names15388%_ (vector-ref _%schema15385%_ '1))
               (_%arity15390%_ (vector-ref _%schema15385%_ '2))
               (_%positions15392%_ (vector-ref _%schema15385%_ '4))
               (_%kinds15394%_ (vector-ref _%schema15385%_ '8))
               (_%count15396%_ (vector-length _%names15388%_)))
          (letrec* ((_%position-of15399%_
                     (if (= _%count15396%_ '1)
                         (lambda (_%name15426%_)
                           (if (eq? _%name15426%_
                                    (vector-ref _%names15388%_ '0))
                               '0
                               (let ()
                                 (declare (not safe))
                                 (error '"unknown ASCENT relation"
                                        _%name15426%_))))
                         (lambda (_%name15428%_)
                           (let ((_%slot15430%_
                                  (let ()
                                    (declare (not safe))
                                    (hash-get
                                     _%positions15392%_
                                     _%name15428%_))))
                             (if _%slot15430%_
                                 '#!void
                                 (let ()
                                   (declare (not safe))
                                   (error '"unknown ASCENT relation"
                                          _%name15428%_)))
                             (- _%slot15430%_ '1)))))
                    (_%atom-plan15400%_
                     (lambda (_%atom15415%_)
                       (if (and (let ()
                                  (declare (not safe))
                                  (object? _%atom15415%_))
                                (let ((__tmp36253
                                       (let ()
                                         (declare (not safe))
                                         (clan/poo/object#.ref
                                          _%atom15415%_
                                          'ascent-clause-kind))))
                                  (declare (not safe))
                                  (##memq __tmp36253
                                          '(atom negation aggregate))))
                           '#!void
                           (let ()
                             (declare (not safe))
                             (error '"invalid ASCENT atom declaration"
                                    _%atom15415%_)))
                       (let* ((_%index15417%_
                               (_%position-of15399%_
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/object#.ref
                                   _%atom15415%_
                                   'relation))))
                              (_%terms15419%_
                               (let ()
                                 (declare (not safe))
                                 (clan/poo/object#.ref _%atom15415%_ 'terms))))
                         (if (and (list? _%terms15419%_)
                                  (= (let ()
                                       (declare (not safe))
                                       (##length _%terms15419%_))
                                     (vector-ref
                                      _%arity15390%_
                                      _%index15417%_)))
                             '#!void
                             (let ((__tmp36254
                                    (let ()
                                      (declare (not safe))
                                      (clan/poo/object#.ref
                                       _%atom15415%_
                                       'relation))))
                               (declare (not safe))
                               (error '"ASCENT atom arity mismatch"
                                      __tmp36254)))
                         (vector _%index15417%_
                                 (map (lambda (_%term15422%_)
                                        (let ((_%kind15424%_
                                               (let ()
                                                 (declare (not safe))
                                                 (clan/poo/object#.ref
                                                  _%term15422%_
                                                  'kind))))
                                          (if (let ()
                                                (declare (not safe))
                                                (##memq _%kind15424%_
                                                        '(variable
                                                          wildcard
                                                          literal
                                                          expression
                                                          pattern)))
                                              '#!void
                                              (let ()
                                                (declare (not safe))
                                                (error '"invalid ASCENT rule term"
                                                       _%kind15424%_)))
                                          (cons _%kind15424%_
                                                (let ()
                                                  (declare (not safe))
                                                  (clan/poo/object#.ref
                                                   _%term15422%_
                                                   'value)))))
                                      _%terms15419%_))))))
            (let* ((_%plans15405%_
                    (map (lambda (_%rule15402%_ _%index15403%_)
                           (gerbil-ascent/program/planning#gerbil-ascent-prepare-rule
                            _%rule15402%_
                            _%index15403%_
                            _%atom-plan15400%_
                            _%on-plan-error15386%_))
                         _%rules15384%_
                         (let ((__tmp36255 (length _%rules15384%_)))
                           (declare (not safe))
                           (##iota __tmp36255))))
                   (_%strata15410%_
                    (let ((__tmp36257
                           (lambda (_%failure15407%_)
                             (gerbil-ascent/program/planning#plan-failure
                              _%on-plan-error15386%_
                              '(program dependencies)
                              _%failure15407%_)))
                          (__tmp36256
                           (lambda ()
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/core/rule-semantics#gerbil-ascent-rule-strata
                                _%plans15405%_
                                _%count15396%_
                                _%kinds15394%_)))))
                      (declare (not safe))
                      (__with-catch __tmp36257 __tmp36256)))
                   (_%active15413%_
                    (gerbil-ascent/program/planning#active-rules
                     _%plans15405%_
                     _%strata15410%_)))
              (vector _%relations15383%_
                      _%rules15384%_
                      _%plans15405%_
                      _%strata15410%_
                      _%active15413%_
                      (let ()
                        (declare (not safe))
                        (gerbil-ascent/core/positive-plan#gerbil-ascent-prepare-rule-activations
                         _%active15413%_))
                      (let ()
                        (declare (not safe))
                        (gerbil-ascent/core/rule-semantics#gerbil-ascent-rule-successors
                         _%plans15405%_
                         _%count15396%_))))))))
    (define gerbil-ascent/program/planning#active-rules
      (lambda (_%plans15362%_ _%strata15363%_)
        (let* ((_%highest15365%_
                (if (zero? (vector-length _%strata15363%_))
                    '-1
                    (let ((__tmp36258 (vector->list _%strata15363%_)))
                      (declare (not safe))
                      (##apply max __tmp36258))))
               (_%active15367%_ (make-vector (+ _%highest15365%_ '1) '())))
          (for-each
           (lambda (_%rule15370%_)
             (let ((_%heads-by-stratum15372%_
                    (let () (declare (not safe)) (make-hash-table-eqv))))
               (for-each
                (lambda (_%head15374%_)
                  (let ((__tmp36260
                         (vector-ref
                          _%strata15363%_
                          (vector-ref _%head15374%_ '0)))
                        (__tmp36259
                         (lambda (_%$%g1537515377%_)
                           (cons _%head15374%_ _%$%g1537515377%_))))
                    (declare (not safe))
                    (__hash-update!__%
                     _%heads-by-stratum15372%_
                     __tmp36260
                     __tmp36259
                     '())))
                (vector-ref _%rule15370%_ '0))
               (let ((__tmp36261
                      (lambda (_%stratum15380%_ _%heads15381%_)
                        (vector-set!
                         _%active15367%_
                         _%stratum15380%_
                         (cons (vector (reverse _%heads15381%_)
                                       (vector-ref _%rule15370%_ '1)
                                       (let ((__tmp36262
                                              (vector-ref _%rule15370%_ '1)))
                                         (declare (not safe))
                                         (gerbil-ascent/core/rule-semantics#gerbil-ascent-delta-positions
                                          __tmp36262
                                          _%strata15363%_
                                          _%stratum15380%_))
                                       (vector-ref _%rule15370%_ '3))
                               (vector-ref
                                _%active15367%_
                                _%stratum15380%_))))))
                 (declare (not safe))
                 (__hash-for-each __tmp36261 _%heads-by-stratum15372%_))))
           _%plans15362%_)
          (vector-map reverse _%active15367%_))))
    (define gerbil-ascent/program/planning#plan-failure
      (lambda (_%callback15358%_ _%path15359%_ _%failure15360%_)
        (if _%callback15358%_
            (_%callback15358%_ _%path15359%_ _%failure15360%_)
            '#!void)
        (let () (declare (not safe)) (raise _%failure15360%_))))
    (define gerbil-ascent/program/planning#head-plan
      (lambda (_%head15345%_ _%bound?15346%_ _%atom-plan15347%_)
        (if (and (let () (declare (not safe)) (object? _%head15345%_))
                 (eq? (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref
                         _%head15345%_
                         'ascent-clause-kind))
                      'atom))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT rule head" _%head15345%_)))
        (let ((_%plan15349%_ (_%atom-plan15347%_ _%head15345%_)))
          (for-each
           (lambda (_%term15351%_)
             (let ((_%$e15353%_ (car _%term15351%_)))
               (if (eq? 'variable _%$e15353%_)
                   (if (_%bound?15346%_ (cdr _%term15351%_))
                       '#!void
                       (let ((__tmp36263 (cdr _%term15351%_)))
                         (declare (not safe))
                         (error '"unsafe ASCENT head variable" __tmp36263)))
                   (if (eq? 'expression _%$e15353%_)
                       (for-each
                        (lambda (_%name15356%_)
                          (if (_%bound?15346%_ _%name15356%_)
                              '#!void
                              (let ()
                                (declare (not safe))
                                (error '"unsafe ASCENT head expression variable"
                                       _%name15356%_))))
                        (vector-ref (cdr _%term15351%_) '0))
                       (if (eq? 'pattern _%$e15353%_)
                           (let ()
                             (declare (not safe))
                             (error '"ASCENT pattern is invalid in a rule head"))
                           (if (eq? 'wildcard _%$e15353%_)
                               (let ()
                                 (declare (not safe))
                                 (error '"ASCENT wildcard is invalid in a rule head"))
                               '#!void))))))
           (vector-ref _%plan15349%_ '1))
          _%plan15349%_)))
    (define gerbil-ascent/program/planning#gerbil-ascent-prepare-rule
      (lambda (_%rule15310%_
               _%rule-index15311%_
               _%atom-plan15312%_
               _%on-plan-error15313%_)
        (if (let () (declare (not safe)) (object? _%rule15310%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT rule declaration" _%rule15310%_)))
        (let* ((_%body15315%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%rule15310%_ 'body)))
               (_%heads15317%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%rule15310%_ 'heads)))
               (_%bound15319%_ '())
               (_%atoms15321%_ '0)
               (_%body-plans15323%_ '()))
          (if (and (list? _%body15315%_) (pair? _%heads15317%_) '#t)
              '#!void
              (let ()
                (declare (not safe))
                (error '"invalid ASCENT rule declaration" _%rule15310%_)))
          (for-each
           (lambda (_%clause15326%_ _%clause-index15327%_)
             (let ((__tmp36265
                    (lambda (_%failure15329%_)
                      (gerbil-ascent/program/planning#plan-failure
                       _%on-plan-error15313%_
                       (list 'rule
                             _%rule-index15311%_
                             'body
                             _%clause-index15327%_)
                       _%failure15329%_)))
                   (__tmp36264
                    (lambda ()
                      (if (let ()
                            (declare (not safe))
                            (object? _%clause15326%_))
                          '#!void
                          (let ()
                            (declare (not safe))
                            (error '"invalid ASCENT rule clause"
                                   _%clause15326%_)))
                      (let ((_%result15332%_
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/program/objects#gerbil-ascent-clause-plan
                                _%clause15326%_
                                _%atom-plan15312%_
                                _%bound15319%_))))
                        (set! _%body-plans15323%_
                              (cons (vector-ref _%result15332%_ '0)
                                    _%body-plans15323%_))
                        (set! _%bound15319%_ (vector-ref _%result15332%_ '1))
                        (set! _%atoms15321%_
                              (+ _%atoms15321%_
                                 (vector-ref _%result15332%_ '2)))))))
               (declare (not safe))
               (__with-catch __tmp36265 __tmp36264)))
           _%body15315%_
           (let ((__tmp36266 (length _%body15315%_)))
             (declare (not safe))
             (##iota __tmp36266)))
          (let* ((_%bound?15334%_
                  (let ()
                    (declare (not safe))
                    (gerbil-ascent/program/objects#gerbil-ascent-bound-membership
                     _%bound15319%_)))
                 (_%planned-heads15342%_
                  (map (lambda (_%head15336%_ _%head-index15337%_)
                         (let ((__tmp36268
                                (lambda (_%failure15339%_)
                                  (gerbil-ascent/program/planning#plan-failure
                                   _%on-plan-error15313%_
                                   (list 'rule
                                         _%rule-index15311%_
                                         'head
                                         _%head-index15337%_)
                                   _%failure15339%_)))
                               (__tmp36267
                                (lambda ()
                                  (gerbil-ascent/program/planning#head-plan
                                   _%head15336%_
                                   _%bound?15334%_
                                   _%atom-plan15312%_))))
                           (declare (not safe))
                           (__with-catch __tmp36268 __tmp36267)))
                       _%heads15317%_
                       (let ((__tmp36269 (length _%heads15317%_)))
                         (declare (not safe))
                         (##iota __tmp36269)))))
            (vector _%planned-heads15342%_
                    (let ()
                      (declare (not safe))
                      (##reverse _%body-plans15323%_))
                    _%atoms15321%_
                    _%rule-index15311%_)))))))
