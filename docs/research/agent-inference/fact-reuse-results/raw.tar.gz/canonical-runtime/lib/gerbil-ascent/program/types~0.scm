(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/types::timestamp 1791691008)
  (begin
    (define gerbil-ascent/program/types#slot-contract
      (lambda (_%identity5664%_ _%predicate5665%_)
        (let ((__tmp35746 (lambda (_%_value5667%_ _%_context5668%_) '())))
          (declare (not safe))
          (core/types#poo-flow-predicate-contract
           _%identity5664%_
           _%predicate5665%_
           __tmp35746))))
    (define gerbil-ascent/program/types#+symbol+
      (gerbil-ascent/program/types#slot-contract 'ascent/symbol symbol?))
    (define gerbil-ascent/program/types#+arity+
      (gerbil-ascent/program/types#slot-contract
       'ascent/arity
       (lambda (_%value5662%_)
         (if (exact-integer? _%value5662%_) (<= '0 _%value5662%_) '#f))))
    (define gerbil-ascent/program/types#+fact-budget+
      (gerbil-ascent/program/types#slot-contract
       'ascent/fact-budget
       (lambda (_%value5660%_)
         (if (exact-integer? _%value5660%_) (> _%value5660%_ '0) '#f))))
    (define gerbil-ascent/program/types#+rows+
      (gerbil-ascent/program/types#slot-contract 'ascent/rows list?))
    (define gerbil-ascent/program/types#+field-predicates+
      (gerbil-ascent/program/types#slot-contract
       'ascent/field-predicates
       (lambda (_%value5658%_)
         (if (list? _%value5658%_)
             (let () (declare (not safe)) (andmap__0 procedure? _%value5658%_))
             '#f))))
    (define gerbil-ascent/program/types#+provider+
      (gerbil-ascent/program/types#slot-contract
       'ascent/index-provider
       (lambda (_%value5653%_)
         (let ((_%$e5655%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                   _%value5653%_))))
           (if _%$e5655%_
               _%$e5655%_
               (let ()
                 (declare (not safe))
                 (clan/poo/mop#element?
                  gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
                  _%value5653%_)))))))
    (define gerbil-ascent/program/types#+storage-provider+
      (gerbil-ascent/program/types#slot-contract
       'ascent/storage-provider
       (lambda (_%value5648%_)
         (let ((_%$e5650%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                   _%value5648%_))))
           (if _%$e5650%_
               _%$e5650%_
               (let ()
                 (declare (not safe))
                 (clan/poo/mop#element?
                  gerbil-ascent/table/storage#GerbilAscentStorageProviderContract
                  _%value5648%_)))))))
    (define gerbil-ascent/program/types#+term-kind+
      (gerbil-ascent/program/types#slot-contract
       'ascent/term-kind
       (lambda (_%value5646%_)
         (let ()
           (declare (not safe))
           (##memq _%value5646%_
                   '(variable wildcard literal expression pattern))))))
    (define gerbil-ascent/program/types#+any+
      (gerbil-ascent/program/types#slot-contract
       'ascent/value
       (lambda (_%_value5644%_) '#t)))
    (define gerbil-ascent/program/types#+plan+
      (gerbil-ascent/program/types#slot-contract
       'ascent/clause-plan
       procedure?))
    (define gerbil-ascent/program/types#clause-kind-contract
      (lambda (_%kind5640%_)
        (gerbil-ascent/program/types#slot-contract
         'ascent/clause-kind
         (lambda (_%value5642%_) (eq? _%value5642%_ _%kind5640%_)))))
    (define gerbil-ascent/program/types#GerbilAscentRelationContract
      (let ((__obj35703
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35748
               (list (cons 'sexp
                           (let ((__tmp35749
                                  (lambda (_%@5556%_)
                                    'GerbilAscentRelationContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35749)))
                     (cons 'identity
                           (let ((__tmp35750
                                  (lambda (_%@5562%_) 'ascent/relation)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35750)))
                     (cons 'proto
                           (let ((__tmp35751
                                  (lambda (_%@5567%_)
                                    (let ((__obj35701
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35753 (list))
                                            (__tmp35752 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35753
                                         __tmp35752
                                         __obj35701))
                                      __obj35701))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35751)))
                     (cons 'responsibilities
                           (let ((__tmp35754
                                  (lambda (_%@5581%_)
                                    (let ((__obj35702
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35756
                                             (list (cons 'name
                                                         (let ((__tmp35757
                                                                (lambda (_%self5603%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35757)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'arity
                                                         (let ((__tmp35758
                                                                (lambda (_%self5610%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+arity+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35758)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'rows
                                                         (let ((__tmp35759
                                                                (lambda (_%self5615%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+rows+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35759)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'field-predicates
                                                         (let ((__tmp35760
                                                                (lambda (_%self5620%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+field-predicates+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35760)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'storage-kind
                                                         (let ((__tmp35761
                                                                (lambda (_%self5625%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'relation))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35761)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'index-provider
                                                         (let ((__tmp35762
                                                                (lambda (_%self5630%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+provider+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35762)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'storage-provider
                                                         (let ((__tmp35763
                                                                (lambda (_%self5635%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+storage-provider+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35763)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35755 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35756
                                         __tmp35755
                                         __obj35702))
                                      __obj35702))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35754)))))
              (__tmp35747 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35748
           __tmp35747
           __obj35703))
        __obj35703))
    (define gerbil-ascent/program/types#GerbilAscentLatticeContract
      (let ((__obj35706
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35765
               (list (cons 'sexp
                           (let ((__tmp35766
                                  (lambda (_%@5448%_)
                                    'GerbilAscentLatticeContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35766)))
                     (cons 'identity
                           (let ((__tmp35767
                                  (lambda (_%@5454%_) 'ascent/lattice)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35767)))
                     (cons 'proto
                           (let ((__tmp35768
                                  (lambda (_%@5459%_)
                                    (let ((__obj35704
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35770 (list))
                                            (__tmp35769 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35770
                                         __tmp35769
                                         __obj35704))
                                      __obj35704))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35768)))
                     (cons 'responsibilities
                           (let ((__tmp35771
                                  (lambda (_%@5473%_)
                                    (let ((__obj35705
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35773
                                             (list (cons 'name
                                                         (let ((__tmp35774
                                                                (lambda (_%self5496%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35774)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'arity
                                                         (let ((__tmp35775
                                                                (lambda (_%self5503%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+arity+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35775)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'rows
                                                         (let ((__tmp35776
                                                                (lambda (_%self5508%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+rows+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35776)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'field-predicates
                                                         (let ((__tmp35777
                                                                (lambda (_%self5513%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+field-predicates+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35777)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'storage-kind
                                                         (let ((__tmp35778
                                                                (lambda (_%self5518%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'lattice))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35778)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'join
                                                         (let ((__tmp35779
                                                                (lambda (_%self5523%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#slot-contract
                           'ascent/lattice-join
                           procedure?))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35779)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'checked-operator
                                                         (let ((__tmp35780
                                                                (lambda (_%self5528%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#slot-contract
                           'ascent/lattice-checked-operator
                           (lambda (_%value5533%_)
                             (let ((_%$e5535%_ (not _%value5533%_)))
                               (if _%$e5535%_
                                   _%$e5535%_
                                   (vector? _%value5533%_))))))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35780)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'index-provider
                                                         (let ((__tmp35781
                                                                (lambda (_%self5538%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+provider+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35781)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35772 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35773
                                         __tmp35772
                                         __obj35705))
                                      __obj35705))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35771)))))
              (__tmp35764 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35765
           __tmp35764
           __obj35706))
        __obj35706))
    (define gerbil-ascent/program/types#GerbilAscentTermContract
      (let ((__obj35709
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35783
               (list (cons 'sexp
                           (let ((__tmp35784
                                  (lambda (_%@5381%_)
                                    'GerbilAscentTermContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35784)))
                     (cons 'identity
                           (let ((__tmp35785
                                  (lambda (_%@5387%_) 'ascent/term)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35785)))
                     (cons 'proto
                           (let ((__tmp35786
                                  (lambda (_%@5392%_)
                                    (let ((__obj35707
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35788 (list))
                                            (__tmp35787 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35788
                                         __tmp35787
                                         __obj35707))
                                      __obj35707))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35786)))
                     (cons 'responsibilities
                           (let ((__tmp35789
                                  (lambda (_%@5406%_)
                                    (let ((__obj35708
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35791
                                             (list (cons 'kind
                                                         (let ((__tmp35792
                                                                (lambda (_%self5423%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+term-kind+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35792)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'value
                                                         (let ((__tmp35793
                                                                (lambda (_%self5430%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+any+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35793)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35790 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35791
                                         __tmp35790
                                         __obj35708))
                                      __obj35708))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35789)))))
              (__tmp35782 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35783
           __tmp35782
           __obj35709))
        __obj35709))
    (define gerbil-ascent/program/types#+terms+
      (gerbil-ascent/program/types#slot-contract
       'ascent/terms
       (lambda (_%value5364%_)
         (if (list? _%value5364%_)
             (let ((__tmp35794
                    (lambda (_%term5366%_)
                      (let ()
                        (declare (not safe))
                        (clan/poo/mop#element?
                         gerbil-ascent/program/types#GerbilAscentTermContract
                         _%term5366%_)))))
               (declare (not safe))
               (andmap__0 __tmp35794 _%value5364%_))
             '#f))))
    (define gerbil-ascent/program/types#GerbilAscentAtomContract
      (let ((__obj35712
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35796
               (list (cons 'sexp
                           (let ((__tmp35797
                                  (lambda (_%@5298%_)
                                    'GerbilAscentAtomContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35797)))
                     (cons 'identity
                           (let ((__tmp35798
                                  (lambda (_%@5304%_) 'ascent/atom)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35798)))
                     (cons 'proto
                           (let ((__tmp35799
                                  (lambda (_%@5309%_)
                                    (let ((__obj35710
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35801 (list))
                                            (__tmp35800 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35801
                                         __tmp35800
                                         __obj35710))
                                      __obj35710))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35799)))
                     (cons 'responsibilities
                           (let ((__tmp35802
                                  (lambda (_%@5323%_)
                                    (let ((__obj35711
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35804
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp35805
                                                                (lambda (_%self5342%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'atom))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35805)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'relation
                                                         (let ((__tmp35806
                                                                (lambda (_%self5349%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35806)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'terms
                                                         (let ((__tmp35807
                                                                (lambda (_%self5354%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+terms+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35807)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp35808
                                                                (lambda (_%self5359%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35808)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35803 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35804
                                         __tmp35803
                                         __obj35711))
                                      __obj35711))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35802)))))
              (__tmp35795 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35796
           __tmp35795
           __obj35712))
        __obj35712))
    (define gerbil-ascent/program/types#+variables+
      (gerbil-ascent/program/types#slot-contract
       'ascent/variables
       (lambda (_%value5283%_)
         (if (list? _%value5283%_)
             (let () (declare (not safe)) (andmap__0 symbol? _%value5283%_))
             '#f))))
    (define gerbil-ascent/program/types#+generator-output+
      (gerbil-ascent/program/types#slot-contract
       'ascent/generator-output
       (lambda (_%value5270%_)
         (let ((_%$e5272%_ (symbol? _%value5270%_)))
           (if _%$e5272%_
               _%$e5272%_
               (if (pair? _%value5270%_)
                   (let _%loop5275%_ ((_%remaining5277%_ _%value5270%_)
                                      (_%seen5278%_ '()))
                     (let ((_%$e5280%_ (null? _%remaining5277%_)))
                       (if _%$e5280%_
                           _%$e5280%_
                           (if (symbol? (car _%remaining5277%_))
                               (if (memq (car _%remaining5277%_) _%seen5278%_)
                                   '#f
                                   (_%loop5275%_
                                    (cdr _%remaining5277%_)
                                    (cons (car _%remaining5277%_)
                                          _%seen5278%_)))
                               '#f))))
                   '#f))))))
    (define gerbil-ascent/program/types#+procedure+
      (gerbil-ascent/program/types#slot-contract 'ascent/procedure procedure?))
    (define gerbil-ascent/program/types#+optional-procedure+
      (gerbil-ascent/program/types#slot-contract
       'ascent/optional-procedure
       (lambda (_%value5265%_)
         (let ((_%$e5267%_ (not _%value5265%_)))
           (if _%$e5267%_ _%$e5267%_ (procedure? _%value5265%_))))))
    (define gerbil-ascent/program/types#+checked-operator+
      (gerbil-ascent/program/types#slot-contract
       'ascent/checked-operator
       (lambda (_%value5260%_)
         (let ((_%$e5262%_ (not _%value5260%_)))
           (if _%$e5262%_ _%$e5262%_ (vector? _%value5260%_))))))
    (define gerbil-ascent/program/types#GerbilAscentGuardContract
      (let ((__obj35715
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35810
               (list (cons 'sexp
                           (let ((__tmp35811
                                  (lambda (_%@5188%_)
                                    'GerbilAscentGuardContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35811)))
                     (cons 'identity
                           (let ((__tmp35812
                                  (lambda (_%@5194%_) 'ascent/guard)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35812)))
                     (cons 'proto
                           (let ((__tmp35813
                                  (lambda (_%@5199%_)
                                    (let ((__obj35713
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35815 (list))
                                            (__tmp35814 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35815
                                         __tmp35814
                                         __obj35713))
                                      __obj35713))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35813)))
                     (cons 'responsibilities
                           (let ((__tmp35816
                                  (lambda (_%@5213%_)
                                    (let ((__obj35714
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35818
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp35819
                                                                (lambda (_%self5233%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'guard))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35819)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variables
                                                         (let ((__tmp35820
                                                                (lambda (_%self5240%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+variables+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35820)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'predicate
                                                         (let ((__tmp35821
                                                                (lambda (_%self5245%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35821)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'checked-operator
                                                         (let ((__tmp35822
                                                                (lambda (_%self5250%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+checked-operator+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35822)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp35823
                                                                (lambda (_%self5255%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35823)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35817 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35818
                                         __tmp35817
                                         __obj35714))
                                      __obj35714))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35816)))))
              (__tmp35809 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35810
           __tmp35809
           __obj35715))
        __obj35715))
    (define gerbil-ascent/program/types#GerbilAscentGeneratorContract
      (let ((__obj35718
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35825
               (list (cons 'sexp
                           (let ((__tmp35826
                                  (lambda (_%@5103%_)
                                    'GerbilAscentGeneratorContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35826)))
                     (cons 'identity
                           (let ((__tmp35827
                                  (lambda (_%@5109%_) 'ascent/generator)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35827)))
                     (cons 'proto
                           (let ((__tmp35828
                                  (lambda (_%@5114%_)
                                    (let ((__obj35716
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35830 (list))
                                            (__tmp35829 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35830
                                         __tmp35829
                                         __obj35716))
                                      __obj35716))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35828)))
                     (cons 'responsibilities
                           (let ((__tmp35831
                                  (lambda (_%@5128%_)
                                    (let ((__obj35717
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35833
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp35834
                                                                (lambda (_%self5148%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'generator))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35834)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variable
                                                         (let ((__tmp35835
                                                                (lambda (_%self5155%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+generator-output+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35835)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variables
                                                         (let ((__tmp35836
                                                                (lambda (_%self5160%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+variables+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35836)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'generate
                                                         (let ((__tmp35837
                                                                (lambda (_%self5165%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35837)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp35838
                                                                (lambda (_%self5170%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35838)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35832 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35833
                                         __tmp35832
                                         __obj35717))
                                      __obj35717))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35831)))))
              (__tmp35824 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35825
           __tmp35824
           __obj35718))
        __obj35718))
    (define gerbil-ascent/program/types#GerbilAscentBindingContract
      (let ((__obj35721
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35840
               (list (cons 'sexp
                           (let ((__tmp35841
                                  (lambda (_%@5012%_)
                                    'GerbilAscentBindingContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35841)))
                     (cons 'identity
                           (let ((__tmp35842
                                  (lambda (_%@5018%_) 'ascent/binding)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35842)))
                     (cons 'proto
                           (let ((__tmp35843
                                  (lambda (_%@5023%_)
                                    (let ((__obj35719
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35845 (list))
                                            (__tmp35844 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35845
                                         __tmp35844
                                         __obj35719))
                                      __obj35719))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35843)))
                     (cons 'responsibilities
                           (let ((__tmp35846
                                  (lambda (_%@5037%_)
                                    (let ((__obj35720
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35848
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp35849
                                                                (lambda (_%self5058%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'binding))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35849)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variable
                                                         (let ((__tmp35850
                                                                (lambda (_%self5065%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35850)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variables
                                                         (let ((__tmp35851
                                                                (lambda (_%self5070%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+variables+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35851)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'checked-operator
                                                         (let ((__tmp35852
                                                                (lambda (_%self5075%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+checked-operator+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35852)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'compute
                                                         (let ((__tmp35853
                                                                (lambda (_%self5080%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35853)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp35854
                                                                (lambda (_%self5085%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35854)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35847 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35848
                                         __tmp35847
                                         __obj35720))
                                      __obj35720))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35846)))))
              (__tmp35839 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35840
           __tmp35839
           __obj35721))
        __obj35721))
    (define gerbil-ascent/program/types#GerbilAscentNegationContract
      (let ((__obj35724
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35856
               (list (cons 'sexp
                           (let ((__tmp35857
                                  (lambda (_%@4933%_)
                                    'GerbilAscentNegationContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35857)))
                     (cons 'identity
                           (let ((__tmp35858
                                  (lambda (_%@4939%_) 'ascent/negation)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35858)))
                     (cons 'proto
                           (let ((__tmp35859
                                  (lambda (_%@4944%_)
                                    (let ((__obj35722
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35861 (list))
                                            (__tmp35860 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35861
                                         __tmp35860
                                         __obj35722))
                                      __obj35722))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35859)))
                     (cons 'responsibilities
                           (let ((__tmp35862
                                  (lambda (_%@4958%_)
                                    (let ((__obj35723
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35864
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp35865
                                                                (lambda (_%self4977%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'negation))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35865)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'relation
                                                         (let ((__tmp35866
                                                                (lambda (_%self4984%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35866)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'terms
                                                         (let ((__tmp35867
                                                                (lambda (_%self4989%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+terms+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35867)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp35868
                                                                (lambda (_%self4994%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35868)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35863 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35864
                                         __tmp35863
                                         __obj35723))
                                      __obj35723))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35862)))))
              (__tmp35855 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35856
           __tmp35855
           __obj35724))
        __obj35724))
    (define gerbil-ascent/program/types#GerbilAscentAggregateContract
      (let ((__obj35727
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35870
               (list (cons 'sexp
                           (let ((__tmp35871
                                  (lambda (_%@4824%_)
                                    'GerbilAscentAggregateContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35871)))
                     (cons 'identity
                           (let ((__tmp35872
                                  (lambda (_%@4830%_) 'ascent/aggregate)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35872)))
                     (cons 'proto
                           (let ((__tmp35873
                                  (lambda (_%@4835%_)
                                    (let ((__obj35725
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35875 (list))
                                            (__tmp35874 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35875
                                         __tmp35874
                                         __obj35725))
                                      __obj35725))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35873)))
                     (cons 'responsibilities
                           (let ((__tmp35876
                                  (lambda (_%@4849%_)
                                    (let ((__obj35726
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35878
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp35879
                                                                (lambda (_%self4873%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'aggregate))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35879)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variable
                                                         (let ((__tmp35880
                                                                (lambda (_%self4880%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+generator-output+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35880)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'relation
                                                         (let ((__tmp35881
                                                                (lambda (_%self4885%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35881)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'terms
                                                         (let ((__tmp35882
                                                                (lambda (_%self4890%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+terms+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35882)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variables
                                                         (let ((__tmp35883
                                                                (lambda (_%self4895%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+variables+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35883)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'aggregate
                                                         (let ((__tmp35884
                                                                (lambda (_%self4900%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35884)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'checked-operator
                                                         (let ((__tmp35885
                                                                (lambda (_%self4905%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+checked-operator+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35885)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'output-pattern
                                                         (let ((__tmp35886
                                                                (lambda (_%self4910%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+optional-procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35886)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp35887
                                                                (lambda (_%self4915%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35887)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35877 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35878
                                         __tmp35877
                                         __obj35726))
                                      __obj35726))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35876)))))
              (__tmp35869 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35870
           __tmp35869
           __obj35727))
        __obj35727))
    (define gerbil-ascent/program/types#+clauses+
      (gerbil-ascent/program/types#slot-contract
       'ascent/clauses
       (lambda (_%value4792%_)
         (if (list? _%value4792%_)
             (let ((__tmp35888
                    (lambda (_%clause4794%_)
                      (let ((_%$e4796%_
                             (let ()
                               (declare (not safe))
                               (clan/poo/mop#element?
                                gerbil-ascent/program/types#GerbilAscentAtomContract
                                _%clause4794%_))))
                        (if _%$e4796%_
                            _%$e4796%_
                            (let ((_%$e4799%_
                                   (let ()
                                     (declare (not safe))
                                     (clan/poo/mop#element?
                                      gerbil-ascent/program/types#GerbilAscentGuardContract
                                      _%clause4794%_))))
                              (if _%$e4799%_
                                  _%$e4799%_
                                  (let ((_%$e4802%_
                                         (let ()
                                           (declare (not safe))
                                           (clan/poo/mop#element?
                                            gerbil-ascent/program/types#GerbilAscentGeneratorContract
                                            _%clause4794%_))))
                                    (if _%$e4802%_
                                        _%$e4802%_
                                        (let ((_%$e4805%_
                                               (let ()
                                                 (declare (not safe))
                                                 (clan/poo/mop#element?
                                                  gerbil-ascent/program/types#GerbilAscentBindingContract
                                                  _%clause4794%_))))
                                          (if _%$e4805%_
                                              _%$e4805%_
                                              (let ((_%$e4808%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (clan/poo/mop#element?
                                                        gerbil-ascent/program/types#GerbilAscentNegationContract
                                                        _%clause4794%_))))
                                                (if _%$e4808%_
                                                    _%$e4808%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (clan/poo/mop#element?
                                                       gerbil-ascent/program/types#GerbilAscentAggregateContract
                                                       _%clause4794%_)))))))))))))))
               (declare (not safe))
               (andmap__0 __tmp35888 _%value4792%_))
             '#f))))
    (define gerbil-ascent/program/types#+heads+
      (gerbil-ascent/program/types#slot-contract
       'ascent/heads
       (lambda (_%value4788%_)
         (if (pair? _%value4788%_)
             (let ((__tmp35889
                    (lambda (_%head4790%_)
                      (let ()
                        (declare (not safe))
                        (clan/poo/mop#element?
                         gerbil-ascent/program/types#GerbilAscentAtomContract
                         _%head4790%_)))))
               (declare (not safe))
               (andmap__0 __tmp35889 _%value4788%_))
             '#f))))
    (define gerbil-ascent/program/types#GerbilAscentRuleContract
      (let ((__obj35730
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35891
               (list (cons 'sexp
                           (let ((__tmp35892
                                  (lambda (_%@4734%_)
                                    'GerbilAscentRuleContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35892)))
                     (cons 'identity
                           (let ((__tmp35893
                                  (lambda (_%@4740%_) 'ascent/rule)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35893)))
                     (cons 'proto
                           (let ((__tmp35894
                                  (lambda (_%@4745%_)
                                    (let ((__obj35728
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35896 (list))
                                            (__tmp35895 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35896
                                         __tmp35895
                                         __obj35728))
                                      __obj35728))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35894)))
                     (cons 'responsibilities
                           (let ((__tmp35897
                                  (lambda (_%@4759%_)
                                    (let ((__obj35729
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35899
                                             (list (cons 'heads
                                                         (let ((__tmp35900
                                                                (lambda (_%self4776%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+heads+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35900)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'body
                                                         (let ((__tmp35901
                                                                (lambda (_%self4783%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+clauses+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35901)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35898 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35899
                                         __tmp35898
                                         __obj35729))
                                      __obj35729))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35897)))))
              (__tmp35890 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35891
           __tmp35890
           __obj35730))
        __obj35730))
    (define gerbil-ascent/program/types#+relations+
      (gerbil-ascent/program/types#slot-contract
       'ascent/relations
       (lambda (_%value4714%_)
         (if (list? _%value4714%_)
             (let ((__tmp35902
                    (lambda (_%relation4716%_)
                      (let ((_%$e4718%_
                             (let ()
                               (declare (not safe))
                               (clan/poo/mop#element?
                                gerbil-ascent/program/types#GerbilAscentRelationContract
                                _%relation4716%_))))
                        (if _%$e4718%_
                            _%$e4718%_
                            (let ()
                              (declare (not safe))
                              (clan/poo/mop#element?
                               gerbil-ascent/program/types#GerbilAscentLatticeContract
                               _%relation4716%_)))))))
               (declare (not safe))
               (andmap__0 __tmp35902 _%value4714%_))
             '#f))))
    (define gerbil-ascent/program/types#+rules+
      (gerbil-ascent/program/types#slot-contract
       'ascent/rules
       (lambda (_%value4710%_)
         (if (list? _%value4710%_)
             (let ((__tmp35903
                    (lambda (_%rule4712%_)
                      (let ()
                        (declare (not safe))
                        (clan/poo/mop#element?
                         gerbil-ascent/program/types#GerbilAscentRuleContract
                         _%rule4712%_)))))
               (declare (not safe))
               (andmap__0 __tmp35903 _%value4710%_))
             '#f))))
    (define gerbil-ascent/program/types#+fragment-exports+
      (gerbil-ascent/program/types#slot-contract
       'ascent/fragment-exports
       procedure?))
    (define gerbil-ascent/program/types#+source-handles+
      (gerbil-ascent/program/types#slot-contract
       'ascent/source-handles
       (lambda (_%value4708%_)
         (if (list? _%value4708%_)
             (let () (declare (not safe)) (andmap__0 symbol? _%value4708%_))
             '#f))))
    (define gerbil-ascent/program/types#GerbilAscentFragmentContract
      (let ((__obj35733
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35905
               (list (cons 'sexp
                           (let ((__tmp35906
                                  (lambda (_%@4642%_)
                                    'GerbilAscentFragmentContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35906)))
                     (cons 'identity
                           (let ((__tmp35907
                                  (lambda (_%@4648%_) 'ascent/fragment)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35907)))
                     (cons 'proto
                           (let ((__tmp35908
                                  (lambda (_%@4653%_)
                                    (let ((__obj35731
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35910 (list))
                                            (__tmp35909 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35910
                                         __tmp35909
                                         __obj35731))
                                      __obj35731))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35908)))
                     (cons 'responsibilities
                           (let ((__tmp35911
                                  (lambda (_%@4667%_)
                                    (let ((__obj35732
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35913
                                             (list (cons 'relations
                                                         (let ((__tmp35914
                                                                (lambda (_%self4686%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+relations+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35914)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'rules
                                                         (let ((__tmp35915
                                                                (lambda (_%self4693%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+rules+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35915)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'exports
                                                         (let ((__tmp35916
                                                                (lambda (_%self4698%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+fragment-exports+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35916)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'source-handles
                                                         (let ((__tmp35917
                                                                (lambda (_%self4703%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+source-handles+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35917)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35912 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35913
                                         __tmp35912
                                         __obj35732))
                                      __obj35732))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35911)))))
              (__tmp35904 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35905
           __tmp35904
           __obj35733))
        __obj35733))
    (define gerbil-ascent/program/types#GerbilAscentProgramContract
      (let ((__obj35736
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35919
               (list (cons 'sexp
                           (let ((__tmp35920
                                  (lambda (_%@4551%_)
                                    'GerbilAscentProgramContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35920)))
                     (cons 'identity
                           (let ((__tmp35921
                                  (lambda (_%@4557%_) 'ascent/program)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35921)))
                     (cons 'proto
                           (let ((__tmp35922
                                  (lambda (_%@4562%_)
                                    (let ((__obj35734
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35924 (list))
                                            (__tmp35923 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35924
                                         __tmp35923
                                         __obj35734))
                                      __obj35734))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35922)))
                     (cons 'responsibilities
                           (let ((__tmp35925
                                  (lambda (_%@4576%_)
                                    (let ((__obj35735
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35927
                                             (list (cons 'relations
                                                         (let ((__tmp35928
                                                                (lambda (_%self4597%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+relations+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35928)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'rules
                                                         (let ((__tmp35929
                                                                (lambda (_%self4604%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+rules+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35929)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'source-handles
                                                         (let ((__tmp35930
                                                                (lambda (_%self4609%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+source-handles+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35930)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'max-input-facts
                                                         (let ((__tmp35931
                                                                (lambda (_%self4614%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+fact-budget+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35931)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'max-derived-facts
                                                         (let ((__tmp35932
                                                                (lambda (_%self4619%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+fact-budget+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35932)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'max-output-facts
                                                         (let ((__tmp35933
                                                                (lambda (_%self4624%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+fact-budget+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35933)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35926 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35927
                                         __tmp35926
                                         __obj35735))
                                      __obj35735))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35925)))))
              (__tmp35918 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35919
           __tmp35918
           __obj35736))
        __obj35736))
    (define gerbil-ascent/program/types#gerbil-ascent-owned-root-contract
      (lambda (_%root4363%_)
        (let* ((_%accepted4365%_
                (let () (declare (not safe)) (make-hash-table-eq)))
               (_%owned-terms4374%_
                (gerbil-ascent/program/types#slot-contract
                 'ascent/terms
                 (lambda (_%value4367%_)
                   (if (list? _%value4367%_)
                       (let ((__tmp35934
                              (lambda (_%term4369%_)
                                (let ((_%$e4371%_
                                       (let ()
                                         (declare (not safe))
                                         (__hash-get
                                          _%accepted4365%_
                                          _%term4369%_))))
                                  (if _%$e4371%_
                                      _%$e4371%_
                                      (if (let ()
                                            (declare (not safe))
                                            (clan/poo/mop#element?
                                             gerbil-ascent/program/types#GerbilAscentTermContract
                                             _%term4369%_))
                                          (begin
                                            (let ()
                                              (declare (not safe))
                                              (__hash-put!
                                               _%accepted4365%_
                                               _%term4369%_
                                               '#t))
                                            '#t)
                                          '#f))))))
                         (declare (not safe))
                         (andmap__0 __tmp35934 _%value4367%_))
                       '#f))))
               (_%owned-atom4418%_
                (let ((__obj35738
                       (let ()
                         (declare (not safe))
                         (##structure
                          clan/poo/object#object::t
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f))))
                  (let ((__tmp35936
                         (list (cons 'proto
                                     (let ((__tmp35937
                                            (lambda (_%@4390%_)
                                              (let ()
                                                (declare (not safe))
                                                (clan/poo/object#.ref
                                                 gerbil-ascent/program/types#GerbilAscentAtomContract
                                                 'proto)))))
                                       (declare (not safe))
                                       (##structure
                                        clan/poo/object#$self-slot-spec::t
                                        __tmp35937)))
                               (cons 'responsibilities
                                     (let ((__tmp35938
                                            (lambda (_%@4396%_)
                                              (let ((__obj35737
                                                     (let ()
                                                       (declare (not safe))
                                                       (##structure
                                                        clan/poo/object#object::t
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f))))
                                                (let ((__tmp35942
                                                       (let ()
                                                         (declare (not safe))
                                                         (clan/poo/object#.ref
                                                          gerbil-ascent/program/types#GerbilAscentAtomContract
                                                          'responsibilities)))
                                                      (__tmp35940
                                                       (list (cons 'terms
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ((__tmp35941
                                  (lambda (_%@4412%_) _%owned-terms4374%_)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35941)))))
              (__tmp35939 (list)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (declare (not safe))
                                                  (clan/poo/object#object:::init!__%
                                                   '#f
                                                   __tmp35942
                                                   __tmp35940
                                                   __tmp35939
                                                   __obj35737))
                                                __obj35737))))
                                       (declare (not safe))
                                       (##structure
                                        clan/poo/object#$self-slot-spec::t
                                        __tmp35938)))))
                        (__tmp35935 (list)))
                    (declare (not safe))
                    (clan/poo/object#object:::init!__%
                     '#f
                     gerbil-ascent/program/types#GerbilAscentAtomContract
                     __tmp35936
                     __tmp35935
                     __obj35738))
                  __obj35738))
               (_%owned-heads4426%_
                (gerbil-ascent/program/types#slot-contract
                 'ascent/heads
                 (lambda (_%value4420%_)
                   (if (pair? _%value4420%_)
                       (let ((__tmp35943
                              (lambda (_%$%g44214423%_)
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/mop#element?
                                   _%owned-atom4418%_
                                   _%$%g44214423%_)))))
                         (declare (not safe))
                         (andmap__0 __tmp35943 _%value4420%_))
                       '#f))))
               (_%owned-body4435%_
                (gerbil-ascent/program/types#slot-contract
                 'ascent/clauses
                 (lambda (_%value4428%_)
                   (if (list? _%value4428%_)
                       (let ((__tmp35944
                              (lambda (_%clause4430%_)
                                (let ((_%$e4432%_
                                       (let ()
                                         (declare (not safe))
                                         (clan/poo/mop#element?
                                          _%owned-atom4418%_
                                          _%clause4430%_))))
                                  (if _%$e4432%_
                                      _%$e4432%_
                                      (let ((__tmp35945 (list _%clause4430%_)))
                                        (declare (not safe))
                                        (clan/poo/mop#element?
                                         gerbil-ascent/program/types#+clauses+
                                         __tmp35945)))))))
                         (declare (not safe))
                         (andmap__0 __tmp35944 _%value4428%_))
                       '#f))))
               (_%owned-rule4485%_
                (let ((__obj35740
                       (let ()
                         (declare (not safe))
                         (##structure
                          clan/poo/object#object::t
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f))))
                  (let ((__tmp35947
                         (list (cons 'proto
                                     (let ((__tmp35948
                                            (lambda (_%@4451%_)
                                              (let ()
                                                (declare (not safe))
                                                (clan/poo/object#.ref
                                                 gerbil-ascent/program/types#GerbilAscentRuleContract
                                                 'proto)))))
                                       (declare (not safe))
                                       (##structure
                                        clan/poo/object#$self-slot-spec::t
                                        __tmp35948)))
                               (cons 'responsibilities
                                     (let ((__tmp35949
                                            (lambda (_%@4457%_)
                                              (let ((__obj35739
                                                     (let ()
                                                       (declare (not safe))
                                                       (##structure
                                                        clan/poo/object#object::t
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f))))
                                                (let ((__tmp35954
                                                       (let ()
                                                         (declare (not safe))
                                                         (clan/poo/object#.ref
                                                          gerbil-ascent/program/types#GerbilAscentRuleContract
                                                          'responsibilities)))
                                                      (__tmp35951
                                                       (list (cons 'heads
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ((__tmp35952
                                  (lambda (_%@4474%_) _%owned-heads4426%_)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35952)))
                     (cons 'body
                           (let ((__tmp35953
                                  (lambda (_%@4480%_) _%owned-body4435%_)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35953)))))
              (__tmp35950 (list)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (declare (not safe))
                                                  (clan/poo/object#object:::init!__%
                                                   '#f
                                                   __tmp35954
                                                   __tmp35951
                                                   __tmp35950
                                                   __obj35739))
                                                __obj35739))))
                                       (declare (not safe))
                                       (##structure
                                        clan/poo/object#$self-slot-spec::t
                                        __tmp35949)))))
                        (__tmp35946 (list)))
                    (declare (not safe))
                    (clan/poo/object#object:::init!__%
                     '#f
                     gerbil-ascent/program/types#GerbilAscentRuleContract
                     __tmp35947
                     __tmp35946
                     __obj35740))
                  __obj35740))
               (_%owned-rules4493%_
                (gerbil-ascent/program/types#slot-contract
                 'ascent/rules
                 (lambda (_%value4487%_)
                   (if (list? _%value4487%_)
                       (let ((__tmp35955
                              (lambda (_%$%g44884490%_)
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/mop#element?
                                   _%owned-rule4485%_
                                   _%$%g44884490%_)))))
                         (declare (not safe))
                         (andmap__0 __tmp35955 _%value4487%_))
                       '#f))))
               (__obj35742
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
          (let ((__tmp35957
                 (list (cons 'proto
                             (let ((__tmp35958
                                    (lambda (_%@4510%_)
                                      (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%root4363%_
                                         'proto)))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp35958)))
                       (cons 'responsibilities
                             (let ((__tmp35959
                                    (lambda (_%@4516%_)
                                      (let ((__obj35741
                                             (let ()
                                               (declare (not safe))
                                               (##structure
                                                clan/poo/object#object::t
                                                '#f
                                                '#f
                                                '#f
                                                '#f
                                                '#f
                                                '#f
                                                '#f))))
                                        (let ((__tmp35963
                                               (let ()
                                                 (declare (not safe))
                                                 (clan/poo/object#.ref
                                                  _%root4363%_
                                                  'responsibilities)))
                                              (__tmp35961
                                               (list (cons 'rules
                                                           (let ((__tmp35962
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (lambda (_%@4532%_) _%owned-rules4493%_)))
                     (declare (not safe))
                     (##structure
                      clan/poo/object#$self-slot-spec::t
                      __tmp35962)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (__tmp35960 (list)))
                                          (declare (not safe))
                                          (clan/poo/object#object:::init!__%
                                           '#f
                                           __tmp35963
                                           __tmp35961
                                           __tmp35960
                                           __obj35741))
                                        __obj35741))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp35959)))))
                (__tmp35956 (list)))
            (declare (not safe))
            (clan/poo/object#object:::init!__%
             '#f
             _%root4363%_
             __tmp35957
             __tmp35956
             __obj35742))
          __obj35742)))
    (define gerbil-ascent/program/types#GerbilAscentSessionContract
      (let ((__obj35745
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35965
               (list (cons 'sexp
                           (let ((__tmp35966
                                  (lambda (_%@4303%_)
                                    'GerbilAscentSessionContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35966)))
                     (cons 'identity
                           (let ((__tmp35967
                                  (lambda (_%@4309%_) 'ascent/session)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35967)))
                     (cons 'proto
                           (let ((__tmp35968
                                  (lambda (_%@4314%_)
                                    (let ((__obj35743
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35970 (list))
                                            (__tmp35969 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35970
                                         __tmp35969
                                         __obj35743))
                                      __obj35743))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35968)))
                     (cons 'responsibilities
                           (let ((__tmp35971
                                  (lambda (_%@4328%_)
                                    (let ((__obj35744
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35973
                                             (list (cons '.append-source!
                                                         (let ((__tmp35974
                                                                (lambda (_%self4346%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35974)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.replace-source!
                                                         (let ((__tmp35975
                                                                (lambda (_%self4353%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35975)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.run
                                                         (let ((__tmp35976
                                                                (lambda (_%self4358%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35976)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35972 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35973
                                         __tmp35972
                                         __obj35744))
                                      __obj35744))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35971)))))
              (__tmp35964 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35965
           __tmp35964
           __obj35745))
        __obj35745))))
