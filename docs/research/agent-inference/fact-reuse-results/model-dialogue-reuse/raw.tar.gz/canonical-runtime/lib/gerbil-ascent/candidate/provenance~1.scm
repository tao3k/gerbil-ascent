(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/provenance[1]#_g34018_|
    (##structure
     gx#syntax-quote::t
     'positive-proof::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34020_|
    (##structure
     gx#syntax-quote::t
     'make-positive-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34022_|
    (##structure
     gx#syntax-quote::t
     'positive-proof?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34024_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34025_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34026_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34027_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34028_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34029_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34030_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34031_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34032_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34034_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34035_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34036_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34037_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34038_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34039_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34040_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34041_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34042_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34044_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34045_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34046_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34047_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34048_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34049_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34050_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34051_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34052_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34054_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34055_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34056_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34057_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34058_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34059_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34060_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34061_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34062_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34064_|
    (##structure
     gx#syntax-quote::t
     'proof-node::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34066_|
    (##structure
     gx#syntax-quote::t
     'make-proof-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34068_|
    (##structure
     gx#syntax-quote::t
     'proof-node?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34070_|
    (##structure
     gx#syntax-quote::t
     'proof-node-id
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34071_|
    (##structure
     gx#syntax-quote::t
     'proof-node-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34072_|
    (##structure
     gx#syntax-quote::t
     'proof-node-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34073_|
    (##structure
     gx#syntax-quote::t
     'proof-node-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34074_|
    (##structure
     gx#syntax-quote::t
     'proof-node-label
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34075_|
    (##structure
     gx#syntax-quote::t
     'proof-node-inputs
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34077_|
    (##structure
     gx#syntax-quote::t
     'proof-node-id-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34078_|
    (##structure
     gx#syntax-quote::t
     'proof-node-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34079_|
    (##structure
     gx#syntax-quote::t
     'proof-node-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34080_|
    (##structure
     gx#syntax-quote::t
     'proof-node-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34081_|
    (##structure
     gx#syntax-quote::t
     'proof-node-label-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34082_|
    (##structure
     gx#syntax-quote::t
     'proof-node-inputs-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34084_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-id
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34085_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34086_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34087_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34088_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-label
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34089_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-inputs
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34091_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-id-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34092_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34093_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34094_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34095_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-label-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34096_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-inputs-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34098_|
    (##structure
     gx#syntax-quote::t
     'proof-relation::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34100_|
    (##structure
     gx#syntax-quote::t
     'make-proof-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34102_|
    (##structure
     gx#syntax-quote::t
     'proof-relation?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34104_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34105_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-tail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34106_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34108_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34109_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-tail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34110_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34112_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34113_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-tail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34114_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34116_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34117_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-tail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34118_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34120_|
    (##structure
     gx#syntax-quote::t
     'positive-rule-replay::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34122_|
    (##structure
     gx#syntax-quote::t
     'make-positive-rule-replay
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34124_|
    (##structure
     gx#syntax-quote::t
     'positive-rule-replay?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34126_|
    (##structure
     gx#syntax-quote::t
     'positive-rule-replay-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34127_|
    (##structure
     gx#syntax-quote::t
     'positive-rule-replay-input-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34128_|
    (##structure
     gx#syntax-quote::t
     'positive-rule-replay-execute
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34130_|
    (##structure
     gx#syntax-quote::t
     'positive-rule-replay-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34131_|
    (##structure
     gx#syntax-quote::t
     'positive-rule-replay-input-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34132_|
    (##structure
     gx#syntax-quote::t
     'positive-rule-replay-execute-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34134_|
    (##structure
     gx#syntax-quote::t
     '&positive-rule-replay-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34135_|
    (##structure
     gx#syntax-quote::t
     '&positive-rule-replay-input-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34136_|
    (##structure
     gx#syntax-quote::t
     '&positive-rule-replay-execute
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34138_|
    (##structure
     gx#syntax-quote::t
     '&positive-rule-replay-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34139_|
    (##structure
     gx#syntax-quote::t
     '&positive-rule-replay-input-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34140_|
    (##structure
     gx#syntax-quote::t
     '&positive-rule-replay-execute-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/provenance[:0:]#positive-proof|
      (let ((__obj33953
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33953
           'gerbil-ascent/candidate/provenance#positive-proof::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33953 'positive-proof '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33953
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    work-budget
                    nodes
                    roots)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33953
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    work-budget
                    nodes
                    roots)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33953 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33953 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33953 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33953 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33953 '#f '13 '#f '#f))
        (let ((__tmp34017 |gerbil-ascent/candidate/provenance[1]#_g34018_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33953 __tmp34017 '4 '#f '#f))
        (let ((__tmp34019 |gerbil-ascent/candidate/provenance[1]#_g34020_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33953 __tmp34019 '14 '#f '#f))
        (let ((__tmp34021 |gerbil-ascent/candidate/provenance[1]#_g34022_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33953 __tmp34021 '15 '#f '#f))
        (let ((__tmp34023
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g34024_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g34025_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g34026_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g34027_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g34028_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g34029_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g34030_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g34031_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g34032_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33953 __tmp34023 '16 '#f '#f))
        (let ((__tmp34033
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g34034_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g34035_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g34036_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g34037_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g34038_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g34039_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g34040_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g34041_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g34042_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33953 __tmp34033 '17 '#f '#f))
        (let ((__tmp34043
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g34044_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g34045_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g34046_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g34047_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g34048_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g34049_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g34050_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g34051_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g34052_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33953 __tmp34043 '18 '#f '#f))
        (let ((__tmp34053
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g34054_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g34055_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g34056_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g34057_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g34058_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g34059_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g34060_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g34061_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g34062_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33953 __tmp34053 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33953 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33953 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33953 '() '21 '#f '#f))
        __obj33953))
    (define |gerbil-ascent/candidate/provenance[:0:]#proof-node|
      (let ((__obj33954
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33954
           'gerbil-ascent/candidate/provenance#proof-node::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33954 'proof-node '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33954
           '(id kind relation row label inputs)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33954
           '(id kind relation row label inputs)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33954 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33954 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33954 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33954 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33954 '#f '13 '#f '#f))
        (let ((__tmp34063 |gerbil-ascent/candidate/provenance[1]#_g34064_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33954 __tmp34063 '4 '#f '#f))
        (let ((__tmp34065 |gerbil-ascent/candidate/provenance[1]#_g34066_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33954 __tmp34065 '14 '#f '#f))
        (let ((__tmp34067 |gerbil-ascent/candidate/provenance[1]#_g34068_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33954 __tmp34067 '15 '#f '#f))
        (let ((__tmp34069
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g34070_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g34071_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g34072_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g34073_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g34074_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g34075_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33954 __tmp34069 '16 '#f '#f))
        (let ((__tmp34076
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g34077_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g34078_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g34079_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g34080_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g34081_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g34082_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33954 __tmp34076 '17 '#f '#f))
        (let ((__tmp34083
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g34084_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g34085_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g34086_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g34087_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g34088_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g34089_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33954 __tmp34083 '18 '#f '#f))
        (let ((__tmp34090
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g34091_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g34092_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g34093_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g34094_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g34095_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g34096_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33954 __tmp34090 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33954 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33954 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33954 '() '21 '#f '#f))
        __obj33954))
    (define |gerbil-ascent/candidate/provenance[:0:]#proof-relation|
      (let ((__obj33955
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33955
           'gerbil-ascent/candidate/provenance#proof-relation::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33955 'proof-relation '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33955
           '(nodes tail members)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33955
           '(nodes tail members)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33955 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33955 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33955 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33955 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33955 '#f '13 '#f '#f))
        (let ((__tmp34097 |gerbil-ascent/candidate/provenance[1]#_g34098_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33955 __tmp34097 '4 '#f '#f))
        (let ((__tmp34099 |gerbil-ascent/candidate/provenance[1]#_g34100_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33955 __tmp34099 '14 '#f '#f))
        (let ((__tmp34101 |gerbil-ascent/candidate/provenance[1]#_g34102_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33955 __tmp34101 '15 '#f '#f))
        (let ((__tmp34103
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g34104_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g34105_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g34106_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33955 __tmp34103 '16 '#f '#f))
        (let ((__tmp34107
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g34108_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g34109_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g34110_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33955 __tmp34107 '17 '#f '#f))
        (let ((__tmp34111
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g34112_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g34113_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g34114_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33955 __tmp34111 '18 '#f '#f))
        (let ((__tmp34115
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g34116_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g34117_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g34118_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33955 __tmp34115 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33955 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33955 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33955 '() '21 '#f '#f))
        __obj33955))
    (define |gerbil-ascent/candidate/provenance[:0:]#positive-rule-replay|
      (let ((__obj33956
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33956
           'gerbil-ascent/candidate/provenance#positive-rule-replay::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33956
           'positive-rule-replay
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33956
           '(relation input-count execute)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33956
           '(relation input-count execute)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33956 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33956 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33956 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33956 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33956 '#f '13 '#f '#f))
        (let ((__tmp34119 |gerbil-ascent/candidate/provenance[1]#_g34120_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33956 __tmp34119 '4 '#f '#f))
        (let ((__tmp34121 |gerbil-ascent/candidate/provenance[1]#_g34122_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33956 __tmp34121 '14 '#f '#f))
        (let ((__tmp34123 |gerbil-ascent/candidate/provenance[1]#_g34124_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33956 __tmp34123 '15 '#f '#f))
        (let ((__tmp34125
               (cons (cons 'relation
                           |gerbil-ascent/candidate/provenance[1]#_g34126_|)
                     (cons (cons 'input-count
                                 |gerbil-ascent/candidate/provenance[1]#_g34127_|)
                           (cons (cons 'execute
                                       |gerbil-ascent/candidate/provenance[1]#_g34128_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33956 __tmp34125 '16 '#f '#f))
        (let ((__tmp34129
               (cons (cons 'relation
                           |gerbil-ascent/candidate/provenance[1]#_g34130_|)
                     (cons (cons 'input-count
                                 |gerbil-ascent/candidate/provenance[1]#_g34131_|)
                           (cons (cons 'execute
                                       |gerbil-ascent/candidate/provenance[1]#_g34132_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33956 __tmp34129 '17 '#f '#f))
        (let ((__tmp34133
               (cons (cons 'relation
                           |gerbil-ascent/candidate/provenance[1]#_g34134_|)
                     (cons (cons 'input-count
                                 |gerbil-ascent/candidate/provenance[1]#_g34135_|)
                           (cons (cons 'execute
                                       |gerbil-ascent/candidate/provenance[1]#_g34136_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33956 __tmp34133 '18 '#f '#f))
        (let ((__tmp34137
               (cons (cons 'relation
                           |gerbil-ascent/candidate/provenance[1]#_g34138_|)
                     (cons (cons 'input-count
                                 |gerbil-ascent/candidate/provenance[1]#_g34139_|)
                           (cons (cons 'execute
                                       |gerbil-ascent/candidate/provenance[1]#_g34140_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33956 __tmp34137 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33956 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33956 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33956 '() '21 '#f '#f))
        __obj33956))))
