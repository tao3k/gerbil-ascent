(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34572_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34574_|
    (##structure
     gx#syntax-quote::t
     'make-evidence-entry
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34576_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34578_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34579_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-candidate
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34580_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-receipt
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34581_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-handle
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34583_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-snapshot-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34584_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-candidate-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34585_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-receipt-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34586_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-handle-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34588_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34589_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-candidate
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34590_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-receipt
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34591_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-handle
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34593_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-snapshot-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34594_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-candidate-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34595_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-receipt-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34596_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-handle-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[:0:]#evidence-entry|
    (let ((__obj34483
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34483
         'gerbil-ascent/candidate/evidence-store#evidence-entry::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34483 'evidence-entry '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34483
         '(snapshot candidate receipt handle)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34483
         '(snapshot candidate receipt handle)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34483 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34483 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34483 '#t '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34483 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34483 '#f '13 '#f '#f))
      (let ((__tmp34571 |gerbil-ascent/candidate/evidence-store[1]#_g34572_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34483 __tmp34571 '4 '#f '#f))
      (let ((__tmp34573 |gerbil-ascent/candidate/evidence-store[1]#_g34574_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34483 __tmp34573 '14 '#f '#f))
      (let ((__tmp34575 |gerbil-ascent/candidate/evidence-store[1]#_g34576_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34483 __tmp34575 '15 '#f '#f))
      (let ((__tmp34577
             (cons (cons 'snapshot
                         |gerbil-ascent/candidate/evidence-store[1]#_g34578_|)
                   (cons (cons 'candidate
                               |gerbil-ascent/candidate/evidence-store[1]#_g34579_|)
                         (cons (cons 'receipt
                                     |gerbil-ascent/candidate/evidence-store[1]#_g34580_|)
                               (cons (cons 'handle
                                           |gerbil-ascent/candidate/evidence-store[1]#_g34581_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34483 __tmp34577 '16 '#f '#f))
      (let ((__tmp34582
             (cons (cons 'snapshot
                         |gerbil-ascent/candidate/evidence-store[1]#_g34583_|)
                   (cons (cons 'candidate
                               |gerbil-ascent/candidate/evidence-store[1]#_g34584_|)
                         (cons (cons 'receipt
                                     |gerbil-ascent/candidate/evidence-store[1]#_g34585_|)
                               (cons (cons 'handle
                                           |gerbil-ascent/candidate/evidence-store[1]#_g34586_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34483 __tmp34582 '17 '#f '#f))
      (let ((__tmp34587
             (cons (cons 'snapshot
                         |gerbil-ascent/candidate/evidence-store[1]#_g34588_|)
                   (cons (cons 'candidate
                               |gerbil-ascent/candidate/evidence-store[1]#_g34589_|)
                         (cons (cons 'receipt
                                     |gerbil-ascent/candidate/evidence-store[1]#_g34590_|)
                               (cons (cons 'handle
                                           |gerbil-ascent/candidate/evidence-store[1]#_g34591_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34483 __tmp34587 '18 '#f '#f))
      (let ((__tmp34592
             (cons (cons 'snapshot
                         |gerbil-ascent/candidate/evidence-store[1]#_g34593_|)
                   (cons (cons 'candidate
                               |gerbil-ascent/candidate/evidence-store[1]#_g34594_|)
                         (cons (cons 'receipt
                                     |gerbil-ascent/candidate/evidence-store[1]#_g34595_|)
                               (cons (cons 'handle
                                           |gerbil-ascent/candidate/evidence-store[1]#_g34596_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34483 __tmp34592 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34483 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34483 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34483 '() '21 '#f '#f))
      __obj34483)))
