prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/candidate

(begin
  (declare-type
   gerbil-ascent/candidate/funs#candidate-same-row-set?
   (@lambda 2
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/funs)))
  (declare-type
   gerbil-ascent/candidate/funs#candidate-schema-of
   (@lambda 2
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/funs)))
  (declare-type
   gerbil-ascent/candidate/funs#candidate-required-entry
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/funs)))
  (declare-type
   gerbil-ascent/candidate/funs#candidate-bind-atom
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/funs)))
  (declare-type
   gerbil-ascent/candidate/funs#candidate-fixed-clause
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/funs)))
  (declare-type
   gerbil-ascent/candidate/funs#candidate-strata-of
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/funs))))
