(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/trrel::timestamp 1791691003)
  (begin
    (define gerbil-ascent/table/trrel#trrel-state::t
      (let ((__tmp35174 (list)) (__tmp35173 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/trrel#trrel-state::t
         'trrel-state
         __tmp35174
         '(known predecessors successors)
         __tmp35173
         '#f)))
    (define gerbil-ascent/table/trrel#trrel-state?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/trrel#trrel-state::t)))
    (define gerbil-ascent/table/trrel#make-trrel-state
      (lambda _%$args1419%_
        (apply make-instance
               gerbil-ascent/table/trrel#trrel-state::t
               _%$args1419%_)))
    (define gerbil-ascent/table/trrel#trrel-state-known
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel#trrel-state::t
         'known)))
    (define gerbil-ascent/table/trrel#trrel-state-predecessors
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel#trrel-state::t
         'predecessors)))
    (define gerbil-ascent/table/trrel#trrel-state-successors
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel#trrel-state::t
         'successors)))
    (define gerbil-ascent/table/trrel#trrel-state-known-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel#trrel-state::t
         'known)))
    (define gerbil-ascent/table/trrel#trrel-state-predecessors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel#trrel-state::t
         'predecessors)))
    (define gerbil-ascent/table/trrel#trrel-state-successors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel#trrel-state::t
         'successors)))
    (define gerbil-ascent/table/trrel#&trrel-state-known
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel#trrel-state::t
         'known)))
    (define gerbil-ascent/table/trrel#&trrel-state-predecessors
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel#trrel-state::t
         'predecessors)))
    (define gerbil-ascent/table/trrel#&trrel-state-successors
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel#trrel-state::t
         'successors)))
    (define gerbil-ascent/table/trrel#&trrel-state-known-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel#trrel-state::t
         'known)))
    (define gerbil-ascent/table/trrel#&trrel-state-predecessors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel#trrel-state::t
         'predecessors)))
    (define gerbil-ascent/table/trrel#&trrel-state-successors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel#trrel-state::t
         'successors)))
    (define gerbil-ascent/table/trrel#gerbil-ascent-trrel-state
      (lambda ()
        (let ((__tmp35177
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value)))
              (__tmp35176
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value)))
              (__tmp35175
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (declare (not safe))
          (##structure
           gerbil-ascent/table/trrel#trrel-state::t
           __tmp35177
           __tmp35176
           __tmp35175))))
    (define gerbil-ascent/table/trrel#gerbil-ascent-trrel-extend
      (lambda (_%state1327%_ _%row1328%_ _%budget1329%_ _%reflexive?1330%_)
        (let* ((_%width1332%_ (length _%row1328%_))
               (_%_1334%_
                (if (let () (declare (not safe)) (##memq _%width1332%_ '(2 3)))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"ASCENT trrel requires two or three columns"
                             _%row1328%_))))
               (_%group1336%_ (if (= _%width1332%_ '3) (car _%row1328%_) '#f))
               (_%pair1338%_
                (if (= _%width1332%_ '3) (cdr _%row1328%_) _%row1328%_))
               (_%left1340%_ (car _%pair1338%_))
               (_%right1342%_ (cadr _%pair1338%_))
               (_%known1344%_
                (##structure-ref
                 _%state1327%_
                 '1
                 gerbil-ascent/table/trrel#trrel-state::t
                 '#f))
               (_%new-edge?1346%_
                (not (let ()
                       (declare (not safe))
                       (hash-get _%known1344%_ _%row1328%_))))
               (_%predecessors1348%_
                (##structure-ref
                 _%state1327%_
                 '2
                 gerbil-ascent/table/trrel#trrel-state::t
                 '#f))
               (_%successors1350%_
                (##structure-ref
                 _%state1327%_
                 '3
                 gerbil-ascent/table/trrel#trrel-state::t
                 '#f))
               (_%added1352%_ '())
               (_%planned1354%_ '#f)
               (_%planned-count1356%_ '0)
               (_%safe-budget?1358%_ '#f))
          (letrec ((_%node-key1361%_
                    (lambda (_%node1416%_)
                      (if (= _%width1332%_ '3)
                          (cons _%group1336%_ _%node1416%_)
                          _%node1416%_)))
                   (_%fact1362%_
                    (lambda (_%from1413%_ _%to1414%_)
                      (if (= _%width1332%_ '3)
                          (list _%group1336%_ _%from1413%_ _%to1414%_)
                          (list _%from1413%_ _%to1414%_))))
                   (_%with-root1363%_
                    (lambda (_%node1410%_ _%neighbors1411%_)
                      (if (let ((__tmp35178
                                 (_%fact1362%_ _%node1410%_ _%node1410%_)))
                            (declare (not safe))
                            (hash-get _%known1344%_ __tmp35178))
                          _%neighbors1411%_
                          (cons _%node1410%_ _%neighbors1411%_))))
                   (_%commit-fact!1364%_
                    (lambda (_%row1391%_)
                      (let* ((_%pair1393%_
                              (if (= _%width1332%_ '3)
                                  (cdr _%row1391%_)
                                  _%row1391%_))
                             (_%from1395%_ (car _%pair1393%_))
                             (_%to1397%_ (cadr _%pair1393%_))
                             (_%from-key1399%_ (_%node-key1361%_ _%from1395%_))
                             (_%to-key1401%_ (_%node-key1361%_ _%to1397%_)))
                        (let ()
                          (declare (not safe))
                          (hash-put! _%known1344%_ _%row1391%_ '#t))
                        (let ((__tmp35179
                               (cons _%to1397%_
                                     (let ((_%$e1404%_
                                            (let ()
                                              (declare (not safe))
                                              (hash-get
                                               _%successors1350%_
                                               _%from-key1399%_))))
                                       (if _%$e1404%_ _%$e1404%_ '())))))
                          (declare (not safe))
                          (hash-put!
                           _%successors1350%_
                           _%from-key1399%_
                           __tmp35179))
                        (let ((__tmp35180
                               (cons _%from1395%_
                                     (let ((_%$e1407%_
                                            (let ()
                                              (declare (not safe))
                                              (hash-get
                                               _%predecessors1348%_
                                               _%to-key1401%_))))
                                       (if _%$e1407%_ _%$e1407%_ '())))))
                          (declare (not safe))
                          (hash-put!
                           _%predecessors1348%_
                           _%to-key1401%_
                           __tmp35180)))))
                   (_%emit!1365%_
                    (lambda (_%from1383%_ _%to1384%_)
                      (let ((_%row1386%_
                             (_%fact1362%_ _%from1383%_ _%to1384%_)))
                        (if (or (let ()
                                  (declare (not safe))
                                  (hash-get _%known1344%_ _%row1386%_))
                                (and _%planned1354%_
                                     (let ()
                                       (declare (not safe))
                                       (hash-get
                                        _%planned1354%_
                                        _%row1386%_))))
                            '#!void
                            (begin
                              (if _%safe-budget?1358%_
                                  '#!void
                                  (begin
                                    (set! _%planned-count1356%_
                                          (+ _%planned-count1356%_ '1))
                                    (if (> _%planned-count1356%_
                                           _%budget1329%_)
                                        (let ()
                                          (declare (not safe))
                                          (error '"ASCENT trrel output fact budget exceeded"))
                                        '#!void)
                                    (let ()
                                      (declare (not safe))
                                      (hash-put!
                                       _%planned1354%_
                                       _%row1386%_
                                       '#t))))
                              (if _%safe-budget?1358%_
                                  (_%commit-fact!1364%_ _%row1386%_)
                                  '#!void)
                              (set! _%added1352%_
                                    (cons _%row1386%_ _%added1352%_))))))))
            (let ((_%from-nodes1373%_
                   (if _%new-edge?1346%_
                       (_%with-root1363%_
                        _%left1340%_
                        (let ((_%$e1367%_
                               (let ((__tmp35181
                                      (_%node-key1361%_ _%left1340%_)))
                                 (declare (not safe))
                                 (hash-get _%predecessors1348%_ __tmp35181))))
                          (if _%$e1367%_ _%$e1367%_ '())))
                       '()))
                  (_%to-nodes1374%_
                   (if _%new-edge?1346%_
                       (_%with-root1363%_
                        _%right1342%_
                        (let ((_%$e1370%_
                               (let ((__tmp35182
                                      (_%node-key1361%_ _%right1342%_)))
                                 (declare (not safe))
                                 (hash-get _%successors1350%_ __tmp35182))))
                          (if _%$e1370%_ _%$e1370%_ '())))
                       '())))
              (set! _%safe-budget?1358%_
                    (<= (+ (* (length _%from-nodes1373%_)
                              (length _%to-nodes1374%_))
                           (if _%reflexive?1330%_ '2 '0))
                        _%budget1329%_))
              (if _%safe-budget?1358%_
                  '#!void
                  (set! _%planned1354%_
                        (let ()
                          (declare (not safe))
                          (make-hash-table__%
                           '#f
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value))))
              (if _%new-edge?1346%_
                  (for-each
                   (lambda (_%from1376%_)
                     (for-each
                      (lambda (_%to1378%_)
                        (if (or (not (equal? _%from1376%_ _%to1378%_))
                                (and (equal? _%left1340%_ _%right1342%_)
                                     (equal? _%from1376%_ _%left1340%_)))
                            (_%emit!1365%_ _%from1376%_ _%to1378%_)
                            '#!void))
                      _%to-nodes1374%_))
                   _%from-nodes1373%_)
                  '#!void))
            (if _%reflexive?1330%_
                (begin
                  (_%emit!1365%_ _%left1340%_ _%left1340%_)
                  (_%emit!1365%_ _%right1342%_ _%right1342%_))
                '#!void)
            (if _%safe-budget?1358%_
                '#!void
                (let ()
                  (declare (not safe))
                  (##for-each _%commit-fact!1364%_ _%added1352%_)))
            (let () (declare (not safe)) (##reverse _%added1352%_))))))
    (define gerbil-ascent/table/trrel#gerbil-ascent-trrel-extension
      (lambda (_%state1321%_
               _%_all1322%_
               _%_pending1323%_
               _%row1324%_
               _%budget1325%_)
        (gerbil-ascent/table/trrel#gerbil-ascent-trrel-extend
         _%state1321%_
         _%row1324%_
         _%budget1325%_
         '#f)))))
