(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/storage[1]#_g35145_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35147_|
    (##structure
     gx#syntax-quote::t
     'make-storage-state-owner
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35149_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35151_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35152_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner-phase
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35154_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35155_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner-phase-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35157_|
    (##structure
     gx#syntax-quote::t
     '&storage-state-owner-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35158_|
    (##structure
     gx#syntax-quote::t
     '&storage-state-owner-phase
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35160_|
    (##structure
     gx#syntax-quote::t
     '&storage-state-owner-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g35161_|
    (##structure
     gx#syntax-quote::t
     '&storage-state-owner-phase-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[:0:]#storage-state-owner|
    (let ((__obj35099
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj35099
         'gerbil-ascent/table/storage#storage-state-owner::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj35099
         'storage-state-owner
         '3
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35099 '(value phase) '6 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35099 '(value phase) '8 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35099 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35099 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35099 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35099 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35099 '#f '13 '#f '#f))
      (let ((__tmp35144 |gerbil-ascent/table/storage[1]#_g35145_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35099 __tmp35144 '4 '#f '#f))
      (let ((__tmp35146 |gerbil-ascent/table/storage[1]#_g35147_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35099 __tmp35146 '14 '#f '#f))
      (let ((__tmp35148 |gerbil-ascent/table/storage[1]#_g35149_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35099 __tmp35148 '15 '#f '#f))
      (let ((__tmp35150
             (cons (cons 'value |gerbil-ascent/table/storage[1]#_g35151_|)
                   (cons (cons 'phase
                               |gerbil-ascent/table/storage[1]#_g35152_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35099 __tmp35150 '16 '#f '#f))
      (let ((__tmp35153
             (cons (cons 'value |gerbil-ascent/table/storage[1]#_g35154_|)
                   (cons (cons 'phase
                               |gerbil-ascent/table/storage[1]#_g35155_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35099 __tmp35153 '17 '#f '#f))
      (let ((__tmp35156
             (cons (cons 'value |gerbil-ascent/table/storage[1]#_g35157_|)
                   (cons (cons 'phase
                               |gerbil-ascent/table/storage[1]#_g35158_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35099 __tmp35156 '18 '#f '#f))
      (let ((__tmp35159
             (cons (cons 'value |gerbil-ascent/table/storage[1]#_g35160_|)
                   (cons (cons 'phase
                               |gerbil-ascent/table/storage[1]#_g35161_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35099 __tmp35159 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35099 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35099 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35099 '() '21 '#f '#f))
      __obj35099)))
