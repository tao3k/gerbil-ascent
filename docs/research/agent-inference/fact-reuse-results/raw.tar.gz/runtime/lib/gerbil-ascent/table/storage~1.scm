(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/storage[1]#_g8602_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g8604_|
    (##structure
     gx#syntax-quote::t
     'make-storage-state-owner
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g8606_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g8608_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g8609_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner-phase
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g8611_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g8612_|
    (##structure
     gx#syntax-quote::t
     'storage-state-owner-phase-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g8614_|
    (##structure
     gx#syntax-quote::t
     '&storage-state-owner-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g8615_|
    (##structure
     gx#syntax-quote::t
     '&storage-state-owner-phase
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g8617_|
    (##structure
     gx#syntax-quote::t
     '&storage-state-owner-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[1]#_g8618_|
    (##structure
     gx#syntax-quote::t
     '&storage-state-owner-phase-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/storage[:0:]#storage-state-owner|
    (let ((__obj8559
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj8559
         'gerbil-ascent/table/storage#storage-state-owner::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj8559 'storage-state-owner '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj8559 '(value phase) '6 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj8559 '(value phase) '8 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj8559 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj8559 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj8559 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj8559 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj8559 '#f '13 '#f '#f))
      (let ((__tmp8601 |gerbil-ascent/table/storage[1]#_g8602_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj8559 __tmp8601 '4 '#f '#f))
      (let ((__tmp8603 |gerbil-ascent/table/storage[1]#_g8604_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj8559 __tmp8603 '14 '#f '#f))
      (let ((__tmp8605 |gerbil-ascent/table/storage[1]#_g8606_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj8559 __tmp8605 '15 '#f '#f))
      (let ((__tmp8607
             (cons (cons 'value |gerbil-ascent/table/storage[1]#_g8608_|)
                   (cons (cons 'phase |gerbil-ascent/table/storage[1]#_g8609_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj8559 __tmp8607 '16 '#f '#f))
      (let ((__tmp8610
             (cons (cons 'value |gerbil-ascent/table/storage[1]#_g8611_|)
                   (cons (cons 'phase |gerbil-ascent/table/storage[1]#_g8612_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj8559 __tmp8610 '17 '#f '#f))
      (let ((__tmp8613
             (cons (cons 'value |gerbil-ascent/table/storage[1]#_g8614_|)
                   (cons (cons 'phase |gerbil-ascent/table/storage[1]#_g8615_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj8559 __tmp8613 '18 '#f '#f))
      (let ((__tmp8616
             (cons (cons 'value |gerbil-ascent/table/storage[1]#_g8617_|)
                   (cons (cons 'phase |gerbil-ascent/table/storage[1]#_g8618_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj8559 __tmp8616 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj8559 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj8559 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj8559 '() '21 '#f '#f))
      __obj8559)))
