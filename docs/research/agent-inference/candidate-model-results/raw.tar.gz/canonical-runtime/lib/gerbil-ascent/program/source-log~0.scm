(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/source-log::timestamp 1791689666)
  (begin
    (define gerbil-ascent/program/source-log#gerbil-ascent-source-log-rows
      (lambda (_%base11923%_ _%additions11924%_)
        (if (null? _%additions11924%_)
            _%base11923%_
            (let ((__tmp33546 (reverse _%additions11924%_)))
              (declare (not safe))
              (##append _%base11923%_ __tmp33546)))))
    (define gerbil-ascent/program/source-log#gerbil-ascent-source-log-equal?
      (lambda (_%base11914%_ _%additions11915%_ _%rows11916%_)
        (if (null? _%additions11915%_)
            (equal? _%base11914%_ _%rows11916%_)
            (let ((_%tail11921%_
                   (let ((__tmp33547
                          (lambda (_%row11918%_ _%remaining11919%_)
                            (if (pair? _%remaining11919%_)
                                (if (equal? _%row11918%_
                                            (let ()
                                              (declare (not safe))
                                              (##car _%remaining11919%_)))
                                    (let ()
                                      (declare (not safe))
                                      (##cdr _%remaining11919%_))
                                    '#f)
                                '#f))))
                     (declare (not safe))
                     (foldl__0 __tmp33547 _%rows11916%_ _%base11914%_))))
              (if _%tail11921%_
                  (equal? (reverse _%additions11915%_) _%tail11921%_)
                  '#f)))))))
