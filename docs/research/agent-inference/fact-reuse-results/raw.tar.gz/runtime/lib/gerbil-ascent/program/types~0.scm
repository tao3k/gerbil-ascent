(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/types::timestamp 1791686872)
  (begin
    (define gerbil-ascent/program/types#slot-contract
      (lambda (_%identity3239%_ _%predicate3240%_)
        (let ((__tmp6111 (lambda (_%_value3242%_ _%_context3243%_) '())))
          (declare (not safe))
          (core/types#poo-flow-predicate-contract
           _%identity3239%_
           _%predicate3240%_
           __tmp6111))))
    (define gerbil-ascent/program/types#+symbol+
      (gerbil-ascent/program/types#slot-contract 'ascent/symbol symbol?))
    (define gerbil-ascent/program/types#+arity+
      (gerbil-ascent/program/types#slot-contract
       'ascent/arity
       (lambda (_%value3237%_)
         (if (exact-integer? _%value3237%_) (<= '0 _%value3237%_) '#f))))
    (define gerbil-ascent/program/types#+fact-budget+
      (gerbil-ascent/program/types#slot-contract
       'ascent/fact-budget
       (lambda (_%value3235%_)
         (if (exact-integer? _%value3235%_) (> _%value3235%_ '0) '#f))))
    (define gerbil-ascent/program/types#+rows+
      (gerbil-ascent/program/types#slot-contract 'ascent/rows list?))
    (define gerbil-ascent/program/types#+field-predicates+
      (gerbil-ascent/program/types#slot-contract
       'ascent/field-predicates
       (lambda (_%value3233%_)
         (if (list? _%value3233%_)
             (let () (declare (not safe)) (andmap__0 procedure? _%value3233%_))
             '#f))))
    (define gerbil-ascent/program/types#+provider+
      (gerbil-ascent/program/types#slot-contract
       'ascent/index-provider
       (lambda (_%value3228%_)
         (let ((_%$e3230%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                   _%value3228%_))))
           (if _%$e3230%_
               _%$e3230%_
               (let ()
                 (declare (not safe))
                 (clan/poo/mop#element?
                  gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
                  _%value3228%_)))))))
    (define gerbil-ascent/program/types#+storage-provider+
      (gerbil-ascent/program/types#slot-contract
       'ascent/storage-provider
       (lambda (_%value3223%_)
         (let ((_%$e3225%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                   _%value3223%_))))
           (if _%$e3225%_
               _%$e3225%_
               (let ()
                 (declare (not safe))
                 (clan/poo/mop#element?
                  gerbil-ascent/table/storage#GerbilAscentStorageProviderContract
                  _%value3223%_)))))))
    (define gerbil-ascent/program/types#+term-kind+
      (gerbil-ascent/program/types#slot-contract
       'ascent/term-kind
       (lambda (_%value3221%_)
         (let ()
           (declare (not safe))
           (##memq _%value3221%_
                   '(variable wildcard literal expression pattern))))))
    (define gerbil-ascent/program/types#+any+
      (gerbil-ascent/program/types#slot-contract
       'ascent/value
       (lambda (_%_value3219%_) '#t)))
    (define gerbil-ascent/program/types#+plan+
      (gerbil-ascent/program/types#slot-contract
       'ascent/clause-plan
       procedure?))
    (define gerbil-ascent/program/types#clause-kind-contract
      (lambda (_%kind3215%_)
        (gerbil-ascent/program/types#slot-contract
         'ascent/clause-kind
         (lambda (_%value3217%_) (eq? _%value3217%_ _%kind3215%_)))))
    (define gerbil-ascent/program/types#GerbilAscentRelationContract
      (let ((__obj6068
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp6113
               (list (cons 'sexp
                           (let ((__tmp6114
                                  (lambda (_%@3131%_)
                                    'GerbilAscentRelationContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6114)))
                     (cons 'identity
                           (let ((__tmp6115
                                  (lambda (_%@3137%_) 'ascent/relation)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6115)))
                     (cons 'proto
                           (let ((__tmp6116
                                  (lambda (_%@3142%_)
                                    (let ((__obj6066
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6118 (list))
                                            (__tmp6117 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6118
                                         __tmp6117
                                         __obj6066))
                                      __obj6066))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6116)))
                     (cons 'responsibilities
                           (let ((__tmp6119
                                  (lambda (_%@3156%_)
                                    (let ((__obj6067
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6121
                                             (list (cons 'name
                                                         (let ((__tmp6122
                                                                (lambda (_%self3178%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6122)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'arity
                                                         (let ((__tmp6123
                                                                (lambda (_%self3185%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+arity+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6123)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'rows
                                                         (let ((__tmp6124
                                                                (lambda (_%self3190%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+rows+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6124)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'field-predicates
                                                         (let ((__tmp6125
                                                                (lambda (_%self3195%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+field-predicates+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6125)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'storage-kind
                                                         (let ((__tmp6126
                                                                (lambda (_%self3200%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'relation))))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6126)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'index-provider
                                                         (let ((__tmp6127
                                                                (lambda (_%self3205%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+provider+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6127)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'storage-provider
                                                         (let ((__tmp6128
                                                                (lambda (_%self3210%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+storage-provider+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp6128)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp6120 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6121
                                         __tmp6120
                                         __obj6067))
                                      __obj6067))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6119)))))
              (__tmp6112 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp6113
           __tmp6112
           __obj6068))
        __obj6068))
    (define gerbil-ascent/program/types#GerbilAscentLatticeContract
      (let ((__obj6071
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp6130
               (list (cons 'sexp
                           (let ((__tmp6131
                                  (lambda (_%@3023%_)
                                    'GerbilAscentLatticeContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6131)))
                     (cons 'identity
                           (let ((__tmp6132
                                  (lambda (_%@3029%_) 'ascent/lattice)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6132)))
                     (cons 'proto
                           (let ((__tmp6133
                                  (lambda (_%@3034%_)
                                    (let ((__obj6069
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6135 (list))
                                            (__tmp6134 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6135
                                         __tmp6134
                                         __obj6069))
                                      __obj6069))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6133)))
                     (cons 'responsibilities
                           (let ((__tmp6136
                                  (lambda (_%@3048%_)
                                    (let ((__obj6070
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6138
                                             (list (cons 'name
                                                         (let ((__tmp6139
                                                                (lambda (_%self3071%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6139)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'arity
                                                         (let ((__tmp6140
                                                                (lambda (_%self3078%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+arity+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6140)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'rows
                                                         (let ((__tmp6141
                                                                (lambda (_%self3083%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+rows+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6141)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'field-predicates
                                                         (let ((__tmp6142
                                                                (lambda (_%self3088%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+field-predicates+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6142)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'storage-kind
                                                         (let ((__tmp6143
                                                                (lambda (_%self3093%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'lattice))))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6143)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'join
                                                         (let ((__tmp6144
                                                                (lambda (_%self3098%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#slot-contract
                           'ascent/lattice-join
                           procedure?))))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6144)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'checked-operator
                                                         (let ((__tmp6145
                                                                (lambda (_%self3103%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#slot-contract
                           'ascent/lattice-checked-operator
                           (lambda (_%value3108%_)
                             (let ((_%$e3110%_ (not _%value3108%_)))
                               (if _%$e3110%_
                                   _%$e3110%_
                                   (vector? _%value3108%_))))))))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6145)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'index-provider
                                                         (let ((__tmp6146
                                                                (lambda (_%self3113%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+provider+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp6146)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp6137 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6138
                                         __tmp6137
                                         __obj6070))
                                      __obj6070))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6136)))))
              (__tmp6129 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp6130
           __tmp6129
           __obj6071))
        __obj6071))
    (define gerbil-ascent/program/types#GerbilAscentTermContract
      (let ((__obj6074
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp6148
               (list (cons 'sexp
                           (let ((__tmp6149
                                  (lambda (_%@2956%_)
                                    'GerbilAscentTermContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6149)))
                     (cons 'identity
                           (let ((__tmp6150 (lambda (_%@2962%_) 'ascent/term)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6150)))
                     (cons 'proto
                           (let ((__tmp6151
                                  (lambda (_%@2967%_)
                                    (let ((__obj6072
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6153 (list))
                                            (__tmp6152 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6153
                                         __tmp6152
                                         __obj6072))
                                      __obj6072))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6151)))
                     (cons 'responsibilities
                           (let ((__tmp6154
                                  (lambda (_%@2981%_)
                                    (let ((__obj6073
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6156
                                             (list (cons 'kind
                                                         (let ((__tmp6157
                                                                (lambda (_%self2998%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+term-kind+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6157)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'value
                                                         (let ((__tmp6158
                                                                (lambda (_%self3005%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+any+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp6158)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp6155 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6156
                                         __tmp6155
                                         __obj6073))
                                      __obj6073))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6154)))))
              (__tmp6147 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp6148
           __tmp6147
           __obj6074))
        __obj6074))
    (define gerbil-ascent/program/types#+terms+
      (gerbil-ascent/program/types#slot-contract
       'ascent/terms
       (lambda (_%value2939%_)
         (if (list? _%value2939%_)
             (let ((__tmp6159
                    (lambda (_%term2941%_)
                      (let ()
                        (declare (not safe))
                        (clan/poo/mop#element?
                         gerbil-ascent/program/types#GerbilAscentTermContract
                         _%term2941%_)))))
               (declare (not safe))
               (andmap__0 __tmp6159 _%value2939%_))
             '#f))))
    (define gerbil-ascent/program/types#GerbilAscentAtomContract
      (let ((__obj6077
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp6161
               (list (cons 'sexp
                           (let ((__tmp6162
                                  (lambda (_%@2873%_)
                                    'GerbilAscentAtomContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6162)))
                     (cons 'identity
                           (let ((__tmp6163 (lambda (_%@2879%_) 'ascent/atom)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6163)))
                     (cons 'proto
                           (let ((__tmp6164
                                  (lambda (_%@2884%_)
                                    (let ((__obj6075
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6166 (list))
                                            (__tmp6165 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6166
                                         __tmp6165
                                         __obj6075))
                                      __obj6075))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6164)))
                     (cons 'responsibilities
                           (let ((__tmp6167
                                  (lambda (_%@2898%_)
                                    (let ((__obj6076
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6169
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp6170
                                                                (lambda (_%self2917%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'atom))))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6170)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'relation
                                                         (let ((__tmp6171
                                                                (lambda (_%self2924%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6171)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'terms
                                                         (let ((__tmp6172
                                                                (lambda (_%self2929%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+terms+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6172)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp6173
                                                                (lambda (_%self2934%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp6173)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp6168 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6169
                                         __tmp6168
                                         __obj6076))
                                      __obj6076))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6167)))))
              (__tmp6160 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp6161
           __tmp6160
           __obj6077))
        __obj6077))
    (define gerbil-ascent/program/types#+variables+
      (gerbil-ascent/program/types#slot-contract
       'ascent/variables
       (lambda (_%value2858%_)
         (if (list? _%value2858%_)
             (let () (declare (not safe)) (andmap__0 symbol? _%value2858%_))
             '#f))))
    (define gerbil-ascent/program/types#+generator-output+
      (gerbil-ascent/program/types#slot-contract
       'ascent/generator-output
       (lambda (_%value2845%_)
         (let ((_%$e2847%_ (symbol? _%value2845%_)))
           (if _%$e2847%_
               _%$e2847%_
               (if (pair? _%value2845%_)
                   (let _%loop2850%_ ((_%remaining2852%_ _%value2845%_)
                                      (_%seen2853%_ '()))
                     (let ((_%$e2855%_ (null? _%remaining2852%_)))
                       (if _%$e2855%_
                           _%$e2855%_
                           (if (symbol? (car _%remaining2852%_))
                               (if (memq (car _%remaining2852%_) _%seen2853%_)
                                   '#f
                                   (_%loop2850%_
                                    (cdr _%remaining2852%_)
                                    (cons (car _%remaining2852%_)
                                          _%seen2853%_)))
                               '#f))))
                   '#f))))))
    (define gerbil-ascent/program/types#+procedure+
      (gerbil-ascent/program/types#slot-contract 'ascent/procedure procedure?))
    (define gerbil-ascent/program/types#+optional-procedure+
      (gerbil-ascent/program/types#slot-contract
       'ascent/optional-procedure
       (lambda (_%value2840%_)
         (let ((_%$e2842%_ (not _%value2840%_)))
           (if _%$e2842%_ _%$e2842%_ (procedure? _%value2840%_))))))
    (define gerbil-ascent/program/types#+checked-operator+
      (gerbil-ascent/program/types#slot-contract
       'ascent/checked-operator
       (lambda (_%value2835%_)
         (let ((_%$e2837%_ (not _%value2835%_)))
           (if _%$e2837%_ _%$e2837%_ (vector? _%value2835%_))))))
    (define gerbil-ascent/program/types#GerbilAscentGuardContract
      (let ((__obj6080
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp6175
               (list (cons 'sexp
                           (let ((__tmp6176
                                  (lambda (_%@2763%_)
                                    'GerbilAscentGuardContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6176)))
                     (cons 'identity
                           (let ((__tmp6177
                                  (lambda (_%@2769%_) 'ascent/guard)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6177)))
                     (cons 'proto
                           (let ((__tmp6178
                                  (lambda (_%@2774%_)
                                    (let ((__obj6078
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6180 (list))
                                            (__tmp6179 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6180
                                         __tmp6179
                                         __obj6078))
                                      __obj6078))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6178)))
                     (cons 'responsibilities
                           (let ((__tmp6181
                                  (lambda (_%@2788%_)
                                    (let ((__obj6079
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6183
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp6184
                                                                (lambda (_%self2808%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'guard))))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6184)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variables
                                                         (let ((__tmp6185
                                                                (lambda (_%self2815%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+variables+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6185)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'predicate
                                                         (let ((__tmp6186
                                                                (lambda (_%self2820%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6186)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'checked-operator
                                                         (let ((__tmp6187
                                                                (lambda (_%self2825%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+checked-operator+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6187)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp6188
                                                                (lambda (_%self2830%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp6188)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp6182 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6183
                                         __tmp6182
                                         __obj6079))
                                      __obj6079))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6181)))))
              (__tmp6174 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp6175
           __tmp6174
           __obj6080))
        __obj6080))
    (define gerbil-ascent/program/types#GerbilAscentGeneratorContract
      (let ((__obj6083
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp6190
               (list (cons 'sexp
                           (let ((__tmp6191
                                  (lambda (_%@2678%_)
                                    'GerbilAscentGeneratorContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6191)))
                     (cons 'identity
                           (let ((__tmp6192
                                  (lambda (_%@2684%_) 'ascent/generator)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6192)))
                     (cons 'proto
                           (let ((__tmp6193
                                  (lambda (_%@2689%_)
                                    (let ((__obj6081
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6195 (list))
                                            (__tmp6194 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6195
                                         __tmp6194
                                         __obj6081))
                                      __obj6081))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6193)))
                     (cons 'responsibilities
                           (let ((__tmp6196
                                  (lambda (_%@2703%_)
                                    (let ((__obj6082
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6198
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp6199
                                                                (lambda (_%self2723%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'generator))))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6199)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variable
                                                         (let ((__tmp6200
                                                                (lambda (_%self2730%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+generator-output+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6200)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variables
                                                         (let ((__tmp6201
                                                                (lambda (_%self2735%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+variables+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6201)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'generate
                                                         (let ((__tmp6202
                                                                (lambda (_%self2740%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6202)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp6203
                                                                (lambda (_%self2745%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp6203)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp6197 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6198
                                         __tmp6197
                                         __obj6082))
                                      __obj6082))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6196)))))
              (__tmp6189 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp6190
           __tmp6189
           __obj6083))
        __obj6083))
    (define gerbil-ascent/program/types#GerbilAscentBindingContract
      (let ((__obj6086
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp6205
               (list (cons 'sexp
                           (let ((__tmp6206
                                  (lambda (_%@2587%_)
                                    'GerbilAscentBindingContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6206)))
                     (cons 'identity
                           (let ((__tmp6207
                                  (lambda (_%@2593%_) 'ascent/binding)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6207)))
                     (cons 'proto
                           (let ((__tmp6208
                                  (lambda (_%@2598%_)
                                    (let ((__obj6084
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6210 (list))
                                            (__tmp6209 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6210
                                         __tmp6209
                                         __obj6084))
                                      __obj6084))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6208)))
                     (cons 'responsibilities
                           (let ((__tmp6211
                                  (lambda (_%@2612%_)
                                    (let ((__obj6085
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6213
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp6214
                                                                (lambda (_%self2633%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'binding))))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6214)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variable
                                                         (let ((__tmp6215
                                                                (lambda (_%self2640%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6215)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variables
                                                         (let ((__tmp6216
                                                                (lambda (_%self2645%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+variables+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6216)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'checked-operator
                                                         (let ((__tmp6217
                                                                (lambda (_%self2650%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+checked-operator+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6217)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'compute
                                                         (let ((__tmp6218
                                                                (lambda (_%self2655%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6218)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp6219
                                                                (lambda (_%self2660%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp6219)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp6212 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6213
                                         __tmp6212
                                         __obj6085))
                                      __obj6085))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6211)))))
              (__tmp6204 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp6205
           __tmp6204
           __obj6086))
        __obj6086))
    (define gerbil-ascent/program/types#GerbilAscentNegationContract
      (let ((__obj6089
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp6221
               (list (cons 'sexp
                           (let ((__tmp6222
                                  (lambda (_%@2508%_)
                                    'GerbilAscentNegationContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6222)))
                     (cons 'identity
                           (let ((__tmp6223
                                  (lambda (_%@2514%_) 'ascent/negation)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6223)))
                     (cons 'proto
                           (let ((__tmp6224
                                  (lambda (_%@2519%_)
                                    (let ((__obj6087
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6226 (list))
                                            (__tmp6225 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6226
                                         __tmp6225
                                         __obj6087))
                                      __obj6087))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6224)))
                     (cons 'responsibilities
                           (let ((__tmp6227
                                  (lambda (_%@2533%_)
                                    (let ((__obj6088
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6229
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp6230
                                                                (lambda (_%self2552%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'negation))))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6230)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'relation
                                                         (let ((__tmp6231
                                                                (lambda (_%self2559%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6231)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'terms
                                                         (let ((__tmp6232
                                                                (lambda (_%self2564%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+terms+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6232)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp6233
                                                                (lambda (_%self2569%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp6233)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp6228 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6229
                                         __tmp6228
                                         __obj6088))
                                      __obj6088))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6227)))))
              (__tmp6220 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp6221
           __tmp6220
           __obj6089))
        __obj6089))
    (define gerbil-ascent/program/types#GerbilAscentAggregateContract
      (let ((__obj6092
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp6235
               (list (cons 'sexp
                           (let ((__tmp6236
                                  (lambda (_%@2399%_)
                                    'GerbilAscentAggregateContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6236)))
                     (cons 'identity
                           (let ((__tmp6237
                                  (lambda (_%@2405%_) 'ascent/aggregate)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6237)))
                     (cons 'proto
                           (let ((__tmp6238
                                  (lambda (_%@2410%_)
                                    (let ((__obj6090
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6240 (list))
                                            (__tmp6239 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6240
                                         __tmp6239
                                         __obj6090))
                                      __obj6090))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6238)))
                     (cons 'responsibilities
                           (let ((__tmp6241
                                  (lambda (_%@2424%_)
                                    (let ((__obj6091
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6243
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp6244
                                                                (lambda (_%self2448%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'aggregate))))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6244)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variable
                                                         (let ((__tmp6245
                                                                (lambda (_%self2455%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+generator-output+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6245)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'relation
                                                         (let ((__tmp6246
                                                                (lambda (_%self2460%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6246)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'terms
                                                         (let ((__tmp6247
                                                                (lambda (_%self2465%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+terms+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6247)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variables
                                                         (let ((__tmp6248
                                                                (lambda (_%self2470%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+variables+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6248)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'aggregate
                                                         (let ((__tmp6249
                                                                (lambda (_%self2475%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6249)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'checked-operator
                                                         (let ((__tmp6250
                                                                (lambda (_%self2480%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+checked-operator+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6250)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'output-pattern
                                                         (let ((__tmp6251
                                                                (lambda (_%self2485%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+optional-procedure+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6251)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp6252
                                                                (lambda (_%self2490%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp6252)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp6242 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6243
                                         __tmp6242
                                         __obj6091))
                                      __obj6091))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6241)))))
              (__tmp6234 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp6235
           __tmp6234
           __obj6092))
        __obj6092))
    (define gerbil-ascent/program/types#+clauses+
      (gerbil-ascent/program/types#slot-contract
       'ascent/clauses
       (lambda (_%value2367%_)
         (if (list? _%value2367%_)
             (let ((__tmp6253
                    (lambda (_%clause2369%_)
                      (let ((_%$e2371%_
                             (let ()
                               (declare (not safe))
                               (clan/poo/mop#element?
                                gerbil-ascent/program/types#GerbilAscentAtomContract
                                _%clause2369%_))))
                        (if _%$e2371%_
                            _%$e2371%_
                            (let ((_%$e2374%_
                                   (let ()
                                     (declare (not safe))
                                     (clan/poo/mop#element?
                                      gerbil-ascent/program/types#GerbilAscentGuardContract
                                      _%clause2369%_))))
                              (if _%$e2374%_
                                  _%$e2374%_
                                  (let ((_%$e2377%_
                                         (let ()
                                           (declare (not safe))
                                           (clan/poo/mop#element?
                                            gerbil-ascent/program/types#GerbilAscentGeneratorContract
                                            _%clause2369%_))))
                                    (if _%$e2377%_
                                        _%$e2377%_
                                        (let ((_%$e2380%_
                                               (let ()
                                                 (declare (not safe))
                                                 (clan/poo/mop#element?
                                                  gerbil-ascent/program/types#GerbilAscentBindingContract
                                                  _%clause2369%_))))
                                          (if _%$e2380%_
                                              _%$e2380%_
                                              (let ((_%$e2383%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (clan/poo/mop#element?
                                                        gerbil-ascent/program/types#GerbilAscentNegationContract
                                                        _%clause2369%_))))
                                                (if _%$e2383%_
                                                    _%$e2383%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (clan/poo/mop#element?
                                                       gerbil-ascent/program/types#GerbilAscentAggregateContract
                                                       _%clause2369%_)))))))))))))))
               (declare (not safe))
               (andmap__0 __tmp6253 _%value2367%_))
             '#f))))
    (define gerbil-ascent/program/types#+heads+
      (gerbil-ascent/program/types#slot-contract
       'ascent/heads
       (lambda (_%value2363%_)
         (if (pair? _%value2363%_)
             (let ((__tmp6254
                    (lambda (_%head2365%_)
                      (let ()
                        (declare (not safe))
                        (clan/poo/mop#element?
                         gerbil-ascent/program/types#GerbilAscentAtomContract
                         _%head2365%_)))))
               (declare (not safe))
               (andmap__0 __tmp6254 _%value2363%_))
             '#f))))
    (define gerbil-ascent/program/types#GerbilAscentRuleContract
      (let ((__obj6095
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp6256
               (list (cons 'sexp
                           (let ((__tmp6257
                                  (lambda (_%@2309%_)
                                    'GerbilAscentRuleContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6257)))
                     (cons 'identity
                           (let ((__tmp6258 (lambda (_%@2315%_) 'ascent/rule)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6258)))
                     (cons 'proto
                           (let ((__tmp6259
                                  (lambda (_%@2320%_)
                                    (let ((__obj6093
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6261 (list))
                                            (__tmp6260 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6261
                                         __tmp6260
                                         __obj6093))
                                      __obj6093))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6259)))
                     (cons 'responsibilities
                           (let ((__tmp6262
                                  (lambda (_%@2334%_)
                                    (let ((__obj6094
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6264
                                             (list (cons 'heads
                                                         (let ((__tmp6265
                                                                (lambda (_%self2351%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+heads+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6265)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'body
                                                         (let ((__tmp6266
                                                                (lambda (_%self2358%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+clauses+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp6266)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp6263 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6264
                                         __tmp6263
                                         __obj6094))
                                      __obj6094))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6262)))))
              (__tmp6255 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp6256
           __tmp6255
           __obj6095))
        __obj6095))
    (define gerbil-ascent/program/types#+relations+
      (gerbil-ascent/program/types#slot-contract
       'ascent/relations
       (lambda (_%value2289%_)
         (if (list? _%value2289%_)
             (let ((__tmp6267
                    (lambda (_%relation2291%_)
                      (let ((_%$e2293%_
                             (let ()
                               (declare (not safe))
                               (clan/poo/mop#element?
                                gerbil-ascent/program/types#GerbilAscentRelationContract
                                _%relation2291%_))))
                        (if _%$e2293%_
                            _%$e2293%_
                            (let ()
                              (declare (not safe))
                              (clan/poo/mop#element?
                               gerbil-ascent/program/types#GerbilAscentLatticeContract
                               _%relation2291%_)))))))
               (declare (not safe))
               (andmap__0 __tmp6267 _%value2289%_))
             '#f))))
    (define gerbil-ascent/program/types#+rules+
      (gerbil-ascent/program/types#slot-contract
       'ascent/rules
       (lambda (_%value2285%_)
         (if (list? _%value2285%_)
             (let ((__tmp6268
                    (lambda (_%rule2287%_)
                      (let ()
                        (declare (not safe))
                        (clan/poo/mop#element?
                         gerbil-ascent/program/types#GerbilAscentRuleContract
                         _%rule2287%_)))))
               (declare (not safe))
               (andmap__0 __tmp6268 _%value2285%_))
             '#f))))
    (define gerbil-ascent/program/types#+fragment-exports+
      (gerbil-ascent/program/types#slot-contract
       'ascent/fragment-exports
       procedure?))
    (define gerbil-ascent/program/types#+source-handles+
      (gerbil-ascent/program/types#slot-contract
       'ascent/source-handles
       (lambda (_%value2283%_)
         (if (list? _%value2283%_)
             (let () (declare (not safe)) (andmap__0 symbol? _%value2283%_))
             '#f))))
    (define gerbil-ascent/program/types#GerbilAscentFragmentContract
      (let ((__obj6098
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp6270
               (list (cons 'sexp
                           (let ((__tmp6271
                                  (lambda (_%@2217%_)
                                    'GerbilAscentFragmentContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6271)))
                     (cons 'identity
                           (let ((__tmp6272
                                  (lambda (_%@2223%_) 'ascent/fragment)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6272)))
                     (cons 'proto
                           (let ((__tmp6273
                                  (lambda (_%@2228%_)
                                    (let ((__obj6096
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6275 (list))
                                            (__tmp6274 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6275
                                         __tmp6274
                                         __obj6096))
                                      __obj6096))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6273)))
                     (cons 'responsibilities
                           (let ((__tmp6276
                                  (lambda (_%@2242%_)
                                    (let ((__obj6097
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6278
                                             (list (cons 'relations
                                                         (let ((__tmp6279
                                                                (lambda (_%self2261%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+relations+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6279)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'rules
                                                         (let ((__tmp6280
                                                                (lambda (_%self2268%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+rules+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6280)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'exports
                                                         (let ((__tmp6281
                                                                (lambda (_%self2273%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+fragment-exports+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6281)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'source-handles
                                                         (let ((__tmp6282
                                                                (lambda (_%self2278%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+source-handles+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp6282)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp6277 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6278
                                         __tmp6277
                                         __obj6097))
                                      __obj6097))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6276)))))
              (__tmp6269 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp6270
           __tmp6269
           __obj6098))
        __obj6098))
    (define gerbil-ascent/program/types#GerbilAscentProgramContract
      (let ((__obj6101
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp6284
               (list (cons 'sexp
                           (let ((__tmp6285
                                  (lambda (_%@2126%_)
                                    'GerbilAscentProgramContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6285)))
                     (cons 'identity
                           (let ((__tmp6286
                                  (lambda (_%@2132%_) 'ascent/program)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6286)))
                     (cons 'proto
                           (let ((__tmp6287
                                  (lambda (_%@2137%_)
                                    (let ((__obj6099
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6289 (list))
                                            (__tmp6288 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6289
                                         __tmp6288
                                         __obj6099))
                                      __obj6099))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6287)))
                     (cons 'responsibilities
                           (let ((__tmp6290
                                  (lambda (_%@2151%_)
                                    (let ((__obj6100
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6292
                                             (list (cons 'relations
                                                         (let ((__tmp6293
                                                                (lambda (_%self2172%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+relations+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6293)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'rules
                                                         (let ((__tmp6294
                                                                (lambda (_%self2179%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+rules+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6294)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'source-handles
                                                         (let ((__tmp6295
                                                                (lambda (_%self2184%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+source-handles+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6295)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'max-input-facts
                                                         (let ((__tmp6296
                                                                (lambda (_%self2189%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+fact-budget+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6296)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'max-derived-facts
                                                         (let ((__tmp6297
                                                                (lambda (_%self2194%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+fact-budget+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6297)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'max-output-facts
                                                         (let ((__tmp6298
                                                                (lambda (_%self2199%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+fact-budget+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp6298)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp6291 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6292
                                         __tmp6291
                                         __obj6100))
                                      __obj6100))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6290)))))
              (__tmp6283 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp6284
           __tmp6283
           __obj6101))
        __obj6101))
    (define gerbil-ascent/program/types#gerbil-ascent-owned-root-contract
      (lambda (_%root1909%_)
        (let* ((_%accepted1911%_
                (let () (declare (not safe)) (make-hash-table-eq)))
               (_%owned-terms1969%_
                (gerbil-ascent/program/types#slot-contract
                 'ascent/terms
                 (lambda (_%value1913%_)
                   (if (list? _%value1913%_)
                       (let ((__tmp6299
                              (lambda (_%term1915%_)
                                (let ((_%$e1941%_
                                       (let* ((_%h1917%_ _%accepted1911%_)
                                              (_%key1920%_ _%term1915%_)
                                              (_%h1924%_ _%h1917%_)
                                              (_%h1926%_ _%h1924%_))
                                         (declare (not safe))
                                         (__hash-get _%h1926%_ _%key1920%_))))
                                  (if _%$e1941%_
                                      _%$e1941%_
                                      (if (let ()
                                            (declare (not safe))
                                            (clan/poo/mop#element?
                                             gerbil-ascent/program/types#GerbilAscentTermContract
                                             _%term1915%_))
                                          (begin
                                            (let* ((_%h1944%_ _%accepted1911%_)
                                                   (_%key1947%_ _%term1915%_)
                                                   (_%value1950%_ '#t)
                                                   (_%h1954%_ _%h1944%_)
                                                   (_%h1956%_ _%h1954%_))
                                              (declare (not safe))
                                              (__hash-put!
                                               _%h1956%_
                                               _%key1947%_
                                               _%value1950%_))
                                            '#t)
                                          '#f))))))
                         (declare (not safe))
                         (andmap__0 __tmp6299 _%value1913%_))
                       '#f))))
               (_%owned-atom2005%_
                (let ((__obj6103
                       (let ()
                         (declare (not safe))
                         (##structure
                          clan/poo/object#object::t
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f))))
                  (let ((__tmp6301
                         (list (cons 'responsibilities
                                     (let ((__tmp6302
                                            (lambda (_%@1982%_)
                                              (let ((__obj6102
                                                     (let ()
                                                       (declare (not safe))
                                                       (##structure
                                                        clan/poo/object#object::t
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f))))
                                                (let ((__tmp6306
                                                       (let ()
                                                         (declare (not safe))
                                                         (clan/poo/object#.ref
                                                          gerbil-ascent/program/types#GerbilAscentAtomContract
                                                          'responsibilities)))
                                                      (__tmp6304
                                                       (list (cons 'terms
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ((__tmp6305
                                  (lambda (_%@1999%_) _%owned-terms1969%_)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6305)))))
              (__tmp6303 (list)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (declare (not safe))
                                                  (clan/poo/object#object:::init!__%
                                                   '#f
                                                   __tmp6306
                                                   __tmp6304
                                                   __tmp6303
                                                   __obj6102))
                                                __obj6102))))
                                       (declare (not safe))
                                       (##structure
                                        clan/poo/object#$self-slot-spec::t
                                        __tmp6302)))))
                        (__tmp6300 (list)))
                    (declare (not safe))
                    (clan/poo/object#object:::init!__%
                     '#f
                     gerbil-ascent/program/types#GerbilAscentAtomContract
                     __tmp6301
                     __tmp6300
                     __obj6103))
                  __obj6103))
               (_%owned-heads2013%_
                (gerbil-ascent/program/types#slot-contract
                 'ascent/heads
                 (lambda (_%value2007%_)
                   (if (pair? _%value2007%_)
                       (let ((__tmp6307
                              (lambda (_%$%g20082010%_)
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/mop#element?
                                   _%owned-atom2005%_
                                   _%$%g20082010%_)))))
                         (declare (not safe))
                         (andmap__0 __tmp6307 _%value2007%_))
                       '#f))))
               (_%owned-body2022%_
                (gerbil-ascent/program/types#slot-contract
                 'ascent/clauses
                 (lambda (_%value2015%_)
                   (if (list? _%value2015%_)
                       (let ((__tmp6308
                              (lambda (_%clause2017%_)
                                (let ((_%$e2019%_
                                       (let ()
                                         (declare (not safe))
                                         (clan/poo/mop#element?
                                          _%owned-atom2005%_
                                          _%clause2017%_))))
                                  (if _%$e2019%_
                                      _%$e2019%_
                                      (let ((__tmp6309 (list _%clause2017%_)))
                                        (declare (not safe))
                                        (clan/poo/mop#element?
                                         gerbil-ascent/program/types#+clauses+
                                         __tmp6309)))))))
                         (declare (not safe))
                         (andmap__0 __tmp6308 _%value2015%_))
                       '#f))))
               (_%owned-rule2066%_
                (let ((__obj6105
                       (let ()
                         (declare (not safe))
                         (##structure
                          clan/poo/object#object::t
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f))))
                  (let ((__tmp6311
                         (list (cons 'responsibilities
                                     (let ((__tmp6312
                                            (lambda (_%@2037%_)
                                              (let ((__obj6104
                                                     (let ()
                                                       (declare (not safe))
                                                       (##structure
                                                        clan/poo/object#object::t
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f))))
                                                (let ((__tmp6317
                                                       (let ()
                                                         (declare (not safe))
                                                         (clan/poo/object#.ref
                                                          gerbil-ascent/program/types#GerbilAscentRuleContract
                                                          'responsibilities)))
                                                      (__tmp6314
                                                       (list (cons 'heads
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ((__tmp6315
                                  (lambda (_%@2055%_) _%owned-heads2013%_)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6315)))
                     (cons 'body
                           (let ((__tmp6316
                                  (lambda (_%@2061%_) _%owned-body2022%_)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6316)))))
              (__tmp6313 (list)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (declare (not safe))
                                                  (clan/poo/object#object:::init!__%
                                                   '#f
                                                   __tmp6317
                                                   __tmp6314
                                                   __tmp6313
                                                   __obj6104))
                                                __obj6104))))
                                       (declare (not safe))
                                       (##structure
                                        clan/poo/object#$self-slot-spec::t
                                        __tmp6312)))))
                        (__tmp6310 (list)))
                    (declare (not safe))
                    (clan/poo/object#object:::init!__%
                     '#f
                     gerbil-ascent/program/types#GerbilAscentRuleContract
                     __tmp6311
                     __tmp6310
                     __obj6105))
                  __obj6105))
               (_%owned-rules2074%_
                (gerbil-ascent/program/types#slot-contract
                 'ascent/rules
                 (lambda (_%value2068%_)
                   (if (list? _%value2068%_)
                       (let ((__tmp6318
                              (lambda (_%$%g20692071%_)
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/mop#element?
                                   _%owned-rule2066%_
                                   _%$%g20692071%_)))))
                         (declare (not safe))
                         (andmap__0 __tmp6318 _%value2068%_))
                       '#f))))
               (__obj6107
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
          (let ((__tmp6320
                 (list (cons 'responsibilities
                             (let ((__tmp6321
                                    (lambda (_%@2090%_)
                                      (let ((__obj6106
                                             (let ()
                                               (declare (not safe))
                                               (##structure
                                                clan/poo/object#object::t
                                                '#f
                                                '#f
                                                '#f
                                                '#f
                                                '#f
                                                '#f
                                                '#f))))
                                        (let ((__tmp6325
                                               (let ()
                                                 (declare (not safe))
                                                 (clan/poo/object#.ref
                                                  _%root1909%_
                                                  'responsibilities)))
                                              (__tmp6323
                                               (list (cons 'rules
                                                           (let ((__tmp6324
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (lambda (_%@2107%_) _%owned-rules2074%_)))
                     (declare (not safe))
                     (##structure
                      clan/poo/object#$self-slot-spec::t
                      __tmp6324)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (__tmp6322 (list)))
                                          (declare (not safe))
                                          (clan/poo/object#object:::init!__%
                                           '#f
                                           __tmp6325
                                           __tmp6323
                                           __tmp6322
                                           __obj6106))
                                        __obj6106))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp6321)))))
                (__tmp6319 (list)))
            (declare (not safe))
            (clan/poo/object#object:::init!__%
             '#f
             _%root1909%_
             __tmp6320
             __tmp6319
             __obj6107))
          __obj6107)))
    (define gerbil-ascent/program/types#GerbilAscentSessionContract
      (let ((__obj6110
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp6327
               (list (cons 'sexp
                           (let ((__tmp6328
                                  (lambda (_%@1849%_)
                                    'GerbilAscentSessionContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6328)))
                     (cons 'identity
                           (let ((__tmp6329
                                  (lambda (_%@1855%_) 'ascent/session)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6329)))
                     (cons 'proto
                           (let ((__tmp6330
                                  (lambda (_%@1860%_)
                                    (let ((__obj6108
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6332 (list))
                                            (__tmp6331 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6332
                                         __tmp6331
                                         __obj6108))
                                      __obj6108))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6330)))
                     (cons 'responsibilities
                           (let ((__tmp6333
                                  (lambda (_%@1874%_)
                                    (let ((__obj6109
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp6335
                                             (list (cons '.append-source!
                                                         (let ((__tmp6336
                                                                (lambda (_%self1892%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6336)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.replace-source!
                                                         (let ((__tmp6337
                                                                (lambda (_%self1899%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp6337)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.run
                                                         (let ((__tmp6338
                                                                (lambda (_%self1904%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp6338)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp6334 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp6335
                                         __tmp6334
                                         __obj6109))
                                      __obj6109))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp6333)))))
              (__tmp6326 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp6327
           __tmp6326
           __obj6110))
        __obj6110))))
