(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "std/test")
    (load-module "gerbil-ascent/candidate/evidence-store")
    (load-module "gerbil-ascent/candidate/reasoning"))
  (load-module "gerbil-ascent/t/qualification/ascent-evidence-store-test~0"))
