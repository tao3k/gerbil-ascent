(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/core/relation-view")
    (load-module "clan/poo/object")
    (load-module "gerbil-ascent/program/lattice-frontier")
    (load-module "gerbil-ascent/program/admission")
    (load-module "gerbil-ascent/core/rule-semantics")
    (load-module "gerbil-ascent/table/storage")
    (load-module "gerbil-ascent/table/provider"))
  (load-module "gerbil-ascent/program/initialization~0"))
