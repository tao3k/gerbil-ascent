(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/reasoning[1]#_g39275_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39277_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-receipt
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39279_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39281_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39282_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39283_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39284_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39285_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39286_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39287_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39288_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-diagnostics
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39289_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39290_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39291_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-nonmembership
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39292_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-stratified
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39294_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39295_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39296_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39297_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39298_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39299_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39300_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39301_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-diagnostics-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39302_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39303_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39304_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-nonmembership-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39305_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-stratified-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39307_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39308_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39309_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39310_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39311_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39312_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39313_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39314_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-diagnostics
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39315_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39316_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39317_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-nonmembership
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39318_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-stratified
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39320_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39321_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39322_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39323_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39324_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39325_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39326_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39327_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-diagnostics-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39328_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39329_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39330_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-nonmembership-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39331_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-stratified-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39333_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39335_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39337_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39339_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39340_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-support
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39341_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-reachable
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39343_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39344_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-support-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39345_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-reachable-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39347_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39348_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-support
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39349_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-reachable
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39351_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39352_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-support-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39353_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-reachable-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39355_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39357_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-stratified-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39359_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39361_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39362_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-finite
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39363_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39364_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39366_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39367_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-finite-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39368_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39369_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39371_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39372_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-finite
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39373_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39374_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39376_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39377_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-finite-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39378_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39379_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39381_|
    (##structure
     gx#syntax-quote::t
     'captured-stage::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39383_|
    (##structure
     gx#syntax-quote::t
     'make-captured-stage
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39385_|
    (##structure
     gx#syntax-quote::t
     'captured-stage?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39387_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-ok?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39388_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39390_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-ok?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39391_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39393_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-ok?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39394_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39396_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-ok?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39397_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39399_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39401_|
    (##structure
     gx#syntax-quote::t
     'make-attempt-observation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39403_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39405_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39406_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39408_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39409_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39411_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39412_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39414_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39415_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/reasoning[:0:]#reasoning-receipt|
      (let ((__obj39193
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39193
           'gerbil-ascent/candidate/reasoning#reasoning-receipt::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39193
           'reasoning-receipt
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39193
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    rows
                    diagnostics
                    evidence
                    proof
                    nonmembership
                    stratified)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39193
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    rows
                    diagnostics
                    evidence
                    proof
                    nonmembership
                    stratified)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39193 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39193 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39193 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39193 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39193 '#f '13 '#f '#f))
        (let ((__tmp39274 |gerbil-ascent/candidate/reasoning[1]#_g39275_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39193 __tmp39274 '4 '#f '#f))
        (let ((__tmp39276 |gerbil-ascent/candidate/reasoning[1]#_g39277_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39193 __tmp39276 '14 '#f '#f))
        (let ((__tmp39278 |gerbil-ascent/candidate/reasoning[1]#_g39279_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39193 __tmp39278 '15 '#f '#f))
        (let ((__tmp39280
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39281_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g39282_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g39283_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g39284_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g39285_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g39286_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g39287_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g39288_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g39289_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g39290_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g39291_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g39292_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj39193 __tmp39280 '16 '#f '#f))
        (let ((__tmp39293
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39294_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g39295_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g39296_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g39297_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g39298_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g39299_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g39300_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g39301_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g39302_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g39303_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g39304_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g39305_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj39193 __tmp39293 '17 '#f '#f))
        (let ((__tmp39306
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39307_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g39308_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g39309_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g39310_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g39311_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g39312_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g39313_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g39314_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g39315_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g39316_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g39317_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g39318_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj39193 __tmp39306 '18 '#f '#f))
        (let ((__tmp39319
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39320_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g39321_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g39322_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g39323_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g39324_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g39325_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g39326_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g39327_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g39328_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g39329_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g39330_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g39331_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj39193 __tmp39319 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39193 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39193 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39193 '() '21 '#f '#f))
        __obj39193))
    (define |gerbil-ascent/candidate/reasoning[:0:]#reasoning-evidence|
      (let ((__obj39194
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39194
           'gerbil-ascent/candidate/reasoning#reasoning-evidence::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39194
           'reasoning-evidence
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39194
           '(kind support reachable)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39194
           '(kind support reachable)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39194 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39194 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39194 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39194 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39194 '#f '13 '#f '#f))
        (let ((__tmp39332 |gerbil-ascent/candidate/reasoning[1]#_g39333_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39194 __tmp39332 '4 '#f '#f))
        (let ((__tmp39334 |gerbil-ascent/candidate/reasoning[1]#_g39335_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39194 __tmp39334 '14 '#f '#f))
        (let ((__tmp39336 |gerbil-ascent/candidate/reasoning[1]#_g39337_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39194 __tmp39336 '15 '#f '#f))
        (let ((__tmp39338
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g39339_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g39340_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g39341_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39194 __tmp39338 '16 '#f '#f))
        (let ((__tmp39342
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g39343_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g39344_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g39345_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39194 __tmp39342 '17 '#f '#f))
        (let ((__tmp39346
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g39347_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g39348_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g39349_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39194 __tmp39346 '18 '#f '#f))
        (let ((__tmp39350
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g39351_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g39352_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g39353_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39194 __tmp39350 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39194 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39194 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39194 '() '21 '#f '#f))
        __obj39194))
    (define |gerbil-ascent/candidate/reasoning[:0:]#reasoning-stratified-evidence|
      (let ((__obj39195
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39195
           'gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39195
           'reasoning-stratified-evidence
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39195
           '(status finite proof work-budget)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39195
           '(status finite proof work-budget)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39195 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39195 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39195 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39195 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39195 '#f '13 '#f '#f))
        (let ((__tmp39354 |gerbil-ascent/candidate/reasoning[1]#_g39355_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39195 __tmp39354 '4 '#f '#f))
        (let ((__tmp39356 |gerbil-ascent/candidate/reasoning[1]#_g39357_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39195 __tmp39356 '14 '#f '#f))
        (let ((__tmp39358 |gerbil-ascent/candidate/reasoning[1]#_g39359_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39195 __tmp39358 '15 '#f '#f))
        (let ((__tmp39360
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39361_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g39362_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g39363_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g39364_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39195 __tmp39360 '16 '#f '#f))
        (let ((__tmp39365
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39366_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g39367_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g39368_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g39369_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39195 __tmp39365 '17 '#f '#f))
        (let ((__tmp39370
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39371_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g39372_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g39373_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g39374_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39195 __tmp39370 '18 '#f '#f))
        (let ((__tmp39375
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39376_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g39377_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g39378_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g39379_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39195 __tmp39375 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39195 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39195 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39195 '() '21 '#f '#f))
        __obj39195))
    (define |gerbil-ascent/candidate/reasoning[:0:]#captured-stage|
      (let ((__obj39196
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39196
           'gerbil-ascent/candidate/reasoning#captured-stage::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39196 'captured-stage '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39196 '(ok? value) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39196 '(ok? value) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39196 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39196 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39196 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39196 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39196 '#f '13 '#f '#f))
        (let ((__tmp39380 |gerbil-ascent/candidate/reasoning[1]#_g39381_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39196 __tmp39380 '4 '#f '#f))
        (let ((__tmp39382 |gerbil-ascent/candidate/reasoning[1]#_g39383_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39196 __tmp39382 '14 '#f '#f))
        (let ((__tmp39384 |gerbil-ascent/candidate/reasoning[1]#_g39385_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39196 __tmp39384 '15 '#f '#f))
        (let ((__tmp39386
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g39387_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g39388_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39196 __tmp39386 '16 '#f '#f))
        (let ((__tmp39389
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g39390_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g39391_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39196 __tmp39389 '17 '#f '#f))
        (let ((__tmp39392
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g39393_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g39394_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39196 __tmp39392 '18 '#f '#f))
        (let ((__tmp39395
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g39396_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g39397_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39196 __tmp39395 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39196 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39196 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39196 '() '21 '#f '#f))
        __obj39196))
    (define |gerbil-ascent/candidate/reasoning[:0:]#attempt-observation|
      (let ((__obj39197
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39197
           'gerbil-ascent/candidate/reasoning#attempt-observation::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39197
           'attempt-observation
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39197 '(rows evidence) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39197 '(rows evidence) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39197 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39197 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39197 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39197 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39197 '#f '13 '#f '#f))
        (let ((__tmp39398 |gerbil-ascent/candidate/reasoning[1]#_g39399_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39197 __tmp39398 '4 '#f '#f))
        (let ((__tmp39400 |gerbil-ascent/candidate/reasoning[1]#_g39401_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39197 __tmp39400 '14 '#f '#f))
        (let ((__tmp39402 |gerbil-ascent/candidate/reasoning[1]#_g39403_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39197 __tmp39402 '15 '#f '#f))
        (let ((__tmp39404
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g39405_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g39406_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39197 __tmp39404 '16 '#f '#f))
        (let ((__tmp39407
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g39408_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g39409_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39197 __tmp39407 '17 '#f '#f))
        (let ((__tmp39410
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g39411_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g39412_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39197 __tmp39410 '18 '#f '#f))
        (let ((__tmp39413
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g39414_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g39415_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39197 __tmp39413 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39197 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39197 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39197 '() '21 '#f '#f))
        __obj39197))))
