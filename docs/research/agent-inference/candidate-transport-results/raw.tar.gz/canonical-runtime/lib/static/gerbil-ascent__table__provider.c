#ifdef ___LINKER_INFO
; File: "gerbil-ascent__table__provider.c", produced by Gambit v4.9.8
(
409008
(C)
"gerbil-ascent__table__provider"
("gerbil-ascent__table__provider")
()
(("gerbil-ascent__table__provider"))
( #|*/"*/"symbols|#
".build-index"
".extend-index!"
".lookup-index"
"GerbilAscentIndexProviderContract"
"ascent/index-provider"
"ascent/index-provider-procedure"
"gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?"
"gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider?"
"gerbil-ascent/table/provider#gerbil-ascent-index-provider-build"
"gerbil-ascent/table/provider#gerbil-ascent-index-provider-extend!"
"gerbil-ascent/table/provider#gerbil-ascent-index-provider-lookup"
"gerbil-ascent__table__provider"
"gerbil-ascent__table__provider#"
"identity"
"proto"
"responsibilities"
"sexp"
) #|*/"*/"symbols|#
( #|*/"*/"keywords|#
) #|*/"*/"keywords|#
( #|*/"*/"globals-s-d|#
"gerbil-ascent/table/provider#+canonical-hash-index-provider+"
"gerbil-ascent/table/provider#+curried-index-provider+"
"gerbil-ascent/table/provider#+procedure+"
"gerbil-ascent/table/provider#GerbilAscentIndexProviderContract"
"gerbil-ascent/table/provider#IndexProvider."
"gerbil-ascent__table__provider#"
) #|*/"*/"globals-s-d|#
( #|*/"*/"globals-s-nd|#
"gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?"
"gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider"
"gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider?"
"gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider"
"gerbil-ascent/table/provider#gerbil-ascent-index-provider-build"
"gerbil-ascent/table/provider#gerbil-ascent-index-provider-extend!"
"gerbil-ascent/table/provider#gerbil-ascent-index-provider-lookup"
"gerbil-ascent/table/provider::timestamp"
) #|*/"*/"globals-s-nd|#
( #|*/"*/"globals-ns|#
"clan/poo/mop#validate"
"clan/poo/object#$self-slot-spec::t"
"clan/poo/object#.ref"
"clan/poo/object#object:::init!__%"
"clan/poo/object#object::t"
"core/types#PooFlowNativeObjectContract."
"core/types#poo-flow-predicate-contract"
"gerbil-ascent/table/funs#gerbil-ascent-index-build"
"gerbil-ascent/table/funs#gerbil-ascent-index-extend!"
"hash-get"
"procedure?"
) #|*/"*/"globals-ns|#
( #|*/"*/"meta-info|#
) #|*/"*/"meta-info|#
)
#else
#define ___VERSION 409008
#define ___MODULE_NAME "gerbil-ascent__table__provider"
#define ___LINKER_ID ___LNK_gerbil_2d_ascent____table____provider
#define ___MH_PROC ___H_gerbil_2d_ascent____table____provider
#define ___SCRIPT_LINE 0
#define ___SYMCOUNT 17
#define ___GLOCOUNT 25
#define ___SUPCOUNT 14
#define ___SUBCOUNT 4
#define ___LBLCOUNT 48
#define ___OFDCOUNT 4
#define ___MODDESCR ___REF_SUB(1)
#include "gambit.h"

___NEED_SYM(___S__2e_build_2d_index)
___NEED_SYM(___S__2e_extend_2d_index_21_)
___NEED_SYM(___S__2e_lookup_2d_index)
___NEED_SYM(___S_GerbilAscentIndexProviderContract)
___NEED_SYM(___S_ascent_2f_index_2d_provider)
___NEED_SYM(___S_ascent_2f_index_2d_provider_2d_procedure)
___NEED_SYM(___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_)
___NEED_SYM(___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_)
___NEED_SYM(___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
___NEED_SYM(___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
___NEED_SYM(___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
___NEED_SYM(___S_gerbil_2d_ascent____table____provider)
___NEED_SYM(___S_gerbil_2d_ascent____table____provider_23_)
___NEED_SYM(___S_identity)
___NEED_SYM(___S_proto)
___NEED_SYM(___S_responsibilities)
___NEED_SYM(___S_sexp)

___NEED_GLO(___G_clan_2f_poo_2f_mop_23_validate)
___NEED_GLO(___G_clan_2f_poo_2f_object_23__24_self_2d_slot_2d_spec_3a__3a_t)
___NEED_GLO(___G_clan_2f_poo_2f_object_23__2e_ref)
___NEED_GLO(___G_clan_2f_poo_2f_object_23_object_3a__3a__3a_init_21______25_)
___NEED_GLO(___G_clan_2f_poo_2f_object_23_object_3a__3a_t)
___NEED_GLO(___G_core_2f_types_23_PooFlowNativeObjectContract_2e_)
___NEED_GLO(___G_core_2f_types_23_poo_2d_flow_2d_predicate_2d_contract)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_build)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_extend_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_provider_23__2b_canonical_2d_hash_2d_index_2d_provider_2b_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_provider_23__2b_curried_2d_index_2d_provider_2b_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_provider_23__2b_procedure_2b_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_provider_23_GerbilAscentIndexProviderContract)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_provider_23_IndexProvider_2e_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_hash_2d_index_2d_provider)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_provider_3a__3a_timestamp)
___NEED_GLO(___G_gerbil_2d_ascent____table____provider_23_)
___NEED_GLO(___G_hash_2d_get)
___NEED_GLO(___G_procedure_3f_)

___BEGIN_SYM
___DEF_SYM(0,___S__2e_build_2d_index,".build-index")
___DEF_SYM(1,___S__2e_extend_2d_index_21_,".extend-index!")
___DEF_SYM(2,___S__2e_lookup_2d_index,".lookup-index")
___DEF_SYM(3,___S_GerbilAscentIndexProviderContract,"GerbilAscentIndexProviderContract")

___DEF_SYM(4,___S_ascent_2f_index_2d_provider,"ascent/index-provider")
___DEF_SYM(5,___S_ascent_2f_index_2d_provider_2d_procedure,"ascent/index-provider-procedure")

___DEF_SYM(6,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_,"gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?")

___DEF_SYM(7,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_,"gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider?")

___DEF_SYM(8,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build,"gerbil-ascent/table/provider#gerbil-ascent-index-provider-build")

___DEF_SYM(9,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_,"gerbil-ascent/table/provider#gerbil-ascent-index-provider-extend!")

___DEF_SYM(10,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup,"gerbil-ascent/table/provider#gerbil-ascent-index-provider-lookup")

___DEF_SYM(11,___S_gerbil_2d_ascent____table____provider,"gerbil-ascent__table__provider")

___DEF_SYM(12,___S_gerbil_2d_ascent____table____provider_23_,"gerbil-ascent__table__provider#")

___DEF_SYM(13,___S_identity,"identity")
___DEF_SYM(14,___S_proto,"proto")
___DEF_SYM(15,___S_responsibilities,"responsibilities")
___DEF_SYM(16,___S_sexp,"sexp")
___END_SYM

#define ___SYM__2e_build_2d_index ___SYM(0,___S__2e_build_2d_index)
#define ___SYM__2e_extend_2d_index_21_ ___SYM(1,___S__2e_extend_2d_index_21_)
#define ___SYM__2e_lookup_2d_index ___SYM(2,___S__2e_lookup_2d_index)
#define ___SYM_GerbilAscentIndexProviderContract ___SYM(3,___S_GerbilAscentIndexProviderContract)
#define ___SYM_ascent_2f_index_2d_provider ___SYM(4,___S_ascent_2f_index_2d_provider)
#define ___SYM_ascent_2f_index_2d_provider_2d_procedure ___SYM(5,___S_ascent_2f_index_2d_provider_2d_procedure)
#define ___SYM_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_ ___SYM(6,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_)
#define ___SYM_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_ ___SYM(7,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_)
#define ___SYM_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build ___SYM(8,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
#define ___SYM_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_ ___SYM(9,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
#define ___SYM_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup ___SYM(10,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
#define ___SYM_gerbil_2d_ascent____table____provider ___SYM(11,___S_gerbil_2d_ascent____table____provider)
#define ___SYM_gerbil_2d_ascent____table____provider_23_ ___SYM(12,___S_gerbil_2d_ascent____table____provider_23_)
#define ___SYM_identity ___SYM(13,___S_identity)
#define ___SYM_proto ___SYM(14,___S_proto)
#define ___SYM_responsibilities ___SYM(15,___S_responsibilities)
#define ___SYM_sexp ___SYM(16,___S_sexp)

___BEGIN_GLO
___DEF_GLO(0,"gerbil-ascent/table/provider#+canonical-hash-index-provider+")

___DEF_GLO(1,"gerbil-ascent/table/provider#+curried-index-provider+")

___DEF_GLO(2,"gerbil-ascent/table/provider#+procedure+")

___DEF_GLO(3,"gerbil-ascent/table/provider#GerbilAscentIndexProviderContract")

___DEF_GLO(4,"gerbil-ascent/table/provider#IndexProvider.")

___DEF_GLO(5,"gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?")

___DEF_GLO(6,"gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider")

___DEF_GLO(7,"gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider?")

___DEF_GLO(8,"gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider")

___DEF_GLO(9,"gerbil-ascent/table/provider#gerbil-ascent-index-provider-build")

___DEF_GLO(10,"gerbil-ascent/table/provider#gerbil-ascent-index-provider-extend!")

___DEF_GLO(11,"gerbil-ascent/table/provider#gerbil-ascent-index-provider-lookup")

___DEF_GLO(12,"gerbil-ascent/table/provider::timestamp")

___DEF_GLO(13,"gerbil-ascent__table__provider#")
___DEF_GLO(14,"clan/poo/mop#validate")
___DEF_GLO(15,"clan/poo/object#$self-slot-spec::t")

___DEF_GLO(16,"clan/poo/object#.ref")
___DEF_GLO(17,"clan/poo/object#object:::init!__%")

___DEF_GLO(18,"clan/poo/object#object::t")
___DEF_GLO(19,"core/types#PooFlowNativeObjectContract.")

___DEF_GLO(20,"core/types#poo-flow-predicate-contract")

___DEF_GLO(21,"gerbil-ascent/table/funs#gerbil-ascent-index-build")

___DEF_GLO(22,"gerbil-ascent/table/funs#gerbil-ascent-index-extend!")

___DEF_GLO(23,"hash-get")
___DEF_GLO(24,"procedure?")
___END_GLO

#define ___GLO_gerbil_2d_ascent_2f_table_2f_provider_23__2b_canonical_2d_hash_2d_index_2d_provider_2b_ ___GLO(0,___G_gerbil_2d_ascent_2f_table_2f_provider_23__2b_canonical_2d_hash_2d_index_2d_provider_2b_)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_provider_23__2b_canonical_2d_hash_2d_index_2d_provider_2b_ ___PRM(0,___G_gerbil_2d_ascent_2f_table_2f_provider_23__2b_canonical_2d_hash_2d_index_2d_provider_2b_)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_provider_23__2b_curried_2d_index_2d_provider_2b_ ___GLO(1,___G_gerbil_2d_ascent_2f_table_2f_provider_23__2b_curried_2d_index_2d_provider_2b_)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_provider_23__2b_curried_2d_index_2d_provider_2b_ ___PRM(1,___G_gerbil_2d_ascent_2f_table_2f_provider_23__2b_curried_2d_index_2d_provider_2b_)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_provider_23__2b_procedure_2b_ ___GLO(2,___G_gerbil_2d_ascent_2f_table_2f_provider_23__2b_procedure_2b_)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_provider_23__2b_procedure_2b_ ___PRM(2,___G_gerbil_2d_ascent_2f_table_2f_provider_23__2b_procedure_2b_)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_provider_23_GerbilAscentIndexProviderContract ___GLO(3,___G_gerbil_2d_ascent_2f_table_2f_provider_23_GerbilAscentIndexProviderContract)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_provider_23_GerbilAscentIndexProviderContract ___PRM(3,___G_gerbil_2d_ascent_2f_table_2f_provider_23_GerbilAscentIndexProviderContract)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_provider_23_IndexProvider_2e_ ___GLO(4,___G_gerbil_2d_ascent_2f_table_2f_provider_23_IndexProvider_2e_)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_provider_23_IndexProvider_2e_ ___PRM(4,___G_gerbil_2d_ascent_2f_table_2f_provider_23_IndexProvider_2e_)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_ ___GLO(5,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_ ___PRM(5,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider ___GLO(6,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider ___PRM(6,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_ ___GLO(7,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_ ___PRM(7,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_hash_2d_index_2d_provider ___GLO(8,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_hash_2d_index_2d_provider)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_hash_2d_index_2d_provider ___PRM(8,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_hash_2d_index_2d_provider)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build ___GLO(9,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build ___PRM(9,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_ ___GLO(10,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_ ___PRM(10,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup ___GLO(11,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup ___PRM(11,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_provider_3a__3a_timestamp ___GLO(12,___G_gerbil_2d_ascent_2f_table_2f_provider_3a__3a_timestamp)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_provider_3a__3a_timestamp ___PRM(12,___G_gerbil_2d_ascent_2f_table_2f_provider_3a__3a_timestamp)
#define ___GLO_gerbil_2d_ascent____table____provider_23_ ___GLO(13,___G_gerbil_2d_ascent____table____provider_23_)
#define ___PRM_gerbil_2d_ascent____table____provider_23_ ___PRM(13,___G_gerbil_2d_ascent____table____provider_23_)
#define ___GLO_clan_2f_poo_2f_mop_23_validate ___GLO(14,___G_clan_2f_poo_2f_mop_23_validate)
#define ___PRM_clan_2f_poo_2f_mop_23_validate ___PRM(14,___G_clan_2f_poo_2f_mop_23_validate)
#define ___GLO_clan_2f_poo_2f_object_23__24_self_2d_slot_2d_spec_3a__3a_t ___GLO(15,___G_clan_2f_poo_2f_object_23__24_self_2d_slot_2d_spec_3a__3a_t)
#define ___PRM_clan_2f_poo_2f_object_23__24_self_2d_slot_2d_spec_3a__3a_t ___PRM(15,___G_clan_2f_poo_2f_object_23__24_self_2d_slot_2d_spec_3a__3a_t)
#define ___GLO_clan_2f_poo_2f_object_23__2e_ref ___GLO(16,___G_clan_2f_poo_2f_object_23__2e_ref)
#define ___PRM_clan_2f_poo_2f_object_23__2e_ref ___PRM(16,___G_clan_2f_poo_2f_object_23__2e_ref)
#define ___GLO_clan_2f_poo_2f_object_23_object_3a__3a__3a_init_21______25_ ___GLO(17,___G_clan_2f_poo_2f_object_23_object_3a__3a__3a_init_21______25_)
#define ___PRM_clan_2f_poo_2f_object_23_object_3a__3a__3a_init_21______25_ ___PRM(17,___G_clan_2f_poo_2f_object_23_object_3a__3a__3a_init_21______25_)
#define ___GLO_clan_2f_poo_2f_object_23_object_3a__3a_t ___GLO(18,___G_clan_2f_poo_2f_object_23_object_3a__3a_t)
#define ___PRM_clan_2f_poo_2f_object_23_object_3a__3a_t ___PRM(18,___G_clan_2f_poo_2f_object_23_object_3a__3a_t)
#define ___GLO_core_2f_types_23_PooFlowNativeObjectContract_2e_ ___GLO(19,___G_core_2f_types_23_PooFlowNativeObjectContract_2e_)
#define ___PRM_core_2f_types_23_PooFlowNativeObjectContract_2e_ ___PRM(19,___G_core_2f_types_23_PooFlowNativeObjectContract_2e_)
#define ___GLO_core_2f_types_23_poo_2d_flow_2d_predicate_2d_contract ___GLO(20,___G_core_2f_types_23_poo_2d_flow_2d_predicate_2d_contract)
#define ___PRM_core_2f_types_23_poo_2d_flow_2d_predicate_2d_contract ___PRM(20,___G_core_2f_types_23_poo_2d_flow_2d_predicate_2d_contract)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_build ___GLO(21,___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_build)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_build ___PRM(21,___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_build)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_extend_21_ ___GLO(22,___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_extend_21_)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_extend_21_ ___PRM(22,___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_extend_21_)
#define ___GLO_hash_2d_get ___GLO(23,___G_hash_2d_get)
#define ___PRM_hash_2d_get ___PRM(23,___G_hash_2d_get)
#define ___GLO_procedure_3f_ ___GLO(24,___G_procedure_3f_)
#define ___PRM_procedure_3f_ ___PRM(24,___G_procedure_3f_)

___DEF_SUB_BIGFIX(___X0,1UL)
               ___BIGFIX1(0x6acb08efL)
___DEF_SUB_VEC(___X1,6UL)
               ___VEC1(___REF_SUB(2))
               ___VEC1(___REF_SUB(3))
               ___VEC1(___REF_NUL)
               ___VEC1(___REF_FIX(1))
               ___VEC1(___REF_PRC(1))
               ___VEC1(___REF_FAL)
               ___VEC0
___DEF_SUB_VEC(___X2,1UL)
               ___VEC1(___REF_SYM(11,___S_gerbil_2d_ascent____table____provider))
               ___VEC0
___DEF_SUB_VEC(___X3,0UL)
               ___VEC0

___BEGIN_SUB
 ___DEF_SUB(___X0)
,___DEF_SUB(___X1)
,___DEF_SUB(___X2)
,___DEF_SUB(___X3)
___END_SUB



#undef ___MD_ALL
#define ___MD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___MR_ALL
#define ___MR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___MW_ALL
#define ___MW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_M_COD
___BEGIN_M_HLBL
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L1_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L2_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L3_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L4_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L5_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L6_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L7_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L8_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L9_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L10_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L11_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L12_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L13_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L14_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L15_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L16_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L17_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L18_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L19_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L20_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L21_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L22_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L23_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L24_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L25_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L26_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL(___L27_gerbil_2d_ascent____table____provider_23_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_)
___END_M_HLBL

___BEGIN_M_SW

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent____table____provider_23_
#undef ___PH_LBL0
#define ___PH_LBL0 1
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L1_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L2_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L3_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L4_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L5_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L6_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L7_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L8_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L9_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L10_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L11_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L12_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L13_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L14_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L15_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L16_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L17_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L18_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L19_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L20_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L21_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L22_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L23_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L24_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L25_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L26_gerbil_2d_ascent____table____provider_23_)
___DEF_P_HLBL(___L27_gerbil_2d_ascent____table____provider_23_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent____table____provider_23_)
   ___IF_NARGS_EQ(0,___NOTHING)
   ___WRONG_NARGS(0,0,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent____table____provider_23_)
   ___SET_GLO(12,___G_gerbil_2d_ascent_2f_table_2f_provider_3a__3a_timestamp,___BIGFIX(0,1791690991LL))
   ___SET_STK(1,___R0)
   ___SET_R3(___LBL(27))
   ___SET_R2(___PRM_procedure_3f_)
   ___SET_R1(___SYM_ascent_2f_index_2d_provider_2d_procedure)
   ___ADJFP(4)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent____table____provider_23_)
   ___SET_R0(___LBL(2))
   ___JUMPGLONOTSAFE(___SET_NARGS(3),20,___G_core_2f_types_23_poo_2d_flow_2d_predicate_2d_contract)
___DEF_SLBL(2,___L2_gerbil_2d_ascent____table____provider_23_)
   ___SET_GLO(2,___G_gerbil_2d_ascent_2f_table_2f_provider_23__2b_procedure_2b_,___R1)
   ___BEGIN_ALLOC_STRUCTURE(8UL)
   ___ADD_STRUCTURE_ELEM(0,___GLO_clan_2f_poo_2f_object_23_object_3a__3a_t)
   ___ADD_STRUCTURE_ELEM(1,___FAL)
   ___ADD_STRUCTURE_ELEM(2,___FAL)
   ___ADD_STRUCTURE_ELEM(3,___FAL)
   ___ADD_STRUCTURE_ELEM(4,___FAL)
   ___ADD_STRUCTURE_ELEM(5,___FAL)
   ___ADD_STRUCTURE_ELEM(6,___FAL)
   ___ADD_STRUCTURE_ELEM(7,___FAL)
   ___END_ALLOC_STRUCTURE(8)
   ___SET_R1(___GET_STRUCTURE(8))
   ___BEGIN_ALLOC_STRUCTURE(2UL)
   ___ADD_STRUCTURE_ELEM(0,___GLO_clan_2f_poo_2f_object_23__24_self_2d_slot_2d_spec_3a__3a_t)
   ___ADD_STRUCTURE_ELEM(1,___LBL(26))
   ___END_ALLOC_STRUCTURE(2)
   ___SET_R2(___GET_STRUCTURE(2))
   ___SET_R2(___CONS(___SYM_sexp,___R2))
   ___BEGIN_ALLOC_STRUCTURE(2UL)
   ___ADD_STRUCTURE_ELEM(0,___GLO_clan_2f_poo_2f_object_23__24_self_2d_slot_2d_spec_3a__3a_t)
   ___ADD_STRUCTURE_ELEM(1,___LBL(25))
   ___END_ALLOC_STRUCTURE(2)
   ___SET_R3(___GET_STRUCTURE(2))
   ___SET_R3(___CONS(___SYM_identity,___R3))
   ___BEGIN_ALLOC_STRUCTURE(2UL)
   ___ADD_STRUCTURE_ELEM(0,___GLO_clan_2f_poo_2f_object_23__24_self_2d_slot_2d_spec_3a__3a_t)
   ___ADD_STRUCTURE_ELEM(1,___LBL(20))
   ___END_ALLOC_STRUCTURE(2)
   ___SET_R4(___GET_STRUCTURE(2))
   ___SET_R4(___CONS(___SYM_proto,___R4))
   ___BEGIN_ALLOC_STRUCTURE(2UL)
   ___ADD_STRUCTURE_ELEM(0,___GLO_clan_2f_poo_2f_object_23__24_self_2d_slot_2d_spec_3a__3a_t)
   ___ADD_STRUCTURE_ELEM(1,___LBL(18))
   ___END_ALLOC_STRUCTURE(2)
   ___SET_R0(___GET_STRUCTURE(2))
   ___SET_R0(___CONS(___SYM_responsibilities,___R0))
   ___BEGIN_ALLOC_LIST(4UL,___R0)
   ___ADD_LIST_ELEM(1,___R4)
   ___ADD_LIST_ELEM(2,___R3)
   ___ADD_LIST_ELEM(3,___R2)
   ___END_ALLOC_LIST(4)
   ___SET_R2(___GET_LIST(4))
   ___SET_R3(___NUL)
   ___SET_STK(-2,___R1)
   ___SET_STK(5,___FAL)
   ___SET_STK(6,___GLO_core_2f_types_23_PooFlowNativeObjectContract_2e_)
   ___SET_STK(-1,___R3)
   ___SET_R3(___R1)
   ___SET_STK(0,___R2)
   ___SET_R2(___STK(-1))
   ___SET_R1(___STK(0))
   ___SET_R0(___LBL(4))
   ___ADJFP(6)
   ___CHECK_HEAP(3,4096)
___DEF_SLBL(3,___L3_gerbil_2d_ascent____table____provider_23_)
   ___JUMPGLONOTSAFE(___SET_NARGS(5),17,___G_clan_2f_poo_2f_object_23_object_3a__3a__3a_init_21______25_)
___DEF_SLBL(4,___L4_gerbil_2d_ascent____table____provider_23_)
   ___SET_GLO(3,___G_gerbil_2d_ascent_2f_table_2f_provider_23_GerbilAscentIndexProviderContract,___STK(-6))
   ___SET_R2(___SYM_proto)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_table_2f_provider_23_GerbilAscentIndexProviderContract)
   ___SET_R0(___LBL(5))
   ___ADJFP(-4)
   ___JUMPGLONOTSAFE(___SET_NARGS(2),16,___G_clan_2f_poo_2f_object_23__2e_ref)
___DEF_SLBL(5,___L5_gerbil_2d_ascent____table____provider_23_)
   ___SET_GLO(4,___G_gerbil_2d_ascent_2f_table_2f_provider_23_IndexProvider_2e_,___R1)
   ___BEGIN_ALLOC_STRUCTURE(8UL)
   ___ADD_STRUCTURE_ELEM(0,___GLO_clan_2f_poo_2f_object_23_object_3a__3a_t)
   ___ADD_STRUCTURE_ELEM(1,___FAL)
   ___ADD_STRUCTURE_ELEM(2,___FAL)
   ___ADD_STRUCTURE_ELEM(3,___FAL)
   ___ADD_STRUCTURE_ELEM(4,___FAL)
   ___ADD_STRUCTURE_ELEM(5,___FAL)
   ___ADD_STRUCTURE_ELEM(6,___FAL)
   ___ADD_STRUCTURE_ELEM(7,___FAL)
   ___END_ALLOC_STRUCTURE(8)
   ___SET_R1(___GET_STRUCTURE(8))
   ___BEGIN_ALLOC_STRUCTURE(2UL)
   ___ADD_STRUCTURE_ELEM(0,___GLO_clan_2f_poo_2f_object_23__24_self_2d_slot_2d_spec_3a__3a_t)
   ___ADD_STRUCTURE_ELEM(1,___LBL(17))
   ___END_ALLOC_STRUCTURE(2)
   ___SET_R2(___GET_STRUCTURE(2))
   ___SET_R2(___CONS(___SYM__2e_build_2d_index,___R2))
   ___BEGIN_ALLOC_STRUCTURE(2UL)
   ___ADD_STRUCTURE_ELEM(0,___GLO_clan_2f_poo_2f_object_23__24_self_2d_slot_2d_spec_3a__3a_t)
   ___ADD_STRUCTURE_ELEM(1,___LBL(16))
   ___END_ALLOC_STRUCTURE(2)
   ___SET_R3(___GET_STRUCTURE(2))
   ___SET_R3(___CONS(___SYM__2e_extend_2d_index_21_,___R3))
   ___BEGIN_ALLOC_STRUCTURE(2UL)
   ___ADD_STRUCTURE_ELEM(0,___GLO_clan_2f_poo_2f_object_23__24_self_2d_slot_2d_spec_3a__3a_t)
   ___ADD_STRUCTURE_ELEM(1,___LBL(12))
   ___END_ALLOC_STRUCTURE(2)
   ___SET_R4(___GET_STRUCTURE(2))
   ___SET_R4(___CONS(___SYM__2e_lookup_2d_index,___R4))
   ___BEGIN_ALLOC_LIST(3UL,___R4)
   ___ADD_LIST_ELEM(1,___R3)
   ___ADD_LIST_ELEM(2,___R2)
   ___END_ALLOC_LIST(3)
   ___SET_R2(___GET_LIST(3))
   ___SET_R3(___NUL)
   ___SET_STK(-2,___R1)
   ___SET_STK(5,___FAL)
   ___SET_STK(6,___GLO_gerbil_2d_ascent_2f_table_2f_provider_23_IndexProvider_2e_)
   ___SET_STK(-1,___R3)
   ___SET_R3(___R1)
   ___SET_STK(0,___R2)
   ___SET_R2(___STK(-1))
   ___SET_R1(___STK(0))
   ___SET_R0(___LBL(7))
   ___ADJFP(6)
   ___CHECK_HEAP(6,4096)
___DEF_SLBL(6,___L6_gerbil_2d_ascent____table____provider_23_)
   ___JUMPGLONOTSAFE(___SET_NARGS(5),17,___G_clan_2f_poo_2f_object_23_object_3a__3a__3a_init_21______25_)
___DEF_SLBL(7,___L7_gerbil_2d_ascent____table____provider_23_)
   ___SET_R2(___STK(-6))
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_table_2f_provider_23_GerbilAscentIndexProviderContract)
   ___SET_R0(___LBL(8))
   ___ADJFP(-4)
   ___JUMPGLONOTSAFE(___SET_NARGS(2),14,___G_clan_2f_poo_2f_mop_23_validate)
___DEF_SLBL(8,___L8_gerbil_2d_ascent____table____provider_23_)
   ___SET_GLO(0,___G_gerbil_2d_ascent_2f_table_2f_provider_23__2b_canonical_2d_hash_2d_index_2d_provider_2b_,___R1)
   ___SET_GLO(8,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_hash_2d_index_2d_provider,___GLO_gerbil_2d_ascent_2f_table_2f_provider_23__2b_canonical_2d_hash_2d_index_2d_provider_2b_)
   ___BEGIN_ALLOC_STRUCTURE(8UL)
   ___ADD_STRUCTURE_ELEM(0,___GLO_clan_2f_poo_2f_object_23_object_3a__3a_t)
   ___ADD_STRUCTURE_ELEM(1,___FAL)
   ___ADD_STRUCTURE_ELEM(2,___FAL)
   ___ADD_STRUCTURE_ELEM(3,___FAL)
   ___ADD_STRUCTURE_ELEM(4,___FAL)
   ___ADD_STRUCTURE_ELEM(5,___FAL)
   ___ADD_STRUCTURE_ELEM(6,___FAL)
   ___ADD_STRUCTURE_ELEM(7,___FAL)
   ___END_ALLOC_STRUCTURE(8)
   ___SET_R1(___GET_STRUCTURE(8))
   ___BEGIN_ALLOC_STRUCTURE(2UL)
   ___ADD_STRUCTURE_ELEM(0,___GLO_clan_2f_poo_2f_object_23__24_self_2d_slot_2d_spec_3a__3a_t)
   ___ADD_STRUCTURE_ELEM(1,___LBL(17))
   ___END_ALLOC_STRUCTURE(2)
   ___SET_R2(___GET_STRUCTURE(2))
   ___SET_R2(___CONS(___SYM__2e_build_2d_index,___R2))
   ___BEGIN_ALLOC_STRUCTURE(2UL)
   ___ADD_STRUCTURE_ELEM(0,___GLO_clan_2f_poo_2f_object_23__24_self_2d_slot_2d_spec_3a__3a_t)
   ___ADD_STRUCTURE_ELEM(1,___LBL(16))
   ___END_ALLOC_STRUCTURE(2)
   ___SET_R3(___GET_STRUCTURE(2))
   ___SET_R3(___CONS(___SYM__2e_extend_2d_index_21_,___R3))
   ___BEGIN_ALLOC_STRUCTURE(2UL)
   ___ADD_STRUCTURE_ELEM(0,___GLO_clan_2f_poo_2f_object_23__24_self_2d_slot_2d_spec_3a__3a_t)
   ___ADD_STRUCTURE_ELEM(1,___LBL(12))
   ___END_ALLOC_STRUCTURE(2)
   ___SET_R4(___GET_STRUCTURE(2))
   ___SET_R4(___CONS(___SYM__2e_lookup_2d_index,___R4))
   ___BEGIN_ALLOC_LIST(3UL,___R4)
   ___ADD_LIST_ELEM(1,___R3)
   ___ADD_LIST_ELEM(2,___R2)
   ___END_ALLOC_LIST(3)
   ___SET_R2(___GET_LIST(3))
   ___SET_R3(___NUL)
   ___SET_STK(-2,___R1)
   ___SET_STK(5,___FAL)
   ___SET_STK(6,___GLO_gerbil_2d_ascent_2f_table_2f_provider_23_IndexProvider_2e_)
   ___SET_STK(-1,___R3)
   ___SET_R3(___R1)
   ___SET_STK(0,___R2)
   ___SET_R2(___STK(-1))
   ___SET_R1(___STK(0))
   ___SET_R0(___LBL(10))
   ___ADJFP(6)
   ___CHECK_HEAP(9,4096)
___DEF_SLBL(9,___L9_gerbil_2d_ascent____table____provider_23_)
   ___JUMPGLONOTSAFE(___SET_NARGS(5),17,___G_clan_2f_poo_2f_object_23_object_3a__3a__3a_init_21______25_)
___DEF_SLBL(10,___L10_gerbil_2d_ascent____table____provider_23_)
   ___SET_R2(___STK(-6))
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_table_2f_provider_23_GerbilAscentIndexProviderContract)
   ___SET_R0(___LBL(11))
   ___ADJFP(-4)
   ___JUMPGLONOTSAFE(___SET_NARGS(2),14,___G_clan_2f_poo_2f_mop_23_validate)
___DEF_SLBL(11,___L11_gerbil_2d_ascent____table____provider_23_)
   ___SET_GLO(1,___G_gerbil_2d_ascent_2f_table_2f_provider_23__2b_curried_2d_index_2d_provider_2b_,___R1)
   ___SET_GLO(6,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider,___GLO_gerbil_2d_ascent_2f_table_2f_provider_23__2b_curried_2d_index_2d_provider_2b_)
   ___SET_R1(___VOID)
   ___ADJFP(-4)
   ___JUMPRET(___STK(1))
___DEF_SLBL(12,___L12_gerbil_2d_ascent____table____provider_23_)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(12,1,0,0)
   ___SET_R1(___LBL(13))
   ___JUMPRET(___R0)
___DEF_SLBL(13,___L13_gerbil_2d_ascent____table____provider_23_)
   ___IF_NARGS_EQ(2,___NOTHING)
   ___WRONG_NARGS(13,2,0,0)
   ___SET_STK(1,___R0)
   ___ADJFP(4)
   ___POLL(14)
___DEF_SLBL(14,___L14_gerbil_2d_ascent____table____provider_23_)
   ___SET_R0(___LBL(15))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),23,___G_hash_2d_get)
___DEF_SLBL(15,___L15_gerbil_2d_ascent____table____provider_23_)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L28_gerbil_2d_ascent____table____provider_23_)
   ___END_IF
   ___ADJFP(-4)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L28_gerbil_2d_ascent____table____provider_23_)
   ___SET_R1(___NUL)
   ___ADJFP(-4)
   ___JUMPRET(___STK(1))
___DEF_SLBL(16,___L16_gerbil_2d_ascent____table____provider_23_)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(16,1,0,0)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_extend_21_)
   ___JUMPRET(___R0)
___DEF_SLBL(17,___L17_gerbil_2d_ascent____table____provider_23_)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(17,1,0,0)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_build)
   ___JUMPRET(___R0)
___DEF_SLBL(18,___L18_gerbil_2d_ascent____table____provider_23_)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(18,1,0,0)
   ___BEGIN_ALLOC_STRUCTURE(8UL)
   ___ADD_STRUCTURE_ELEM(0,___GLO_clan_2f_poo_2f_object_23_object_3a__3a_t)
   ___ADD_STRUCTURE_ELEM(1,___FAL)
   ___ADD_STRUCTURE_ELEM(2,___FAL)
   ___ADD_STRUCTURE_ELEM(3,___FAL)
   ___ADD_STRUCTURE_ELEM(4,___FAL)
   ___ADD_STRUCTURE_ELEM(5,___FAL)
   ___ADD_STRUCTURE_ELEM(6,___FAL)
   ___ADD_STRUCTURE_ELEM(7,___FAL)
   ___END_ALLOC_STRUCTURE(8)
   ___SET_R1(___GET_STRUCTURE(8))
   ___BEGIN_ALLOC_STRUCTURE(2UL)
   ___ADD_STRUCTURE_ELEM(0,___GLO_clan_2f_poo_2f_object_23__24_self_2d_slot_2d_spec_3a__3a_t)
   ___ADD_STRUCTURE_ELEM(1,___LBL(24))
   ___END_ALLOC_STRUCTURE(2)
   ___SET_R2(___GET_STRUCTURE(2))
   ___SET_R2(___CONS(___SYM__2e_build_2d_index,___R2))
   ___BEGIN_ALLOC_STRUCTURE(2UL)
   ___ADD_STRUCTURE_ELEM(0,___GLO_clan_2f_poo_2f_object_23__24_self_2d_slot_2d_spec_3a__3a_t)
   ___ADD_STRUCTURE_ELEM(1,___LBL(24))
   ___END_ALLOC_STRUCTURE(2)
   ___SET_R3(___GET_STRUCTURE(2))
   ___SET_R3(___CONS(___SYM__2e_extend_2d_index_21_,___R3))
   ___BEGIN_ALLOC_STRUCTURE(2UL)
   ___ADD_STRUCTURE_ELEM(0,___GLO_clan_2f_poo_2f_object_23__24_self_2d_slot_2d_spec_3a__3a_t)
   ___ADD_STRUCTURE_ELEM(1,___LBL(24))
   ___END_ALLOC_STRUCTURE(2)
   ___SET_R4(___GET_STRUCTURE(2))
   ___SET_R4(___CONS(___SYM__2e_lookup_2d_index,___R4))
   ___BEGIN_ALLOC_LIST(3UL,___R4)
   ___ADD_LIST_ELEM(1,___R3)
   ___ADD_LIST_ELEM(2,___R2)
   ___END_ALLOC_LIST(3)
   ___SET_R2(___GET_LIST(3))
   ___CHECK_HEAP(19,4096)
___DEF_SLBL(19,___L19_gerbil_2d_ascent____table____provider_23_)
   ___GOTO(___L29_gerbil_2d_ascent____table____provider_23_)
___DEF_SLBL(20,___L20_gerbil_2d_ascent____table____provider_23_)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(20,1,0,0)
   ___BEGIN_ALLOC_STRUCTURE(8UL)
   ___ADD_STRUCTURE_ELEM(0,___GLO_clan_2f_poo_2f_object_23_object_3a__3a_t)
   ___ADD_STRUCTURE_ELEM(1,___FAL)
   ___ADD_STRUCTURE_ELEM(2,___FAL)
   ___ADD_STRUCTURE_ELEM(3,___FAL)
   ___ADD_STRUCTURE_ELEM(4,___FAL)
   ___ADD_STRUCTURE_ELEM(5,___FAL)
   ___ADD_STRUCTURE_ELEM(6,___FAL)
   ___ADD_STRUCTURE_ELEM(7,___FAL)
   ___END_ALLOC_STRUCTURE(8)
   ___SET_R1(___GET_STRUCTURE(8))
   ___SET_R2(___NUL)
   ___CHECK_HEAP(21,4096)
___DEF_SLBL(21,___L21_gerbil_2d_ascent____table____provider_23_)
___DEF_GLBL(___L29_gerbil_2d_ascent____table____provider_23_)
   ___SET_R3(___NUL)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(9,___FAL)
   ___SET_STK(10,___NUL)
   ___SET_STK(3,___R3)
   ___SET_R3(___R1)
   ___SET_STK(4,___R2)
   ___SET_R2(___STK(3))
   ___SET_R1(___STK(4))
   ___ADJFP(10)
   ___POLL(22)
___DEF_SLBL(22,___L22_gerbil_2d_ascent____table____provider_23_)
   ___SET_R0(___LBL(23))
   ___JUMPGLONOTSAFE(___SET_NARGS(5),17,___G_clan_2f_poo_2f_object_23_object_3a__3a__3a_init_21______25_)
___DEF_SLBL(23,___L23_gerbil_2d_ascent____table____provider_23_)
   ___SET_R1(___STK(-6))
   ___ADJFP(-8)
   ___JUMPRET(___STK(1))
___DEF_SLBL(24,___L24_gerbil_2d_ascent____table____provider_23_)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(24,1,0,0)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_table_2f_provider_23__2b_procedure_2b_)
   ___JUMPRET(___R0)
___DEF_SLBL(25,___L25_gerbil_2d_ascent____table____provider_23_)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(25,1,0,0)
   ___SET_R1(___SYM_ascent_2f_index_2d_provider)
   ___JUMPRET(___R0)
___DEF_SLBL(26,___L26_gerbil_2d_ascent____table____provider_23_)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(26,1,0,0)
   ___SET_R1(___SYM_GerbilAscentIndexProviderContract)
   ___JUMPRET(___R0)
___DEF_SLBL(27,___L27_gerbil_2d_ascent____table____provider_23_)
   ___IF_NARGS_EQ(2,___NOTHING)
   ___WRONG_NARGS(27,2,0,0)
   ___SET_R1(___NUL)
   ___JUMPRET(___R0)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build
#undef ___PH_LBL0
#define ___PH_LBL0 30
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
   ___IF_NARGS_EQ(3,___NOTHING)
   ___WRONG_NARGS(0,3,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R2)
   ___SET_STK(3,___R3)
   ___SET_R2(___SYM__2e_build_2d_index)
   ___ADJFP(8)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
   ___SET_R0(___LBL(2))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),16,___G_clan_2f_poo_2f_object_23__2e_ref)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
   ___SET_R2(___STK(-5))
   ___SET_STK(-5,___R1)
   ___SET_R1(___STK(-6))
   ___SET_R0(___STK(-7))
   ___POLL(3)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
   ___ADJFP(-8)
   ___JUMPGENSAFE(___SET_NARGS(2),___STK(3))
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_
#undef ___PH_LBL0
#define ___PH_LBL0 35
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
   ___IF_NARGS_EQ(4,___NOTHING)
   ___WRONG_NARGS(0,4,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_STK(4,___R3)
   ___SET_R1(___STK(0))
   ___SET_R2(___SYM__2e_extend_2d_index_21_)
   ___ADJFP(7)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
   ___SET_R0(___LBL(2))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),16,___G_clan_2f_poo_2f_object_23__2e_ref)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
   ___SET_R3(___STK(-3))
   ___SET_R2(___STK(-4))
   ___SET_STK(-7,___R1)
   ___SET_R1(___STK(-5))
   ___SET_R0(___STK(-6))
   ___POLL(3)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
   ___ADJFP(-8)
   ___JUMPGENSAFE(___SET_NARGS(3),___STK(1))
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup
#undef ___PH_LBL0
#define ___PH_LBL0 40
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
   ___IF_NARGS_EQ(3,___NOTHING)
   ___WRONG_NARGS(0,3,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R2)
   ___SET_STK(3,___R3)
   ___SET_R2(___SYM__2e_lookup_2d_index)
   ___ADJFP(8)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
   ___SET_R0(___LBL(2))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),16,___G_clan_2f_poo_2f_object_23__2e_ref)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
   ___SET_R2(___STK(-5))
   ___SET_STK(-5,___R1)
   ___SET_R1(___STK(-6))
   ___SET_R0(___STK(-7))
   ___POLL(3)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
   ___ADJFP(-8)
   ___JUMPGENSAFE(___SET_NARGS(2),___STK(3))
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_
#undef ___PH_LBL0
#define ___PH_LBL0 45
#undef ___PD_ALL
#define ___PD_ALL ___D_R0 ___D_R1
#undef ___PR_ALL
#define ___PR_ALL ___R_R0 ___R_R1
#undef ___PW_ALL
#define ___PW_ALL ___W_R1
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_)
   ___SET_R1(___BOOLEAN(___EQP(___R1,___GLO_gerbil_2d_ascent_2f_table_2f_provider_23__2b_curried_2d_index_2d_provider_2b_)))
   ___JUMPRET(___R0)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_
#undef ___PH_LBL0
#define ___PH_LBL0 47
#undef ___PD_ALL
#define ___PD_ALL ___D_R0 ___D_R1 ___D_R2
#undef ___PR_ALL
#define ___PR_ALL ___R_R0 ___R_R1 ___R_R2
#undef ___PW_ALL
#define ___PW_ALL ___W_R1 ___W_R2
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_)
   ___SET_R2(___BOOLEAN(___EQP(___R1,___GLO_gerbil_2d_ascent_2f_table_2f_provider_23__2b_canonical_2d_hash_2d_index_2d_provider_2b_)))
   ___IF(___NOT(___NOTFALSEP(___R2)))
   ___GOTO(___L1_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_)
   ___END_IF
   ___SET_R1(___R2)
   ___JUMPRET(___R0)
___DEF_GLBL(___L1_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_)
   ___SET_R1(___BOOLEAN(___EQP(___R1,___GLO_gerbil_2d_ascent_2f_table_2f_provider_23__2b_curried_2d_index_2d_provider_2b_)))
   ___JUMPRET(___R0)
___END_P_SW
___END_P_COD

___END_M_SW
___END_M_COD

___BEGIN_LBL
 ___DEF_LBL_INTRO(___H_gerbil_2d_ascent____table____provider_23_,___REF_SYM(12,___S_gerbil_2d_ascent____table____provider_23_),___REF_FAL,28,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____table____provider_23_,0,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent____table____provider_23_,___IFD(___RETI,4,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____table____provider_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____table____provider_23_,___OFD(___RETI,10,0,0x3f303L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____table____provider_23_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____table____provider_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____table____provider_23_,___OFD(___RETI,10,0,0x3f303L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____table____provider_23_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____table____provider_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____table____provider_23_,___OFD(___RETI,10,0,0x3f303L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____table____provider_23_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____table____provider_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____table____provider_23_,1,-1)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____table____provider_23_,2,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent____table____provider_23_,___IFD(___RETI,4,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____table____provider_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____table____provider_23_,1,-1)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____table____provider_23_,1,-1)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____table____provider_23_,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent____table____provider_23_,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____table____provider_23_,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent____table____provider_23_,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____table____provider_23_,___OFD(___RETI,10,0,0x3f303L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____table____provider_23_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____table____provider_23_,1,-1)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____table____provider_23_,1,-1)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____table____provider_23_,1,-1)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____table____provider_23_,2,-1)
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build,___REF_SYM(8,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build),___REF_FAL,4,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build,3,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build,___IFD(___RETI,8,0,0x3f07L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build,___IFD(___RETI,8,8,0x3f04L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_,___REF_SYM(9,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_),___REF_FAL,4,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_,4,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_,___IFD(___RETI,8,1,0x3f1eL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_,___IFD(___RETN,5,1,0x1eL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_,___IFD(___RETI,8,8,0x3f01L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup,___REF_SYM(10,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup),___REF_FAL,4,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup,3,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup,___IFD(___RETI,8,0,0x3f07L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup,___IFD(___RETI,8,8,0x3f04L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_,___REF_SYM(7,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_),___REF_FAL,1,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_,1,-1)
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_,___REF_SYM(6,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_),___REF_FAL,1,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_,1,-1)
___END_LBL

___BEGIN_OFD
 ___DEF_OFD(___RETI,10,0)
               ___GCMAP1(0x3f303L)
,___DEF_OFD(___RETI,10,0)
               ___GCMAP1(0x3f303L)
,___DEF_OFD(___RETI,10,0)
               ___GCMAP1(0x3f303L)
,___DEF_OFD(___RETI,10,0)
               ___GCMAP1(0x3f303L)
___END_OFD

___BEGIN_MOD_PRM
___DEF_MOD_PRM(13,___G_gerbil_2d_ascent____table____provider_23_,1)
___DEF_MOD_PRM(9,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build,30)
___DEF_MOD_PRM(10,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_,35)
___DEF_MOD_PRM(11,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup,40)
___DEF_MOD_PRM(7,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_,45)
___DEF_MOD_PRM(5,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_,47)
___END_MOD_PRM

___BEGIN_MOD_C_INIT
___END_MOD_C_INIT

___BEGIN_MOD_GLO
___DEF_MOD_GLO(13,___G_gerbil_2d_ascent____table____provider_23_,1)
___DEF_MOD_GLO(9,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build,30)
___DEF_MOD_GLO(10,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_,35)
___DEF_MOD_GLO(11,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup,40)
___DEF_MOD_GLO(7,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_,45)
___DEF_MOD_GLO(5,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_,47)
___END_MOD_GLO

___BEGIN_MOD_SYM_KEY
___DEF_MOD_SYM(0,___S__2e_build_2d_index,".build-index")
___DEF_MOD_SYM(1,___S__2e_extend_2d_index_21_,".extend-index!")
___DEF_MOD_SYM(2,___S__2e_lookup_2d_index,".lookup-index")
___DEF_MOD_SYM(3,___S_GerbilAscentIndexProviderContract,"GerbilAscentIndexProviderContract")

___DEF_MOD_SYM(4,___S_ascent_2f_index_2d_provider,"ascent/index-provider")
___DEF_MOD_SYM(5,___S_ascent_2f_index_2d_provider_2d_procedure,"ascent/index-provider-procedure")

___DEF_MOD_SYM(6,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_,"gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?")

___DEF_MOD_SYM(7,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_curried_2d_index_2d_provider_3f_,"gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider?")

___DEF_MOD_SYM(8,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build,"gerbil-ascent/table/provider#gerbil-ascent-index-provider-build")

___DEF_MOD_SYM(9,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_,"gerbil-ascent/table/provider#gerbil-ascent-index-provider-extend!")

___DEF_MOD_SYM(10,___S_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup,"gerbil-ascent/table/provider#gerbil-ascent-index-provider-lookup")

___DEF_MOD_SYM(11,___S_gerbil_2d_ascent____table____provider,"gerbil-ascent__table__provider")

___DEF_MOD_SYM(12,___S_gerbil_2d_ascent____table____provider_23_,"gerbil-ascent__table__provider#")

___DEF_MOD_SYM(13,___S_identity,"identity")
___DEF_MOD_SYM(14,___S_proto,"proto")
___DEF_MOD_SYM(15,___S_responsibilities,"responsibilities")
___DEF_MOD_SYM(16,___S_sexp,"sexp")
___END_MOD_SYM_KEY

#endif
