(declare (block) (standard-bindings) (extended-bindings))
(begin (begin) (load-module "gerbil-ascent/core/dependency-graph~0"))
