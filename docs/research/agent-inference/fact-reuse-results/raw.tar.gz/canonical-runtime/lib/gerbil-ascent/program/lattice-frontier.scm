(declare (block) (standard-bindings) (extended-bindings))
(begin (begin) (load-module "gerbil-ascent/program/lattice-frontier~0"))
