(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/objects::timestamp 1791686896)
  (begin
    (define gerbil-ascent/program/objects#current-declaration-check
      (make-parameter clan/poo/mop#validate))
    (define gerbil-ascent/program/objects#declaration-check
      (lambda (_%contract4857%_ _%value4858%_)
        ((let ()
           (declare (not safe))
           (gerbil-ascent/program/objects#current-declaration-check))
         _%contract4857%_
         _%value4858%_)))
    (define gerbil-ascent/program/objects#receive-inert-declarations
      (lambda (_%construct4849%_ _%receive4850%_)
        (call-with-values
         (lambda ()
           (let ((__tmp7698 (lambda () (_%construct4849%_)))
                 (__tmp7697
                  (lambda (_%_contract4854%_ _%value4855%_) _%value4855%_)))
             (declare (not safe))
             (call-with-parameters__1
              __tmp7698
              gerbil-ascent/program/objects#current-declaration-check
              __tmp7697)))
         _%receive4850%_)))
    (define gerbil-ascent/program/objects#validate-inert-root
      (lambda (_%contract4846%_ _%value4847%_)
        (let ((__tmp7699
               (if (null? (let ()
                            (declare (not safe))
                            (clan/poo/object#.ref _%value4847%_ 'rules)))
                   _%contract4846%_
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/program/types#gerbil-ascent-owned-root-contract
                      _%contract4846%_)))))
          (declare (not safe))
          (clan/poo/mop#validate __tmp7699 _%value4847%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-construct-inert-program
      (lambda (_%construct4837%_)
        (gerbil-ascent/program/objects#receive-inert-declarations
         _%construct4837%_
         (lambda _g7700_
           (let ((_g7701_ (let () (declare (not safe)) (##length _g7700_))))
             (cond ((let () (declare (not safe)) (##fx= _g7701_ 1))
                    (apply (lambda (_%program4839%_)
                             (gerbil-ascent/program/objects#validate-inert-root
                              gerbil-ascent/program/types#GerbilAscentProgramContract
                              _%program4839%_))
                           _g7700_))
                   ((let () (declare (not safe)) (##fx= _g7701_ 2))
                    (apply (lambda (_%program4841%_ _%output4842%_)
                             (let ((_%checked4844%_
                                    (gerbil-ascent/program/objects#validate-inert-root
                                     gerbil-ascent/program/types#GerbilAscentProgramContract
                                     _%program4841%_)))
                               (values _%checked4844%_ _%output4842%_)))
                           _g7700_))
                   (else
                    (##raise-wrong-number-of-arguments-exception
                     'case-lambda-dispatch
                     _g7700_))))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-construct-inert-fragment
      (lambda (_%construct4833%_)
        (gerbil-ascent/program/objects#receive-inert-declarations
         _%construct4833%_
         (lambda (_%fragment4835%_)
           (gerbil-ascent/program/objects#validate-inert-root
            gerbil-ascent/program/types#GerbilAscentFragmentContract
            _%fragment4835%_)))))
    (define gerbil-ascent/program/objects#Relation.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentRelationContract
         'proto)))
    (define gerbil-ascent/program/objects#Lattice.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentLatticeContract
         'proto)))
    (define gerbil-ascent/program/objects#Term.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentTermContract
         'proto)))
    (define gerbil-ascent/program/objects#Atom.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentAtomContract
         'proto)))
    (define gerbil-ascent/program/objects#Guard.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentGuardContract
         'proto)))
    (define gerbil-ascent/program/objects#Generator.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentGeneratorContract
         'proto)))
    (define gerbil-ascent/program/objects#Binding.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentBindingContract
         'proto)))
    (define gerbil-ascent/program/objects#Negation.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentNegationContract
         'proto)))
    (define gerbil-ascent/program/objects#Aggregate.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentAggregateContract
         'proto)))
    (define gerbil-ascent/program/objects#Rule.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentRuleContract
         'proto)))
    (define gerbil-ascent/program/objects#Fragment.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentFragmentContract
         'proto)))
    (define gerbil-ascent/program/objects#Program.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentProgramContract
         'proto)))
    (define gerbil-ascent/program/objects#gerbil-ascent-clause-plan
      (lambda (_%clause4829%_ _%atom-plan4830%_ _%bound4831%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%clause4829%_ '.plan))
         _%atom-plan4830%_
         _%bound4831%_)))
    (define gerbil-ascent/program/objects#name-index
      (lambda (_%names4794%_)
        (let ((_%index4796%_
               (let () (declare (not safe)) (make-hash-table-eq))))
          (for-each
           (lambda (_%$%g47974799%_)
             (let* ((_%h4802%_ _%index4796%_)
                    (_%key4805%_ _%$%g47974799%_)
                    (_%value4808%_ '#t)
                    (_%h4812%_ _%h4802%_)
                    (_%h4814%_ _%h4812%_))
               (declare (not safe))
               (__hash-put! _%h4814%_ _%key4805%_ _%value4808%_)))
           _%names4794%_)
          _%index4796%_)))
    (define gerbil-ascent/program/objects#wide-scope?
      (lambda (_%names4784%_)
        (letrec ((_%enough?4786%_
                  (lambda (_%remaining4788%_ _%left4789%_)
                    (if (pair? _%remaining4788%_)
                        (let ((_%$e4791%_
                               (let ()
                                 (declare (not safe))
                                 (##fx= _%left4789%_ '1))))
                          (if _%$e4791%_
                              _%$e4791%_
                              (_%enough?4786%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%remaining4788%_))
                               (let ()
                                 (declare (not safe))
                                 (##fx- _%left4789%_ '1)))))
                        '#f))))
          (_%enough?4786%_ _%names4784%_ '32))))
    (define gerbil-ascent/program/objects#gerbil-ascent-bound-membership
      (lambda (_%names4732%_)
        (if (gerbil-ascent/program/objects#wide-scope? _%names4732%_)
            (let ((_%index4736%_ '#f) (_%reads4737%_ '0))
              (lambda (_%name4739%_)
                (if _%index4736%_
                    (let* ((_%h4741%_ _%index4736%_)
                           (_%key4744%_ _%name4739%_)
                           (_%h4748%_
                            (let ()
                              (declare (not safe))
                              (cast HashTable::interface _%h4741%_)))
                           (_%h4750%_ _%h4748%_))
                      (declare (not safe))
                      (__hash-get _%h4750%_ _%key4744%_))
                    (begin
                      (set! _%reads4737%_
                            (let ()
                              (declare (not safe))
                              (##fx+ _%reads4737%_ '1)))
                      (if (let ()
                            (declare (not safe))
                            (##fx= _%reads4737%_ '32))
                          (begin
                            (set! _%index4736%_
                                  (gerbil-ascent/program/objects#name-index
                                   _%names4732%_))
                            (let* ((_%h4764%_ _%index4736%_)
                                   (_%key4767%_ _%name4739%_)
                                   (_%h4771%_
                                    (let ()
                                      (declare (not safe))
                                      (cast HashTable::interface _%h4764%_)))
                                   (_%h4773%_ _%h4771%_))
                              (declare (not safe))
                              (__hash-get _%h4773%_ _%key4767%_)))
                          (if (memq _%name4739%_ _%names4732%_) '#t '#f))))))
            (lambda (_%name4734%_)
              (if (memq _%name4734%_ _%names4732%_) '#t '#f)))))
    (define gerbil-ascent/program/objects#require-bound
      (lambda (_%names4727%_ _%bound?4728%_)
        (for-each
         (lambda (_%name4730%_)
           (if (_%bound?4728%_ _%name4730%_)
               '#!void
               (let ()
                 (declare (not safe))
                 (error '"unbound ASCENT clause variable" _%name4730%_))))
         _%names4727%_)))
    (define gerbil-ascent/program/objects#pattern-outputs
      (lambda (_%term4725%_)
        (if (eq? (car _%term4725%_) 'pattern)
            (vector-ref (cdr _%term4725%_) '0)
            '#f)))
    (define gerbil-ascent/program/objects#indexed-atom
      (lambda (_%plan4592%_ _%bound4593%_)
        (let* ((_%wide?4595%_
                (gerbil-ascent/program/objects#wide-scope?
                 (vector-ref _%plan4592%_ '1)))
               (_%prior?4597%_
                (gerbil-ascent/program/objects#gerbil-ascent-bound-membership
                 _%bound4593%_))
               (_%seen-bound4599%_
                (if _%wide?4595%_
                    (gerbil-ascent/program/objects#name-index _%bound4593%_)
                    _%bound4593%_)))
          (letrec ((_%seen?4602%_
                    (lambda (_%name4702%_)
                      (if _%wide?4595%_
                          (let* ((_%h4704%_ _%seen-bound4599%_)
                                 (_%key4707%_ _%name4702%_)
                                 (_%h4711%_
                                  (let ()
                                    (declare (not safe))
                                    (cast HashTable::interface _%h4704%_)))
                                 (_%h4713%_ _%h4711%_))
                            (declare (not safe))
                            (__hash-get _%h4713%_ _%key4707%_))
                          (memq _%name4702%_ _%seen-bound4599%_)))))
            (let _%loop4604%_ ((_%terms4606%_ (vector-ref _%plan4592%_ '1))
                               (_%column4607%_ '0)
                               (_%columns4608%_ '())
                               (_%bindings4609%_ '())
                               (_%key-terms4610%_ '()))
              (if (null? _%terms4606%_)
                  (vector (vector-ref _%plan4592%_ '0)
                          (vector-ref _%plan4592%_ '1)
                          (reverse _%columns4608%_)
                          (reverse _%bindings4609%_)
                          (reverse _%key-terms4610%_))
                  (let* ((_%term4612%_ (car _%terms4606%_))
                         (_%kind4614%_ (car _%term4612%_))
                         (_%inputs4616%_
                          (if (eq? _%kind4614%_ 'expression)
                              (vector-ref (cdr _%term4612%_) '0)
                              '#f)))
                    (if _%inputs4616%_
                        (gerbil-ascent/program/objects#require-bound
                         _%inputs4616%_
                         _%seen?4602%_)
                        '#!void)
                    (let* ((_%indexed?4625%_
                            (let ((_%$e4619%_ (eq? _%kind4614%_ 'literal)))
                              (if _%$e4619%_
                                  _%$e4619%_
                                  (let ((_%$e4622%_
                                         (if (eq? _%kind4614%_ 'variable)
                                             (let ((__tmp7702
                                                    (cdr _%term4612%_)))
                                               (declare (not safe))
                                               (_%prior?4597%_ __tmp7702))
                                             '#f)))
                                    (if _%$e4622%_
                                        _%$e4622%_
                                        (if _%inputs4616%_
                                            (let ()
                                              (declare (not safe))
                                              (andmap__0
                                               _%prior?4597%_
                                               _%inputs4616%_))
                                            '#f))))))
                           (_%binding4627%_
                            (if (and (eq? _%kind4614%_ 'variable)
                                     (not (_%seen?4602%_ (cdr _%term4612%_))))
                                (cons 'fresh-variable (cdr _%term4612%_))
                                _%term4612%_)))
                      (let ((_%$e4630%_ _%kind4614%_))
                        (if (eq? 'variable _%$e4630%_)
                            (if _%wide?4595%_
                                (let* ((_%h4633%_ _%seen-bound4599%_)
                                       (_%key4636%_ (cdr _%term4612%_))
                                       (_%value4639%_ '#t)
                                       (_%h4643%_
                                        (let ()
                                          (declare (not safe))
                                          (cast HashTable::interface
                                                _%h4633%_)))
                                       (_%h4645%_ _%h4643%_))
                                  (declare (not safe))
                                  (__hash-put!
                                   _%h4645%_
                                   _%key4636%_
                                   _%value4639%_))
                                (set! _%seen-bound4599%_
                                      (cons (cdr _%term4612%_)
                                            _%seen-bound4599%_)))
                            (if (eq? 'pattern _%$e4630%_)
                                (if _%wide?4595%_
                                    (for-each
                                     (lambda (_%$%g46724674%_)
                                       (let* ((_%h4677%_ _%seen-bound4599%_)
                                              (_%key4680%_ _%$%g46724674%_)
                                              (_%value4683%_ '#t)
                                              (_%h4687%_
                                               (let ()
                                                 (declare (not safe))
                                                 (cast HashTable::interface
                                                       _%h4677%_)))
                                              (_%h4689%_ _%h4687%_))
                                         (declare (not safe))
                                         (__hash-put!
                                          _%h4689%_
                                          _%key4680%_
                                          _%value4683%_)))
                                     (gerbil-ascent/program/objects#pattern-outputs
                                      _%term4612%_))
                                    (set! _%seen-bound4599%_
                                          (append (gerbil-ascent/program/objects#pattern-outputs
                                                   _%term4612%_)
                                                  _%seen-bound4599%_)))
                                '#!void)))
                      (_%loop4604%_
                       (cdr _%terms4606%_)
                       (+ _%column4607%_ '1)
                       (if _%indexed?4625%_
                           (cons _%column4607%_ _%columns4608%_)
                           _%columns4608%_)
                       (cons _%binding4627%_ _%bindings4609%_)
                       (if _%indexed?4625%_
                           (cons _%term4612%_ _%key-terms4610%_)
                           _%key-terms4610%_))))))))))
    (define gerbil-ascent/program/objects#atom-clause-plan
      (lambda (_%clause4572%_ _%atom-plan4573%_ _%bound4574%_)
        (let* ((_%plan4576%_
                (gerbil-ascent/program/objects#indexed-atom
                 (_%atom-plan4573%_ _%clause4572%_)
                 _%bound4574%_))
               (_%next-bound4589%_
                (let ((__tmp7704
                       (lambda (_%term4578%_ _%prior4579%_)
                         (if (eq? (car _%term4578%_) 'variable)
                             (cons (cdr _%term4578%_) _%prior4579%_)
                             (if (eq? (car _%term4578%_) 'pattern)
                                 (let _%loop4583%_ ((_%outputs4585%_
                                                     (gerbil-ascent/program/objects#pattern-outputs
                                                      _%term4578%_))
                                                    (_%next4586%_
                                                     _%prior4579%_))
                                   (if (null? _%outputs4585%_)
                                       _%next4586%_
                                       (begin
                                         (if (memq (car _%outputs4585%_)
                                                   _%next4586%_)
                                             (let ((__tmp7705
                                                    (car _%outputs4585%_)))
                                               (declare (not safe))
                                               (error '"ASCENT pattern variable already bound"
                                                      __tmp7705))
                                             '#!void)
                                         (_%loop4583%_
                                          (cdr _%outputs4585%_)
                                          (cons (car _%outputs4585%_)
                                                _%next4586%_)))))
                                 _%prior4579%_))))
                      (__tmp7703 (vector-ref _%plan4576%_ '1)))
                  (declare (not safe))
                  (foldl__0 __tmp7704 _%bound4574%_ __tmp7703))))
          (vector (vector 'atom _%plan4576%_) _%next-bound4589%_ '1))))
    (define gerbil-ascent/program/objects#negation-clause-plan
      (lambda (_%clause4563%_ _%atom-plan4564%_ _%bound4565%_)
        (let ((_%plan4567%_
               (gerbil-ascent/program/objects#indexed-atom
                (_%atom-plan4564%_ _%clause4563%_)
                _%bound4565%_))
              (_%bound?4568%_
               (gerbil-ascent/program/objects#gerbil-ascent-bound-membership
                _%bound4565%_)))
          (for-each
           (lambda (_%term4570%_)
             (if (eq? (car _%term4570%_) 'pattern)
                 (let ()
                   (declare (not safe))
                   (error '"ASCENT pattern cannot bind in negation"))
                 '#!void)
             (if (and (eq? (car _%term4570%_) 'variable)
                      (not (let ((__tmp7706 (cdr _%term4570%_)))
                             (declare (not safe))
                             (_%bound?4568%_ __tmp7706))))
                 (let ((__tmp7707 (cdr _%term4570%_)))
                   (declare (not safe))
                   (error '"unsafe ASCENT negation variable" __tmp7707))
                 '#!void))
           (vector-ref _%plan4567%_ '1))
          (vector (vector 'negation _%plan4567%_) _%bound4565%_ '0))))
    (define gerbil-ascent/program/objects#computed-clause-plan
      (lambda (_%clause4490%_ _%kind4491%_ _%function-slot4492%_ _%bound4493%_)
        (let* ((_%inputs4495%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%clause4490%_ 'variables)))
               (_%name4497%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%clause4490%_ 'variable)))
               (_%names4499%_
                (if (and (eq? _%kind4491%_ 'generator) (list? _%name4497%_))
                    _%name4497%_
                    (list _%name4497%_))))
          (gerbil-ascent/program/objects#require-bound
           _%inputs4495%_
           (gerbil-ascent/program/objects#gerbil-ascent-bound-membership
            _%bound4493%_))
          (let ((_%known4502%_
                 (if (gerbil-ascent/program/objects#wide-scope? _%names4499%_)
                     (gerbil-ascent/program/objects#name-index _%bound4493%_)
                     '#f)))
            (let _%loop4504%_ ((_%remaining4506%_ _%names4499%_)
                               (_%next-bound4507%_ _%bound4493%_))
              (if (null? _%remaining4506%_)
                  (vector (vector _%kind4491%_
                                  (if (list? _%name4497%_)
                                      (let ((__tmp7708
                                             (lambda (_%output4509%_)
                                               (cons 'variable
                                                     _%output4509%_))))
                                        (declare (not safe))
                                        (##map __tmp7708 _%name4497%_))
                                      _%name4497%_)
                                  _%inputs4495%_
                                  (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref
                                     _%clause4490%_
                                     _%function-slot4492%_)))
                          _%next-bound4507%_
                          '0)
                  (begin
                    (if (if _%known4502%_
                            (let* ((_%h4511%_ _%known4502%_)
                                   (_%key4514%_ (car _%remaining4506%_))
                                   (_%h4518%_ _%h4511%_)
                                   (_%h4520%_ _%h4518%_))
                              (declare (not safe))
                              (__hash-get _%h4520%_ _%key4514%_))
                            (memq (car _%remaining4506%_) _%next-bound4507%_))
                        (let ((__tmp7709 (car _%remaining4506%_)))
                          (declare (not safe))
                          (error '"ASCENT computed variable already bound"
                                 __tmp7709))
                        '#!void)
                    (if _%known4502%_
                        (let* ((_%h4539%_ _%known4502%_)
                               (_%key4542%_ (car _%remaining4506%_))
                               (_%value4545%_ '#t)
                               (_%h4549%_ _%h4539%_)
                               (_%h4551%_ _%h4549%_))
                          (declare (not safe))
                          (__hash-put! _%h4551%_ _%key4542%_ _%value4545%_))
                        '#!void)
                    (_%loop4504%_
                     (cdr _%remaining4506%_)
                     (cons (car _%remaining4506%_) _%next-bound4507%_)))))))))
    (define gerbil-ascent/program/objects#aggregate-clause-plan
      (lambda (_%clause4384%_ _%atom-plan4385%_ _%bound4386%_)
        (let* ((_%plan4388%_
                (gerbil-ascent/program/objects#indexed-atom
                 (_%atom-plan4385%_ _%clause4384%_)
                 _%bound4386%_))
               (_%name4390%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%clause4384%_ 'variable)))
               (_%names4392%_
                (if (list? _%name4390%_) _%name4390%_ (list _%name4390%_)))
               (_%inputs4394%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%clause4384%_ 'variables)))
               (_%terms4396%_ (vector-ref _%plan4388%_ '1)))
          (if (let ()
                (declare (not safe))
                (ormap__0
                 gerbil-ascent/program/objects#pattern-outputs
                 _%terms4396%_))
              (let ()
                (declare (not safe))
                (error '"ASCENT pattern cannot bind in aggregate"))
              '#!void)
          (let ((_%known4399%_
                 (if (gerbil-ascent/program/objects#wide-scope? _%names4392%_)
                     (gerbil-ascent/program/objects#name-index _%bound4386%_)
                     '#f)))
            (let _%loop4401%_ ((_%remaining4403%_ _%names4392%_)
                               (_%next-bound4404%_ _%bound4386%_))
              (if (null? _%remaining4403%_)
                  '#!void
                  (begin
                    (if (if _%known4399%_
                            (let* ((_%h4406%_ _%known4399%_)
                                   (_%key4409%_ (car _%remaining4403%_))
                                   (_%h4413%_ _%h4406%_)
                                   (_%h4415%_ _%h4413%_))
                              (declare (not safe))
                              (__hash-get _%h4415%_ _%key4409%_))
                            (memq (car _%remaining4403%_) _%next-bound4404%_))
                        (let ((__tmp7710 (car _%remaining4403%_)))
                          (declare (not safe))
                          (error '"ASCENT aggregate variable already bound"
                                 __tmp7710))
                        '#!void)
                    (if _%known4399%_
                        (let* ((_%h4436%_ _%known4399%_)
                               (_%key4439%_ (car _%remaining4403%_))
                               (_%value4442%_ '#t)
                               (_%h4446%_ _%h4436%_)
                               (_%h4448%_ _%h4446%_))
                          (declare (not safe))
                          (__hash-put! _%h4448%_ _%key4439%_ _%value4442%_))
                        '#!void)
                    (_%loop4401%_
                     (cdr _%remaining4403%_)
                     (cons (car _%remaining4403%_) _%next-bound4404%_))))))
          (let ((_%variables4462%_
                 (if (gerbil-ascent/program/objects#wide-scope? _%inputs4394%_)
                     (gerbil-ascent/program/objects#name-index
                      (let ((__tmp7711
                             (lambda (_%term4460%_)
                               (if (eq? (car _%term4460%_) 'variable)
                                   (cdr _%term4460%_)
                                   '#f))))
                        (declare (not safe))
                        (filter-map__0 __tmp7711 _%terms4396%_)))
                     '#f)))
            (for-each
             (lambda (_%input4464%_)
               (if (if _%variables4462%_
                       (let* ((_%h4466%_ _%variables4462%_)
                              (_%key4469%_ _%input4464%_)
                              (_%h4473%_ _%h4466%_)
                              (_%h4475%_ _%h4473%_))
                         (declare (not safe))
                         (__hash-get _%h4475%_ _%key4469%_))
                       (let ((__tmp7712
                              (lambda (_%term4488%_)
                                (and (eq? (car _%term4488%_) 'variable)
                                     (eq? (cdr _%term4488%_) _%input4464%_)))))
                         (declare (not safe))
                         (ormap__0 __tmp7712 _%terms4396%_)))
                   '#!void
                   (let ()
                     (declare (not safe))
                     (error '"ASCENT aggregate input absent from atom"
                            _%input4464%_))))
             _%inputs4394%_))
          (vector (vector 'aggregate
                          _%plan4388%_
                          _%name4390%_
                          _%inputs4394%_
                          (let ()
                            (declare (not safe))
                            (clan/poo/object#.ref _%clause4384%_ 'aggregate))
                          (let ()
                            (declare (not safe))
                            (clan/poo/object#.ref
                             _%clause4384%_
                             'output-pattern)))
                  (append _%names4392%_ _%bound4386%_)
                  '0))))
    (define gerbil-ascent/program/objects#gerbil-ascent-relation__%
      (lambda (_%relation-name4256%_
               _%column-count4257%_
               _%source-rows4258%_
               _%provider-value4259%_
               _%storage-value4260%_
               _%field-predicates-value4261%_
               _%domain-descriptor4262%_)
        (if (and (symbol? _%relation-name4256%_)
                 (exact-integer? _%column-count4257%_)
                 (<= '0 _%column-count4257%_)
                 (list? _%source-rows4258%_)
                 (list? _%field-predicates-value4261%_)
                 (or (null? _%field-predicates-value4261%_)
                     (= (let ()
                          (declare (not safe))
                          (##length _%field-predicates-value4261%_))
                        _%column-count4257%_))
                 (let ()
                   (declare (not safe))
                   (andmap__0 procedure? _%field-predicates-value4261%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT relation declaration"
                     _%relation-name4256%_
                     _%column-count4257%_)))
        (for-each
         (lambda (_%row4267%_)
           (if (and (list? _%row4267%_)
                    (= (let () (declare (not safe)) (##length _%row4267%_))
                       _%column-count4257%_))
               '#!void
               (let ()
                 (declare (not safe))
                 (error '"invalid ASCENT relation row"
                        _%relation-name4256%_
                        _%row4267%_
                        _%column-count4257%_)))
           (if (pair? _%field-predicates-value4261%_)
               (let ((__tmp7713
                      (lambda (_%predicate4269%_ _%value4270%_)
                        (if (_%predicate4269%_ _%value4270%_)
                            '#!void
                            (let ()
                              (declare (not safe))
                              (error '"ASCENT relation source field type mismatch"
                                     _%relation-name4256%_
                                     _%row4267%_))))))
                 (declare (not safe))
                 (##for-each
                  __tmp7713
                  _%field-predicates-value4261%_
                  _%row4267%_))
               '#!void))
         _%source-rows4258%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentRelationContract
         (let ((__obj7681
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp7715
                  (list (cons 'name
                              (let ((__tmp7716
                                     (lambda (_%@4290%_)
                                       _%relation-name4256%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7716)))
                        (cons 'arity
                              (let ((__tmp7717
                                     (lambda (_%@4296%_)
                                       _%column-count4257%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7717)))
                        (cons 'rows
                              (let ((__tmp7718
                                     (lambda (_%@4301%_) _%source-rows4258%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7718)))
                        (cons 'field-predicates
                              (let ((__tmp7719
                                     (lambda (_%@4306%_)
                                       _%field-predicates-value4261%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7719)))
                        (cons 'checked-domain
                              (let ((__tmp7720
                                     (lambda (_%@4311%_)
                                       _%domain-descriptor4262%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7720)))
                        (cons 'storage-kind
                              (let ((__tmp7721 (lambda (_%@4316%_) 'relation)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7721)))
                        (cons 'index-provider
                              (let ((__tmp7722
                                     (lambda (_%@4321%_)
                                       _%provider-value4259%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7722)))
                        (cons 'storage-provider
                              (let ((__tmp7723
                                     (lambda (_%@4326%_)
                                       _%storage-value4260%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7723)))))
                 (__tmp7714 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Relation.
              __tmp7715
              __tmp7714
              __obj7681))
           __obj7681))))
    (define gerbil-ascent/program/objects#gerbil-ascent-relation__0
      (lambda (_%relation-name4334%_ _%column-count4335%_ _%source-rows4336%_)
        (let* ((_%provider-value4338%_
                gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider)
               (_%storage-value4340%_
                gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider)
               (_%field-predicates-value4342%_ '())
               (_%domain-descriptor4344%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-relation__%
           _%relation-name4334%_
           _%column-count4335%_
           _%source-rows4336%_
           _%provider-value4338%_
           _%storage-value4340%_
           _%field-predicates-value4342%_
           _%domain-descriptor4344%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-relation__1
      (lambda (_%relation-name4346%_
               _%column-count4347%_
               _%source-rows4348%_
               _%provider-value4349%_)
        (let* ((_%storage-value4351%_
                gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider)
               (_%field-predicates-value4353%_ '())
               (_%domain-descriptor4355%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-relation__%
           _%relation-name4346%_
           _%column-count4347%_
           _%source-rows4348%_
           _%provider-value4349%_
           _%storage-value4351%_
           _%field-predicates-value4353%_
           _%domain-descriptor4355%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-relation__2
      (lambda (_%relation-name4357%_
               _%column-count4358%_
               _%source-rows4359%_
               _%provider-value4360%_
               _%storage-value4361%_)
        (let* ((_%field-predicates-value4363%_ '())
               (_%domain-descriptor4365%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-relation__%
           _%relation-name4357%_
           _%column-count4358%_
           _%source-rows4359%_
           _%provider-value4360%_
           _%storage-value4361%_
           _%field-predicates-value4363%_
           _%domain-descriptor4365%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-relation__3
      (lambda (_%relation-name4367%_
               _%column-count4368%_
               _%source-rows4369%_
               _%provider-value4370%_
               _%storage-value4371%_
               _%field-predicates-value4372%_)
        (let ((_%domain-descriptor4374%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-relation__%
           _%relation-name4367%_
           _%column-count4368%_
           _%source-rows4369%_
           _%provider-value4370%_
           _%storage-value4371%_
           _%field-predicates-value4372%_
           _%domain-descriptor4374%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-relation
      (lambda _g7724_
        (let ((_g7725_ (let () (declare (not safe)) (##length _g7724_))))
          (cond ((let () (declare (not safe)) (##fx= _g7725_ 3))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-relation__0
                        _g7724_))
                ((let () (declare (not safe)) (##fx= _g7725_ 4))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-relation__1
                        _g7724_))
                ((let () (declare (not safe)) (##fx= _g7725_ 5))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-relation__2
                        _g7724_))
                ((let () (declare (not safe)) (##fx= _g7725_ 6))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-relation__3
                        _g7724_))
                ((let () (declare (not safe)) (##fx= _g7725_ 7))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-relation__%
                        _g7724_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-relation
                  _g7724_))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-lattice__%
      (lambda (_%relation-name4115%_
               _%column-count4116%_
               _%source-rows4117%_
               _%join-procedure4118%_
               _%provider-value4119%_
               _%field-predicates-value4120%_
               _%operator-descriptor4121%_
               _%domain-descriptor4122%_)
        (if (and (symbol? _%relation-name4115%_)
                 (exact-integer? _%column-count4116%_)
                 (> _%column-count4116%_ '0)
                 (list? _%source-rows4117%_)
                 (procedure? _%join-procedure4118%_)
                 (list? _%field-predicates-value4120%_)
                 (or (null? _%field-predicates-value4120%_)
                     (= (let ()
                          (declare (not safe))
                          (##length _%field-predicates-value4120%_))
                        _%column-count4116%_))
                 (let ()
                   (declare (not safe))
                   (andmap__0 procedure? _%field-predicates-value4120%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT lattice declaration"
                     _%relation-name4115%_
                     _%column-count4116%_)))
        (for-each
         (lambda (_%row4127%_)
           (if (and (list? _%row4127%_)
                    (= (let () (declare (not safe)) (##length _%row4127%_))
                       _%column-count4116%_))
               '#!void
               (let ()
                 (declare (not safe))
                 (error '"invalid ASCENT lattice row"
                        _%relation-name4115%_
                        _%row4127%_
                        _%column-count4116%_)))
           (if (pair? _%field-predicates-value4120%_)
               (let ((__tmp7726
                      (lambda (_%predicate4129%_ _%value4130%_)
                        (if (_%predicate4129%_ _%value4130%_)
                            '#!void
                            (let ()
                              (declare (not safe))
                              (error '"ASCENT lattice source field type mismatch"
                                     _%relation-name4115%_
                                     _%row4127%_))))))
                 (declare (not safe))
                 (##for-each
                  __tmp7726
                  _%field-predicates-value4120%_
                  _%row4127%_))
               '#!void))
         _%source-rows4117%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentLatticeContract
         (let ((__obj7682
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp7728
                  (list (cons 'name
                              (let ((__tmp7729
                                     (lambda (_%@4151%_)
                                       _%relation-name4115%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7729)))
                        (cons 'arity
                              (let ((__tmp7730
                                     (lambda (_%@4157%_)
                                       _%column-count4116%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7730)))
                        (cons 'rows
                              (let ((__tmp7731
                                     (lambda (_%@4162%_) _%source-rows4117%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7731)))
                        (cons 'field-predicates
                              (let ((__tmp7732
                                     (lambda (_%@4167%_)
                                       _%field-predicates-value4120%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7732)))
                        (cons 'checked-domain
                              (let ((__tmp7733
                                     (lambda (_%@4172%_)
                                       _%domain-descriptor4122%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7733)))
                        (cons 'storage-kind
                              (let ((__tmp7734 (lambda (_%@4177%_) 'lattice)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7734)))
                        (cons 'join
                              (let ((__tmp7735
                                     (lambda (_%@4182%_)
                                       _%join-procedure4118%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7735)))
                        (cons 'checked-operator
                              (let ((__tmp7736
                                     (lambda (_%@4187%_)
                                       _%operator-descriptor4121%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7736)))
                        (cons 'index-provider
                              (let ((__tmp7737
                                     (lambda (_%@4192%_)
                                       _%provider-value4119%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7737)))))
                 (__tmp7727 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Lattice.
              __tmp7728
              __tmp7727
              __obj7682))
           __obj7682))))
    (define gerbil-ascent/program/objects#gerbil-ascent-lattice__0
      (lambda (_%relation-name4200%_
               _%column-count4201%_
               _%source-rows4202%_
               _%join-procedure4203%_)
        (let* ((_%provider-value4205%_
                gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider)
               (_%field-predicates-value4207%_ '())
               (_%operator-descriptor4209%_ '#f)
               (_%domain-descriptor4211%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-lattice__%
           _%relation-name4200%_
           _%column-count4201%_
           _%source-rows4202%_
           _%join-procedure4203%_
           _%provider-value4205%_
           _%field-predicates-value4207%_
           _%operator-descriptor4209%_
           _%domain-descriptor4211%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-lattice__1
      (lambda (_%relation-name4213%_
               _%column-count4214%_
               _%source-rows4215%_
               _%join-procedure4216%_
               _%provider-value4217%_)
        (let* ((_%field-predicates-value4219%_ '())
               (_%operator-descriptor4221%_ '#f)
               (_%domain-descriptor4223%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-lattice__%
           _%relation-name4213%_
           _%column-count4214%_
           _%source-rows4215%_
           _%join-procedure4216%_
           _%provider-value4217%_
           _%field-predicates-value4219%_
           _%operator-descriptor4221%_
           _%domain-descriptor4223%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-lattice__2
      (lambda (_%relation-name4225%_
               _%column-count4226%_
               _%source-rows4227%_
               _%join-procedure4228%_
               _%provider-value4229%_
               _%field-predicates-value4230%_)
        (let* ((_%operator-descriptor4232%_ '#f)
               (_%domain-descriptor4234%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-lattice__%
           _%relation-name4225%_
           _%column-count4226%_
           _%source-rows4227%_
           _%join-procedure4228%_
           _%provider-value4229%_
           _%field-predicates-value4230%_
           _%operator-descriptor4232%_
           _%domain-descriptor4234%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-lattice__3
      (lambda (_%relation-name4236%_
               _%column-count4237%_
               _%source-rows4238%_
               _%join-procedure4239%_
               _%provider-value4240%_
               _%field-predicates-value4241%_
               _%operator-descriptor4242%_)
        (let ((_%domain-descriptor4244%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-lattice__%
           _%relation-name4236%_
           _%column-count4237%_
           _%source-rows4238%_
           _%join-procedure4239%_
           _%provider-value4240%_
           _%field-predicates-value4241%_
           _%operator-descriptor4242%_
           _%domain-descriptor4244%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-lattice
      (lambda _g7738_
        (let ((_g7739_ (let () (declare (not safe)) (##length _g7738_))))
          (cond ((let () (declare (not safe)) (##fx= _g7739_ 4))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-lattice__0
                        _g7738_))
                ((let () (declare (not safe)) (##fx= _g7739_ 5))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-lattice__1
                        _g7738_))
                ((let () (declare (not safe)) (##fx= _g7739_ 6))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-lattice__2
                        _g7738_))
                ((let () (declare (not safe)) (##fx= _g7739_ 7))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-lattice__3
                        _g7738_))
                ((let () (declare (not safe)) (##fx= _g7739_ 8))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-lattice__%
                        _g7738_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-lattice
                  _g7738_))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-variable
      (lambda (_%name4089%_)
        (if (symbol? _%name4089%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"ASCENT variable name must be a symbol" _%name4089%_)))
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentTermContract
         (let ((__obj7683
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp7741
                  (list (cons 'kind
                              (let ((__tmp7742 (lambda (_%@4103%_) 'variable)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7742)))
                        (cons 'value
                              (let ((__tmp7743
                                     (lambda (_%@4109%_) _%name4089%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7743)))))
                 (__tmp7740 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Term.
              __tmp7741
              __tmp7740
              __obj7683))
           __obj7683))))
    (define gerbil-ascent/program/objects#gerbil-ascent-wildcard
      (lambda ()
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentTermContract
         (let ((__obj7684
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp7745
                  (list (cons 'kind
                              (let ((__tmp7746 (lambda (_%@4078%_) 'wildcard)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7746)))
                        (cons 'value
                              (let ((__tmp7747 (lambda (_%@4084%_) '#f)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7747)))))
                 (__tmp7744 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Term.
              __tmp7745
              __tmp7744
              __obj7684))
           __obj7684))))
    (define gerbil-ascent/program/objects#gerbil-ascent-literal
      (lambda (_%literal-value4040%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentTermContract
         (let ((__obj7685
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp7749
                  (list (cons 'kind
                              (let ((__tmp7750 (lambda (_%@4054%_) 'literal)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7750)))
                        (cons 'value
                              (let ((__tmp7751
                                     (lambda (_%@4060%_)
                                       _%literal-value4040%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7751)))))
                 (__tmp7748 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Term.
              __tmp7749
              __tmp7748
              __obj7685))
           __obj7685))))
    (define gerbil-ascent/program/objects#gerbil-ascent-expression
      (lambda (_%input-variables4014%_ _%compute4015%_)
        (if (and (list? _%input-variables4014%_)
                 (let ()
                   (declare (not safe))
                   (andmap__0 symbol? _%input-variables4014%_))
                 (procedure? _%compute4015%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT head expression"
                     _%input-variables4014%_
                     _%compute4015%_)))
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentTermContract
         (let ((__obj7686
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp7753
                  (list (cons 'kind
                              (let ((__tmp7754
                                     (lambda (_%@4029%_) 'expression)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7754)))
                        (cons 'value
                              (let ((__tmp7755
                                     (lambda (_%@4035%_)
                                       (vector _%input-variables4014%_
                                               _%compute4015%_))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7755)))))
                 (__tmp7752 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Term.
              __tmp7753
              __tmp7752
              __obj7686))
           __obj7686))))
    (define gerbil-ascent/program/objects#gerbil-ascent-pattern
      (lambda (_%output-variables3988%_ _%matcher3989%_)
        (if (and (list? _%output-variables3988%_)
                 (let ()
                   (declare (not safe))
                   (andmap__0 symbol? _%output-variables3988%_))
                 (procedure? _%matcher3989%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT pattern"
                     _%output-variables3988%_
                     _%matcher3989%_)))
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentTermContract
         (let ((__obj7687
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp7757
                  (list (cons 'kind
                              (let ((__tmp7758 (lambda (_%@4003%_) 'pattern)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7758)))
                        (cons 'value
                              (let ((__tmp7759
                                     (lambda (_%@4009%_)
                                       (vector _%output-variables3988%_
                                               _%matcher3989%_))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7759)))))
                 (__tmp7756 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Term.
              __tmp7757
              __tmp7756
              __obj7687))
           __obj7687))))
    (define gerbil-ascent/program/objects#gerbil-ascent-atom
      (lambda (_%relation-name3947%_ _%atom-terms3948%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentAtomContract
         (let ((__obj7688
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp7761
                  (list (cons 'ascent-clause-kind
                              (let ((__tmp7762 (lambda (_%self3964%_) 'atom)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7762)))
                        (cons 'relation
                              (let ((__tmp7763
                                     (lambda (_%self3970%_)
                                       _%relation-name3947%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7763)))
                        (cons 'terms
                              (let ((__tmp7764
                                     (lambda (_%self3975%_)
                                       _%atom-terms3948%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7764)))
                        (cons '.plan
                              (let ((__tmp7765
                                     (lambda (_%self3980%_)
                                       (lambda (_%atom-plan3985%_
                                                _%bound3986%_)
                                         (gerbil-ascent/program/objects#atom-clause-plan
                                          _%self3980%_
                                          _%atom-plan3985%_
                                          _%bound3986%_)))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7765)))))
                 (__tmp7760 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Atom.
              __tmp7761
              __tmp7760
              __obj7688))
           __obj7688))))
    (define gerbil-ascent/program/objects#gerbil-ascent-guard__%
      (lambda (_%input-variables3887%_
               _%guard-procedure3888%_
               _%operator-descriptor3889%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentGuardContract
         (let ((__obj7689
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp7767
                  (list (cons 'ascent-clause-kind
                              (let ((__tmp7768 (lambda (_%self3906%_) 'guard)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7768)))
                        (cons 'variables
                              (let ((__tmp7769
                                     (lambda (_%self3912%_)
                                       _%input-variables3887%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7769)))
                        (cons 'predicate
                              (let ((__tmp7770
                                     (lambda (_%self3917%_)
                                       _%guard-procedure3888%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7770)))
                        (cons 'checked-operator
                              (let ((__tmp7771
                                     (lambda (_%self3922%_)
                                       _%operator-descriptor3889%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7771)))
                        (cons '.plan
                              (let ((__tmp7772
                                     (lambda (_%self3927%_)
                                       (lambda (_%_atom-plan3932%_
                                                _%bound3933%_)
                                         (gerbil-ascent/program/objects#require-bound
                                          (let ()
                                            (declare (not safe))
                                            (clan/poo/object#.ref
                                             _%self3927%_
                                             'variables))
                                          (gerbil-ascent/program/objects#gerbil-ascent-bound-membership
                                           _%bound3933%_))
                                         (vector (vector 'guard
                                                         (let ()
                                                           (declare (not safe))
                                                           (clan/poo/object#.ref
                                                            _%self3927%_
                                                            'variables))
                                                         (let ()
                                                           (declare (not safe))
                                                           (clan/poo/object#.ref
                                                            _%self3927%_
                                                            'predicate)))
                                                 _%bound3933%_
                                                 '0)))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7772)))))
                 (__tmp7766 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Guard.
              __tmp7767
              __tmp7766
              __obj7689))
           __obj7689))))
    (define gerbil-ascent/program/objects#gerbil-ascent-guard__0
      (lambda (_%input-variables3938%_ _%guard-procedure3939%_)
        (let ((_%operator-descriptor3941%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-guard__%
           _%input-variables3938%_
           _%guard-procedure3939%_
           _%operator-descriptor3941%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-guard
      (lambda _g7773_
        (let ((_g7774_ (let () (declare (not safe)) (##length _g7773_))))
          (cond ((let () (declare (not safe)) (##fx= _g7774_ 2))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-guard__0
                        _g7773_))
                ((let () (declare (not safe)) (##fx= _g7774_ 3))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-guard__%
                        _g7773_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-guard
                  _g7773_))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-generator
      (lambda (_%output-variable3838%_
               _%input-variables3839%_
               _%generator-procedure3840%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentGeneratorContract
         (let ((__obj7690
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp7776
                  (list (cons 'ascent-clause-kind
                              (let ((__tmp7777
                                     (lambda (_%self3857%_) 'generator)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7777)))
                        (cons 'variable
                              (let ((__tmp7778
                                     (lambda (_%self3863%_)
                                       _%output-variable3838%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7778)))
                        (cons 'variables
                              (let ((__tmp7779
                                     (lambda (_%self3868%_)
                                       _%input-variables3839%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7779)))
                        (cons 'generate
                              (let ((__tmp7780
                                     (lambda (_%self3873%_)
                                       _%generator-procedure3840%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7780)))
                        (cons '.plan
                              (let ((__tmp7781
                                     (lambda (_%self3878%_)
                                       (lambda (_%_atom-plan3883%_
                                                _%bound3884%_)
                                         (gerbil-ascent/program/objects#computed-clause-plan
                                          _%self3878%_
                                          'generator
                                          'generate
                                          _%bound3884%_)))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7781)))))
                 (__tmp7775 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Generator.
              __tmp7776
              __tmp7775
              __obj7690))
           __obj7690))))
    (define gerbil-ascent/program/objects#gerbil-ascent-binding__%
      (lambda (_%output-variable3769%_
               _%input-variables3770%_
               _%binding-procedure3771%_
               _%operator-descriptor3772%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentBindingContract
         (let ((__obj7691
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp7783
                  (list (cons 'ascent-clause-kind
                              (let ((__tmp7784
                                     (lambda (_%self3790%_) 'binding)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7784)))
                        (cons 'variable
                              (let ((__tmp7785
                                     (lambda (_%self3796%_)
                                       _%output-variable3769%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7785)))
                        (cons 'variables
                              (let ((__tmp7786
                                     (lambda (_%self3801%_)
                                       _%input-variables3770%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7786)))
                        (cons 'compute
                              (let ((__tmp7787
                                     (lambda (_%self3806%_)
                                       _%binding-procedure3771%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7787)))
                        (cons 'checked-operator
                              (let ((__tmp7788
                                     (lambda (_%self3811%_)
                                       _%operator-descriptor3772%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7788)))
                        (cons '.plan
                              (let ((__tmp7789
                                     (lambda (_%self3816%_)
                                       (lambda (_%_atom-plan3821%_
                                                _%bound3822%_)
                                         (gerbil-ascent/program/objects#computed-clause-plan
                                          _%self3816%_
                                          'binding
                                          'compute
                                          _%bound3822%_)))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7789)))))
                 (__tmp7782 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Binding.
              __tmp7783
              __tmp7782
              __obj7691))
           __obj7691))))
    (define gerbil-ascent/program/objects#gerbil-ascent-binding__0
      (lambda (_%output-variable3827%_
               _%input-variables3828%_
               _%binding-procedure3829%_)
        (let ((_%operator-descriptor3831%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-binding__%
           _%output-variable3827%_
           _%input-variables3828%_
           _%binding-procedure3829%_
           _%operator-descriptor3831%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-binding
      (lambda _g7790_
        (let ((_g7791_ (let () (declare (not safe)) (##length _g7790_))))
          (cond ((let () (declare (not safe)) (##fx= _g7791_ 3))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-binding__0
                        _g7790_))
                ((let () (declare (not safe)) (##fx= _g7791_ 4))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-binding__%
                        _g7790_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-binding
                  _g7790_))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-negation
      (lambda (_%relation-name3727%_ _%atom-terms3728%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentNegationContract
         (let ((__obj7692
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp7793
                  (list (cons 'ascent-clause-kind
                              (let ((__tmp7794
                                     (lambda (_%self3744%_) 'negation)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7794)))
                        (cons 'relation
                              (let ((__tmp7795
                                     (lambda (_%self3750%_)
                                       _%relation-name3727%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7795)))
                        (cons 'terms
                              (let ((__tmp7796
                                     (lambda (_%self3755%_)
                                       _%atom-terms3728%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7796)))
                        (cons '.plan
                              (let ((__tmp7797
                                     (lambda (_%self3760%_)
                                       (lambda (_%atom-plan3765%_
                                                _%bound3766%_)
                                         (gerbil-ascent/program/objects#negation-clause-plan
                                          _%self3760%_
                                          _%atom-plan3765%_
                                          _%bound3766%_)))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7797)))))
                 (__tmp7792 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Negation.
              __tmp7793
              __tmp7792
              __obj7692))
           __obj7692))))
    (define gerbil-ascent/program/objects#gerbil-ascent-aggregate__%
      (lambda (_%output-variable3618%_
               _%relation-name3619%_
               _%atom-terms3620%_
               _%value-variables3621%_
               _%aggregate-procedure3622%_
               _%matcher3623%_
               _%operator-descriptor3624%_)
        (if (or (and (symbol? _%output-variable3618%_) (not _%matcher3623%_))
                (and (pair? _%output-variable3618%_)
                     (let ()
                       (declare (not safe))
                       (andmap__0 symbol? _%output-variable3618%_))
                     (procedure? _%matcher3623%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT aggregate output"
                     _%output-variable3618%_
                     _%matcher3623%_)))
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentAggregateContract
         (let ((__obj7693
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp7799
                  (list (cons 'ascent-clause-kind
                              (let ((__tmp7800
                                     (lambda (_%self3648%_) 'aggregate)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7800)))
                        (cons 'variable
                              (let ((__tmp7801
                                     (lambda (_%self3654%_)
                                       _%output-variable3618%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7801)))
                        (cons 'relation
                              (let ((__tmp7802
                                     (lambda (_%self3659%_)
                                       _%relation-name3619%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7802)))
                        (cons 'terms
                              (let ((__tmp7803
                                     (lambda (_%self3664%_)
                                       _%atom-terms3620%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7803)))
                        (cons 'variables
                              (let ((__tmp7804
                                     (lambda (_%self3669%_)
                                       _%value-variables3621%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7804)))
                        (cons 'aggregate
                              (let ((__tmp7805
                                     (lambda (_%self3674%_)
                                       _%aggregate-procedure3622%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7805)))
                        (cons 'output-pattern
                              (let ((__tmp7806
                                     (lambda (_%self3679%_) _%matcher3623%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7806)))
                        (cons 'checked-operator
                              (let ((__tmp7807
                                     (lambda (_%self3684%_)
                                       _%operator-descriptor3624%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7807)))
                        (cons '.plan
                              (let ((__tmp7808
                                     (lambda (_%self3689%_)
                                       (lambda (_%atom-plan3694%_
                                                _%bound3695%_)
                                         (gerbil-ascent/program/objects#aggregate-clause-plan
                                          _%self3689%_
                                          _%atom-plan3694%_
                                          _%bound3695%_)))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7808)))))
                 (__tmp7798 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Aggregate.
              __tmp7799
              __tmp7798
              __obj7693))
           __obj7693))))
    (define gerbil-ascent/program/objects#gerbil-ascent-aggregate__0
      (lambda (_%output-variable3700%_
               _%relation-name3701%_
               _%atom-terms3702%_
               _%value-variables3703%_
               _%aggregate-procedure3704%_)
        (let* ((_%matcher3706%_ '#f) (_%operator-descriptor3708%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-aggregate__%
           _%output-variable3700%_
           _%relation-name3701%_
           _%atom-terms3702%_
           _%value-variables3703%_
           _%aggregate-procedure3704%_
           _%matcher3706%_
           _%operator-descriptor3708%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-aggregate__1
      (lambda (_%output-variable3710%_
               _%relation-name3711%_
               _%atom-terms3712%_
               _%value-variables3713%_
               _%aggregate-procedure3714%_
               _%matcher3715%_)
        (let ((_%operator-descriptor3717%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-aggregate__%
           _%output-variable3710%_
           _%relation-name3711%_
           _%atom-terms3712%_
           _%value-variables3713%_
           _%aggregate-procedure3714%_
           _%matcher3715%_
           _%operator-descriptor3717%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-aggregate
      (lambda _g7809_
        (let ((_g7810_ (let () (declare (not safe)) (##length _g7809_))))
          (cond ((let () (declare (not safe)) (##fx= _g7810_ 5))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-aggregate__0
                        _g7809_))
                ((let () (declare (not safe)) (##fx= _g7810_ 6))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-aggregate__1
                        _g7809_))
                ((let () (declare (not safe)) (##fx= _g7810_ 7))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-aggregate__%
                        _g7809_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-aggregate
                  _g7809_))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-rule
      (lambda (_%head-atoms3591%_ _%body-atoms3592%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentRuleContract
         (let ((__obj7694
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp7812
                  (list (cons 'heads
                              (let ((__tmp7813
                                     (lambda (_%@3606%_) _%head-atoms3591%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7813)))
                        (cons 'body
                              (let ((__tmp7814
                                     (lambda (_%@3612%_) _%body-atoms3592%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7814)))))
                 (__tmp7811 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Rule.
              __tmp7812
              __tmp7811
              __obj7694))
           __obj7694))))
    (define gerbil-ascent/program/objects#fragment-export-resolver
      (lambda (_%export-values3512%_)
        (if (list? _%export-values3512%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT fragment exports"
                     _%export-values3512%_)))
        (let ((_%entries3514%_
               (let () (declare (not safe)) (make-hash-table-eq))))
          (for-each
           (lambda (_%entry3516%_)
             (if (and (pair? _%entry3516%_)
                      (symbol? (let ()
                                 (declare (not safe))
                                 (##car _%entry3516%_)))
                      (symbol? (let ()
                                 (declare (not safe))
                                 (##cdr _%entry3516%_)))
                      (not (let* ((_%h3518%_ _%entries3514%_)
                                  (_%key3521%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%entry3516%_)))
                                  (_%h3525%_ _%h3518%_)
                                  (_%h3527%_ _%h3525%_))
                             (declare (not safe))
                             (__hash-get _%h3527%_ _%key3521%_))))
                 '#!void
                 (let ()
                   (declare (not safe))
                   (error '"invalid or duplicate ASCENT fragment export"
                          _%entry3516%_)))
             (let* ((_%h3541%_ _%entries3514%_)
                    (_%key3544%_ (car _%entry3516%_))
                    (_%value3547%_ (cdr _%entry3516%_))
                    (_%h3551%_ _%h3541%_)
                    (_%h3553%_ _%h3551%_))
               (declare (not safe))
               (__hash-put! _%h3553%_ _%key3544%_ _%value3547%_)))
           _%export-values3512%_)
          (lambda (_%label3565%_)
            (let ((_%$e3588%_
                   (let* ((_%h3567%_ _%entries3514%_)
                          (_%key3570%_ _%label3565%_)
                          (_%h3574%_ _%h3567%_)
                          (_%h3576%_ _%h3574%_))
                     (declare (not safe))
                     (__hash-get _%h3576%_ _%key3570%_))))
              (if _%$e3588%_
                  _%$e3588%_
                  (let ()
                    (declare (not safe))
                    (error '"unknown relational fragment export"
                           _%label3565%_))))))))
    (define gerbil-ascent/program/objects#declared-name-membership
      (lambda (_%relations3443%_)
        (let ((_%remaining3445%_ _%relations3443%_)
              (_%names3446%_
               (let () (declare (not safe)) (make-hash-table-eq))))
          (lambda (_%name3448%_)
            (let ((_%$e3473%_
                   (let* ((_%h3450%_ _%names3446%_)
                          (_%key3453%_ _%name3448%_)
                          (_%h3457%_ _%h3450%_)
                          (_%h3459%_ _%h3457%_))
                     (declare (not safe))
                     (__hash-get _%h3459%_ _%key3453%_))))
              (if _%$e3473%_
                  _%$e3473%_
                  (let _%scan3476%_ ()
                    (if (null? _%remaining3445%_)
                        '#f
                        (let ((_%found3479%_
                               (let ((__tmp7815 (car _%remaining3445%_)))
                                 (declare (not safe))
                                 (clan/poo/object#.ref __tmp7815 'name))))
                          (set! _%remaining3445%_ (cdr _%remaining3445%_))
                          (let* ((_%h3481%_ _%names3446%_)
                                 (_%key3484%_ _%found3479%_)
                                 (_%value3487%_ '#t)
                                 (_%h3491%_ _%h3481%_)
                                 (_%h3493%_ _%h3491%_))
                            (declare (not safe))
                            (__hash-put! _%h3493%_ _%key3484%_ _%value3487%_))
                          (let ((_%$e3509%_ (eq? _%found3479%_ _%name3448%_)))
                            (if _%$e3509%_ _%$e3509%_ (_%scan3476%_))))))))))))
    (define gerbil-ascent/program/objects#checked-source-handles
      (lambda (_%relations3381%_ _%source-handle-values3382%_)
        (if (list? _%source-handle-values3382%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT source handles"
                     _%source-handle-values3382%_)))
        (letrec* ((_%seen3384%_
                   (let () (declare (not safe)) (make-hash-table-eq)))
                  (_%declared?3385%_
                   (gerbil-ascent/program/objects#declared-name-membership
                    _%relations3381%_)))
          (let _%loop3387%_ ((_%remaining3389%_ _%source-handle-values3382%_)
                             (_%copied3390%_ '()))
            (if (null? _%remaining3389%_)
                (reverse _%copied3390%_)
                (let ((_%name3392%_ (car _%remaining3389%_)))
                  (if (and (symbol? _%name3392%_)
                           (if (let* ((_%h3394%_ _%seen3384%_)
                                      (_%key3397%_ _%name3392%_)
                                      (_%h3401%_ _%h3394%_)
                                      (_%h3403%_ _%h3401%_))
                                 (declare (not safe))
                                 (__hash-get _%h3403%_ _%key3397%_))
                               '#f
                               (let ()
                                 (declare (not safe))
                                 (_%declared?3385%_ _%name3392%_))))
                      '#!void
                      (let ()
                        (declare (not safe))
                        (error '"invalid or duplicate ASCENT source handle"
                               _%name3392%_)))
                  (let* ((_%h3419%_ _%seen3384%_)
                         (_%key3422%_ _%name3392%_)
                         (_%value3425%_ '#t)
                         (_%h3429%_ _%h3419%_)
                         (_%h3431%_ _%h3429%_))
                    (declare (not safe))
                    (__hash-put! _%h3431%_ _%key3422%_ _%value3425%_))
                  (_%loop3387%_
                   (cdr _%remaining3389%_)
                   (cons _%name3392%_ _%copied3390%_))))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-fragment__%
      (lambda (_%relation-values3320%_
               _%rule-values3321%_
               _%export-values3322%_
               _%source-handle-values3323%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentFragmentContract
         (let ((__obj7695
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp7817
                  (list (cons 'relations
                              (let ((__tmp7818
                                     (lambda (_%@3339%_)
                                       _%relation-values3320%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7818)))
                        (cons 'rules
                              (let ((__tmp7819
                                     (lambda (_%@3345%_) _%rule-values3321%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7819)))
                        (cons 'exports
                              (let ((__tmp7820
                                     (lambda (_%@3350%_)
                                       (gerbil-ascent/program/objects#fragment-export-resolver
                                        _%export-values3322%_))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7820)))
                        (cons 'source-handles
                              (let ((__tmp7821
                                     (lambda (_%@3355%_)
                                       (gerbil-ascent/program/objects#checked-source-handles
                                        _%relation-values3320%_
                                        _%source-handle-values3323%_))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7821)))))
                 (__tmp7816 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Fragment.
              __tmp7817
              __tmp7816
              __obj7695))
           __obj7695))))
    (define gerbil-ascent/program/objects#gerbil-ascent-fragment__0
      (lambda (_%relation-values3363%_ _%rule-values3364%_)
        (let* ((_%export-values3366%_ '()) (_%source-handle-values3368%_ '()))
          (gerbil-ascent/program/objects#gerbil-ascent-fragment__%
           _%relation-values3363%_
           _%rule-values3364%_
           _%export-values3366%_
           _%source-handle-values3368%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-fragment__1
      (lambda (_%relation-values3370%_
               _%rule-values3371%_
               _%export-values3372%_)
        (let ((_%source-handle-values3374%_ '()))
          (gerbil-ascent/program/objects#gerbil-ascent-fragment__%
           _%relation-values3370%_
           _%rule-values3371%_
           _%export-values3372%_
           _%source-handle-values3374%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-fragment
      (lambda _g7822_
        (let ((_g7823_ (let () (declare (not safe)) (##length _g7822_))))
          (cond ((let () (declare (not safe)) (##fx= _g7823_ 2))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-fragment__0
                        _g7822_))
                ((let () (declare (not safe)) (##fx= _g7823_ 3))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-fragment__1
                        _g7822_))
                ((let () (declare (not safe)) (##fx= _g7823_ 4))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-fragment__%
                        _g7822_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-fragment
                  _g7822_))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-program__%
      (lambda (_%declared-relations3246%_
               _%declared-rules3247%_
               _%input-fact-limit3248%_
               _%derived-fact-limit3249%_
               _%output-fact-limit3250%_
               _%source-handle-values3251%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentProgramContract
         (let ((__obj7696
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp7825
                  (list (cons 'relations
                              (let ((__tmp7826
                                     (lambda (_%@3270%_)
                                       _%declared-relations3246%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7826)))
                        (cons 'rules
                              (let ((__tmp7827
                                     (lambda (_%@3276%_)
                                       _%declared-rules3247%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7827)))
                        (cons 'source-handles
                              (let ((__tmp7828
                                     (lambda (_%@3281%_)
                                       (gerbil-ascent/program/objects#checked-source-handles
                                        _%declared-relations3246%_
                                        _%source-handle-values3251%_))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7828)))
                        (cons 'max-input-facts
                              (let ((__tmp7829
                                     (lambda (_%@3286%_)
                                       _%input-fact-limit3248%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7829)))
                        (cons 'max-derived-facts
                              (let ((__tmp7830
                                     (lambda (_%@3291%_)
                                       _%derived-fact-limit3249%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7830)))
                        (cons 'max-output-facts
                              (let ((__tmp7831
                                     (lambda (_%@3296%_)
                                       _%output-fact-limit3250%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp7831)))))
                 (__tmp7824 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Program.
              __tmp7825
              __tmp7824
              __obj7696))
           __obj7696))))
    (define gerbil-ascent/program/objects#gerbil-ascent-program__0
      (lambda (_%declared-relations3304%_
               _%declared-rules3305%_
               _%input-fact-limit3306%_
               _%derived-fact-limit3307%_
               _%output-fact-limit3308%_)
        (let ((_%source-handle-values3310%_ '()))
          (gerbil-ascent/program/objects#gerbil-ascent-program__%
           _%declared-relations3304%_
           _%declared-rules3305%_
           _%input-fact-limit3306%_
           _%derived-fact-limit3307%_
           _%output-fact-limit3308%_
           _%source-handle-values3310%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-program
      (lambda _g7832_
        (let ((_g7833_ (let () (declare (not safe)) (##length _g7832_))))
          (cond ((let () (declare (not safe)) (##fx= _g7833_ 5))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-program__0
                        _g7832_))
                ((let () (declare (not safe)) (##fx= _g7833_ 6))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-program__%
                        _g7832_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-program
                  _g7832_))))))))
