(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/reasoning::timestamp 1791687902)
  (begin
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt::t
      (let ((__tmp39178 (list)) (__tmp39177 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'reasoning-receipt
         __tmp39178
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  query
                  rows
                  diagnostics
                  evidence
                  proof
                  nonmembership
                  stratified)
         __tmp39177
         '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t)))
    (define gerbil-ascent/candidate/reasoning#make-reasoning-receipt
      (lambda _%$args30207%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#reasoning-receipt::t
               _%$args30207%_)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-query
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'query)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-diagnostics
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'diagnostics)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-evidence
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-proof
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-nonmembership
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'nonmembership)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-stratified
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'stratified)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'query)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-diagnostics-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'diagnostics)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-evidence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-proof-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-nonmembership-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'nonmembership)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-stratified-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'stratified)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-query
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'query)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-diagnostics
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'diagnostics)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-evidence
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-proof
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-nonmembership
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'nonmembership)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-stratified
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'stratified)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'query)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-diagnostics-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'diagnostics)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-evidence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-proof-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-nonmembership-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'nonmembership)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-receipt-stratified-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
         'stratified)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence::t
      (let ((__tmp39180 (list)) (__tmp39179 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reasoning-evidence
         __tmp39180
         '(kind support reachable)
         __tmp39179
         '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t)))
    (define gerbil-ascent/candidate/reasoning#make-reasoning-evidence
      (lambda _%$args30204%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#reasoning-evidence::t
               _%$args30204%_)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'kind)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-support
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'support)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-reachable
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reachable)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'kind)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-support-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'support)))
    (define gerbil-ascent/candidate/reasoning#reasoning-evidence-reachable-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reachable)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'kind)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-support
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'support)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-reachable
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reachable)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'kind)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-support-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'support)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-evidence-reachable-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
         'reachable)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
      (let ((__tmp39182 (list)) (__tmp39181 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'reasoning-stratified-evidence
         __tmp39182
         '(status finite proof work-budget)
         __tmp39181
         '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t)))
    (define gerbil-ascent/candidate/reasoning#make-reasoning-stratified-evidence
      (lambda _%$args30201%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
               _%$args30201%_)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-finite
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'finite)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-proof
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-finite-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'finite)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-proof-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-finite
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'finite)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-proof
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'status)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-finite-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'finite)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-proof-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'proof)))
    (define gerbil-ascent/candidate/reasoning#&reasoning-stratified-evidence-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/reasoning#copy-row
      (lambda (_%row30198%_ _%arity30199%_)
        (if (list? _%row30198%_)
            (if (= (let () (declare (not safe)) (##length _%row30198%_))
                   _%arity30199%_)
                (if (let ()
                      (declare (not safe))
                      (andmap__0
                       gerbil-ascent/candidate/program#scalar?
                       _%row30198%_))
                    (let () (declare (not safe)) (##map identity _%row30198%_))
                    '#f)
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/reasoning#digest-datum
      (lambda (_%datum30129%_)
        (let* ((_%bytes30149%_
                (let* ((_%bytes30133%_
                        (let ((__tmp39183
                               (call-with-output-string
                                '""
                                (lambda (_%port30131%_)
                                  (write _%datum30129%_ _%port30131%_)))))
                          (declare (not safe))
                          (##string->utf8 __tmp39183)))
                       (_%bytes30138%_ _%bytes30133%_))
                  (declare (not safe))
                  (std/crypto/digest#__sha256 _%bytes30138%_)))
               (_%start30152%_ '0)
               (_%end30155%_
                (let ()
                  (declare (not safe))
                  (##u8vector-length _%bytes30149%_)))
               (_%bytes30160%_ _%bytes30149%_))
          (if (and (let () (declare (not safe)) (##fx>= _%start30152%_ '0))
                   (let ((__tmp39184
                          (let ((__tmp39185
                                 (let ()
                                   (declare (not safe))
                                   (##u8vector-length _%bytes30160%_))))
                            (declare (not safe))
                            (##fxmax __tmp39185 '1))))
                     (declare (not safe))
                     (##fx< _%start30152%_ __tmp39184)))
              (let ((_%start30175%_ _%start30152%_))
                (if (let ((__tmp39186
                           (let ()
                             (declare (not safe))
                             (##u8vector-length _%bytes30160%_))))
                      (declare (not safe))
                      (##fx<= _%start30175%_ _%end30155%_ __tmp39186))
                    (let ((_%end30188%_ _%end30155%_))
                      (declare (not safe))
                      (std/encoding/hex#__hex-encode__%
                       _%bytes30160%_
                       _%start30175%_
                       _%end30188%_))
                    (begin
                      (raise-contract-violation-error
                       '"contract violation"
                       'context:
                       'gerbil-ascent/candidate/reasoning
                       'contract:
                       '(in-range-inclusive? start (u8vector-length bytes))
                       'value:
                       _%end30155%_)
                      '#!void)))
              (begin
                (raise-contract-violation-error
                 '"contract violation"
                 'context:
                 'gerbil-ascent/candidate/reasoning
                 'contract:
                 '(in-range? 0 (fxmax (u8vector-length bytes) 1))
                 'value:
                 _%start30152%_)
                '#!void)))))
    (define gerbil-ascent/candidate/reasoning#candidate-content-digest
      (lambda (_%candidate30127%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/datum#reasoning-bounded-data?
               _%candidate30127%_
               '16384
               '128))
            (gerbil-ascent/candidate/reasoning#digest-datum
             (list 'reasoning-candidate-v1 _%candidate30127%_))
            '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
      (lambda (_%receipt30121%_ _%snapshot30122%_ _%candidate30123%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%receipt30121%_
               'gerbil-ascent/candidate/reasoning#reasoning-receipt::t))
            (if (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                   _%snapshot30122%_))
                (if (equal? (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%receipt30121%_
                               '2
                               '#f
                               '#f))
                            (##structure-ref
                             _%snapshot30122%_
                             '1
                             gerbil-ascent/candidate/types#reasoning-snapshot::t
                             '#f))
                    (if (equal? (let ()
                                  (declare (not safe))
                                  (##unchecked-structure-ref
                                   _%receipt30121%_
                                   '3
                                   '#f
                                   '#f))
                                (##structure-ref
                                 _%snapshot30122%_
                                 '2
                                 gerbil-ascent/candidate/types#reasoning-snapshot::t
                                 '#f))
                        (if (equal? (let ()
                                      (declare (not safe))
                                      (##unchecked-structure-ref
                                       _%receipt30121%_
                                       '4
                                       '#f
                                       '#f))
                                    (##structure-ref
                                     _%snapshot30122%_
                                     '3
                                     gerbil-ascent/candidate/types#reasoning-snapshot::t
                                     '#f))
                            (let ((_%digest30125%_
                                   (gerbil-ascent/candidate/reasoning#candidate-content-digest
                                    _%candidate30123%_)))
                              (if _%digest30125%_
                                  (equal? _%digest30125%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%receipt30121%_
                                             '5
                                             '#f
                                             '#f)))
                                  '#f))
                            '#f)
                        '#f)
                    '#f)
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/reasoning#reasoning-source-snapshot
      (lambda (_%identity30087%_ _%generation30088%_ _%declarations30089%_)
        (if (and (or (symbol? _%identity30087%_) (string? _%identity30087%_))
                 (exact-integer? _%generation30088%_)
                 (<= '0 _%generation30088%_)
                 (let ()
                   (declare (not safe))
                   (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                    _%declarations30089%_
                    '131072
                    '128))
                 (list? _%declarations30089%_)
                 (<= (let ()
                       (declare (not safe))
                       (##length _%declarations30089%_))
                     gerbil-ascent/candidate/types#+max-relations+))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid reasoning source snapshot")))
        (let _%loop30094%_ ((_%remaining30096%_ _%declarations30089%_)
                            (_%seen30097%_ '())
                            (_%copied30098%_ '())
                            (_%facts30099%_ '0))
          (if (null? _%remaining30096%_)
              (let* ((_%relations30101%_ (reverse _%copied30098%_))
                     (__tmp39187
                      (let ()
                        (declare (not safe))
                        (gerbil-ascent/candidate/types#reasoning-snapshot-content-digest
                         _%identity30087%_
                         _%generation30088%_
                         _%relations30101%_))))
                (declare (not safe))
                (##structure
                 gerbil-ascent/candidate/types#reasoning-snapshot::t
                 _%identity30087%_
                 _%generation30088%_
                 __tmp39187
                 _%relations30101%_))
              (let ((_%entry30103%_ (car _%remaining30096%_)))
                (if (and (list? _%entry30103%_)
                         (= (let ()
                              (declare (not safe))
                              (##length _%entry30103%_))
                            '3)
                         (symbol? (car _%entry30103%_))
                         (exact-integer? (cadr _%entry30103%_))
                         (<= '0 (cadr _%entry30103%_))
                         (list? (caddr _%entry30103%_))
                         (not (memq (car _%entry30103%_) _%seen30097%_)))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"invalid or duplicate reasoning source declaration"
                             _%entry30103%_)))
                (let* ((_%name30105%_ (car _%entry30103%_))
                       (_%arity30107%_ (cadr _%entry30103%_))
                       (_%rows30109%_ (caddr _%entry30103%_))
                       (_%next-facts30111%_
                        (+ _%facts30099%_ (length _%rows30109%_))))
                  (if (> _%next-facts30111%_
                         gerbil-ascent/candidate/types#+max-input-facts+)
                      (let ()
                        (declare (not safe))
                        (error '"reasoning source snapshot exceeds input cap"))
                      '#!void)
                  (let ((_%owned30119%_
                         (map (lambda (_%row30114%_)
                                (let ((_%$e30116%_
                                       (gerbil-ascent/candidate/reasoning#copy-row
                                        _%row30114%_
                                        _%arity30107%_)))
                                  (if _%$e30116%_
                                      _%$e30116%_
                                      (let ()
                                        (declare (not safe))
                                        (error '"invalid reasoning source row"
                                               _%name30105%_
                                               _%row30114%_)))))
                              _%rows30109%_)))
                    (_%loop30094%_
                     (cdr _%remaining30096%_)
                     (cons _%name30105%_ _%seen30097%_)
                     (cons (list _%name30105%_ _%arity30107%_ _%owned30119%_)
                           _%copied30098%_)
                     _%next-facts30111%_))))))))
    (define gerbil-ascent/candidate/reasoning#query-row-matches?
      (lambda (_%terms30070%_ _%row30071%_)
        (let _%loop30073%_ ((_%terms30075%_ _%terms30070%_)
                            (_%values30076%_ _%row30071%_)
                            (_%bindings30077%_ '()))
          (if (null? _%terms30075%_)
              '#t
              (let ((_%term30079%_ (car _%terms30075%_))
                    (_%value30080%_ (car _%values30076%_)))
                (if (eq? _%term30079%_ '?_)
                    (_%loop30073%_
                     (cdr _%terms30075%_)
                     (cdr _%values30076%_)
                     _%bindings30077%_)
                    (if (let ()
                          (declare (not safe))
                          (gerbil-ascent/candidate/program#candidate-variable?
                           _%term30079%_))
                        (let ((_%binding30084%_
                               (assq _%term30079%_ _%bindings30077%_)))
                          (if _%binding30084%_
                              (if (equal? (cdr _%binding30084%_)
                                          _%value30080%_)
                                  (_%loop30073%_
                                   (cdr _%terms30075%_)
                                   (cdr _%values30076%_)
                                   _%bindings30077%_)
                                  '#f)
                              (_%loop30073%_
                               (cdr _%terms30075%_)
                               (cdr _%values30076%_)
                               (cons (cons _%term30079%_ _%value30080%_)
                                     _%bindings30077%_))))
                        (if (equal? _%term30079%_ _%value30080%_)
                            (_%loop30073%_
                             (cdr _%terms30075%_)
                             (cdr _%values30076%_)
                             _%bindings30077%_)
                            '#f))))))))
    (define gerbil-ascent/candidate/reasoning#candidate-graph-case?
      (lambda (_%snapshot30058%_ _%spec30059%_ _%query30060%_)
        (let ((_%source30062%_
               (##structure-ref
                _%snapshot30058%_
                '4
                gerbil-ascent/candidate/types#reasoning-snapshot::t
                '#f))
              (_%derived30063%_
               (##structure-ref
                _%spec30059%_
                '1
                gerbil-ascent/candidate/types#reasoning-candidate::t
                '#f))
              (_%rules30064%_
               (##structure-ref
                _%spec30059%_
                '3
                gerbil-ascent/candidate/types#reasoning-candidate::t
                '#f)))
          (if (= (length _%source30062%_) '1)
              (if (eq? (caar _%source30062%_) 'edge)
                  (if (= (cadar _%source30062%_) '2)
                      (if (equal? _%derived30063%_ '((path . 2)))
                          (if (= (length _%rules30064%_) '2)
                              (if (let ((_%forms30068%_
                                         (map (lambda (_%rule30066%_)
                                                (cons (vector-ref
                                                       _%rule30066%_
                                                       '0)
                                                      (vector-ref
                                                       _%rule30066%_
                                                       '1)))
                                              _%rules30064%_)))
                                    (and (let ()
                                           (declare (not safe))
                                           (##member
                                            '((path ?x ?y) (edge ?x ?y))
                                            _%forms30068%_))
                                         (let ()
                                           (declare (not safe))
                                           (##member
                                            '((path ?x ?z)
                                              (path ?x ?y)
                                              (edge ?y ?z))
                                            _%forms30068%_))))
                                  (if (= (length _%query30060%_) '3)
                                      (if (eq? (car _%query30060%_) 'path)
                                          (if (exact-integer?
                                               (cadr _%query30060%_))
                                              (exact-integer?
                                               (caddr _%query30060%_))
                                              '#f)
                                          '#f)
                                      '#f)
                                  '#f)
                              '#f)
                          '#f)
                      '#f)
                  '#f)
              '#f))))
    (define gerbil-ascent/candidate/reasoning#candidate-edge-records
      (lambda (_%snapshot30050%_ _%spec30051%_)
        (let ((__tmp39189
               (map (lambda (_%row30053%_ _%index30054%_)
                      (list 'source _%index30054%_ _%row30053%_))
                    (caddar (##structure-ref
                             _%snapshot30050%_
                             '4
                             gerbil-ascent/candidate/types#reasoning-snapshot::t
                             '#f))
                    (let ((__tmp39190
                           (length (caddar (##structure-ref
                                            _%snapshot30050%_
                                            '4
                                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                                            '#f)))))
                      (declare (not safe))
                      (##iota __tmp39190 '1))))
              (__tmp39188
               (map (lambda (_%fact30056%_)
                      (list 'candidate
                            (vector-ref _%fact30056%_ '2)
                            (vector-ref _%fact30056%_ '1)))
                    (##structure-ref
                     _%spec30051%_
                     '2
                     gerbil-ascent/candidate/types#reasoning-candidate::t
                     '#f))))
          (declare (not safe))
          (##append __tmp39189 __tmp39188))))
    (define gerbil-ascent/candidate/reasoning#candidate-edge-index
      (lambda (_%records30042%_)
        (let ((_%index30044%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (for-each
           (lambda (_%record30046%_)
             (let* ((_%origin30048%_ (caaddr _%record30046%_))
                    (__tmp39191
                     (cons _%record30046%_
                           (let ()
                             (declare (not safe))
                             (__hash-ref__%
                              _%index30044%_
                              _%origin30048%_
                              '())))))
               (declare (not safe))
               (__hash-put! _%index30044%_ _%origin30048%_ __tmp39191)))
           _%records30042%_)
          _%index30044%_)))
    (define gerbil-ascent/candidate/reasoning#candidate-graph-walk
      (lambda (_%records29967%_ _%origin29968%_ _%target29969%_)
        (let ((_%index29971%_
               (gerbil-ascent/candidate/reasoning#candidate-edge-index
                _%records29967%_))
              (_%visited29972%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value)))
              (_%reachable29973%_ (list _%origin29968%_))
              (_%support29974%_ '#f))
          (let ()
            (declare (not safe))
            (__hash-put! _%visited29972%_ _%origin29968%_ '#t))
          (let _%loop29976%_ ((_%front29978%_
                               (list (cons _%origin29968%_ '())))
                              (_%back29979%_ '()))
            (if (null? _%front29978%_)
                (if (null? _%back29979%_)
                    (values _%support29974%_
                            (let ()
                              (declare (not safe))
                              (##reverse _%reachable29973%_)))
                    (_%loop29976%_ (reverse _%back29979%_) '()))
                (let* ((_%state29983%_ (car _%front29978%_))
                       (_%node29985%_ (car _%state29983%_))
                       (_%path29987%_ (cdr _%state29983%_))
                       (_%next29989%_ _%back29979%_))
                  (let ((__tmp39193
                         (lambda (_%record29992%_)
                           (let* ((_%$%record2999330008%_ _%record29992%_)
                                  (_%$%E2999530011%_
                                   (lambda ()
                                     (let ()
                                       (declare (not safe))
                                       (error '"No clause matching"
                                              _%$%record2999330008%_
                                              '([_ _ [_ neighbor]])))
                                     '#!void))
                                  (_%$%K2999630018%_
                                   (lambda (_%neighbor30014%_)
                                     (let ((_%extended30016%_
                                            (cons _%record29992%_
                                                  _%path29987%_)))
                                       (if (if _%support29974%_
                                               '#f
                                               (equal? _%neighbor30014%_
                                                       _%target29969%_))
                                           (set! _%support29974%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##reverse
                                                    _%extended30016%_)))
                                           '#!void)
                                       (if (let ()
                                             (declare (not safe))
                                             (__hash-get
                                              _%visited29972%_
                                              _%neighbor30014%_))
                                           '#!void
                                           (begin
                                             (let ()
                                               (declare (not safe))
                                               (__hash-put!
                                                _%visited29972%_
                                                _%neighbor30014%_
                                                '#t))
                                             (set! _%reachable29973%_
                                                   (cons _%neighbor30014%_
                                                         _%reachable29973%_))
                                             (set! _%next29989%_
                                                   (cons (cons _%neighbor30014%_
                                                               _%extended30016%_)
                                                         _%next29989%_))))))))
                             (if (pair? _%$%record2999330008%_)
                                 (let ((_%$%tl2999830021%_
                                        (let ()
                                          (declare (not safe))
                                          (##cdr _%$%record2999330008%_))))
                                   (if (pair? _%$%tl2999830021%_)
                                       (let ((_%$%tl3000030024%_
                                              (let ()
                                                (declare (not safe))
                                                (##cdr _%$%tl2999830021%_))))
                                         (if (pair? _%$%tl3000030024%_)
                                             (let ((_%$%hd3000130027%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##car _%$%tl3000030024%_)))
                                                   (_%$%tl3000230029%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##cdr _%$%tl3000030024%_))))
                                               (if (pair? _%$%hd3000130027%_)
                                                   (let ((_%$%tl3000430032%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (##cdr _%$%hd3000130027%_))))
                                                     (if (pair? _%$%tl3000430032%_)
                                                         (let ((_%$%hd3000530035%_
                                                                (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##car _%$%tl3000430032%_)))
                       (_%$%tl3000630037%_
                        (let ()
                          (declare (not safe))
                          (##cdr _%$%tl3000430032%_))))
                   (let ((_%neighbor30040%_ _%$%hd3000530035%_))
                     (if (null? _%$%tl3000630037%_)
                         (if (null? _%$%tl3000230029%_)
                             (_%$%K2999630018%_ _%neighbor30040%_)
                             (_%$%E2999530011%_))
                         (_%$%E2999530011%_))))
                 (_%$%E2999530011%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (_%$%E2999530011%_)))
                                             (_%$%E2999530011%_)))
                                       (_%$%E2999530011%_)))
                                 (_%$%E2999530011%_)))))
                        (__tmp39192
                         (reverse (let ()
                                    (declare (not safe))
                                    (__hash-ref__%
                                     _%index29971%_
                                     _%node29985%_
                                     '())))))
                    (declare (not safe))
                    (##for-each __tmp39193 __tmp39192))
                  (_%loop29976%_ (cdr _%front29978%_) _%next29989%_)))))))
    (define gerbil-ascent/candidate/reasoning#candidate-evidence
      (lambda (_%snapshot29955%_ _%spec29956%_ _%query29957%_ _%rows29958%_)
        (if (gerbil-ascent/candidate/reasoning#candidate-graph-case?
             _%snapshot29955%_
             _%spec29956%_
             _%query29957%_)
            (let ((_g39194_
                   (gerbil-ascent/candidate/reasoning#candidate-graph-walk
                    (gerbil-ascent/candidate/reasoning#candidate-edge-records
                     _%snapshot29955%_
                     _%spec29956%_)
                    (cadr _%query29957%_)
                    (caddr _%query29957%_))))
              (begin
                (let ((_g39195_
                       (let ()
                         (declare (not safe))
                         (if (##values? _g39194_)
                             (##values-length _g39194_)
                             1))))
                  (if (not (let () (declare (not safe)) (##fx= _g39195_ 2)))
                      (error "Context expects 2 values" _g39195_)))
                (let ((_%support29960%_
                       (let () (declare (not safe)) (##values-ref _g39194_ 0)))
                      (_%reachable29961%_
                       (let ()
                         (declare (not safe))
                         (##values-ref _g39194_ 1))))
                  (if (and (pair? _%rows29958%_) _%support29960%_)
                      (let ()
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                         'witness
                         _%support29960%_
                         '()))
                      (if (and (null? _%rows29958%_)
                               (if _%support29960%_
                                   '#f
                                   (not (member (caddr _%query29957%_)
                                                _%reachable29961%_))))
                          (let ()
                            (declare (not safe))
                            (##structure
                             gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                             'cut
                             '()
                             _%reachable29961%_))
                          (if (and (null? _%rows29958%_)
                                   (if _%support29960%_
                                       '#f
                                       (equal? (cadr _%query29957%_)
                                               (caddr _%query29957%_))))
                              (let ()
                                (declare (not safe))
                                (##structure
                                 gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                                 'unsupported
                                 '()
                                 '()))
                              '#f))))))
            (let ()
              (declare (not safe))
              (##structure
               gerbil-ascent/candidate/reasoning#reasoning-evidence::t
               'unsupported
               '()
               '())))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
      (lambda (_%snapshot29889%_
               _%digest29890%_
               _%status29891%_
               _%query29892%_
               _%rows29893%_
               _%diagnostics29894%_
               _%evidence29895%_
               _%proof29896%_
               _%nonmembership29897%_
               _%stratified29898%_)
        (let ((__tmp39212
               (##structure-ref
                _%snapshot29889%_
                '1
                gerbil-ascent/candidate/types#reasoning-snapshot::t
                '#f))
              (__tmp39211
               (##structure-ref
                _%snapshot29889%_
                '2
                gerbil-ascent/candidate/types#reasoning-snapshot::t
                '#f))
              (__tmp39210
               (##structure-ref
                _%snapshot29889%_
                '3
                gerbil-ascent/candidate/types#reasoning-snapshot::t
                '#f))
              (__tmp39209
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/datum#candidate-copy-pairs
                  _%query29892%_)))
              (__tmp39208
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/datum#candidate-copy-pairs
                  _%rows29893%_)))
              (__tmp39202
               (map (lambda (_%diagnostic29900%_)
                      (let ((__tmp39207
                             (##structure-ref
                              _%diagnostic29900%_
                              '1
                              gerbil-ascent/candidate/types#reasoning-diagnostic::t
                              '#f))
                            (__tmp39205
                             (let ((__tmp39206
                                    (##structure-ref
                                     _%diagnostic29900%_
                                     '2
                                     gerbil-ascent/candidate/types#reasoning-diagnostic::t
                                     '#f)))
                               (declare (not safe))
                               (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                __tmp39206)))
                            (__tmp39203
                             (let ((__tmp39204
                                    (##structure-ref
                                     _%diagnostic29900%_
                                     '3
                                     gerbil-ascent/candidate/types#reasoning-diagnostic::t
                                     '#f)))
                               (declare (not safe))
                               (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                __tmp39204))))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/types#reasoning-diagnostic::t
                         __tmp39207
                         __tmp39205
                         __tmp39203)))
                    _%diagnostics29894%_))
              (__tmp39196
               (if _%evidence29895%_
                   (let ((__tmp39201
                          (##structure-ref
                           _%evidence29895%_
                           '1
                           gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                           '#f))
                         (__tmp39199
                          (let ((__tmp39200
                                 (##structure-ref
                                  _%evidence29895%_
                                  '2
                                  gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                                  '#f)))
                            (declare (not safe))
                            (gerbil-ascent/candidate/datum#candidate-copy-pairs
                             __tmp39200)))
                         (__tmp39197
                          (let ((__tmp39198
                                 (##structure-ref
                                  _%evidence29895%_
                                  '3
                                  gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                                  '#f)))
                            (declare (not safe))
                            (gerbil-ascent/candidate/datum#candidate-copy-pairs
                             __tmp39198))))
                     (declare (not safe))
                     (##structure
                      gerbil-ascent/candidate/reasoning#reasoning-evidence::t
                      __tmp39201
                      __tmp39199
                      __tmp39197))
                   '#f)))
          (declare (not safe))
          (##structure
           gerbil-ascent/candidate/reasoning#reasoning-receipt::t
           _%status29891%_
           __tmp39212
           __tmp39211
           __tmp39210
           _%digest29890%_
           __tmp39209
           __tmp39208
           __tmp39202
           __tmp39196
           _%proof29896%_
           _%nonmembership29897%_
           _%stratified29898%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
      (lambda (_%snapshot29905%_
               _%digest29906%_
               _%status29907%_
               _%query29908%_
               _%rows29909%_
               _%diagnostics29910%_
               _%evidence29911%_)
        (let* ((_%proof29913%_ '#f)
               (_%nonmembership29915%_ '#f)
               (_%stratified29917%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
           _%snapshot29905%_
           _%digest29906%_
           _%status29907%_
           _%query29908%_
           _%rows29909%_
           _%diagnostics29910%_
           _%evidence29911%_
           _%proof29913%_
           _%nonmembership29915%_
           _%stratified29917%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for__1
      (lambda (_%snapshot29919%_
               _%digest29920%_
               _%status29921%_
               _%query29922%_
               _%rows29923%_
               _%diagnostics29924%_
               _%evidence29925%_
               _%proof29926%_)
        (let* ((_%nonmembership29928%_ '#f) (_%stratified29930%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
           _%snapshot29919%_
           _%digest29920%_
           _%status29921%_
           _%query29922%_
           _%rows29923%_
           _%diagnostics29924%_
           _%evidence29925%_
           _%proof29926%_
           _%nonmembership29928%_
           _%stratified29930%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for__2
      (lambda (_%snapshot29932%_
               _%digest29933%_
               _%status29934%_
               _%query29935%_
               _%rows29936%_
               _%diagnostics29937%_
               _%evidence29938%_
               _%proof29939%_
               _%nonmembership29940%_)
        (let ((_%stratified29942%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
           _%snapshot29932%_
           _%digest29933%_
           _%status29934%_
           _%query29935%_
           _%rows29936%_
           _%diagnostics29937%_
           _%evidence29938%_
           _%proof29939%_
           _%nonmembership29940%_
           _%stratified29942%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-receipt-for
      (lambda _g39213_
        (let ((_g39214_ (let () (declare (not safe)) (##length _g39213_))))
          (cond ((let () (declare (not safe)) (##fx= _g39214_ 7))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
                        _g39213_))
                ((let () (declare (not safe)) (##fx= _g39214_ 8))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-receipt-for__1
                        _g39213_))
                ((let () (declare (not safe)) (##fx= _g39214_ 9))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-receipt-for__2
                        _g39213_))
                ((let () (declare (not safe)) (##fx= _g39214_ 10))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
                        _g39213_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/candidate/reasoning#reasoning-receipt-for
                  _g39213_))))))
    (define gerbil-ascent/candidate/reasoning#captured-stage::t
      (let ((__tmp39216 (list)) (__tmp39215 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#captured-stage::t
         'captured-stage
         __tmp39216
         '(ok? value)
         __tmp39215
         '#f)))
    (define gerbil-ascent/candidate/reasoning#captured-stage?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#captured-stage::t)))
    (define gerbil-ascent/candidate/reasoning#make-captured-stage
      (lambda _%$args29885%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#captured-stage::t
               _%$args29885%_)))
    (define gerbil-ascent/candidate/reasoning#captured-stage-ok?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'ok?)))
    (define gerbil-ascent/candidate/reasoning#captured-stage-value
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'value)))
    (define gerbil-ascent/candidate/reasoning#captured-stage-ok?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'ok?)))
    (define gerbil-ascent/candidate/reasoning#captured-stage-value-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'value)))
    (define gerbil-ascent/candidate/reasoning#&captured-stage-ok?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'ok?)))
    (define gerbil-ascent/candidate/reasoning#&captured-stage-value
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'value)))
    (define gerbil-ascent/candidate/reasoning#&captured-stage-ok?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'ok?)))
    (define gerbil-ascent/candidate/reasoning#&captured-stage-value-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#captured-stage::t
         'value)))
    (define gerbil-ascent/candidate/reasoning#capture
      (lambda (_%thunk29880%_)
        (let ((__tmp39219
               (lambda (_%failure29882%_)
                 (let ()
                   (declare (not safe))
                   (##structure
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#f
                    _%failure29882%_))))
              (__tmp39217
               (lambda ()
                 (let ((__tmp39218 (_%thunk29880%_)))
                   (declare (not safe))
                   (##structure
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#t
                    __tmp39218)))))
          (declare (not safe))
          (__with-catch __tmp39219 __tmp39217))))
    (define gerbil-ascent/candidate/reasoning#failure-detail
      (lambda (_%failure29876%_)
        (let ((_%message29878%_
               (let ()
                 (declare (not safe))
                 (std/error#exception->string _%failure29876%_))))
          (if (> (let ()
                   (declare (not safe))
                   (##string-length _%message29878%_))
                 '240)
              (substring _%message29878%_ '0 '240)
              _%message29878%_))))
    (define gerbil-ascent/candidate/reasoning#produce-receipt-stratified
      (lambda (_%snapshot29865%_
               _%spec29866%_
               _%digest29867%_
               _%rows29868%_
               _%work-budget29869%_)
        (let ((_%finite29871%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/finite-evidence#candidate-finite-evidence
                  _%snapshot29865%_
                  _%spec29866%_
                  _%digest29867%_
                  'complete
                  _%rows29868%_
                  _%work-budget29869%_))))
          (if (eq? (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref _%finite29871%_ '1 '#f '#f))
                   'complete)
              (let ((_g39220_
                     (let ()
                       (declare (not safe))
                       (gerbil-ascent/candidate/stratified-producer#candidate-produce-stratified-proof
                        _%snapshot29865%_
                        _%spec29866%_
                        _%digest29867%_
                        'complete
                        _%rows29868%_
                        _%finite29871%_
                        _%work-budget29869%_
                        _%work-budget29869%_))))
                (begin
                  (let ((_g39221_
                         (let ()
                           (declare (not safe))
                           (if (##values? _g39220_)
                               (##values-length _g39220_)
                               1))))
                    (if (not (let () (declare (not safe)) (##fx= _g39221_ 2)))
                        (error "Context expects 2 values" _g39221_)))
                  (let ((_%status29873%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g39220_ 0)))
                        (_%proof29874%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g39220_ 1))))
                    (let ()
                      (declare (not safe))
                      (##structure
                       gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                       _%status29873%_
                       _%finite29871%_
                       _%proof29874%_
                       _%work-budget29869%_)))))
              (let ((__tmp39222
                     (let ()
                       (declare (not safe))
                       (##unchecked-structure-ref
                        _%finite29871%_
                        '1
                        '#f
                        '#f))))
                (declare (not safe))
                (##structure
                 gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                 __tmp39222
                 _%finite29871%_
                 '()
                 _%work-budget29869%_))))))
    (define gerbil-ascent/candidate/reasoning#reasoning-verify-finite-receipt
      (lambda (_%receipt29857%_
               _%snapshot29858%_
               _%candidate29859%_
               _%work-budget29860%_)
        (if (and (exact-integer? _%work-budget29860%_)
                 (> _%work-budget29860%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"finite receipt verification needs positive work budget"
                     _%work-budget29860%_)))
        (if (and (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                  _%receipt29857%_
                  _%snapshot29858%_
                  _%candidate29859%_)
                 (eq? (##structure-ref
                       _%receipt29857%_
                       '1
                       gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                       '#f)
                      'complete)
                 (let ((__tmp39223
                        (##structure-ref
                         _%receipt29857%_
                         '12
                         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                         '#f)))
                   (declare (not safe))
                   (##structure-instance-of?
                    __tmp39223
                    'gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t)))
            (let ((_%checked29863%_
                   (gerbil-ascent/candidate/reasoning#capture
                    (lambda ()
                      (let ((__tmp39227
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program#candidate-inspect
                                _%snapshot29858%_
                                _%candidate29859%_)))
                            (__tmp39226
                             (##structure-ref
                              _%receipt29857%_
                              '5
                              gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                              '#f))
                            (__tmp39225
                             (##structure-ref
                              _%receipt29857%_
                              '7
                              gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                              '#f))
                            (__tmp39224
                             (##structure-ref
                              (##structure-ref
                               _%receipt29857%_
                               '12
                               gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                               '#f)
                              '2
                              gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                              '#f)))
                        (declare (not safe))
                        (gerbil-ascent/candidate/finite-evidence#candidate-verify-finite-evidence
                         _%snapshot29858%_
                         __tmp39227
                         __tmp39226
                         'complete
                         __tmp39225
                         __tmp39224
                         _%work-budget29860%_))))))
              (if (##structure-ref
                   _%checked29863%_
                   '1
                   gerbil-ascent/candidate/reasoning#captured-stage::t
                   '#f)
                  (##structure-ref
                   _%checked29863%_
                   '2
                   gerbil-ascent/candidate/reasoning#captured-stage::t
                   '#f)
                  'invalid))
            'invalid)))
    (define gerbil-ascent/candidate/reasoning#reasoning-verify-stratified-receipt
      (lambda (_%receipt29844%_
               _%snapshot29845%_
               _%candidate29846%_
               _%work-budget29847%_)
        (if (and (exact-integer? _%work-budget29847%_)
                 (> _%work-budget29847%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"stratified receipt verification needs positive work budget"
                     _%work-budget29847%_)))
        (if (and (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                  _%receipt29844%_
                  _%snapshot29845%_
                  _%candidate29846%_)
                 (eq? (##structure-ref
                       _%receipt29844%_
                       '1
                       gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                       '#f)
                      'complete)
                 (let ((__tmp39228
                        (##structure-ref
                         _%receipt29844%_
                         '12
                         gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                         '#f)))
                   (declare (not safe))
                   (##structure-instance-of?
                    __tmp39228
                    'gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t)))
            (let* ((_%evidence29849%_
                    (##structure-ref
                     _%receipt29844%_
                     '12
                     gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                     '#f))
                   (_%$e29851%_
                    (##structure-ref
                     _%evidence29849%_
                     '1
                     gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                     '#f)))
              (if (eq? 'complete _%$e29851%_)
                  (let ((_%checked29855%_
                         (gerbil-ascent/candidate/reasoning#capture
                          (lambda ()
                            (let ((__tmp39233
                                   (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/program#candidate-inspect
                                      _%snapshot29845%_
                                      _%candidate29846%_)))
                                  (__tmp39232
                                   (##structure-ref
                                    _%receipt29844%_
                                    '5
                                    gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                    '#f))
                                  (__tmp39231
                                   (##structure-ref
                                    _%receipt29844%_
                                    '7
                                    gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                    '#f))
                                  (__tmp39230
                                   (##structure-ref
                                    _%evidence29849%_
                                    '2
                                    gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                                    '#f))
                                  (__tmp39229
                                   (##structure-ref
                                    _%evidence29849%_
                                    '3
                                    gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                                    '#f)))
                              (declare (not safe))
                              (gerbil-ascent/candidate/stratified-proof#candidate-verify-stratified-proof
                               _%snapshot29845%_
                               __tmp39233
                               __tmp39232
                               'complete
                               __tmp39231
                               __tmp39230
                               _%work-budget29847%_
                               __tmp39229
                               _%work-budget29847%_))))))
                    (if (##structure-ref
                         _%checked29855%_
                         '1
                         gerbil-ascent/candidate/reasoning#captured-stage::t
                         '#f)
                        (##structure-ref
                         _%checked29855%_
                         '2
                         gerbil-ascent/candidate/reasoning#captured-stage::t
                         '#f)
                        'invalid))
                  (if (eq? 'bounded _%$e29851%_)
                      'bounded
                      (if (eq? 'unsupported _%$e29851%_)
                          'unsupported
                          'invalid))))
            'invalid)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation::t
      (let ((__tmp39235 (list)) (__tmp39234 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/reasoning#attempt-observation::t
         'attempt-observation
         __tmp39235
         '(rows evidence)
         __tmp39234
         '#f)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/reasoning#attempt-observation::t)))
    (define gerbil-ascent/candidate/reasoning#make-attempt-observation
      (lambda _%$args29841%_
        (apply make-instance
               gerbil-ascent/candidate/reasoning#attempt-observation::t
               _%$args29841%_)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation-evidence
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#attempt-observation-evidence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#&attempt-observation-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#&attempt-observation-evidence
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#&attempt-observation-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'rows)))
    (define gerbil-ascent/candidate/reasoning#&attempt-observation-evidence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/reasoning#attempt-observation::t
         'evidence)))
    (define gerbil-ascent/candidate/reasoning#attempt-failure
      (lambda (_%snapshot29833%_
               _%digest29834%_
               _%status29835%_
               _%query29836%_
               _%code29837%_
               _%path29838%_
               _%failure29839%_)
        (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
         _%snapshot29833%_
         _%digest29834%_
         _%status29835%_
         _%query29836%_
         '()
         (list (let ((__tmp39236
                      (gerbil-ascent/candidate/reasoning#failure-detail
                       _%failure29839%_)))
                 (declare (not safe))
                 (##structure
                  gerbil-ascent/candidate/types#reasoning-diagnostic::t
                  _%code29837%_
                  _%path29838%_
                  __tmp39236)))
         '#f)))
    (define gerbil-ascent/candidate/reasoning#attempt-proof-diagnostics
      (lambda (_%result29827%_ _%code29828%_)
        (if (or (not _%result29827%_)
                (##structure-ref
                 _%result29827%_
                 '1
                 gerbil-ascent/candidate/reasoning#captured-stage::t
                 '#f))
            '()
            (list (let ((__tmp39237
                         (gerbil-ascent/candidate/reasoning#failure-detail
                          (##structure-ref
                           _%result29827%_
                           '2
                           gerbil-ascent/candidate/reasoning#captured-stage::t
                           '#f))))
                    (declare (not safe))
                    (##structure
                     gerbil-ascent/candidate/types#reasoning-diagnostic::t
                     _%code29828%_
                     '(explain)
                     __tmp39237))))))
    (define gerbil-ascent/candidate/reasoning#attempt-proof-value
      (lambda (_%result29825%_)
        (if _%result29825%_
            (if (##structure-ref
                 _%result29825%_
                 '1
                 gerbil-ascent/candidate/reasoning#captured-stage::t
                 '#f)
                (##structure-ref
                 _%result29825%_
                 '2
                 gerbil-ascent/candidate/reasoning#captured-stage::t
                 '#f)
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/reasoning#attempt-publish
      (lambda (_%snapshot29779%_
               _%spec29780%_
               _%digest29781%_
               _%query29782%_
               _%observation29783%_
               _%proof-steps29784%_
               _%stratified-steps29785%_)
        (let* ((_%$%observation2978629793%_ _%observation29783%_)
               (_%$%E2978829796%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%observation2978629793%_
                           '((attempt-observation rows evidence))))
                  '#!void))
               (_%$%K2978929812%_
                (lambda (_%evidence29799%_ _%rows29800%_)
                  (let* ((_%proof29803%_
                          (gerbil-ascent/candidate/reasoning#capture
                           (lambda ()
                             (if _%proof-steps29784%_
                                 (let ()
                                   (declare (not safe))
                                   (gerbil-ascent/candidate/provenance#candidate-positive-proof
                                    _%snapshot29779%_
                                    _%spec29780%_
                                    _%digest29781%_
                                    'complete
                                    _%rows29800%_
                                    _%proof-steps29784%_))
                                 '#f))))
                         (_%absence29806%_
                          (gerbil-ascent/candidate/reasoning#capture
                           (lambda ()
                             (if _%proof-steps29784%_
                                 (let ()
                                   (declare (not safe))
                                   (gerbil-ascent/candidate/nonmembership#candidate-positive-nonmembership
                                    _%snapshot29779%_
                                    _%spec29780%_
                                    _%digest29781%_
                                    'complete
                                    _%rows29800%_
                                    _%proof-steps29784%_))
                                 '#f))))
                         (_%stratified29809%_
                          (if _%stratified-steps29785%_
                              (gerbil-ascent/candidate/reasoning#capture
                               (lambda ()
                                 (gerbil-ascent/candidate/reasoning#produce-receipt-stratified
                                  _%snapshot29779%_
                                  _%spec29780%_
                                  _%digest29781%_
                                  _%rows29800%_
                                  _%stratified-steps29785%_)))
                              '#f)))
                    (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__%
                     _%snapshot29779%_
                     _%digest29781%_
                     'complete
                     _%query29782%_
                     _%rows29800%_
                     (let ((__tmp39240
                            (gerbil-ascent/candidate/reasoning#attempt-proof-diagnostics
                             _%proof29803%_
                             'proof-failed))
                           (__tmp39239
                            (gerbil-ascent/candidate/reasoning#attempt-proof-diagnostics
                             _%absence29806%_
                             'nonmembership-failed))
                           (__tmp39238
                            (gerbil-ascent/candidate/reasoning#attempt-proof-diagnostics
                             _%stratified29809%_
                             'stratified-evidence-failed)))
                       (declare (not safe))
                       (##append __tmp39240 __tmp39239 __tmp39238))
                     _%evidence29799%_
                     (gerbil-ascent/candidate/reasoning#attempt-proof-value
                      _%proof29803%_)
                     (gerbil-ascent/candidate/reasoning#attempt-proof-value
                      _%absence29806%_)
                     (gerbil-ascent/candidate/reasoning#attempt-proof-value
                      _%stratified29809%_))))))
          (if (let ()
                (declare (not safe))
                (##structure-instance-of?
                 _%$%observation2978629793%_
                 'gerbil-ascent/candidate/reasoning#attempt-observation::t))
              (let* ((_%$%e2979029815%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%observation2978629793%_
                         '1
                         '#f
                         '#f)))
                     (_%rows29818%_ _%$%e2979029815%_)
                     (_%$%e2979129820%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%observation2978629793%_
                         '2
                         '#f
                         '#f)))
                     (_%evidence29823%_ _%$%e2979129820%_))
                (_%$%K2978929812%_ _%evidence29823%_ _%rows29818%_))
              (_%$%E2978829796%_)))))
    (define gerbil-ascent/candidate/reasoning#attempt-observe
      (lambda (_%snapshot29756%_
               _%spec29757%_
               _%digest29758%_
               _%query29759%_
               _%solved29760%_
               _%proof-steps29761%_
               _%stratified-steps29762%_)
        (let ((_%observed29774%_
               (gerbil-ascent/candidate/reasoning#capture
                (lambda ()
                  (let* ((_%all29765%_
                          (let ((__tmp39241 (car _%query29759%_)))
                            (declare (not safe))
                            (gerbil-ascent/program/scheme-query#relational-query-name
                             _%solved29760%_
                             __tmp39241)))
                         (_%rows29771%_
                          (let ((__tmp39242
                                 (lambda (_%$%g2976629768%_)
                                   (gerbil-ascent/candidate/reasoning#query-row-matches?
                                    (cdr _%query29759%_)
                                    _%$%g2976629768%_))))
                            (declare (not safe))
                            (##filter __tmp39242 _%all29765%_)))
                         (__tmp39243
                          (gerbil-ascent/candidate/reasoning#candidate-evidence
                           _%snapshot29756%_
                           _%spec29757%_
                           _%query29759%_
                           _%rows29771%_)))
                    (declare (not safe))
                    (##structure
                     gerbil-ascent/candidate/reasoning#attempt-observation::t
                     _%rows29771%_
                     __tmp39243))))))
          (if (##structure-ref
               _%observed29774%_
               '1
               gerbil-ascent/candidate/reasoning#captured-stage::t
               '#f)
              (if (##structure-ref
                   (##structure-ref
                    _%observed29774%_
                    '2
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#f)
                   '2
                   gerbil-ascent/candidate/reasoning#attempt-observation::t
                   '#f)
                  (gerbil-ascent/candidate/reasoning#attempt-publish
                   _%snapshot29756%_
                   _%spec29757%_
                   _%digest29758%_
                   _%query29759%_
                   (##structure-ref
                    _%observed29774%_
                    '2
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#f)
                   _%proof-steps29761%_
                   _%stratified-steps29762%_)
                  (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
                   _%snapshot29756%_
                   _%digest29758%_
                   'unknown
                   _%query29759%_
                   '()
                   (list (let ()
                           (declare (not safe))
                           (##structure
                            gerbil-ascent/candidate/types#reasoning-diagnostic::t
                            'evidence-mismatch
                            '(explain)
                            _%query29759%_)))
                   '#f))
              (gerbil-ascent/candidate/reasoning#attempt-failure
               _%snapshot29756%_
               _%digest29758%_
               'unknown
               _%query29759%_
               'query-failed
               '(query)
               (##structure-ref
                _%observed29774%_
                '2
                gerbil-ascent/candidate/reasoning#captured-stage::t
                '#f))))))
    (define gerbil-ascent/candidate/reasoning#attempt-solve
      (lambda (_%snapshot29743%_
               _%spec29744%_
               _%digest29745%_
               _%query29746%_
               _%report29747%_
               _%proof-steps29748%_
               _%stratified-steps29749%_)
        (let ((_%diagnostic29751%_
               (##structure-ref
                _%report29747%_
                '2
                gerbil-ascent/program/scheme-admit#relational-admission-report::t
                '#f)))
          (if _%diagnostic29751%_
              (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
               _%snapshot29743%_
               _%digest29745%_
               'rejected
               _%query29746%_
               '()
               (list (let ((__tmp39247
                            (##structure-ref
                             _%diagnostic29751%_
                             '1
                             gerbil-ascent/program/scheme-admit#relational-diagnostic::t
                             '#f))
                           (__tmp39245
                            (let ((__tmp39246
                                   (##structure-ref
                                    _%diagnostic29751%_
                                    '2
                                    gerbil-ascent/program/scheme-admit#relational-diagnostic::t
                                    '#f)))
                              (declare (not safe))
                              (gerbil-ascent/candidate/program#candidate-planner-path
                               _%spec29744%_
                               __tmp39246)))
                           (__tmp39244
                            (##structure-ref
                             _%diagnostic29751%_
                             '3
                             gerbil-ascent/program/scheme-admit#relational-diagnostic::t
                             '#f)))
                       (declare (not safe))
                       (##structure
                        gerbil-ascent/candidate/types#reasoning-diagnostic::t
                        __tmp39247
                        __tmp39245
                        __tmp39244)))
               '#f)
              (let ((_%solved29754%_
                     (gerbil-ascent/candidate/reasoning#capture
                      (lambda ()
                        (let ((__tmp39248
                               (##structure-ref
                                _%report29747%_
                                '1
                                gerbil-ascent/program/scheme-admit#relational-admission-report::t
                                '#f)))
                          (declare (not safe))
                          (gerbil-ascent/program/scheme-admit#relational-solve
                           __tmp39248))))))
                (if (##structure-ref
                     _%solved29754%_
                     '1
                     gerbil-ascent/candidate/reasoning#captured-stage::t
                     '#f)
                    (gerbil-ascent/candidate/reasoning#attempt-observe
                     _%snapshot29743%_
                     _%spec29744%_
                     _%digest29745%_
                     _%query29746%_
                     (##structure-ref
                      _%solved29754%_
                      '2
                      gerbil-ascent/candidate/reasoning#captured-stage::t
                      '#f)
                     _%proof-steps29748%_
                     _%stratified-steps29749%_)
                    (gerbil-ascent/candidate/reasoning#attempt-failure
                     _%snapshot29743%_
                     _%digest29745%_
                     'unknown
                     _%query29746%_
                     'solve-failed
                     '(solve)
                     (##structure-ref
                      _%solved29754%_
                      '2
                      gerbil-ascent/candidate/reasoning#captured-stage::t
                      '#f))))))))
    (define gerbil-ascent/candidate/reasoning#attempt-prepare
      (lambda (_%snapshot29731%_
               _%spec29732%_
               _%digest29733%_
               _%proof-steps29734%_
               _%stratified-steps29735%_)
        (let* ((_%query29737%_
                (vector-ref
                 (##structure-ref
                  _%spec29732%_
                  '4
                  gerbil-ascent/candidate/types#reasoning-candidate::t
                  '#f)
                 '0))
               (_%prepared29740%_
                (gerbil-ascent/candidate/reasoning#capture
                 (lambda ()
                   (let ((__tmp39249
                          (let ()
                            (declare (not safe))
                            (gerbil-ascent/candidate/program#candidate-program
                             _%snapshot29731%_
                             _%spec29732%_))))
                     (declare (not safe))
                     (gerbil-ascent/program/scheme-admit#relational-admit/report
                      __tmp39249))))))
          (if (##structure-ref
               _%prepared29740%_
               '1
               gerbil-ascent/candidate/reasoning#captured-stage::t
               '#f)
              (gerbil-ascent/candidate/reasoning#attempt-solve
               _%snapshot29731%_
               _%spec29732%_
               _%digest29733%_
               _%query29737%_
               (##structure-ref
                _%prepared29740%_
                '2
                gerbil-ascent/candidate/reasoning#captured-stage::t
                '#f)
               _%proof-steps29734%_
               _%stratified-steps29735%_)
              (gerbil-ascent/candidate/reasoning#attempt-failure
               _%snapshot29731%_
               _%digest29733%_
               'rejected
               _%query29737%_
               'planner-rejected
               '(program)
               (##structure-ref
                _%prepared29740%_
                '2
                gerbil-ascent/candidate/reasoning#captured-stage::t
                '#f))))))
    (define gerbil-ascent/candidate/reasoning#reasoning-attempt__%
      (lambda (_%snapshot29690%_
               _%candidate29691%_
               _%proof-steps29692%_
               _%stratified-steps29693%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
               _%snapshot29690%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"reasoning attempt requires a current valid source snapshot"
                     _%snapshot29690%_)))
        (if (or (not _%proof-steps29692%_)
                (and (exact-integer? _%proof-steps29692%_)
                     (> _%proof-steps29692%_ '0)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"reasoning attempt requires positive proof work budget or #f"
                     _%proof-steps29692%_)))
        (if (or (not _%stratified-steps29693%_)
                (and (exact-integer? _%stratified-steps29693%_)
                     (> _%stratified-steps29693%_ '0)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"reasoning attempt requires positive stratified work budget"
                     _%stratified-steps29693%_)))
        (let* ((_%digest29701%_
                (gerbil-ascent/candidate/reasoning#candidate-content-digest
                 _%candidate29691%_))
               (_%inspection29704%_
                (gerbil-ascent/candidate/reasoning#capture
                 (lambda ()
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/program#candidate-inspect
                      _%snapshot29690%_
                      _%candidate29691%_))))))
          (if (##structure-ref
               _%inspection29704%_
               '1
               gerbil-ascent/candidate/reasoning#captured-stage::t
               '#f)
              (gerbil-ascent/candidate/reasoning#attempt-prepare
               _%snapshot29690%_
               (##structure-ref
                _%inspection29704%_
                '2
                gerbil-ascent/candidate/reasoning#captured-stage::t
                '#f)
               _%digest29701%_
               _%proof-steps29692%_
               _%stratified-steps29693%_)
              (if (let ((__tmp39250
                         (##structure-ref
                          _%inspection29704%_
                          '2
                          gerbil-ascent/candidate/reasoning#captured-stage::t
                          '#f)))
                    (declare (not safe))
                    (##structure-instance-of?
                     __tmp39250
                     'gerbil-ascent/candidate/types#candidate-rejection::t))
                  (gerbil-ascent/candidate/reasoning#reasoning-receipt-for__0
                   _%snapshot29690%_
                   _%digest29701%_
                   'rejected
                   '#f
                   '()
                   (list (##structure-ref
                          (##structure-ref
                           _%inspection29704%_
                           '2
                           gerbil-ascent/candidate/reasoning#captured-stage::t
                           '#f)
                          '1
                          gerbil-ascent/candidate/types#candidate-rejection::t
                          '#f))
                   '#f)
                  (gerbil-ascent/candidate/reasoning#attempt-failure
                   _%snapshot29690%_
                   _%digest29701%_
                   'unknown
                   '#f
                   'inspector-failed
                   '(candidate)
                   (##structure-ref
                    _%inspection29704%_
                    '2
                    gerbil-ascent/candidate/reasoning#captured-stage::t
                    '#f)))))))
    (define gerbil-ascent/candidate/reasoning#reasoning-attempt__0
      (lambda (_%snapshot29713%_ _%candidate29714%_)
        (let* ((_%proof-steps29716%_ '100000) (_%stratified-steps29718%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-attempt__%
           _%snapshot29713%_
           _%candidate29714%_
           _%proof-steps29716%_
           _%stratified-steps29718%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-attempt__1
      (lambda (_%snapshot29720%_ _%candidate29721%_ _%proof-steps29722%_)
        (let ((_%stratified-steps29724%_ '#f))
          (gerbil-ascent/candidate/reasoning#reasoning-attempt__%
           _%snapshot29720%_
           _%candidate29721%_
           _%proof-steps29722%_
           _%stratified-steps29724%_))))
    (define gerbil-ascent/candidate/reasoning#reasoning-attempt
      (lambda _g39251_
        (let ((_g39252_ (let () (declare (not safe)) (##length _g39251_))))
          (cond ((let () (declare (not safe)) (##fx= _g39252_ 2))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-attempt__0
                        _g39251_))
                ((let () (declare (not safe)) (##fx= _g39252_ 3))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                        _g39251_))
                ((let () (declare (not safe)) (##fx= _g39252_ 4))
                 (apply gerbil-ascent/candidate/reasoning#reasoning-attempt__%
                        _g39251_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/candidate/reasoning#reasoning-attempt
                  _g39251_))))))))
