(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/types::timestamp 1791689691)
  (begin
    (define gerbil-ascent/program/types#slot-contract
      (lambda (_%identity5664%_ _%predicate5665%_)
        (let ((__tmp35225 (lambda (_%_value5667%_ _%_context5668%_) '())))
          (declare (not safe))
          (core/types#poo-flow-predicate-contract
           _%identity5664%_
           _%predicate5665%_
           __tmp35225))))
    (define gerbil-ascent/program/types#+symbol+
      (gerbil-ascent/program/types#slot-contract 'ascent/symbol symbol?))
    (define gerbil-ascent/program/types#+arity+
      (gerbil-ascent/program/types#slot-contract
       'ascent/arity
       (lambda (_%value5662%_)
         (if (exact-integer? _%value5662%_) (<= '0 _%value5662%_) '#f))))
    (define gerbil-ascent/program/types#+fact-budget+
      (gerbil-ascent/program/types#slot-contract
       'ascent/fact-budget
       (lambda (_%value5660%_)
         (if (exact-integer? _%value5660%_) (> _%value5660%_ '0) '#f))))
    (define gerbil-ascent/program/types#+rows+
      (gerbil-ascent/program/types#slot-contract 'ascent/rows list?))
    (define gerbil-ascent/program/types#+field-predicates+
      (gerbil-ascent/program/types#slot-contract
       'ascent/field-predicates
       (lambda (_%value5658%_)
         (if (list? _%value5658%_)
             (let () (declare (not safe)) (andmap__0 procedure? _%value5658%_))
             '#f))))
    (define gerbil-ascent/program/types#+provider+
      (gerbil-ascent/program/types#slot-contract
       'ascent/index-provider
       (lambda (_%value5653%_)
         (let ((_%$e5655%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                   _%value5653%_))))
           (if _%$e5655%_
               _%$e5655%_
               (let ()
                 (declare (not safe))
                 (clan/poo/mop#element?
                  gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
                  _%value5653%_)))))))
    (define gerbil-ascent/program/types#+storage-provider+
      (gerbil-ascent/program/types#slot-contract
       'ascent/storage-provider
       (lambda (_%value5648%_)
         (let ((_%$e5650%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                   _%value5648%_))))
           (if _%$e5650%_
               _%$e5650%_
               (let ()
                 (declare (not safe))
                 (clan/poo/mop#element?
                  gerbil-ascent/table/storage#GerbilAscentStorageProviderContract
                  _%value5648%_)))))))
    (define gerbil-ascent/program/types#+term-kind+
      (gerbil-ascent/program/types#slot-contract
       'ascent/term-kind
       (lambda (_%value5646%_)
         (let ()
           (declare (not safe))
           (##memq _%value5646%_
                   '(variable wildcard literal expression pattern))))))
    (define gerbil-ascent/program/types#+any+
      (gerbil-ascent/program/types#slot-contract
       'ascent/value
       (lambda (_%_value5644%_) '#t)))
    (define gerbil-ascent/program/types#+plan+
      (gerbil-ascent/program/types#slot-contract
       'ascent/clause-plan
       procedure?))
    (define gerbil-ascent/program/types#clause-kind-contract
      (lambda (_%kind5640%_)
        (gerbil-ascent/program/types#slot-contract
         'ascent/clause-kind
         (lambda (_%value5642%_) (eq? _%value5642%_ _%kind5640%_)))))
    (define gerbil-ascent/program/types#GerbilAscentRelationContract
      (let ((__obj35182
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35227
               (list (cons 'sexp
                           (let ((__tmp35228
                                  (lambda (_%@5556%_)
                                    'GerbilAscentRelationContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35228)))
                     (cons 'identity
                           (let ((__tmp35229
                                  (lambda (_%@5562%_) 'ascent/relation)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35229)))
                     (cons 'proto
                           (let ((__tmp35230
                                  (lambda (_%@5567%_)
                                    (let ((__obj35180
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35232 (list))
                                            (__tmp35231 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35232
                                         __tmp35231
                                         __obj35180))
                                      __obj35180))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35230)))
                     (cons 'responsibilities
                           (let ((__tmp35233
                                  (lambda (_%@5581%_)
                                    (let ((__obj35181
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35235
                                             (list (cons 'name
                                                         (let ((__tmp35236
                                                                (lambda (_%self5603%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35236)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'arity
                                                         (let ((__tmp35237
                                                                (lambda (_%self5610%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+arity+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35237)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'rows
                                                         (let ((__tmp35238
                                                                (lambda (_%self5615%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+rows+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35238)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'field-predicates
                                                         (let ((__tmp35239
                                                                (lambda (_%self5620%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+field-predicates+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35239)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'storage-kind
                                                         (let ((__tmp35240
                                                                (lambda (_%self5625%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'relation))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35240)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'index-provider
                                                         (let ((__tmp35241
                                                                (lambda (_%self5630%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+provider+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35241)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'storage-provider
                                                         (let ((__tmp35242
                                                                (lambda (_%self5635%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+storage-provider+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35242)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35234 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35235
                                         __tmp35234
                                         __obj35181))
                                      __obj35181))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35233)))))
              (__tmp35226 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35227
           __tmp35226
           __obj35182))
        __obj35182))
    (define gerbil-ascent/program/types#GerbilAscentLatticeContract
      (let ((__obj35185
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35244
               (list (cons 'sexp
                           (let ((__tmp35245
                                  (lambda (_%@5448%_)
                                    'GerbilAscentLatticeContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35245)))
                     (cons 'identity
                           (let ((__tmp35246
                                  (lambda (_%@5454%_) 'ascent/lattice)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35246)))
                     (cons 'proto
                           (let ((__tmp35247
                                  (lambda (_%@5459%_)
                                    (let ((__obj35183
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35249 (list))
                                            (__tmp35248 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35249
                                         __tmp35248
                                         __obj35183))
                                      __obj35183))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35247)))
                     (cons 'responsibilities
                           (let ((__tmp35250
                                  (lambda (_%@5473%_)
                                    (let ((__obj35184
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35252
                                             (list (cons 'name
                                                         (let ((__tmp35253
                                                                (lambda (_%self5496%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35253)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'arity
                                                         (let ((__tmp35254
                                                                (lambda (_%self5503%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+arity+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35254)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'rows
                                                         (let ((__tmp35255
                                                                (lambda (_%self5508%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+rows+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35255)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'field-predicates
                                                         (let ((__tmp35256
                                                                (lambda (_%self5513%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+field-predicates+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35256)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'storage-kind
                                                         (let ((__tmp35257
                                                                (lambda (_%self5518%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'lattice))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35257)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'join
                                                         (let ((__tmp35258
                                                                (lambda (_%self5523%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#slot-contract
                           'ascent/lattice-join
                           procedure?))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35258)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'checked-operator
                                                         (let ((__tmp35259
                                                                (lambda (_%self5528%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#slot-contract
                           'ascent/lattice-checked-operator
                           (lambda (_%value5533%_)
                             (let ((_%$e5535%_ (not _%value5533%_)))
                               (if _%$e5535%_
                                   _%$e5535%_
                                   (vector? _%value5533%_))))))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35259)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'index-provider
                                                         (let ((__tmp35260
                                                                (lambda (_%self5538%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+provider+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35260)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35251 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35252
                                         __tmp35251
                                         __obj35184))
                                      __obj35184))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35250)))))
              (__tmp35243 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35244
           __tmp35243
           __obj35185))
        __obj35185))
    (define gerbil-ascent/program/types#GerbilAscentTermContract
      (let ((__obj35188
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35262
               (list (cons 'sexp
                           (let ((__tmp35263
                                  (lambda (_%@5381%_)
                                    'GerbilAscentTermContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35263)))
                     (cons 'identity
                           (let ((__tmp35264
                                  (lambda (_%@5387%_) 'ascent/term)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35264)))
                     (cons 'proto
                           (let ((__tmp35265
                                  (lambda (_%@5392%_)
                                    (let ((__obj35186
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35267 (list))
                                            (__tmp35266 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35267
                                         __tmp35266
                                         __obj35186))
                                      __obj35186))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35265)))
                     (cons 'responsibilities
                           (let ((__tmp35268
                                  (lambda (_%@5406%_)
                                    (let ((__obj35187
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35270
                                             (list (cons 'kind
                                                         (let ((__tmp35271
                                                                (lambda (_%self5423%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+term-kind+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35271)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'value
                                                         (let ((__tmp35272
                                                                (lambda (_%self5430%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+any+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35272)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35269 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35270
                                         __tmp35269
                                         __obj35187))
                                      __obj35187))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35268)))))
              (__tmp35261 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35262
           __tmp35261
           __obj35188))
        __obj35188))
    (define gerbil-ascent/program/types#+terms+
      (gerbil-ascent/program/types#slot-contract
       'ascent/terms
       (lambda (_%value5364%_)
         (if (list? _%value5364%_)
             (let ((__tmp35273
                    (lambda (_%term5366%_)
                      (let ()
                        (declare (not safe))
                        (clan/poo/mop#element?
                         gerbil-ascent/program/types#GerbilAscentTermContract
                         _%term5366%_)))))
               (declare (not safe))
               (andmap__0 __tmp35273 _%value5364%_))
             '#f))))
    (define gerbil-ascent/program/types#GerbilAscentAtomContract
      (let ((__obj35191
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35275
               (list (cons 'sexp
                           (let ((__tmp35276
                                  (lambda (_%@5298%_)
                                    'GerbilAscentAtomContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35276)))
                     (cons 'identity
                           (let ((__tmp35277
                                  (lambda (_%@5304%_) 'ascent/atom)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35277)))
                     (cons 'proto
                           (let ((__tmp35278
                                  (lambda (_%@5309%_)
                                    (let ((__obj35189
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35280 (list))
                                            (__tmp35279 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35280
                                         __tmp35279
                                         __obj35189))
                                      __obj35189))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35278)))
                     (cons 'responsibilities
                           (let ((__tmp35281
                                  (lambda (_%@5323%_)
                                    (let ((__obj35190
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35283
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp35284
                                                                (lambda (_%self5342%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'atom))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35284)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'relation
                                                         (let ((__tmp35285
                                                                (lambda (_%self5349%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35285)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'terms
                                                         (let ((__tmp35286
                                                                (lambda (_%self5354%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+terms+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35286)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp35287
                                                                (lambda (_%self5359%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35287)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35282 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35283
                                         __tmp35282
                                         __obj35190))
                                      __obj35190))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35281)))))
              (__tmp35274 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35275
           __tmp35274
           __obj35191))
        __obj35191))
    (define gerbil-ascent/program/types#+variables+
      (gerbil-ascent/program/types#slot-contract
       'ascent/variables
       (lambda (_%value5283%_)
         (if (list? _%value5283%_)
             (let () (declare (not safe)) (andmap__0 symbol? _%value5283%_))
             '#f))))
    (define gerbil-ascent/program/types#+generator-output+
      (gerbil-ascent/program/types#slot-contract
       'ascent/generator-output
       (lambda (_%value5270%_)
         (let ((_%$e5272%_ (symbol? _%value5270%_)))
           (if _%$e5272%_
               _%$e5272%_
               (if (pair? _%value5270%_)
                   (let _%loop5275%_ ((_%remaining5277%_ _%value5270%_)
                                      (_%seen5278%_ '()))
                     (let ((_%$e5280%_ (null? _%remaining5277%_)))
                       (if _%$e5280%_
                           _%$e5280%_
                           (if (symbol? (car _%remaining5277%_))
                               (if (memq (car _%remaining5277%_) _%seen5278%_)
                                   '#f
                                   (_%loop5275%_
                                    (cdr _%remaining5277%_)
                                    (cons (car _%remaining5277%_)
                                          _%seen5278%_)))
                               '#f))))
                   '#f))))))
    (define gerbil-ascent/program/types#+procedure+
      (gerbil-ascent/program/types#slot-contract 'ascent/procedure procedure?))
    (define gerbil-ascent/program/types#+optional-procedure+
      (gerbil-ascent/program/types#slot-contract
       'ascent/optional-procedure
       (lambda (_%value5265%_)
         (let ((_%$e5267%_ (not _%value5265%_)))
           (if _%$e5267%_ _%$e5267%_ (procedure? _%value5265%_))))))
    (define gerbil-ascent/program/types#+checked-operator+
      (gerbil-ascent/program/types#slot-contract
       'ascent/checked-operator
       (lambda (_%value5260%_)
         (let ((_%$e5262%_ (not _%value5260%_)))
           (if _%$e5262%_ _%$e5262%_ (vector? _%value5260%_))))))
    (define gerbil-ascent/program/types#GerbilAscentGuardContract
      (let ((__obj35194
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35289
               (list (cons 'sexp
                           (let ((__tmp35290
                                  (lambda (_%@5188%_)
                                    'GerbilAscentGuardContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35290)))
                     (cons 'identity
                           (let ((__tmp35291
                                  (lambda (_%@5194%_) 'ascent/guard)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35291)))
                     (cons 'proto
                           (let ((__tmp35292
                                  (lambda (_%@5199%_)
                                    (let ((__obj35192
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35294 (list))
                                            (__tmp35293 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35294
                                         __tmp35293
                                         __obj35192))
                                      __obj35192))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35292)))
                     (cons 'responsibilities
                           (let ((__tmp35295
                                  (lambda (_%@5213%_)
                                    (let ((__obj35193
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35297
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp35298
                                                                (lambda (_%self5233%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'guard))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35298)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variables
                                                         (let ((__tmp35299
                                                                (lambda (_%self5240%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+variables+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35299)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'predicate
                                                         (let ((__tmp35300
                                                                (lambda (_%self5245%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35300)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'checked-operator
                                                         (let ((__tmp35301
                                                                (lambda (_%self5250%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+checked-operator+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35301)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp35302
                                                                (lambda (_%self5255%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35302)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35296 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35297
                                         __tmp35296
                                         __obj35193))
                                      __obj35193))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35295)))))
              (__tmp35288 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35289
           __tmp35288
           __obj35194))
        __obj35194))
    (define gerbil-ascent/program/types#GerbilAscentGeneratorContract
      (let ((__obj35197
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35304
               (list (cons 'sexp
                           (let ((__tmp35305
                                  (lambda (_%@5103%_)
                                    'GerbilAscentGeneratorContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35305)))
                     (cons 'identity
                           (let ((__tmp35306
                                  (lambda (_%@5109%_) 'ascent/generator)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35306)))
                     (cons 'proto
                           (let ((__tmp35307
                                  (lambda (_%@5114%_)
                                    (let ((__obj35195
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35309 (list))
                                            (__tmp35308 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35309
                                         __tmp35308
                                         __obj35195))
                                      __obj35195))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35307)))
                     (cons 'responsibilities
                           (let ((__tmp35310
                                  (lambda (_%@5128%_)
                                    (let ((__obj35196
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35312
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp35313
                                                                (lambda (_%self5148%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'generator))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35313)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variable
                                                         (let ((__tmp35314
                                                                (lambda (_%self5155%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+generator-output+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35314)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variables
                                                         (let ((__tmp35315
                                                                (lambda (_%self5160%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+variables+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35315)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'generate
                                                         (let ((__tmp35316
                                                                (lambda (_%self5165%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35316)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp35317
                                                                (lambda (_%self5170%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35317)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35311 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35312
                                         __tmp35311
                                         __obj35196))
                                      __obj35196))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35310)))))
              (__tmp35303 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35304
           __tmp35303
           __obj35197))
        __obj35197))
    (define gerbil-ascent/program/types#GerbilAscentBindingContract
      (let ((__obj35200
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35319
               (list (cons 'sexp
                           (let ((__tmp35320
                                  (lambda (_%@5012%_)
                                    'GerbilAscentBindingContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35320)))
                     (cons 'identity
                           (let ((__tmp35321
                                  (lambda (_%@5018%_) 'ascent/binding)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35321)))
                     (cons 'proto
                           (let ((__tmp35322
                                  (lambda (_%@5023%_)
                                    (let ((__obj35198
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35324 (list))
                                            (__tmp35323 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35324
                                         __tmp35323
                                         __obj35198))
                                      __obj35198))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35322)))
                     (cons 'responsibilities
                           (let ((__tmp35325
                                  (lambda (_%@5037%_)
                                    (let ((__obj35199
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35327
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp35328
                                                                (lambda (_%self5058%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'binding))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35328)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variable
                                                         (let ((__tmp35329
                                                                (lambda (_%self5065%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35329)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variables
                                                         (let ((__tmp35330
                                                                (lambda (_%self5070%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+variables+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35330)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'checked-operator
                                                         (let ((__tmp35331
                                                                (lambda (_%self5075%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+checked-operator+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35331)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'compute
                                                         (let ((__tmp35332
                                                                (lambda (_%self5080%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35332)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp35333
                                                                (lambda (_%self5085%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35333)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35326 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35327
                                         __tmp35326
                                         __obj35199))
                                      __obj35199))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35325)))))
              (__tmp35318 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35319
           __tmp35318
           __obj35200))
        __obj35200))
    (define gerbil-ascent/program/types#GerbilAscentNegationContract
      (let ((__obj35203
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35335
               (list (cons 'sexp
                           (let ((__tmp35336
                                  (lambda (_%@4933%_)
                                    'GerbilAscentNegationContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35336)))
                     (cons 'identity
                           (let ((__tmp35337
                                  (lambda (_%@4939%_) 'ascent/negation)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35337)))
                     (cons 'proto
                           (let ((__tmp35338
                                  (lambda (_%@4944%_)
                                    (let ((__obj35201
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35340 (list))
                                            (__tmp35339 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35340
                                         __tmp35339
                                         __obj35201))
                                      __obj35201))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35338)))
                     (cons 'responsibilities
                           (let ((__tmp35341
                                  (lambda (_%@4958%_)
                                    (let ((__obj35202
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35343
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp35344
                                                                (lambda (_%self4977%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'negation))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35344)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'relation
                                                         (let ((__tmp35345
                                                                (lambda (_%self4984%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35345)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'terms
                                                         (let ((__tmp35346
                                                                (lambda (_%self4989%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+terms+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35346)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp35347
                                                                (lambda (_%self4994%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35347)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35342 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35343
                                         __tmp35342
                                         __obj35202))
                                      __obj35202))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35341)))))
              (__tmp35334 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35335
           __tmp35334
           __obj35203))
        __obj35203))
    (define gerbil-ascent/program/types#GerbilAscentAggregateContract
      (let ((__obj35206
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35349
               (list (cons 'sexp
                           (let ((__tmp35350
                                  (lambda (_%@4824%_)
                                    'GerbilAscentAggregateContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35350)))
                     (cons 'identity
                           (let ((__tmp35351
                                  (lambda (_%@4830%_) 'ascent/aggregate)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35351)))
                     (cons 'proto
                           (let ((__tmp35352
                                  (lambda (_%@4835%_)
                                    (let ((__obj35204
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35354 (list))
                                            (__tmp35353 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35354
                                         __tmp35353
                                         __obj35204))
                                      __obj35204))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35352)))
                     (cons 'responsibilities
                           (let ((__tmp35355
                                  (lambda (_%@4849%_)
                                    (let ((__obj35205
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35357
                                             (list (cons 'ascent-clause-kind
                                                         (let ((__tmp35358
                                                                (lambda (_%self4873%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (gerbil-ascent/program/types#clause-kind-contract
                           'aggregate))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35358)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variable
                                                         (let ((__tmp35359
                                                                (lambda (_%self4880%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+generator-output+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35359)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'relation
                                                         (let ((__tmp35360
                                                                (lambda (_%self4885%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+symbol+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35360)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'terms
                                                         (let ((__tmp35361
                                                                (lambda (_%self4890%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+terms+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35361)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'variables
                                                         (let ((__tmp35362
                                                                (lambda (_%self4895%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+variables+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35362)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'aggregate
                                                         (let ((__tmp35363
                                                                (lambda (_%self4900%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35363)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'checked-operator
                                                         (let ((__tmp35364
                                                                (lambda (_%self4905%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+checked-operator+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35364)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'output-pattern
                                                         (let ((__tmp35365
                                                                (lambda (_%self4910%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+optional-procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35365)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.plan
                                                         (let ((__tmp35366
                                                                (lambda (_%self4915%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+plan+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35366)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35356 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35357
                                         __tmp35356
                                         __obj35205))
                                      __obj35205))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35355)))))
              (__tmp35348 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35349
           __tmp35348
           __obj35206))
        __obj35206))
    (define gerbil-ascent/program/types#+clauses+
      (gerbil-ascent/program/types#slot-contract
       'ascent/clauses
       (lambda (_%value4792%_)
         (if (list? _%value4792%_)
             (let ((__tmp35367
                    (lambda (_%clause4794%_)
                      (let ((_%$e4796%_
                             (let ()
                               (declare (not safe))
                               (clan/poo/mop#element?
                                gerbil-ascent/program/types#GerbilAscentAtomContract
                                _%clause4794%_))))
                        (if _%$e4796%_
                            _%$e4796%_
                            (let ((_%$e4799%_
                                   (let ()
                                     (declare (not safe))
                                     (clan/poo/mop#element?
                                      gerbil-ascent/program/types#GerbilAscentGuardContract
                                      _%clause4794%_))))
                              (if _%$e4799%_
                                  _%$e4799%_
                                  (let ((_%$e4802%_
                                         (let ()
                                           (declare (not safe))
                                           (clan/poo/mop#element?
                                            gerbil-ascent/program/types#GerbilAscentGeneratorContract
                                            _%clause4794%_))))
                                    (if _%$e4802%_
                                        _%$e4802%_
                                        (let ((_%$e4805%_
                                               (let ()
                                                 (declare (not safe))
                                                 (clan/poo/mop#element?
                                                  gerbil-ascent/program/types#GerbilAscentBindingContract
                                                  _%clause4794%_))))
                                          (if _%$e4805%_
                                              _%$e4805%_
                                              (let ((_%$e4808%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (clan/poo/mop#element?
                                                        gerbil-ascent/program/types#GerbilAscentNegationContract
                                                        _%clause4794%_))))
                                                (if _%$e4808%_
                                                    _%$e4808%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (clan/poo/mop#element?
                                                       gerbil-ascent/program/types#GerbilAscentAggregateContract
                                                       _%clause4794%_)))))))))))))))
               (declare (not safe))
               (andmap__0 __tmp35367 _%value4792%_))
             '#f))))
    (define gerbil-ascent/program/types#+heads+
      (gerbil-ascent/program/types#slot-contract
       'ascent/heads
       (lambda (_%value4788%_)
         (if (pair? _%value4788%_)
             (let ((__tmp35368
                    (lambda (_%head4790%_)
                      (let ()
                        (declare (not safe))
                        (clan/poo/mop#element?
                         gerbil-ascent/program/types#GerbilAscentAtomContract
                         _%head4790%_)))))
               (declare (not safe))
               (andmap__0 __tmp35368 _%value4788%_))
             '#f))))
    (define gerbil-ascent/program/types#GerbilAscentRuleContract
      (let ((__obj35209
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35370
               (list (cons 'sexp
                           (let ((__tmp35371
                                  (lambda (_%@4734%_)
                                    'GerbilAscentRuleContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35371)))
                     (cons 'identity
                           (let ((__tmp35372
                                  (lambda (_%@4740%_) 'ascent/rule)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35372)))
                     (cons 'proto
                           (let ((__tmp35373
                                  (lambda (_%@4745%_)
                                    (let ((__obj35207
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35375 (list))
                                            (__tmp35374 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35375
                                         __tmp35374
                                         __obj35207))
                                      __obj35207))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35373)))
                     (cons 'responsibilities
                           (let ((__tmp35376
                                  (lambda (_%@4759%_)
                                    (let ((__obj35208
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35378
                                             (list (cons 'heads
                                                         (let ((__tmp35379
                                                                (lambda (_%self4776%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+heads+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35379)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'body
                                                         (let ((__tmp35380
                                                                (lambda (_%self4783%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+clauses+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35380)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35377 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35378
                                         __tmp35377
                                         __obj35208))
                                      __obj35208))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35376)))))
              (__tmp35369 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35370
           __tmp35369
           __obj35209))
        __obj35209))
    (define gerbil-ascent/program/types#+relations+
      (gerbil-ascent/program/types#slot-contract
       'ascent/relations
       (lambda (_%value4714%_)
         (if (list? _%value4714%_)
             (let ((__tmp35381
                    (lambda (_%relation4716%_)
                      (let ((_%$e4718%_
                             (let ()
                               (declare (not safe))
                               (clan/poo/mop#element?
                                gerbil-ascent/program/types#GerbilAscentRelationContract
                                _%relation4716%_))))
                        (if _%$e4718%_
                            _%$e4718%_
                            (let ()
                              (declare (not safe))
                              (clan/poo/mop#element?
                               gerbil-ascent/program/types#GerbilAscentLatticeContract
                               _%relation4716%_)))))))
               (declare (not safe))
               (andmap__0 __tmp35381 _%value4714%_))
             '#f))))
    (define gerbil-ascent/program/types#+rules+
      (gerbil-ascent/program/types#slot-contract
       'ascent/rules
       (lambda (_%value4710%_)
         (if (list? _%value4710%_)
             (let ((__tmp35382
                    (lambda (_%rule4712%_)
                      (let ()
                        (declare (not safe))
                        (clan/poo/mop#element?
                         gerbil-ascent/program/types#GerbilAscentRuleContract
                         _%rule4712%_)))))
               (declare (not safe))
               (andmap__0 __tmp35382 _%value4710%_))
             '#f))))
    (define gerbil-ascent/program/types#+fragment-exports+
      (gerbil-ascent/program/types#slot-contract
       'ascent/fragment-exports
       procedure?))
    (define gerbil-ascent/program/types#+source-handles+
      (gerbil-ascent/program/types#slot-contract
       'ascent/source-handles
       (lambda (_%value4708%_)
         (if (list? _%value4708%_)
             (let () (declare (not safe)) (andmap__0 symbol? _%value4708%_))
             '#f))))
    (define gerbil-ascent/program/types#GerbilAscentFragmentContract
      (let ((__obj35212
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35384
               (list (cons 'sexp
                           (let ((__tmp35385
                                  (lambda (_%@4642%_)
                                    'GerbilAscentFragmentContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35385)))
                     (cons 'identity
                           (let ((__tmp35386
                                  (lambda (_%@4648%_) 'ascent/fragment)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35386)))
                     (cons 'proto
                           (let ((__tmp35387
                                  (lambda (_%@4653%_)
                                    (let ((__obj35210
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35389 (list))
                                            (__tmp35388 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35389
                                         __tmp35388
                                         __obj35210))
                                      __obj35210))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35387)))
                     (cons 'responsibilities
                           (let ((__tmp35390
                                  (lambda (_%@4667%_)
                                    (let ((__obj35211
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35392
                                             (list (cons 'relations
                                                         (let ((__tmp35393
                                                                (lambda (_%self4686%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+relations+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35393)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'rules
                                                         (let ((__tmp35394
                                                                (lambda (_%self4693%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+rules+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35394)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'exports
                                                         (let ((__tmp35395
                                                                (lambda (_%self4698%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+fragment-exports+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35395)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'source-handles
                                                         (let ((__tmp35396
                                                                (lambda (_%self4703%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+source-handles+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35396)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35391 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35392
                                         __tmp35391
                                         __obj35211))
                                      __obj35211))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35390)))))
              (__tmp35383 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35384
           __tmp35383
           __obj35212))
        __obj35212))
    (define gerbil-ascent/program/types#GerbilAscentProgramContract
      (let ((__obj35215
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35398
               (list (cons 'sexp
                           (let ((__tmp35399
                                  (lambda (_%@4551%_)
                                    'GerbilAscentProgramContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35399)))
                     (cons 'identity
                           (let ((__tmp35400
                                  (lambda (_%@4557%_) 'ascent/program)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35400)))
                     (cons 'proto
                           (let ((__tmp35401
                                  (lambda (_%@4562%_)
                                    (let ((__obj35213
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35403 (list))
                                            (__tmp35402 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35403
                                         __tmp35402
                                         __obj35213))
                                      __obj35213))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35401)))
                     (cons 'responsibilities
                           (let ((__tmp35404
                                  (lambda (_%@4576%_)
                                    (let ((__obj35214
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35406
                                             (list (cons 'relations
                                                         (let ((__tmp35407
                                                                (lambda (_%self4597%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+relations+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35407)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'rules
                                                         (let ((__tmp35408
                                                                (lambda (_%self4604%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+rules+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35408)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'source-handles
                                                         (let ((__tmp35409
                                                                (lambda (_%self4609%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+source-handles+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35409)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'max-input-facts
                                                         (let ((__tmp35410
                                                                (lambda (_%self4614%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+fact-budget+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35410)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'max-derived-facts
                                                         (let ((__tmp35411
                                                                (lambda (_%self4619%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+fact-budget+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35411)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons 'max-output-facts
                                                         (let ((__tmp35412
                                                                (lambda (_%self4624%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+fact-budget+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35412)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35405 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35406
                                         __tmp35405
                                         __obj35214))
                                      __obj35214))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35404)))))
              (__tmp35397 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35398
           __tmp35397
           __obj35215))
        __obj35215))
    (define gerbil-ascent/program/types#gerbil-ascent-owned-root-contract
      (lambda (_%root4363%_)
        (let* ((_%accepted4365%_
                (let () (declare (not safe)) (make-hash-table-eq)))
               (_%owned-terms4374%_
                (gerbil-ascent/program/types#slot-contract
                 'ascent/terms
                 (lambda (_%value4367%_)
                   (if (list? _%value4367%_)
                       (let ((__tmp35413
                              (lambda (_%term4369%_)
                                (let ((_%$e4371%_
                                       (let ()
                                         (declare (not safe))
                                         (__hash-get
                                          _%accepted4365%_
                                          _%term4369%_))))
                                  (if _%$e4371%_
                                      _%$e4371%_
                                      (if (let ()
                                            (declare (not safe))
                                            (clan/poo/mop#element?
                                             gerbil-ascent/program/types#GerbilAscentTermContract
                                             _%term4369%_))
                                          (begin
                                            (let ()
                                              (declare (not safe))
                                              (__hash-put!
                                               _%accepted4365%_
                                               _%term4369%_
                                               '#t))
                                            '#t)
                                          '#f))))))
                         (declare (not safe))
                         (andmap__0 __tmp35413 _%value4367%_))
                       '#f))))
               (_%owned-atom4418%_
                (let ((__obj35217
                       (let ()
                         (declare (not safe))
                         (##structure
                          clan/poo/object#object::t
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f))))
                  (let ((__tmp35415
                         (list (cons 'proto
                                     (let ((__tmp35416
                                            (lambda (_%@4390%_)
                                              (let ()
                                                (declare (not safe))
                                                (clan/poo/object#.ref
                                                 gerbil-ascent/program/types#GerbilAscentAtomContract
                                                 'proto)))))
                                       (declare (not safe))
                                       (##structure
                                        clan/poo/object#$self-slot-spec::t
                                        __tmp35416)))
                               (cons 'responsibilities
                                     (let ((__tmp35417
                                            (lambda (_%@4396%_)
                                              (let ((__obj35216
                                                     (let ()
                                                       (declare (not safe))
                                                       (##structure
                                                        clan/poo/object#object::t
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f))))
                                                (let ((__tmp35421
                                                       (let ()
                                                         (declare (not safe))
                                                         (clan/poo/object#.ref
                                                          gerbil-ascent/program/types#GerbilAscentAtomContract
                                                          'responsibilities)))
                                                      (__tmp35419
                                                       (list (cons 'terms
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ((__tmp35420
                                  (lambda (_%@4412%_) _%owned-terms4374%_)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35420)))))
              (__tmp35418 (list)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (declare (not safe))
                                                  (clan/poo/object#object:::init!__%
                                                   '#f
                                                   __tmp35421
                                                   __tmp35419
                                                   __tmp35418
                                                   __obj35216))
                                                __obj35216))))
                                       (declare (not safe))
                                       (##structure
                                        clan/poo/object#$self-slot-spec::t
                                        __tmp35417)))))
                        (__tmp35414 (list)))
                    (declare (not safe))
                    (clan/poo/object#object:::init!__%
                     '#f
                     gerbil-ascent/program/types#GerbilAscentAtomContract
                     __tmp35415
                     __tmp35414
                     __obj35217))
                  __obj35217))
               (_%owned-heads4426%_
                (gerbil-ascent/program/types#slot-contract
                 'ascent/heads
                 (lambda (_%value4420%_)
                   (if (pair? _%value4420%_)
                       (let ((__tmp35422
                              (lambda (_%$%g44214423%_)
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/mop#element?
                                   _%owned-atom4418%_
                                   _%$%g44214423%_)))))
                         (declare (not safe))
                         (andmap__0 __tmp35422 _%value4420%_))
                       '#f))))
               (_%owned-body4435%_
                (gerbil-ascent/program/types#slot-contract
                 'ascent/clauses
                 (lambda (_%value4428%_)
                   (if (list? _%value4428%_)
                       (let ((__tmp35423
                              (lambda (_%clause4430%_)
                                (let ((_%$e4432%_
                                       (let ()
                                         (declare (not safe))
                                         (clan/poo/mop#element?
                                          _%owned-atom4418%_
                                          _%clause4430%_))))
                                  (if _%$e4432%_
                                      _%$e4432%_
                                      (let ((__tmp35424 (list _%clause4430%_)))
                                        (declare (not safe))
                                        (clan/poo/mop#element?
                                         gerbil-ascent/program/types#+clauses+
                                         __tmp35424)))))))
                         (declare (not safe))
                         (andmap__0 __tmp35423 _%value4428%_))
                       '#f))))
               (_%owned-rule4485%_
                (let ((__obj35219
                       (let ()
                         (declare (not safe))
                         (##structure
                          clan/poo/object#object::t
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f
                          '#f))))
                  (let ((__tmp35426
                         (list (cons 'proto
                                     (let ((__tmp35427
                                            (lambda (_%@4451%_)
                                              (let ()
                                                (declare (not safe))
                                                (clan/poo/object#.ref
                                                 gerbil-ascent/program/types#GerbilAscentRuleContract
                                                 'proto)))))
                                       (declare (not safe))
                                       (##structure
                                        clan/poo/object#$self-slot-spec::t
                                        __tmp35427)))
                               (cons 'responsibilities
                                     (let ((__tmp35428
                                            (lambda (_%@4457%_)
                                              (let ((__obj35218
                                                     (let ()
                                                       (declare (not safe))
                                                       (##structure
                                                        clan/poo/object#object::t
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f
                                                        '#f))))
                                                (let ((__tmp35433
                                                       (let ()
                                                         (declare (not safe))
                                                         (clan/poo/object#.ref
                                                          gerbil-ascent/program/types#GerbilAscentRuleContract
                                                          'responsibilities)))
                                                      (__tmp35430
                                                       (list (cons 'heads
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ((__tmp35431
                                  (lambda (_%@4474%_) _%owned-heads4426%_)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35431)))
                     (cons 'body
                           (let ((__tmp35432
                                  (lambda (_%@4480%_) _%owned-body4435%_)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35432)))))
              (__tmp35429 (list)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (declare (not safe))
                                                  (clan/poo/object#object:::init!__%
                                                   '#f
                                                   __tmp35433
                                                   __tmp35430
                                                   __tmp35429
                                                   __obj35218))
                                                __obj35218))))
                                       (declare (not safe))
                                       (##structure
                                        clan/poo/object#$self-slot-spec::t
                                        __tmp35428)))))
                        (__tmp35425 (list)))
                    (declare (not safe))
                    (clan/poo/object#object:::init!__%
                     '#f
                     gerbil-ascent/program/types#GerbilAscentRuleContract
                     __tmp35426
                     __tmp35425
                     __obj35219))
                  __obj35219))
               (_%owned-rules4493%_
                (gerbil-ascent/program/types#slot-contract
                 'ascent/rules
                 (lambda (_%value4487%_)
                   (if (list? _%value4487%_)
                       (let ((__tmp35434
                              (lambda (_%$%g44884490%_)
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/mop#element?
                                   _%owned-rule4485%_
                                   _%$%g44884490%_)))))
                         (declare (not safe))
                         (andmap__0 __tmp35434 _%value4487%_))
                       '#f))))
               (__obj35221
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
          (let ((__tmp35436
                 (list (cons 'proto
                             (let ((__tmp35437
                                    (lambda (_%@4510%_)
                                      (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%root4363%_
                                         'proto)))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp35437)))
                       (cons 'responsibilities
                             (let ((__tmp35438
                                    (lambda (_%@4516%_)
                                      (let ((__obj35220
                                             (let ()
                                               (declare (not safe))
                                               (##structure
                                                clan/poo/object#object::t
                                                '#f
                                                '#f
                                                '#f
                                                '#f
                                                '#f
                                                '#f
                                                '#f))))
                                        (let ((__tmp35442
                                               (let ()
                                                 (declare (not safe))
                                                 (clan/poo/object#.ref
                                                  _%root4363%_
                                                  'responsibilities)))
                                              (__tmp35440
                                               (list (cons 'rules
                                                           (let ((__tmp35441
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (lambda (_%@4532%_) _%owned-rules4493%_)))
                     (declare (not safe))
                     (##structure
                      clan/poo/object#$self-slot-spec::t
                      __tmp35441)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (__tmp35439 (list)))
                                          (declare (not safe))
                                          (clan/poo/object#object:::init!__%
                                           '#f
                                           __tmp35442
                                           __tmp35440
                                           __tmp35439
                                           __obj35220))
                                        __obj35220))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp35438)))))
                (__tmp35435 (list)))
            (declare (not safe))
            (clan/poo/object#object:::init!__%
             '#f
             _%root4363%_
             __tmp35436
             __tmp35435
             __obj35221))
          __obj35221)))
    (define gerbil-ascent/program/types#GerbilAscentSessionContract
      (let ((__obj35224
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35444
               (list (cons 'sexp
                           (let ((__tmp35445
                                  (lambda (_%@4303%_)
                                    'GerbilAscentSessionContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35445)))
                     (cons 'identity
                           (let ((__tmp35446
                                  (lambda (_%@4309%_) 'ascent/session)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35446)))
                     (cons 'proto
                           (let ((__tmp35447
                                  (lambda (_%@4314%_)
                                    (let ((__obj35222
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35449 (list))
                                            (__tmp35448 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35449
                                         __tmp35448
                                         __obj35222))
                                      __obj35222))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35447)))
                     (cons 'responsibilities
                           (let ((__tmp35450
                                  (lambda (_%@4328%_)
                                    (let ((__obj35223
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35452
                                             (list (cons '.append-source!
                                                         (let ((__tmp35453
                                                                (lambda (_%self4346%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35453)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.replace-source!
                                                         (let ((__tmp35454
                                                                (lambda (_%self4353%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35454)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.run
                                                         (let ((__tmp35455
                                                                (lambda (_%self4358%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/program/types#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35455)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35451 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35452
                                         __tmp35451
                                         __obj35223))
                                      __obj35223))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35450)))))
              (__tmp35443 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35444
           __tmp35443
           __obj35224))
        __obj35224))))
