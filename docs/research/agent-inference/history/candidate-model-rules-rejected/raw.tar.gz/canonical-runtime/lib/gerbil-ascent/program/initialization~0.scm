(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/initialization::timestamp 1791687880)
  (begin
    (define gerbil-ascent/program/initialization#initial-source-state::t
      (let ((__tmp35829 (list))
            (__tmp35828
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/initialization#initial-source-state::t
         'initial-source-state
         __tmp35829
         '(all delta all-size delta-size storage-states seen lattice-rows)
         __tmp35828
         '#f)))
    (define gerbil-ascent/program/initialization#initial-source-state?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/initialization#initial-source-state::t)))
    (define gerbil-ascent/program/initialization#make-initial-source-state
      (lambda _%$args16889%_
        (apply make-instance
               gerbil-ascent/program/initialization#initial-source-state::t
               _%$args16889%_)))
    (define gerbil-ascent/program/initialization#initial-source-state-all
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'all)))
    (define gerbil-ascent/program/initialization#initial-source-state-delta
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'delta)))
    (define gerbil-ascent/program/initialization#initial-source-state-all-size
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'all-size)))
    (define gerbil-ascent/program/initialization#initial-source-state-delta-size
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'delta-size)))
    (define gerbil-ascent/program/initialization#initial-source-state-storage-states
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'storage-states)))
    (define gerbil-ascent/program/initialization#initial-source-state-seen
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'seen)))
    (define gerbil-ascent/program/initialization#initial-source-state-lattice-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'lattice-rows)))
    (define gerbil-ascent/program/initialization#initial-source-state-all-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'all)))
    (define gerbil-ascent/program/initialization#initial-source-state-delta-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'delta)))
    (define gerbil-ascent/program/initialization#initial-source-state-all-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'all-size)))
    (define gerbil-ascent/program/initialization#initial-source-state-delta-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'delta-size)))
    (define gerbil-ascent/program/initialization#initial-source-state-storage-states-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'storage-states)))
    (define gerbil-ascent/program/initialization#initial-source-state-seen-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'seen)))
    (define gerbil-ascent/program/initialization#initial-source-state-lattice-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'lattice-rows)))
    (define gerbil-ascent/program/initialization#&initial-source-state-all
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'all)))
    (define gerbil-ascent/program/initialization#&initial-source-state-delta
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'delta)))
    (define gerbil-ascent/program/initialization#&initial-source-state-all-size
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'all-size)))
    (define gerbil-ascent/program/initialization#&initial-source-state-delta-size
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'delta-size)))
    (define gerbil-ascent/program/initialization#&initial-source-state-storage-states
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'storage-states)))
    (define gerbil-ascent/program/initialization#&initial-source-state-seen
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'seen)))
    (define gerbil-ascent/program/initialization#&initial-source-state-lattice-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'lattice-rows)))
    (define gerbil-ascent/program/initialization#&initial-source-state-all-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'all)))
    (define gerbil-ascent/program/initialization#&initial-source-state-delta-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'delta)))
    (define gerbil-ascent/program/initialization#&initial-source-state-all-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'all-size)))
    (define gerbil-ascent/program/initialization#&initial-source-state-delta-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'delta-size)))
    (define gerbil-ascent/program/initialization#&initial-source-state-storage-states-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'storage-states)))
    (define gerbil-ascent/program/initialization#&initial-source-state-seen-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'seen)))
    (define gerbil-ascent/program/initialization#&initial-source-state-lattice-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'lattice-rows)))
    (define gerbil-ascent/program/initialization#gerbil-ascent-initialize-sources!
      (lambda (_%relations16728%_
               _%schema16729%_
               _%buffers16730%_
               _%input-limit16731%_
               _%output-limit16732%_)
        (let ((_%buffers16734%_ _%buffers16730%_))
          (let ((_%names16741%_ (vector-ref _%schema16729%_ '1))
                (_%arity16742%_ (vector-ref _%schema16729%_ '2))
                (_%field-checkers16743%_ (vector-ref _%schema16729%_ '3))
                (_%storage-extensions16744%_ (vector-ref _%schema16729%_ '6))
                (_%lattice-joins16745%_ (vector-ref _%schema16729%_ '7))
                (_%kinds16746%_ (vector-ref _%schema16729%_ '8))
                (_%storage-providers16747%_ (vector-ref _%schema16729%_ '9))
                (_%all16748%_
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%buffers16734%_ '1 '#f '#f)))
                (_%delta16749%_
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%buffers16734%_ '2 '#f '#f)))
                (_%all-size16750%_
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%buffers16734%_ '3 '#f '#f)))
                (_%delta-size16751%_
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%buffers16734%_ '4 '#f '#f)))
                (_%storage-states16752%_
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%buffers16734%_ '5 '#f '#f)))
                (_%seen16753%_
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%buffers16734%_ '6 '#f '#f)))
                (_%lattice-rows16754%_
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%buffers16734%_ '7 '#f '#f)))
                (_%source-count16755%_ '0)
                (_%source-materialized-count16756%_ '0))
            (let ((_%index16758%_ '0))
              (for-each
               (lambda (_%relation16760%_)
                 (let* ((_%name16762%_
                         (vector-ref _%names16741%_ _%index16758%_))
                        (_%width16764%_
                         (vector-ref _%arity16742%_ _%index16758%_))
                        (_%rows16766%_
                         (let ()
                           (declare (not safe))
                           (clan/poo/object#.ref _%relation16760%_ 'rows)))
                        (_%kind16768%_
                         (vector-ref _%kinds16746%_ _%index16758%_))
                        (_%check16770%_
                         (vector-ref _%field-checkers16743%_ _%index16758%_))
                        (_%provider16772%_
                         (vector-ref
                          _%storage-providers16747%_
                          _%index16758%_))
                        (_%set-storage?16774%_
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                            _%provider16772%_)))
                        (_%native-set?16776%_
                         (if (eq? _%kind16768%_ 'relation)
                             (if _%set-storage?16774%_
                                 (not _%check16770%_)
                                 '#f)
                             '#f))
                        (_%check-source!16783%_
                         (if _%native-set?16776%_
                             '#f
                             (lambda (_%row16778%_)
                               (if (and (list? _%row16778%_)
                                        (= (let ()
                                             (declare (not safe))
                                             (##length _%row16778%_))
                                           _%width16764%_))
                                   '#!void
                                   (let ()
                                     (declare (not safe))
                                     (error '"invalid ASCENT relation row"
                                            _%name16762%_
                                            _%row16778%_)))
                               (if _%check16770%_
                                   (_%check16770%_ _%row16778%_)
                                   '#!void)
                               (set! _%source-count16755%_
                                     (+ _%source-count16755%_ '1))
                               (if (or (> _%source-count16755%_
                                          _%input-limit16731%_)
                                       (> _%source-count16755%_
                                          _%output-limit16732%_))
                                   (let ()
                                     (declare (not safe))
                                     (error '"ASCENT source fact budget exceeded"))
                                   '#!void))))
                        (_%native-view?16785%_
                         (if (let ()
                               (declare (not safe))
                               (gerbil-ascent/table/storage#gerbil-ascent-canonical-view-storage-provider?
                                _%provider16772%_))
                             (let ((__tmp35830
                                    (vector-ref
                                     (vector-ref _%schema16729%_ '5)
                                     _%index16758%_)))
                               (declare (not safe))
                               (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                                __tmp35830))
                             '#f))
                        (_%present16787%_
                         (let ()
                           (declare (not safe))
                           (make-hash-table__%
                            '#f
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value)))
                        (_%frontier16789%_ '#f))
                   (if (list? _%rows16766%_)
                       '#!void
                       (let ()
                         (declare (not safe))
                         (error '"invalid ASCENT relation rows"
                                _%name16762%_
                                _%rows16766%_)))
                   (if (eq? _%kind16768%_ 'lattice)
                       (vector-set!
                        _%lattice-rows16754%_
                        _%index16758%_
                        (let ()
                          (declare (not safe))
                          (make-hash-table__%
                           '#f
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value)))
                       '#!void)
                   (if (eq? _%kind16768%_ 'relation)
                       (vector-set!
                        _%storage-states16752%_
                        _%index16758%_
                        (let ((__tmp35831
                               (vector-ref
                                _%storage-providers16747%_
                                _%index16758%_)))
                          (declare (not safe))
                          (gerbil-ascent/table/storage#gerbil-ascent-storage-engine-state
                           __tmp35831)))
                       '#!void)
                   (if (eq? _%kind16768%_ 'lattice)
                       (for-each
                        (lambda (_%row16793%_)
                          (_%check-source!16783%_ _%row16793%_)
                          (let* ((_%key16795%_
                                  (let ()
                                    (declare (not safe))
                                    (gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-key
                                     _%row16793%_)))
                                 (_%keyed16797%_
                                  (vector-ref
                                   _%lattice-rows16754%_
                                   _%index16758%_))
                                 (_%previous16799%_
                                  (let ()
                                    (declare (not safe))
                                    (hash-get _%keyed16797%_ _%key16795%_)))
                                 (_%merged16801%_
                                  (if _%previous16799%_
                                      (let ((__tmp35832
                                             ((vector-ref
                                               _%lattice-joins16745%_
                                               _%index16758%_)
                                              (last _%previous16799%_)
                                              (last _%row16793%_))))
                                        (declare (not safe))
                                        (gerbil-ascent/core/rule-semantics#gerbil-ascent-joined-row
                                         _%key16795%_
                                         __tmp35832))
                                      _%row16793%_)))
                            (if _%check16770%_
                                (_%check16770%_ _%merged16801%_)
                                '#!void)
                            (let ()
                              (declare (not safe))
                              (hash-put!
                               _%keyed16797%_
                               _%key16795%_
                               _%merged16801%_))
                            (if _%previous16799%_
                                '#!void
                                (set! _%source-materialized-count16756%_
                                      (+ _%source-materialized-count16756%_
                                         '1)))
                            (if _%frontier16789%_
                                '#!void
                                (set! _%frontier16789%_
                                      (let ()
                                        (declare (not safe))
                                        (gerbil-ascent/program/lattice-frontier#make-lattice-frontier))))
                            (let* ((_%frontier16804%_ _%frontier16789%_)
                                   (_%key16807%_ _%key16795%_)
                                   (_%row16810%_ _%merged16801%_)
                                   (_%frontier16814%_ _%frontier16804%_))
                              (declare (not safe))
                              (gerbil-ascent/program/lattice-frontier#__lattice-frontier-stage!
                               _%frontier16814%_
                               _%key16807%_
                               _%row16810%_))))
                        _%rows16766%_)
                       (if _%native-view?16785%_
                           (for-each
                            (lambda (_%row16851%_)
                              (_%check-source!16783%_ _%row16851%_)
                              (let ((_%frontier16853%_
                                     (let ((__tmp35834
                                            (vector-ref
                                             _%storage-states16752%_
                                             _%index16758%_))
                                           (__tmp35833
                                            (- _%output-limit16732%_
                                               _%source-materialized-count16756%_)))
                                       (declare (not safe))
                                       (gerbil-ascent/table/storage#gerbil-ascent-storage-view-extension!
                                        __tmp35834
                                        _%row16851%_
                                        __tmp35833))))
                                (if _%check16770%_
                                    (let ()
                                      (declare (not safe))
                                      (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
                                       _%check16770%_
                                       _%frontier16853%_))
                                    '#!void)
                                (set! _%source-materialized-count16756%_
                                      (+ _%source-materialized-count16756%_
                                         (let ()
                                           (declare (not safe))
                                           (gerbil-ascent/core/relation-view#gerbil-ascent-row-count
                                            _%frontier16853%_))))
                                (let ((__tmp35835
                                       (vector-ref
                                        _%storage-states16752%_
                                        _%index16758%_)))
                                  (declare (not safe))
                                  (gerbil-ascent/table/storage#gerbil-ascent-storage-admit-state!
                                   __tmp35835))))
                            _%rows16766%_)
                           (if _%set-storage?16774%_
                               (if _%check16770%_
                                   (for-each
                                    (lambda (_%row16856%_)
                                      (_%check-source!16783%_ _%row16856%_)
                                      (set! _%source-materialized-count16756%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/program/admission#gerbil-ascent-initialize-source-row!
                                               _%row16856%_
                                               _%width16764%_
                                               _%check16770%_
                                               _%present16787%_
                                               _%all16748%_
                                               _%index16758%_
                                               _%source-materialized-count16756%_
                                               _%output-limit16732%_))))
                                    _%rows16766%_)
                                   (let ((_%accepted16858%_
                                          (vector-ref
                                           _%all16748%_
                                           _%index16758%_)))
                                     (set! _%source-count16755%_
                                           (let ((__tmp35836
                                                  (lambda (_%row16860%_
                                                           _%source-count16861%_)
                                                    (if (and (list? _%row16860%_)
                                                             (= (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##length _%row16860%_))
                        _%width16764%_))
                '#!void
                (let ()
                  (declare (not safe))
                  (error '"invalid ASCENT relation row"
                         _%name16762%_
                         _%row16860%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (let ((_%next-count16863%_
                                                           (+ _%source-count16861%_
                                                              '1)))
                                                      (if (or (> _%next-count16863%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%input-limit16731%_)
                      (> _%next-count16863%_ _%output-limit16732%_))
                  (let ()
                    (declare (not safe))
                    (error '"ASCENT source fact budget exceeded"))
                  '#!void)
              (let ()
                (declare (not safe))
                (__hash-put! _%present16787%_ _%row16860%_ '#t))
              (set! _%source-materialized-count16756%_
                    (+ _%source-materialized-count16756%_ '1))
              (if (> _%source-materialized-count16756%_ _%output-limit16732%_)
                  (let ()
                    (declare (not safe))
                    (error '"ASCENT source fact budget exceeded"))
                  '#!void)
              (set! _%accepted16858%_ (cons _%row16860%_ _%accepted16858%_))
              _%next-count16863%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (declare (not safe))
                                             (foldl__0
                                              __tmp35836
                                              _%source-count16755%_
                                              _%rows16766%_)))
                                     (vector-set!
                                      _%all16748%_
                                      _%index16758%_
                                      _%accepted16858%_)))
                               (for-each
                                (lambda (_%row16870%_)
                                  (_%check-source!16783%_ _%row16870%_)
                                  (let ((_%materialized16872%_
                                         ((vector-ref
                                           _%storage-extensions16744%_
                                           _%index16758%_)
                                          (vector-ref
                                           _%storage-states16752%_
                                           _%index16758%_)
                                          (vector-ref
                                           _%all16748%_
                                           _%index16758%_)
                                          '()
                                          _%row16870%_
                                          (- _%output-limit16732%_
                                             _%source-materialized-count16756%_))))
                                    (if (list? _%materialized16872%_)
                                        '#!void
                                        (let ()
                                          (declare (not safe))
                                          (error '"ASCENT storage provider returned non-list rows")))
                                    (for-each
                                     (lambda (_%stored16874%_)
                                       (set! _%source-materialized-count16756%_
                                             (let ()
                                               (declare (not safe))
                                               (gerbil-ascent/program/admission#gerbil-ascent-initialize-source-row!
                                                _%stored16874%_
                                                _%width16764%_
                                                _%check16770%_
                                                _%present16787%_
                                                _%all16748%_
                                                _%index16758%_
                                                _%source-materialized-count16756%_
                                                _%output-limit16732%_))))
                                     _%materialized16872%_)
                                    (let ((__tmp35837
                                           (vector-ref
                                            _%storage-states16752%_
                                            _%index16758%_)))
                                      (declare (not safe))
                                      (gerbil-ascent/table/storage#gerbil-ascent-storage-admit-state!
                                       __tmp35837))))
                                _%rows16766%_))))
                   (if _%native-view?16785%_
                       (vector-set!
                        _%all16748%_
                        _%index16758%_
                        (let ((__tmp35838
                               (vector-ref
                                _%storage-states16752%_
                                _%index16758%_)))
                          (declare (not safe))
                          (gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__%
                           __tmp35838
                           '#f)))
                       '#!void)
                   (if (eq? _%kind16768%_ 'lattice)
                       (vector-set!
                        _%all16748%_
                        _%index16758%_
                        (if _%frontier16789%_
                            (let* ((_%frontier16876%_ _%frontier16789%_)
                                   (_%frontier16880%_ _%frontier16876%_))
                              (declare (not safe))
                              (gerbil-ascent/program/lattice-frontier#__lattice-frontier-rows
                               _%frontier16880%_))
                            '()))
                       '#!void)
                   (vector-set! _%seen16753%_ _%index16758%_ _%present16787%_)
                   (vector-set!
                    _%delta16749%_
                    _%index16758%_
                    (vector-ref _%all16748%_ _%index16758%_))
                   (vector-set!
                    _%all-size16750%_
                    _%index16758%_
                    (let ((__tmp35839
                           (vector-ref _%all16748%_ _%index16758%_)))
                      (declare (not safe))
                      (gerbil-ascent/core/relation-view#gerbil-ascent-row-count
                       __tmp35839)))
                   (vector-set!
                    _%delta-size16751%_
                    _%index16758%_
                    (vector-ref _%all-size16750%_ _%index16758%_))
                   (set! _%index16758%_ (+ _%index16758%_ '1))))
               _%relations16728%_))
            (values _%source-count16755%_
                    _%source-materialized-count16756%_)))))))
