(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/provenance::timestamp 1791692691)
  (begin
    (define gerbil-ascent/candidate/provenance#positive-proof::t
      (let ((__tmp33901 (list)) (__tmp33900 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/provenance#positive-proof::t
         'positive-proof
         __tmp33901
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  query
                  work-budget
                  nodes
                  roots)
         __tmp33900
         '#f)))
    (define gerbil-ascent/candidate/provenance#positive-proof?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/provenance#positive-proof::t)))
    (define gerbil-ascent/candidate/provenance#make-positive-proof
      (lambda _%$args29697%_
        (apply make-instance
               gerbil-ascent/candidate/provenance#positive-proof::t
               _%$args29697%_)))
    (define gerbil-ascent/candidate/provenance#positive-proof-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'status)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/provenance#positive-proof-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/provenance#positive-proof-query
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'query)))
    (define gerbil-ascent/candidate/provenance#positive-proof-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'work-budget)))
    (define gerbil-ascent/candidate/provenance#positive-proof-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#positive-proof-roots
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'roots)))
    (define gerbil-ascent/candidate/provenance#positive-proof-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'status)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/provenance#positive-proof-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/provenance#positive-proof-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'query)))
    (define gerbil-ascent/candidate/provenance#positive-proof-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'work-budget)))
    (define gerbil-ascent/candidate/provenance#positive-proof-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#positive-proof-roots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'roots)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'status)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-query
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'query)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'work-budget)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-roots
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'roots)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'status)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'query)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'work-budget)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-roots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'roots)))
    (define gerbil-ascent/candidate/provenance#proof-node::t
      (let ((__tmp33903 (list)) (__tmp33902 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/provenance#proof-node::t
         'proof-node
         __tmp33903
         '(id kind relation row label inputs)
         __tmp33902
         '#f)))
    (define gerbil-ascent/candidate/provenance#proof-node?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/provenance#proof-node::t)))
    (define gerbil-ascent/candidate/provenance#make-proof-node
      (lambda _%$args29694%_
        (apply make-instance
               gerbil-ascent/candidate/provenance#proof-node::t
               _%$args29694%_)))
    (define gerbil-ascent/candidate/provenance#proof-node-id
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'id)))
    (define gerbil-ascent/candidate/provenance#proof-node-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'kind)))
    (define gerbil-ascent/candidate/provenance#proof-node-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#proof-node-row
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'row)))
    (define gerbil-ascent/candidate/provenance#proof-node-label
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'label)))
    (define gerbil-ascent/candidate/provenance#proof-node-inputs
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'inputs)))
    (define gerbil-ascent/candidate/provenance#proof-node-id-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'id)))
    (define gerbil-ascent/candidate/provenance#proof-node-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'kind)))
    (define gerbil-ascent/candidate/provenance#proof-node-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#proof-node-row-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'row)))
    (define gerbil-ascent/candidate/provenance#proof-node-label-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'label)))
    (define gerbil-ascent/candidate/provenance#proof-node-inputs-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'inputs)))
    (define gerbil-ascent/candidate/provenance#&proof-node-id
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'id)))
    (define gerbil-ascent/candidate/provenance#&proof-node-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'kind)))
    (define gerbil-ascent/candidate/provenance#&proof-node-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#&proof-node-row
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'row)))
    (define gerbil-ascent/candidate/provenance#&proof-node-label
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'label)))
    (define gerbil-ascent/candidate/provenance#&proof-node-inputs
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'inputs)))
    (define gerbil-ascent/candidate/provenance#&proof-node-id-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'id)))
    (define gerbil-ascent/candidate/provenance#&proof-node-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'kind)))
    (define gerbil-ascent/candidate/provenance#&proof-node-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#&proof-node-row-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'row)))
    (define gerbil-ascent/candidate/provenance#&proof-node-label-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'label)))
    (define gerbil-ascent/candidate/provenance#&proof-node-inputs-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'inputs)))
    (define gerbil-ascent/candidate/provenance#proof-relation::t
      (let ((__tmp33905 (list)) (__tmp33904 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/provenance#proof-relation::t
         'proof-relation
         __tmp33905
         '(nodes tail members)
         __tmp33904
         '#f)))
    (define gerbil-ascent/candidate/provenance#proof-relation?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/provenance#proof-relation::t)))
    (define gerbil-ascent/candidate/provenance#make-proof-relation
      (lambda _%$args29691%_
        (apply make-instance
               gerbil-ascent/candidate/provenance#proof-relation::t
               _%$args29691%_)))
    (define gerbil-ascent/candidate/provenance#proof-relation-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#proof-relation-tail
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'tail)))
    (define gerbil-ascent/candidate/provenance#proof-relation-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'members)))
    (define gerbil-ascent/candidate/provenance#proof-relation-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#proof-relation-tail-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'tail)))
    (define gerbil-ascent/candidate/provenance#proof-relation-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'members)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-tail
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'tail)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'members)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-tail-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'tail)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'members)))
    (define gerbil-ascent/candidate/provenance#positive-atom?
      (lambda (_%atom29689%_)
        (if (pair? _%atom29689%_)
            (if (symbol? (let () (declare (not safe)) (##car _%atom29689%_)))
                (not (let ((__tmp33906
                            (let ()
                              (declare (not safe))
                              (##car _%atom29689%_))))
                       (declare (not safe))
                       (##memq __tmp33906 '(not where compute reduce))))
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/provenance#positive-fixed-clause?
      (lambda (_%clause29678%_)
        (if (list? _%clause29678%_)
            (if (pair? _%clause29678%_)
                (let ((_%$e29680%_
                       (let () (declare (not safe)) (##car _%clause29678%_))))
                  (if (eq? 'where _%$e29680%_)
                      (if (= (let ()
                               (declare (not safe))
                               (##length _%clause29678%_))
                             '2)
                          (if (list? (cadr _%clause29678%_))
                              (if (pair? (cadr _%clause29678%_))
                                  (let ((_%$e29683%_ (caadr _%clause29678%_)))
                                    (if (eq? 'even? _%$e29683%_)
                                        (= (length (cadr _%clause29678%_)) '2)
                                        (if (eq? '< _%$e29683%_)
                                            (= (length (cadr _%clause29678%_))
                                               '3)
                                            '#f)))
                                  '#f)
                              '#f)
                          '#f)
                      (if (eq? 'compute _%$e29680%_)
                          (if (= (let ()
                                   (declare (not safe))
                                   (##length _%clause29678%_))
                                 '3)
                              (if (let ((__tmp33907 (cadr _%clause29678%_)))
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/program#candidate-variable?
                                     __tmp33907))
                                  (if (list? (caddr _%clause29678%_))
                                      (if (pair? (caddr _%clause29678%_))
                                          (let ((_%$e29686%_
                                                 (caaddr _%clause29678%_)))
                                            (if (eq? 'identity _%$e29686%_)
                                                (= (length (caddr _%clause29678%_))
                                                   '2)
                                                (if (eq? '+ _%$e29686%_)
                                                    (= (length (caddr _%clause29678%_))
                                                       '3)
                                                    '#f)))
                                          '#f)
                                      '#f)
                                  '#f)
                              '#f)
                          '#f)))
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/provenance#positive-rule-body?
      (lambda (_%rule29671%_)
        (let ((__tmp33909
               (lambda (_%clause29673%_)
                 (let ((_%$e29675%_
                        (gerbil-ascent/candidate/provenance#positive-atom?
                         _%clause29673%_)))
                   (if _%$e29675%_
                       _%$e29675%_
                       (gerbil-ascent/candidate/provenance#positive-fixed-clause?
                        _%clause29673%_)))))
              (__tmp33908 (vector-ref _%rule29671%_ '1)))
          (declare (not safe))
          (andmap__0 __tmp33909 __tmp33908))))
    (define gerbil-ascent/candidate/provenance#positive-rules?
      (lambda (_%spec29669%_)
        (let ((__tmp33910
               (##structure-ref
                _%spec29669%_
                '3
                gerbil-ascent/candidate/types#reasoning-candidate::t
                '#f)))
          (declare (not safe))
          (andmap__0
           gerbil-ascent/candidate/provenance#positive-rule-body?
           __tmp33910))))
    (define gerbil-ascent/candidate/provenance#candidate-positive-proof/option
      (lambda (_%snapshot29493%_
               _%spec29494%_
               _%candidate-digest29495%_
               _%native-status29496%_
               _%native-rows29497%_
               _%max-steps29498%_
               _%retain-closed-absence?29499%_)
        (if (and (exact-integer? _%max-steps29498%_) (> _%max-steps29498%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid positive proof work budget"
                     _%max-steps29498%_)))
        (let ((_%query29501%_
               (vector-ref
                (##structure-ref
                 _%spec29494%_
                 '4
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f)
                '0)))
          (letrec ((_%result29503%_
                    (lambda (_%status29665%_ _%nodes29666%_ _%roots29667%_)
                      (let ((__tmp33914
                             (##structure-ref
                              _%snapshot29493%_
                              '1
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp33913
                             (##structure-ref
                              _%snapshot29493%_
                              '2
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp33912
                             (##structure-ref
                              _%snapshot29493%_
                              '3
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp33911
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                _%query29501%_))))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/provenance#positive-proof::t
                         _%status29665%_
                         __tmp33914
                         __tmp33913
                         __tmp33912
                         _%candidate-digest29495%_
                         __tmp33911
                         _%max-steps29498%_
                         _%nodes29666%_
                         _%roots29667%_)))))
            (if (or (not (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                            _%snapshot29493%_)))
                    (not (eq? _%native-status29496%_ 'complete))
                    (not (gerbil-ascent/candidate/provenance#positive-rules?
                          _%spec29494%_)))
                (_%result29503%_ 'unsupported '() '())
                (let ((_%index29511%_
                       (let ()
                         (declare (not safe))
                         (make-hash-table__%
                          '#f
                          absent-value
                          absent-value
                          absent-value
                          absent-value
                          absent-value
                          absent-value
                          absent-value
                          absent-value)))
                      (_%plans29512%_
                       (map gerbil-ascent/candidate/grounding-plan#prepare-grounding-rule
                            (##structure-ref
                             _%spec29494%_
                             '3
                             gerbil-ascent/candidate/types#reasoning-candidate::t
                             '#f)))
                      (_%query-match29513%_
                       (let ()
                         (declare (not safe))
                         (gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
                          _%query29501%_)))
                      (_%nodes29514%_ '())
                      (_%next-id29515%_ '0)
                      (_%derived-count29516%_ '0)
                      (_%steps29517%_ '0)
                      (_%material29518%_
                       (if _%retain-closed-absence?29499%_
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/candidate/certificate-limits#make-certificate-material-budget))
                           '#f))
                      (_%bounded?29519%_ '#f)
                      (_%derived-limit29520%_
                       (cadr (##structure-ref
                              _%spec29494%_
                              '5
                              gerbil-ascent/candidate/types#reasoning-candidate::t
                              '#f))))
                  (letrec ((_%facts29522%_
                            (lambda (_%name29661%_)
                              (let ((_%relation29663%_
                                     (let ()
                                       (declare (not safe))
                                       (__hash-get
                                        _%index29511%_
                                        _%name29661%_))))
                                (if _%relation29663%_
                                    (##structure-ref
                                     _%relation29663%_
                                     '1
                                     gerbil-ascent/candidate/provenance#proof-relation::t
                                     '#f)
                                    '()))))
                           (_%active?29523%_
                            (lambda () (not _%bounded?29519%_)))
                           (_%known?29524%_
                            (lambda (_%name29655%_ _%row29656%_)
                              (let ((_%relation29658%_
                                     (let ()
                                       (declare (not safe))
                                       (__hash-get
                                        _%index29511%_
                                        _%name29655%_))))
                                (if _%relation29658%_
                                    (let ((__tmp33915
                                           (##structure-ref
                                            _%relation29658%_
                                            '3
                                            gerbil-ascent/candidate/provenance#proof-relation::t
                                            '#f)))
                                      (declare (not safe))
                                      (hash-get __tmp33915 _%row29656%_))
                                    '#f))))
                           (_%reserve-row!29525%_
                            (lambda (_%row29647%_)
                              (let ((_%$e29649%_ (not _%material29518%_)))
                                (if _%$e29649%_
                                    _%$e29649%_
                                    (let ((_%$e29652%_
                                           (let ()
                                             (declare (not safe))
                                             (gerbil-ascent/candidate/certificate-limits#certificate-material-reserve!
                                              _%material29518%_
                                              _%row29647%_))))
                                      (if _%$e29652%_
                                          _%$e29652%_
                                          (begin
                                            (set! _%bounded?29519%_ '#t)
                                            '#f)))))))
                           (_%install!29526%_
                            (lambda (_%node29633%_)
                              (let* ((_%name29635%_
                                      (##structure-ref
                                       _%node29633%_
                                       '3
                                       gerbil-ascent/candidate/provenance#proof-node::t
                                       '#f))
                                     (_%relation29642%_
                                      (let ((_%$e29637%_
                                             (let ()
                                               (declare (not safe))
                                               (__hash-get
                                                _%index29511%_
                                                _%name29635%_))))
                                        (if _%$e29637%_
                                            _%$e29637%_
                                            (let ((_%owned29640%_
                                                   (let ((__tmp33916
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (make-hash-table__%
                                                             '#f
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value))))
                                                     (declare (not safe))
                                                     (##structure
                                                      gerbil-ascent/candidate/provenance#proof-relation::t
                                                      '()
                                                      '#f
                                                      __tmp33916))))
                                              (let ()
                                                (declare (not safe))
                                                (__hash-put!
                                                 _%index29511%_
                                                 _%name29635%_
                                                 _%owned29640%_))
                                              _%owned29640%_))))
                                     (_%cell29644%_ (list _%node29633%_)))
                                (if (##structure-ref
                                     _%relation29642%_
                                     '2
                                     gerbil-ascent/candidate/provenance#proof-relation::t
                                     '#f)
                                    (set-cdr!
                                     (##structure-ref
                                      _%relation29642%_
                                      '2
                                      gerbil-ascent/candidate/provenance#proof-relation::t
                                      '#f)
                                     _%cell29644%_)
                                    (##structure-set!
                                     _%relation29642%_
                                     _%cell29644%_
                                     '1
                                     gerbil-ascent/candidate/provenance#proof-relation::t
                                     '#f))
                                (##structure-set!
                                 _%relation29642%_
                                 _%cell29644%_
                                 '2
                                 gerbil-ascent/candidate/provenance#proof-relation::t
                                 '#f)
                                (let ((__tmp33918
                                       (##structure-ref
                                        _%relation29642%_
                                        '3
                                        gerbil-ascent/candidate/provenance#proof-relation::t
                                        '#f))
                                      (__tmp33917
                                       (##structure-ref
                                        _%node29633%_
                                        '4
                                        gerbil-ascent/candidate/provenance#proof-node::t
                                        '#f)))
                                  (declare (not safe))
                                  (hash-put!
                                   __tmp33918
                                   __tmp33917
                                   _%node29633%_))
                                (set! _%nodes29514%_
                                      (cons _%node29633%_ _%nodes29514%_)))))
                           (_%add!29527%_
                            (lambda (_%kind29625%_
                                     _%name29626%_
                                     _%row29627%_
                                     _%label29628%_
                                     _%inputs29629%_)
                              (if (if _%bounded?29519%_
                                      '#f
                                      (if (_%known?29524%_
                                           _%name29626%_
                                           _%row29627%_)
                                          '#f
                                          (_%reserve-row!29525%_
                                           _%row29627%_)))
                                  (let ((_%node29631%_
                                         (let ((__tmp33920
                                                (let ()
                                                  (declare (not safe))
                                                  (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                                   _%row29627%_)))
                                               (__tmp33919
                                                (let ()
                                                  (declare (not safe))
                                                  (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                                   _%inputs29629%_))))
                                           (declare (not safe))
                                           (##structure
                                            gerbil-ascent/candidate/provenance#proof-node::t
                                            _%next-id29515%_
                                            _%kind29625%_
                                            _%name29626%_
                                            __tmp33920
                                            _%label29628%_
                                            __tmp33919))))
                                    (set! _%next-id29515%_
                                          (+ _%next-id29515%_ '1))
                                    (_%install!29526%_ _%node29631%_))
                                  '#!void))))
                    (let ((__tmp33922
                           (lambda (_%entry29529%_)
                             (let ((_%position29531%_ '0))
                               (let ((__tmp33924
                                      (lambda (_%row29533%_)
                                        (set! _%position29531%_
                                              (+ _%position29531%_ '1))
                                        (_%add!29527%_
                                         'source
                                         (car _%entry29529%_)
                                         _%row29533%_
                                         _%position29531%_
                                         '())))
                                     (__tmp33923 (caddr _%entry29529%_)))
                                 (declare (not safe))
                                 (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                                  _%active?29523%_
                                  __tmp33924
                                  __tmp33923)))))
                          (__tmp33921
                           (##structure-ref
                            _%snapshot29493%_
                            '4
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f)))
                      (declare (not safe))
                      (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                       _%active?29523%_
                       __tmp33922
                       __tmp33921))
                    (let ((__tmp33926
                           (lambda (_%fact29535%_)
                             (_%add!29527%_
                              'candidate
                              (vector-ref _%fact29535%_ '0)
                              (vector-ref _%fact29535%_ '1)
                              (vector-ref _%fact29535%_ '2)
                              '())))
                          (__tmp33925
                           (##structure-ref
                            _%spec29494%_
                            '2
                            gerbil-ascent/candidate/types#reasoning-candidate::t
                            '#f)))
                      (declare (not safe))
                      (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                       _%active?29523%_
                       __tmp33926
                       __tmp33925))
                    (let _%saturate29537%_ ()
                      (let ((_%pending29540%_ '())
                            (_%pending-count29541%_ '0)
                            (_%pending-index29542%_ '#f))
                        (let ((__tmp33927
                               (lambda (_%rule29544%_)
                                 (let ((_%rule29547%_ _%rule29544%_))
                                   (let ((_%name29564%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%rule29547%_
                                             '1
                                             '#f
                                             '#f)))
                                         (_%render29565%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%rule29547%_
                                             '2
                                             '#f
                                             '#f)))
                                         (_%body29566%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%rule29547%_
                                             '3
                                             '#f
                                             '#f)))
                                         (_%label29567%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%rule29547%_
                                             '4
                                             '#f
                                             '#f))))
                                     (letrec ((_%walk29569%_
                                               (lambda (_%remaining29571%_
                                                        _%bindings29572%_
                                                        _%inputs29573%_)
                                                 (if _%bounded?29519%_
                                                     '#!void
                                                     (if (null? _%remaining29571%_)
                                                         (let ((_%row29575%_
                                                                (_%render29565%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%bindings29572%_)))
                   (if (or (_%known?29524%_ _%name29564%_ _%row29575%_)
                           (let ((_%members29580%_
                                  (and _%pending-index29542%_
                                       (let ()
                                         (declare (not safe))
                                         (hash-get
                                          _%pending-index29542%_
                                          _%name29564%_)))))
                             (and _%members29580%_
                                  (let ()
                                    (declare (not safe))
                                    (hash-get
                                     _%members29580%_
                                     _%row29575%_)))))
                       '#!void
                       (begin
                         (if (>= (+ _%derived-count29516%_
                                    _%pending-count29541%_)
                                 _%derived-limit29520%_)
                             (set! _%bounded?29519%_ '#t)
                             '#!void)
                         (if (if _%bounded?29519%_
                                 '#f
                                 (_%reserve-row!29525%_ _%row29575%_))
                             (let* ((_%node29582%_
                                     (let ((__tmp33930
                                            (+ _%next-id29515%_
                                               _%pending-count29541%_))
                                           (__tmp33929
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                               _%row29575%_)))
                                           (__tmp33928
                                            (reverse _%inputs29573%_)))
                                       (declare (not safe))
                                       (##structure
                                        gerbil-ascent/candidate/provenance#proof-node::t
                                        __tmp33930
                                        'rule
                                        _%name29564%_
                                        __tmp33929
                                        _%label29567%_
                                        __tmp33928)))
                                    (_%members29589%_
                                     (let ((_%$e29584%_
                                            (if _%pending-index29542%_
                                                (let ()
                                                  (declare (not safe))
                                                  (hash-get
                                                   _%pending-index29542%_
                                                   _%name29564%_))
                                                '#f)))
                                       (if _%$e29584%_
                                           _%$e29584%_
                                           (let ((_%table29587%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (make-hash-table__%
                                                     '#f
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value))))
                                             (if _%pending-index29542%_
                                                 '#!void
                                                 (set! _%pending-index29542%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (make-hash-table-eq))))
                                             (let ()
                                               (declare (not safe))
                                               (hash-put!
                                                _%pending-index29542%_
                                                _%name29564%_
                                                _%table29587%_))
                                             _%table29587%_)))))
                               (let ((__tmp33931
                                      (let ()
                                        (declare (not safe))
                                        (##unchecked-structure-ref
                                         _%node29582%_
                                         '4
                                         '#f
                                         '#f))))
                                 (declare (not safe))
                                 (hash-put!
                                  _%members29589%_
                                  __tmp33931
                                  _%node29582%_))
                               (set! _%pending29540%_
                                     (cons _%node29582%_ _%pending29540%_))
                               (set! _%pending-count29541%_
                                     (+ _%pending-count29541%_ '1)))
                             '#!void))))
                 (let* ((_%clause29592%_ (car _%remaining29571%_))
                        (_%clause29594%_ _%clause29592%_))
                   (if (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%clause29594%_
                          '1
                          '#f
                          '#f))
                       (let ((__tmp33933
                              (lambda (_%node29609%_)
                                (if _%bounded?29519%_
                                    '#!void
                                    (begin
                                      (set! _%steps29517%_
                                            (+ _%steps29517%_ '1))
                                      (if (> _%steps29517%_ _%max-steps29498%_)
                                          (set! _%bounded?29519%_ '#t)
                                          (let ((_%next29611%_
                                                 ((let ()
                                                    (declare (not safe))
                                                    (##unchecked-structure-ref
                                                     _%clause29594%_
                                                     '2
                                                     '#f
                                                     '#f))
                                                  (##structure-ref
                                                   _%node29609%_
                                                   '4
                                                   gerbil-ascent/candidate/provenance#proof-node::t
                                                   '#f)
                                                  _%bindings29572%_)))
                                            (if _%next29611%_
                                                (_%walk29569%_
                                                 (cdr _%remaining29571%_)
                                                 _%next29611%_
                                                 (cons (##structure-ref
                                                        _%node29609%_
                                                        '1
                                                        gerbil-ascent/candidate/provenance#proof-node::t
                                                        '#f)
                                                       _%inputs29573%_))
                                                '#!void)))))))
                             (__tmp33932
                              (_%facts29522%_
                               (let ()
                                 (declare (not safe))
                                 (##unchecked-structure-ref
                                  _%clause29594%_
                                  '1
                                  '#f
                                  '#f)))))
                         (declare (not safe))
                         (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                          _%active?29523%_
                          __tmp33933
                          __tmp33932))
                       (begin
                         (set! _%steps29517%_ (+ _%steps29517%_ '1))
                         (if (> _%steps29517%_ _%max-steps29498%_)
                             (set! _%bounded?29519%_ '#t)
                             (let ((_%next29607%_
                                    ((let ()
                                       (declare (not safe))
                                       (##unchecked-structure-ref
                                        _%clause29594%_
                                        '2
                                        '#f
                                        '#f))
                                     _%bindings29572%_)))
                               (if _%next29607%_
                                   (_%walk29569%_
                                    (cdr _%remaining29571%_)
                                    _%next29607%_
                                    _%inputs29573%_)
                                   '#!void)))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                       (_%walk29569%_
                                        _%body29566%_
                                        '()
                                        '())))))))
                          (declare (not safe))
                          (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                           _%active?29523%_
                           __tmp33927
                           _%plans29512%_))
                        (if _%bounded?29519%_
                            (_%result29503%_ 'bounded '() '())
                            (if (null? _%pending29540%_)
                                (let* ((_%matching29615%_
                                        (filter (lambda (_%node29613%_)
                                                  (_%query-match29513%_
                                                   (##structure-ref
                                                    _%node29613%_
                                                    '4
                                                    gerbil-ascent/candidate/provenance#proof-node::t
                                                    '#f)
                                                   '()))
                                                (_%facts29522%_
                                                 (car _%query29501%_))))
                                       (_%rows29617%_
                                        (let ()
                                          (declare (not safe))
                                          (##map gerbil-ascent/candidate/provenance#proof-node-row
                                                 _%matching29615%_)))
                                       (_%roots29619%_
                                        (let ()
                                          (declare (not safe))
                                          (##map gerbil-ascent/candidate/provenance#proof-node-id
                                                 _%matching29615%_))))
                                  (if (and (pair? _%roots29619%_)
                                           (let ()
                                             (declare (not safe))
                                             (gerbil-ascent/candidate/funs#candidate-same-row-set?
                                              _%rows29617%_
                                              _%native-rows29497%_)))
                                      (_%result29503%_
                                       'complete
                                       (let ()
                                         (declare (not safe))
                                         (##reverse _%nodes29514%_))
                                       _%roots29619%_)
                                      (if (and _%retain-closed-absence?29499%_
                                               (null? _%roots29619%_)
                                               (null? _%native-rows29497%_))
                                          (_%result29503%_
                                           'closed-absent
                                           (let ()
                                             (declare (not safe))
                                             (##reverse _%nodes29514%_))
                                           '())
                                          (_%result29503%_
                                           'unsupported
                                           '()
                                           '()))))
                                (begin
                                  (let ((__tmp33934
                                         (let ()
                                           (declare (not safe))
                                           (##reverse _%pending29540%_))))
                                    (declare (not safe))
                                    (##for-each _%install!29526%_ __tmp33934))
                                  (set! _%next-id29515%_
                                        (+ _%next-id29515%_
                                           _%pending-count29541%_))
                                  (set! _%derived-count29516%_
                                        (+ _%derived-count29516%_
                                           _%pending-count29541%_))
                                  (_%saturate29537%_)))))))))))))
    (define gerbil-ascent/candidate/provenance#candidate-positive-proof
      (lambda (_%snapshot29486%_
               _%spec29487%_
               _%candidate-digest29488%_
               _%native-status29489%_
               _%native-rows29490%_
               _%max-steps29491%_)
        (gerbil-ascent/candidate/provenance#candidate-positive-proof/option
         _%snapshot29486%_
         _%spec29487%_
         _%candidate-digest29488%_
         _%native-status29489%_
         _%native-rows29490%_
         _%max-steps29491%_
         '#f)))
    (define gerbil-ascent/candidate/provenance#candidate-positive-closed-absence
      (lambda (_%snapshot29479%_
               _%spec29480%_
               _%candidate-digest29481%_
               _%native-status29482%_
               _%native-rows29483%_
               _%max-steps29484%_)
        (gerbil-ascent/candidate/provenance#candidate-positive-proof/option
         _%snapshot29479%_
         _%spec29480%_
         _%candidate-digest29481%_
         _%native-status29482%_
         _%native-rows29483%_
         _%max-steps29484%_
         '#t)))
    (define gerbil-ascent/candidate/provenance#proof-metadata-lookup
      (lambda (_%entries29427%_)
        (let* ((_%$%entries2942829438%_ _%entries29427%_)
               (_%$%else2943129452%_
                (lambda ()
                  (let ((_%index29446%_
                         (let ()
                           (declare (not safe))
                           (make-hash-table__%
                            '#f
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value))))
                    (for-each
                     (lambda (_%entry29448%_)
                       (if (let ((__tmp33935 (car _%entry29448%_)))
                             (declare (not safe))
                             (__hash-get _%index29446%_ __tmp33935))
                           '#!void
                           (let ((__tmp33937 (car _%entry29448%_))
                                 (__tmp33936 (cdr _%entry29448%_)))
                             (declare (not safe))
                             (__hash-put!
                              _%index29446%_
                              __tmp33937
                              __tmp33936))))
                     _%entries29427%_)
                    (lambda (_%key29450%_)
                      (let ()
                        (declare (not safe))
                        (__hash-get _%index29446%_ _%key29450%_)))))))
          (let ((_%$%K2943629476%_ (lambda () (lambda (_%_29474%_) '#f)))
                (_%$%K2943329460%_
                 (lambda (_%entry29456%_)
                   (lambda (_%key29458%_)
                     (if (equal? _%key29458%_ (car _%entry29456%_))
                         (cdr _%entry29456%_)
                         '#f)))))
            (let ((_%$%try-match2943029470%_
                   (lambda ()
                     (if (pair? _%$%entries2942829438%_)
                         (let ((_%$%tl2943529465%_
                                (let ()
                                  (declare (not safe))
                                  (##cdr _%$%entries2942829438%_)))
                               (_%$%hd2943429463%_
                                (let ()
                                  (declare (not safe))
                                  (##car _%$%entries2942829438%_))))
                           (if (null? _%$%tl2943529465%_)
                               (let ((_%entry29468%_ _%$%hd2943429463%_))
                                 (_%$%K2943329460%_ _%entry29468%_))
                               (_%$%else2943129452%_)))
                         (_%$%else2943129452%_)))))
              (if (null? _%$%entries2942829438%_)
                  (_%$%K2943629476%_)
                  (_%$%try-match2943029470%_)))))))
    (define gerbil-ascent/candidate/provenance#positive-rule-replay::t
      (let ((__tmp33939 (list))
            (__tmp33938
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'positive-rule-replay
         __tmp33939
         '(relation input-count execute)
         __tmp33938
         '#f)))
    (define gerbil-ascent/candidate/provenance#positive-rule-replay?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/provenance#positive-rule-replay::t)))
    (define gerbil-ascent/candidate/provenance#make-positive-rule-replay
      (lambda _%$args29424%_
        (apply make-instance
               gerbil-ascent/candidate/provenance#positive-rule-replay::t
               _%$args29424%_)))
    (define gerbil-ascent/candidate/provenance#positive-rule-replay-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#positive-rule-replay-input-count
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'input-count)))
    (define gerbil-ascent/candidate/provenance#positive-rule-replay-execute
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'execute)))
    (define gerbil-ascent/candidate/provenance#positive-rule-replay-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#positive-rule-replay-input-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'input-count)))
    (define gerbil-ascent/candidate/provenance#positive-rule-replay-execute-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'execute)))
    (define gerbil-ascent/candidate/provenance#&positive-rule-replay-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#&positive-rule-replay-input-count
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'input-count)))
    (define gerbil-ascent/candidate/provenance#&positive-rule-replay-execute
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'execute)))
    (define gerbil-ascent/candidate/provenance#&positive-rule-replay-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#&positive-rule-replay-input-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'input-count)))
    (define gerbil-ascent/candidate/provenance#&positive-rule-replay-execute-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'execute)))
    (define gerbil-ascent/candidate/provenance#prepare-positive-rule-replay
      (lambda (_%rule29331%_)
        (let* ((_%$%rule2933229340%_ _%rule29331%_)
               (_%$%E2933429343%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%rule2933229340%_
                           '(#(head body _))))
                  '#!void))
               (_%$%K2933529408%_
                (lambda (_%body29346%_ _%head29347%_)
                  (let* ((_%flow29349%_
                          (let ()
                            (declare (not safe))
                            (gerbil-ascent/candidate/proof-frame#prepare-proof-binding-flow
                             _%head29347%_
                             _%body29346%_)))
                         (_%render29351%_
                          (let ()
                            (declare (not safe))
                            (##unchecked-structure-ref
                             _%flow29349%_
                             '2
                             '#f
                             '#f)))
                         (_%fresh29353%_
                          (let ()
                            (declare (not safe))
                            (##unchecked-structure-ref
                             _%flow29349%_
                             '1
                             '#f
                             '#f)))
                         (_%replay29399%_
                          (let ((__tmp33942
                                 (lambda (_%clause29355%_ _%next29356%_)
                                   (let* ((_%clause29359%_ _%clause29355%_)
                                          (_%evaluate29375%_
                                           (let ()
                                             (declare (not safe))
                                             (##unchecked-structure-ref
                                              _%clause29359%_
                                              '2
                                              '#f
                                              '#f))))
                                     (if (let ()
                                           (declare (not safe))
                                           (##unchecked-structure-ref
                                            _%clause29359%_
                                            '1
                                            '#f
                                            '#f))
                                         (lambda (_%inputs29377%_
                                                  _%frame29378%_
                                                  _%by-id29379%_
                                                  _%before29380%_
                                                  _%row29381%_)
                                           (let ((_%id29383%_
                                                  (car _%inputs29377%_)))
                                             (if (exact-integer? _%id29383%_)
                                                 (if (<= '0 _%id29383%_)
                                                     (if (< _%id29383%_
                                                            _%before29380%_)
                                                         (let ((_%input29385%_
                                                                (vector-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%by-id29379%_
                         _%id29383%_)))
                   (if (eq? (##structure-ref
                             _%input29385%_
                             '3
                             gerbil-ascent/candidate/provenance#proof-node::t
                             '#f)
                            (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%clause29359%_
                               '1
                               '#f
                               '#f)))
                       (if (_%evaluate29375%_
                            (##structure-ref
                             _%input29385%_
                             '4
                             gerbil-ascent/candidate/provenance#proof-node::t
                             '#f)
                            _%frame29378%_)
                           (_%next29356%_
                            (cdr _%inputs29377%_)
                            _%frame29378%_
                            _%by-id29379%_
                            _%before29380%_
                            _%row29381%_)
                           '#f)
                       '#f))
                 '#f)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     '#f)
                                                 '#f)))
                                         (lambda (_%inputs29387%_
                                                  _%frame29388%_
                                                  _%by-id29389%_
                                                  _%before29390%_
                                                  _%row29391%_)
                                           (if (_%evaluate29375%_
                                                _%frame29388%_)
                                               (_%next29356%_
                                                _%inputs29387%_
                                                _%frame29388%_
                                                _%by-id29389%_
                                                _%before29390%_
                                                _%row29391%_)
                                               '#f))))))
                                (__tmp33941
                                 (lambda (_%inputs29393%_
                                          _%frame29394%_
                                          _%_by-id29395%_
                                          _%_before29396%_
                                          _%row29397%_)
                                   (if (null? _%inputs29393%_)
                                       (equal? _%row29397%_
                                               (_%render29351%_
                                                _%frame29394%_))
                                       '#f)))
                                (__tmp33940
                                 (let ()
                                   (declare (not safe))
                                   (##unchecked-structure-ref
                                    _%flow29349%_
                                    '3
                                    '#f
                                    '#f))))
                            (declare (not safe))
                            (foldr__0 __tmp33942 __tmp33941 __tmp33940))))
                    (let ((__tmp33946 (car _%head29347%_))
                          (__tmp33944
                           (let ((__tmp33945
                                  (filter gerbil-ascent/candidate/provenance#positive-atom?
                                          _%body29346%_)))
                             (declare (not safe))
                             (##length __tmp33945)))
                          (__tmp33943
                           (lambda (_%inputs29402%_
                                    _%_bindings29403%_
                                    _%by-id29404%_
                                    _%before29405%_
                                    _%row29406%_)
                             (_%replay29399%_
                              _%inputs29402%_
                              (_%fresh29353%_)
                              _%by-id29404%_
                              _%before29405%_
                              _%row29406%_))))
                      (declare (not safe))
                      (##structure
                       gerbil-ascent/candidate/provenance#positive-rule-replay::t
                       __tmp33946
                       __tmp33944
                       __tmp33943))))))
          (if (vector? _%$%rule2933229340%_)
              (if (let ((__tmp33947
                         (let ()
                           (declare (not safe))
                           (##vector-length _%$%rule2933229340%_))))
                    (declare (not safe))
                    (##fx= __tmp33947 '3))
                  (let* ((_%$%e2933629411%_
                          (let ()
                            (declare (not safe))
                            (##vector-ref _%$%rule2933229340%_ '0)))
                         (_%head29414%_ _%$%e2933629411%_)
                         (_%$%e2933729416%_
                          (let ()
                            (declare (not safe))
                            (##vector-ref _%$%rule2933229340%_ '1)))
                         (_%body29419%_ _%$%e2933729416%_)
                         (_%$%e2933829421%_
                          (let ()
                            (declare (not safe))
                            (##vector-ref _%$%rule2933229340%_ '2))))
                    (_%$%K2933529408%_ _%body29419%_ _%head29414%_))
                  (_%$%E2933429343%_))
              (_%$%E2933429343%_)))))
    (define gerbil-ascent/candidate/provenance#candidate-verify-positive-proof
      (lambda (_%snapshot29261%_
               _%spec29262%_
               _%candidate-digest29263%_
               _%native-status29264%_
               _%native-rows29265%_
               _%proof29266%_
               _%max-nodes29267%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%proof29266%_
               'gerbil-ascent/candidate/provenance#positive-proof::t))
            (if (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                   _%snapshot29261%_))
                (if (eq? (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%proof29266%_
                            '1
                            '#f
                            '#f))
                         'complete)
                    (if (eq? _%native-status29264%_ 'complete)
                        (if (gerbil-ascent/candidate/provenance#positive-rules?
                             _%spec29262%_)
                            (if (exact-integer? _%max-nodes29267%_)
                                (if (> _%max-nodes29267%_ '0)
                                    (if (equal? (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%proof29266%_
                                                   '2
                                                   '#f
                                                   '#f))
                                                (##structure-ref
                                                 _%snapshot29261%_
                                                 '1
                                                 gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                 '#f))
                                        (if (equal? (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%proof29266%_
                                                       '3
                                                       '#f
                                                       '#f))
                                                    (##structure-ref
                                                     _%snapshot29261%_
                                                     '2
                                                     gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                     '#f))
                                            (if (equal? (let ()
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           _%proof29266%_
                                                           '4
                                                           '#f
                                                           '#f))
                                                        (##structure-ref
                                                         _%snapshot29261%_
                                                         '3
                                                         gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                         '#f))
                                                (if (equal? (let ()
                                                              (declare
                                                                (not safe))
                                                              (##unchecked-structure-ref
                                                               _%proof29266%_
                                                               '5
                                                               '#f
                                                               '#f))
                                                            _%candidate-digest29263%_)
                                                    (if (equal? (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%proof29266%_
                           '6
                           '#f
                           '#f))
                        (vector-ref
                         (##structure-ref
                          _%spec29262%_
                          '4
                          gerbil-ascent/candidate/types#reasoning-candidate::t
                          '#f)
                         '0))
                (let* ((_%nodes29269%_
                        (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%proof29266%_
                           '8
                           '#f
                           '#f)))
                       (_%node-count29271%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                           _%nodes29269%_
                           _%max-nodes29267%_))))
                  (if _%node-count29271%_
                      (if (let ((__tmp33948
                                 (let ()
                                   (declare (not safe))
                                   (##unchecked-structure-ref
                                    _%proof29266%_
                                    '9
                                    '#f
                                    '#f))))
                            (declare (not safe))
                            (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                             __tmp33948
                             _%node-count29271%_))
                          (let* ((_%by-id29274%_
                                  (make-vector _%node-count29271%_ '#f))
                                 (_%arities29276%_
                                  (gerbil-ascent/candidate/provenance#proof-metadata-lookup
                                   (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/funs#candidate-schema-of
                                      _%snapshot29261%_
                                      _%spec29262%_))))
                                 (_%source29278%_
                                  (##structure-ref
                                   _%snapshot29261%_
                                   '4
                                   gerbil-ascent/candidate/types#reasoning-snapshot::t
                                   '#f))
                                 (_%facts29280%_
                                  (##structure-ref
                                   _%spec29262%_
                                   '2
                                   gerbil-ascent/candidate/types#reasoning-candidate::t
                                   '#f))
                                 (_%rules29282%_
                                  (##structure-ref
                                   _%spec29262%_
                                   '3
                                   gerbil-ascent/candidate/types#reasoning-candidate::t
                                   '#f))
                                 (_%query29284%_
                                  (let ()
                                    (declare (not safe))
                                    (##unchecked-structure-ref
                                     _%proof29266%_
                                     '6
                                     '#f
                                     '#f)))
                                 (_%source-rows29288%_
                                  (gerbil-ascent/candidate/provenance#proof-metadata-lookup
                                   (map (lambda (_%entry29286%_)
                                          (cons (car _%entry29286%_)
                                                (list->vector
                                                 (caddr _%entry29286%_))))
                                        _%source29278%_)))
                                 (_%fact-keys29290%_
                                  (if (pair? _%facts29280%_)
                                      (let ()
                                        (declare (not safe))
                                        (make-hash-table__%
                                         '#f
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value))
                                      '#f))
                                 (_%rule-labels29294%_
                                  (gerbil-ascent/candidate/provenance#proof-metadata-lookup
                                   (map (lambda (_%rule29292%_)
                                          (cons (vector-ref _%rule29292%_ '2)
                                                (gerbil-ascent/candidate/provenance#prepare-positive-rule-replay
                                                 _%rule29292%_)))
                                        _%rules29282%_)))
                                 (_%match-query29296%_
                                  (let ()
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
                                     _%query29284%_))))
                            (for-each
                             (lambda (_%fact29299%_)
                               (let ((__tmp33949
                                      (list (vector-ref _%fact29299%_ '2)
                                            (vector-ref _%fact29299%_ '0)
                                            (vector-ref _%fact29299%_ '1))))
                                 (declare (not safe))
                                 (hash-put!
                                  _%fact-keys29290%_
                                  __tmp33949
                                  '#t)))
                             _%facts29280%_)
                            (letrec ((_%existing-input?29301%_
                                      (lambda (_%id29328%_ _%before29329%_)
                                        (if (exact-integer? _%id29328%_)
                                            (if (<= '0 _%id29328%_)
                                                (< _%id29328%_ _%before29329%_)
                                                '#f)
                                            '#f)))
                                     (_%node-valid?29302%_
                                      (lambda (_%node29316%_ _%index29317%_)
                                        (if (let ()
                                              (declare (not safe))
                                              (##structure-instance-of?
                                               _%node29316%_
                                               'gerbil-ascent/candidate/provenance#proof-node::t))
                                            (if (exact-integer?
                                                 (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%node29316%_
                                                    '1
                                                    '#f
                                                    '#f)))
                                                (if (= (let ()
                                                         (declare (not safe))
                                                         (##unchecked-structure-ref
                                                          _%node29316%_
                                                          '1
                                                          '#f
                                                          '#f))
                                                       _%index29317%_)
                                                    (if (symbol? (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%node29316%_
                            '3
                            '#f
                            '#f)))
                (if (let ((_%arity29319%_
                           (let ((__tmp33950
                                  (let ()
                                    (declare (not safe))
                                    (##unchecked-structure-ref
                                     _%node29316%_
                                     '3
                                     '#f
                                     '#f))))
                             (declare (not safe))
                             (_%arities29276%_ __tmp33950))))
                      (and _%arity29319%_
                           (equal? (let ((__tmp33951
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%node29316%_
                                             '4
                                             '#f
                                             '#f))))
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                                      __tmp33951
                                      _%arity29319%_))
                                   _%arity29319%_)))
                    (let ((_%$e29321%_
                           (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%node29316%_
                              '2
                              '#f
                              '#f))))
                      (if (eq? 'source _%$e29321%_)
                          (if (null? (let ()
                                       (declare (not safe))
                                       (##unchecked-structure-ref
                                        _%node29316%_
                                        '6
                                        '#f
                                        '#f)))
                              (let ((_%rows29324%_
                                     (let ((__tmp33952
                                            (let ()
                                              (declare (not safe))
                                              (##unchecked-structure-ref
                                               _%node29316%_
                                               '3
                                               '#f
                                               '#f))))
                                       (declare (not safe))
                                       (_%source-rows29288%_ __tmp33952))))
                                (if _%rows29324%_
                                    (if (exact-integer?
                                         (let ()
                                           (declare (not safe))
                                           (##unchecked-structure-ref
                                            _%node29316%_
                                            '5
                                            '#f
                                            '#f)))
                                        (if (<= '1
                                                (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%node29316%_
                                                   '5
                                                   '#f
                                                   '#f)))
                                            (if (<= (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%node29316%_
                                                       '5
                                                       '#f
                                                       '#f))
                                                    (vector-length
                                                     _%rows29324%_))
                                                (equal? (let ()
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           _%node29316%_
                                                           '4
                                                           '#f
                                                           '#f))
                                                        (vector-ref
                                                         _%rows29324%_
                                                         (- (let ()
                                                              (declare
                                                                (not safe))
                                                              (##unchecked-structure-ref
                                                               _%node29316%_
                                                               '5
                                                               '#f
                                                               '#f))
                                                            '1)))
                                                '#f)
                                            '#f)
                                        '#f)
                                    '#f))
                              '#f)
                          (if (eq? 'candidate _%$e29321%_)
                              (if (null? (let ()
                                           (declare (not safe))
                                           (##unchecked-structure-ref
                                            _%node29316%_
                                            '6
                                            '#f
                                            '#f)))
                                  (if _%fact-keys29290%_
                                      (let ((__tmp33953
                                             (list (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%node29316%_
                                                      '5
                                                      '#f
                                                      '#f))
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%node29316%_
                                                      '3
                                                      '#f
                                                      '#f))
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%node29316%_
                                                      '4
                                                      '#f
                                                      '#f)))))
                                        (declare (not safe))
                                        (__hash-get
                                         _%fact-keys29290%_
                                         __tmp33953))
                                      '#f)
                                  '#f)
                              (if (eq? 'rule _%$e29321%_)
                                  (let ((_%plan29326%_
                                         (let ((__tmp33954
                                                (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%node29316%_
                                                   '5
                                                   '#f
                                                   '#f))))
                                           (declare (not safe))
                                           (_%rule-labels29294%_ __tmp33954))))
                                    (if _%plan29326%_
                                        (if (eq? (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%node29316%_
                                                    '3
                                                    '#f
                                                    '#f))
                                                 (##direct-structure-ref
                                                  _%plan29326%_
                                                  '1
                                                  gerbil-ascent/candidate/provenance#positive-rule-replay::t
                                                  '#f))
                                            (if (equal? (let ((__tmp33956
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (##unchecked-structure-ref _%node29316%_ '6 '#f '#f)))
                      (__tmp33955
                       (##direct-structure-ref
                        _%plan29326%_
                        '2
                        gerbil-ascent/candidate/provenance#positive-rule-replay::t
                        '#f)))
                  (declare (not safe))
                  (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                   __tmp33956
                   __tmp33955))
                (##direct-structure-ref
                 _%plan29326%_
                 '2
                 gerbil-ascent/candidate/provenance#positive-rule-replay::t
                 '#f))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                ((##direct-structure-ref
                                                  _%plan29326%_
                                                  '3
                                                  gerbil-ascent/candidate/provenance#positive-rule-replay::t
                                                  '#f)
                                                 (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%node29316%_
                                                    '6
                                                    '#f
                                                    '#f))
                                                 '()
                                                 _%by-id29274%_
                                                 _%index29317%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%node29316%_
                                                    '4
                                                    '#f
                                                    '#f)))
                                                '#f)
                                            '#f)
                                        '#f))
                                  '#f))))
                    '#f)
                '#f)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '#f)
                                                '#f)
                                            '#f))))
                              (if (let _%loop29304%_ ((_%remaining29306%_
                                                       _%nodes29269%_)
                                                      (_%index29307%_ '0))
                                    (or (null? _%remaining29306%_)
                                        (and (_%node-valid?29302%_
                                              (car _%remaining29306%_)
                                              _%index29307%_)
                                             (begin
                                               (vector-set!
                                                _%by-id29274%_
                                                _%index29307%_
                                                (car _%remaining29306%_))
                                               (_%loop29304%_
                                                (cdr _%remaining29306%_)
                                                (+ _%index29307%_ '1))))))
                                  (if (let ((__tmp33958
                                             (lambda (_%id29312%_)
                                               (and (_%existing-input?29301%_
                                                     _%id29312%_
                                                     _%node-count29271%_)
                                                    (eq? (##structure-ref
                                                          (vector-ref
                                                           _%by-id29274%_
                                                           _%id29312%_)
                                                          '3
                                                          gerbil-ascent/candidate/provenance#proof-node::t
                                                          '#f)
                                                         (car _%query29284%_))
                                                    (_%match-query29296%_
                                                     (##structure-ref
                                                      (vector-ref
                                                       _%by-id29274%_
                                                       _%id29312%_)
                                                      '4
                                                      gerbil-ascent/candidate/provenance#proof-node::t
                                                      '#f)
                                                     '()))))
                                            (__tmp33957
                                             (let ()
                                               (declare (not safe))
                                               (##unchecked-structure-ref
                                                _%proof29266%_
                                                '9
                                                '#f
                                                '#f))))
                                        (declare (not safe))
                                        (andmap__0 __tmp33958 __tmp33957))
                                      (let ((__tmp33959
                                             (map (lambda (_%id29314%_)
                                                    (##structure-ref
                                                     (vector-ref
                                                      _%by-id29274%_
                                                      _%id29314%_)
                                                     '4
                                                     gerbil-ascent/candidate/provenance#proof-node::t
                                                     '#f))
                                                  (let ()
                                                    (declare (not safe))
                                                    (##unchecked-structure-ref
                                                     _%proof29266%_
                                                     '9
                                                     '#f
                                                     '#f)))))
                                        (declare (not safe))
                                        (gerbil-ascent/candidate/funs#candidate-same-row-set?
                                         __tmp33959
                                         _%native-rows29265%_))
                                      '#f)
                                  '#f)))
                          '#f)
                      '#f))
                '#f)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '#f)
                                                '#f)
                                            '#f)
                                        '#f)
                                    '#f)
                                '#f)
                            '#f)
                        '#f)
                    '#f)
                '#f)
            '#f)))))
