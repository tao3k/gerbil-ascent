(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/scheme-admit::timestamp 1791689709)
  (begin
    (define gerbil-ascent/program/scheme-admit#relational-admission::t
      (let ((__tmp37698 (list)) (__tmp37697 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/scheme-admit#relational-admission::t
         'relational-admission
         __tmp37698
         '(run)
         __tmp37697
         '#f)))
    (define gerbil-ascent/program/scheme-admit#relational-admission?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/scheme-admit#relational-admission::t)))
    (define gerbil-ascent/program/scheme-admit#make-relational-admission
      (lambda _%$args20472%_
        (apply make-instance
               gerbil-ascent/program/scheme-admit#relational-admission::t
               _%$args20472%_)))
    (define gerbil-ascent/program/scheme-admit#relational-admission-run
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-admit#relational-admission::t
         'run)))
    (define gerbil-ascent/program/scheme-admit#relational-admission-run-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-admit#relational-admission::t
         'run)))
    (define gerbil-ascent/program/scheme-admit#&relational-admission-run
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-admit#relational-admission::t
         'run)))
    (define gerbil-ascent/program/scheme-admit#&relational-admission-run-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-admit#relational-admission::t
         'run)))
    (define gerbil-ascent/program/scheme-admit#relational-diagnostic::t
      (let ((__tmp37700 (list)) (__tmp37699 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'relational-diagnostic
         __tmp37700
         '(code path detail)
         __tmp37699
         '#f)))
    (define gerbil-ascent/program/scheme-admit#relational-diagnostic?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t)))
    (define gerbil-ascent/program/scheme-admit#make-relational-diagnostic
      (lambda _%$args20469%_
        (apply make-instance
               gerbil-ascent/program/scheme-admit#relational-diagnostic::t
               _%$args20469%_)))
    (define gerbil-ascent/program/scheme-admit#relational-diagnostic-code
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'code)))
    (define gerbil-ascent/program/scheme-admit#relational-diagnostic-path
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'path)))
    (define gerbil-ascent/program/scheme-admit#relational-diagnostic-detail
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'detail)))
    (define gerbil-ascent/program/scheme-admit#relational-diagnostic-code-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'code)))
    (define gerbil-ascent/program/scheme-admit#relational-diagnostic-path-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'path)))
    (define gerbil-ascent/program/scheme-admit#relational-diagnostic-detail-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'detail)))
    (define gerbil-ascent/program/scheme-admit#&relational-diagnostic-code
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'code)))
    (define gerbil-ascent/program/scheme-admit#&relational-diagnostic-path
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'path)))
    (define gerbil-ascent/program/scheme-admit#&relational-diagnostic-detail
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'detail)))
    (define gerbil-ascent/program/scheme-admit#&relational-diagnostic-code-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'code)))
    (define gerbil-ascent/program/scheme-admit#&relational-diagnostic-path-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'path)))
    (define gerbil-ascent/program/scheme-admit#&relational-diagnostic-detail-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'detail)))
    (define gerbil-ascent/program/scheme-admit#relational-admission-report::t
      (let ((__tmp37702 (list)) (__tmp37701 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/scheme-admit#relational-admission-report::t
         'relational-admission-report
         __tmp37702
         '(admission diagnostic)
         __tmp37701
         '#f)))
    (define gerbil-ascent/program/scheme-admit#relational-admission-report?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/scheme-admit#relational-admission-report::t)))
    (define gerbil-ascent/program/scheme-admit#make-relational-admission-report
      (lambda _%$args20466%_
        (apply make-instance
               gerbil-ascent/program/scheme-admit#relational-admission-report::t
               _%$args20466%_)))
    (define gerbil-ascent/program/scheme-admit#relational-admission-report-admission
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-admit#relational-admission-report::t
         'admission)))
    (define gerbil-ascent/program/scheme-admit#relational-admission-report-diagnostic
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-admit#relational-admission-report::t
         'diagnostic)))
    (define gerbil-ascent/program/scheme-admit#relational-admission-report-admission-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-admit#relational-admission-report::t
         'admission)))
    (define gerbil-ascent/program/scheme-admit#relational-admission-report-diagnostic-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-admit#relational-admission-report::t
         'diagnostic)))
    (define gerbil-ascent/program/scheme-admit#&relational-admission-report-admission
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-admit#relational-admission-report::t
         'admission)))
    (define gerbil-ascent/program/scheme-admit#&relational-admission-report-diagnostic
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-admit#relational-admission-report::t
         'diagnostic)))
    (define gerbil-ascent/program/scheme-admit#&relational-admission-report-admission-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-admit#relational-admission-report::t
         'admission)))
    (define gerbil-ascent/program/scheme-admit#&relational-admission-report-diagnostic-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-admit#relational-admission-report::t
         'diagnostic)))
    (define gerbil-ascent/program/scheme-admit#relational-compose
      (lambda (_%fragments20453%_
               _%input-limit20454%_
               _%derived-limit20455%_
               _%output-limit20456%_)
        (for-each
         (lambda (_%fragment20458%_)
           (let ()
             (declare (not safe))
             (clan/poo/mop#validate
              gerbil-ascent/program/types#GerbilAscentFragmentContract
              _%fragment20458%_)))
         _%fragments20453%_)
        (let ((__tmp37707
               (let ((__tmp37708
                      (lambda (_%fragment20460%_)
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref
                           _%fragment20460%_
                           'relations)))))
                 (declare (not safe))
                 (std/list/list#append-map __tmp37708 _%fragments20453%_)))
              (__tmp37705
               (let ((__tmp37706
                      (lambda (_%fragment20462%_)
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref _%fragment20462%_ 'rules)))))
                 (declare (not safe))
                 (std/list/list#append-map __tmp37706 _%fragments20453%_)))
              (__tmp37703
               (let ((__tmp37704
                      (lambda (_%fragment20464%_)
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref
                           _%fragment20464%_
                           'source-handles)))))
                 (declare (not safe))
                 (std/list/list#append-map __tmp37704 _%fragments20453%_))))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-program__%
           __tmp37707
           __tmp37705
           _%input-limit20454%_
           _%derived-limit20455%_
           _%output-limit20456%_
           __tmp37703))))
    (define gerbil-ascent/program/scheme-admit#relational-admit__%
      (lambda (_%program20425%_ _%on-plan-error20426%_)
        (let ((_%snapshot20428%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/program/scheme-snapshot#relational-snapshot-program
                  _%program20425%_))))
          (let ((_%run20430%_
                 (let ()
                   (declare (not safe))
                   (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__4
                    _%snapshot20428%_
                    '#f
                    '#f
                    '#f
                    '#f
                    _%on-plan-error20426%_)))
                (_%status20431%_ 'ready)
                (_%complete-result20432%_ '#f))
            (let ((__tmp37709
                   (lambda ()
                     (let ((_%$e20435%_ _%status20431%_))
                       (if (eq? 'complete _%$e20435%_)
                           _%complete-result20432%_
                           (if (eq? 'failed _%$e20435%_)
                               (let ()
                                 (declare (not safe))
                                 (error '"relational solve previously failed"))
                               (if (eq? 'running _%$e20435%_)
                                   (let ()
                                     (declare (not safe))
                                     (error '"reentrant relational solve"))
                                   (begin
                                     (set! _%status20431%_ 'running)
                                     (let ((__tmp37711
                                            (lambda (_%failure20438%_)
                                              (set! _%status20431%_ 'failed)
                                              (let ()
                                                (declare (not safe))
                                                (raise _%failure20438%_))))
                                           (__tmp37710
                                            (lambda ()
                                              (let ((_%result20441%_
                                                     (_%run20430%_)))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (clan/poo/object#.ref
                                                       _%result20441%_
                                                       'finished))
                                                    '#!void
                                                    (let ()
                                                      (declare (not safe))
                                                      (error '"relational solve did not complete")))
                                                (set! _%complete-result20432%_
                                                      _%result20441%_)
                                                (set! _%status20431%_
                                                      'complete)
                                                _%result20441%_))))
                                       (declare (not safe))
                                       (__with-catch
                                        __tmp37711
                                        __tmp37710))))))))))
              (declare (not safe))
              (##structure
               gerbil-ascent/program/scheme-admit#relational-admission::t
               __tmp37709))))))
    (define gerbil-ascent/program/scheme-admit#relational-admit__0
      (lambda (_%program20446%_)
        (let ((_%on-plan-error20448%_ '#f))
          (gerbil-ascent/program/scheme-admit#relational-admit__%
           _%program20446%_
           _%on-plan-error20448%_))))
    (define gerbil-ascent/program/scheme-admit#relational-admit
      (lambda _g37712_
        (let ((_g37713_ (let () (declare (not safe)) (##length _g37712_))))
          (cond ((let () (declare (not safe)) (##fx= _g37713_ 1))
                 (apply gerbil-ascent/program/scheme-admit#relational-admit__0
                        _g37712_))
                ((let () (declare (not safe)) (##fx= _g37713_ 2))
                 (apply gerbil-ascent/program/scheme-admit#relational-admit__%
                        _g37712_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/scheme-admit#relational-admit
                  _g37712_))))))
    (define gerbil-ascent/program/scheme-admit#relational-admit/report
      (lambda (_%program20411%_)
        (let ((_%path20413%_ '(program)))
          (let ((__tmp37716
                 (lambda (_%failure20415%_)
                   (let ((__tmp37717
                          (let ((__tmp37719
                                 (if (and (pair? _%path20413%_)
                                          (eq? (car _%path20413%_) 'rule))
                                     (if (eq? (caddr _%path20413%_) 'body)
                                         'invalid-body
                                         'invalid-head)
                                     (if (equal? _%path20413%_
                                                 '(program dependencies))
                                         'invalid-dependencies
                                         'invalid-program)))
                                (__tmp37718
                                 (let ()
                                   (declare (not safe))
                                   (std/error#exception->string
                                    _%failure20415%_))))
                            (declare (not safe))
                            (##structure
                             gerbil-ascent/program/scheme-admit#relational-diagnostic::t
                             __tmp37719
                             _%path20413%_
                             __tmp37718))))
                     (declare (not safe))
                     (##structure
                      gerbil-ascent/program/scheme-admit#relational-admission-report::t
                      '#f
                      __tmp37717))))
                (__tmp37714
                 (lambda ()
                   (let ((__tmp37715
                          (gerbil-ascent/program/scheme-admit#relational-admit__%
                           _%program20411%_
                           (lambda (_%location20421%_ _%_failure20422%_)
                             (set! _%path20413%_ _%location20421%_)))))
                     (declare (not safe))
                     (##structure
                      gerbil-ascent/program/scheme-admit#relational-admission-report::t
                      __tmp37715
                      '#f)))))
            (declare (not safe))
            (__with-catch __tmp37716 __tmp37714)))))
    (define gerbil-ascent/program/scheme-admit#relational-solve
      (lambda (_%admission20409%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%admission20409%_
               'gerbil-ascent/program/scheme-admit#relational-admission::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational solve requires admission"
                     _%admission20409%_)))
        (let ((__tmp37720
               ((##structure-ref
                 _%admission20409%_
                 '1
                 gerbil-ascent/program/scheme-admit#relational-admission::t
                 '#f))))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/scheme-query#relational-solution::t
           __tmp37720))))))
