(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "clan/poo/object")
    (load-module "clan/poo/mop")
    (load-module "core/types")
    (load-module "gerbil-ascent/table/funs"))
  (load-module "gerbil-ascent/table/provider~0"))
