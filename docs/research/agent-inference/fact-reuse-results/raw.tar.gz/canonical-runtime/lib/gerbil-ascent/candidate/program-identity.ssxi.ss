prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/candidate

(begin
  (declare-type
   gerbil-ascent/candidate/program-identity#entry-datum
   (@lambda 1
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/program-identity)))
  (declare-type
   gerbil-ascent/candidate/program-identity#program-shape
   (@lambda 1
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/program-identity)))
  (declare-type
   gerbil-ascent/candidate/program-identity#datum-fingerprint
   (@lambda 1
            #f
            signature:
            (return:
             string::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/program-identity)))
  (declare-type
   gerbil-ascent/candidate/program-identity#candidate-finite-program-fingerprint
   (@lambda 1
            #f
            signature:
            (return:
             string::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/program-identity)))
  (declare-type
   gerbil-ascent/candidate/program-identity#candidate-positive-program-fingerprint
   (@lambda 1
            #f
            signature:
            (return:
             string::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/program-identity))))
