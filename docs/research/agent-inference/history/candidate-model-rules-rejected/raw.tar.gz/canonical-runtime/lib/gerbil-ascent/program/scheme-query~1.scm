(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/scheme-query[1]#_g36226_|
    (##structure
     gx#syntax-quote::t
     'relational-solution::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36228_|
    (##structure
     gx#syntax-quote::t
     'make-relational-solution
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36230_|
    (##structure
     gx#syntax-quote::t
     'relational-solution?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36232_|
    (##structure
     gx#syntax-quote::t
     'relational-solution-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36234_|
    (##structure
     gx#syntax-quote::t
     'relational-solution-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36236_|
    (##structure
     gx#syntax-quote::t
     '&relational-solution-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36238_|
    (##structure
     gx#syntax-quote::t
     '&relational-solution-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36240_|
    (##structure
     gx#syntax-quote::t
     'relational-program-solution::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36242_|
    (##structure
     gx#syntax-quote::t
     'make-relational-program-solution
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36244_|
    (##structure
     gx#syntax-quote::t
     'relational-program-solution?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36246_|
    (##structure
     gx#syntax-quote::t
     'relational-program-solution-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36248_|
    (##structure
     gx#syntax-quote::t
     'relational-program-solution-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36250_|
    (##structure
     gx#syntax-quote::t
     '&relational-program-solution-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36252_|
    (##structure
     gx#syntax-quote::t
     '&relational-program-solution-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/scheme-query[:0:]#relational-solution|
      (let ((__obj36212
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36212
           'gerbil-ascent/program/scheme-query#relational-solution::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36212
           'relational-solution
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36212 '(result) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36212 '(result) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36212 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36212 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36212 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36212 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36212 '#f '13 '#f '#f))
        (let ((__tmp36225 |gerbil-ascent/program/scheme-query[1]#_g36226_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36212 __tmp36225 '4 '#f '#f))
        (let ((__tmp36227 |gerbil-ascent/program/scheme-query[1]#_g36228_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36212 __tmp36227 '14 '#f '#f))
        (let ((__tmp36229 |gerbil-ascent/program/scheme-query[1]#_g36230_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36212 __tmp36229 '15 '#f '#f))
        (let ((__tmp36231
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36232_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36212 __tmp36231 '16 '#f '#f))
        (let ((__tmp36233
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36234_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36212 __tmp36233 '17 '#f '#f))
        (let ((__tmp36235
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36236_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36212 __tmp36235 '18 '#f '#f))
        (let ((__tmp36237
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36238_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36212 __tmp36237 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36212 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36212 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36212 '() '21 '#f '#f))
        __obj36212))
    (define |gerbil-ascent/program/scheme-query[:0:]#relational-program-solution|
      (let ((__obj36213
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36213
           'gerbil-ascent/program/scheme-query#relational-program-solution::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36213
           'relational-program-solution
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36213 '(result) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36213 '(result) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36213 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36213 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36213 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36213 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36213 '#f '13 '#f '#f))
        (let ((__tmp36239 |gerbil-ascent/program/scheme-query[1]#_g36240_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36213 __tmp36239 '4 '#f '#f))
        (let ((__tmp36241 |gerbil-ascent/program/scheme-query[1]#_g36242_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36213 __tmp36241 '14 '#f '#f))
        (let ((__tmp36243 |gerbil-ascent/program/scheme-query[1]#_g36244_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36213 __tmp36243 '15 '#f '#f))
        (let ((__tmp36245
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36246_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36213 __tmp36245 '16 '#f '#f))
        (let ((__tmp36247
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36248_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36213 __tmp36247 '17 '#f '#f))
        (let ((__tmp36249
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36250_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36213 __tmp36249 '18 '#f '#f))
        (let ((__tmp36251
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36252_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36213 __tmp36251 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36213 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36213 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36213 '() '21 '#f '#f))
        __obj36213))))
