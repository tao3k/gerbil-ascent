(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/grounding-plan::timestamp 1791689702)
  (begin
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule::t
      (let ((__tmp37052 (list))
            (__tmp37051
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'grounding-rule
         __tmp37052
         '(name head body label)
         __tmp37051
         '#f)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t)))
    (define gerbil-ascent/candidate/grounding-plan#make-grounding-rule
      (lambda _%$args27655%_
        (apply make-instance
               gerbil-ascent/candidate/grounding-plan#grounding-rule::t
               _%$args27655%_)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule-name
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'name)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule-head
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'head)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule-body
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'body)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule-label
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'label)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule-name-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'name)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule-head-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'head)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule-body-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'body)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-rule-label-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'label)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-rule-name
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'name)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-rule-head
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'head)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-rule-body
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'body)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-rule-label
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'label)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-rule-name-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'name)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-rule-head-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'head)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-rule-body-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'body)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-rule-label-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-rule::t
         'label)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-clause::t
      (let ((__tmp37054 (list))
            (__tmp37053
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/grounding-plan#grounding-clause::t
         'grounding-clause
         __tmp37054
         '(relation apply)
         __tmp37053
         '#f)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-clause?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/grounding-plan#grounding-clause::t)))
    (define gerbil-ascent/candidate/grounding-plan#make-grounding-clause
      (lambda _%$args27652%_
        (apply make-instance
               gerbil-ascent/candidate/grounding-plan#grounding-clause::t
               _%$args27652%_)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-clause-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-clause::t
         'relation)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-clause-apply
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-clause::t
         'apply)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-clause-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-clause::t
         'relation)))
    (define gerbil-ascent/candidate/grounding-plan#grounding-clause-apply-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-clause::t
         'apply)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-clause-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-clause::t
         'relation)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-clause-apply
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/grounding-plan#grounding-clause::t
         'apply)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-clause-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-clause::t
         'relation)))
    (define gerbil-ascent/candidate/grounding-plan#&grounding-clause-apply-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/grounding-plan#grounding-clause::t
         'apply)))
    (define gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
      (lambda (_%atom27626%_)
        (let ((__tmp37057
               (lambda (_%term27628%_ _%next27629%_)
                 (if (eq? _%term27628%_ '?_)
                     (lambda (_%row27632%_ _%bindings27633%_)
                       (_%next27629%_ (cdr _%row27632%_) _%bindings27633%_))
                     (if (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/program#candidate-variable?
                            _%term27628%_))
                         (lambda (_%row27636%_ _%bindings27637%_)
                           (let ((_%$e27639%_
                                  (assq _%term27628%_ _%bindings27637%_)))
                             (if _%$e27639%_
                                 (if (equal? (cdr _%$e27639%_)
                                             (car _%row27636%_))
                                     (_%next27629%_
                                      (cdr _%row27636%_)
                                      _%bindings27637%_)
                                     '#f)
                                 (_%next27629%_
                                  (cdr _%row27636%_)
                                  (cons (cons _%term27628%_ (car _%row27636%_))
                                        _%bindings27637%_)))))
                         (lambda (_%row27646%_ _%bindings27647%_)
                           (if (equal? _%term27628%_ (car _%row27646%_))
                               (_%next27629%_
                                (cdr _%row27646%_)
                                _%bindings27647%_)
                               '#f))))))
              (__tmp37056
               (lambda (_%_27649%_ _%bindings27650%_) _%bindings27650%_))
              (__tmp37055 (cdr _%atom27626%_)))
          (declare (not safe))
          (foldr__0 __tmp37057 __tmp37056 __tmp37055))))
    (define gerbil-ascent/candidate/grounding-plan#prepare-grounding-rule
      (lambda (_%rule27587%_)
        (let* ((_%$%rule2758827596%_ _%rule27587%_)
               (_%$%E2759027599%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%rule2758827596%_
                           '(#(head body label))))
                  '#!void))
               (_%$%K2759127608%_
                (lambda (_%label27602%_ _%body27603%_ _%head27604%_)
                  (let ((__tmp37064 (car _%head27604%_))
                        (__tmp37063
                         (gerbil-ascent/candidate/grounding-plan#prepare-grounding-head
                          _%head27604%_))
                        (__tmp37058
                         (map (lambda (_%clause27606%_)
                                (if (let ((__tmp37059 (car _%clause27606%_)))
                                      (declare (not safe))
                                      (##memq __tmp37059 '(where compute)))
                                    (let ((__tmp37060
                                           (gerbil-ascent/candidate/grounding-plan#prepare-grounding-fixed
                                            _%clause27606%_)))
                                      (declare (not safe))
                                      (##structure
                                       gerbil-ascent/candidate/grounding-plan#grounding-clause::t
                                       '#f
                                       __tmp37060))
                                    (let ((__tmp37062 (car _%clause27606%_))
                                          (__tmp37061
                                           (gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
                                            _%clause27606%_)))
                                      (declare (not safe))
                                      (##structure
                                       gerbil-ascent/candidate/grounding-plan#grounding-clause::t
                                       __tmp37062
                                       __tmp37061))))
                              _%body27603%_)))
                    (declare (not safe))
                    (##structure
                     gerbil-ascent/candidate/grounding-plan#grounding-rule::t
                     __tmp37064
                     __tmp37063
                     __tmp37058
                     _%label27602%_)))))
          (if (vector? _%$%rule2758827596%_)
              (if (let ((__tmp37065
                         (let ()
                           (declare (not safe))
                           (##vector-length _%$%rule2758827596%_))))
                    (declare (not safe))
                    (##fx= __tmp37065 '3))
                  (let* ((_%$%e2759227611%_
                          (let ()
                            (declare (not safe))
                            (##vector-ref _%$%rule2758827596%_ '0)))
                         (_%head27614%_ _%$%e2759227611%_)
                         (_%$%e2759327616%_
                          (let ()
                            (declare (not safe))
                            (##vector-ref _%$%rule2758827596%_ '1)))
                         (_%body27619%_ _%$%e2759327616%_)
                         (_%$%e2759427621%_
                          (let ()
                            (declare (not safe))
                            (##vector-ref _%$%rule2758827596%_ '2)))
                         (_%label27624%_ _%$%e2759427621%_))
                    (_%$%K2759127608%_
                     _%label27624%_
                     _%body27619%_
                     _%head27614%_))
                  (_%$%E2759027599%_))
              (_%$%E2759027599%_)))))
    (define gerbil-ascent/candidate/grounding-plan#prepare-grounding-head
      (lambda (_%head27573%_)
        (let ((_%getters27581%_
               (map (lambda (_%term27575%_)
                      (if (let ()
                            (declare (not safe))
                            (gerbil-ascent/candidate/program#candidate-variable?
                             _%term27575%_))
                          (lambda (_%bindings27577%_)
                            (cdr (assq _%term27575%_ _%bindings27577%_)))
                          (lambda (_%_27579%_) _%term27575%_)))
                    (cdr _%head27573%_))))
          (lambda (_%bindings27583%_)
            (let ((__tmp37066
                   (lambda (_%get27585%_) (_%get27585%_ _%bindings27583%_))))
              (declare (not safe))
              (##map __tmp37066 _%getters27581%_))))))
    (define gerbil-ascent/candidate/grounding-plan#prepare-grounding-fixed
      (lambda (_%clause27333%_)
        (let* ((_%$%clause2733427386%_ _%clause27333%_)
               (_%$%else2733927396%_
                (lambda ()
                  (lambda (_%bindings27394%_)
                    (let ()
                      (declare (not safe))
                      (gerbil-ascent/candidate/funs#candidate-fixed-clause
                       _%clause27333%_
                       _%bindings27394%_))))))
          (let ((_%$%K2737627548%_
                 (lambda (_%name27538%_)
                   (lambda (_%bindings27540%_)
                     (let ((_%$e27542%_
                            (assq _%name27538%_ _%bindings27540%_)))
                       (if _%$e27542%_
                           (if (exact-integer? (cdr _%$e27542%_))
                               (if (even? (cdr _%$e27542%_))
                                   _%bindings27540%_
                                   '#f)
                               '#f)
                           '#f)))))
                (_%$%K2736527503%_
                 (lambda (_%right27495%_ _%left27496%_)
                   (lambda (_%bindings27498%_)
                     (let ((_%a27500%_ (assq _%left27496%_ _%bindings27498%_))
                           (_%b27501%_
                            (assq _%right27495%_ _%bindings27498%_)))
                       (if _%a27500%_
                           (if _%b27501%_
                               (if (exact-integer? (cdr _%a27500%_))
                                   (if (exact-integer? (cdr _%b27501%_))
                                       (if (< (cdr _%a27500%_)
                                              (cdr _%b27501%_))
                                           _%bindings27498%_
                                           '#f)
                                       '#f)
                                   '#f)
                               '#f)
                           '#f)))))
                (_%$%K2735427459%_
                 (lambda (_%name27452%_ _%output27453%_)
                   (lambda (_%bindings27455%_)
                     (let ((_%input27457%_
                            (assq _%name27452%_ _%bindings27455%_)))
                       (if _%input27457%_
                           (if (assq _%output27453%_ _%bindings27455%_)
                               '#f
                               (cons (cons _%output27453%_
                                           (cdr _%input27457%_))
                                     _%bindings27455%_))
                           '#f)))))
                (_%$%K2734127409%_
                 (lambda (_%right27400%_ _%left27401%_ _%output27402%_)
                   (lambda (_%bindings27404%_)
                     (let ((_%a27406%_ (assq _%left27401%_ _%bindings27404%_))
                           (_%b27407%_
                            (assq _%right27400%_ _%bindings27404%_)))
                       (if _%a27406%_
                           (if _%b27407%_
                               (if (assq _%output27402%_ _%bindings27404%_)
                                   '#f
                                   (if (exact-integer? (cdr _%a27406%_))
                                       (if (exact-integer? (cdr _%b27407%_))
                                           (cons (cons _%output27402%_
                                                       (+ (cdr _%a27406%_)
                                                          (cdr _%b27407%_)))
                                                 _%bindings27404%_)
                                           '#f)
                                       '#f))
                               '#f)
                           '#f))))))
            (if (pair? _%$%clause2733427386%_)
                (let ((_%$%tl2737827553%_
                       (let ()
                         (declare (not safe))
                         (##cdr _%$%clause2733427386%_)))
                      (_%$%hd2737727551%_
                       (let ()
                         (declare (not safe))
                         (##car _%$%clause2733427386%_))))
                  (if (let ()
                        (declare (not safe))
                        (##eq? _%$%hd2737727551%_ 'where))
                      (if (pair? _%$%tl2737827553%_)
                          (let ((_%$%tl2738027558%_
                                 (let ()
                                   (declare (not safe))
                                   (##cdr _%$%tl2737827553%_)))
                                (_%$%hd2737927556%_
                                 (let ()
                                   (declare (not safe))
                                   (##car _%$%tl2737827553%_))))
                            (if (pair? _%$%hd2737927556%_)
                                (let ((_%$%tl2738227563%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%hd2737927556%_)))
                                      (_%$%hd2738127561%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%$%hd2737927556%_))))
                                  (if (let ()
                                        (declare (not safe))
                                        (##eq? _%$%hd2738127561%_ 'even?))
                                      (if (pair? _%$%tl2738227563%_)
                                          (let ((_%$%tl2738427568%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%tl2738227563%_)))
                                                (_%$%hd2738327566%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%tl2738227563%_))))
                                            (if (null? _%$%tl2738427568%_)
                                                (if (null? _%$%tl2738027558%_)
                                                    (let ((_%name27571%_
                                                           _%$%hd2738327566%_))
                                                      (_%$%K2737627548%_
                                                       _%name27571%_))
                                                    (_%$%else2733927396%_))
                                                (_%$%else2733927396%_)))
                                          (_%$%else2733927396%_))
                                      (if (let ()
                                            (declare (not safe))
                                            (##eq? _%$%hd2738127561%_ '<))
                                          (if (pair? _%$%tl2738227563%_)
                                              (let ((_%$%tl2737327523%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%tl2738227563%_)))
                                                    (_%$%hd2737227521%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%tl2738227563%_))))
                                                (if (pair? _%$%tl2737327523%_)
                                                    (let ((_%$%tl2737527530%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%tl2737327523%_)))
                                                          (_%$%hd2737427528%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%tl2737327523%_))))
                                                      (if (null? _%$%tl2737527530%_)
                                                          (if (null? _%$%tl2738027558%_)
                                                              (let ((_%left27526%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             _%$%hd2737227521%_)
                            (_%right27533%_ _%$%hd2737427528%_))
                        (_%$%K2736527503%_ _%right27533%_ _%left27526%_))
                      (_%$%else2733927396%_))
                  (_%$%else2733927396%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%else2733927396%_)))
                                              (_%$%else2733927396%_))
                                          (_%$%else2733927396%_))))
                                (_%$%else2733927396%_)))
                          (_%$%else2733927396%_))
                      (if (let ()
                            (declare (not safe))
                            (##eq? _%$%hd2737727551%_ 'compute))
                          (if (pair? _%$%tl2737827553%_)
                              (let ((_%$%tl2735827469%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%tl2737827553%_)))
                                    (_%$%hd2735727467%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%tl2737827553%_))))
                                (if (pair? _%$%tl2735827469%_)
                                    (let ((_%$%tl2736027476%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%tl2735827469%_)))
                                          (_%$%hd2735927474%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%tl2735827469%_))))
                                      (if (pair? _%$%hd2735927474%_)
                                          (let ((_%$%tl2736227481%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%hd2735927474%_)))
                                                (_%$%hd2736127479%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%hd2735927474%_))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (##eq? _%$%hd2736127479%_
                                                         'identity))
                                                (if (pair? _%$%tl2736227481%_)
                                                    (let ((_%$%tl2736427486%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%tl2736227481%_)))
                                                          (_%$%hd2736327484%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%tl2736227481%_))))
                                                      (if (null? _%$%tl2736427486%_)
                                                          (if (null? _%$%tl2736027476%_)
                                                              (let ((_%output27472%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             _%$%hd2735727467%_)
                            (_%name27489%_ _%$%hd2736327484%_))
                        (_%$%K2735427459%_ _%name27489%_ _%output27472%_))
                      (_%$%else2733927396%_))
                  (_%$%else2733927396%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%else2733927396%_))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (##eq? _%$%hd2736127479%_
                                                             '+))
                                                    (if (pair? _%$%tl2736227481%_)
                                                        (let ((_%$%tl2735127436%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (##cdr _%$%tl2736227481%_)))
                      (_%$%hd2735027434%_
                       (let ()
                         (declare (not safe))
                         (##car _%$%tl2736227481%_))))
                  (if (pair? _%$%tl2735127436%_)
                      (let ((_%$%tl2735327443%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%tl2735127436%_)))
                            (_%$%hd2735227441%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%tl2735127436%_))))
                        (if (null? _%$%tl2735327443%_)
                            (if (null? _%$%tl2736027476%_)
                                (let ((_%output27422%_ _%$%hd2735727467%_)
                                      (_%left27439%_ _%$%hd2735027434%_)
                                      (_%right27446%_ _%$%hd2735227441%_))
                                  (_%$%K2734127409%_
                                   _%right27446%_
                                   _%left27439%_
                                   _%output27422%_))
                                (_%$%else2733927396%_))
                            (_%$%else2733927396%_)))
                      (_%$%else2733927396%_)))
                (_%$%else2733927396%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%else2733927396%_))))
                                          (_%$%else2733927396%_)))
                                    (_%$%else2733927396%_)))
                              (_%$%else2733927396%_))
                          (_%$%else2733927396%_))))
                (_%$%else2733927396%_))))))))
