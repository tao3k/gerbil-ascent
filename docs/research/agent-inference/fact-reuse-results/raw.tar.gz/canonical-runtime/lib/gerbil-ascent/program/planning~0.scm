(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/planning::timestamp 1791691015)
  (begin
    (define gerbil-ascent/program/planning#gerbil-ascent-prepare-program
      (lambda (_%relations15401%_
               _%rules15402%_
               _%schema15403%_
               _%on-plan-error15404%_)
        (let* ((_%names15406%_ (vector-ref _%schema15403%_ '1))
               (_%arity15408%_ (vector-ref _%schema15403%_ '2))
               (_%positions15410%_ (vector-ref _%schema15403%_ '4))
               (_%kinds15412%_ (vector-ref _%schema15403%_ '8))
               (_%count15414%_ (vector-length _%names15406%_)))
          (letrec* ((_%position-of15417%_
                     (if (= _%count15414%_ '1)
                         (lambda (_%name15444%_)
                           (if (eq? _%name15444%_
                                    (vector-ref _%names15406%_ '0))
                               '0
                               (let ()
                                 (declare (not safe))
                                 (error '"unknown ASCENT relation"
                                        _%name15444%_))))
                         (lambda (_%name15446%_)
                           (let ((_%slot15448%_
                                  (let ()
                                    (declare (not safe))
                                    (hash-get
                                     _%positions15410%_
                                     _%name15446%_))))
                             (if _%slot15448%_
                                 '#!void
                                 (let ()
                                   (declare (not safe))
                                   (error '"unknown ASCENT relation"
                                          _%name15446%_)))
                             (- _%slot15448%_ '1)))))
                    (_%atom-plan15418%_
                     (lambda (_%atom15433%_)
                       (if (and (let ()
                                  (declare (not safe))
                                  (object? _%atom15433%_))
                                (let ((__tmp36689
                                       (let ()
                                         (declare (not safe))
                                         (clan/poo/object#.ref
                                          _%atom15433%_
                                          'ascent-clause-kind))))
                                  (declare (not safe))
                                  (##memq __tmp36689
                                          '(atom negation aggregate))))
                           '#!void
                           (let ()
                             (declare (not safe))
                             (error '"invalid ASCENT atom declaration"
                                    _%atom15433%_)))
                       (let* ((_%index15435%_
                               (_%position-of15417%_
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/object#.ref
                                   _%atom15433%_
                                   'relation))))
                              (_%terms15437%_
                               (let ()
                                 (declare (not safe))
                                 (clan/poo/object#.ref _%atom15433%_ 'terms))))
                         (if (and (list? _%terms15437%_)
                                  (= (let ()
                                       (declare (not safe))
                                       (##length _%terms15437%_))
                                     (vector-ref
                                      _%arity15408%_
                                      _%index15435%_)))
                             '#!void
                             (let ((__tmp36690
                                    (let ()
                                      (declare (not safe))
                                      (clan/poo/object#.ref
                                       _%atom15433%_
                                       'relation))))
                               (declare (not safe))
                               (error '"ASCENT atom arity mismatch"
                                      __tmp36690)))
                         (vector _%index15435%_
                                 (map (lambda (_%term15440%_)
                                        (let ((_%kind15442%_
                                               (let ()
                                                 (declare (not safe))
                                                 (clan/poo/object#.ref
                                                  _%term15440%_
                                                  'kind))))
                                          (if (let ()
                                                (declare (not safe))
                                                (##memq _%kind15442%_
                                                        '(variable
                                                          wildcard
                                                          literal
                                                          expression
                                                          pattern)))
                                              '#!void
                                              (let ()
                                                (declare (not safe))
                                                (error '"invalid ASCENT rule term"
                                                       _%kind15442%_)))
                                          (cons _%kind15442%_
                                                (let ()
                                                  (declare (not safe))
                                                  (clan/poo/object#.ref
                                                   _%term15440%_
                                                   'value)))))
                                      _%terms15437%_))))))
            (let* ((_%plans15423%_
                    (map (lambda (_%rule15420%_ _%index15421%_)
                           (gerbil-ascent/program/planning#gerbil-ascent-prepare-rule
                            _%rule15420%_
                            _%index15421%_
                            _%atom-plan15418%_
                            _%on-plan-error15404%_))
                         _%rules15402%_
                         (let ((__tmp36691 (length _%rules15402%_)))
                           (declare (not safe))
                           (##iota __tmp36691))))
                   (_%strata15428%_
                    (let ((__tmp36693
                           (lambda (_%failure15425%_)
                             (gerbil-ascent/program/planning#plan-failure
                              _%on-plan-error15404%_
                              '(program dependencies)
                              _%failure15425%_)))
                          (__tmp36692
                           (lambda ()
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/core/rule-semantics#gerbil-ascent-rule-strata
                                _%plans15423%_
                                _%count15414%_
                                _%kinds15412%_)))))
                      (declare (not safe))
                      (__with-catch __tmp36693 __tmp36692)))
                   (_%active15431%_
                    (gerbil-ascent/program/planning#active-rules
                     _%plans15423%_
                     _%strata15428%_)))
              (vector _%relations15401%_
                      _%rules15402%_
                      _%plans15423%_
                      _%strata15428%_
                      _%active15431%_
                      (let ()
                        (declare (not safe))
                        (gerbil-ascent/core/positive-plan#gerbil-ascent-prepare-rule-activations
                         _%active15431%_))
                      (let ()
                        (declare (not safe))
                        (gerbil-ascent/core/rule-semantics#gerbil-ascent-rule-successors
                         _%plans15423%_
                         _%count15414%_))))))))
    (define gerbil-ascent/program/planning#active-rules
      (lambda (_%plans15380%_ _%strata15381%_)
        (let* ((_%highest15383%_
                (if (zero? (vector-length _%strata15381%_))
                    '-1
                    (let ((__tmp36694 (vector->list _%strata15381%_)))
                      (declare (not safe))
                      (##apply max __tmp36694))))
               (_%active15385%_ (make-vector (+ _%highest15383%_ '1) '())))
          (for-each
           (lambda (_%rule15388%_)
             (let ((_%heads-by-stratum15390%_
                    (let () (declare (not safe)) (make-hash-table-eqv))))
               (for-each
                (lambda (_%head15392%_)
                  (let ((__tmp36696
                         (vector-ref
                          _%strata15381%_
                          (vector-ref _%head15392%_ '0)))
                        (__tmp36695
                         (lambda (_%$%g1539315395%_)
                           (cons _%head15392%_ _%$%g1539315395%_))))
                    (declare (not safe))
                    (__hash-update!__%
                     _%heads-by-stratum15390%_
                     __tmp36696
                     __tmp36695
                     '())))
                (vector-ref _%rule15388%_ '0))
               (let ((__tmp36697
                      (lambda (_%stratum15398%_ _%heads15399%_)
                        (vector-set!
                         _%active15385%_
                         _%stratum15398%_
                         (cons (vector (reverse _%heads15399%_)
                                       (vector-ref _%rule15388%_ '1)
                                       (let ((__tmp36698
                                              (vector-ref _%rule15388%_ '1)))
                                         (declare (not safe))
                                         (gerbil-ascent/core/rule-semantics#gerbil-ascent-delta-positions
                                          __tmp36698
                                          _%strata15381%_
                                          _%stratum15398%_))
                                       (vector-ref _%rule15388%_ '3))
                               (vector-ref
                                _%active15385%_
                                _%stratum15398%_))))))
                 (declare (not safe))
                 (__hash-for-each __tmp36697 _%heads-by-stratum15390%_))))
           _%plans15380%_)
          (vector-map reverse _%active15385%_))))
    (define gerbil-ascent/program/planning#plan-failure
      (lambda (_%callback15376%_ _%path15377%_ _%failure15378%_)
        (if _%callback15376%_
            (_%callback15376%_ _%path15377%_ _%failure15378%_)
            '#!void)
        (let () (declare (not safe)) (raise _%failure15378%_))))
    (define gerbil-ascent/program/planning#head-plan
      (lambda (_%head15363%_ _%bound?15364%_ _%atom-plan15365%_)
        (if (and (let () (declare (not safe)) (object? _%head15363%_))
                 (eq? (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref
                         _%head15363%_
                         'ascent-clause-kind))
                      'atom))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT rule head" _%head15363%_)))
        (let ((_%plan15367%_ (_%atom-plan15365%_ _%head15363%_)))
          (for-each
           (lambda (_%term15369%_)
             (let ((_%$e15371%_ (car _%term15369%_)))
               (if (eq? 'variable _%$e15371%_)
                   (if (_%bound?15364%_ (cdr _%term15369%_))
                       '#!void
                       (let ((__tmp36699 (cdr _%term15369%_)))
                         (declare (not safe))
                         (error '"unsafe ASCENT head variable" __tmp36699)))
                   (if (eq? 'expression _%$e15371%_)
                       (for-each
                        (lambda (_%name15374%_)
                          (if (_%bound?15364%_ _%name15374%_)
                              '#!void
                              (let ()
                                (declare (not safe))
                                (error '"unsafe ASCENT head expression variable"
                                       _%name15374%_))))
                        (vector-ref (cdr _%term15369%_) '0))
                       (if (eq? 'pattern _%$e15371%_)
                           (let ()
                             (declare (not safe))
                             (error '"ASCENT pattern is invalid in a rule head"))
                           (if (eq? 'wildcard _%$e15371%_)
                               (let ()
                                 (declare (not safe))
                                 (error '"ASCENT wildcard is invalid in a rule head"))
                               '#!void))))))
           (vector-ref _%plan15367%_ '1))
          _%plan15367%_)))
    (define gerbil-ascent/program/planning#gerbil-ascent-prepare-rule
      (lambda (_%rule15328%_
               _%rule-index15329%_
               _%atom-plan15330%_
               _%on-plan-error15331%_)
        (if (let () (declare (not safe)) (object? _%rule15328%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT rule declaration" _%rule15328%_)))
        (let* ((_%body15333%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%rule15328%_ 'body)))
               (_%heads15335%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%rule15328%_ 'heads)))
               (_%bound15337%_ '())
               (_%atoms15339%_ '0)
               (_%body-plans15341%_ '()))
          (if (and (list? _%body15333%_) (pair? _%heads15335%_) '#t)
              '#!void
              (let ()
                (declare (not safe))
                (error '"invalid ASCENT rule declaration" _%rule15328%_)))
          (for-each
           (lambda (_%clause15344%_ _%clause-index15345%_)
             (let ((__tmp36701
                    (lambda (_%failure15347%_)
                      (gerbil-ascent/program/planning#plan-failure
                       _%on-plan-error15331%_
                       (list 'rule
                             _%rule-index15329%_
                             'body
                             _%clause-index15345%_)
                       _%failure15347%_)))
                   (__tmp36700
                    (lambda ()
                      (if (let ()
                            (declare (not safe))
                            (object? _%clause15344%_))
                          '#!void
                          (let ()
                            (declare (not safe))
                            (error '"invalid ASCENT rule clause"
                                   _%clause15344%_)))
                      (let ((_%result15350%_
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/program/objects#gerbil-ascent-clause-plan
                                _%clause15344%_
                                _%atom-plan15330%_
                                _%bound15337%_))))
                        (set! _%body-plans15341%_
                              (cons (vector-ref _%result15350%_ '0)
                                    _%body-plans15341%_))
                        (set! _%bound15337%_ (vector-ref _%result15350%_ '1))
                        (set! _%atoms15339%_
                              (+ _%atoms15339%_
                                 (vector-ref _%result15350%_ '2)))))))
               (declare (not safe))
               (__with-catch __tmp36701 __tmp36700)))
           _%body15333%_
           (let ((__tmp36702 (length _%body15333%_)))
             (declare (not safe))
             (##iota __tmp36702)))
          (let* ((_%bound?15352%_
                  (let ()
                    (declare (not safe))
                    (gerbil-ascent/program/objects#gerbil-ascent-bound-membership
                     _%bound15337%_)))
                 (_%planned-heads15360%_
                  (map (lambda (_%head15354%_ _%head-index15355%_)
                         (let ((__tmp36704
                                (lambda (_%failure15357%_)
                                  (gerbil-ascent/program/planning#plan-failure
                                   _%on-plan-error15331%_
                                   (list 'rule
                                         _%rule-index15329%_
                                         'head
                                         _%head-index15355%_)
                                   _%failure15357%_)))
                               (__tmp36703
                                (lambda ()
                                  (gerbil-ascent/program/planning#head-plan
                                   _%head15354%_
                                   _%bound?15352%_
                                   _%atom-plan15330%_))))
                           (declare (not safe))
                           (__with-catch __tmp36704 __tmp36703)))
                       _%heads15335%_
                       (let ((__tmp36705 (length _%heads15335%_)))
                         (declare (not safe))
                         (##iota __tmp36705)))))
            (vector _%planned-heads15360%_
                    (let ()
                      (declare (not safe))
                      (##reverse _%body-plans15341%_))
                    _%atoms15339%_
                    _%rule-index15329%_)))))))
