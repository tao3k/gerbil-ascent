(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/candidate/types")
    (load-module "gerbil-ascent/candidate/program"))
  (load-module "gerbil-ascent/candidate/funs~0"))
