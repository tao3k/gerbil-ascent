(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "clan/poo/object")
    (load-module "clan/poo/mop")
    (load-module "core/types")
    (load-module "gerbil-ascent/table/provider")
    (load-module "gerbil-ascent/table/storage"))
  (load-module "gerbil-ascent/program/types~0"))
