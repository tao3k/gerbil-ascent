(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33887_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-flow::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33889_|
    (##structure
     gx#syntax-quote::t
     'make-proof-binding-flow
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33891_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-flow?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33893_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-flow-fresh
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33894_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-flow-head
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33895_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-flow-clauses
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33897_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-flow-fresh-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33898_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-flow-head-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33899_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-flow-clauses-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33901_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-flow-fresh
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33902_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-flow-head
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33903_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-flow-clauses
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33905_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-flow-fresh-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33906_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-flow-head-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33907_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-flow-clauses-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33909_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-clause::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33911_|
    (##structure
     gx#syntax-quote::t
     'make-proof-binding-clause
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33913_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-clause?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33915_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-clause-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33916_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-clause-apply
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33918_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-clause-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33919_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-clause-apply-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33921_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-clause-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33922_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-clause-apply
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33924_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-clause-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33925_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-clause-apply-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33927_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-term::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33929_|
    (##structure
     gx#syntax-quote::t
     'make-proof-binding-term
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33931_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-term?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33933_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-term-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33934_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-term-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33936_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-term-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33937_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-term-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33939_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-term-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33940_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-term-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33942_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-term-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33943_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-term-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/proof-frame[:0:]#proof-binding-flow|
      (let ((__obj33867
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33867
           'gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33867
           'proof-binding-flow
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33867
           '(fresh head clauses)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33867
           '(fresh head clauses)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33867 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33867 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33867 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33867 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33867 '#f '13 '#f '#f))
        (let ((__tmp33886 |gerbil-ascent/candidate/proof-frame[1]#_g33887_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33867 __tmp33886 '4 '#f '#f))
        (let ((__tmp33888 |gerbil-ascent/candidate/proof-frame[1]#_g33889_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33867 __tmp33888 '14 '#f '#f))
        (let ((__tmp33890 |gerbil-ascent/candidate/proof-frame[1]#_g33891_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33867 __tmp33890 '15 '#f '#f))
        (let ((__tmp33892
               (cons (cons 'fresh
                           |gerbil-ascent/candidate/proof-frame[1]#_g33893_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33894_|)
                           (cons (cons 'clauses
                                       |gerbil-ascent/candidate/proof-frame[1]#_g33895_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33867 __tmp33892 '16 '#f '#f))
        (let ((__tmp33896
               (cons (cons 'fresh
                           |gerbil-ascent/candidate/proof-frame[1]#_g33897_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33898_|)
                           (cons (cons 'clauses
                                       |gerbil-ascent/candidate/proof-frame[1]#_g33899_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33867 __tmp33896 '17 '#f '#f))
        (let ((__tmp33900
               (cons (cons 'fresh
                           |gerbil-ascent/candidate/proof-frame[1]#_g33901_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33902_|)
                           (cons (cons 'clauses
                                       |gerbil-ascent/candidate/proof-frame[1]#_g33903_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33867 __tmp33900 '18 '#f '#f))
        (let ((__tmp33904
               (cons (cons 'fresh
                           |gerbil-ascent/candidate/proof-frame[1]#_g33905_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33906_|)
                           (cons (cons 'clauses
                                       |gerbil-ascent/candidate/proof-frame[1]#_g33907_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33867 __tmp33904 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33867 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33867 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33867 '() '21 '#f '#f))
        __obj33867))
    (define |gerbil-ascent/candidate/proof-frame[:0:]#proof-binding-clause|
      (let ((__obj33868
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33868
           'gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33868
           'proof-binding-clause
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33868 '(relation apply) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33868 '(relation apply) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33868 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33868 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33868 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33868 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33868 '#f '13 '#f '#f))
        (let ((__tmp33908 |gerbil-ascent/candidate/proof-frame[1]#_g33909_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33868 __tmp33908 '4 '#f '#f))
        (let ((__tmp33910 |gerbil-ascent/candidate/proof-frame[1]#_g33911_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33868 __tmp33910 '14 '#f '#f))
        (let ((__tmp33912 |gerbil-ascent/candidate/proof-frame[1]#_g33913_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33868 __tmp33912 '15 '#f '#f))
        (let ((__tmp33914
               (cons (cons 'relation
                           |gerbil-ascent/candidate/proof-frame[1]#_g33915_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33916_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33868 __tmp33914 '16 '#f '#f))
        (let ((__tmp33917
               (cons (cons 'relation
                           |gerbil-ascent/candidate/proof-frame[1]#_g33918_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33919_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33868 __tmp33917 '17 '#f '#f))
        (let ((__tmp33920
               (cons (cons 'relation
                           |gerbil-ascent/candidate/proof-frame[1]#_g33921_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33922_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33868 __tmp33920 '18 '#f '#f))
        (let ((__tmp33923
               (cons (cons 'relation
                           |gerbil-ascent/candidate/proof-frame[1]#_g33924_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33925_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33868 __tmp33923 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33868 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33868 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33868 '() '21 '#f '#f))
        __obj33868))
    (define |gerbil-ascent/candidate/proof-frame[:0:]#proof-binding-term|
      (let ((__obj33869
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33869
           'gerbil-ascent/candidate/proof-frame#proof-binding-term::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33869
           'proof-binding-term
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33869 '(kind value) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33869 '(kind value) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33869 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33869 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33869 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33869 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33869 '#f '13 '#f '#f))
        (let ((__tmp33926 |gerbil-ascent/candidate/proof-frame[1]#_g33927_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33869 __tmp33926 '4 '#f '#f))
        (let ((__tmp33928 |gerbil-ascent/candidate/proof-frame[1]#_g33929_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33869 __tmp33928 '14 '#f '#f))
        (let ((__tmp33930 |gerbil-ascent/candidate/proof-frame[1]#_g33931_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33869 __tmp33930 '15 '#f '#f))
        (let ((__tmp33932
               (cons (cons 'kind
                           |gerbil-ascent/candidate/proof-frame[1]#_g33933_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33934_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33869 __tmp33932 '16 '#f '#f))
        (let ((__tmp33935
               (cons (cons 'kind
                           |gerbil-ascent/candidate/proof-frame[1]#_g33936_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33937_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33869 __tmp33935 '17 '#f '#f))
        (let ((__tmp33938
               (cons (cons 'kind
                           |gerbil-ascent/candidate/proof-frame[1]#_g33939_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33940_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33869 __tmp33938 '18 '#f '#f))
        (let ((__tmp33941
               (cons (cons 'kind
                           |gerbil-ascent/candidate/proof-frame[1]#_g33942_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33943_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33869 __tmp33941 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33869 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33869 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33869 '() '21 '#f '#f))
        __obj33869))))
