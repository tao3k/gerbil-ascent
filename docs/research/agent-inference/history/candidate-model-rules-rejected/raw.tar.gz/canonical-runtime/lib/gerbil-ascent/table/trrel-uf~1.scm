(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/trrel-uf[1]#_g34223_|
    (##structure
     gx#syntax-quote::t
     'uf-node::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34225_|
    (##structure
     gx#syntax-quote::t
     'make-uf-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34227_|
    (##structure
     gx#syntax-quote::t
     'uf-node?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34229_|
    (##structure
     gx#syntax-quote::t
     'uf-node-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34230_|
    (##structure
     gx#syntax-quote::t
     'uf-node-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34231_|
    (##structure
     gx#syntax-quote::t
     'uf-node-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34232_|
    (##structure
     gx#syntax-quote::t
     'uf-node-reach
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34233_|
    (##structure
     gx#syntax-quote::t
     'uf-node-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34234_|
    (##structure
     gx#syntax-quote::t
     'uf-node-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34236_|
    (##structure
     gx#syntax-quote::t
     'uf-node-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34237_|
    (##structure
     gx#syntax-quote::t
     'uf-node-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34238_|
    (##structure
     gx#syntax-quote::t
     'uf-node-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34239_|
    (##structure
     gx#syntax-quote::t
     'uf-node-reach-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34240_|
    (##structure
     gx#syntax-quote::t
     'uf-node-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34241_|
    (##structure
     gx#syntax-quote::t
     'uf-node-order-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34243_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34244_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34245_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34246_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-reach
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34247_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34248_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34250_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34251_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34252_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34253_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-reach-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34254_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34255_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-order-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34257_|
    (##structure
     gx#syntax-quote::t
     'uf-group::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34259_|
    (##structure
     gx#syntax-quote::t
     'make-uf-group
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34261_|
    (##structure
     gx#syntax-quote::t
     'uf-group?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34263_|
    (##structure
     gx#syntax-quote::t
     'uf-group-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34264_|
    (##structure
     gx#syntax-quote::t
     'uf-group-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34265_|
    (##structure
     gx#syntax-quote::t
     'uf-group-next-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34266_|
    (##structure
     gx#syntax-quote::t
     'uf-group-indexed?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34268_|
    (##structure
     gx#syntax-quote::t
     'uf-group-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34269_|
    (##structure
     gx#syntax-quote::t
     'uf-group-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34270_|
    (##structure
     gx#syntax-quote::t
     'uf-group-next-order-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34271_|
    (##structure
     gx#syntax-quote::t
     'uf-group-indexed?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34273_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34274_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34275_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-next-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34276_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-indexed?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34278_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34279_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34280_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-next-order-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34281_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-indexed?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34283_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34285_|
    (##structure
     gx#syntax-quote::t
     'make-uf-insertion
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34287_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34289_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-group-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34290_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-group
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34291_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34292_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-left-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34293_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-right-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34294_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-a
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34295_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-b
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34297_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-group-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34298_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-group-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34299_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34300_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-left-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34301_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-right-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34302_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-a-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34303_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-b-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34305_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-group-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34306_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-group
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34307_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34308_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-left-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34309_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-right-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34310_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-a
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34311_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-b
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34313_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-group-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34314_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-group-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34315_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34316_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-left-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34317_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-right-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34318_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-a-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34319_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-b-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34321_|
    (##structure
     gx#syntax-quote::t
     'frozen-members::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34323_|
    (##structure
     gx#syntax-quote::t
     'make-frozen-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34325_|
    (##structure
     gx#syntax-quote::t
     'frozen-members?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34327_|
    (##structure
     gx#syntax-quote::t
     'frozen-members-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34328_|
    (##structure
     gx#syntax-quote::t
     'frozen-members-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34330_|
    (##structure
     gx#syntax-quote::t
     'frozen-members-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34331_|
    (##structure
     gx#syntax-quote::t
     'frozen-members-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34333_|
    (##structure
     gx#syntax-quote::t
     '&frozen-members-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34334_|
    (##structure
     gx#syntax-quote::t
     '&frozen-members-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34336_|
    (##structure
     gx#syntax-quote::t
     '&frozen-members-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34337_|
    (##structure
     gx#syntax-quote::t
     '&frozen-members-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/table/trrel-uf[:0:]#uf-node|
      (let ((__obj34024
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34024
           'gerbil-ascent/table/trrel-uf#uf-node::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34024 'uf-node '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34024
           '(parent members size reach predecessors order)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34024
           '(parent members size reach predecessors order)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34024 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34024 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34024 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34024 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34024 '#f '13 '#f '#f))
        (let ((__tmp34222 |gerbil-ascent/table/trrel-uf[1]#_g34223_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34024 __tmp34222 '4 '#f '#f))
        (let ((__tmp34224 |gerbil-ascent/table/trrel-uf[1]#_g34225_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34024 __tmp34224 '14 '#f '#f))
        (let ((__tmp34226 |gerbil-ascent/table/trrel-uf[1]#_g34227_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34024 __tmp34226 '15 '#f '#f))
        (let ((__tmp34228
               (cons (cons 'parent |gerbil-ascent/table/trrel-uf[1]#_g34229_|)
                     (cons (cons 'members
                                 |gerbil-ascent/table/trrel-uf[1]#_g34230_|)
                           (cons (cons 'size
                                       |gerbil-ascent/table/trrel-uf[1]#_g34231_|)
                                 (cons (cons 'reach
                                             |gerbil-ascent/table/trrel-uf[1]#_g34232_|)
                                       (cons (cons 'predecessors
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34233_|)
                                             (cons (cons 'order
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34234_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34024 __tmp34228 '16 '#f '#f))
        (let ((__tmp34235
               (cons (cons 'parent |gerbil-ascent/table/trrel-uf[1]#_g34236_|)
                     (cons (cons 'members
                                 |gerbil-ascent/table/trrel-uf[1]#_g34237_|)
                           (cons (cons 'size
                                       |gerbil-ascent/table/trrel-uf[1]#_g34238_|)
                                 (cons (cons 'reach
                                             |gerbil-ascent/table/trrel-uf[1]#_g34239_|)
                                       (cons (cons 'predecessors
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34240_|)
                                             (cons (cons 'order
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34241_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34024 __tmp34235 '17 '#f '#f))
        (let ((__tmp34242
               (cons (cons 'parent |gerbil-ascent/table/trrel-uf[1]#_g34243_|)
                     (cons (cons 'members
                                 |gerbil-ascent/table/trrel-uf[1]#_g34244_|)
                           (cons (cons 'size
                                       |gerbil-ascent/table/trrel-uf[1]#_g34245_|)
                                 (cons (cons 'reach
                                             |gerbil-ascent/table/trrel-uf[1]#_g34246_|)
                                       (cons (cons 'predecessors
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34247_|)
                                             (cons (cons 'order
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34248_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34024 __tmp34242 '18 '#f '#f))
        (let ((__tmp34249
               (cons (cons 'parent |gerbil-ascent/table/trrel-uf[1]#_g34250_|)
                     (cons (cons 'members
                                 |gerbil-ascent/table/trrel-uf[1]#_g34251_|)
                           (cons (cons 'size
                                       |gerbil-ascent/table/trrel-uf[1]#_g34252_|)
                                 (cons (cons 'reach
                                             |gerbil-ascent/table/trrel-uf[1]#_g34253_|)
                                       (cons (cons 'predecessors
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34254_|)
                                             (cons (cons 'order
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34255_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34024 __tmp34249 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34024 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34024 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34024 '() '21 '#f '#f))
        __obj34024))
    (define |gerbil-ascent/table/trrel-uf[:0:]#uf-group|
      (let ((__obj34025
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34025
           'gerbil-ascent/table/trrel-uf#uf-group::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34025 'uf-group '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34025
           '(nodes roots next-order indexed?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34025
           '(nodes roots next-order indexed?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34025 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34025 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34025 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34025 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34025 '#f '13 '#f '#f))
        (let ((__tmp34256 |gerbil-ascent/table/trrel-uf[1]#_g34257_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34025 __tmp34256 '4 '#f '#f))
        (let ((__tmp34258 |gerbil-ascent/table/trrel-uf[1]#_g34259_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34025 __tmp34258 '14 '#f '#f))
        (let ((__tmp34260 |gerbil-ascent/table/trrel-uf[1]#_g34261_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34025 __tmp34260 '15 '#f '#f))
        (let ((__tmp34262
               (cons (cons 'nodes |gerbil-ascent/table/trrel-uf[1]#_g34263_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/table/trrel-uf[1]#_g34264_|)
                           (cons (cons 'next-order
                                       |gerbil-ascent/table/trrel-uf[1]#_g34265_|)
                                 (cons (cons 'indexed?
                                             |gerbil-ascent/table/trrel-uf[1]#_g34266_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34025 __tmp34262 '16 '#f '#f))
        (let ((__tmp34267
               (cons (cons 'nodes |gerbil-ascent/table/trrel-uf[1]#_g34268_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/table/trrel-uf[1]#_g34269_|)
                           (cons (cons 'next-order
                                       |gerbil-ascent/table/trrel-uf[1]#_g34270_|)
                                 (cons (cons 'indexed?
                                             |gerbil-ascent/table/trrel-uf[1]#_g34271_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34025 __tmp34267 '17 '#f '#f))
        (let ((__tmp34272
               (cons (cons 'nodes |gerbil-ascent/table/trrel-uf[1]#_g34273_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/table/trrel-uf[1]#_g34274_|)
                           (cons (cons 'next-order
                                       |gerbil-ascent/table/trrel-uf[1]#_g34275_|)
                                 (cons (cons 'indexed?
                                             |gerbil-ascent/table/trrel-uf[1]#_g34276_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34025 __tmp34272 '18 '#f '#f))
        (let ((__tmp34277
               (cons (cons 'nodes |gerbil-ascent/table/trrel-uf[1]#_g34278_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/table/trrel-uf[1]#_g34279_|)
                           (cons (cons 'next-order
                                       |gerbil-ascent/table/trrel-uf[1]#_g34280_|)
                                 (cons (cons 'indexed?
                                             |gerbil-ascent/table/trrel-uf[1]#_g34281_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34025 __tmp34277 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34025 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34025 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34025 '() '21 '#f '#f))
        __obj34025))
    (define |gerbil-ascent/table/trrel-uf[:0:]#uf-insertion|
      (let ((__obj34026
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34026
           'gerbil-ascent/table/trrel-uf#uf-insertion::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34026 'uf-insertion '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34026
           '(group-key group row left-node right-node a b)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34026
           '(group-key group row left-node right-node a b)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34026 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34026 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34026 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34026 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34026 '#f '13 '#f '#f))
        (let ((__tmp34282 |gerbil-ascent/table/trrel-uf[1]#_g34283_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34026 __tmp34282 '4 '#f '#f))
        (let ((__tmp34284 |gerbil-ascent/table/trrel-uf[1]#_g34285_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34026 __tmp34284 '14 '#f '#f))
        (let ((__tmp34286 |gerbil-ascent/table/trrel-uf[1]#_g34287_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34026 __tmp34286 '15 '#f '#f))
        (let ((__tmp34288
               (cons (cons 'group-key
                           |gerbil-ascent/table/trrel-uf[1]#_g34289_|)
                     (cons (cons 'group
                                 |gerbil-ascent/table/trrel-uf[1]#_g34290_|)
                           (cons (cons 'row
                                       |gerbil-ascent/table/trrel-uf[1]#_g34291_|)
                                 (cons (cons 'left-node
                                             |gerbil-ascent/table/trrel-uf[1]#_g34292_|)
                                       (cons (cons 'right-node
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34293_|)
                                             (cons (cons 'a
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34294_|)
                                                   (cons (cons 'b
                                                               |gerbil-ascent/table/trrel-uf[1]#_g34295_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34026 __tmp34288 '16 '#f '#f))
        (let ((__tmp34296
               (cons (cons 'group-key
                           |gerbil-ascent/table/trrel-uf[1]#_g34297_|)
                     (cons (cons 'group
                                 |gerbil-ascent/table/trrel-uf[1]#_g34298_|)
                           (cons (cons 'row
                                       |gerbil-ascent/table/trrel-uf[1]#_g34299_|)
                                 (cons (cons 'left-node
                                             |gerbil-ascent/table/trrel-uf[1]#_g34300_|)
                                       (cons (cons 'right-node
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34301_|)
                                             (cons (cons 'a
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34302_|)
                                                   (cons (cons 'b
                                                               |gerbil-ascent/table/trrel-uf[1]#_g34303_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34026 __tmp34296 '17 '#f '#f))
        (let ((__tmp34304
               (cons (cons 'group-key
                           |gerbil-ascent/table/trrel-uf[1]#_g34305_|)
                     (cons (cons 'group
                                 |gerbil-ascent/table/trrel-uf[1]#_g34306_|)
                           (cons (cons 'row
                                       |gerbil-ascent/table/trrel-uf[1]#_g34307_|)
                                 (cons (cons 'left-node
                                             |gerbil-ascent/table/trrel-uf[1]#_g34308_|)
                                       (cons (cons 'right-node
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34309_|)
                                             (cons (cons 'a
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34310_|)
                                                   (cons (cons 'b
                                                               |gerbil-ascent/table/trrel-uf[1]#_g34311_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34026 __tmp34304 '18 '#f '#f))
        (let ((__tmp34312
               (cons (cons 'group-key
                           |gerbil-ascent/table/trrel-uf[1]#_g34313_|)
                     (cons (cons 'group
                                 |gerbil-ascent/table/trrel-uf[1]#_g34314_|)
                           (cons (cons 'row
                                       |gerbil-ascent/table/trrel-uf[1]#_g34315_|)
                                 (cons (cons 'left-node
                                             |gerbil-ascent/table/trrel-uf[1]#_g34316_|)
                                       (cons (cons 'right-node
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34317_|)
                                             (cons (cons 'a
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34318_|)
                                                   (cons (cons 'b
                                                               |gerbil-ascent/table/trrel-uf[1]#_g34319_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34026 __tmp34312 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34026 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34026 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34026 '() '21 '#f '#f))
        __obj34026))
    (define |gerbil-ascent/table/trrel-uf[:0:]#frozen-members|
      (let ((__obj34027
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34027
           'gerbil-ascent/table/trrel-uf#frozen-members::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34027 'frozen-members '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34027 '(rows count) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34027 '(rows count) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34027 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34027 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34027 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34027 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34027 '#f '13 '#f '#f))
        (let ((__tmp34320 |gerbil-ascent/table/trrel-uf[1]#_g34321_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34027 __tmp34320 '4 '#f '#f))
        (let ((__tmp34322 |gerbil-ascent/table/trrel-uf[1]#_g34323_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34027 __tmp34322 '14 '#f '#f))
        (let ((__tmp34324 |gerbil-ascent/table/trrel-uf[1]#_g34325_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34027 __tmp34324 '15 '#f '#f))
        (let ((__tmp34326
               (cons (cons 'rows |gerbil-ascent/table/trrel-uf[1]#_g34327_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/trrel-uf[1]#_g34328_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34027 __tmp34326 '16 '#f '#f))
        (let ((__tmp34329
               (cons (cons 'rows |gerbil-ascent/table/trrel-uf[1]#_g34330_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/trrel-uf[1]#_g34331_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34027 __tmp34329 '17 '#f '#f))
        (let ((__tmp34332
               (cons (cons 'rows |gerbil-ascent/table/trrel-uf[1]#_g34333_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/trrel-uf[1]#_g34334_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34027 __tmp34332 '18 '#f '#f))
        (let ((__tmp34335
               (cons (cons 'rows |gerbil-ascent/table/trrel-uf[1]#_g34336_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/trrel-uf[1]#_g34337_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34027 __tmp34335 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34027 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34027 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34027 '() '21 '#f '#f))
        __obj34027))))
