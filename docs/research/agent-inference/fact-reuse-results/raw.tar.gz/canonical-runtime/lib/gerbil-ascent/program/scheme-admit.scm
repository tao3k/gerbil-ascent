(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/program/objects")
    (load-module "gerbil-ascent/program/types")
    (load-module "gerbil-ascent/program/scheme-snapshot")
    (load-module "gerbil-ascent/program/scheme-query")
    (load-module "gerbil-ascent/program/evaluate")
    (load-module "clan/poo/object")
    (load-module "clan/poo/mop")
    (load-module "std/error")
    (load-module "std/list/list"))
  (load-module "gerbil-ascent/program/scheme-admit~0"))
