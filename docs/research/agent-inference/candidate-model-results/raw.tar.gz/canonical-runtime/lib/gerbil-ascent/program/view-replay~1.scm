(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/view-replay[1]#_g33951_|
    (##structure
     gx#syntax-quote::t
     'replay-node::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33953_|
    (##structure
     gx#syntax-quote::t
     'make-replay-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33955_|
    (##structure
     gx#syntax-quote::t
     'replay-node?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33957_|
    (##structure
     gx#syntax-quote::t
     'replay-node-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33958_|
    (##structure
     gx#syntax-quote::t
     'replay-node-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33959_|
    (##structure
     gx#syntax-quote::t
     'replay-node-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33961_|
    (##structure
     gx#syntax-quote::t
     'replay-node-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33962_|
    (##structure
     gx#syntax-quote::t
     'replay-node-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33963_|
    (##structure
     gx#syntax-quote::t
     'replay-node-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33965_|
    (##structure
     gx#syntax-quote::t
     '&replay-node-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33966_|
    (##structure
     gx#syntax-quote::t
     '&replay-node-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33967_|
    (##structure
     gx#syntax-quote::t
     '&replay-node-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33969_|
    (##structure
     gx#syntax-quote::t
     '&replay-node-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33970_|
    (##structure
     gx#syntax-quote::t
     '&replay-node-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33971_|
    (##structure
     gx#syntax-quote::t
     '&replay-node-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33973_|
    (##structure
     gx#syntax-quote::t
     'replay-group::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33975_|
    (##structure
     gx#syntax-quote::t
     'make-replay-group
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33977_|
    (##structure
     gx#syntax-quote::t
     'replay-group?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33979_|
    (##structure
     gx#syntax-quote::t
     'replay-group-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33980_|
    (##structure
     gx#syntax-quote::t
     'replay-group-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33981_|
    (##structure
     gx#syntax-quote::t
     'replay-group-values
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33982_|
    (##structure
     gx#syntax-quote::t
     'replay-group-used
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33983_|
    (##structure
     gx#syntax-quote::t
     'replay-group-width
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33984_|
    (##structure
     gx#syntax-quote::t
     'replay-group-bits
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33986_|
    (##structure
     gx#syntax-quote::t
     'replay-group-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33987_|
    (##structure
     gx#syntax-quote::t
     'replay-group-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33988_|
    (##structure
     gx#syntax-quote::t
     'replay-group-values-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33989_|
    (##structure
     gx#syntax-quote::t
     'replay-group-used-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33990_|
    (##structure
     gx#syntax-quote::t
     'replay-group-width-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33991_|
    (##structure
     gx#syntax-quote::t
     'replay-group-bits-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33993_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33994_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33995_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-values
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33996_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-used
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33997_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-width
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g33998_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-bits
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34000_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34001_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34002_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-values-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34003_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-used-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34004_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-width-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-replay[1]#_g34005_|
    (##structure
     gx#syntax-quote::t
     '&replay-group-bits-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/view-replay[:0:]#replay-node|
      (let ((__obj33824
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33824
           'gerbil-ascent/program/view-replay#replay-node::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33824 'replay-node '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33824
           '(parent members size)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33824
           '(parent members size)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33824 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33824 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33824 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33824 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33824 '#f '13 '#f '#f))
        (let ((__tmp33950 |gerbil-ascent/program/view-replay[1]#_g33951_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33824 __tmp33950 '4 '#f '#f))
        (let ((__tmp33952 |gerbil-ascent/program/view-replay[1]#_g33953_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33824 __tmp33952 '14 '#f '#f))
        (let ((__tmp33954 |gerbil-ascent/program/view-replay[1]#_g33955_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33824 __tmp33954 '15 '#f '#f))
        (let ((__tmp33956
               (cons (cons 'parent
                           |gerbil-ascent/program/view-replay[1]#_g33957_|)
                     (cons (cons 'members
                                 |gerbil-ascent/program/view-replay[1]#_g33958_|)
                           (cons (cons 'size
                                       |gerbil-ascent/program/view-replay[1]#_g33959_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33824 __tmp33956 '16 '#f '#f))
        (let ((__tmp33960
               (cons (cons 'parent
                           |gerbil-ascent/program/view-replay[1]#_g33961_|)
                     (cons (cons 'members
                                 |gerbil-ascent/program/view-replay[1]#_g33962_|)
                           (cons (cons 'size
                                       |gerbil-ascent/program/view-replay[1]#_g33963_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33824 __tmp33960 '17 '#f '#f))
        (let ((__tmp33964
               (cons (cons 'parent
                           |gerbil-ascent/program/view-replay[1]#_g33965_|)
                     (cons (cons 'members
                                 |gerbil-ascent/program/view-replay[1]#_g33966_|)
                           (cons (cons 'size
                                       |gerbil-ascent/program/view-replay[1]#_g33967_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33824 __tmp33964 '18 '#f '#f))
        (let ((__tmp33968
               (cons (cons 'parent
                           |gerbil-ascent/program/view-replay[1]#_g33969_|)
                     (cons (cons 'members
                                 |gerbil-ascent/program/view-replay[1]#_g33970_|)
                           (cons (cons 'size
                                       |gerbil-ascent/program/view-replay[1]#_g33971_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33824 __tmp33968 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33824 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33824 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33824 '() '21 '#f '#f))
        __obj33824))
    (define |gerbil-ascent/program/view-replay[:0:]#replay-group|
      (let ((__obj33825
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33825
           'gerbil-ascent/program/view-replay#replay-group::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33825 'replay-group '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33825
           '(nodes roots values used width bits)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33825
           '(nodes roots values used width bits)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33825 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33825 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33825 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33825 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33825 '#f '13 '#f '#f))
        (let ((__tmp33972 |gerbil-ascent/program/view-replay[1]#_g33973_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33825 __tmp33972 '4 '#f '#f))
        (let ((__tmp33974 |gerbil-ascent/program/view-replay[1]#_g33975_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33825 __tmp33974 '14 '#f '#f))
        (let ((__tmp33976 |gerbil-ascent/program/view-replay[1]#_g33977_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33825 __tmp33976 '15 '#f '#f))
        (let ((__tmp33978
               (cons (cons 'nodes
                           |gerbil-ascent/program/view-replay[1]#_g33979_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/program/view-replay[1]#_g33980_|)
                           (cons (cons 'values
                                       |gerbil-ascent/program/view-replay[1]#_g33981_|)
                                 (cons (cons 'used
                                             |gerbil-ascent/program/view-replay[1]#_g33982_|)
                                       (cons (cons 'width
                                                   |gerbil-ascent/program/view-replay[1]#_g33983_|)
                                             (cons (cons 'bits
                                                         |gerbil-ascent/program/view-replay[1]#_g33984_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33825 __tmp33978 '16 '#f '#f))
        (let ((__tmp33985
               (cons (cons 'nodes
                           |gerbil-ascent/program/view-replay[1]#_g33986_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/program/view-replay[1]#_g33987_|)
                           (cons (cons 'values
                                       |gerbil-ascent/program/view-replay[1]#_g33988_|)
                                 (cons (cons 'used
                                             |gerbil-ascent/program/view-replay[1]#_g33989_|)
                                       (cons (cons 'width
                                                   |gerbil-ascent/program/view-replay[1]#_g33990_|)
                                             (cons (cons 'bits
                                                         |gerbil-ascent/program/view-replay[1]#_g33991_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33825 __tmp33985 '17 '#f '#f))
        (let ((__tmp33992
               (cons (cons 'nodes
                           |gerbil-ascent/program/view-replay[1]#_g33993_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/program/view-replay[1]#_g33994_|)
                           (cons (cons 'values
                                       |gerbil-ascent/program/view-replay[1]#_g33995_|)
                                 (cons (cons 'used
                                             |gerbil-ascent/program/view-replay[1]#_g33996_|)
                                       (cons (cons 'width
                                                   |gerbil-ascent/program/view-replay[1]#_g33997_|)
                                             (cons (cons 'bits
                                                         |gerbil-ascent/program/view-replay[1]#_g33998_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33825 __tmp33992 '18 '#f '#f))
        (let ((__tmp33999
               (cons (cons 'nodes
                           |gerbil-ascent/program/view-replay[1]#_g34000_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/program/view-replay[1]#_g34001_|)
                           (cons (cons 'values
                                       |gerbil-ascent/program/view-replay[1]#_g34002_|)
                                 (cons (cons 'used
                                             |gerbil-ascent/program/view-replay[1]#_g34003_|)
                                       (cons (cons 'width
                                                   |gerbil-ascent/program/view-replay[1]#_g34004_|)
                                             (cons (cons 'bits
                                                         |gerbil-ascent/program/view-replay[1]#_g34005_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33825 __tmp33999 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33825 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33825 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33825 '() '21 '#f '#f))
        __obj33825))))
