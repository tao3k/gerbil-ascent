(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/finite-evidence::timestamp 1791687890)
  (begin
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence::t
      (let ((__tmp37549 (list)) (__tmp37548 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'finite-evidence
         __tmp37549
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  program
                  query
                  work-budget
                  closure)
         __tmp37548
         '#f)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t)))
    (define gerbil-ascent/candidate/finite-evidence#make-finite-evidence
      (lambda _%$args28547%_
        (apply make-instance
               gerbil-ascent/candidate/finite-evidence#finite-evidence::t
               _%$args28547%_)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'status)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-program
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'program)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-query
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'query)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-closure
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'closure)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'status)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-program-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'program)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'query)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-closure-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'closure)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'status)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-program
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'program)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-query
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'query)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-closure
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'closure)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'status)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-program-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'program)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'query)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-closure-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'closure)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation::t
      (let ((__tmp37551 (list))
            (__tmp37550
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'replay-relation
         __tmp37551
         '(arity reversed present frontier dirty?)
         __tmp37550
         '#f)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/finite-evidence#replay-relation::t)))
    (define gerbil-ascent/candidate/finite-evidence#make-replay-relation
      (lambda _%$args28544%_
        (apply make-instance
               gerbil-ascent/candidate/finite-evidence#replay-relation::t
               _%$args28544%_)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-arity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'arity)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-reversed
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'reversed)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-present
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'present)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-frontier
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'frontier)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-dirty?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'dirty?)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-arity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'arity)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-reversed-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'reversed)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-present-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'present)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-frontier-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'frontier)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-dirty?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'dirty?)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-arity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'arity)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-reversed
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'reversed)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-present
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'present)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-frontier
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'frontier)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-dirty?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'dirty?)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-arity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'arity)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-reversed-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'reversed)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-present-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'present)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-frontier-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'frontier)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-dirty?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'dirty?)))
    (define gerbil-ascent/candidate/finite-evidence#closure-valid?
      (lambda (_%closure28529%_ _%schema28530%_)
        (if (equal? (let ()
                      (declare (not safe))
                      (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                       _%closure28529%_
                       gerbil-ascent/candidate/certificate-limits#+max-certificate-relations+))
                    (length _%schema28530%_))
            (let ((_%rows28532%_ '0) (_%cells28533%_ '0))
              (let ((__tmp37552
                     (lambda (_%entry28535%_ _%declaration28536%_)
                       (if (equal? (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                                      _%entry28535%_
                                      '3))
                                   '3)
                           (if (eq? (car _%entry28535%_)
                                    (car _%declaration28536%_))
                               (if (exact-integer? (cadr _%entry28535%_))
                                   (if (= (cadr _%entry28535%_)
                                          (cdr _%declaration28536%_))
                                       (if (let ((_%count28538%_
                                                  (let ((__tmp37554
                                                         (caddr _%entry28535%_))
                                                        (__tmp37553
                                                         (- gerbil-ascent/candidate/certificate-limits#+max-certificate-rows+
                                                            _%rows28532%_)))
                                                    (declare (not safe))
                                                    (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                                                     __tmp37554
                                                     __tmp37553))))
                                             (and _%count28538%_
                                                  (begin
                                                    (set! _%rows28532%_
                                                          (+ _%rows28532%_
                                                             _%count28538%_))
                                                    '#t)))
                                           (if (<= _%rows28532%_
                                                   gerbil-ascent/candidate/certificate-limits#+max-certificate-rows+)
                                               (if (let ((__tmp37556
                                                          (lambda (_%row28540%_)
                                                            (let ((_%width28542%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ((__tmp37557
                                  (min gerbil-ascent/candidate/certificate-limits#+max-certificate-row-arity+
                                       (- gerbil-ascent/candidate/certificate-limits#+max-certificate-cells+
                                          _%cells28533%_))))
                             (declare (not safe))
                             (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                              _%row28540%_
                              __tmp37557))))
                      (and _%width28542%_
                           (= _%width28542%_ (cadr _%entry28535%_))
                           (begin
                             (set! _%cells28533%_
                                   (+ _%cells28533%_ _%width28542%_))
                             '#t)
                           (let ()
                             (declare (not safe))
                             (andmap__0
                              gerbil-ascent/candidate/program#scalar?
                              _%row28540%_))))))
                 (__tmp37555 (caddr _%entry28535%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (declare (not safe))
                                                     (andmap__0
                                                      __tmp37556
                                                      __tmp37555))
                                                   (let ((__tmp37558
                                                          (caddr _%entry28535%_)))
                                                     (declare (not safe))
                                                     (gerbil-ascent/candidate/certificate-limits#unique-rows?
                                                      __tmp37558))
                                                   '#f)
                                               '#f)
                                           '#f)
                                       '#f)
                                   '#f)
                               '#f)
                           '#f))))
                (declare (not safe))
                (andmap__1 __tmp37552 _%closure28529%_ _%schema28530%_)))
            '#f)))
    (define gerbil-ascent/candidate/finite-evidence#finite-replay
      (lambda (_%snapshot27760%_ _%spec27761%_ _%work-budget27762%_)
        (let* ((_%schema27764%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/funs#candidate-schema-of
                   _%snapshot27760%_
                   _%spec27761%_)))
               (_%rules27766%_
                (##structure-ref
                 _%spec27761%_
                 '3
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f))
               (_%levels27768%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/funs#candidate-strata-of
                   _%schema27764%_
                   _%rules27766%_)))
               (_%tables27772%_
                (let ((__tmp37559
                       (lambda (_%entry27770%_)
                         (cons (car _%entry27770%_)
                               (let ((__tmp37561 (cdr _%entry27770%_))
                                     (__tmp37560
                                      (let ()
                                        (declare (not safe))
                                        (make-hash-table__%
                                         '#f
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value))))
                                 (declare (not safe))
                                 (##structure
                                  gerbil-ascent/candidate/finite-evidence#replay-relation::t
                                  __tmp37561
                                  '()
                                  __tmp37560
                                  '()
                                  '#f))))))
                  (declare (not safe))
                  (##map __tmp37559 _%schema27764%_)))
               (_%relations27774%_
                (let ()
                  (declare (not safe))
                  (list->hash-table-eq _%tables27772%_)))
               (_%resolve27781%_
                (lambda (_%name27776%_)
                  (let ((_%$e27778%_
                         (let ()
                           (declare (not safe))
                           (hash-get _%relations27774%_ _%name27776%_))))
                    (if _%$e27778%_
                        _%$e27778%_
                        (let ()
                          (declare (not safe))
                          (error '"candidate is missing inspected entry"
                                 _%name27776%_))))))
               (_%plans27785%_
                (if _%levels27768%_
                    (map (lambda (_%rule27783%_)
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/candidate/finite-plan#prepare-finite-rule
                              _%rule27783%_
                              _%resolve27781%_
                              _%levels27768%_)))
                         _%rules27766%_)
                    '#f))
               (_%steps27787%_ '0)
               (_%bounded?27789%_ '#f)
               (_%material27791%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/certificate-limits#make-certificate-material-budget)))
               (_%derived-count27793%_ '0)
               (_%derived-limit27795%_
                (cadr (##structure-ref
                       _%spec27761%_
                       '5
                       gerbil-ascent/candidate/types#reasoning-candidate::t
                       '#f))))
          (letrec ((_%active?27798%_ (lambda () (not _%bounded?27789%_)))
                   (_%__rows27951%_
                    (lambda (_%relation28516%_)
                      (let ((_%relation28519%_ _%relation28516%_))
                        (if (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%relation28519%_
                               '5
                               '#f
                               '#f))
                            (begin
                              (let ((__tmp37562
                                     (reverse (let ()
                                                (declare (not safe))
                                                (##unchecked-structure-ref
                                                 _%relation28519%_
                                                 '2
                                                 '#f
                                                 '#f)))))
                                (declare (not safe))
                                (##unchecked-structure-set!
                                 _%relation28519%_
                                 __tmp37562
                                 '4
                                 '#f
                                 '#f))
                              (let ()
                                (declare (not safe))
                                (##unchecked-structure-set!
                                 _%relation28519%_
                                 '#f
                                 '5
                                 '#f
                                 '#f)))
                            '#!void)
                        (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%relation28519%_
                           '4
                           '#f
                           '#f)))))
                   (_%rows27952%_
                    (lambda (_%relation28504%_)
                      (let ((_%relation28507%_ _%relation28504%_))
                        (_%__rows27951%_ _%relation28507%_))))
                   (_%__add-row!28074%_
                    (lambda (_%relation28482%_ _%row28483%_ _%derived?28484%_)
                      (let ((_%relation28487%_ _%relation28482%_))
                        (if (or _%bounded?27789%_
                                (let ((__tmp37563
                                       (let ()
                                         (declare (not safe))
                                         (##unchecked-structure-ref
                                          _%relation28487%_
                                          '3
                                          '#f
                                          '#f))))
                                  (declare (not safe))
                                  (hash-get __tmp37563 _%row28483%_)))
                            '#f
                            (begin
                              (if _%derived?28484%_
                                  (begin
                                    (set! _%derived-count27793%_
                                          (+ _%derived-count27793%_ '1))
                                    (if (> _%derived-count27793%_
                                           _%derived-limit27795%_)
                                        (set! _%bounded?27789%_ '#t)
                                        '#!void))
                                  '#!void)
                              (if (or _%bounded?27789%_
                                      (let ()
                                        (declare (not safe))
                                        (gerbil-ascent/candidate/certificate-limits#certificate-material-reserve!
                                         _%material27791%_
                                         _%row28483%_)))
                                  '#!void
                                  (set! _%bounded?27789%_ '#t))
                              (if _%bounded?27789%_
                                  '#f
                                  (let ((_%owned28502%_
                                         (let ()
                                           (declare (not safe))
                                           (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                            _%row28483%_))))
                                    (let ((__tmp37564
                                           (let ()
                                             (declare (not safe))
                                             (##unchecked-structure-ref
                                              _%relation28487%_
                                              '3
                                              '#f
                                              '#f))))
                                      (declare (not safe))
                                      (hash-put!
                                       __tmp37564
                                       _%owned28502%_
                                       '#t))
                                    (let ((__tmp37565
                                           (cons _%owned28502%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%relation28487%_
                                                    '2
                                                    '#f
                                                    '#f)))))
                                      (declare (not safe))
                                      (##unchecked-structure-set!
                                       _%relation28487%_
                                       __tmp37565
                                       '2
                                       '#f
                                       '#f))
                                    (let ()
                                      (declare (not safe))
                                      (##unchecked-structure-set!
                                       _%relation28487%_
                                       '#t
                                       '5
                                       '#f
                                       '#f))
                                    '#t)))))))
                   (_%add-row!28075%_
                    (lambda (_%relation28468%_ _%row28469%_ _%derived?28470%_)
                      (let ((_%relation28473%_ _%relation28468%_))
                        (_%__add-row!28074%_
                         _%relation28473%_
                         _%row28469%_
                         _%derived?28470%_))))
                   (_%step!28076%_
                    (lambda ()
                      (if _%bounded?27789%_
                          '#!void
                          (begin
                            (set! _%steps27787%_ (+ _%steps27787%_ '1))
                            (if (> _%steps27787%_ _%work-budget27762%_)
                                (set! _%bounded?27789%_ '#t)
                                '#!void)))
                      (not _%bounded?27789%_)))
                   (_%__evaluate-rule28198%_
                    (lambda (_%rule28323%_)
                      (let ((_%rule28326%_ _%rule28323%_))
                        (let ((_%body28335%_
                               (let ()
                                 (declare (not safe))
                                 (##unchecked-structure-ref
                                  _%rule28326%_
                                  '3
                                  '#f
                                  '#f)))
                              (_%changed?28336%_ '#f))
                          (letrec ((_%walk28338%_
                                    (lambda (_%clauses28340%_
                                             _%bindings28341%_)
                                      (if _%bounded?27789%_
                                          '#!void
                                          (if (null? _%clauses28340%_)
                                              (if (let* ((_%relation28343%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (##unchecked-structure-ref
                                                             _%rule28326%_
                                                             '1
                                                             '#f
                                                             '#f)))
                                                         (_%row28346%_
                                                          ((let ()
                                                             (declare
                                                               (not safe))
                                                             (##unchecked-structure-ref
                                                              _%rule28326%_
                                                              '2
                                                              '#f
                                                              '#f))
                                                           _%bindings28341%_))
                                                         (_%derived?28349%_
                                                          '#t)
                                                         (_%relation28353%_
                                                          _%relation28343%_))
                                                    (_%__add-row!28074%_
                                                     _%relation28353%_
                                                     _%row28346%_
                                                     _%derived?28349%_))
                                                  (set! _%changed?28336%_ '#t)
                                                  '#!void)
                                              (let* ((_%clause28370%_
                                                      (car _%clauses28340%_))
                                                     (_%clause28372%_
                                                      _%clause28370%_)
                                                     (_%$e28379%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (##unchecked-structure-ref
                                                         _%clause28372%_
                                                         '1
                                                         '#f
                                                         '#f))))
                                                (if (eq? 'fixed _%$e28379%_)
                                                    (if (_%step!28076%_)
                                                        (let ((_%next28382%_
                                                               ((let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%clause28372%_
                           '3
                           '#f
                           '#f))
                        _%bindings28341%_)))
                  (if _%next28382%_
                      (_%walk28338%_ (cdr _%clauses28340%_) _%next28382%_)
                      '#!void))
                '#!void)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (if (eq? 'not _%$e28379%_)
                                                        (let ((_%matched?28384%_
                                                               '#f))
                                                          (let _%probe28386%_ ((_%remaining28388%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                        (let* ((_%relation28390%_
                                                (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%clause28372%_
                                                   '2
                                                   '#f
                                                   '#f)))
                                               (_%relation28394%_
                                                _%relation28390%_))
                                          (_%__rows27951%_
                                           _%relation28394%_))))
                    (if (and (pair? _%remaining28388%_) (_%step!28076%_))
                        (if ((let ()
                               (declare (not safe))
                               (##unchecked-structure-ref
                                _%clause28372%_
                                '3
                                '#f
                                '#f))
                             (car _%remaining28388%_)
                             _%bindings28341%_)
                            (set! _%matched?28384%_ '#t)
                            (_%probe28386%_ (cdr _%remaining28388%_)))
                        '#!void))
                  (if (if _%bounded?27789%_
                          '#f
                          (if _%matched?28384%_ '#f (_%step!28076%_)))
                      (_%walk28338%_ (cdr _%clauses28340%_) _%bindings28341%_)
                      '#!void))
                (if (eq? 'reduce _%$e28379%_)
                    (let* ((_%output28407%_
                            (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%clause28372%_
                               '4
                               '#f
                               '#f)))
                           (_%operator28409%_
                            (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%clause28372%_
                               '5
                               '#f
                               '#f)))
                           (_%mode28411%_ (car _%operator28409%_))
                           (_%accumulator28413%_
                            (if (let ()
                                  (declare (not safe))
                                  (##memq _%mode28411%_ '(count sum)))
                                '0
                                '#f))
                           (_%numeric?28415%_ '#t))
                      (let _%probe28418%_ ((_%remaining28420%_
                                            (let* ((_%relation28429%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%clause28372%_
                                                       '2
                                                       '#f
                                                       '#f)))
                                                   (_%relation28433%_
                                                    _%relation28429%_))
                                              (_%__rows27951%_
                                               _%relation28433%_))))
                        (if (and (pair? _%remaining28420%_) (_%step!28076%_))
                            (begin
                              (let ((_%next28422%_
                                     ((let ()
                                        (declare (not safe))
                                        (##unchecked-structure-ref
                                         _%clause28372%_
                                         '3
                                         '#f
                                         '#f))
                                      (car _%remaining28420%_)
                                      _%bindings28341%_)))
                                (if _%next28422%_
                                    (if (eq? _%mode28411%_ 'count)
                                        (set! _%accumulator28413%_
                                              (+ _%accumulator28413%_ '1))
                                        (if _%numeric?28415%_
                                            (let ((_%value28424%_
                                                   (cdr (let ((__tmp37566
                                                               (cadr _%operator28409%_)))
                                                          (declare (not safe))
                                                          (gerbil-ascent/candidate/funs#candidate-required-entry
                                                           __tmp37566
                                                           _%next28422%_)))))
                                              (if (exact-integer?
                                                   _%value28424%_)
                                                  (set! _%accumulator28413%_
                                                        (let ((_%$e28426%_
                                                               _%mode28411%_))
                                                          (if (eq? 'sum
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           _%$e28426%_)
                      (+ _%accumulator28413%_ _%value28424%_)
                      (if (eq? 'min _%$e28426%_)
                          (if _%accumulator28413%_
                              (min _%accumulator28413%_ _%value28424%_)
                              _%value28424%_)
                          (if (eq? 'max _%$e28426%_)
                              (if _%accumulator28413%_
                                  (max _%accumulator28413%_ _%value28424%_)
                                  _%value28424%_)
                              '#f)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (set! _%numeric?28415%_
                                                        '#f)))
                                            '#!void))
                                    '#!void))
                              (_%probe28418%_ (cdr _%remaining28420%_)))
                            '#!void))
                      (if _%bounded?27789%_
                          '#!void
                          (let ((_%value28448%_
                                 (if _%numeric?28415%_
                                     _%accumulator28413%_
                                     '#f)))
                            (if _%value28448%_
                                (_%walk28338%_
                                 (cdr _%clauses28340%_)
                                 (cons (cons _%output28407%_ _%value28448%_)
                                       _%bindings28341%_))
                                '#!void))))
                    (let ((__tmp37568
                           (lambda (_%row28450%_)
                             (if (_%step!28076%_)
                                 (let ((_%next28452%_
                                        ((let ()
                                           (declare (not safe))
                                           (##unchecked-structure-ref
                                            _%clause28372%_
                                            '3
                                            '#f
                                            '#f))
                                         _%row28450%_
                                         _%bindings28341%_)))
                                   (if _%next28452%_
                                       (_%walk28338%_
                                        (cdr _%clauses28340%_)
                                        _%next28452%_)
                                       '#!void))
                                 '#!void)))
                          (__tmp37567
                           (let* ((_%relation28454%_
                                   (let ()
                                     (declare (not safe))
                                     (##unchecked-structure-ref
                                      _%clause28372%_
                                      '2
                                      '#f
                                      '#f)))
                                  (_%relation28458%_ _%relation28454%_))
                             (_%__rows27951%_ _%relation28458%_))))
                      (declare (not safe))
                      (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                       _%active?27798%_
                       __tmp37568
                       __tmp37567)))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                            (_%walk28338%_ _%body28335%_ '())
                            _%changed?28336%_)))))
                   (_%evaluate-rule28199%_
                    (lambda (_%rule28311%_)
                      (let ((_%rule28314%_ _%rule28311%_))
                        (_%__evaluate-rule28198%_ _%rule28314%_)))))
            (if (> (let () (declare (not safe)) (##length _%schema27764%_))
                   gerbil-ascent/candidate/certificate-limits#+max-certificate-relations+)
                (values 'bounded '())
                (if _%levels27768%_
                    (begin
                      (let ((__tmp37570
                             (lambda (_%entry28201%_)
                               (let ((__tmp37572
                                      (lambda (_%row28203%_)
                                        (let* ((_%relation28205%_
                                                (_%resolve27781%_
                                                 (car _%entry28201%_)))
                                               (_%row28208%_ _%row28203%_)
                                               (_%derived?28211%_ '#f)
                                               (_%relation28215%_
                                                _%relation28205%_))
                                          (_%__add-row!28074%_
                                           _%relation28215%_
                                           _%row28208%_
                                           _%derived?28211%_))))
                                     (__tmp37571 (caddr _%entry28201%_)))
                                 (declare (not safe))
                                 (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                                  _%active?27798%_
                                  __tmp37572
                                  __tmp37571))))
                            (__tmp37569
                             (##structure-ref
                              _%snapshot27760%_
                              '4
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f)))
                        (declare (not safe))
                        (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                         _%active?27798%_
                         __tmp37570
                         __tmp37569))
                      (let ((__tmp37574
                             (lambda (_%fact28228%_)
                               (let* ((_%relation28230%_
                                       (_%resolve27781%_
                                        (vector-ref _%fact28228%_ '0)))
                                      (_%row28233%_
                                       (vector-ref _%fact28228%_ '1))
                                      (_%derived?28236%_ '#f)
                                      (_%relation28240%_ _%relation28230%_))
                                 (_%__add-row!28074%_
                                  _%relation28240%_
                                  _%row28233%_
                                  _%derived?28236%_))))
                            (__tmp37573
                             (##structure-ref
                              _%spec27761%_
                              '2
                              gerbil-ascent/candidate/types#reasoning-candidate::t
                              '#f)))
                        (declare (not safe))
                        (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                         _%active?27798%_
                         __tmp37574
                         __tmp37573))
                      (let _%stratum28252%_ ((_%level28254%_ '0)
                                             (_%maximum28255%_
                                              (let ((__tmp37576
                                                     (map cdr
                                                          _%levels27768%_)))
                                                (declare (not safe))
                                                (##apply max __tmp37576))))
                        (if (and (<= _%level28254%_ _%maximum28255%_)
                                 (not _%bounded?27789%_))
                            (begin
                              (let _%repeat28257%_ ()
                                (let ((_%changed?28260%_ '#f))
                                  (let ((__tmp37575
                                         (lambda (_%rule28262%_)
                                           (let ((_%rule28265%_ _%rule28262%_))
                                             (if (if _%bounded?27789%_
                                                     '#f
                                                     (= (let ()
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           _%rule28265%_
                                                           '4
                                                           '#f
                                                           '#f))
                                                        _%level28254%_))
                                                 (if (let* ((_%rule28279%_
                                                             _%rule28265%_)
                                                            (_%rule28283%_
                                                             _%rule28279%_))
                                                       (_%__evaluate-rule28198%_
                                                        _%rule28283%_))
                                                     (set! _%changed?28260%_
                                                           '#t)
                                                     '#!void)
                                                 '#!void)))))
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                                     _%active?27798%_
                                     __tmp37575
                                     _%plans27785%_))
                                  (if (and _%changed?28260%_
                                           (not _%bounded?27789%_))
                                      (_%repeat28257%_)
                                      '#!void)))
                              (_%stratum28252%_
                               (+ _%level28254%_ '1)
                               _%maximum28255%_))
                            '#!void))
                      (values (if _%bounded?27789%_ 'bounded 'complete)
                              (if _%bounded?27789%_
                                  '()
                                  (let ((__tmp37577
                                         (lambda (_%entry28295%_)
                                           (list (car _%entry28295%_)
                                                 (##direct-structure-ref
                                                  (cdr _%entry28295%_)
                                                  '1
                                                  gerbil-ascent/candidate/finite-evidence#replay-relation::t
                                                  '#f)
                                                 (let* ((_%relation28297%_
                                                         (cdr _%entry28295%_))
                                                        (_%relation28301%_
                                                         _%relation28297%_))
                                                   (_%__rows27951%_
                                                    _%relation28301%_))))))
                                    (declare (not safe))
                                    (##map __tmp37577 _%tables27772%_)))))
                    (values 'unsupported '())))))))
    (define gerbil-ascent/candidate/finite-evidence#query-rows
      (lambda (_%spec27748%_ _%closure27749%_)
        (let* ((_%query27751%_
                (vector-ref
                 (##structure-ref
                  _%spec27748%_
                  '4
                  gerbil-ascent/candidate/types#reasoning-candidate::t
                  '#f)
                 '0))
               (_%entry27753%_
                (let ((__tmp37578 (car _%query27751%_)))
                  (declare (not safe))
                  (gerbil-ascent/candidate/funs#candidate-required-entry
                   __tmp37578
                   _%closure27749%_)))
               (_%match-row27755%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
                   _%query27751%_))))
          (filter (lambda (_%row27758%_)
                    (if (_%match-row27755%_ _%row27758%_ '()) '#t '#f))
                  (caddr _%entry27753%_)))))
    (define gerbil-ascent/candidate/finite-evidence#candidate-finite-evidence
      (lambda (_%snapshot27724%_
               _%spec27725%_
               _%candidate-digest27726%_
               _%native-status27727%_
               _%native-rows27728%_
               _%work-budget27729%_)
        (if (and (exact-integer? _%work-budget27729%_)
                 (> _%work-budget27729%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"finite evidence requires positive work budget"
                     _%work-budget27729%_)))
        (letrec ((_%result27731%_
                  (lambda (_%status27745%_ _%closure27746%_)
                    (let ((__tmp37584
                           (##structure-ref
                            _%snapshot27724%_
                            '1
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                          (__tmp37583
                           (##structure-ref
                            _%snapshot27724%_
                            '2
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                          (__tmp37582
                           (##structure-ref
                            _%snapshot27724%_
                            '3
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                          (__tmp37581
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/candidate/program-identity#candidate-finite-program-fingerprint
                              _%spec27725%_)))
                          (__tmp37579
                           (let ((__tmp37580
                                  (vector-ref
                                   (##structure-ref
                                    _%spec27725%_
                                    '4
                                    gerbil-ascent/candidate/types#reasoning-candidate::t
                                    '#f)
                                   '0)))
                             (declare (not safe))
                             (gerbil-ascent/candidate/datum#candidate-copy-pairs
                              __tmp37580))))
                      (declare (not safe))
                      (##structure
                       gerbil-ascent/candidate/finite-evidence#finite-evidence::t
                       _%status27745%_
                       __tmp37584
                       __tmp37583
                       __tmp37582
                       _%candidate-digest27726%_
                       __tmp37581
                       __tmp37579
                       _%work-budget27729%_
                       _%closure27746%_)))))
          (if (or (not (let ()
                         (declare (not safe))
                         (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                          _%snapshot27724%_)))
                  (not (eq? _%native-status27727%_ 'complete)))
              (_%result27731%_ 'unsupported '())
              (let ((_g37585_
                     (gerbil-ascent/candidate/finite-evidence#finite-replay
                      _%snapshot27724%_
                      _%spec27725%_
                      _%work-budget27729%_)))
                (begin
                  (let ((_g37586_
                         (let ()
                           (declare (not safe))
                           (if (##values? _g37585_)
                               (##values-length _g37585_)
                               1))))
                    (if (not (let () (declare (not safe)) (##fx= _g37586_ 2)))
                        (error "Context expects 2 values" _g37586_)))
                  (let ((_%status27736%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g37585_ 0)))
                        (_%closure27737%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g37585_ 1))))
                    (let ((_%$e27739%_ _%status27736%_))
                      (if (eq? 'complete _%$e27739%_)
                          (if (gerbil-ascent/candidate/finite-evidence#closure-valid?
                               _%closure27737%_
                               (let ()
                                 (declare (not safe))
                                 (gerbil-ascent/candidate/funs#candidate-schema-of
                                  _%snapshot27724%_
                                  _%spec27725%_)))
                              (if (let ((__tmp37587
                                         (gerbil-ascent/candidate/finite-evidence#query-rows
                                          _%spec27725%_
                                          _%closure27737%_)))
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/funs#candidate-same-row-set?
                                     __tmp37587
                                     _%native-rows27728%_))
                                  (_%result27731%_ 'complete _%closure27737%_)
                                  (_%result27731%_ 'mismatch '()))
                              (_%result27731%_ 'bounded '()))
                          (if (eq? 'bounded _%$e27739%_)
                              (_%result27731%_ 'bounded '())
                              (_%result27731%_ 'unsupported '())))))))))))
    (define gerbil-ascent/candidate/finite-evidence#candidate-verified-finite-closure
      (lambda (_%snapshot27707%_
               _%spec27708%_
               _%candidate-digest27709%_
               _%native-status27710%_
               _%native-rows27711%_
               _%certificate27712%_
               _%work-budget27713%_)
        (if (and (exact-integer? _%work-budget27713%_)
                 (> _%work-budget27713%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"finite evidence verification needs positive budget"
                     _%work-budget27713%_)))
        (if (and (let ()
                   (declare (not safe))
                   (##structure-instance-of?
                    _%certificate27712%_
                    'gerbil-ascent/candidate/finite-evidence#finite-evidence::t))
                 (let ()
                   (declare (not safe))
                   (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                    _%snapshot27707%_))
                 (eq? _%native-status27710%_ 'complete)
                 (eq? (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%certificate27712%_
                         '1
                         '#f
                         '#f))
                      'complete)
                 (equal? (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%certificate27712%_
                            '2
                            '#f
                            '#f))
                         (##structure-ref
                          _%snapshot27707%_
                          '1
                          gerbil-ascent/candidate/types#reasoning-snapshot::t
                          '#f))
                 (equal? (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%certificate27712%_
                            '3
                            '#f
                            '#f))
                         (##structure-ref
                          _%snapshot27707%_
                          '2
                          gerbil-ascent/candidate/types#reasoning-snapshot::t
                          '#f))
                 (equal? (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%certificate27712%_
                            '4
                            '#f
                            '#f))
                         (##structure-ref
                          _%snapshot27707%_
                          '3
                          gerbil-ascent/candidate/types#reasoning-snapshot::t
                          '#f))
                 (equal? (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%certificate27712%_
                            '5
                            '#f
                            '#f))
                         _%candidate-digest27709%_)
                 (equal? (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%certificate27712%_
                            '6
                            '#f
                            '#f))
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/program-identity#candidate-finite-program-fingerprint
                            _%spec27708%_)))
                 (equal? (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%certificate27712%_
                            '7
                            '#f
                            '#f))
                         (vector-ref
                          (##structure-ref
                           _%spec27708%_
                           '4
                           gerbil-ascent/candidate/types#reasoning-candidate::t
                           '#f)
                          '0))
                 (gerbil-ascent/candidate/finite-evidence#closure-valid?
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref
                     _%certificate27712%_
                     '9
                     '#f
                     '#f))
                  (let ()
                    (declare (not safe))
                    (gerbil-ascent/candidate/funs#candidate-schema-of
                     _%snapshot27707%_
                     _%spec27708%_))))
            (let ((_g37588_
                   (gerbil-ascent/candidate/finite-evidence#finite-replay
                    _%snapshot27707%_
                    _%spec27708%_
                    _%work-budget27713%_)))
              (begin
                (let ((_g37589_
                       (let ()
                         (declare (not safe))
                         (if (##values? _g37588_)
                             (##values-length _g37588_)
                             1))))
                  (if (not (let () (declare (not safe)) (##fx= _g37589_ 2)))
                      (error "Context expects 2 values" _g37589_)))
                (let ((_%status27715%_
                       (let () (declare (not safe)) (##values-ref _g37588_ 0)))
                      (_%closure27716%_
                       (let ()
                         (declare (not safe))
                         (##values-ref _g37588_ 1))))
                  (let ((_%$e27718%_ _%status27715%_))
                    (if (eq? 'bounded _%$e27718%_)
                        (values 'bounded '())
                        (if (eq? 'complete _%$e27718%_)
                            (if (and (let ((__tmp37591
                                            (lambda (_%actual27721%_
                                                     _%supplied27722%_)
                                              (let ((__tmp37593
                                                     (caddr _%actual27721%_))
                                                    (__tmp37592
                                                     (caddr _%supplied27722%_)))
                                                (declare (not safe))
                                                (gerbil-ascent/candidate/funs#candidate-same-row-set?
                                                 __tmp37593
                                                 __tmp37592))))
                                           (__tmp37590
                                            (##structure-ref
                                             _%certificate27712%_
                                             '9
                                             gerbil-ascent/candidate/finite-evidence#finite-evidence::t
                                             '#f)))
                                       (declare (not safe))
                                       (andmap__1
                                        __tmp37591
                                        _%closure27716%_
                                        __tmp37590))
                                     (let ((__tmp37594
                                            (gerbil-ascent/candidate/finite-evidence#query-rows
                                             _%spec27708%_
                                             _%closure27716%_)))
                                       (declare (not safe))
                                       (gerbil-ascent/candidate/funs#candidate-same-row-set?
                                        __tmp37594
                                        _%native-rows27711%_)))
                                (values 'valid _%closure27716%_)
                                (values 'invalid '()))
                            (values 'invalid '())))))))
            (values 'invalid '()))))
    (define gerbil-ascent/candidate/finite-evidence#candidate-verify-finite-evidence
      (lambda (_%snapshot27696%_
               _%spec27697%_
               _%candidate-digest27698%_
               _%native-status27699%_
               _%native-rows27700%_
               _%certificate27701%_
               _%work-budget27702%_)
        (let ((_g37595_
               (gerbil-ascent/candidate/finite-evidence#candidate-verified-finite-closure
                _%snapshot27696%_
                _%spec27697%_
                _%candidate-digest27698%_
                _%native-status27699%_
                _%native-rows27700%_
                _%certificate27701%_
                _%work-budget27702%_)))
          (begin
            (let ((_g37596_
                   (let ()
                     (declare (not safe))
                     (if (##values? _g37595_) (##values-length _g37595_) 1))))
              (if (not (let () (declare (not safe)) (##fx= _g37596_ 2)))
                  (error "Context expects 2 values" _g37596_)))
            (let ((_%verdict27704%_
                   (let () (declare (not safe)) (##values-ref _g37595_ 0)))
                  (_%closure27705%_
                   (let () (declare (not safe)) (##values-ref _g37595_ 1))))
              _%verdict27704%_)))))))
