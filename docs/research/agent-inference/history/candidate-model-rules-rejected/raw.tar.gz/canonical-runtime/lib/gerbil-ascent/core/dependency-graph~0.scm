(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/core/dependency-graph::timestamp 1791687855)
  (begin
    (define gerbil-ascent/core/dependency-graph#graph-frame::t
      (let ((__tmp33339 (list))
            (__tmp33338
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/core/dependency-graph#graph-frame::t
         'graph-frame
         __tmp33339
         '(node remaining parent)
         __tmp33338
         '#f)))
    (define gerbil-ascent/core/dependency-graph#graph-frame?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/core/dependency-graph#graph-frame::t)))
    (define gerbil-ascent/core/dependency-graph#make-graph-frame
      (lambda _%$args7385%_
        (apply make-instance
               gerbil-ascent/core/dependency-graph#graph-frame::t
               _%$args7385%_)))
    (define gerbil-ascent/core/dependency-graph#graph-frame-node
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'node)))
    (define gerbil-ascent/core/dependency-graph#graph-frame-remaining
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'remaining)))
    (define gerbil-ascent/core/dependency-graph#graph-frame-parent
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'parent)))
    (define gerbil-ascent/core/dependency-graph#graph-frame-node-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'node)))
    (define gerbil-ascent/core/dependency-graph#graph-frame-remaining-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'remaining)))
    (define gerbil-ascent/core/dependency-graph#graph-frame-parent-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'parent)))
    (define gerbil-ascent/core/dependency-graph#&graph-frame-node
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'node)))
    (define gerbil-ascent/core/dependency-graph#&graph-frame-remaining
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'remaining)))
    (define gerbil-ascent/core/dependency-graph#&graph-frame-parent
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'parent)))
    (define gerbil-ascent/core/dependency-graph#&graph-frame-node-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'node)))
    (define gerbil-ascent/core/dependency-graph#&graph-frame-remaining-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'remaining)))
    (define gerbil-ascent/core/dependency-graph#&graph-frame-parent-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'parent)))
    (define gerbil-ascent/core/dependency-graph#gerbil-ascent-graph-close!
      (lambda (_%successors7330%_ _%selected7331%_)
        (let ((_%count7333%_ (vector-length _%selected7331%_))
              (_%pending7334%_ '()))
          (let _%seed7336%_ ((_%index7338%_ '0))
            (if (< _%index7338%_ _%count7333%_)
                (begin
                  (if (vector-ref _%selected7331%_ _%index7338%_)
                      (set! _%pending7334%_
                            (cons _%index7338%_ _%pending7334%_))
                      '#!void)
                  (_%seed7336%_ (+ _%index7338%_ '1)))
                '#!void))
          (letrec ((_%enqueue7340%_
                    (lambda (_%target7383%_)
                      (if (vector-ref _%selected7331%_ _%target7383%_)
                          '#!void
                          (begin
                            (vector-set! _%selected7331%_ _%target7383%_ '#t)
                            (set! _%pending7334%_
                                  (cons _%target7383%_ _%pending7334%_)))))))
            (let _%visit7342%_ ()
              (let* ((_%$%pending73447353%_ _%pending7334%_)
                     (_%$%E73477357%_
                      (lambda ()
                        (let ()
                          (declare (not safe))
                          (error '"No clause matching"
                                 _%$%pending73447353%_
                                 '([])
                                 '([source . rest])))
                        '#!void)))
                (let ((_%$%K73517380%_ (lambda () '#!void))
                      (_%$%K73487364%_
                       (lambda (_%rest7361%_ _%source7362%_)
                         (set! _%pending7334%_ _%rest7361%_)
                         (for-each
                          _%enqueue7340%_
                          (vector-ref _%successors7330%_ _%source7362%_))
                         (_%visit7342%_))))
                  (let ((_%$%try-match73467376%_
                         (lambda ()
                           (if (pair? _%$%pending73447353%_)
                               (let ((_%$%tl73507369%_
                                      (let ()
                                        (declare (not safe))
                                        (##cdr _%$%pending73447353%_)))
                                     (_%$%hd73497367%_
                                      (let ()
                                        (declare (not safe))
                                        (##car _%$%pending73447353%_))))
                                 (let ((_%source7372%_ _%$%hd73497367%_)
                                       (_%rest7374%_ _%$%tl73507369%_))
                                   (_%$%K73487364%_
                                    _%rest7374%_
                                    _%source7372%_)))
                               (_%$%E73477357%_)))))
                    (if (null? _%$%pending73447353%_)
                        '#!void
                        (_%$%try-match73467376%_))))))))))
    (define gerbil-ascent/core/dependency-graph#gerbil-ascent-graph-components
      (lambda (_%successors7012%_)
        (let* ((_%count7014%_ (vector-length _%successors7012%_))
               (_%next-index7016%_ '0)
               (_%indices7018%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count7014%_ '#f)))
               (_%lowlinks7020%_
                (let () (declare (not safe)) (##make-vector _%count7014%_ '0)))
               (_%stack7022%_ '())
               (_%components7024%_ '()))
          (letrec ((_%enter7027%_
                    (lambda (_%node7325%_ _%frames7326%_)
                      (let ((_%index7328%_ _%next-index7016%_))
                        (set! _%next-index7016%_
                              (let ()
                                (declare (not safe))
                                (##fx+ _%next-index7016%_ '1)))
                        (vector-set!
                         _%indices7018%_
                         _%node7325%_
                         _%index7328%_)
                        (vector-set!
                         _%lowlinks7020%_
                         _%node7325%_
                         _%index7328%_)
                        (set! _%stack7022%_ (cons _%node7325%_ _%stack7022%_)))
                      (let ((__tmp33340
                             (vector-ref _%successors7012%_ _%node7325%_)))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/core/dependency-graph#graph-frame::t
                         _%node7325%_
                         __tmp33340
                         _%frames7326%_))))
                   (_%lower!7028%_
                    (lambda (_%node7322%_ _%index7323%_)
                      (vector-set!
                       _%lowlinks7020%_
                       _%node7322%_
                       (fxmin (vector-ref _%lowlinks7020%_ _%node7322%_)
                              _%index7323%_))))
                   (_%finish7029%_
                    (lambda (_%node7287%_)
                      (if (fx= (vector-ref _%lowlinks7020%_ _%node7287%_)
                               (vector-ref _%indices7018%_ _%node7287%_))
                          (let _%pop7289%_ ((_%members7291%_ '()))
                            (let* ((_%$%stack72927299%_ _%stack7022%_)
                                   (_%$%E72947302%_
                                    (lambda ()
                                      (let ()
                                        (declare (not safe))
                                        (error '"No clause matching"
                                               _%$%stack72927299%_
                                               '([member . rest])))
                                      '#!void))
                                   (_%$%K72957310%_
                                    (lambda (_%rest7305%_ _%member7306%_)
                                      (set! _%stack7022%_ _%rest7305%_)
                                      (vector-set!
                                       _%indices7018%_
                                       _%member7306%_
                                       '#t)
                                      (let ((_%collected7308%_
                                             (cons _%member7306%_
                                                   _%members7291%_)))
                                        (if (fx= _%member7306%_ _%node7287%_)
                                            (set! _%components7024%_
                                                  (cons _%collected7308%_
                                                        _%components7024%_))
                                            (_%pop7289%_
                                             _%collected7308%_))))))
                              (if (pair? _%$%stack72927299%_)
                                  (let ((_%$%hd72967313%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%stack72927299%_)))
                                        (_%$%tl72977315%_
                                         (let ()
                                           (declare (not safe))
                                           (##cdr _%$%stack72927299%_))))
                                    (let* ((_%member7318%_ _%$%hd72967313%_)
                                           (_%rest7320%_ _%$%tl72977315%_))
                                      (_%$%K72957310%_
                                       _%rest7320%_
                                       _%member7318%_)))
                                  (_%$%E72947302%_))))
                          '#!void)))
                   (_%__advance7170%_
                    (lambda (_%node7241%_ _%remaining7242%_ _%frame7243%_)
                      (let* ((_%frame7246%_ _%frame7243%_)
                             (_%$%remaining72547261%_ _%remaining7242%_)
                             (_%$%E72567264%_
                              (lambda ()
                                (let ()
                                  (declare (not safe))
                                  (error '"No clause matching"
                                         _%$%remaining72547261%_
                                         '([neighbor . rest])))
                                '#!void))
                             (_%$%K72577275%_
                              (lambda (_%rest7267%_ _%neighbor7268%_)
                                (let ()
                                  (declare (not safe))
                                  (##unchecked-structure-set!
                                   _%frame7246%_
                                   _%rest7267%_
                                   '2
                                   '#f
                                   '#f))
                                (let ((_%index7270%_
                                       (vector-ref
                                        _%indices7018%_
                                        _%neighbor7268%_)))
                                  (if _%index7270%_
                                      (if (eq? _%index7270%_ '#t)
                                          _%frame7246%_
                                          (let ()
                                            (_%lower!7028%_
                                             _%node7241%_
                                             _%index7270%_)
                                            _%frame7246%_))
                                      (_%enter7027%_
                                       _%neighbor7268%_
                                       _%frame7246%_))))))
                        (if (pair? _%$%remaining72547261%_)
                            (let ((_%$%hd72587278%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%remaining72547261%_)))
                                  (_%$%tl72597280%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%remaining72547261%_))))
                              (let* ((_%neighbor7283%_ _%$%hd72587278%_)
                                     (_%rest7285%_ _%$%tl72597280%_))
                                (_%$%K72577275%_
                                 _%rest7285%_
                                 _%neighbor7283%_)))
                            (_%$%E72567264%_)))))
                   (_%advance7171%_
                    (lambda (_%node7227%_ _%remaining7228%_ _%frame7229%_)
                      (let ((_%frame7232%_ _%frame7229%_))
                        (_%__advance7170%_
                         _%node7227%_
                         _%remaining7228%_
                         _%frame7232%_))))
                   (_%leave7172%_
                    (lambda (_%node7217%_ _%parent7218%_)
                      (_%finish7029%_ _%node7217%_)
                      (if _%parent7218%_
                          (let ((_%parent7220%_ _%parent7218%_))
                            (_%lower!7028%_
                             (let ()
                               (declare (not safe))
                               (##unchecked-structure-ref
                                _%parent7220%_
                                '1
                                '#f
                                '#f))
                             (vector-ref _%lowlinks7020%_ _%node7217%_)))
                          '#!void)
                      _%parent7218%_))
                   (_%traverse7173%_
                    (lambda (_%root7179%_)
                      (let _%walk7181%_ ((_%frame7183%_
                                          (_%enter7027%_ _%root7179%_ '#f)))
                        (if _%frame7183%_
                            (let ((_%frame7185%_ _%frame7183%_))
                              (_%walk7181%_
                               (if (pair? (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%frame7185%_
                                             '2
                                             '#f
                                             '#f)))
                                   (let* ((_%node7194%_
                                           (let ()
                                             (declare (not safe))
                                             (##unchecked-structure-ref
                                              _%frame7185%_
                                              '1
                                              '#f
                                              '#f)))
                                          (_%remaining7197%_
                                           (let ()
                                             (declare (not safe))
                                             (##unchecked-structure-ref
                                              _%frame7185%_
                                              '2
                                              '#f
                                              '#f)))
                                          (_%frame7200%_ _%frame7185%_)
                                          (_%frame7204%_ _%frame7200%_))
                                     (_%__advance7170%_
                                      _%node7194%_
                                      _%remaining7197%_
                                      _%frame7204%_))
                                   (_%leave7172%_
                                    (let ()
                                      (declare (not safe))
                                      (##unchecked-structure-ref
                                       _%frame7185%_
                                       '1
                                       '#f
                                       '#f))
                                    (let ()
                                      (declare (not safe))
                                      (##unchecked-structure-ref
                                       _%frame7185%_
                                       '3
                                       '#f
                                       '#f))))))
                            '#!void)))))
            (let _%roots7175%_ ((_%root7177%_ '0))
              (if (let ()
                    (declare (not safe))
                    (##fx< _%root7177%_ _%count7014%_))
                  (begin
                    (if (vector-ref _%indices7018%_ _%root7177%_)
                        '#!void
                        (_%traverse7173%_ _%root7177%_))
                    (_%roots7175%_
                     (let () (declare (not safe)) (##fx+ _%root7177%_ '1))))
                  '#!void))
            _%components7024%_))))))
