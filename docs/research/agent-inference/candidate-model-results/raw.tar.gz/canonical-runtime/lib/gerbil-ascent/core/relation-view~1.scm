(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/core/relation-view[1]#_g33382_|
    (##structure
     gx#syntax-quote::t
     'relation-view::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33384_|
    (##structure
     gx#syntax-quote::t
     'make-relation-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33386_|
    (##structure
     gx#syntax-quote::t
     'relation-view?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33388_|
    (##structure
     gx#syntax-quote::t
     'relation-view-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33389_|
    (##structure
     gx#syntax-quote::t
     'relation-view-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33390_|
    (##structure
     gx#syntax-quote::t
     'relation-view-revision
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33391_|
    (##structure
     gx#syntax-quote::t
     'relation-view-lane
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33392_|
    (##structure
     gx#syntax-quote::t
     'relation-view-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33393_|
    (##structure
     gx#syntax-quote::t
     'relation-view-units
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33394_|
    (##structure
     gx#syntax-quote::t
     'relation-view-visit
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33395_|
    (##structure
     gx#syntax-quote::t
     'relation-view-contains
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33396_|
    (##structure
     gx#syntax-quote::t
     'relation-view-export
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33397_|
    (##structure
     gx#syntax-quote::t
     'relation-view-parts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33399_|
    (##structure
     gx#syntax-quote::t
     'relation-view-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33400_|
    (##structure
     gx#syntax-quote::t
     'relation-view-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33401_|
    (##structure
     gx#syntax-quote::t
     'relation-view-revision-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33402_|
    (##structure
     gx#syntax-quote::t
     'relation-view-lane-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33403_|
    (##structure
     gx#syntax-quote::t
     'relation-view-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33404_|
    (##structure
     gx#syntax-quote::t
     'relation-view-units-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33405_|
    (##structure
     gx#syntax-quote::t
     'relation-view-visit-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33406_|
    (##structure
     gx#syntax-quote::t
     'relation-view-contains-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33407_|
    (##structure
     gx#syntax-quote::t
     'relation-view-export-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33408_|
    (##structure
     gx#syntax-quote::t
     'relation-view-parts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33410_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33411_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33412_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-revision
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33413_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-lane
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33414_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33415_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-units
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33416_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-visit
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33417_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-contains
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33418_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-export
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33419_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-parts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33421_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33422_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33423_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-revision-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33424_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-lane-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33425_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33426_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-units-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33427_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-visit-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33428_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-contains-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33429_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-export-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33430_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-parts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33432_|
    (##structure
     gx#syntax-quote::t
     'part-visitors::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33434_|
    (##structure
     gx#syntax-quote::t
     'make-part-visitors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33436_|
    (##structure
     gx#syntax-quote::t
     'part-visitors?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33438_|
    (##structure
     gx#syntax-quote::t
     'part-visitors-checked
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33439_|
    (##structure
     gx#syntax-quote::t
     'part-visitors-admitted
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33441_|
    (##structure
     gx#syntax-quote::t
     'part-visitors-checked-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33442_|
    (##structure
     gx#syntax-quote::t
     'part-visitors-admitted-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33444_|
    (##structure
     gx#syntax-quote::t
     '&part-visitors-checked
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33445_|
    (##structure
     gx#syntax-quote::t
     '&part-visitors-admitted
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33447_|
    (##structure
     gx#syntax-quote::t
     '&part-visitors-checked-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33448_|
    (##structure
     gx#syntax-quote::t
     '&part-visitors-admitted-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33450_|
    (##structure
     gx#syntax-quote::t
     'row-stream::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33452_|
    (##structure
     gx#syntax-quote::t
     'make-row-stream
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33454_|
    (##structure
     gx#syntax-quote::t
     'row-stream?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33456_|
    (##structure
     gx#syntax-quote::t
     'row-stream-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33457_|
    (##structure
     gx#syntax-quote::t
     'row-stream-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33458_|
    (##structure
     gx#syntax-quote::t
     'row-stream-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33460_|
    (##structure
     gx#syntax-quote::t
     'row-stream-view-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33461_|
    (##structure
     gx#syntax-quote::t
     'row-stream-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33462_|
    (##structure
     gx#syntax-quote::t
     'row-stream-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33464_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33465_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33466_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33468_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-view-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33469_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33470_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33472_|
    (##structure
     gx#syntax-quote::t
     'rectangle::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33474_|
    (##structure
     gx#syntax-quote::t
     'make-rectangle
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33476_|
    (##structure
     gx#syntax-quote::t
     'rectangle?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33478_|
    (##structure
     gx#syntax-quote::t
     'rectangle-prefix
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33479_|
    (##structure
     gx#syntax-quote::t
     'rectangle-left
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33480_|
    (##structure
     gx#syntax-quote::t
     'rectangle-right
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33482_|
    (##structure
     gx#syntax-quote::t
     'rectangle-prefix-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33483_|
    (##structure
     gx#syntax-quote::t
     'rectangle-left-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33484_|
    (##structure
     gx#syntax-quote::t
     'rectangle-right-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33486_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-prefix
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33487_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-left
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33488_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-right
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33490_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-prefix-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33491_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-left-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33492_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-right-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33494_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33496_|
    (##structure
     gx#syntax-quote::t
     'make-rectangle-bucket
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33498_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33500_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33501_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-blocks
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33502_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33503_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-plain
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33505_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33506_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-blocks-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33507_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33508_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-plain-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33510_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33511_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-blocks
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33512_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33513_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-plain
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33515_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33516_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-blocks-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33517_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33518_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-plain-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/core/relation-view[:0:]#relation-view|
      (let ((__obj33108
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33108
           'gerbil-ascent/core/relation-view#relation-view::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33108 'relation-view '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33108
           '(identity
             generation
             revision
             lane
             count
             units
             visit
             contains
             export
             parts)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33108
           '(identity
             generation
             revision
             lane
             count
             units
             visit
             contains
             export
             parts)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33108 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33108 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33108 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33108 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33108 '#f '13 '#f '#f))
        (let ((__tmp33381 |gerbil-ascent/core/relation-view[1]#_g33382_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33108 __tmp33381 '4 '#f '#f))
        (let ((__tmp33383 |gerbil-ascent/core/relation-view[1]#_g33384_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33108 __tmp33383 '14 '#f '#f))
        (let ((__tmp33385 |gerbil-ascent/core/relation-view[1]#_g33386_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33108 __tmp33385 '15 '#f '#f))
        (let ((__tmp33387
               (cons (cons 'identity
                           |gerbil-ascent/core/relation-view[1]#_g33388_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/core/relation-view[1]#_g33389_|)
                           (cons (cons 'revision
                                       |gerbil-ascent/core/relation-view[1]#_g33390_|)
                                 (cons (cons 'lane
                                             |gerbil-ascent/core/relation-view[1]#_g33391_|)
                                       (cons (cons 'count
                                                   |gerbil-ascent/core/relation-view[1]#_g33392_|)
                                             (cons (cons 'units
                                                         |gerbil-ascent/core/relation-view[1]#_g33393_|)
                                                   (cons (cons 'visit
                                                               |gerbil-ascent/core/relation-view[1]#_g33394_|)
                                                         (cons (cons 'contains
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/core/relation-view[1]#_g33395_|)
                       (cons (cons 'export
                                   |gerbil-ascent/core/relation-view[1]#_g33396_|)
                             (cons (cons 'parts
                                         |gerbil-ascent/core/relation-view[1]#_g33397_|)
                                   '()))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33108 __tmp33387 '16 '#f '#f))
        (let ((__tmp33398
               (cons (cons 'identity
                           |gerbil-ascent/core/relation-view[1]#_g33399_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/core/relation-view[1]#_g33400_|)
                           (cons (cons 'revision
                                       |gerbil-ascent/core/relation-view[1]#_g33401_|)
                                 (cons (cons 'lane
                                             |gerbil-ascent/core/relation-view[1]#_g33402_|)
                                       (cons (cons 'count
                                                   |gerbil-ascent/core/relation-view[1]#_g33403_|)
                                             (cons (cons 'units
                                                         |gerbil-ascent/core/relation-view[1]#_g33404_|)
                                                   (cons (cons 'visit
                                                               |gerbil-ascent/core/relation-view[1]#_g33405_|)
                                                         (cons (cons 'contains
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/core/relation-view[1]#_g33406_|)
                       (cons (cons 'export
                                   |gerbil-ascent/core/relation-view[1]#_g33407_|)
                             (cons (cons 'parts
                                         |gerbil-ascent/core/relation-view[1]#_g33408_|)
                                   '()))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33108 __tmp33398 '17 '#f '#f))
        (let ((__tmp33409
               (cons (cons 'identity
                           |gerbil-ascent/core/relation-view[1]#_g33410_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/core/relation-view[1]#_g33411_|)
                           (cons (cons 'revision
                                       |gerbil-ascent/core/relation-view[1]#_g33412_|)
                                 (cons (cons 'lane
                                             |gerbil-ascent/core/relation-view[1]#_g33413_|)
                                       (cons (cons 'count
                                                   |gerbil-ascent/core/relation-view[1]#_g33414_|)
                                             (cons (cons 'units
                                                         |gerbil-ascent/core/relation-view[1]#_g33415_|)
                                                   (cons (cons 'visit
                                                               |gerbil-ascent/core/relation-view[1]#_g33416_|)
                                                         (cons (cons 'contains
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/core/relation-view[1]#_g33417_|)
                       (cons (cons 'export
                                   |gerbil-ascent/core/relation-view[1]#_g33418_|)
                             (cons (cons 'parts
                                         |gerbil-ascent/core/relation-view[1]#_g33419_|)
                                   '()))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33108 __tmp33409 '18 '#f '#f))
        (let ((__tmp33420
               (cons (cons 'identity
                           |gerbil-ascent/core/relation-view[1]#_g33421_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/core/relation-view[1]#_g33422_|)
                           (cons (cons 'revision
                                       |gerbil-ascent/core/relation-view[1]#_g33423_|)
                                 (cons (cons 'lane
                                             |gerbil-ascent/core/relation-view[1]#_g33424_|)
                                       (cons (cons 'count
                                                   |gerbil-ascent/core/relation-view[1]#_g33425_|)
                                             (cons (cons 'units
                                                         |gerbil-ascent/core/relation-view[1]#_g33426_|)
                                                   (cons (cons 'visit
                                                               |gerbil-ascent/core/relation-view[1]#_g33427_|)
                                                         (cons (cons 'contains
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/core/relation-view[1]#_g33428_|)
                       (cons (cons 'export
                                   |gerbil-ascent/core/relation-view[1]#_g33429_|)
                             (cons (cons 'parts
                                         |gerbil-ascent/core/relation-view[1]#_g33430_|)
                                   '()))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33108 __tmp33420 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33108 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33108 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33108 '() '21 '#f '#f))
        __obj33108))
    (define |gerbil-ascent/core/relation-view[:0:]#part-visitors|
      (let ((__obj33109
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33109
           'gerbil-ascent/core/relation-view#part-visitors::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33109 'part-visitors '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33109
           '(checked admitted)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33109
           '(checked admitted)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33109 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33109 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33109 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33109 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33109 '#f '13 '#f '#f))
        (let ((__tmp33431 |gerbil-ascent/core/relation-view[1]#_g33432_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33109 __tmp33431 '4 '#f '#f))
        (let ((__tmp33433 |gerbil-ascent/core/relation-view[1]#_g33434_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33109 __tmp33433 '14 '#f '#f))
        (let ((__tmp33435 |gerbil-ascent/core/relation-view[1]#_g33436_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33109 __tmp33435 '15 '#f '#f))
        (let ((__tmp33437
               (cons (cons 'checked
                           |gerbil-ascent/core/relation-view[1]#_g33438_|)
                     (cons (cons 'admitted
                                 |gerbil-ascent/core/relation-view[1]#_g33439_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33109 __tmp33437 '16 '#f '#f))
        (let ((__tmp33440
               (cons (cons 'checked
                           |gerbil-ascent/core/relation-view[1]#_g33441_|)
                     (cons (cons 'admitted
                                 |gerbil-ascent/core/relation-view[1]#_g33442_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33109 __tmp33440 '17 '#f '#f))
        (let ((__tmp33443
               (cons (cons 'checked
                           |gerbil-ascent/core/relation-view[1]#_g33444_|)
                     (cons (cons 'admitted
                                 |gerbil-ascent/core/relation-view[1]#_g33445_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33109 __tmp33443 '18 '#f '#f))
        (let ((__tmp33446
               (cons (cons 'checked
                           |gerbil-ascent/core/relation-view[1]#_g33447_|)
                     (cons (cons 'admitted
                                 |gerbil-ascent/core/relation-view[1]#_g33448_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33109 __tmp33446 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33109 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33109 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33109 '() '21 '#f '#f))
        __obj33109))
    (define |gerbil-ascent/core/relation-view[:0:]#row-stream|
      (let ((__obj33110
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33110
           'gerbil-ascent/core/relation-view#row-stream::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33110 'row-stream '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33110
           '(view columns key)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33110
           '(view columns key)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33110 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33110 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33110 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33110 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33110 '#f '13 '#f '#f))
        (let ((__tmp33449 |gerbil-ascent/core/relation-view[1]#_g33450_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33110 __tmp33449 '4 '#f '#f))
        (let ((__tmp33451 |gerbil-ascent/core/relation-view[1]#_g33452_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33110 __tmp33451 '14 '#f '#f))
        (let ((__tmp33453 |gerbil-ascent/core/relation-view[1]#_g33454_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33110 __tmp33453 '15 '#f '#f))
        (let ((__tmp33455
               (cons (cons 'view
                           |gerbil-ascent/core/relation-view[1]#_g33456_|)
                     (cons (cons 'columns
                                 |gerbil-ascent/core/relation-view[1]#_g33457_|)
                           (cons (cons 'key
                                       |gerbil-ascent/core/relation-view[1]#_g33458_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33110 __tmp33455 '16 '#f '#f))
        (let ((__tmp33459
               (cons (cons 'view
                           |gerbil-ascent/core/relation-view[1]#_g33460_|)
                     (cons (cons 'columns
                                 |gerbil-ascent/core/relation-view[1]#_g33461_|)
                           (cons (cons 'key
                                       |gerbil-ascent/core/relation-view[1]#_g33462_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33110 __tmp33459 '17 '#f '#f))
        (let ((__tmp33463
               (cons (cons 'view
                           |gerbil-ascent/core/relation-view[1]#_g33464_|)
                     (cons (cons 'columns
                                 |gerbil-ascent/core/relation-view[1]#_g33465_|)
                           (cons (cons 'key
                                       |gerbil-ascent/core/relation-view[1]#_g33466_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33110 __tmp33463 '18 '#f '#f))
        (let ((__tmp33467
               (cons (cons 'view
                           |gerbil-ascent/core/relation-view[1]#_g33468_|)
                     (cons (cons 'columns
                                 |gerbil-ascent/core/relation-view[1]#_g33469_|)
                           (cons (cons 'key
                                       |gerbil-ascent/core/relation-view[1]#_g33470_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33110 __tmp33467 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33110 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33110 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33110 '() '21 '#f '#f))
        __obj33110))
    (define |gerbil-ascent/core/relation-view[:0:]#rectangle|
      (let ((__obj33111
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33111
           'gerbil-ascent/core/relation-view#rectangle::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33111 'rectangle '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33111
           '(prefix left right)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33111
           '(prefix left right)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33111 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33111 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33111 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33111 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33111 '#f '13 '#f '#f))
        (let ((__tmp33471 |gerbil-ascent/core/relation-view[1]#_g33472_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33111 __tmp33471 '4 '#f '#f))
        (let ((__tmp33473 |gerbil-ascent/core/relation-view[1]#_g33474_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33111 __tmp33473 '14 '#f '#f))
        (let ((__tmp33475 |gerbil-ascent/core/relation-view[1]#_g33476_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33111 __tmp33475 '15 '#f '#f))
        (let ((__tmp33477
               (cons (cons 'prefix
                           |gerbil-ascent/core/relation-view[1]#_g33478_|)
                     (cons (cons 'left
                                 |gerbil-ascent/core/relation-view[1]#_g33479_|)
                           (cons (cons 'right
                                       |gerbil-ascent/core/relation-view[1]#_g33480_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33111 __tmp33477 '16 '#f '#f))
        (let ((__tmp33481
               (cons (cons 'prefix
                           |gerbil-ascent/core/relation-view[1]#_g33482_|)
                     (cons (cons 'left
                                 |gerbil-ascent/core/relation-view[1]#_g33483_|)
                           (cons (cons 'right
                                       |gerbil-ascent/core/relation-view[1]#_g33484_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33111 __tmp33481 '17 '#f '#f))
        (let ((__tmp33485
               (cons (cons 'prefix
                           |gerbil-ascent/core/relation-view[1]#_g33486_|)
                     (cons (cons 'left
                                 |gerbil-ascent/core/relation-view[1]#_g33487_|)
                           (cons (cons 'right
                                       |gerbil-ascent/core/relation-view[1]#_g33488_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33111 __tmp33485 '18 '#f '#f))
        (let ((__tmp33489
               (cons (cons 'prefix
                           |gerbil-ascent/core/relation-view[1]#_g33490_|)
                     (cons (cons 'left
                                 |gerbil-ascent/core/relation-view[1]#_g33491_|)
                           (cons (cons 'right
                                       |gerbil-ascent/core/relation-view[1]#_g33492_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33111 __tmp33489 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33111 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33111 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33111 '() '21 '#f '#f))
        __obj33111))
    (define |gerbil-ascent/core/relation-view[:0:]#rectangle-bucket|
      (let ((__obj33112
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33112
           'gerbil-ascent/core/relation-view#rectangle-bucket::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33112 'rectangle-bucket '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33112
           '(members blocks count plain)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33112
           '(members blocks count plain)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33112 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33112 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33112 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33112 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33112 '#f '13 '#f '#f))
        (let ((__tmp33493 |gerbil-ascent/core/relation-view[1]#_g33494_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33112 __tmp33493 '4 '#f '#f))
        (let ((__tmp33495 |gerbil-ascent/core/relation-view[1]#_g33496_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33112 __tmp33495 '14 '#f '#f))
        (let ((__tmp33497 |gerbil-ascent/core/relation-view[1]#_g33498_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33112 __tmp33497 '15 '#f '#f))
        (let ((__tmp33499
               (cons (cons 'members
                           |gerbil-ascent/core/relation-view[1]#_g33500_|)
                     (cons (cons 'blocks
                                 |gerbil-ascent/core/relation-view[1]#_g33501_|)
                           (cons (cons 'count
                                       |gerbil-ascent/core/relation-view[1]#_g33502_|)
                                 (cons (cons 'plain
                                             |gerbil-ascent/core/relation-view[1]#_g33503_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33112 __tmp33499 '16 '#f '#f))
        (let ((__tmp33504
               (cons (cons 'members
                           |gerbil-ascent/core/relation-view[1]#_g33505_|)
                     (cons (cons 'blocks
                                 |gerbil-ascent/core/relation-view[1]#_g33506_|)
                           (cons (cons 'count
                                       |gerbil-ascent/core/relation-view[1]#_g33507_|)
                                 (cons (cons 'plain
                                             |gerbil-ascent/core/relation-view[1]#_g33508_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33112 __tmp33504 '17 '#f '#f))
        (let ((__tmp33509
               (cons (cons 'members
                           |gerbil-ascent/core/relation-view[1]#_g33510_|)
                     (cons (cons 'blocks
                                 |gerbil-ascent/core/relation-view[1]#_g33511_|)
                           (cons (cons 'count
                                       |gerbil-ascent/core/relation-view[1]#_g33512_|)
                                 (cons (cons 'plain
                                             |gerbil-ascent/core/relation-view[1]#_g33513_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33112 __tmp33509 '18 '#f '#f))
        (let ((__tmp33514
               (cons (cons 'members
                           |gerbil-ascent/core/relation-view[1]#_g33515_|)
                     (cons (cons 'blocks
                                 |gerbil-ascent/core/relation-view[1]#_g33516_|)
                           (cons (cons 'count
                                       |gerbil-ascent/core/relation-view[1]#_g33517_|)
                                 (cons (cons 'plain
                                             |gerbil-ascent/core/relation-view[1]#_g33518_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33112 __tmp33514 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33112 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33112 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33112 '() '21 '#f '#f))
        __obj33112))))
