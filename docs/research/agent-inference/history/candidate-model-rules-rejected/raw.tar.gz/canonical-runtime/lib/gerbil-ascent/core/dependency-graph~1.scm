(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/core/dependency-graph[1]#_g33498_|
    (##structure
     gx#syntax-quote::t
     'graph-frame::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33500_|
    (##structure
     gx#syntax-quote::t
     'make-graph-frame
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33502_|
    (##structure
     gx#syntax-quote::t
     'graph-frame?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33504_|
    (##structure
     gx#syntax-quote::t
     'graph-frame-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33505_|
    (##structure
     gx#syntax-quote::t
     'graph-frame-remaining
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33506_|
    (##structure
     gx#syntax-quote::t
     'graph-frame-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33508_|
    (##structure
     gx#syntax-quote::t
     'graph-frame-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33509_|
    (##structure
     gx#syntax-quote::t
     'graph-frame-remaining-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33510_|
    (##structure
     gx#syntax-quote::t
     'graph-frame-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33512_|
    (##structure
     gx#syntax-quote::t
     '&graph-frame-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33513_|
    (##structure
     gx#syntax-quote::t
     '&graph-frame-remaining
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33514_|
    (##structure
     gx#syntax-quote::t
     '&graph-frame-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33516_|
    (##structure
     gx#syntax-quote::t
     '&graph-frame-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33517_|
    (##structure
     gx#syntax-quote::t
     '&graph-frame-remaining-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33518_|
    (##structure
     gx#syntax-quote::t
     '&graph-frame-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[:0:]#graph-frame|
    (let ((__obj33337
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj33337
         'gerbil-ascent/core/dependency-graph#graph-frame::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33337 'graph-frame '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj33337
         '(node remaining parent)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj33337
         '(node remaining parent)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33337 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33337 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33337 '#t '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33337 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33337 '#f '13 '#f '#f))
      (let ((__tmp33497 |gerbil-ascent/core/dependency-graph[1]#_g33498_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj33337 __tmp33497 '4 '#f '#f))
      (let ((__tmp33499 |gerbil-ascent/core/dependency-graph[1]#_g33500_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj33337 __tmp33499 '14 '#f '#f))
      (let ((__tmp33501 |gerbil-ascent/core/dependency-graph[1]#_g33502_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj33337 __tmp33501 '15 '#f '#f))
      (let ((__tmp33503
             (cons (cons 'node
                         |gerbil-ascent/core/dependency-graph[1]#_g33504_|)
                   (cons (cons 'remaining
                               |gerbil-ascent/core/dependency-graph[1]#_g33505_|)
                         (cons (cons 'parent
                                     |gerbil-ascent/core/dependency-graph[1]#_g33506_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33337 __tmp33503 '16 '#f '#f))
      (let ((__tmp33507
             (cons (cons 'node
                         |gerbil-ascent/core/dependency-graph[1]#_g33508_|)
                   (cons (cons 'remaining
                               |gerbil-ascent/core/dependency-graph[1]#_g33509_|)
                         (cons (cons 'parent
                                     |gerbil-ascent/core/dependency-graph[1]#_g33510_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33337 __tmp33507 '17 '#f '#f))
      (let ((__tmp33511
             (cons (cons 'node
                         |gerbil-ascent/core/dependency-graph[1]#_g33512_|)
                   (cons (cons 'remaining
                               |gerbil-ascent/core/dependency-graph[1]#_g33513_|)
                         (cons (cons 'parent
                                     |gerbil-ascent/core/dependency-graph[1]#_g33514_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33337 __tmp33511 '18 '#f '#f))
      (let ((__tmp33515
             (cons (cons 'node
                         |gerbil-ascent/core/dependency-graph[1]#_g33516_|)
                   (cons (cons 'remaining
                               |gerbil-ascent/core/dependency-graph[1]#_g33517_|)
                         (cons (cons 'parent
                                     |gerbil-ascent/core/dependency-graph[1]#_g33518_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33337 __tmp33515 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33337 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33337 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33337 '() '21 '#f '#f))
      __obj33337)))
