(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/trrel[1]#_g5754_|
    (##structure
     gx#syntax-quote::t
     'trrel-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g5756_|
    (##structure
     gx#syntax-quote::t
     'make-trrel-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g5758_|
    (##structure
     gx#syntax-quote::t
     'trrel-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g5760_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-known
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g5761_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g5762_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-successors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g5764_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-known-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g5765_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g5766_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-successors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g5768_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-known
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g5769_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g5770_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-successors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g5772_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-known-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g5773_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g5774_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-successors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[:0:]#trrel-state|
    (let ((__obj5747
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj5747
         'gerbil-ascent/table/trrel#trrel-state::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj5747 'trrel-state '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj5747
         '(known predecessors successors)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj5747
         '(known predecessors successors)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj5747 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj5747 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj5747 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj5747 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj5747 '#f '13 '#f '#f))
      (let ((__tmp5753 |gerbil-ascent/table/trrel[1]#_g5754_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj5747 __tmp5753 '4 '#f '#f))
      (let ((__tmp5755 |gerbil-ascent/table/trrel[1]#_g5756_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj5747 __tmp5755 '14 '#f '#f))
      (let ((__tmp5757 |gerbil-ascent/table/trrel[1]#_g5758_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj5747 __tmp5757 '15 '#f '#f))
      (let ((__tmp5759
             (cons (cons 'known |gerbil-ascent/table/trrel[1]#_g5760_|)
                   (cons (cons 'predecessors
                               |gerbil-ascent/table/trrel[1]#_g5761_|)
                         (cons (cons 'successors
                                     |gerbil-ascent/table/trrel[1]#_g5762_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj5747 __tmp5759 '16 '#f '#f))
      (let ((__tmp5763
             (cons (cons 'known |gerbil-ascent/table/trrel[1]#_g5764_|)
                   (cons (cons 'predecessors
                               |gerbil-ascent/table/trrel[1]#_g5765_|)
                         (cons (cons 'successors
                                     |gerbil-ascent/table/trrel[1]#_g5766_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj5747 __tmp5763 '17 '#f '#f))
      (let ((__tmp5767
             (cons (cons 'known |gerbil-ascent/table/trrel[1]#_g5768_|)
                   (cons (cons 'predecessors
                               |gerbil-ascent/table/trrel[1]#_g5769_|)
                         (cons (cons 'successors
                                     |gerbil-ascent/table/trrel[1]#_g5770_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj5747 __tmp5767 '18 '#f '#f))
      (let ((__tmp5771
             (cons (cons 'known |gerbil-ascent/table/trrel[1]#_g5772_|)
                   (cons (cons 'predecessors
                               |gerbil-ascent/table/trrel[1]#_g5773_|)
                         (cons (cons 'successors
                                     |gerbil-ascent/table/trrel[1]#_g5774_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj5747 __tmp5771 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj5747 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj5747 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj5747 '() '21 '#f '#f))
      __obj5747)))
