(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/trrel-uf::timestamp 1791687543)
  (begin
    (define gerbil-ascent/table/trrel-uf#uf-node::t
      (let ((__tmp5202 (list)) (__tmp5201 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/trrel-uf#uf-node::t
         'uf-node
         __tmp5202
         '(parent members size reach predecessors order)
         __tmp5201
         '#f)))
    (define gerbil-ascent/table/trrel-uf#uf-node?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/trrel-uf#uf-node::t)))
    (define gerbil-ascent/table/trrel-uf#make-uf-node
      (lambda _%$args5195%_
        (apply make-instance
               gerbil-ascent/table/trrel-uf#uf-node::t
               _%$args5195%_)))
    (define gerbil-ascent/table/trrel-uf#uf-node-parent
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'parent)))
    (define gerbil-ascent/table/trrel-uf#uf-node-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'members)))
    (define gerbil-ascent/table/trrel-uf#uf-node-size
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'size)))
    (define gerbil-ascent/table/trrel-uf#uf-node-reach
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'reach)))
    (define gerbil-ascent/table/trrel-uf#uf-node-predecessors
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'predecessors)))
    (define gerbil-ascent/table/trrel-uf#uf-node-order
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'order)))
    (define gerbil-ascent/table/trrel-uf#uf-node-parent-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'parent)))
    (define gerbil-ascent/table/trrel-uf#uf-node-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'members)))
    (define gerbil-ascent/table/trrel-uf#uf-node-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'size)))
    (define gerbil-ascent/table/trrel-uf#uf-node-reach-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'reach)))
    (define gerbil-ascent/table/trrel-uf#uf-node-predecessors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'predecessors)))
    (define gerbil-ascent/table/trrel-uf#uf-node-order-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'order)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-parent
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'parent)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'members)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-size
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'size)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-reach
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'reach)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-predecessors
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'predecessors)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-order
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'order)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-parent-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'parent)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'members)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'size)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-reach-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'reach)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-predecessors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'predecessors)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-order-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'order)))
    (define gerbil-ascent/table/trrel-uf#uf-group::t
      (let ((__tmp5204 (list)) (__tmp5203 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/trrel-uf#uf-group::t
         'uf-group
         __tmp5204
         '(nodes roots next-order indexed?)
         __tmp5203
         '#f)))
    (define gerbil-ascent/table/trrel-uf#uf-group?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/trrel-uf#uf-group::t)))
    (define gerbil-ascent/table/trrel-uf#make-uf-group
      (lambda _%$args5192%_
        (apply make-instance
               gerbil-ascent/table/trrel-uf#uf-group::t
               _%$args5192%_)))
    (define gerbil-ascent/table/trrel-uf#uf-group-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'nodes)))
    (define gerbil-ascent/table/trrel-uf#uf-group-roots
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'roots)))
    (define gerbil-ascent/table/trrel-uf#uf-group-next-order
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'next-order)))
    (define gerbil-ascent/table/trrel-uf#uf-group-indexed?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'indexed?)))
    (define gerbil-ascent/table/trrel-uf#uf-group-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'nodes)))
    (define gerbil-ascent/table/trrel-uf#uf-group-roots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'roots)))
    (define gerbil-ascent/table/trrel-uf#uf-group-next-order-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'next-order)))
    (define gerbil-ascent/table/trrel-uf#uf-group-indexed?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'indexed?)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'nodes)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-roots
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'roots)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-next-order
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'next-order)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-indexed?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'indexed?)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'nodes)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-roots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'roots)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-next-order-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'next-order)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-indexed?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'indexed?)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion::t
      (let ((__tmp5206 (list))
            (__tmp5205
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/trrel-uf#uf-insertion::t
         'uf-insertion
         __tmp5206
         '(group-key group row left-node right-node a b)
         __tmp5205
         '#f)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/trrel-uf#uf-insertion::t)))
    (define gerbil-ascent/table/trrel-uf#make-uf-insertion
      (lambda _%$args5189%_
        (apply make-instance
               gerbil-ascent/table/trrel-uf#uf-insertion::t
               _%$args5189%_)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-group-key
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group-key)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-group
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-row
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'row)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-left-node
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'left-node)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-right-node
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'right-node)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-a
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'a)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-b
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'b)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-group-key-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group-key)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-group-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-row-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'row)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-left-node-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'left-node)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-right-node-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'right-node)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-a-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'a)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-b-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'b)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-group-key
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group-key)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-group
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-row
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'row)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-left-node
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'left-node)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-right-node
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'right-node)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-a
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'a)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-b
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'b)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-group-key-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group-key)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-group-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-row-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'row)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-left-node-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'left-node)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-right-node-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'right-node)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-a-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'a)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-b-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'b)))
    (define gerbil-ascent/table/trrel-uf#frozen-members::t
      (let ((__tmp5208 (list))
            (__tmp5207
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/trrel-uf#frozen-members::t
         'frozen-members
         __tmp5208
         '(rows count)
         __tmp5207
         '#f)))
    (define gerbil-ascent/table/trrel-uf#frozen-members?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/table/trrel-uf#frozen-members::t)))
    (define gerbil-ascent/table/trrel-uf#make-frozen-members
      (lambda _%$args5186%_
        (apply make-instance
               gerbil-ascent/table/trrel-uf#frozen-members::t
               _%$args5186%_)))
    (define gerbil-ascent/table/trrel-uf#frozen-members-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'rows)))
    (define gerbil-ascent/table/trrel-uf#frozen-members-count
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'count)))
    (define gerbil-ascent/table/trrel-uf#frozen-members-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'rows)))
    (define gerbil-ascent/table/trrel-uf#frozen-members-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'count)))
    (define gerbil-ascent/table/trrel-uf#&frozen-members-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'rows)))
    (define gerbil-ascent/table/trrel-uf#&frozen-members-count
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'count)))
    (define gerbil-ascent/table/trrel-uf#&frozen-members-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'rows)))
    (define gerbil-ascent/table/trrel-uf#&frozen-members-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'count)))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-state
      (lambda ()
        (let ()
          (declare (not safe))
          (make-hash-table__%
           '#f
           absent-value
           absent-value
           absent-value
           absent-value
           absent-value
           absent-value
           absent-value
           absent-value))))
    (define gerbil-ascent/table/trrel-uf#root
      (lambda (_%node5183%_)
        (if (##structure-ref
             _%node5183%_
             '1
             gerbil-ascent/table/trrel-uf#uf-node::t
             '#f)
            (gerbil-ascent/table/trrel-uf#root
             (##structure-ref
              _%node5183%_
              '1
              gerbil-ascent/table/trrel-uf#uf-node::t
              '#f))
            _%node5183%_)))
    (define gerbil-ascent/table/trrel-uf#reachable?
      (lambda (_%from5155%_ _%to5156%_)
        (let ((_%$e5158%_ (eq? _%from5155%_ _%to5156%_)))
          (if _%$e5158%_
              _%$e5158%_
              (let* ((_%h5161%_
                      (##structure-ref
                       _%from5155%_
                       '4
                       gerbil-ascent/table/trrel-uf#uf-node::t
                       '#f))
                     (_%key5164%_ _%to5156%_)
                     (_%h5168%_
                      (let ()
                        (declare (not safe))
                        (cast HashTable::interface _%h5161%_)))
                     (_%h5170%_ _%h5168%_))
                (declare (not safe))
                (__hash-get _%h5170%_ _%key5164%_))))))
    (define gerbil-ascent/table/trrel-uf#fresh
      (lambda (_%node5151%_ _%order5152%_ _%indexed?5153%_)
        (let ((__tmp5211 (list _%node5151%_))
              (__tmp5210 (let () (declare (not safe)) (make-hash-table-eq)))
              (__tmp5209
               (if _%indexed?5153%_
                   (let () (declare (not safe)) (make-hash-table-eq))
                   '#f)))
          (declare (not safe))
          (##structure
           gerbil-ascent/table/trrel-uf#uf-node::t
           '#f
           __tmp5211
           '1
           __tmp5210
           __tmp5209
           _%order5152%_))))
    (define gerbil-ascent/table/trrel-uf#ordered-neighbors
      (lambda (_%node5128%_ _%table5129%_)
        (let ((__tmp5213
               (lambda (_%a5131%_ _%b5132%_)
                 (> (##structure-ref
                     _%a5131%_
                     '6
                     gerbil-ascent/table/trrel-uf#uf-node::t
                     '#f)
                    (##structure-ref
                     _%b5132%_
                     '6
                     gerbil-ascent/table/trrel-uf#uf-node::t
                     '#f))))
              (__tmp5212
               (cons _%node5128%_
                     (let* ((_%h5134%_ _%table5129%_)
                            (_%h5138%_
                             (let ()
                               (declare (not safe))
                               (cast HashTable::interface _%h5134%_)))
                            (_%h5140%_ _%h5138%_))
                       (declare (not safe))
                       (__hash-keys _%h5140%_)))))
          (declare (not safe))
          (##list-sort __tmp5213 __tmp5212))))
    (define gerbil-ascent/table/trrel-uf#rebuild-predecessors!
      (lambda (_%roots5062%_)
        (for-each
         (lambda (_%n5064%_)
           (##structure-set!
            _%n5064%_
            (let () (declare (not safe)) (make-hash-table-eq))
            '5
            gerbil-ascent/table/trrel-uf#uf-node::t
            '#f))
         _%roots5062%_)
        (for-each
         (lambda (_%n5066%_)
           (let* ((_%proc5098%_
                   (lambda (_%target5068%_ _%_5069%_)
                     (let* ((_%h5071%_
                             (##structure-ref
                              _%target5068%_
                              '5
                              gerbil-ascent/table/trrel-uf#uf-node::t
                              '#f))
                            (_%key5074%_ _%n5066%_)
                            (_%value5077%_ '#t)
                            (_%h5081%_
                             (let ()
                               (declare (not safe))
                               (cast HashTable::interface _%h5071%_)))
                            (_%h5083%_ _%h5081%_))
                       (declare (not safe))
                       (__hash-put! _%h5083%_ _%key5074%_ _%value5077%_))))
                  (_%h5101%_
                   (##structure-ref
                    _%n5066%_
                    '4
                    gerbil-ascent/table/trrel-uf#uf-node::t
                    '#f))
                  (_%proc5106%_ _%proc5098%_)
                  (_%h5116%_
                   (let ()
                     (declare (not safe))
                     (cast HashTable::interface _%h5101%_)))
                  (_%h5118%_ _%h5116%_))
             (declare (not safe))
             (__hash-for-each _%proc5106%_ _%h5118%_)))
         _%roots5062%_)))
    (define gerbil-ascent/table/trrel-uf#retire-cycle-predecessors!
      (lambda (_%winner4981%_ _%cycle4982%_)
        (for-each
         (lambda (_%n4984%_)
           (if (eq? _%n4984%_ _%winner4981%_)
               '#!void
               (let* ((_%proc5012%_
                       (lambda (_%target4986%_ _%_4987%_)
                         (let* ((_%h4989%_
                                 (##structure-ref
                                  _%target4986%_
                                  '5
                                  gerbil-ascent/table/trrel-uf#uf-node::t
                                  '#f))
                                (_%key4992%_ _%n4984%_)
                                (_%h4996%_
                                 (let ()
                                   (declare (not safe))
                                   (cast HashTable::interface _%h4989%_)))
                                (_%h4998%_ _%h4996%_))
                           (declare (not safe))
                           (__hash-remove! _%h4998%_ _%key4992%_))))
                      (_%h5015%_
                       (##structure-ref
                        _%n4984%_
                        '4
                        gerbil-ascent/table/trrel-uf#uf-node::t
                        '#f))
                      (_%proc5020%_ _%proc5012%_)
                      (_%h5030%_
                       (let ()
                         (declare (not safe))
                         (cast HashTable::interface _%h5015%_)))
                      (_%h5032%_ _%h5030%_))
                 (declare (not safe))
                 (__hash-for-each _%proc5020%_ _%h5032%_)))
           (let* ((_%h5042%_
                   (##structure-ref
                    _%winner4981%_
                    '5
                    gerbil-ascent/table/trrel-uf#uf-node::t
                    '#f))
                  (_%key5045%_ _%n4984%_)
                  (_%h5049%_
                   (let ()
                     (declare (not safe))
                     (cast HashTable::interface _%h5042%_)))
                  (_%h5051%_ _%h5049%_))
             (declare (not safe))
             (__hash-remove! _%h5051%_ _%key5045%_)))
         _%cycle4982%_)))
    (define gerbil-ascent/table/trrel-uf#merge-cycle!
      (lambda (_%group4885%_ _%roots4886%_ _%cycle4887%_)
        (let* ((_%winner4892%_
                (let ((__tmp5216
                       (lambda (_%n4889%_ _%best4890%_)
                         (if (> (##structure-ref
                                 _%n4889%_
                                 '3
                                 gerbil-ascent/table/trrel-uf#uf-node::t
                                 '#f)
                                (##structure-ref
                                 _%best4890%_
                                 '3
                                 gerbil-ascent/table/trrel-uf#uf-node::t
                                 '#f))
                             _%n4889%_
                             _%best4890%_)))
                      (__tmp5215 (car _%cycle4887%_))
                      (__tmp5214 (cdr _%cycle4887%_)))
                  (declare (not safe))
                  (foldl__0 __tmp5216 __tmp5215 __tmp5214)))
               (_%merged4894%_
                (##structure-ref
                 _%winner4892%_
                 '2
                 gerbil-ascent/table/trrel-uf#uf-node::t
                 '#f))
               (_%size4896%_
                (##structure-ref
                 _%winner4892%_
                 '3
                 gerbil-ascent/table/trrel-uf#uf-node::t
                 '#f)))
          (if (##structure-ref
               _%group4885%_
               '4
               gerbil-ascent/table/trrel-uf#uf-group::t
               '#f)
              (gerbil-ascent/table/trrel-uf#retire-cycle-predecessors!
               _%winner4892%_
               _%cycle4887%_)
              '#!void)
          (for-each
           (lambda (_%n4899%_)
             (if (eq? _%n4899%_ _%winner4892%_)
                 '#!void
                 (begin
                   (set! _%merged4894%_
                         (append (##structure-ref
                                  _%n4899%_
                                  '2
                                  gerbil-ascent/table/trrel-uf#uf-node::t
                                  '#f)
                                 _%merged4894%_))
                   (set! _%size4896%_
                         (+ _%size4896%_
                            (##structure-ref
                             _%n4899%_
                             '3
                             gerbil-ascent/table/trrel-uf#uf-node::t
                             '#f)))
                   (##structure-set!
                    _%n4899%_
                    _%winner4892%_
                    '1
                    gerbil-ascent/table/trrel-uf#uf-node::t
                    '#f)
                   (##structure-set!
                    _%n4899%_
                    '()
                    '2
                    gerbil-ascent/table/trrel-uf#uf-node::t
                    '#f)
                   (##structure-set!
                    _%n4899%_
                    '0
                    '3
                    gerbil-ascent/table/trrel-uf#uf-node::t
                    '#f)
                   (##structure-set!
                    _%n4899%_
                    (let () (declare (not safe)) (make-hash-table-eq))
                    '4
                    gerbil-ascent/table/trrel-uf#uf-node::t
                    '#f)
                   (##structure-set!
                    _%n4899%_
                    '#f
                    '5
                    gerbil-ascent/table/trrel-uf#uf-node::t
                    '#f))))
           _%cycle4887%_)
          (##structure-set!
           _%winner4892%_
           _%merged4894%_
           '2
           gerbil-ascent/table/trrel-uf#uf-node::t
           '#f)
          (##structure-set!
           _%winner4892%_
           _%size4896%_
           '3
           gerbil-ascent/table/trrel-uf#uf-node::t
           '#f)
          (set! _%roots4886%_
                (filter (lambda (_%n4901%_)
                          (not (##structure-ref
                                _%n4901%_
                                '1
                                gerbil-ascent/table/trrel-uf#uf-node::t
                                '#f)))
                        _%roots4886%_))
          (##structure-set!
           _%group4885%_
           _%roots4886%_
           '2
           gerbil-ascent/table/trrel-uf#uf-group::t
           '#f)
          (for-each
           (lambda (_%n4903%_)
             (if (and (eq? _%n4903%_ _%winner4892%_)
                      (or (null? (cdr _%roots4886%_))
                          (= (let* ((_%h4908%_
                                     (##structure-ref
                                      _%n4903%_
                                      '4
                                      gerbil-ascent/table/trrel-uf#uf-node::t
                                      '#f))
                                    (_%h4912%_
                                     (let ()
                                       (declare (not safe))
                                       (cast HashTable::interface _%h4908%_)))
                                    (_%h4914%_ _%h4912%_))
                               (declare (not safe))
                               (__hash-length _%h4914%_))
                             (- (length _%cycle4887%_) '1))))
                 (##structure-set!
                  _%n4903%_
                  (let () (declare (not safe)) (make-hash-table-eq))
                  '4
                  gerbil-ascent/table/trrel-uf#uf-node::t
                  '#f)
                 (if (or (eq? _%n4903%_ _%winner4892%_)
                         (let* ((_%h4934%_
                                 (##structure-ref
                                  _%n4903%_
                                  '4
                                  gerbil-ascent/table/trrel-uf#uf-node::t
                                  '#f))
                                (_%key4937%_ _%winner4892%_)
                                (_%h4941%_
                                 (let ()
                                   (declare (not safe))
                                   (cast HashTable::interface _%h4934%_)))
                                (_%h4943%_ _%h4941%_))
                           (declare (not safe))
                           (__hash-get _%h4943%_ _%key4937%_)))
                     (for-each
                      (lambda (_%target4955%_)
                        (if (or (not (eq? _%target4955%_ _%winner4892%_))
                                (eq? _%n4903%_ _%winner4892%_))
                            (let* ((_%h4960%_
                                    (##structure-ref
                                     _%n4903%_
                                     '4
                                     gerbil-ascent/table/trrel-uf#uf-node::t
                                     '#f))
                                   (_%key4963%_ _%target4955%_)
                                   (_%h4967%_
                                    (let ()
                                      (declare (not safe))
                                      (cast HashTable::interface _%h4960%_)))
                                   (_%h4969%_ _%h4967%_))
                              (declare (not safe))
                              (__hash-remove! _%h4969%_ _%key4963%_))
                            '#!void))
                      _%cycle4887%_)
                     '#!void)))
           _%roots4886%_))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-insert!
      (lambda (_%groups4778%_ _%row4779%_ _%budget4780%_)
        (let* ((_%width4782%_ (length _%row4779%_))
               (_%_4784%_
                (if (let () (declare (not safe)) (##memq _%width4782%_ '(2 3)))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"ASCENT trrel requires two or three columns"
                             _%row4779%_))))
               (_%group-key4786%_
                (list _%width4782%_
                      (if (= _%width4782%_ '3) (car _%row4779%_) '#f)))
               (_%pair4788%_
                (if (= _%width4782%_ '3) (cdr _%row4779%_) _%row4779%_))
               (_%left4790%_ (car _%pair4788%_))
               (_%right4792%_ (cadr _%pair4788%_))
               (_%stored4821%_
                (let* ((_%h4794%_ _%groups4778%_)
                       (_%key4797%_ _%group-key4786%_)
                       (_%h4801%_
                        (let ()
                          (declare (not safe))
                          (cast HashTable::interface _%h4794%_)))
                       (_%h4803%_ _%h4801%_))
                  (declare (not safe))
                  (__hash-get _%h4803%_ _%key4797%_)))
               (_%group4826%_
                (let ((_%$e4823%_ _%stored4821%_))
                  (if _%$e4823%_
                      _%$e4823%_
                      (let ((__tmp5217
                             (let ()
                               (declare (not safe))
                               (make-hash-table__%
                                '#f
                                absent-value
                                absent-value
                                absent-value
                                absent-value
                                absent-value
                                absent-value
                                absent-value
                                absent-value))))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/table/trrel-uf#uf-group::t
                         __tmp5217
                         '()
                         '0
                         '#f)))))
               (_%nodes4828%_
                (##structure-ref
                 _%group4826%_
                 '1
                 gerbil-ascent/table/trrel-uf#uf-group::t
                 '#f))
               (_%left-node4853%_
                (let* ((_%h4830%_ _%nodes4828%_)
                       (_%key4833%_ _%left4790%_)
                       (_%h4837%_
                        (let ()
                          (declare (not safe))
                          (cast HashTable::interface _%h4830%_)))
                       (_%h4839%_ _%h4837%_))
                  (declare (not safe))
                  (__hash-get _%h4839%_ _%key4833%_)))
               (_%right-node4876%_
                (let* ((_%h4855%_ _%nodes4828%_)
                       (_%key4858%_ _%right4792%_)
                       (_%h4862%_
                        (let ()
                          (declare (not safe))
                          (cast HashTable::interface _%h4855%_)))
                       (_%h4864%_ _%h4862%_))
                  (declare (not safe))
                  (__hash-get _%h4864%_ _%key4858%_)))
               (_%a4878%_
                (if _%left-node4853%_
                    (gerbil-ascent/table/trrel-uf#root _%left-node4853%_)
                    (gerbil-ascent/table/trrel-uf#fresh
                     _%left4790%_
                     (+ '2
                        (##structure-ref
                         _%group4826%_
                         '3
                         gerbil-ascent/table/trrel-uf#uf-group::t
                         '#f))
                     (##structure-ref
                      _%group4826%_
                      '4
                      gerbil-ascent/table/trrel-uf#uf-group::t
                      '#f))))
               (_%b4880%_
                (if (equal? _%left4790%_ _%right4792%_)
                    _%a4878%_
                    (if _%right-node4876%_
                        (gerbil-ascent/table/trrel-uf#root _%right-node4876%_)
                        (gerbil-ascent/table/trrel-uf#fresh
                         _%right4792%_
                         (+ '1
                            (##structure-ref
                             _%group4826%_
                             '3
                             gerbil-ascent/table/trrel-uf#uf-group::t
                             '#f))
                         (##structure-ref
                          _%group4826%_
                          '4
                          gerbil-ascent/table/trrel-uf#uf-group::t
                          '#f)))))
               (_%admitted?4882%_
                (if _%left-node4853%_
                    (if _%right-node4876%_
                        (gerbil-ascent/table/trrel-uf#reachable?
                         _%a4878%_
                         _%b4880%_)
                        '#f)
                    '#f)))
          (if _%admitted?4882%_
              (begin
                (if (< _%budget4780%_ '0)
                    (let ()
                      (declare (not safe))
                      (error '"ASCENT trrel output fact budget exceeded"))
                    '#!void)
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__0
                   '()
                   '0
                   '0)))
              (gerbil-ascent/table/trrel-uf#insert-components!
               _%groups4778%_
               (let ()
                 (declare (not safe))
                 (##structure
                  gerbil-ascent/table/trrel-uf#uf-insertion::t
                  _%group-key4786%_
                  _%group4826%_
                  _%row4779%_
                  _%left-node4853%_
                  _%right-node4876%_
                  _%a4878%_
                  _%b4880%_))
               _%budget4780%_)))))
    (define gerbil-ascent/table/trrel-uf#insert-components!
      (lambda (_%groups4522%_ _%admission4523%_ _%budget4524%_)
        (let* ((_%$%admission45254537%_ _%admission4523%_)
               (_%$%E45274540%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%admission45254537%_
                           '((uf-insertion
                              group-key
                              group
                              row
                              left-node
                              right-node
                              a
                              b))))
                  '#!void))
               (_%$%K45284740%_
                (lambda (_%b4543%_
                         _%a4544%_
                         _%right-node4545%_
                         _%left-node4546%_
                         _%row4547%_
                         _%group4548%_
                         _%group-key4549%_)
                  (let* ((_%width4551%_ (car _%group-key4549%_))
                         (_%nodes4553%_
                          (##structure-ref
                           _%group4548%_
                           '1
                           gerbil-ascent/table/trrel-uf#uf-group::t
                           '#f))
                         (_%pair4555%_
                          (if (= _%width4551%_ '3)
                              (cdr _%row4547%_)
                              _%row4547%_))
                         (_%left4557%_ (car _%pair4555%_))
                         (_%right4559%_ (cadr _%pair4555%_))
                         (_%new4564%_
                          (let ((__tmp5219
                                 (if _%left-node4546%_ '() (list _%a4544%_)))
                                (__tmp5218
                                 (if (or _%right-node4545%_
                                         (eq? _%a4544%_ _%b4543%_))
                                     '()
                                     (list _%b4543%_))))
                            (declare (not safe))
                            (##append __tmp5219 __tmp5218)))
                         (_%roots4566%_
                          (append _%new4564%_
                                  (##structure-ref
                                   _%group4548%_
                                   '2
                                   gerbil-ascent/table/trrel-uf#uf-group::t
                                   '#f)))
                         (_%preds4570%_
                          (if (##structure-ref
                               _%group4548%_
                               '4
                               gerbil-ascent/table/trrel-uf#uf-group::t
                               '#f)
                              (gerbil-ascent/table/trrel-uf#ordered-neighbors
                               _%a4544%_
                               (##structure-ref
                                _%a4544%_
                                '5
                                gerbil-ascent/table/trrel-uf#uf-node::t
                                '#f))
                              (let ((__tmp5220
                                     (lambda (_%p4568%_)
                                       (gerbil-ascent/table/trrel-uf#reachable?
                                        _%p4568%_
                                        _%a4544%_))))
                                (declare (not safe))
                                (##filter __tmp5220 _%roots4566%_))))
                         (_%succs4574%_
                          (if (##structure-ref
                               _%group4548%_
                               '4
                               gerbil-ascent/table/trrel-uf#uf-group::t
                               '#f)
                              (gerbil-ascent/table/trrel-uf#ordered-neighbors
                               _%b4543%_
                               (##structure-ref
                                _%b4543%_
                                '4
                                gerbil-ascent/table/trrel-uf#uf-node::t
                                '#f))
                              (let ((__tmp5221
                                     (lambda (_%s4572%_)
                                       (gerbil-ascent/table/trrel-uf#reachable?
                                        _%b4543%_
                                        _%s4572%_))))
                                (declare (not safe))
                                (##filter __tmp5221 _%roots4566%_))))
                         (_%cycle4578%_
                          (if (eq? _%a4544%_ _%b4543%_)
                              '#f
                              (if (gerbil-ascent/table/trrel-uf#reachable?
                                   _%b4543%_
                                   _%a4544%_)
                                  (let ((__tmp5222
                                         (lambda (_%p4576%_)
                                           (gerbil-ascent/table/trrel-uf#reachable?
                                            _%b4543%_
                                            _%p4576%_))))
                                    (declare (not safe))
                                    (##filter __tmp5222 _%preds4570%_))
                                  '#f)))
                         (_%changes4580%_ '())
                         (_%needed4582%_
                          (let () (declare (not safe)) (##length _%new4564%_)))
                         (_%added4584%_ '()))
                    (let ((__tmp5223
                           (lambda (_%p4587%_)
                             (let ((__tmp5224
                                    (lambda (_%s4589%_)
                                      (if (gerbil-ascent/table/trrel-uf#reachable?
                                           _%p4587%_
                                           _%s4589%_)
                                          '#!void
                                          (begin
                                            (set! _%needed4582%_
                                                  (+ _%needed4582%_
                                                     (* (##structure-ref
                                                         _%p4587%_
                                                         '3
                                                         gerbil-ascent/table/trrel-uf#uf-node::t
                                                         '#f)
                                                        (##structure-ref
                                                         _%s4589%_
                                                         '3
                                                         gerbil-ascent/table/trrel-uf#uf-node::t
                                                         '#f))))
                                            (set! _%changes4580%_
                                                  (cons (cons _%p4587%_
                                                              _%s4589%_)
                                                        _%changes4580%_)))))))
                               (declare (not safe))
                               (##for-each __tmp5224 _%succs4574%_)))))
                      (declare (not safe))
                      (##for-each __tmp5223 _%preds4570%_))
                    (if (> _%needed4582%_ _%budget4524%_)
                        (let ()
                          (declare (not safe))
                          (error '"ASCENT trrel output fact budget exceeded"))
                        '#!void)
                    (let ((_%prefix4591%_
                           (if (= _%width4551%_ '3)
                               (list (car _%row4547%_))
                               '())))
                      (let ((__tmp5225
                             (lambda (_%n4593%_)
                               (let ((_%members4595%_
                                      (##structure-ref
                                       _%n4593%_
                                       '2
                                       gerbil-ascent/table/trrel-uf#uf-node::t
                                       '#f)))
                                 (set! _%added4584%_
                                       (cons (let ()
                                               (declare (not safe))
                                               (##structure
                                                gerbil-ascent/core/relation-view#rectangle::t
                                                _%prefix4591%_
                                                _%members4595%_
                                                _%members4595%_))
                                             _%added4584%_))))))
                        (declare (not safe))
                        (##for-each __tmp5225 _%new4564%_))
                      (let ((__tmp5226
                             (lambda (_%change4597%_)
                               (set! _%added4584%_
                                     (cons (let ((__tmp5228
                                                  (##structure-ref
                                                   (car _%change4597%_)
                                                   '2
                                                   gerbil-ascent/table/trrel-uf#uf-node::t
                                                   '#f))
                                                 (__tmp5227
                                                  (##structure-ref
                                                   (cdr _%change4597%_)
                                                   '2
                                                   gerbil-ascent/table/trrel-uf#uf-node::t
                                                   '#f)))
                                             (declare (not safe))
                                             (##structure
                                              gerbil-ascent/core/relation-view#rectangle::t
                                              _%prefix4591%_
                                              __tmp5228
                                              __tmp5227))
                                           _%added4584%_)))))
                        (declare (not safe))
                        (##for-each __tmp5226 _%changes4580%_)))
                    (if (null? _%new4564%_)
                        '#!void
                        (begin
                          (let* ((_%h4599%_ _%groups4522%_)
                                 (_%key4602%_ _%group-key4549%_)
                                 (_%value4605%_ _%group4548%_)
                                 (_%h4609%_
                                  (let ()
                                    (declare (not safe))
                                    (cast HashTable::interface _%h4599%_)))
                                 (_%h4611%_ _%h4609%_))
                            (declare (not safe))
                            (__hash-put! _%h4611%_ _%key4602%_ _%value4605%_))
                          (if _%left-node4546%_
                              '#!void
                              (let* ((_%h4641%_ _%nodes4553%_)
                                     (_%key4644%_ _%left4557%_)
                                     (_%value4647%_ _%a4544%_)
                                     (_%h4651%_
                                      (let ()
                                        (declare (not safe))
                                        (cast HashTable::interface _%h4641%_)))
                                     (_%h4653%_ _%h4651%_))
                                (declare (not safe))
                                (__hash-put!
                                 _%h4653%_
                                 _%key4644%_
                                 _%value4647%_)))
                          (if _%right-node4545%_
                              '#!void
                              (let* ((_%h4665%_ _%nodes4553%_)
                                     (_%key4668%_ _%right4559%_)
                                     (_%value4671%_ _%b4543%_)
                                     (_%h4675%_
                                      (let ()
                                        (declare (not safe))
                                        (cast HashTable::interface _%h4665%_)))
                                     (_%h4677%_ _%h4675%_))
                                (declare (not safe))
                                (__hash-put!
                                 _%h4677%_
                                 _%key4668%_
                                 _%value4671%_)))
                          (##structure-set!
                           _%group4548%_
                           _%roots4566%_
                           '2
                           gerbil-ascent/table/trrel-uf#uf-group::t
                           '#f)
                          (##structure-set!
                           _%group4548%_
                           (+ '2
                              (##structure-ref
                               _%group4548%_
                               '3
                               gerbil-ascent/table/trrel-uf#uf-group::t
                               '#f))
                           '3
                           gerbil-ascent/table/trrel-uf#uf-group::t
                           '#f)))
                    (if (##structure-ref
                         _%group4548%_
                         '4
                         gerbil-ascent/table/trrel-uf#uf-group::t
                         '#f)
                        '#!void
                        (if (> (let ()
                                 (declare (not safe))
                                 (##length _%roots4566%_))
                               '64)
                            (begin
                              (##structure-set!
                               _%group4548%_
                               '#t
                               '4
                               gerbil-ascent/table/trrel-uf#uf-group::t
                               '#f)
                              (gerbil-ascent/table/trrel-uf#rebuild-predecessors!
                               _%roots4566%_))
                            '#!void))
                    (if (and _%cycle4578%_
                             (= (let ()
                                  (declare (not safe))
                                  (##length _%cycle4578%_))
                                (let ()
                                  (declare (not safe))
                                  (##length _%roots4566%_))))
                        '#!void
                        (let ((__tmp5229
                               (lambda (_%change4689%_)
                                 (let* ((_%h4691%_
                                         (##structure-ref
                                          (car _%change4689%_)
                                          '4
                                          gerbil-ascent/table/trrel-uf#uf-node::t
                                          '#f))
                                        (_%key4694%_ (cdr _%change4689%_))
                                        (_%value4697%_ '#t)
                                        (_%h4701%_
                                         (let ()
                                           (declare (not safe))
                                           (cast HashTable::interface
                                                 _%h4691%_)))
                                        (_%h4703%_ _%h4701%_))
                                   (declare (not safe))
                                   (__hash-put!
                                    _%h4703%_
                                    _%key4694%_
                                    _%value4697%_))
                                 (if (##structure-ref
                                      _%group4548%_
                                      '4
                                      gerbil-ascent/table/trrel-uf#uf-group::t
                                      '#f)
                                     (let* ((_%h4716%_
                                             (##structure-ref
                                              (cdr _%change4689%_)
                                              '5
                                              gerbil-ascent/table/trrel-uf#uf-node::t
                                              '#f))
                                            (_%key4719%_ (car _%change4689%_))
                                            (_%value4722%_ '#t)
                                            (_%h4726%_
                                             (let ()
                                               (declare (not safe))
                                               (cast HashTable::interface
                                                     _%h4716%_)))
                                            (_%h4728%_ _%h4726%_))
                                       (declare (not safe))
                                       (__hash-put!
                                        _%h4728%_
                                        _%key4719%_
                                        _%value4722%_))
                                     '#!void))))
                          (declare (not safe))
                          (##for-each __tmp5229 _%changes4580%_)))
                    (if _%cycle4578%_
                        (gerbil-ascent/table/trrel-uf#merge-cycle!
                         _%group4548%_
                         _%roots4566%_
                         _%cycle4578%_)
                        '#!void)
                    (let ((__tmp5231
                           (let ()
                             (declare (not safe))
                             (##reverse _%added4584%_)))
                          (__tmp5230
                           (let ()
                             (declare (not safe))
                             (##length _%added4584%_))))
                      (declare (not safe))
                      (gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__0
                       __tmp5231
                       _%needed4582%_
                       __tmp5230))))))
          (if (let ()
                (declare (not safe))
                (##structure-direct-instance-of?
                 _%$%admission45254537%_
                 'gerbil-ascent/table/trrel-uf#uf-insertion::t))
              (let* ((_%$%e45294743%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission45254537%_
                         '1
                         '#f
                         '#f)))
                     (_%group-key4746%_ _%$%e45294743%_)
                     (_%$%e45304748%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission45254537%_
                         '2
                         '#f
                         '#f)))
                     (_%group4751%_ _%$%e45304748%_)
                     (_%$%e45314753%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission45254537%_
                         '3
                         '#f
                         '#f)))
                     (_%row4756%_ _%$%e45314753%_)
                     (_%$%e45324758%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission45254537%_
                         '4
                         '#f
                         '#f)))
                     (_%left-node4761%_ _%$%e45324758%_)
                     (_%$%e45334763%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission45254537%_
                         '5
                         '#f
                         '#f)))
                     (_%right-node4766%_ _%$%e45334763%_)
                     (_%$%e45344768%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission45254537%_
                         '6
                         '#f
                         '#f)))
                     (_%a4771%_ _%$%e45344768%_)
                     (_%$%e45354773%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission45254537%_
                         '7
                         '#f
                         '#f)))
                     (_%b4776%_ _%$%e45354773%_))
                (_%$%K45284740%_
                 _%b4776%_
                 _%a4771%_
                 _%right-node4766%_
                 _%left-node4761%_
                 _%row4756%_
                 _%group4751%_
                 _%group-key4746%_))
              (_%$%E45274540%_)))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-observation
      (lambda (_%groups4445%_)
        (let ((_%nodes4447%_ '0) (_%components4448%_ '0) (_%arcs4449%_ '0))
          (let* ((_%proc4492%_
                  (lambda (_%_4451%_ _%g4452%_)
                    (set! _%nodes4447%_
                          (+ _%nodes4447%_
                             (let* ((_%h4454%_
                                     (##structure-ref
                                      _%g4452%_
                                      '1
                                      gerbil-ascent/table/trrel-uf#uf-group::t
                                      '#f))
                                    (_%h4458%_
                                     (let ()
                                       (declare (not safe))
                                       (cast HashTable::interface _%h4454%_)))
                                    (_%h4460%_ _%h4458%_))
                               (declare (not safe))
                               (__hash-length _%h4460%_))))
                    (set! _%components4448%_
                          (+ _%components4448%_
                             (length (##structure-ref
                                      _%g4452%_
                                      '2
                                      gerbil-ascent/table/trrel-uf#uf-group::t
                                      '#f))))
                    (for-each
                     (lambda (_%n4473%_)
                       (set! _%arcs4449%_
                             (+ _%arcs4449%_
                                (let* ((_%h4475%_
                                        (##structure-ref
                                         _%n4473%_
                                         '4
                                         gerbil-ascent/table/trrel-uf#uf-node::t
                                         '#f))
                                       (_%h4479%_
                                        (let ()
                                          (declare (not safe))
                                          (cast HashTable::interface
                                                _%h4475%_)))
                                       (_%h4481%_ _%h4479%_))
                                  (declare (not safe))
                                  (__hash-length _%h4481%_)))))
                     (##structure-ref
                      _%g4452%_
                      '2
                      gerbil-ascent/table/trrel-uf#uf-group::t
                      '#f))))
                 (_%h4495%_ _%groups4445%_)
                 (_%proc4500%_ _%proc4492%_)
                 (_%h4510%_
                  (let ()
                    (declare (not safe))
                    (cast HashTable::interface _%h4495%_)))
                 (_%h4512%_ _%h4510%_))
            (declare (not safe))
            (__hash-for-each _%proc4500%_ _%h4512%_))
          (vector _%nodes4447%_ _%components4448%_ _%arcs4449%_))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-validate
      (lambda (_%groups4145%_)
        (letrec ((_%require!4147%_
                  (lambda (_%ok4442%_ _%message4443%_)
                    (if _%ok4442%_
                        '#!void
                        (let ()
                          (declare (not safe))
                          (error _%message4443%_)))))
                 (_%unique?4148%_
                  (lambda (_%values4430%_ _%same?4431%_)
                    (let _%loop4433%_ ((_%rest4435%_ _%values4430%_))
                      (let ((_%$e4437%_ (null? _%rest4435%_)))
                        (if _%$e4437%_
                            _%$e4437%_
                            (if (let ((__tmp5233
                                       (lambda (_%v4440%_)
                                         (_%same?4431%_
                                          (car _%rest4435%_)
                                          _%v4440%_)))
                                      (__tmp5232 (cdr _%rest4435%_)))
                                  (declare (not safe))
                                  (ormap__0 __tmp5233 __tmp5232))
                                '#f
                                (_%loop4433%_ (cdr _%rest4435%_))))))))
                 (_%checked-root4149%_
                  (lambda (_%node4423%_)
                    (let _%loop4425%_ ((_%n4427%_ _%node4423%_)
                                       (_%seen4428%_ '()))
                      (_%require!4147%_
                       (not (memq _%n4427%_ _%seen4428%_))
                       '"ASCENT UF parent cycle")
                      (if (##structure-ref
                           _%n4427%_
                           '1
                           gerbil-ascent/table/trrel-uf#uf-node::t
                           '#f)
                          (_%loop4425%_
                           (##structure-ref
                            _%n4427%_
                            '1
                            gerbil-ascent/table/trrel-uf#uf-node::t
                            '#f)
                           (cons _%n4427%_ _%seen4428%_))
                          _%n4427%_)))))
          (let* ((_%proc4393%_
                  (lambda (_%_4151%_ _%group4152%_)
                    (let ((_%nodes4154%_
                           (##structure-ref
                            _%group4152%_
                            '1
                            gerbil-ascent/table/trrel-uf#uf-group::t
                            '#f))
                          (_%roots4155%_
                           (##structure-ref
                            _%group4152%_
                            '2
                            gerbil-ascent/table/trrel-uf#uf-group::t
                            '#f)))
                      (_%require!4147%_
                       (_%unique?4148%_ _%roots4155%_ eq?)
                       '"ASCENT UF duplicate root")
                      (let _%loop4157%_ ((_%remaining4159%_ _%roots4155%_)
                                         (_%ceiling4160%_
                                          (+ '1
                                             (##structure-ref
                                              _%group4152%_
                                              '3
                                              gerbil-ascent/table/trrel-uf#uf-group::t
                                              '#f))))
                        (if (null? _%remaining4159%_)
                            '#!void
                            (let ((_%order4162%_
                                   (##structure-ref
                                    (car _%remaining4159%_)
                                    '6
                                    gerbil-ascent/table/trrel-uf#uf-node::t
                                    '#f)))
                              (_%require!4147%_
                               (if (exact-integer? _%order4162%_)
                                   (if (> _%order4162%_ '0)
                                       (< _%order4162%_ _%ceiling4160%_)
                                       '#f)
                                   '#f)
                               '"ASCENT UF root scan order mismatch")
                              (_%loop4157%_
                               (cdr _%remaining4159%_)
                               _%order4162%_))))
                      (let* ((_%proc4191%_
                              (lambda (_%value4164%_ _%node4165%_)
                                (let ((_%owner4167%_
                                       (_%checked-root4149%_ _%node4165%_)))
                                  (_%require!4147%_
                                   (memq _%owner4167%_ _%roots4155%_)
                                   '"ASCENT UF missing root")
                                  (_%require!4147%_
                                   (member _%value4164%_
                                           (##structure-ref
                                            _%owner4167%_
                                            '2
                                            gerbil-ascent/table/trrel-uf#uf-node::t
                                            '#f))
                                   '"ASCENT UF missing member")
                                  (if (##structure-ref
                                       _%node4165%_
                                       '1
                                       gerbil-ascent/table/trrel-uf#uf-node::t
                                       '#f)
                                      (_%require!4147%_
                                       (if (null? (##structure-ref
                                                   _%node4165%_
                                                   '2
                                                   gerbil-ascent/table/trrel-uf#uf-node::t
                                                   '#f))
                                           (if (= (##structure-ref
                                                   _%node4165%_
                                                   '3
                                                   gerbil-ascent/table/trrel-uf#uf-node::t
                                                   '#f)
                                                  '0)
                                               (if (= (let* ((_%h4169%_
                                                              (##structure-ref
                                                               _%node4165%_
                                                               '4
                                                               gerbil-ascent/table/trrel-uf#uf-node::t
                                                               '#f))
                                                             (_%h4173%_
                                                              (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (cast HashTable::interface _%h4169%_)))
                     (_%h4175%_ _%h4173%_))
                (declare (not safe))
                (__hash-length _%h4175%_))
              '0)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (not (##structure-ref
                                                         _%node4165%_
                                                         '5
                                                         gerbil-ascent/table/trrel-uf#uf-node::t
                                                         '#f))
                                                   '#f)
                                               '#f)
                                           '#f)
                                       '"ASCENT UF absorbed storage retained")
                                      '#!void))))
                             (_%h4194%_ _%nodes4154%_)
                             (_%proc4199%_ _%proc4191%_)
                             (_%h4209%_
                              (let ()
                                (declare (not safe))
                                (cast HashTable::interface _%h4194%_)))
                             (_%h4211%_ _%h4209%_))
                        (declare (not safe))
                        (__hash-for-each _%proc4199%_ _%h4211%_))
                      (for-each
                       (lambda (_%n4221%_)
                         (let ((_%members4223%_
                                (##structure-ref
                                 _%n4221%_
                                 '2
                                 gerbil-ascent/table/trrel-uf#uf-node::t
                                 '#f)))
                           (_%require!4147%_
                            (not (##structure-ref
                                  _%n4221%_
                                  '1
                                  gerbil-ascent/table/trrel-uf#uf-node::t
                                  '#f))
                            '"ASCENT UF non-root owner")
                           (_%require!4147%_
                            (if (> (##structure-ref
                                    _%n4221%_
                                    '3
                                    gerbil-ascent/table/trrel-uf#uf-node::t
                                    '#f)
                                   '0)
                                (if (= (##structure-ref
                                        _%n4221%_
                                        '3
                                        gerbil-ascent/table/trrel-uf#uf-node::t
                                        '#f)
                                       (length _%members4223%_))
                                    (_%unique?4148%_ _%members4223%_ equal?)
                                    '#f)
                                '#f)
                            '"ASCENT UF member size mismatch")
                           (for-each
                            (lambda (_%value4225%_)
                              (let ((_%node4250%_
                                     (let* ((_%h4227%_ _%nodes4154%_)
                                            (_%key4230%_ _%value4225%_)
                                            (_%h4234%_
                                             (let ()
                                               (declare (not safe))
                                               (cast HashTable::interface
                                                     _%h4227%_)))
                                            (_%h4236%_ _%h4234%_))
                                       (declare (not safe))
                                       (__hash-get _%h4236%_ _%key4230%_))))
                                (_%require!4147%_
                                 (if _%node4250%_
                                     (eq? (_%checked-root4149%_ _%node4250%_)
                                          _%n4221%_)
                                     '#f)
                                 '"ASCENT UF wrong member owner")))
                            _%members4223%_))
                         (if (##structure-ref
                              _%group4152%_
                              '4
                              gerbil-ascent/table/trrel-uf#uf-group::t
                              '#f)
                             (begin
                               (_%require!4147%_
                                (let ((__tmp5234
                                       (##structure-ref
                                        _%n4221%_
                                        '5
                                        gerbil-ascent/table/trrel-uf#uf-node::t
                                        '#f)))
                                  (declare (not safe))
                                  (##structure-direct-instance-of?
                                   __tmp5234
                                   'HashTable::t))
                                '"ASCENT UF missing predecessor map")
                               (let* ((_%proc4276%_
                                       (lambda (_%predecessor4252%_ _%_4253%_)
                                         (_%require!4147%_
                                          (if (eq? _%n4221%_
                                                   _%predecessor4252%_)
                                              '#f
                                              (if (memq _%predecessor4252%_
                                                        _%roots4155%_)
                                                  (let* ((_%h4255%_
                                                          (##structure-ref
                                                           _%predecessor4252%_
                                                           '4
                                                           gerbil-ascent/table/trrel-uf#uf-node::t
                                                           '#f))
                                                         (_%key4258%_
                                                          _%n4221%_)
                                                         (_%h4262%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (cast HashTable::interface
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          _%h4255%_)))
                 (_%h4264%_ _%h4262%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (declare (not safe))
                                                    (__hash-get
                                                     _%h4264%_
                                                     _%key4258%_))
                                                  '#f))
                                          '"ASCENT UF stale predecessor key")))
                                      (_%h4279%_
                                       (##structure-ref
                                        _%n4221%_
                                        '5
                                        gerbil-ascent/table/trrel-uf#uf-node::t
                                        '#f))
                                      (_%proc4284%_ _%proc4276%_)
                                      (_%h4294%_
                                       (let ()
                                         (declare (not safe))
                                         (cast HashTable::interface
                                               _%h4279%_)))
                                      (_%h4296%_ _%h4294%_))
                                 (declare (not safe))
                                 (__hash-for-each _%proc4284%_ _%h4296%_)))
                             (_%require!4147%_
                              (not (##structure-ref
                                    _%n4221%_
                                    '5
                                    gerbil-ascent/table/trrel-uf#uf-node::t
                                    '#f))
                              '"ASCENT UF premature predecessor map"))
                         (let* ((_%proc4363%_
                                 (lambda (_%target4306%_ _%_4307%_)
                                   (if (##structure-ref
                                        _%group4152%_
                                        '4
                                        gerbil-ascent/table/trrel-uf#uf-group::t
                                        '#f)
                                       (_%require!4147%_
                                        (let* ((_%h4309%_
                                                (##structure-ref
                                                 _%target4306%_
                                                 '5
                                                 gerbil-ascent/table/trrel-uf#uf-node::t
                                                 '#f))
                                               (_%key4312%_ _%n4221%_)
                                               (_%h4316%_
                                                (let ()
                                                  (declare (not safe))
                                                  (cast HashTable::interface
                                                        _%h4309%_)))
                                               (_%h4318%_ _%h4316%_))
                                          (declare (not safe))
                                          (__hash-get _%h4318%_ _%key4312%_))
                                        '"ASCENT UF missing predecessor key")
                                       '#!void)
                                   (_%require!4147%_
                                    (if (eq? _%n4221%_ _%target4306%_)
                                        '#f
                                        (memq _%target4306%_ _%roots4155%_))
                                    '"ASCENT UF stale reach key")
                                   (let* ((_%proc4333%_
                                           (lambda (_%successor4330%_
                                                    _%_4331%_)
                                             (_%require!4147%_
                                              (gerbil-ascent/table/trrel-uf#reachable?
                                               _%n4221%_
                                               _%successor4330%_)
                                              '"ASCENT UF incomplete root closure")))
                                          (_%h4336%_
                                           (##structure-ref
                                            _%target4306%_
                                            '4
                                            gerbil-ascent/table/trrel-uf#uf-node::t
                                            '#f))
                                          (_%proc4341%_ _%proc4333%_)
                                          (_%h4351%_
                                           (let ()
                                             (declare (not safe))
                                             (cast HashTable::interface
                                                   _%h4336%_)))
                                          (_%h4353%_ _%h4351%_))
                                     (declare (not safe))
                                     (__hash-for-each
                                      _%proc4341%_
                                      _%h4353%_))))
                                (_%h4366%_
                                 (##structure-ref
                                  _%n4221%_
                                  '4
                                  gerbil-ascent/table/trrel-uf#uf-node::t
                                  '#f))
                                (_%proc4371%_ _%proc4363%_)
                                (_%h4381%_
                                 (let ()
                                   (declare (not safe))
                                   (cast HashTable::interface _%h4366%_)))
                                (_%h4383%_ _%h4381%_))
                           (declare (not safe))
                           (__hash-for-each _%proc4371%_ _%h4383%_)))
                       _%roots4155%_))))
                 (_%h4396%_ _%groups4145%_)
                 (_%proc4401%_ _%proc4393%_)
                 (_%h4411%_
                  (let ()
                    (declare (not safe))
                    (cast HashTable::interface _%h4396%_)))
                 (_%h4413%_ _%h4411%_))
            (declare (not safe))
            (__hash-for-each _%proc4401%_ _%h4413%_))
          '#t)))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-extension
      (lambda (_%groups4139%_
               _%_all4140%_
               _%_pending4141%_
               _%row4142%_
               _%budget4143%_)
        (let ((__tmp5235
               (gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-insert!
                _%groups4139%_
                _%row4142%_
                _%budget4143%_)))
          (declare (not safe))
          (gerbil-ascent/core/relation-view#gerbil-ascent-view-rows
           __tmp5235))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__%
      (lambda (_%groups3950%_ _%indexed?3951%_)
        (let ((_%blocks3953%_ '()) (_%count3954%_ '0) (_%units3955%_ '0))
          (let* ((_%proc4099%_
                  (lambda (_%key3957%_ _%group3958%_)
                    (let ((_%members3960%_
                           (let () (declare (not safe)) (make-hash-table-eq)))
                          (_%prefix3961%_
                           (if (= (car _%key3957%_) '3)
                               (list (cadr _%key3957%_))
                               '())))
                      (for-each
                       (lambda (_%node3963%_)
                         (let ((_%owned3965%_
                                (map values
                                     (##structure-ref
                                      _%node3963%_
                                      '2
                                      gerbil-ascent/table/trrel-uf#uf-node::t
                                      '#f))))
                           (set! _%units3955%_
                                 (+ _%units3955%_
                                    (##structure-ref
                                     _%node3963%_
                                     '3
                                     gerbil-ascent/table/trrel-uf#uf-node::t
                                     '#f)))
                           (let* ((_%h3967%_ _%members3960%_)
                                  (_%key3970%_ _%node3963%_)
                                  (_%value3973%_
                                   (let ((__tmp5236
                                          (##structure-ref
                                           _%node3963%_
                                           '3
                                           gerbil-ascent/table/trrel-uf#uf-node::t
                                           '#f)))
                                     (declare (not safe))
                                     (##structure
                                      gerbil-ascent/table/trrel-uf#frozen-members::t
                                      _%owned3965%_
                                      __tmp5236)))
                                  (_%h3977%_ _%h3967%_)
                                  (_%h3979%_ _%h3977%_))
                             (declare (not safe))
                             (__hash-put!
                              _%h3979%_
                              _%key3970%_
                              _%value3973%_))))
                       (##structure-ref
                        _%group3958%_
                        '2
                        gerbil-ascent/table/trrel-uf#uf-group::t
                        '#f))
                      (for-each
                       (lambda (_%node3997%_)
                         (let* ((_%left4020%_
                                 (let* ((_%h3999%_ _%members3960%_)
                                        (_%key4002%_ _%node3997%_)
                                        (_%h4006%_ _%h3999%_)
                                        (_%h4008%_ _%h4006%_))
                                   (declare (not safe))
                                   (__hash-get _%h4008%_ _%key4002%_)))
                                (_%left4022%_ _%left4020%_))
                           (letrec ((_%capture4029%_
                                     (lambda (_%target4067%_)
                                       (let* ((_%right4090%_
                                               (let* ((_%h4069%_
                                                       _%members3960%_)
                                                      (_%key4072%_
                                                       _%target4067%_)
                                                      (_%h4076%_ _%h4069%_)
                                                      (_%h4078%_ _%h4076%_))
                                                 (declare (not safe))
                                                 (__hash-get
                                                  _%h4078%_
                                                  _%key4072%_)))
                                              (_%right4092%_ _%right4090%_))
                                         (set! _%count3954%_
                                               (+ _%count3954%_
                                                  (* (let ()
                                                       (declare (not safe))
                                                       (##unchecked-structure-ref
                                                        _%left4022%_
                                                        '2
                                                        '#f
                                                        '#f))
                                                     (let ()
                                                       (declare (not safe))
                                                       (##unchecked-structure-ref
                                                        _%right4092%_
                                                        '2
                                                        '#f
                                                        '#f)))))
                                         (set! _%units3955%_
                                               (+ _%units3955%_ '1))
                                         (set! _%blocks3953%_
                                               (cons (let ((__tmp5238
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (##unchecked-structure-ref
                                                               _%left4022%_
                                                               '1
                                                               '#f
                                                               '#f)))
                                                           (__tmp5237
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (##unchecked-structure-ref
                                                               _%right4092%_
                                                               '1
                                                               '#f
                                                               '#f))))
                                                       (declare (not safe))
                                                       (##structure
                                                        gerbil-ascent/core/relation-view#rectangle::t
                                                        _%prefix3961%_
                                                        __tmp5238
                                                        __tmp5237))
                                                     _%blocks3953%_))))))
                             (_%capture4029%_ _%node3997%_)
                             (let* ((_%proc4034%_
                                     (lambda (_%target4031%_ _%_4032%_)
                                       (_%capture4029%_ _%target4031%_)))
                                    (_%h4037%_
                                     (##structure-ref
                                      _%node3997%_
                                      '4
                                      gerbil-ascent/table/trrel-uf#uf-node::t
                                      '#f))
                                    (_%proc4042%_ _%proc4034%_)
                                    (_%h4055%_
                                     (let ()
                                       (declare (not safe))
                                       (cast HashTable::interface _%h4037%_)))
                                    (_%h4057%_ _%h4055%_))
                               (declare (not safe))
                               (__hash-for-each _%proc4042%_ _%h4057%_)))))
                       (##structure-ref
                        _%group3958%_
                        '2
                        gerbil-ascent/table/trrel-uf#uf-group::t
                        '#f)))))
                 (_%h4102%_ _%groups3950%_)
                 (_%proc4107%_ _%proc4099%_)
                 (_%h4117%_
                  (let ()
                    (declare (not safe))
                    (cast HashTable::interface _%h4102%_)))
                 (_%h4119%_ _%h4117%_))
            (declare (not safe))
            (__hash-for-each _%proc4107%_ _%h4119%_))
          (let ((__tmp5239
                 (let () (declare (not safe)) (##reverse _%blocks3953%_))))
            (declare (not safe))
            (gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__%
             __tmp5239
             _%count3954%_
             _%units3955%_
             _%indexed?3951%_)))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__0
      (lambda (_%groups4132%_)
        (let ((_%indexed?4134%_ '#t))
          (gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__%
           _%groups4132%_
           _%indexed?4134%_))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze
      (lambda _g5240_
        (let ((_g5241_ (let () (declare (not safe)) (##length _g5240_))))
          (cond ((let () (declare (not safe)) (##fx= _g5241_ 1))
                 (apply gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__0
                        _g5240_))
                ((let () (declare (not safe)) (##fx= _g5241_ 2))
                 (apply gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__%
                        _g5240_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze
                  _g5240_))))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-frontier-extension
      gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-insert!)
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-snapshot
      gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze)
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-view-count
      gerbil-ascent/core/relation-view#relation-view-count)
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-view-for-each
      (lambda (_%view3946%_ _%consume3947%_)
        (let ()
          (declare (not safe))
          (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
           _%consume3947%_
           _%view3946%_))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-view-lookup
      (lambda (_%view3936%_ _%columns3937%_ _%key3938%_)
        (if (and (list? _%columns3937%_)
                 (list? _%key3938%_)
                 (= (let () (declare (not safe)) (##length _%columns3937%_))
                    (let () (declare (not safe)) (##length _%key3938%_)))
                 (let ((__tmp5242
                        (lambda (_%column3940%_)
                          (and (exact-integer? _%column3940%_)
                               (>= _%column3940%_ '0)))))
                   (declare (not safe))
                   (andmap__0 __tmp5242 _%columns3937%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT UF view key")))
        (let ((_%rows3942%_ '()))
          (let ((__tmp5244
                 (lambda (_%row3944%_)
                   (set! _%rows3942%_ (cons _%row3944%_ _%rows3942%_))))
                (__tmp5243
                 (let ()
                   (declare (not safe))
                   (gerbil-ascent/core/relation-view#gerbil-ascent-view-select
                    _%view3936%_
                    _%columns3937%_
                    _%key3938%_))))
            (declare (not safe))
            (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
             __tmp5244
             __tmp5243))
          (let () (declare (not safe)) (##reverse _%rows3942%_)))))))
