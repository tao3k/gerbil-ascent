(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/core/ordered-call")
    (load-module "gerbil-ascent/core/relation-view")
    (load-module "gerbil-ascent/core/expression-plan")
    (load-module "gerbil-ascent/core/rule-bindings"))
  (load-module "gerbil-ascent/core/positive-plan~0"))
