(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/core/relation-view[1]#_g3777_|
    (##structure
     gx#syntax-quote::t
     'relation-view::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3779_|
    (##structure
     gx#syntax-quote::t
     'make-relation-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3781_|
    (##structure
     gx#syntax-quote::t
     'relation-view?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3783_|
    (##structure
     gx#syntax-quote::t
     'relation-view-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3784_|
    (##structure
     gx#syntax-quote::t
     'relation-view-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3785_|
    (##structure
     gx#syntax-quote::t
     'relation-view-revision
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3786_|
    (##structure
     gx#syntax-quote::t
     'relation-view-lane
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3787_|
    (##structure
     gx#syntax-quote::t
     'relation-view-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3788_|
    (##structure
     gx#syntax-quote::t
     'relation-view-units
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3789_|
    (##structure
     gx#syntax-quote::t
     'relation-view-visit
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3790_|
    (##structure
     gx#syntax-quote::t
     'relation-view-contains
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3791_|
    (##structure
     gx#syntax-quote::t
     'relation-view-export
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3792_|
    (##structure
     gx#syntax-quote::t
     'relation-view-parts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3794_|
    (##structure
     gx#syntax-quote::t
     'relation-view-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3795_|
    (##structure
     gx#syntax-quote::t
     'relation-view-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3796_|
    (##structure
     gx#syntax-quote::t
     'relation-view-revision-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3797_|
    (##structure
     gx#syntax-quote::t
     'relation-view-lane-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3798_|
    (##structure
     gx#syntax-quote::t
     'relation-view-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3799_|
    (##structure
     gx#syntax-quote::t
     'relation-view-units-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3800_|
    (##structure
     gx#syntax-quote::t
     'relation-view-visit-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3801_|
    (##structure
     gx#syntax-quote::t
     'relation-view-contains-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3802_|
    (##structure
     gx#syntax-quote::t
     'relation-view-export-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3803_|
    (##structure
     gx#syntax-quote::t
     'relation-view-parts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3805_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3806_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3807_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-revision
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3808_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-lane
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3809_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3810_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-units
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3811_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-visit
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3812_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-contains
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3813_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-export
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3814_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-parts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3816_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3817_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3818_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-revision-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3819_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-lane-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3820_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3821_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-units-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3822_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-visit-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3823_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-contains-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3824_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-export-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3825_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-parts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3827_|
    (##structure
     gx#syntax-quote::t
     'part-visitors::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3829_|
    (##structure
     gx#syntax-quote::t
     'make-part-visitors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3831_|
    (##structure
     gx#syntax-quote::t
     'part-visitors?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3833_|
    (##structure
     gx#syntax-quote::t
     'part-visitors-checked
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3834_|
    (##structure
     gx#syntax-quote::t
     'part-visitors-admitted
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3836_|
    (##structure
     gx#syntax-quote::t
     'part-visitors-checked-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3837_|
    (##structure
     gx#syntax-quote::t
     'part-visitors-admitted-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3839_|
    (##structure
     gx#syntax-quote::t
     '&part-visitors-checked
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3840_|
    (##structure
     gx#syntax-quote::t
     '&part-visitors-admitted
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3842_|
    (##structure
     gx#syntax-quote::t
     '&part-visitors-checked-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3843_|
    (##structure
     gx#syntax-quote::t
     '&part-visitors-admitted-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3845_|
    (##structure
     gx#syntax-quote::t
     'row-stream::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3847_|
    (##structure
     gx#syntax-quote::t
     'make-row-stream
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3849_|
    (##structure
     gx#syntax-quote::t
     'row-stream?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3851_|
    (##structure
     gx#syntax-quote::t
     'row-stream-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3852_|
    (##structure
     gx#syntax-quote::t
     'row-stream-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3853_|
    (##structure
     gx#syntax-quote::t
     'row-stream-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3855_|
    (##structure
     gx#syntax-quote::t
     'row-stream-view-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3856_|
    (##structure
     gx#syntax-quote::t
     'row-stream-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3857_|
    (##structure
     gx#syntax-quote::t
     'row-stream-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3859_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3860_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3861_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3863_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-view-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3864_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3865_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3867_|
    (##structure
     gx#syntax-quote::t
     'rectangle::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3869_|
    (##structure
     gx#syntax-quote::t
     'make-rectangle
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3871_|
    (##structure
     gx#syntax-quote::t
     'rectangle?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3873_|
    (##structure
     gx#syntax-quote::t
     'rectangle-prefix
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3874_|
    (##structure
     gx#syntax-quote::t
     'rectangle-left
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3875_|
    (##structure
     gx#syntax-quote::t
     'rectangle-right
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3877_|
    (##structure
     gx#syntax-quote::t
     'rectangle-prefix-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3878_|
    (##structure
     gx#syntax-quote::t
     'rectangle-left-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3879_|
    (##structure
     gx#syntax-quote::t
     'rectangle-right-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3881_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-prefix
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3882_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-left
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3883_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-right
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3885_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-prefix-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3886_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-left-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3887_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-right-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3889_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3891_|
    (##structure
     gx#syntax-quote::t
     'make-rectangle-bucket
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3893_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3895_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3896_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-blocks
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3897_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3898_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-plain
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3900_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3901_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-blocks-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3902_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3903_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-plain-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3905_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3906_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-blocks
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3907_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3908_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-plain
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3910_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3911_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-blocks-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3912_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g3913_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-plain-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/core/relation-view[:0:]#relation-view|
      (let ((__obj3691
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj3691
           'gerbil-ascent/core/relation-view#relation-view::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3691 'relation-view '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj3691
           '(identity
             generation
             revision
             lane
             count
             units
             visit
             contains
             export
             parts)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj3691
           '(identity
             generation
             revision
             lane
             count
             units
             visit
             contains
             export
             parts)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3691 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3691 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3691 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3691 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3691 '#f '13 '#f '#f))
        (let ((__tmp3776 |gerbil-ascent/core/relation-view[1]#_g3777_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj3691 __tmp3776 '4 '#f '#f))
        (let ((__tmp3778 |gerbil-ascent/core/relation-view[1]#_g3779_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj3691 __tmp3778 '14 '#f '#f))
        (let ((__tmp3780 |gerbil-ascent/core/relation-view[1]#_g3781_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj3691 __tmp3780 '15 '#f '#f))
        (let ((__tmp3782
               (cons (cons 'identity
                           |gerbil-ascent/core/relation-view[1]#_g3783_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/core/relation-view[1]#_g3784_|)
                           (cons (cons 'revision
                                       |gerbil-ascent/core/relation-view[1]#_g3785_|)
                                 (cons (cons 'lane
                                             |gerbil-ascent/core/relation-view[1]#_g3786_|)
                                       (cons (cons 'count
                                                   |gerbil-ascent/core/relation-view[1]#_g3787_|)
                                             (cons (cons 'units
                                                         |gerbil-ascent/core/relation-view[1]#_g3788_|)
                                                   (cons (cons 'visit
                                                               |gerbil-ascent/core/relation-view[1]#_g3789_|)
                                                         (cons (cons 'contains
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/core/relation-view[1]#_g3790_|)
                       (cons (cons 'export
                                   |gerbil-ascent/core/relation-view[1]#_g3791_|)
                             (cons (cons 'parts
                                         |gerbil-ascent/core/relation-view[1]#_g3792_|)
                                   '()))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj3691 __tmp3782 '16 '#f '#f))
        (let ((__tmp3793
               (cons (cons 'identity
                           |gerbil-ascent/core/relation-view[1]#_g3794_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/core/relation-view[1]#_g3795_|)
                           (cons (cons 'revision
                                       |gerbil-ascent/core/relation-view[1]#_g3796_|)
                                 (cons (cons 'lane
                                             |gerbil-ascent/core/relation-view[1]#_g3797_|)
                                       (cons (cons 'count
                                                   |gerbil-ascent/core/relation-view[1]#_g3798_|)
                                             (cons (cons 'units
                                                         |gerbil-ascent/core/relation-view[1]#_g3799_|)
                                                   (cons (cons 'visit
                                                               |gerbil-ascent/core/relation-view[1]#_g3800_|)
                                                         (cons (cons 'contains
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/core/relation-view[1]#_g3801_|)
                       (cons (cons 'export
                                   |gerbil-ascent/core/relation-view[1]#_g3802_|)
                             (cons (cons 'parts
                                         |gerbil-ascent/core/relation-view[1]#_g3803_|)
                                   '()))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj3691 __tmp3793 '17 '#f '#f))
        (let ((__tmp3804
               (cons (cons 'identity
                           |gerbil-ascent/core/relation-view[1]#_g3805_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/core/relation-view[1]#_g3806_|)
                           (cons (cons 'revision
                                       |gerbil-ascent/core/relation-view[1]#_g3807_|)
                                 (cons (cons 'lane
                                             |gerbil-ascent/core/relation-view[1]#_g3808_|)
                                       (cons (cons 'count
                                                   |gerbil-ascent/core/relation-view[1]#_g3809_|)
                                             (cons (cons 'units
                                                         |gerbil-ascent/core/relation-view[1]#_g3810_|)
                                                   (cons (cons 'visit
                                                               |gerbil-ascent/core/relation-view[1]#_g3811_|)
                                                         (cons (cons 'contains
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/core/relation-view[1]#_g3812_|)
                       (cons (cons 'export
                                   |gerbil-ascent/core/relation-view[1]#_g3813_|)
                             (cons (cons 'parts
                                         |gerbil-ascent/core/relation-view[1]#_g3814_|)
                                   '()))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj3691 __tmp3804 '18 '#f '#f))
        (let ((__tmp3815
               (cons (cons 'identity
                           |gerbil-ascent/core/relation-view[1]#_g3816_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/core/relation-view[1]#_g3817_|)
                           (cons (cons 'revision
                                       |gerbil-ascent/core/relation-view[1]#_g3818_|)
                                 (cons (cons 'lane
                                             |gerbil-ascent/core/relation-view[1]#_g3819_|)
                                       (cons (cons 'count
                                                   |gerbil-ascent/core/relation-view[1]#_g3820_|)
                                             (cons (cons 'units
                                                         |gerbil-ascent/core/relation-view[1]#_g3821_|)
                                                   (cons (cons 'visit
                                                               |gerbil-ascent/core/relation-view[1]#_g3822_|)
                                                         (cons (cons 'contains
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/core/relation-view[1]#_g3823_|)
                       (cons (cons 'export
                                   |gerbil-ascent/core/relation-view[1]#_g3824_|)
                             (cons (cons 'parts
                                         |gerbil-ascent/core/relation-view[1]#_g3825_|)
                                   '()))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj3691 __tmp3815 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3691 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3691 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3691 '() '21 '#f '#f))
        __obj3691))
    (define |gerbil-ascent/core/relation-view[:0:]#part-visitors|
      (let ((__obj3692
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj3692
           'gerbil-ascent/core/relation-view#part-visitors::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3692 'part-visitors '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj3692
           '(checked admitted)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj3692
           '(checked admitted)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3692 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3692 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3692 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3692 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3692 '#f '13 '#f '#f))
        (let ((__tmp3826 |gerbil-ascent/core/relation-view[1]#_g3827_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj3692 __tmp3826 '4 '#f '#f))
        (let ((__tmp3828 |gerbil-ascent/core/relation-view[1]#_g3829_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj3692 __tmp3828 '14 '#f '#f))
        (let ((__tmp3830 |gerbil-ascent/core/relation-view[1]#_g3831_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj3692 __tmp3830 '15 '#f '#f))
        (let ((__tmp3832
               (cons (cons 'checked
                           |gerbil-ascent/core/relation-view[1]#_g3833_|)
                     (cons (cons 'admitted
                                 |gerbil-ascent/core/relation-view[1]#_g3834_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj3692 __tmp3832 '16 '#f '#f))
        (let ((__tmp3835
               (cons (cons 'checked
                           |gerbil-ascent/core/relation-view[1]#_g3836_|)
                     (cons (cons 'admitted
                                 |gerbil-ascent/core/relation-view[1]#_g3837_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj3692 __tmp3835 '17 '#f '#f))
        (let ((__tmp3838
               (cons (cons 'checked
                           |gerbil-ascent/core/relation-view[1]#_g3839_|)
                     (cons (cons 'admitted
                                 |gerbil-ascent/core/relation-view[1]#_g3840_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj3692 __tmp3838 '18 '#f '#f))
        (let ((__tmp3841
               (cons (cons 'checked
                           |gerbil-ascent/core/relation-view[1]#_g3842_|)
                     (cons (cons 'admitted
                                 |gerbil-ascent/core/relation-view[1]#_g3843_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj3692 __tmp3841 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3692 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3692 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3692 '() '21 '#f '#f))
        __obj3692))
    (define |gerbil-ascent/core/relation-view[:0:]#row-stream|
      (let ((__obj3693
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj3693
           'gerbil-ascent/core/relation-view#row-stream::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3693 'row-stream '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj3693
           '(view columns key)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj3693
           '(view columns key)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3693 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3693 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3693 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3693 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3693 '#f '13 '#f '#f))
        (let ((__tmp3844 |gerbil-ascent/core/relation-view[1]#_g3845_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj3693 __tmp3844 '4 '#f '#f))
        (let ((__tmp3846 |gerbil-ascent/core/relation-view[1]#_g3847_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj3693 __tmp3846 '14 '#f '#f))
        (let ((__tmp3848 |gerbil-ascent/core/relation-view[1]#_g3849_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj3693 __tmp3848 '15 '#f '#f))
        (let ((__tmp3850
               (cons (cons 'view |gerbil-ascent/core/relation-view[1]#_g3851_|)
                     (cons (cons 'columns
                                 |gerbil-ascent/core/relation-view[1]#_g3852_|)
                           (cons (cons 'key
                                       |gerbil-ascent/core/relation-view[1]#_g3853_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj3693 __tmp3850 '16 '#f '#f))
        (let ((__tmp3854
               (cons (cons 'view |gerbil-ascent/core/relation-view[1]#_g3855_|)
                     (cons (cons 'columns
                                 |gerbil-ascent/core/relation-view[1]#_g3856_|)
                           (cons (cons 'key
                                       |gerbil-ascent/core/relation-view[1]#_g3857_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj3693 __tmp3854 '17 '#f '#f))
        (let ((__tmp3858
               (cons (cons 'view |gerbil-ascent/core/relation-view[1]#_g3859_|)
                     (cons (cons 'columns
                                 |gerbil-ascent/core/relation-view[1]#_g3860_|)
                           (cons (cons 'key
                                       |gerbil-ascent/core/relation-view[1]#_g3861_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj3693 __tmp3858 '18 '#f '#f))
        (let ((__tmp3862
               (cons (cons 'view |gerbil-ascent/core/relation-view[1]#_g3863_|)
                     (cons (cons 'columns
                                 |gerbil-ascent/core/relation-view[1]#_g3864_|)
                           (cons (cons 'key
                                       |gerbil-ascent/core/relation-view[1]#_g3865_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj3693 __tmp3862 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3693 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3693 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3693 '() '21 '#f '#f))
        __obj3693))
    (define |gerbil-ascent/core/relation-view[:0:]#rectangle|
      (let ((__obj3694
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj3694
           'gerbil-ascent/core/relation-view#rectangle::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3694 'rectangle '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj3694
           '(prefix left right)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj3694
           '(prefix left right)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3694 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3694 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3694 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3694 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3694 '#f '13 '#f '#f))
        (let ((__tmp3866 |gerbil-ascent/core/relation-view[1]#_g3867_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj3694 __tmp3866 '4 '#f '#f))
        (let ((__tmp3868 |gerbil-ascent/core/relation-view[1]#_g3869_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj3694 __tmp3868 '14 '#f '#f))
        (let ((__tmp3870 |gerbil-ascent/core/relation-view[1]#_g3871_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj3694 __tmp3870 '15 '#f '#f))
        (let ((__tmp3872
               (cons (cons 'prefix
                           |gerbil-ascent/core/relation-view[1]#_g3873_|)
                     (cons (cons 'left
                                 |gerbil-ascent/core/relation-view[1]#_g3874_|)
                           (cons (cons 'right
                                       |gerbil-ascent/core/relation-view[1]#_g3875_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj3694 __tmp3872 '16 '#f '#f))
        (let ((__tmp3876
               (cons (cons 'prefix
                           |gerbil-ascent/core/relation-view[1]#_g3877_|)
                     (cons (cons 'left
                                 |gerbil-ascent/core/relation-view[1]#_g3878_|)
                           (cons (cons 'right
                                       |gerbil-ascent/core/relation-view[1]#_g3879_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj3694 __tmp3876 '17 '#f '#f))
        (let ((__tmp3880
               (cons (cons 'prefix
                           |gerbil-ascent/core/relation-view[1]#_g3881_|)
                     (cons (cons 'left
                                 |gerbil-ascent/core/relation-view[1]#_g3882_|)
                           (cons (cons 'right
                                       |gerbil-ascent/core/relation-view[1]#_g3883_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj3694 __tmp3880 '18 '#f '#f))
        (let ((__tmp3884
               (cons (cons 'prefix
                           |gerbil-ascent/core/relation-view[1]#_g3885_|)
                     (cons (cons 'left
                                 |gerbil-ascent/core/relation-view[1]#_g3886_|)
                           (cons (cons 'right
                                       |gerbil-ascent/core/relation-view[1]#_g3887_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj3694 __tmp3884 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3694 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3694 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3694 '() '21 '#f '#f))
        __obj3694))
    (define |gerbil-ascent/core/relation-view[:0:]#rectangle-bucket|
      (let ((__obj3695
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj3695
           'gerbil-ascent/core/relation-view#rectangle-bucket::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3695 'rectangle-bucket '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj3695
           '(members blocks count plain)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj3695
           '(members blocks count plain)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3695 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3695 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3695 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3695 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3695 '#f '13 '#f '#f))
        (let ((__tmp3888 |gerbil-ascent/core/relation-view[1]#_g3889_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj3695 __tmp3888 '4 '#f '#f))
        (let ((__tmp3890 |gerbil-ascent/core/relation-view[1]#_g3891_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj3695 __tmp3890 '14 '#f '#f))
        (let ((__tmp3892 |gerbil-ascent/core/relation-view[1]#_g3893_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj3695 __tmp3892 '15 '#f '#f))
        (let ((__tmp3894
               (cons (cons 'members
                           |gerbil-ascent/core/relation-view[1]#_g3895_|)
                     (cons (cons 'blocks
                                 |gerbil-ascent/core/relation-view[1]#_g3896_|)
                           (cons (cons 'count
                                       |gerbil-ascent/core/relation-view[1]#_g3897_|)
                                 (cons (cons 'plain
                                             |gerbil-ascent/core/relation-view[1]#_g3898_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj3695 __tmp3894 '16 '#f '#f))
        (let ((__tmp3899
               (cons (cons 'members
                           |gerbil-ascent/core/relation-view[1]#_g3900_|)
                     (cons (cons 'blocks
                                 |gerbil-ascent/core/relation-view[1]#_g3901_|)
                           (cons (cons 'count
                                       |gerbil-ascent/core/relation-view[1]#_g3902_|)
                                 (cons (cons 'plain
                                             |gerbil-ascent/core/relation-view[1]#_g3903_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj3695 __tmp3899 '17 '#f '#f))
        (let ((__tmp3904
               (cons (cons 'members
                           |gerbil-ascent/core/relation-view[1]#_g3905_|)
                     (cons (cons 'blocks
                                 |gerbil-ascent/core/relation-view[1]#_g3906_|)
                           (cons (cons 'count
                                       |gerbil-ascent/core/relation-view[1]#_g3907_|)
                                 (cons (cons 'plain
                                             |gerbil-ascent/core/relation-view[1]#_g3908_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj3695 __tmp3904 '18 '#f '#f))
        (let ((__tmp3909
               (cons (cons 'members
                           |gerbil-ascent/core/relation-view[1]#_g3910_|)
                     (cons (cons 'blocks
                                 |gerbil-ascent/core/relation-view[1]#_g3911_|)
                           (cons (cons 'count
                                       |gerbil-ascent/core/relation-view[1]#_g3912_|)
                                 (cons (cons 'plain
                                             |gerbil-ascent/core/relation-view[1]#_g3913_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj3695 __tmp3909 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3695 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3695 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj3695 '() '21 '#f '#f))
        __obj3695))))
