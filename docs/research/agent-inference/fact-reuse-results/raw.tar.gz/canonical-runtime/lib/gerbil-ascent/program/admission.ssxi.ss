prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/program

(begin
  (declare-type
   gerbil-ascent/program/admission#gerbil-ascent-check-replacement-rows!
   (@lambda 4
            #f
            signature:
            (return:
             void::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/admission)))
  (declare-type
   gerbil-ascent/program/admission#gerbil-ascent-initialize-source-row!
   (@lambda 8
            #f
            signature:
            (return:
             number::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/admission)))
  (declare-type
   gerbil-ascent/program/admission#gerbil-ascent-admit-source-row!
   (@lambda 6
            #f
            signature:
            (return:
             number::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/admission)))
  (declare-type
   gerbil-ascent/program/admission#gerbil-ascent-prepare-storage-batch
   (@lambda 6
            #f
            signature:
            (return:
             values::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/admission))))
