(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/trrel-uf::timestamp 1791689671)
  (begin
    (define gerbil-ascent/table/trrel-uf#uf-node::t
      (let ((__tmp34047 (list)) (__tmp34046 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/trrel-uf#uf-node::t
         'uf-node
         __tmp34047
         '(parent members size reach predecessors order)
         __tmp34046
         '#f)))
    (define gerbil-ascent/table/trrel-uf#uf-node?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/trrel-uf#uf-node::t)))
    (define gerbil-ascent/table/trrel-uf#make-uf-node
      (lambda _%$args1317%_
        (apply make-instance
               gerbil-ascent/table/trrel-uf#uf-node::t
               _%$args1317%_)))
    (define gerbil-ascent/table/trrel-uf#uf-node-parent
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'parent)))
    (define gerbil-ascent/table/trrel-uf#uf-node-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'members)))
    (define gerbil-ascent/table/trrel-uf#uf-node-size
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'size)))
    (define gerbil-ascent/table/trrel-uf#uf-node-reach
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'reach)))
    (define gerbil-ascent/table/trrel-uf#uf-node-predecessors
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'predecessors)))
    (define gerbil-ascent/table/trrel-uf#uf-node-order
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'order)))
    (define gerbil-ascent/table/trrel-uf#uf-node-parent-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'parent)))
    (define gerbil-ascent/table/trrel-uf#uf-node-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'members)))
    (define gerbil-ascent/table/trrel-uf#uf-node-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'size)))
    (define gerbil-ascent/table/trrel-uf#uf-node-reach-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'reach)))
    (define gerbil-ascent/table/trrel-uf#uf-node-predecessors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'predecessors)))
    (define gerbil-ascent/table/trrel-uf#uf-node-order-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'order)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-parent
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'parent)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'members)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-size
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'size)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-reach
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'reach)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-predecessors
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'predecessors)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-order
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'order)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-parent-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'parent)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'members)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'size)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-reach-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'reach)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-predecessors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'predecessors)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-order-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'order)))
    (define gerbil-ascent/table/trrel-uf#uf-group::t
      (let ((__tmp34049 (list)) (__tmp34048 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/trrel-uf#uf-group::t
         'uf-group
         __tmp34049
         '(nodes roots next-order indexed?)
         __tmp34048
         '#f)))
    (define gerbil-ascent/table/trrel-uf#uf-group?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/trrel-uf#uf-group::t)))
    (define gerbil-ascent/table/trrel-uf#make-uf-group
      (lambda _%$args1314%_
        (apply make-instance
               gerbil-ascent/table/trrel-uf#uf-group::t
               _%$args1314%_)))
    (define gerbil-ascent/table/trrel-uf#uf-group-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'nodes)))
    (define gerbil-ascent/table/trrel-uf#uf-group-roots
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'roots)))
    (define gerbil-ascent/table/trrel-uf#uf-group-next-order
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'next-order)))
    (define gerbil-ascent/table/trrel-uf#uf-group-indexed?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'indexed?)))
    (define gerbil-ascent/table/trrel-uf#uf-group-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'nodes)))
    (define gerbil-ascent/table/trrel-uf#uf-group-roots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'roots)))
    (define gerbil-ascent/table/trrel-uf#uf-group-next-order-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'next-order)))
    (define gerbil-ascent/table/trrel-uf#uf-group-indexed?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'indexed?)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'nodes)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-roots
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'roots)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-next-order
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'next-order)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-indexed?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'indexed?)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'nodes)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-roots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'roots)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-next-order-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'next-order)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-indexed?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'indexed?)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion::t
      (let ((__tmp34051 (list))
            (__tmp34050
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/trrel-uf#uf-insertion::t
         'uf-insertion
         __tmp34051
         '(group-key group row left-node right-node a b)
         __tmp34050
         '#f)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/trrel-uf#uf-insertion::t)))
    (define gerbil-ascent/table/trrel-uf#make-uf-insertion
      (lambda _%$args1311%_
        (apply make-instance
               gerbil-ascent/table/trrel-uf#uf-insertion::t
               _%$args1311%_)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-group-key
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group-key)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-group
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-row
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'row)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-left-node
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'left-node)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-right-node
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'right-node)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-a
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'a)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-b
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'b)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-group-key-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group-key)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-group-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-row-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'row)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-left-node-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'left-node)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-right-node-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'right-node)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-a-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'a)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-b-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'b)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-group-key
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group-key)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-group
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-row
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'row)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-left-node
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'left-node)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-right-node
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'right-node)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-a
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'a)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-b
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'b)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-group-key-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group-key)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-group-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-row-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'row)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-left-node-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'left-node)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-right-node-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'right-node)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-a-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'a)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-b-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'b)))
    (define gerbil-ascent/table/trrel-uf#frozen-members::t
      (let ((__tmp34053 (list))
            (__tmp34052
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/trrel-uf#frozen-members::t
         'frozen-members
         __tmp34053
         '(rows count)
         __tmp34052
         '#f)))
    (define gerbil-ascent/table/trrel-uf#frozen-members?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/table/trrel-uf#frozen-members::t)))
    (define gerbil-ascent/table/trrel-uf#make-frozen-members
      (lambda _%$args1308%_
        (apply make-instance
               gerbil-ascent/table/trrel-uf#frozen-members::t
               _%$args1308%_)))
    (define gerbil-ascent/table/trrel-uf#frozen-members-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'rows)))
    (define gerbil-ascent/table/trrel-uf#frozen-members-count
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'count)))
    (define gerbil-ascent/table/trrel-uf#frozen-members-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'rows)))
    (define gerbil-ascent/table/trrel-uf#frozen-members-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'count)))
    (define gerbil-ascent/table/trrel-uf#&frozen-members-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'rows)))
    (define gerbil-ascent/table/trrel-uf#&frozen-members-count
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'count)))
    (define gerbil-ascent/table/trrel-uf#&frozen-members-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'rows)))
    (define gerbil-ascent/table/trrel-uf#&frozen-members-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'count)))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-state
      (lambda ()
        (let ()
          (declare (not safe))
          (make-hash-table__%
           '#f
           absent-value
           absent-value
           absent-value
           absent-value
           absent-value
           absent-value
           absent-value
           absent-value))))
    (define gerbil-ascent/table/trrel-uf#root
      (lambda (_%node1305%_)
        (if (##structure-ref
             _%node1305%_
             '1
             gerbil-ascent/table/trrel-uf#uf-node::t
             '#f)
            (gerbil-ascent/table/trrel-uf#root
             (##structure-ref
              _%node1305%_
              '1
              gerbil-ascent/table/trrel-uf#uf-node::t
              '#f))
            _%node1305%_)))
    (define gerbil-ascent/table/trrel-uf#reachable?
      (lambda (_%from1299%_ _%to1300%_)
        (let ((_%$e1302%_ (eq? _%from1299%_ _%to1300%_)))
          (if _%$e1302%_
              _%$e1302%_
              (let ((__tmp34054
                     (##structure-ref
                      _%from1299%_
                      '4
                      gerbil-ascent/table/trrel-uf#uf-node::t
                      '#f)))
                (declare (not safe))
                (hash-get __tmp34054 _%to1300%_))))))
    (define gerbil-ascent/table/trrel-uf#fresh
      (lambda (_%node1295%_ _%order1296%_ _%indexed?1297%_)
        (let ((__tmp34057 (list _%node1295%_))
              (__tmp34056 (let () (declare (not safe)) (make-hash-table-eq)))
              (__tmp34055
               (if _%indexed?1297%_
                   (let () (declare (not safe)) (make-hash-table-eq))
                   '#f)))
          (declare (not safe))
          (##structure
           gerbil-ascent/table/trrel-uf#uf-node::t
           '#f
           __tmp34057
           '1
           __tmp34056
           __tmp34055
           _%order1296%_))))
    (define gerbil-ascent/table/trrel-uf#ordered-neighbors
      (lambda (_%node1289%_ _%table1290%_)
        (let ((__tmp34059
               (lambda (_%a1292%_ _%b1293%_)
                 (> (##structure-ref
                     _%a1292%_
                     '6
                     gerbil-ascent/table/trrel-uf#uf-node::t
                     '#f)
                    (##structure-ref
                     _%b1293%_
                     '6
                     gerbil-ascent/table/trrel-uf#uf-node::t
                     '#f))))
              (__tmp34058
               (cons _%node1289%_
                     (let () (declare (not safe)) (hash-keys _%table1290%_)))))
          (declare (not safe))
          (##list-sort __tmp34059 __tmp34058))))
    (define gerbil-ascent/table/trrel-uf#rebuild-predecessors!
      (lambda (_%roots1280%_)
        (for-each
         (lambda (_%n1282%_)
           (##structure-set!
            _%n1282%_
            (let () (declare (not safe)) (make-hash-table-eq))
            '5
            gerbil-ascent/table/trrel-uf#uf-node::t
            '#f))
         _%roots1280%_)
        (for-each
         (lambda (_%n1284%_)
           (let ((__tmp34061
                  (lambda (_%target1286%_ _%_1287%_)
                    (let ((__tmp34062
                           (##structure-ref
                            _%target1286%_
                            '5
                            gerbil-ascent/table/trrel-uf#uf-node::t
                            '#f)))
                      (declare (not safe))
                      (hash-put! __tmp34062 _%n1284%_ '#t))))
                 (__tmp34060
                  (##structure-ref
                   _%n1284%_
                   '4
                   gerbil-ascent/table/trrel-uf#uf-node::t
                   '#f)))
             (declare (not safe))
             (hash-for-each __tmp34061 __tmp34060)))
         _%roots1280%_)))
    (define gerbil-ascent/table/trrel-uf#retire-cycle-predecessors!
      (lambda (_%winner1272%_ _%cycle1273%_)
        (for-each
         (lambda (_%n1275%_)
           (if (eq? _%n1275%_ _%winner1272%_)
               '#!void
               (let ((__tmp34064
                      (lambda (_%target1277%_ _%_1278%_)
                        (let ((__tmp34065
                               (##structure-ref
                                _%target1277%_
                                '5
                                gerbil-ascent/table/trrel-uf#uf-node::t
                                '#f)))
                          (declare (not safe))
                          (hash-remove! __tmp34065 _%n1275%_))))
                     (__tmp34063
                      (##structure-ref
                       _%n1275%_
                       '4
                       gerbil-ascent/table/trrel-uf#uf-node::t
                       '#f)))
                 (declare (not safe))
                 (hash-for-each __tmp34064 __tmp34063)))
           (let ((__tmp34066
                  (##structure-ref
                   _%winner1272%_
                   '5
                   gerbil-ascent/table/trrel-uf#uf-node::t
                   '#f)))
             (declare (not safe))
             (hash-remove! __tmp34066 _%n1275%_)))
         _%cycle1273%_)))
    (define gerbil-ascent/table/trrel-uf#merge-cycle!
      (lambda (_%group1241%_ _%roots1242%_ _%cycle1243%_)
        (let* ((_%winner1248%_
                (let ((__tmp34069
                       (lambda (_%n1245%_ _%best1246%_)
                         (if (> (##structure-ref
                                 _%n1245%_
                                 '3
                                 gerbil-ascent/table/trrel-uf#uf-node::t
                                 '#f)
                                (##structure-ref
                                 _%best1246%_
                                 '3
                                 gerbil-ascent/table/trrel-uf#uf-node::t
                                 '#f))
                             _%n1245%_
                             _%best1246%_)))
                      (__tmp34068 (car _%cycle1243%_))
                      (__tmp34067 (cdr _%cycle1243%_)))
                  (declare (not safe))
                  (foldl__0 __tmp34069 __tmp34068 __tmp34067)))
               (_%merged1250%_
                (##structure-ref
                 _%winner1248%_
                 '2
                 gerbil-ascent/table/trrel-uf#uf-node::t
                 '#f))
               (_%size1252%_
                (##structure-ref
                 _%winner1248%_
                 '3
                 gerbil-ascent/table/trrel-uf#uf-node::t
                 '#f)))
          (if (##structure-ref
               _%group1241%_
               '4
               gerbil-ascent/table/trrel-uf#uf-group::t
               '#f)
              (gerbil-ascent/table/trrel-uf#retire-cycle-predecessors!
               _%winner1248%_
               _%cycle1243%_)
              '#!void)
          (for-each
           (lambda (_%n1255%_)
             (if (eq? _%n1255%_ _%winner1248%_)
                 '#!void
                 (begin
                   (set! _%merged1250%_
                         (append (##structure-ref
                                  _%n1255%_
                                  '2
                                  gerbil-ascent/table/trrel-uf#uf-node::t
                                  '#f)
                                 _%merged1250%_))
                   (set! _%size1252%_
                         (+ _%size1252%_
                            (##structure-ref
                             _%n1255%_
                             '3
                             gerbil-ascent/table/trrel-uf#uf-node::t
                             '#f)))
                   (##structure-set!
                    _%n1255%_
                    _%winner1248%_
                    '1
                    gerbil-ascent/table/trrel-uf#uf-node::t
                    '#f)
                   (##structure-set!
                    _%n1255%_
                    '()
                    '2
                    gerbil-ascent/table/trrel-uf#uf-node::t
                    '#f)
                   (##structure-set!
                    _%n1255%_
                    '0
                    '3
                    gerbil-ascent/table/trrel-uf#uf-node::t
                    '#f)
                   (##structure-set!
                    _%n1255%_
                    (let () (declare (not safe)) (make-hash-table-eq))
                    '4
                    gerbil-ascent/table/trrel-uf#uf-node::t
                    '#f)
                   (##structure-set!
                    _%n1255%_
                    '#f
                    '5
                    gerbil-ascent/table/trrel-uf#uf-node::t
                    '#f))))
           _%cycle1243%_)
          (##structure-set!
           _%winner1248%_
           _%merged1250%_
           '2
           gerbil-ascent/table/trrel-uf#uf-node::t
           '#f)
          (##structure-set!
           _%winner1248%_
           _%size1252%_
           '3
           gerbil-ascent/table/trrel-uf#uf-node::t
           '#f)
          (set! _%roots1242%_
                (filter (lambda (_%n1257%_)
                          (not (##structure-ref
                                _%n1257%_
                                '1
                                gerbil-ascent/table/trrel-uf#uf-node::t
                                '#f)))
                        _%roots1242%_))
          (##structure-set!
           _%group1241%_
           _%roots1242%_
           '2
           gerbil-ascent/table/trrel-uf#uf-group::t
           '#f)
          (for-each
           (lambda (_%n1259%_)
             (if (and (eq? _%n1259%_ _%winner1248%_)
                      (or (null? (cdr _%roots1242%_))
                          (= (let ((__tmp34070
                                    (##structure-ref
                                     _%n1259%_
                                     '4
                                     gerbil-ascent/table/trrel-uf#uf-node::t
                                     '#f)))
                               (declare (not safe))
                               (hash-length __tmp34070))
                             (- (length _%cycle1243%_) '1))))
                 (##structure-set!
                  _%n1259%_
                  (let () (declare (not safe)) (make-hash-table-eq))
                  '4
                  gerbil-ascent/table/trrel-uf#uf-node::t
                  '#f)
                 (if (or (eq? _%n1259%_ _%winner1248%_)
                         (let ((__tmp34071
                                (##structure-ref
                                 _%n1259%_
                                 '4
                                 gerbil-ascent/table/trrel-uf#uf-node::t
                                 '#f)))
                           (declare (not safe))
                           (hash-get __tmp34071 _%winner1248%_)))
                     (for-each
                      (lambda (_%target1267%_)
                        (if (or (not (eq? _%target1267%_ _%winner1248%_))
                                (eq? _%n1259%_ _%winner1248%_))
                            (let ((__tmp34072
                                   (##structure-ref
                                    _%n1259%_
                                    '4
                                    gerbil-ascent/table/trrel-uf#uf-node::t
                                    '#f)))
                              (declare (not safe))
                              (hash-remove! __tmp34072 _%target1267%_))
                            '#!void))
                      _%cycle1243%_)
                     '#!void)))
           _%roots1242%_))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-insert!
      (lambda (_%groups1205%_ _%row1206%_ _%budget1207%_)
        (let* ((_%width1209%_ (length _%row1206%_))
               (_%_1211%_
                (if (let () (declare (not safe)) (##memq _%width1209%_ '(2 3)))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"ASCENT trrel requires two or three columns"
                             _%row1206%_))))
               (_%group-key1213%_
                (list _%width1209%_
                      (if (= _%width1209%_ '3) (car _%row1206%_) '#f)))
               (_%pair1215%_
                (if (= _%width1209%_ '3) (cdr _%row1206%_) _%row1206%_))
               (_%left1217%_ (car _%pair1215%_))
               (_%right1219%_ (cadr _%pair1215%_))
               (_%stored1221%_
                (let ()
                  (declare (not safe))
                  (hash-get _%groups1205%_ _%group-key1213%_)))
               (_%group1226%_
                (let ((_%$e1223%_ _%stored1221%_))
                  (if _%$e1223%_
                      _%$e1223%_
                      (let ((__tmp34073
                             (let ()
                               (declare (not safe))
                               (make-hash-table__%
                                '#f
                                absent-value
                                absent-value
                                absent-value
                                absent-value
                                absent-value
                                absent-value
                                absent-value
                                absent-value))))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/table/trrel-uf#uf-group::t
                         __tmp34073
                         '()
                         '0
                         '#f)))))
               (_%nodes1228%_
                (##structure-ref
                 _%group1226%_
                 '1
                 gerbil-ascent/table/trrel-uf#uf-group::t
                 '#f))
               (_%left-node1230%_
                (let ()
                  (declare (not safe))
                  (hash-get _%nodes1228%_ _%left1217%_)))
               (_%right-node1232%_
                (let ()
                  (declare (not safe))
                  (hash-get _%nodes1228%_ _%right1219%_)))
               (_%a1234%_
                (if _%left-node1230%_
                    (gerbil-ascent/table/trrel-uf#root _%left-node1230%_)
                    (gerbil-ascent/table/trrel-uf#fresh
                     _%left1217%_
                     (+ '2
                        (##structure-ref
                         _%group1226%_
                         '3
                         gerbil-ascent/table/trrel-uf#uf-group::t
                         '#f))
                     (##structure-ref
                      _%group1226%_
                      '4
                      gerbil-ascent/table/trrel-uf#uf-group::t
                      '#f))))
               (_%b1236%_
                (if (equal? _%left1217%_ _%right1219%_)
                    _%a1234%_
                    (if _%right-node1232%_
                        (gerbil-ascent/table/trrel-uf#root _%right-node1232%_)
                        (gerbil-ascent/table/trrel-uf#fresh
                         _%right1219%_
                         (+ '1
                            (##structure-ref
                             _%group1226%_
                             '3
                             gerbil-ascent/table/trrel-uf#uf-group::t
                             '#f))
                         (##structure-ref
                          _%group1226%_
                          '4
                          gerbil-ascent/table/trrel-uf#uf-group::t
                          '#f)))))
               (_%admitted?1238%_
                (if _%left-node1230%_
                    (if _%right-node1232%_
                        (gerbil-ascent/table/trrel-uf#reachable?
                         _%a1234%_
                         _%b1236%_)
                        '#f)
                    '#f)))
          (if _%admitted?1238%_
              (begin
                (if (< _%budget1207%_ '0)
                    (let ()
                      (declare (not safe))
                      (error '"ASCENT trrel output fact budget exceeded"))
                    '#!void)
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__0
                   '()
                   '0
                   '0)))
              (gerbil-ascent/table/trrel-uf#insert-components!
               _%groups1205%_
               (let ()
                 (declare (not safe))
                 (##structure
                  gerbil-ascent/table/trrel-uf#uf-insertion::t
                  _%group-key1213%_
                  _%group1226%_
                  _%row1206%_
                  _%left-node1230%_
                  _%right-node1232%_
                  _%a1234%_
                  _%b1236%_))
               _%budget1207%_)))))
    (define gerbil-ascent/table/trrel-uf#insert-components!
      (lambda (_%groups1088%_ _%admission1089%_ _%budget1090%_)
        (let* ((_%$%admission10911103%_ _%admission1089%_)
               (_%$%E10931106%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%admission10911103%_
                           '((uf-insertion
                              group-key
                              group
                              row
                              left-node
                              right-node
                              a
                              b))))
                  '#!void))
               (_%$%K10941167%_
                (lambda (_%b1109%_
                         _%a1110%_
                         _%right-node1111%_
                         _%left-node1112%_
                         _%row1113%_
                         _%group1114%_
                         _%group-key1115%_)
                  (let* ((_%width1117%_ (car _%group-key1115%_))
                         (_%nodes1119%_
                          (##structure-ref
                           _%group1114%_
                           '1
                           gerbil-ascent/table/trrel-uf#uf-group::t
                           '#f))
                         (_%pair1121%_
                          (if (= _%width1117%_ '3)
                              (cdr _%row1113%_)
                              _%row1113%_))
                         (_%left1123%_ (car _%pair1121%_))
                         (_%right1125%_ (cadr _%pair1121%_))
                         (_%new1130%_
                          (let ((__tmp34075
                                 (if _%left-node1112%_ '() (list _%a1110%_)))
                                (__tmp34074
                                 (if (or _%right-node1111%_
                                         (eq? _%a1110%_ _%b1109%_))
                                     '()
                                     (list _%b1109%_))))
                            (declare (not safe))
                            (##append __tmp34075 __tmp34074)))
                         (_%roots1132%_
                          (append _%new1130%_
                                  (##structure-ref
                                   _%group1114%_
                                   '2
                                   gerbil-ascent/table/trrel-uf#uf-group::t
                                   '#f)))
                         (_%preds1136%_
                          (if (##structure-ref
                               _%group1114%_
                               '4
                               gerbil-ascent/table/trrel-uf#uf-group::t
                               '#f)
                              (gerbil-ascent/table/trrel-uf#ordered-neighbors
                               _%a1110%_
                               (##structure-ref
                                _%a1110%_
                                '5
                                gerbil-ascent/table/trrel-uf#uf-node::t
                                '#f))
                              (let ((__tmp34076
                                     (lambda (_%p1134%_)
                                       (gerbil-ascent/table/trrel-uf#reachable?
                                        _%p1134%_
                                        _%a1110%_))))
                                (declare (not safe))
                                (##filter __tmp34076 _%roots1132%_))))
                         (_%succs1140%_
                          (if (##structure-ref
                               _%group1114%_
                               '4
                               gerbil-ascent/table/trrel-uf#uf-group::t
                               '#f)
                              (gerbil-ascent/table/trrel-uf#ordered-neighbors
                               _%b1109%_
                               (##structure-ref
                                _%b1109%_
                                '4
                                gerbil-ascent/table/trrel-uf#uf-node::t
                                '#f))
                              (let ((__tmp34077
                                     (lambda (_%s1138%_)
                                       (gerbil-ascent/table/trrel-uf#reachable?
                                        _%b1109%_
                                        _%s1138%_))))
                                (declare (not safe))
                                (##filter __tmp34077 _%roots1132%_))))
                         (_%cycle1144%_
                          (if (eq? _%a1110%_ _%b1109%_)
                              '#f
                              (if (gerbil-ascent/table/trrel-uf#reachable?
                                   _%b1109%_
                                   _%a1110%_)
                                  (let ((__tmp34078
                                         (lambda (_%p1142%_)
                                           (gerbil-ascent/table/trrel-uf#reachable?
                                            _%b1109%_
                                            _%p1142%_))))
                                    (declare (not safe))
                                    (##filter __tmp34078 _%preds1136%_))
                                  '#f)))
                         (_%changes1146%_ '())
                         (_%needed1148%_
                          (let () (declare (not safe)) (##length _%new1130%_)))
                         (_%added1150%_ '()))
                    (let ((__tmp34079
                           (lambda (_%p1153%_)
                             (let ((__tmp34080
                                    (lambda (_%s1155%_)
                                      (if (gerbil-ascent/table/trrel-uf#reachable?
                                           _%p1153%_
                                           _%s1155%_)
                                          '#!void
                                          (begin
                                            (set! _%needed1148%_
                                                  (+ _%needed1148%_
                                                     (* (##structure-ref
                                                         _%p1153%_
                                                         '3
                                                         gerbil-ascent/table/trrel-uf#uf-node::t
                                                         '#f)
                                                        (##structure-ref
                                                         _%s1155%_
                                                         '3
                                                         gerbil-ascent/table/trrel-uf#uf-node::t
                                                         '#f))))
                                            (set! _%changes1146%_
                                                  (cons (cons _%p1153%_
                                                              _%s1155%_)
                                                        _%changes1146%_)))))))
                               (declare (not safe))
                               (##for-each __tmp34080 _%succs1140%_)))))
                      (declare (not safe))
                      (##for-each __tmp34079 _%preds1136%_))
                    (if (> _%needed1148%_ _%budget1090%_)
                        (let ()
                          (declare (not safe))
                          (error '"ASCENT trrel output fact budget exceeded"))
                        '#!void)
                    (let ((_%prefix1157%_
                           (if (= _%width1117%_ '3)
                               (list (car _%row1113%_))
                               '())))
                      (let ((__tmp34081
                             (lambda (_%n1159%_)
                               (let ((_%members1161%_
                                      (##structure-ref
                                       _%n1159%_
                                       '2
                                       gerbil-ascent/table/trrel-uf#uf-node::t
                                       '#f)))
                                 (set! _%added1150%_
                                       (cons (let ()
                                               (declare (not safe))
                                               (##structure
                                                gerbil-ascent/core/relation-view#rectangle::t
                                                _%prefix1157%_
                                                _%members1161%_
                                                _%members1161%_))
                                             _%added1150%_))))))
                        (declare (not safe))
                        (##for-each __tmp34081 _%new1130%_))
                      (let ((__tmp34082
                             (lambda (_%change1163%_)
                               (set! _%added1150%_
                                     (cons (let ((__tmp34084
                                                  (##structure-ref
                                                   (car _%change1163%_)
                                                   '2
                                                   gerbil-ascent/table/trrel-uf#uf-node::t
                                                   '#f))
                                                 (__tmp34083
                                                  (##structure-ref
                                                   (cdr _%change1163%_)
                                                   '2
                                                   gerbil-ascent/table/trrel-uf#uf-node::t
                                                   '#f)))
                                             (declare (not safe))
                                             (##structure
                                              gerbil-ascent/core/relation-view#rectangle::t
                                              _%prefix1157%_
                                              __tmp34084
                                              __tmp34083))
                                           _%added1150%_)))))
                        (declare (not safe))
                        (##for-each __tmp34082 _%changes1146%_)))
                    (if (null? _%new1130%_)
                        '#!void
                        (begin
                          (let ()
                            (declare (not safe))
                            (hash-put!
                             _%groups1088%_
                             _%group-key1115%_
                             _%group1114%_))
                          (if _%left-node1112%_
                              '#!void
                              (let ()
                                (declare (not safe))
                                (hash-put!
                                 _%nodes1119%_
                                 _%left1123%_
                                 _%a1110%_)))
                          (if _%right-node1111%_
                              '#!void
                              (let ()
                                (declare (not safe))
                                (hash-put!
                                 _%nodes1119%_
                                 _%right1125%_
                                 _%b1109%_)))
                          (##structure-set!
                           _%group1114%_
                           _%roots1132%_
                           '2
                           gerbil-ascent/table/trrel-uf#uf-group::t
                           '#f)
                          (##structure-set!
                           _%group1114%_
                           (+ '2
                              (##structure-ref
                               _%group1114%_
                               '3
                               gerbil-ascent/table/trrel-uf#uf-group::t
                               '#f))
                           '3
                           gerbil-ascent/table/trrel-uf#uf-group::t
                           '#f)))
                    (if (##structure-ref
                         _%group1114%_
                         '4
                         gerbil-ascent/table/trrel-uf#uf-group::t
                         '#f)
                        '#!void
                        (if (> (let ()
                                 (declare (not safe))
                                 (##length _%roots1132%_))
                               '64)
                            (begin
                              (##structure-set!
                               _%group1114%_
                               '#t
                               '4
                               gerbil-ascent/table/trrel-uf#uf-group::t
                               '#f)
                              (gerbil-ascent/table/trrel-uf#rebuild-predecessors!
                               _%roots1132%_))
                            '#!void))
                    (if (and _%cycle1144%_
                             (= (let ()
                                  (declare (not safe))
                                  (##length _%cycle1144%_))
                                (let ()
                                  (declare (not safe))
                                  (##length _%roots1132%_))))
                        '#!void
                        (let ((__tmp34085
                               (lambda (_%change1165%_)
                                 (let ((__tmp34087
                                        (##structure-ref
                                         (car _%change1165%_)
                                         '4
                                         gerbil-ascent/table/trrel-uf#uf-node::t
                                         '#f))
                                       (__tmp34086 (cdr _%change1165%_)))
                                   (declare (not safe))
                                   (hash-put! __tmp34087 __tmp34086 '#t))
                                 (if (##structure-ref
                                      _%group1114%_
                                      '4
                                      gerbil-ascent/table/trrel-uf#uf-group::t
                                      '#f)
                                     (let ((__tmp34089
                                            (##structure-ref
                                             (cdr _%change1165%_)
                                             '5
                                             gerbil-ascent/table/trrel-uf#uf-node::t
                                             '#f))
                                           (__tmp34088 (car _%change1165%_)))
                                       (declare (not safe))
                                       (hash-put! __tmp34089 __tmp34088 '#t))
                                     '#!void))))
                          (declare (not safe))
                          (##for-each __tmp34085 _%changes1146%_)))
                    (if _%cycle1144%_
                        (gerbil-ascent/table/trrel-uf#merge-cycle!
                         _%group1114%_
                         _%roots1132%_
                         _%cycle1144%_)
                        '#!void)
                    (let ((__tmp34091
                           (let ()
                             (declare (not safe))
                             (##reverse _%added1150%_)))
                          (__tmp34090
                           (let ()
                             (declare (not safe))
                             (##length _%added1150%_))))
                      (declare (not safe))
                      (gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__0
                       __tmp34091
                       _%needed1148%_
                       __tmp34090))))))
          (if (let ()
                (declare (not safe))
                (##structure-direct-instance-of?
                 _%$%admission10911103%_
                 'gerbil-ascent/table/trrel-uf#uf-insertion::t))
              (let* ((_%$%e10951170%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission10911103%_
                         '1
                         '#f
                         '#f)))
                     (_%group-key1173%_ _%$%e10951170%_)
                     (_%$%e10961175%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission10911103%_
                         '2
                         '#f
                         '#f)))
                     (_%group1178%_ _%$%e10961175%_)
                     (_%$%e10971180%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission10911103%_
                         '3
                         '#f
                         '#f)))
                     (_%row1183%_ _%$%e10971180%_)
                     (_%$%e10981185%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission10911103%_
                         '4
                         '#f
                         '#f)))
                     (_%left-node1188%_ _%$%e10981185%_)
                     (_%$%e10991190%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission10911103%_
                         '5
                         '#f
                         '#f)))
                     (_%right-node1193%_ _%$%e10991190%_)
                     (_%$%e11001195%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission10911103%_
                         '6
                         '#f
                         '#f)))
                     (_%a1198%_ _%$%e11001195%_)
                     (_%$%e11011200%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission10911103%_
                         '7
                         '#f
                         '#f)))
                     (_%b1203%_ _%$%e11011200%_))
                (_%$%K10941167%_
                 _%b1203%_
                 _%a1198%_
                 _%right-node1193%_
                 _%left-node1188%_
                 _%row1183%_
                 _%group1178%_
                 _%group-key1173%_))
              (_%$%E10931106%_)))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-observation
      (lambda (_%groups1077%_)
        (let ((_%nodes1079%_ '0) (_%components1080%_ '0) (_%arcs1081%_ '0))
          (let ((__tmp34092
                 (lambda (_%_1083%_ _%g1084%_)
                   (set! _%nodes1079%_
                         (+ _%nodes1079%_
                            (let ((__tmp34093
                                   (##structure-ref
                                    _%g1084%_
                                    '1
                                    gerbil-ascent/table/trrel-uf#uf-group::t
                                    '#f)))
                              (declare (not safe))
                              (hash-length __tmp34093))))
                   (set! _%components1080%_
                         (+ _%components1080%_
                            (length (##structure-ref
                                     _%g1084%_
                                     '2
                                     gerbil-ascent/table/trrel-uf#uf-group::t
                                     '#f))))
                   (for-each
                    (lambda (_%n1086%_)
                      (set! _%arcs1081%_
                            (+ _%arcs1081%_
                               (let ((__tmp34094
                                      (##structure-ref
                                       _%n1086%_
                                       '4
                                       gerbil-ascent/table/trrel-uf#uf-node::t
                                       '#f)))
                                 (declare (not safe))
                                 (hash-length __tmp34094)))))
                    (##structure-ref
                     _%g1084%_
                     '2
                     gerbil-ascent/table/trrel-uf#uf-group::t
                     '#f)))))
            (declare (not safe))
            (hash-for-each __tmp34092 _%groups1077%_))
          (vector _%nodes1079%_ _%components1080%_ _%arcs1081%_))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-validate
      (lambda (_%groups1014%_)
        (letrec ((_%require!1016%_
                  (lambda (_%ok1074%_ _%message1075%_)
                    (if _%ok1074%_
                        '#!void
                        (let ()
                          (declare (not safe))
                          (error _%message1075%_)))))
                 (_%unique?1017%_
                  (lambda (_%values1062%_ _%same?1063%_)
                    (let _%loop1065%_ ((_%rest1067%_ _%values1062%_))
                      (let ((_%$e1069%_ (null? _%rest1067%_)))
                        (if _%$e1069%_
                            _%$e1069%_
                            (if (let ((__tmp34096
                                       (lambda (_%v1072%_)
                                         (_%same?1063%_
                                          (car _%rest1067%_)
                                          _%v1072%_)))
                                      (__tmp34095 (cdr _%rest1067%_)))
                                  (declare (not safe))
                                  (ormap__0 __tmp34096 __tmp34095))
                                '#f
                                (_%loop1065%_ (cdr _%rest1067%_))))))))
                 (_%checked-root1018%_
                  (lambda (_%node1055%_)
                    (let _%loop1057%_ ((_%n1059%_ _%node1055%_)
                                       (_%seen1060%_ '()))
                      (_%require!1016%_
                       (not (memq _%n1059%_ _%seen1060%_))
                       '"ASCENT UF parent cycle")
                      (if (##structure-ref
                           _%n1059%_
                           '1
                           gerbil-ascent/table/trrel-uf#uf-node::t
                           '#f)
                          (_%loop1057%_
                           (##structure-ref
                            _%n1059%_
                            '1
                            gerbil-ascent/table/trrel-uf#uf-node::t
                            '#f)
                           (cons _%n1059%_ _%seen1060%_))
                          _%n1059%_)))))
          (let ((__tmp34097
                 (lambda (_%_1020%_ _%group1021%_)
                   (let ((_%nodes1023%_
                          (##structure-ref
                           _%group1021%_
                           '1
                           gerbil-ascent/table/trrel-uf#uf-group::t
                           '#f))
                         (_%roots1024%_
                          (##structure-ref
                           _%group1021%_
                           '2
                           gerbil-ascent/table/trrel-uf#uf-group::t
                           '#f)))
                     (_%require!1016%_
                      (_%unique?1017%_ _%roots1024%_ eq?)
                      '"ASCENT UF duplicate root")
                     (let _%loop1026%_ ((_%remaining1028%_ _%roots1024%_)
                                        (_%ceiling1029%_
                                         (+ '1
                                            (##structure-ref
                                             _%group1021%_
                                             '3
                                             gerbil-ascent/table/trrel-uf#uf-group::t
                                             '#f))))
                       (if (null? _%remaining1028%_)
                           '#!void
                           (let ((_%order1031%_
                                  (##structure-ref
                                   (car _%remaining1028%_)
                                   '6
                                   gerbil-ascent/table/trrel-uf#uf-node::t
                                   '#f)))
                             (_%require!1016%_
                              (if (exact-integer? _%order1031%_)
                                  (if (> _%order1031%_ '0)
                                      (< _%order1031%_ _%ceiling1029%_)
                                      '#f)
                                  '#f)
                              '"ASCENT UF root scan order mismatch")
                             (_%loop1026%_
                              (cdr _%remaining1028%_)
                              _%order1031%_))))
                     (let ((__tmp34098
                            (lambda (_%value1033%_ _%node1034%_)
                              (let ((_%owner1036%_
                                     (_%checked-root1018%_ _%node1034%_)))
                                (_%require!1016%_
                                 (memq _%owner1036%_ _%roots1024%_)
                                 '"ASCENT UF missing root")
                                (_%require!1016%_
                                 (member _%value1033%_
                                         (##structure-ref
                                          _%owner1036%_
                                          '2
                                          gerbil-ascent/table/trrel-uf#uf-node::t
                                          '#f))
                                 '"ASCENT UF missing member")
                                (if (##structure-ref
                                     _%node1034%_
                                     '1
                                     gerbil-ascent/table/trrel-uf#uf-node::t
                                     '#f)
                                    (_%require!1016%_
                                     (if (null? (##structure-ref
                                                 _%node1034%_
                                                 '2
                                                 gerbil-ascent/table/trrel-uf#uf-node::t
                                                 '#f))
                                         (if (= (##structure-ref
                                                 _%node1034%_
                                                 '3
                                                 gerbil-ascent/table/trrel-uf#uf-node::t
                                                 '#f)
                                                '0)
                                             (if (= (let ((__tmp34099
                                                           (##structure-ref
                                                            _%node1034%_
                                                            '4
                                                            gerbil-ascent/table/trrel-uf#uf-node::t
                                                            '#f)))
                                                      (declare (not safe))
                                                      (hash-length __tmp34099))
                                                    '0)
                                                 (not (##structure-ref
                                                       _%node1034%_
                                                       '5
                                                       gerbil-ascent/table/trrel-uf#uf-node::t
                                                       '#f))
                                                 '#f)
                                             '#f)
                                         '#f)
                                     '"ASCENT UF absorbed storage retained")
                                    '#!void)))))
                       (declare (not safe))
                       (hash-for-each __tmp34098 _%nodes1023%_))
                     (for-each
                      (lambda (_%n1038%_)
                        (let ((_%members1040%_
                               (##structure-ref
                                _%n1038%_
                                '2
                                gerbil-ascent/table/trrel-uf#uf-node::t
                                '#f)))
                          (_%require!1016%_
                           (not (##structure-ref
                                 _%n1038%_
                                 '1
                                 gerbil-ascent/table/trrel-uf#uf-node::t
                                 '#f))
                           '"ASCENT UF non-root owner")
                          (_%require!1016%_
                           (if (> (##structure-ref
                                   _%n1038%_
                                   '3
                                   gerbil-ascent/table/trrel-uf#uf-node::t
                                   '#f)
                                  '0)
                               (if (= (##structure-ref
                                       _%n1038%_
                                       '3
                                       gerbil-ascent/table/trrel-uf#uf-node::t
                                       '#f)
                                      (length _%members1040%_))
                                   (_%unique?1017%_ _%members1040%_ equal?)
                                   '#f)
                               '#f)
                           '"ASCENT UF member size mismatch")
                          (for-each
                           (lambda (_%value1042%_)
                             (let ((_%node1044%_
                                    (let ()
                                      (declare (not safe))
                                      (hash-get _%nodes1023%_ _%value1042%_))))
                               (_%require!1016%_
                                (if _%node1044%_
                                    (eq? (_%checked-root1018%_ _%node1044%_)
                                         _%n1038%_)
                                    '#f)
                                '"ASCENT UF wrong member owner")))
                           _%members1040%_))
                        (if (##structure-ref
                             _%group1021%_
                             '4
                             gerbil-ascent/table/trrel-uf#uf-group::t
                             '#f)
                            (begin
                              (_%require!1016%_
                               (let ((__tmp34100
                                      (##structure-ref
                                       _%n1038%_
                                       '5
                                       gerbil-ascent/table/trrel-uf#uf-node::t
                                       '#f)))
                                 (declare (not safe))
                                 (##structure-direct-instance-of?
                                  __tmp34100
                                  'HashTable::t))
                               '"ASCENT UF missing predecessor map")
                              (let ((__tmp34102
                                     (lambda (_%predecessor1046%_ _%_1047%_)
                                       (_%require!1016%_
                                        (if (eq? _%n1038%_ _%predecessor1046%_)
                                            '#f
                                            (if (memq _%predecessor1046%_
                                                      _%roots1024%_)
                                                (let ((__tmp34103
                                                       (##structure-ref
                                                        _%predecessor1046%_
                                                        '4
                                                        gerbil-ascent/table/trrel-uf#uf-node::t
                                                        '#f)))
                                                  (declare (not safe))
                                                  (hash-get
                                                   __tmp34103
                                                   _%n1038%_))
                                                '#f))
                                        '"ASCENT UF stale predecessor key")))
                                    (__tmp34101
                                     (##structure-ref
                                      _%n1038%_
                                      '5
                                      gerbil-ascent/table/trrel-uf#uf-node::t
                                      '#f)))
                                (declare (not safe))
                                (hash-for-each __tmp34102 __tmp34101)))
                            (_%require!1016%_
                             (not (##structure-ref
                                   _%n1038%_
                                   '5
                                   gerbil-ascent/table/trrel-uf#uf-node::t
                                   '#f))
                             '"ASCENT UF premature predecessor map"))
                        (let ((__tmp34105
                               (lambda (_%target1049%_ _%_1050%_)
                                 (if (##structure-ref
                                      _%group1021%_
                                      '4
                                      gerbil-ascent/table/trrel-uf#uf-group::t
                                      '#f)
                                     (_%require!1016%_
                                      (let ((__tmp34106
                                             (##structure-ref
                                              _%target1049%_
                                              '5
                                              gerbil-ascent/table/trrel-uf#uf-node::t
                                              '#f)))
                                        (declare (not safe))
                                        (hash-get __tmp34106 _%n1038%_))
                                      '"ASCENT UF missing predecessor key")
                                     '#!void)
                                 (_%require!1016%_
                                  (if (eq? _%n1038%_ _%target1049%_)
                                      '#f
                                      (memq _%target1049%_ _%roots1024%_))
                                  '"ASCENT UF stale reach key")
                                 (let ((__tmp34108
                                        (lambda (_%successor1052%_ _%_1053%_)
                                          (_%require!1016%_
                                           (gerbil-ascent/table/trrel-uf#reachable?
                                            _%n1038%_
                                            _%successor1052%_)
                                           '"ASCENT UF incomplete root closure")))
                                       (__tmp34107
                                        (##structure-ref
                                         _%target1049%_
                                         '4
                                         gerbil-ascent/table/trrel-uf#uf-node::t
                                         '#f)))
                                   (declare (not safe))
                                   (hash-for-each __tmp34108 __tmp34107))))
                              (__tmp34104
                               (##structure-ref
                                _%n1038%_
                                '4
                                gerbil-ascent/table/trrel-uf#uf-node::t
                                '#f)))
                          (declare (not safe))
                          (hash-for-each __tmp34105 __tmp34104)))
                      _%roots1024%_)))))
            (declare (not safe))
            (hash-for-each __tmp34097 _%groups1014%_))
          '#t)))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-extension
      (lambda (_%groups1008%_
               _%_all1009%_
               _%_pending1010%_
               _%row1011%_
               _%budget1012%_)
        (let ((__tmp34109
               (gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-insert!
                _%groups1008%_
                _%row1011%_
                _%budget1012%_)))
          (declare (not safe))
          (gerbil-ascent/core/relation-view#gerbil-ascent-view-rows
           __tmp34109))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__%
      (lambda (_%groups945%_ _%indexed?946%_)
        (let ((_%blocks948%_ '()) (_%count949%_ '0) (_%units950%_ '0))
          (let ((__tmp34110
                 (lambda (_%key952%_ _%group953%_)
                   (let ((_%members955%_
                          (let () (declare (not safe)) (make-hash-table-eq)))
                         (_%prefix956%_
                          (if (= (car _%key952%_) '3)
                              (list (cadr _%key952%_))
                              '())))
                     (for-each
                      (lambda (_%node958%_)
                        (let ((_%owned960%_
                               (map values
                                    (##structure-ref
                                     _%node958%_
                                     '2
                                     gerbil-ascent/table/trrel-uf#uf-node::t
                                     '#f))))
                          (set! _%units950%_
                                (+ _%units950%_
                                   (##structure-ref
                                    _%node958%_
                                    '3
                                    gerbil-ascent/table/trrel-uf#uf-node::t
                                    '#f)))
                          (let ((__tmp34111
                                 (let ((__tmp34112
                                        (##structure-ref
                                         _%node958%_
                                         '3
                                         gerbil-ascent/table/trrel-uf#uf-node::t
                                         '#f)))
                                   (declare (not safe))
                                   (##structure
                                    gerbil-ascent/table/trrel-uf#frozen-members::t
                                    _%owned960%_
                                    __tmp34112))))
                            (declare (not safe))
                            (__hash-put!
                             _%members955%_
                             _%node958%_
                             __tmp34111))))
                      (##structure-ref
                       _%group953%_
                       '2
                       gerbil-ascent/table/trrel-uf#uf-group::t
                       '#f))
                     (for-each
                      (lambda (_%node962%_)
                        (let* ((_%left964%_
                                (let ()
                                  (declare (not safe))
                                  (__hash-get _%members955%_ _%node962%_)))
                               (_%left966%_ _%left964%_))
                          (letrec ((_%capture978%_
                                    (lambda (_%target983%_)
                                      (let* ((_%right985%_
                                              (let ()
                                                (declare (not safe))
                                                (__hash-get
                                                 _%members955%_
                                                 _%target983%_)))
                                             (_%right987%_ _%right985%_))
                                        (set! _%count949%_
                                              (+ _%count949%_
                                                 (* (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%left966%_
                                                       '2
                                                       '#f
                                                       '#f))
                                                    (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%right987%_
                                                       '2
                                                       '#f
                                                       '#f)))))
                                        (set! _%units950%_ (+ _%units950%_ '1))
                                        (set! _%blocks948%_
                                              (cons (let ((__tmp34114
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##unchecked-structure-ref
                                                              _%left966%_
                                                              '1
                                                              '#f
                                                              '#f)))
                                                          (__tmp34113
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##unchecked-structure-ref
                                                              _%right987%_
                                                              '1
                                                              '#f
                                                              '#f))))
                                                      (declare (not safe))
                                                      (##structure
                                                       gerbil-ascent/core/relation-view#rectangle::t
                                                       _%prefix956%_
                                                       __tmp34114
                                                       __tmp34113))
                                                    _%blocks948%_))))))
                            (_%capture978%_ _%node962%_)
                            (let ((__tmp34116
                                   (lambda (_%target980%_ _%_981%_)
                                     (_%capture978%_ _%target980%_)))
                                  (__tmp34115
                                   (##structure-ref
                                    _%node962%_
                                    '4
                                    gerbil-ascent/table/trrel-uf#uf-node::t
                                    '#f)))
                              (declare (not safe))
                              (hash-for-each __tmp34116 __tmp34115)))))
                      (##structure-ref
                       _%group953%_
                       '2
                       gerbil-ascent/table/trrel-uf#uf-group::t
                       '#f))))))
            (declare (not safe))
            (hash-for-each __tmp34110 _%groups945%_))
          (let ((__tmp34117
                 (let () (declare (not safe)) (##reverse _%blocks948%_))))
            (declare (not safe))
            (gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__%
             __tmp34117
             _%count949%_
             _%units950%_
             _%indexed?946%_)))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__0
      (lambda (_%groups1001%_)
        (let ((_%indexed?1003%_ '#t))
          (gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__%
           _%groups1001%_
           _%indexed?1003%_))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze
      (lambda _g34118_
        (let ((_g34119_ (let () (declare (not safe)) (##length _g34118_))))
          (cond ((let () (declare (not safe)) (##fx= _g34119_ 1))
                 (apply gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__0
                        _g34118_))
                ((let () (declare (not safe)) (##fx= _g34119_ 2))
                 (apply gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__%
                        _g34118_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze
                  _g34118_))))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-frontier-extension
      gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-insert!)
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-snapshot
      gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze)
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-view-count
      gerbil-ascent/core/relation-view#relation-view-count)
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-view-for-each
      (lambda (_%view941%_ _%consume942%_)
        (let ()
          (declare (not safe))
          (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
           _%consume942%_
           _%view941%_))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-view-lookup
      (lambda (_%view931%_ _%columns932%_ _%key933%_)
        (if (and (list? _%columns932%_)
                 (list? _%key933%_)
                 (= (let () (declare (not safe)) (##length _%columns932%_))
                    (let () (declare (not safe)) (##length _%key933%_)))
                 (let ((__tmp34120
                        (lambda (_%column935%_)
                          (and (exact-integer? _%column935%_)
                               (>= _%column935%_ '0)))))
                   (declare (not safe))
                   (andmap__0 __tmp34120 _%columns932%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT UF view key")))
        (let ((_%rows937%_ '()))
          (let ((__tmp34122
                 (lambda (_%row939%_)
                   (set! _%rows937%_ (cons _%row939%_ _%rows937%_))))
                (__tmp34121
                 (let ()
                   (declare (not safe))
                   (gerbil-ascent/core/relation-view#gerbil-ascent-view-select
                    _%view931%_
                    _%columns932%_
                    _%key933%_))))
            (declare (not safe))
            (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
             __tmp34122
             __tmp34121))
          (let () (declare (not safe)) (##reverse _%rows937%_)))))))
