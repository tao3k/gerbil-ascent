(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/provider::timestamp 1791689672)
  (begin
    (define gerbil-ascent/table/provider#+procedure+
      (let ((__tmp34445 (lambda (_%_value4286%_ _%_context4287%_) '())))
        (declare (not safe))
        (core/types#poo-flow-predicate-contract
         'ascent/index-provider-procedure
         procedure?
         __tmp34445)))
    (define gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
      (let ((__obj34442
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp34447
               (list (cons 'sexp
                           (let ((__tmp34448
                                  (lambda (_%@4226%_)
                                    'GerbilAscentIndexProviderContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34448)))
                     (cons 'identity
                           (let ((__tmp34449
                                  (lambda (_%@4232%_) 'ascent/index-provider)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34449)))
                     (cons 'proto
                           (let ((__tmp34450
                                  (lambda (_%@4237%_)
                                    (let ((__obj34440
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp34452 (list))
                                            (__tmp34451 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp34452
                                         __tmp34451
                                         __obj34440))
                                      __obj34440))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34450)))
                     (cons 'responsibilities
                           (let ((__tmp34453
                                  (lambda (_%@4251%_)
                                    (let ((__obj34441
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp34455
                                             (list (cons '.build-index
                                                         (let ((__tmp34456
                                                                (lambda (_%self4269%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/table/provider#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp34456)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.extend-index!
                                                         (let ((__tmp34457
                                                                (lambda (_%self4276%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/table/provider#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp34457)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.lookup-index
                                                         (let ((__tmp34458
                                                                (lambda (_%self4281%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/table/provider#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp34458)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp34454 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp34455
                                         __tmp34454
                                         __obj34441))
                                      __obj34441))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34453)))))
              (__tmp34446 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp34447
           __tmp34446
           __obj34442))
        __obj34442))
    (define gerbil-ascent/table/provider#IndexProvider.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
         'proto)))
    (define gerbil-ascent/table/provider#gerbil-ascent-index-provider-build
      (lambda (_%provider4209%_ _%rows4210%_ _%columns4211%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%provider4209%_ '.build-index))
         _%rows4210%_
         _%columns4211%_)))
    (define gerbil-ascent/table/provider#gerbil-ascent-index-provider-extend!
      (lambda (_%provider4204%_ _%index4205%_ _%rows4206%_ _%columns4207%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%provider4204%_ '.extend-index!))
         _%index4205%_
         _%rows4206%_
         _%columns4207%_)))
    (define gerbil-ascent/table/provider#gerbil-ascent-index-provider-lookup
      (lambda (_%provider4200%_ _%index4201%_ _%key4202%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%provider4200%_ '.lookup-index))
         _%index4201%_
         _%key4202%_)))
    (define gerbil-ascent/table/provider#+canonical-hash-index-provider+
      (let ((__tmp34459
             (let ((__obj34443
                    (let ()
                      (declare (not safe))
                      (##structure
                       clan/poo/object#object::t
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f))))
               (let ((__tmp34461
                      (list (cons '.build-index
                                  (let ((__tmp34462
                                         (lambda (_%@4178%_)
                                           gerbil-ascent/table/funs#gerbil-ascent-index-build)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp34462)))
                            (cons '.extend-index!
                                  (let ((__tmp34463
                                         (lambda (_%@4184%_)
                                           gerbil-ascent/table/funs#gerbil-ascent-index-extend!)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp34463)))
                            (cons '.lookup-index
                                  (let ((__tmp34464
                                         (lambda (_%@4189%_)
                                           (lambda (_%index4194%_ _%key4195%_)
                                             (let ((_%$e4197%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (hash-get
                                                       _%index4194%_
                                                       _%key4195%_))))
                                               (if _%$e4197%_
                                                   _%$e4197%_
                                                   '()))))))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp34464)))))
                     (__tmp34460 (list)))
                 (declare (not safe))
                 (clan/poo/object#object:::init!__%
                  '#f
                  gerbil-ascent/table/provider#IndexProvider.
                  __tmp34461
                  __tmp34460
                  __obj34443))
               __obj34443)))
        (declare (not safe))
        (clan/poo/mop#validate
         gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
         __tmp34459)))
    (define gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider
      gerbil-ascent/table/provider#+canonical-hash-index-provider+)
    (define gerbil-ascent/table/provider#+curried-index-provider+
      (let ((__tmp34465
             (let ((__obj34444
                    (let ()
                      (declare (not safe))
                      (##structure
                       clan/poo/object#object::t
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f))))
               (let ((__tmp34467
                      (list (cons '.build-index
                                  (let ((__tmp34468
                                         (lambda (_%@4144%_)
                                           gerbil-ascent/table/funs#gerbil-ascent-index-build)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp34468)))
                            (cons '.extend-index!
                                  (let ((__tmp34469
                                         (lambda (_%@4150%_)
                                           gerbil-ascent/table/funs#gerbil-ascent-index-extend!)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp34469)))
                            (cons '.lookup-index
                                  (let ((__tmp34470
                                         (lambda (_%@4155%_)
                                           (lambda (_%index4160%_ _%key4161%_)
                                             (let ((_%$e4163%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (hash-get
                                                       _%index4160%_
                                                       _%key4161%_))))
                                               (if _%$e4163%_
                                                   _%$e4163%_
                                                   '()))))))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp34470)))))
                     (__tmp34466 (list)))
                 (declare (not safe))
                 (clan/poo/object#object:::init!__%
                  '#f
                  gerbil-ascent/table/provider#IndexProvider.
                  __tmp34467
                  __tmp34466
                  __obj34444))
               __obj34444)))
        (declare (not safe))
        (clan/poo/mop#validate
         gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
         __tmp34465)))
    (define gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider
      gerbil-ascent/table/provider#+curried-index-provider+)
    (define gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider?
      (lambda (_%value4129%_)
        (eq? _%value4129%_
             gerbil-ascent/table/provider#+curried-index-provider+)))
    (define gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
      (lambda (_%value4124%_)
        (let ((_%$e4126%_
               (eq? _%value4124%_
                    gerbil-ascent/table/provider#+canonical-hash-index-provider+)))
          (if _%$e4126%_
              _%$e4126%_
              (eq? _%value4124%_
                   gerbil-ascent/table/provider#+curried-index-provider+)))))))
