prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/core

(begin
  (declare-class
   gerbil-ascent/core/relation-view#relation-view::t
   (@class gerbil-ascent/core/relation-view#relation-view::t
           ()
           (object::t t::t)
           (identity
            generation
            revision
            lane
            count
            units
            visit
            contains
            export
            parts)
           (identity
            generation
            revision
            lane
            count
            units
            visit
            contains
            export
            parts)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/core/relation-view#relation-view::t)
    'class::t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view?
   (@predicate gerbil-ascent/core/relation-view#relation-view::t))
  (declare-type
   gerbil-ascent/core/relation-view#make-relation-view
   (@constructor gerbil-ascent/core/relation-view#relation-view::t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-identity
   (@accessor gerbil-ascent/core/relation-view#relation-view::t identity #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-generation
   (@accessor gerbil-ascent/core/relation-view#relation-view::t generation #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-revision
   (@accessor gerbil-ascent/core/relation-view#relation-view::t revision #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-lane
   (@accessor gerbil-ascent/core/relation-view#relation-view::t lane #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-count
   (@accessor gerbil-ascent/core/relation-view#relation-view::t count #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-units
   (@accessor gerbil-ascent/core/relation-view#relation-view::t units #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-visit
   (@accessor gerbil-ascent/core/relation-view#relation-view::t visit #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-contains
   (@accessor gerbil-ascent/core/relation-view#relation-view::t contains #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-export
   (@accessor gerbil-ascent/core/relation-view#relation-view::t export #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-parts
   (@accessor gerbil-ascent/core/relation-view#relation-view::t parts #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-identity-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t identity #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-generation-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t generation #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-revision-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t revision #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-lane-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t lane #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-count-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t count #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-units-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t units #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-visit-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t visit #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-contains-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t contains #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-export-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t export #t))
  (declare-type
   gerbil-ascent/core/relation-view#relation-view-parts-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t parts #t))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-identity
   (@accessor gerbil-ascent/core/relation-view#relation-view::t identity #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-generation
   (@accessor gerbil-ascent/core/relation-view#relation-view::t generation #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-revision
   (@accessor gerbil-ascent/core/relation-view#relation-view::t revision #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-lane
   (@accessor gerbil-ascent/core/relation-view#relation-view::t lane #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-count
   (@accessor gerbil-ascent/core/relation-view#relation-view::t count #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-units
   (@accessor gerbil-ascent/core/relation-view#relation-view::t units #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-visit
   (@accessor gerbil-ascent/core/relation-view#relation-view::t visit #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-contains
   (@accessor gerbil-ascent/core/relation-view#relation-view::t contains #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-export
   (@accessor gerbil-ascent/core/relation-view#relation-view::t export #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-parts
   (@accessor gerbil-ascent/core/relation-view#relation-view::t parts #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-identity-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t identity #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-generation-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t generation #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-revision-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t revision #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-lane-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t lane #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-count-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t count #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-units-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t units #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-visit-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t visit #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-contains-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t contains #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-export-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t export #f))
  (declare-type
   gerbil-ascent/core/relation-view#&relation-view-parts-set!
   (@mutator gerbil-ascent/core/relation-view#relation-view::t parts #f))
  (declare-class
   gerbil-ascent/core/relation-view#part-visitors::t
   (@class gerbil-ascent/core/relation-view#part-visitors::t
           ()
           (object::t t::t)
           (checked admitted)
           (checked admitted)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/core/relation-view#part-visitors::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/core/relation-view#part-visitors::t)
    'class::t))
  (declare-type
   gerbil-ascent/core/relation-view#part-visitors?
   (@predicate gerbil-ascent/core/relation-view#part-visitors::t))
  (declare-type
   gerbil-ascent/core/relation-view#make-part-visitors
   (@constructor gerbil-ascent/core/relation-view#part-visitors::t))
  (declare-type
   gerbil-ascent/core/relation-view#part-visitors-checked
   (@accessor gerbil-ascent/core/relation-view#part-visitors::t checked #t))
  (declare-type
   gerbil-ascent/core/relation-view#part-visitors-admitted
   (@accessor gerbil-ascent/core/relation-view#part-visitors::t admitted #t))
  (declare-type
   gerbil-ascent/core/relation-view#part-visitors-checked-set!
   (@mutator gerbil-ascent/core/relation-view#part-visitors::t checked #t))
  (declare-type
   gerbil-ascent/core/relation-view#part-visitors-admitted-set!
   (@mutator gerbil-ascent/core/relation-view#part-visitors::t admitted #t))
  (declare-type
   gerbil-ascent/core/relation-view#&part-visitors-checked
   (@accessor gerbil-ascent/core/relation-view#part-visitors::t checked #f))
  (declare-type
   gerbil-ascent/core/relation-view#&part-visitors-admitted
   (@accessor gerbil-ascent/core/relation-view#part-visitors::t admitted #f))
  (declare-type
   gerbil-ascent/core/relation-view#&part-visitors-checked-set!
   (@mutator gerbil-ascent/core/relation-view#part-visitors::t checked #f))
  (declare-type
   gerbil-ascent/core/relation-view#&part-visitors-admitted-set!
   (@mutator gerbil-ascent/core/relation-view#part-visitors::t admitted #f))
  (declare-class
   gerbil-ascent/core/relation-view#row-stream::t
   (@class gerbil-ascent/core/relation-view#row-stream::t
           ()
           (object::t t::t)
           (view columns key)
           (view columns key)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/core/relation-view#row-stream::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/core/relation-view#row-stream::t)
    'class::t))
  (declare-type
   gerbil-ascent/core/relation-view#row-stream?
   (@predicate gerbil-ascent/core/relation-view#row-stream::t))
  (declare-type
   gerbil-ascent/core/relation-view#make-row-stream
   (@constructor gerbil-ascent/core/relation-view#row-stream::t))
  (declare-type
   gerbil-ascent/core/relation-view#row-stream-view
   (@accessor gerbil-ascent/core/relation-view#row-stream::t view #t))
  (declare-type
   gerbil-ascent/core/relation-view#row-stream-columns
   (@accessor gerbil-ascent/core/relation-view#row-stream::t columns #t))
  (declare-type
   gerbil-ascent/core/relation-view#row-stream-key
   (@accessor gerbil-ascent/core/relation-view#row-stream::t key #t))
  (declare-type
   gerbil-ascent/core/relation-view#row-stream-view-set!
   (@mutator gerbil-ascent/core/relation-view#row-stream::t view #t))
  (declare-type
   gerbil-ascent/core/relation-view#row-stream-columns-set!
   (@mutator gerbil-ascent/core/relation-view#row-stream::t columns #t))
  (declare-type
   gerbil-ascent/core/relation-view#row-stream-key-set!
   (@mutator gerbil-ascent/core/relation-view#row-stream::t key #t))
  (declare-type
   gerbil-ascent/core/relation-view#&row-stream-view
   (@accessor gerbil-ascent/core/relation-view#row-stream::t view #f))
  (declare-type
   gerbil-ascent/core/relation-view#&row-stream-columns
   (@accessor gerbil-ascent/core/relation-view#row-stream::t columns #f))
  (declare-type
   gerbil-ascent/core/relation-view#&row-stream-key
   (@accessor gerbil-ascent/core/relation-view#row-stream::t key #f))
  (declare-type
   gerbil-ascent/core/relation-view#&row-stream-view-set!
   (@mutator gerbil-ascent/core/relation-view#row-stream::t view #f))
  (declare-type
   gerbil-ascent/core/relation-view#&row-stream-columns-set!
   (@mutator gerbil-ascent/core/relation-view#row-stream::t columns #f))
  (declare-type
   gerbil-ascent/core/relation-view#&row-stream-key-set!
   (@mutator gerbil-ascent/core/relation-view#row-stream::t key #f))
  (declare-class
   gerbil-ascent/core/relation-view#rectangle::t
   (@class gerbil-ascent/core/relation-view#rectangle::t
           ()
           (object::t t::t)
           (prefix left right)
           (prefix left right)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/core/relation-view#rectangle::t)
    'class::t))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle?
   (@predicate gerbil-ascent/core/relation-view#rectangle::t))
  (declare-type
   gerbil-ascent/core/relation-view#make-rectangle
   (@constructor gerbil-ascent/core/relation-view#rectangle::t))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle-prefix
   (@accessor gerbil-ascent/core/relation-view#rectangle::t prefix #t))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle-left
   (@accessor gerbil-ascent/core/relation-view#rectangle::t left #t))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle-right
   (@accessor gerbil-ascent/core/relation-view#rectangle::t right #t))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle-prefix-set!
   (@mutator gerbil-ascent/core/relation-view#rectangle::t prefix #t))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle-left-set!
   (@mutator gerbil-ascent/core/relation-view#rectangle::t left #t))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle-right-set!
   (@mutator gerbil-ascent/core/relation-view#rectangle::t right #t))
  (declare-type
   gerbil-ascent/core/relation-view#&rectangle-prefix
   (@accessor gerbil-ascent/core/relation-view#rectangle::t prefix #f))
  (declare-type
   gerbil-ascent/core/relation-view#&rectangle-left
   (@accessor gerbil-ascent/core/relation-view#rectangle::t left #f))
  (declare-type
   gerbil-ascent/core/relation-view#&rectangle-right
   (@accessor gerbil-ascent/core/relation-view#rectangle::t right #f))
  (declare-type
   gerbil-ascent/core/relation-view#&rectangle-prefix-set!
   (@mutator gerbil-ascent/core/relation-view#rectangle::t prefix #f))
  (declare-type
   gerbil-ascent/core/relation-view#&rectangle-left-set!
   (@mutator gerbil-ascent/core/relation-view#rectangle::t left #f))
  (declare-type
   gerbil-ascent/core/relation-view#&rectangle-right-set!
   (@mutator gerbil-ascent/core/relation-view#rectangle::t right #f))
  (declare-class
   gerbil-ascent/core/relation-view#rectangle-bucket::t
   (@class gerbil-ascent/core/relation-view#rectangle-bucket::t
           ()
           (object::t t::t)
           (members blocks count plain)
           (members blocks count plain)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle-bucket::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/core/relation-view#rectangle-bucket::t)
    'class::t))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle-bucket?
   (@predicate gerbil-ascent/core/relation-view#rectangle-bucket::t))
  (declare-type
   gerbil-ascent/core/relation-view#make-rectangle-bucket
   (@constructor gerbil-ascent/core/relation-view#rectangle-bucket::t))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle-bucket-members
   (@accessor gerbil-ascent/core/relation-view#rectangle-bucket::t members #t))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle-bucket-blocks
   (@accessor gerbil-ascent/core/relation-view#rectangle-bucket::t blocks #t))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle-bucket-count
   (@accessor gerbil-ascent/core/relation-view#rectangle-bucket::t count #t))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle-bucket-plain
   (@accessor gerbil-ascent/core/relation-view#rectangle-bucket::t plain #t))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle-bucket-members-set!
   (@mutator gerbil-ascent/core/relation-view#rectangle-bucket::t members #t))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle-bucket-blocks-set!
   (@mutator gerbil-ascent/core/relation-view#rectangle-bucket::t blocks #t))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle-bucket-count-set!
   (@mutator gerbil-ascent/core/relation-view#rectangle-bucket::t count #t))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle-bucket-plain-set!
   (@mutator gerbil-ascent/core/relation-view#rectangle-bucket::t plain #t))
  (declare-type
   gerbil-ascent/core/relation-view#&rectangle-bucket-members
   (@accessor gerbil-ascent/core/relation-view#rectangle-bucket::t members #f))
  (declare-type
   gerbil-ascent/core/relation-view#&rectangle-bucket-blocks
   (@accessor gerbil-ascent/core/relation-view#rectangle-bucket::t blocks #f))
  (declare-type
   gerbil-ascent/core/relation-view#&rectangle-bucket-count
   (@accessor gerbil-ascent/core/relation-view#rectangle-bucket::t count #f))
  (declare-type
   gerbil-ascent/core/relation-view#&rectangle-bucket-plain
   (@accessor gerbil-ascent/core/relation-view#rectangle-bucket::t plain #f))
  (declare-type
   gerbil-ascent/core/relation-view#&rectangle-bucket-members-set!
   (@mutator gerbil-ascent/core/relation-view#rectangle-bucket::t members #f))
  (declare-type
   gerbil-ascent/core/relation-view#&rectangle-bucket-blocks-set!
   (@mutator gerbil-ascent/core/relation-view#rectangle-bucket::t blocks #f))
  (declare-type
   gerbil-ascent/core/relation-view#&rectangle-bucket-count-set!
   (@mutator gerbil-ascent/core/relation-view#rectangle-bucket::t count #f))
  (declare-type
   gerbil-ascent/core/relation-view#&rectangle-bucket-plain-set!
   (@mutator gerbil-ascent/core/relation-view#rectangle-bucket::t plain #f))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-view-bind
   (@lambda 5
            #f
            signature:
            (return:
             gerbil-ascent/core/relation-view#relation-view::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-view-with-export
   (@lambda 2
            #f
            signature:
            (return:
             gerbil-ascent/core/relation-view#relation-view::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-any-row?
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-row-count
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-view-select
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-row-parts?
   (@lambda 1
            #f
            signature:
            (return:
             (nullable true::t)
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-admitted-row-parts?
   (@lambda 1
            #f
            signature:
            (return:
             (nullable true::t)
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row-parts
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-visit-view-parts!
   (@lambda 4
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-visit-admitted-view-parts!
   (@lambda 4
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-view-contains?
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-view-rows
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#matches-key?
   (@lambda 3
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#ordered-key-offsets
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#matches-offset-key?
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#compile-explicit-key-match
   (@lambda 2
            #f
            signature:
            (return:
             procedure::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#matches-prefix?
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-explicit-view
   (@lambda 2
            #f
            signature:
            (return:
             gerbil-ascent/core/relation-view#relation-view::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-lazy-explicit-view
   (@lambda 2
            #f
            signature:
            (return:
             gerbil-ascent/core/relation-view#relation-view::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-view-union
   (@lambda 2
            #f
            signature:
            (return:
             gerbil-ascent/core/relation-view#relation-view::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-view-difference
   (@lambda 3
            #f
            signature:
            (return:
             gerbil-ascent/core/relation-view#relation-view::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#matches-coordinate?
   (@lambda 4
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#captured-member
   (@lambda 4
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#selected-members
   (@lambda 5
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#visit-right-members
   (@lambda 4
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#visit-left-members
   (@lambda 4
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#visit-rectangle-parts__%
   (@lambda 5
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#visit-rectangle-parts__0
   (@lambda 4
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#visit-rectangle-parts
   (@case-lambda
    (4
     gerbil-ascent/core/relation-view#visit-rectangle-parts__0
     signature:
     (return:
      t::t
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/core/relation-view))
    (5
     gerbil-ascent/core/relation-view#visit-rectangle-parts__%
     signature:
     (return:
      t::t
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/core/relation-view))))
  (declare-type
   gerbil-ascent/core/relation-view#visit-admitted-rectangle-parts
   (@lambda 5
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#visit-admitted-blocks
   (@lambda 5
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle-routing
   (@lambda 1
            #f
            signature:
            (return:
             vector::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#routed-rectangles
   (@lambda 4
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#rectangle-contains?
   (@lambda 3
            #f
            signature:
            (return:
             (nullable true::t)
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__%
   (@lambda 4
            #f
            signature:
            (return:
             gerbil-ascent/core/relation-view#relation-view::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__0
   (@lambda 3
            #f
            signature:
            (return:
             gerbil-ascent/core/relation-view#relation-view::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/relation-view)))
  (declare-type
   gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view
   (@case-lambda
    (3
     gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__0
     signature:
     (return:
      gerbil-ascent/core/relation-view#relation-view::t
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/core/relation-view))
    (4
     gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__%
     signature:
     (return:
      gerbil-ascent/core/relation-view#relation-view::t
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/core/relation-view)))))
