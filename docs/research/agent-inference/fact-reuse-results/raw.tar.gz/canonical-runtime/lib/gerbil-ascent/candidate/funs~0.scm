(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/funs::timestamp 1791691020)
  (begin
    (define gerbil-ascent/candidate/funs#candidate-same-row-set?
      (lambda (_%left27196%_ _%right27197%_)
        (if (= (length _%left27196%_) (length _%right27197%_))
            (let ((_%$e27199%_ (equal? _%left27196%_ _%right27197%_)))
              (if _%$e27199%_
                  _%$e27199%_
                  (let ((_%a27202%_
                         (let ()
                           (declare (not safe))
                           (make-hash-table__%
                            '#f
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value)))
                        (_%b27203%_
                         (let ()
                           (declare (not safe))
                           (make-hash-table__%
                            '#f
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value))))
                    (for-each
                     (lambda (_%row27205%_)
                       (let ()
                         (declare (not safe))
                         (__hash-put! _%a27202%_ _%row27205%_ '#t)))
                     _%left27196%_)
                    (for-each
                     (lambda (_%row27207%_)
                       (let ()
                         (declare (not safe))
                         (__hash-put! _%b27203%_ _%row27207%_ '#t)))
                     _%right27197%_)
                    (if (= (let ()
                             (declare (not safe))
                             (__hash-length _%a27202%_))
                           (let ()
                             (declare (not safe))
                             (__hash-length _%b27203%_)))
                        (let ((__tmp37324
                               (lambda (_%row27209%_)
                                 (if (let ()
                                       (declare (not safe))
                                       (__hash-get _%b27203%_ _%row27209%_))
                                     '#t
                                     '#f))))
                          (declare (not safe))
                          (andmap__0 __tmp37324 _%left27196%_))
                        '#f))))
            '#f)))
    (define gerbil-ascent/candidate/funs#candidate-schema-of
      (lambda (_%snapshot27191%_ _%spec27192%_)
        (append (map (lambda (_%entry27194%_)
                       (cons (car _%entry27194%_) (cadr _%entry27194%_)))
                     (##structure-ref
                      _%snapshot27191%_
                      '4
                      gerbil-ascent/candidate/types#reasoning-snapshot::t
                      '#f))
                (##structure-ref
                 _%spec27192%_
                 '1
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f))))
    (define gerbil-ascent/candidate/funs#candidate-required-entry
      (lambda (_%name27185%_ _%index27186%_)
        (let ((_%$e27188%_ (assq _%name27185%_ _%index27186%_)))
          (if _%$e27188%_
              _%$e27188%_
              (let ()
                (declare (not safe))
                (error '"candidate is missing inspected entry"
                       _%name27185%_))))))
    (define gerbil-ascent/candidate/funs#candidate-bind-atom
      (lambda (_%atom27167%_ _%row27168%_ _%prior27169%_)
        (let _%loop27171%_ ((_%terms27173%_ (cdr _%atom27167%_))
                            (_%values27174%_ _%row27168%_)
                            (_%bindings27175%_ _%prior27169%_))
          (if (null? _%terms27173%_)
              _%bindings27175%_
              (let ((_%term27177%_ (car _%terms27173%_))
                    (_%value27178%_ (car _%values27174%_)))
                (if (eq? _%term27177%_ '?_)
                    (_%loop27171%_
                     (cdr _%terms27173%_)
                     (cdr _%values27174%_)
                     _%bindings27175%_)
                    (if (let ()
                          (declare (not safe))
                          (gerbil-ascent/candidate/program#candidate-variable?
                           _%term27177%_))
                        (let ((_%old27182%_
                               (assq _%term27177%_ _%bindings27175%_)))
                          (if _%old27182%_
                              (if (equal? (cdr _%old27182%_) _%value27178%_)
                                  (_%loop27171%_
                                   (cdr _%terms27173%_)
                                   (cdr _%values27174%_)
                                   _%bindings27175%_)
                                  '#f)
                              (_%loop27171%_
                               (cdr _%terms27173%_)
                               (cdr _%values27174%_)
                               (cons (cons _%term27177%_ _%value27178%_)
                                     _%bindings27175%_))))
                        (if (equal? _%term27177%_ _%value27178%_)
                            (_%loop27171%_
                             (cdr _%terms27173%_)
                             (cdr _%values27174%_)
                             _%bindings27175%_)
                            '#f))))))))
    (define gerbil-ascent/candidate/funs#candidate-fixed-clause
      (lambda (_%clause27142%_ _%bindings27143%_)
        (let* ((_%mode27145%_ (car _%clause27142%_))
               (_%form27147%_
                (if (eq? _%mode27145%_ 'where)
                    (cadr _%clause27142%_)
                    (caddr _%clause27142%_)))
               (_%inputs27151%_
                (map (lambda (_%name27149%_)
                       (assq _%name27149%_ _%bindings27143%_))
                     (cdr _%form27147%_))))
          (if (let ((__tmp37325
                     (lambda (_%input27154%_) (and _%input27154%_ '#t))))
                (declare (not safe))
                (andmap__0 __tmp37325 _%inputs27151%_))
              (let* ((_%values27156%_
                      (let ()
                        (declare (not safe))
                        (##map cdr _%inputs27151%_)))
                     (_%$e27158%_ _%mode27145%_))
                (if (eq? 'where _%$e27158%_)
                    (let ((_%$e27161%_ (car _%form27147%_)))
                      (if (eq? 'even? _%$e27161%_)
                          (if (exact-integer? (car _%values27156%_))
                              (if (even? (car _%values27156%_))
                                  _%bindings27143%_
                                  '#f)
                              '#f)
                          (if (eq? '< _%$e27161%_)
                              (if (let ()
                                    (declare (not safe))
                                    (andmap__0 exact-integer? _%values27156%_))
                                  (if (< (car _%values27156%_)
                                         (cadr _%values27156%_))
                                      _%bindings27143%_
                                      '#f)
                                  '#f)
                              '#f)))
                    (if (eq? 'compute _%$e27158%_)
                        (if (assq (cadr _%clause27142%_) _%bindings27143%_)
                            '#f
                            (let ((_%$e27164%_ (car _%form27147%_)))
                              (if (eq? 'identity _%$e27164%_)
                                  (cons (cons (cadr _%clause27142%_)
                                              (car _%values27156%_))
                                        _%bindings27143%_)
                                  (if (eq? '+ _%$e27164%_)
                                      (if (let ()
                                            (declare (not safe))
                                            (andmap__0
                                             exact-integer?
                                             _%values27156%_))
                                          (cons (cons (cadr _%clause27142%_)
                                                      (+ (car _%values27156%_)
                                                         (cadr _%values27156%_)))
                                                _%bindings27143%_)
                                          '#f)
                                      '#f))))
                        '#f)))
              '#f))))
    (define gerbil-ascent/candidate/funs#candidate-strata-of
      (lambda (_%schema27105%_ _%rules27106%_)
        (let ((_%levels27110%_
               (map (lambda (_%entry27108%_) (cons (car _%entry27108%_) '0))
                    _%schema27105%_)))
          (let _%loop27112%_ ((_%round27114%_ '0))
            (let ((_%changed?27116%_ '#f))
              (for-each
               (lambda (_%rule27118%_)
                 (let ((_%head27120%_ (car (vector-ref _%rule27118%_ '0))))
                   (for-each
                    (lambda (_%clause27122%_)
                      (let ((_%dependency27130%_
                             (let ((_%$e27124%_ (car _%clause27122%_)))
                               (if (eq? 'not _%$e27124%_)
                                   (cons (caadr _%clause27122%_) '1)
                                   (if (eq? 'reduce _%$e27124%_)
                                       (cons (car (cadddr _%clause27122%_)) '1)
                                       (if (or (eq? 'where _%$e27124%_)
                                               (eq? 'compute _%$e27124%_))
                                           '#f
                                           (cons (car _%clause27122%_)
                                                 '0)))))))
                        (if _%dependency27130%_
                            (let* ((_%head-level27132%_
                                    (gerbil-ascent/candidate/funs#candidate-required-entry
                                     _%head27120%_
                                     _%levels27110%_))
                                   (_%dep-level27134%_
                                    (gerbil-ascent/candidate/funs#candidate-required-entry
                                     (let ()
                                       (declare (not safe))
                                       (##car _%dependency27130%_))
                                     _%levels27110%_))
                                   (_%required27136%_
                                    (+ (cdr _%dep-level27134%_)
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%dependency27130%_)))))
                              (if (< (cdr _%head-level27132%_)
                                     _%required27136%_)
                                  (begin
                                    (set-cdr!
                                     _%head-level27132%_
                                     _%required27136%_)
                                    (set! _%changed?27116%_ '#t))
                                  '#!void))
                            '#!void)))
                    (vector-ref _%rule27118%_ '1))))
               _%rules27106%_)
              (if _%changed?27116%_
                  (if (>= _%round27114%_ (length _%schema27105%_))
                      '#f
                      (_%loop27112%_ (+ _%round27114%_ '1)))
                  _%levels27110%_))))))))
