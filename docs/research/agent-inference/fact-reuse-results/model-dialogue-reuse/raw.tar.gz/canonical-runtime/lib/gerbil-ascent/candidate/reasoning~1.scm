(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/reasoning[1]#_g34333_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34335_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-receipt
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34337_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34339_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34340_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34341_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34342_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34343_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34344_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34345_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34346_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-diagnostics
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34347_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34348_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34349_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-nonmembership
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34350_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-stratified
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34352_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34353_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34354_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34355_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34356_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34357_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34358_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34359_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-diagnostics-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34360_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34361_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34362_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-nonmembership-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34363_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-stratified-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34365_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34366_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34367_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34368_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34369_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34370_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34371_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34372_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-diagnostics
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34373_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34374_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34375_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-nonmembership
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34376_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-stratified
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34378_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34379_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34380_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34381_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34382_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34383_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34384_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34385_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-diagnostics-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34386_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34387_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34388_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-nonmembership-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34389_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-stratified-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34391_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34393_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34395_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34397_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34398_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-support
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34399_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-reachable
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34401_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34402_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-support-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34403_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-reachable-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34405_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34406_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-support
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34407_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-reachable
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34409_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34410_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-support-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34411_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-reachable-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34413_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34415_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-stratified-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34417_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34419_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34420_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-finite
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34421_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34422_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34424_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34425_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-finite-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34426_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34427_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34429_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34430_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-finite
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34431_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34432_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34434_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34435_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-finite-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34436_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34437_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34439_|
    (##structure
     gx#syntax-quote::t
     'captured-stage::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34441_|
    (##structure
     gx#syntax-quote::t
     'make-captured-stage
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34443_|
    (##structure
     gx#syntax-quote::t
     'captured-stage?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34445_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-ok?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34446_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34448_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-ok?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34449_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34451_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-ok?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34452_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34454_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-ok?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34455_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34457_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34459_|
    (##structure
     gx#syntax-quote::t
     'make-attempt-observation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34461_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34463_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34464_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34466_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34467_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34469_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34470_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34472_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g34473_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/reasoning[:0:]#reasoning-receipt|
      (let ((__obj34251
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34251
           'gerbil-ascent/candidate/reasoning#reasoning-receipt::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34251
           'reasoning-receipt
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34251
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    rows
                    diagnostics
                    evidence
                    proof
                    nonmembership
                    stratified)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34251
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    rows
                    diagnostics
                    evidence
                    proof
                    nonmembership
                    stratified)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34251 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34251 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34251 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34251 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34251 '#f '13 '#f '#f))
        (let ((__tmp34332 |gerbil-ascent/candidate/reasoning[1]#_g34333_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34251 __tmp34332 '4 '#f '#f))
        (let ((__tmp34334 |gerbil-ascent/candidate/reasoning[1]#_g34335_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34251 __tmp34334 '14 '#f '#f))
        (let ((__tmp34336 |gerbil-ascent/candidate/reasoning[1]#_g34337_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34251 __tmp34336 '15 '#f '#f))
        (let ((__tmp34338
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g34339_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g34340_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g34341_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g34342_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g34343_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g34344_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g34345_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g34346_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g34347_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g34348_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g34349_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g34350_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj34251 __tmp34338 '16 '#f '#f))
        (let ((__tmp34351
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g34352_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g34353_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g34354_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g34355_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g34356_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g34357_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g34358_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g34359_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g34360_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g34361_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g34362_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g34363_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj34251 __tmp34351 '17 '#f '#f))
        (let ((__tmp34364
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g34365_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g34366_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g34367_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g34368_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g34369_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g34370_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g34371_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g34372_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g34373_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g34374_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g34375_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g34376_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj34251 __tmp34364 '18 '#f '#f))
        (let ((__tmp34377
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g34378_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g34379_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g34380_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g34381_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g34382_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g34383_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g34384_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g34385_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g34386_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g34387_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g34388_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g34389_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj34251 __tmp34377 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34251 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34251 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34251 '() '21 '#f '#f))
        __obj34251))
    (define |gerbil-ascent/candidate/reasoning[:0:]#reasoning-evidence|
      (let ((__obj34252
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34252
           'gerbil-ascent/candidate/reasoning#reasoning-evidence::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34252
           'reasoning-evidence
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34252
           '(kind support reachable)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34252
           '(kind support reachable)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34252 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34252 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34252 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34252 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34252 '#f '13 '#f '#f))
        (let ((__tmp34390 |gerbil-ascent/candidate/reasoning[1]#_g34391_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34252 __tmp34390 '4 '#f '#f))
        (let ((__tmp34392 |gerbil-ascent/candidate/reasoning[1]#_g34393_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34252 __tmp34392 '14 '#f '#f))
        (let ((__tmp34394 |gerbil-ascent/candidate/reasoning[1]#_g34395_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34252 __tmp34394 '15 '#f '#f))
        (let ((__tmp34396
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g34397_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g34398_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g34399_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34252 __tmp34396 '16 '#f '#f))
        (let ((__tmp34400
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g34401_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g34402_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g34403_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34252 __tmp34400 '17 '#f '#f))
        (let ((__tmp34404
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g34405_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g34406_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g34407_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34252 __tmp34404 '18 '#f '#f))
        (let ((__tmp34408
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g34409_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g34410_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g34411_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34252 __tmp34408 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34252 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34252 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34252 '() '21 '#f '#f))
        __obj34252))
    (define |gerbil-ascent/candidate/reasoning[:0:]#reasoning-stratified-evidence|
      (let ((__obj34253
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34253
           'gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34253
           'reasoning-stratified-evidence
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34253
           '(status finite proof work-budget)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34253
           '(status finite proof work-budget)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34253 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34253 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34253 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34253 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34253 '#f '13 '#f '#f))
        (let ((__tmp34412 |gerbil-ascent/candidate/reasoning[1]#_g34413_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34253 __tmp34412 '4 '#f '#f))
        (let ((__tmp34414 |gerbil-ascent/candidate/reasoning[1]#_g34415_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34253 __tmp34414 '14 '#f '#f))
        (let ((__tmp34416 |gerbil-ascent/candidate/reasoning[1]#_g34417_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34253 __tmp34416 '15 '#f '#f))
        (let ((__tmp34418
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g34419_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g34420_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g34421_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g34422_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34253 __tmp34418 '16 '#f '#f))
        (let ((__tmp34423
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g34424_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g34425_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g34426_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g34427_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34253 __tmp34423 '17 '#f '#f))
        (let ((__tmp34428
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g34429_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g34430_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g34431_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g34432_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34253 __tmp34428 '18 '#f '#f))
        (let ((__tmp34433
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g34434_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g34435_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g34436_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g34437_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34253 __tmp34433 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34253 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34253 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34253 '() '21 '#f '#f))
        __obj34253))
    (define |gerbil-ascent/candidate/reasoning[:0:]#captured-stage|
      (let ((__obj34254
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34254
           'gerbil-ascent/candidate/reasoning#captured-stage::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 'captured-stage '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 '(ok? value) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 '(ok? value) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 '#f '13 '#f '#f))
        (let ((__tmp34438 |gerbil-ascent/candidate/reasoning[1]#_g34439_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 __tmp34438 '4 '#f '#f))
        (let ((__tmp34440 |gerbil-ascent/candidate/reasoning[1]#_g34441_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 __tmp34440 '14 '#f '#f))
        (let ((__tmp34442 |gerbil-ascent/candidate/reasoning[1]#_g34443_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 __tmp34442 '15 '#f '#f))
        (let ((__tmp34444
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g34445_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g34446_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 __tmp34444 '16 '#f '#f))
        (let ((__tmp34447
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g34448_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g34449_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 __tmp34447 '17 '#f '#f))
        (let ((__tmp34450
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g34451_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g34452_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 __tmp34450 '18 '#f '#f))
        (let ((__tmp34453
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g34454_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g34455_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 __tmp34453 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 '() '21 '#f '#f))
        __obj34254))
    (define |gerbil-ascent/candidate/reasoning[:0:]#attempt-observation|
      (let ((__obj34255
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34255
           'gerbil-ascent/candidate/reasoning#attempt-observation::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34255
           'attempt-observation
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '(rows evidence) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '(rows evidence) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '#f '13 '#f '#f))
        (let ((__tmp34456 |gerbil-ascent/candidate/reasoning[1]#_g34457_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 __tmp34456 '4 '#f '#f))
        (let ((__tmp34458 |gerbil-ascent/candidate/reasoning[1]#_g34459_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 __tmp34458 '14 '#f '#f))
        (let ((__tmp34460 |gerbil-ascent/candidate/reasoning[1]#_g34461_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 __tmp34460 '15 '#f '#f))
        (let ((__tmp34462
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g34463_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g34464_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 __tmp34462 '16 '#f '#f))
        (let ((__tmp34465
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g34466_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g34467_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 __tmp34465 '17 '#f '#f))
        (let ((__tmp34468
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g34469_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g34470_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 __tmp34468 '18 '#f '#f))
        (let ((__tmp34471
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g34472_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g34473_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 __tmp34471 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '() '21 '#f '#f))
        __obj34255))))
