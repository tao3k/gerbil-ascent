(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/core/positive-plan[:0:]#match-value!|
    (lambda (_%$stx8445%_)
      (let* ((_%$%g84498471%_
              (lambda (_%$%g84508467%_)
                (let ()
                  (declare (not safe))
                  (gx#raise-syntax-error
                   '#f
                   '"Bad syntax; invalid match target"
                   _%$%g84508467%_))))
             (_%$%g84488541%_
              (lambda (_%$%g84508475%_)
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair? _%$%g84508475%_))
                    (let ((_%$%e84548478%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%$%g84508475%_))))
                      (let ((_%$%hd84558482%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e84548478%_)))
                            (_%$%tl84568485%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e84548478%_))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair? _%$%tl84568485%_))
                            (let ((_%$%e84578488%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-e _%$%tl84568485%_))))
                              (let ((_%$%hd84588492%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e84578488%_)))
                                    (_%$%tl84598495%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e84578488%_))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%tl84598495%_))
                                    (let ((_%$%e84608498%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e _%$%tl84598495%_))))
                                      (let ((_%$%hd84618502%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e84608498%_)))
                                            (_%$%tl84628505%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e84608498%_))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair? _%$%tl84628505%_))
                                            (let ((_%$%e84638508%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl84628505%_))))
                                              (let ((_%$%hd84648512%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e84638508%_)))
                                                    (_%$%tl84658515%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e84638508%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl84658515%_))
                                                    (cons (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#datum->syntax__0
                                                             '#f
                                                             'let))
                                                          (cons (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                      (declare (not safe))
                                      (gx#datum->syntax__0 '#f 'selected))
                                    (cons _%$%hd84588492%_ '()))
                              (cons (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0 '#f 'stored))
                                          (cons _%$%hd84618502%_ '()))
                                    (cons (cons (let ()
                                                  (declare (not safe))
                                                  (gx#datum->syntax__0
                                                   '#f
                                                   'bindings))
                                                (cons _%$%hd84648512%_ '()))
                                          '())))
                        (cons (cons (let ()
                                      (declare (not safe))
                                      (gx#datum->syntax__0 '#f 'case))
                                    (cons (cons (let ()
                                                  (declare (not safe))
                                                  (gx#datum->syntax__0
                                                   '#f
                                                   'car))
                                                (cons (let ()
                                                        (declare (not safe))
                                                        (gx#datum->syntax__0
                                                         '#f
                                                         'selected))
                                                      '()))
                                          (cons (cons (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'fresh))
                                                            '())
                                                      (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (declare (not safe))
                            (gx#datum->syntax__0 '#f 'vector-set!))
                          (cons (let ()
                                  (declare (not safe))
                                  (gx#datum->syntax__0 '#f 'bindings))
                                (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0 '#f 'cdr))
                                            (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'selected))
                                                  '()))
                                      (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'stored))
                                            '()))))
                    (cons '#t '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (cons (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (declare (not safe))
                            (gx#datum->syntax__0 '#f 'bound))
                          '())
                    (cons (cons (let ()
                                  (declare (not safe))
                                  (gx#datum->syntax__0 '#f 'equal?))
                                (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'vector-ref))
                                            (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'bindings))
                                                  (cons (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'cdr))
                      (cons (let ()
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'selected))
                            '()))
                '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                      (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'stored))
                                            '())))
                          '()))
              (cons (cons (cons (let ()
                                  (declare (not safe))
                                  (gx#datum->syntax__0 '#f 'literal))
                                '())
                          (cons (cons (let ()
                                        (declare (not safe))
                                        (gx#datum->syntax__0 '#f 'equal?))
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'cdr))
                                                  (cons (let ()
                                                          (declare (not safe))
                                                          (gx#datum->syntax__0
                                                           '#f
                                                           'selected))
                                                        '()))
                                            (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'stored))
                                                  '())))
                                '()))
                    (cons (cons (cons (let ()
                                        (declare (not safe))
                                        (gx#datum->syntax__0 '#f 'expression))
                                      '())
                                (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'equal?))
                                            (cons (cons (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'cdr))
                      (cons (let ()
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'selected))
                            '()))
                (cons (let ()
                        (declare (not safe))
                        (gx#datum->syntax__0 '#f 'bindings))
                      '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons (let ()
                                                          (declare (not safe))
                                                          (gx#datum->syntax__0
                                                           '#f
                                                           'stored))
                                                        '())))
                                      '()))
                          (cons (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'wildcard))
                                            '())
                                      (cons '#t '()))
                                '())))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                              '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%g84498471%_
                                                     _%$%g84508475%_))))
                                            (_%$%g84498471%_
                                             _%$%g84508475%_))))
                                    (_%$%g84498471%_ _%$%g84508475%_))))
                            (_%$%g84498471%_ _%$%g84508475%_))))
                    (_%$%g84498471%_ _%$%g84508475%_)))))
        (_%$%g84488541%_ _%$stx8445%_))))
  (define |gerbil-ascent/core/positive-plan[:0:]#parts-matcher|
    (lambda (_%$stx8545%_)
      (let* ((_%$%g85498590%_
              (lambda (_%$%g85508586%_)
                (let ()
                  (declare (not safe))
                  (gx#raise-syntax-error
                   '#f
                   '"Bad syntax; invalid match target"
                   _%$%g85508586%_))))
             (_%$%g85488727%_
              (lambda (_%$%g85508594%_)
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair? _%$%g85508594%_))
                    (let ((_%$%e85588597%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%$%g85508594%_))))
                      (let ((_%$%hd85598601%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e85588597%_)))
                            (_%$%tl85608604%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e85588597%_))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair? _%$%tl85608604%_))
                            (let ((_%$%e85618607%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-e _%$%tl85608604%_))))
                              (let ((_%$%hd85628611%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e85618607%_)))
                                    (_%$%tl85638614%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e85618607%_))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%tl85638614%_))
                                    (let ((_%$%e85648617%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e _%$%tl85638614%_))))
                                      (let ((_%$%hd85658621%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e85648617%_)))
                                            (_%$%tl85668624%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e85648617%_))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair? _%$%hd85658621%_))
                                            (let ((_%$%e85678627%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%hd85658621%_))))
                                              (let ((_%$%hd85688631%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e85678627%_)))
                                                    (_%$%tl85698634%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e85678627%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair?
                                                       _%$%tl85698634%_))
                                                    (let ((_%$%e85708637%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-e
                                                              _%$%tl85698634%_))))
                                                      (let ((_%$%hd85718641%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##car _%$%e85708637%_)))
                    (_%$%tl85728644%_
                     (let () (declare (not safe)) (##cdr _%$%e85708637%_))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair? _%$%tl85728644%_))
                    (let ((_%$%e85738647%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%$%tl85728644%_))))
                      (let ((_%$%hd85748651%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e85738647%_)))
                            (_%$%tl85758654%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e85738647%_))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair? _%$%tl85758654%_))
                            (let ((_%$%e85768657%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-e _%$%tl85758654%_))))
                              (let ((_%$%hd85778661%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e85768657%_)))
                                    (_%$%tl85788664%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e85768657%_))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl85788664%_))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%tl85668624%_))
                                        (let ((_%$%e85798667%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%tl85668624%_))))
                                          (let ((_%$%hd85808671%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e85798667%_)))
                                                (_%$%tl85818674%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e85798667%_))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair?
                                                   _%$%tl85818674%_))
                                                (let ((_%$%e85828677%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-e
                                                          _%$%tl85818674%_))))
                                                  (let ((_%$%hd85838681%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e85828677%_)))
                                                        (_%$%tl85848684%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e85828677%_))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl85848684%_))
                                                        (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'lambda))
                      (cons (cons _%$%hd85688631%_
                                  (cons _%$%hd85718641%_
                                        (cons _%$%hd85748651%_
                                              (cons _%$%hd85778661%_ '()))))
                            (cons (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'if))
                                        (cons _%$%hd85808671%_
                                              (cons _%$%hd85838681%_
                                                    (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'match-parts!))
                        (cons _%$%hd85628611%_
                              (cons _%$%hd85688631%_
                                    (cons _%$%hd85718641%_
                                          (cons _%$%hd85748651%_
                                                (cons _%$%hd85778661%_
                                                      '()))))))
                  '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                  '())))
                (_%$%g85498590%_ _%$%g85508594%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (_%$%g85498590%_
                                                 _%$%g85508594%_))))
                                        (_%$%g85498590%_ _%$%g85508594%_))
                                    (_%$%g85498590%_ _%$%g85508594%_))))
                            (_%$%g85498590%_ _%$%g85508594%_))))
                    (_%$%g85498590%_ _%$%g85508594%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%g85498590%_
                                                     _%$%g85508594%_))))
                                            (_%$%g85498590%_
                                             _%$%g85508594%_))))
                                    (_%$%g85498590%_ _%$%g85508594%_))))
                            (_%$%g85498590%_ _%$%g85508594%_))))
                    (_%$%g85498590%_ _%$%g85508594%_)))))
        (_%$%g85488727%_ _%$stx8545%_)))))
