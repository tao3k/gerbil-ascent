(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil/runtime/mop::timestamp 1791538538)
  (begin
    (define type-flag-opaque '1)
    (define type-flag-extensible '2)
    (define type-flag-macros '4)
    (define type-flag-concrete '8)
    (define type-flag-id '16)
    (define class-type-flag-struct '1024)
    (define class-type-flag-sealed '2048)
    (define class-type-flag-metaclass '4096)
    (define class-type-flag-system '8192)
    (define class-type-flag-acyclic '16384)
    (define t::t
      (let ((_%flags145765%_
             (let ()
               (declare (not safe))
               (##fxior type-flag-extensible
                        type-flag-id
                        class-type-flag-system)))
            (_%properties145766%_ '((direct-slots:) (system: . #t)))
            (_%slot-table145767%_
             (let () (declare (not safe)) (make-symbolic-table__% '#f '0))))
        (let ()
          (declare (not safe))
          (##structure
           '#f
           't
           't
           _%flags145765%_
           '#f
           '#()
           '()
           '#(#f)
           _%slot-table145767%_
           _%properties145766%_
           '#f
           '#f
           '#f
           '#f))))
    (define class::t
      (let* ((_%slots145722%_
              '(id name
                   flags
                   super
                   fields
                   precedence-list
                   slot-vector
                   slot-table
                   properties
                   constructor
                   methods
                   specializer
                   interface))
             (_%slot-vector145724%_ (list->vector (cons '#f _%slots145722%_)))
             (_%slot-table145750%_
              (let ((_%slot-table145726%_
                     (let ()
                       (declare (not safe))
                       (make-symbolic-table__% '#f '0))))
                (let ((__tmp148723
                       (lambda (_%slot145728%_ _%field145729%_)
                         (let ()
                           (declare (not safe))
                           (symbolic-table-set!
                            _%slot-table145726%_
                            _%slot145728%_
                            _%field145729%_))
                         (let ((__tmp148724
                                (let ((_%sym145731%_ _%slot145728%_))
                                  (if (symbol? _%sym145731%_)
                                      (let ((_%sym145736%_ _%sym145731%_))
                                        (declare (not safe))
                                        (__symbol->keyword _%sym145736%_))
                                      (begin
                                        (raise-contract-violation-error
                                         '"contract violation"
                                         'context:
                                         'gerbil/runtime/mop
                                         'contract:
                                         'symbol?
                                         'value:
                                         _%sym145731%_)
                                        '#!void)))))
                           (declare (not safe))
                           (symbolic-table-set!
                            _%slot-table145726%_
                            __tmp148724
                            _%field145729%_))))
                      (__tmp148721
                       (let ((__tmp148722
                              (let ()
                                (declare (not safe))
                                (##length _%slots145722%_))))
                         (declare (not safe))
                         (##iota __tmp148722 '1))))
                  (declare (not safe))
                  (##for-each __tmp148723 _%slots145722%_ __tmp148721))
                _%slot-table145726%_))
             (_%flags145752%_
              (let ()
                (declare (not safe))
                (##fxior type-flag-extensible
                         type-flag-concrete
                         type-flag-id
                         class-type-flag-struct)))
             (_%fields145758%_
              (list->vector
               (let ((__tmp148725
                      (map (lambda (_%$%g145753145755%_)
                             (list _%$%g145753145755%_ '5 '#f))
                           (drop _%slots145722%_ '5))))
                 (declare (not safe))
                 (##apply append __tmp148725))))
             (_%properties145760%_
              (cons (cons 'direct-slots: _%slots145722%_) '((struct: . #t))))
             (_%t145762%_
              (let ((__tmp148726 (cons t::t '())))
                (declare (not safe))
                (##structure
                 '#f
                 'class
                 'class
                 _%flags145752%_
                 ##type-type
                 _%fields145758%_
                 __tmp148726
                 _%slot-vector145724%_
                 _%slot-table145750%_
                 _%properties145760%_
                 '#f
                 '#f
                 '#f
                 '#f))))
        (let ()
          (declare (not safe))
          (##structure-type-set! _%t145762%_ _%t145762%_))
        _%t145762%_))
    (let () (declare (not safe)) (##structure-type-set! t::t class::t))
    (define object::t
      (let ((_%flags145718%_
             (let ()
               (declare (not safe))
               (##fxior type-flag-extensible
                        type-flag-id
                        class-type-flag-system)))
            (_%properties145719%_ '((direct-slots:) (system: . #t)))
            (_%slot-table145720%_
             (let () (declare (not safe)) (make-symbolic-table__% '#f '0))))
        (let ((__tmp148727 (cons t::t '())))
          (declare (not safe))
          (##structure
           class::t
           'object
           'object
           _%flags145718%_
           '#f
           '#()
           __tmp148727
           '#(#f)
           _%slot-table145720%_
           _%properties145719%_
           '#f
           '#f
           '#f
           '#f))))
    (define __class-type
      (lambda (_%klass145706%_)
        (let ((_%klass145709%_ _%klass145706%_))
          (declare (not safe))
          (##structure-type _%klass145709%_))))
    (define class-type
      (lambda (_%klass145692%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass145692%_ 'class))
            (let ((_%klass145696%_ _%klass145692%_))
              (__class-type _%klass145696%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@166.19-166.24"
               'contract:
               'class-type?
               'value:
               _%klass145692%_)
              '#!void))))
    (define class-type?
      (lambda (_%obj145690%_)
        (let ()
          (declare (not safe))
          (##structure-instance-of? _%obj145690%_ 'class))))
    (define __class-type=?
      (lambda (_%x145669%_ _%y145670%_)
        (let* ((_%x145673%_ _%x145669%_) (_%y145681%_ _%y145670%_))
          (eq? (let ()
                 (declare (not safe))
                 (##unchecked-structure-ref _%x145673%_ '1 '#f '#f))
               (let ()
                 (declare (not safe))
                 (##unchecked-structure-ref _%y145681%_ '1 '#f '#f))))))
    (define class-type=?
      (lambda (_%x145644%_ _%y145645%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%x145644%_ 'class))
            (let ((_%x145649%_ _%x145644%_))
              (if (let ()
                    (declare (not safe))
                    (##structure-instance-of? _%y145645%_ 'class))
                  (let ((_%y145659%_ _%y145645%_))
                    (__class-type=? _%x145649%_ _%y145659%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@175.34-175.35"
                     'contract:
                     'class-type?
                     'value:
                     _%y145645%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@175.21-175.22"
               'contract:
               'class-type?
               'value:
               _%x145644%_)
              '#!void))))
    (define __type-opaque?
      (lambda (_%type145632%_)
        (let* ((_%type145635%_ _%type145632%_)
               (__tmp148728
                (let ((__tmp148729
                       (let ()
                         (declare (not safe))
                         (##type-flags _%type145635%_))))
                  (declare (not safe))
                  (##fxand __tmp148729 type-flag-opaque))))
          (declare (not safe))
          (##fx= __tmp148728 type-flag-opaque))))
    (define type-opaque?
      (lambda (_%type145618%_)
        (if (let () (declare (not safe)) (##type? _%type145618%_))
            (let ((_%type145622%_ _%type145618%_))
              (__type-opaque? _%type145622%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@189.21-189.25"
               'contract:
               '##type?
               'value:
               _%type145618%_)
              '#!void))))
    (define __class-type-opaque?
      (lambda (_%klass145606%_)
        (let* ((_%klass145609%_ _%klass145606%_)
               (__tmp148730
                (let ((__tmp148731
                       (let ()
                         (declare (not safe))
                         (##type-flags _%klass145609%_))))
                  (declare (not safe))
                  (##fxand __tmp148731 type-flag-opaque))))
          (declare (not safe))
          (##fx= __tmp148730 type-flag-opaque))))
    (define class-type-opaque?
      (lambda (_%klass145592%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass145592%_ 'class))
            (let ((_%klass145596%_ _%klass145592%_))
              (__class-type-opaque? _%klass145596%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@191.27-191.32"
               'contract:
               'class-type?
               'value:
               _%klass145592%_)
              '#!void))))
    (define __type-extensible?
      (lambda (_%type145580%_)
        (let* ((_%type145583%_ _%type145580%_)
               (__tmp148732
                (let ((__tmp148733
                       (let ()
                         (declare (not safe))
                         (##type-flags _%type145583%_))))
                  (declare (not safe))
                  (##fxand __tmp148733 type-flag-extensible))))
          (declare (not safe))
          (##fx= __tmp148732 type-flag-extensible))))
    (define type-extensible?
      (lambda (_%type145566%_)
        (if (let () (declare (not safe)) (##type? _%type145566%_))
            (let ((_%type145570%_ _%type145566%_))
              (__type-extensible? _%type145570%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@193.25-193.29"
               'contract:
               '##type?
               'value:
               _%type145566%_)
              '#!void))))
    (define __class-type-final?
      (lambda (_%type145554%_)
        (let* ((_%type145557%_ _%type145554%_)
               (__tmp148734
                (let ((__tmp148735
                       (let ()
                         (declare (not safe))
                         (##type-flags _%type145557%_))))
                  (declare (not safe))
                  (##fxand __tmp148735 type-flag-extensible))))
          (declare (not safe))
          (##fx= __tmp148734 '0))))
    (define class-type-final?
      (lambda (_%type145540%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%type145540%_ 'class))
            (let ((_%type145544%_ _%type145540%_))
              (__class-type-final? _%type145544%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@195.26-195.30"
               'contract:
               'class-type?
               'value:
               _%type145540%_)
              '#!void))))
    (define __class-type-struct?
      (lambda (_%klass145528%_)
        (let* ((_%klass145531%_ _%klass145528%_)
               (__tmp148736
                (let ((__tmp148737
                       (let ()
                         (declare (not safe))
                         (##type-flags _%klass145531%_))))
                  (declare (not safe))
                  (##fxand __tmp148737 class-type-flag-struct))))
          (declare (not safe))
          (##fx= __tmp148736 class-type-flag-struct))))
    (define class-type-struct?
      (lambda (_%klass145514%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass145514%_ 'class))
            (let ((_%klass145518%_ _%klass145514%_))
              (__class-type-struct? _%klass145518%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@197.27-197.32"
               'contract:
               'class-type?
               'value:
               _%klass145514%_)
              '#!void))))
    (define __class-type-sealed?
      (lambda (_%klass145502%_)
        (let* ((_%klass145505%_ _%klass145502%_)
               (__tmp148738
                (let ((__tmp148739
                       (let ()
                         (declare (not safe))
                         (##type-flags _%klass145505%_))))
                  (declare (not safe))
                  (##fxand __tmp148739 class-type-flag-sealed))))
          (declare (not safe))
          (##fx= __tmp148738 class-type-flag-sealed))))
    (define class-type-sealed?
      (lambda (_%klass145488%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass145488%_ 'class))
            (let ((_%klass145492%_ _%klass145488%_))
              (__class-type-sealed? _%klass145492%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@199.27-199.32"
               'contract:
               'class-type?
               'value:
               _%klass145488%_)
              '#!void))))
    (define __class-type-metaclass?
      (lambda (_%klass145476%_)
        (let* ((_%klass145479%_ _%klass145476%_)
               (__tmp148740
                (let ((__tmp148741
                       (let ()
                         (declare (not safe))
                         (##type-flags _%klass145479%_))))
                  (declare (not safe))
                  (##fxand __tmp148741 class-type-flag-metaclass))))
          (declare (not safe))
          (##fx= __tmp148740 class-type-flag-metaclass))))
    (define class-type-metaclass?
      (lambda (_%klass145462%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass145462%_ 'class))
            (let ((_%klass145466%_ _%klass145462%_))
              (__class-type-metaclass? _%klass145466%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@201.30-201.35"
               'contract:
               'class-type?
               'value:
               _%klass145462%_)
              '#!void))))
    (define __class-type-system?
      (lambda (_%klass145450%_)
        (let* ((_%klass145453%_ _%klass145450%_)
               (__tmp148742
                (let ((__tmp148743
                       (let ()
                         (declare (not safe))
                         (##type-flags _%klass145453%_))))
                  (declare (not safe))
                  (##fxand __tmp148743 class-type-flag-system))))
          (declare (not safe))
          (##fx= __tmp148742 class-type-flag-system))))
    (define class-type-system?
      (lambda (_%klass145436%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass145436%_ 'class))
            (let ((_%klass145440%_ _%klass145436%_))
              (__class-type-system? _%klass145440%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@203.27-203.32"
               'contract:
               'class-type?
               'value:
               _%klass145436%_)
              '#!void))))
    (define __class-type-acyclic?
      (lambda (_%klass145424%_)
        (let* ((_%klass145427%_ _%klass145424%_)
               (__tmp148744
                (let ((__tmp148745
                       (let ()
                         (declare (not safe))
                         (##type-flags _%klass145427%_))))
                  (declare (not safe))
                  (##fxand __tmp148745 class-type-flag-acyclic))))
          (declare (not safe))
          (##fx= __tmp148744 class-type-flag-acyclic))))
    (define class-type-acyclic?
      (lambda (_%klass145410%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass145410%_ 'class))
            (let ((_%klass145414%_ _%klass145410%_))
              (__class-type-acyclic? _%klass145414%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@205.28-205.33"
               'contract:
               'class-type?
               'value:
               _%klass145410%_)
              '#!void))))
    (define make-class-type-descriptor
      (lambda (_%type-id145176%_
               _%type-name145177%_
               _%type-super145178%_
               _%precedence-list145179%_
               _%slot-vector145180%_
               _%properties145181%_
               _%constructor145182%_
               _%slot-table145183%_
               _%methods145184%_)
        (letrec ((_%make-props!145187%_
                  (lambda (_%key145355%_ _%transparent?145356%_)
                    (letrec* ((_%ht145358%_
                               (let ()
                                 (declare (not safe))
                                 (make-symbolic-table__% '#f '0)))
                              (_%put-slots!145359%_
                               (lambda (_%ht145403%_ _%slots145404%_)
                                 (for-each
                                  (lambda (_%$%g145405145407%_)
                                    (let ()
                                      (declare (not safe))
                                      (symbolic-table-set!
                                       _%ht145403%_
                                       _%$%g145405145407%_
                                       '#t)))
                                  _%slots145404%_)))
                              (_%put-all-new-slots!145360%_
                               (lambda (_%ht145395%_)
                                 (let ((_%first145397%_
                                        (if (let ()
                                              (declare (not safe))
                                              (##structure-instance-of?
                                               _%type-super145178%_
                                               'class))
                                            (let ((__tmp148746
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%type-super145178%_
                                                      '7
                                                      '#f
                                                      '#f))))
                                              (declare (not safe))
                                              (##vector-length __tmp148746))
                                            '1)))
                                   (let _%lp145399%_ ((_%i145401%_
                                                       _%first145397%_))
                                     (if (let ((__tmp148747
                                                (let ()
                                                  (declare (not safe))
                                                  (##vector-length
                                                   _%slot-vector145180%_))))
                                           (declare (not safe))
                                           (##fx< _%i145401%_ __tmp148747))
                                         (begin
                                           (let ((__tmp148748
                                                  (let ()
                                                    (declare (not safe))
                                                    (##vector-ref
                                                     _%slot-vector145180%_
                                                     _%i145401%_))))
                                             (declare (not safe))
                                             (symbolic-table-set!
                                              _%ht145395%_
                                              __tmp148748
                                              '#t))
                                           (_%lp145399%_
                                            (let ()
                                              (declare (not safe))
                                              (##fx+ _%i145401%_ '1))))
                                         '#!void)))))
                              (_%put-alist!145361%_
                               (lambda (_%ht145386%_
                                        _%key145387%_
                                        _%alist145388%_)
                                 (let ((_%$e145390%_
                                        (let ()
                                          (declare (not safe))
                                          (agetq__%
                                           _%key145387%_
                                           _%alist145388%_
                                           _%transparent?145356%_))))
                                   (if _%$e145390%_
                                       (if (eq? _%$e145390%_ '#t)
                                           (_%put-all-new-slots!145360%_
                                            _%ht145386%_)
                                           (_%put-slots!145359%_
                                            _%ht145386%_
                                            _%$e145390%_))
                                       '#!void)))))
                      (_%put-alist!145361%_
                       _%ht145358%_
                       _%key145355%_
                       _%properties145181%_)
                      (for-each
                       (lambda (_%mixin145363%_)
                         (let ((_%alist145365%_
                                (##structure-ref
                                 _%mixin145363%_
                                 '9
                                 class::t
                                 '#f)))
                           (if (eq? '#t
                                    (let ()
                                      (declare (not safe))
                                      (agetq__%
                                       _%key145355%_
                                       _%alist145365%_
                                       _%transparent?145356%_)))
                               (_%put-slots!145359%_
                                _%ht145358%_
                                (let ((_%klass145367%_ _%mixin145363%_))
                                  (if (let ()
                                        (declare (not safe))
                                        (##structure-instance-of?
                                         _%klass145367%_
                                         'class))
                                      (let ((_%klass145372%_ _%klass145367%_))
                                        (__class-type-slot-list
                                         _%klass145372%_))
                                      (begin
                                        (raise-contract-violation-error
                                         '"contract violation"
                                         'context:
                                         'gerbil/runtime/mop
                                         'contract:
                                         'class-type?
                                         'value:
                                         _%klass145367%_)
                                        '#!void))))
                               (_%put-alist!145361%_
                                _%ht145358%_
                                _%key145355%_
                                _%alist145365%_))))
                       _%precedence-list145179%_)
                      _%ht145358%_)))
                 (_%all-slots-property?145188%_
                  (lambda (_%key145350%_ _%transparent?145351%_)
                    (let ((_%entry145353%_
                           (assq _%key145350%_ _%properties145181%_)))
                      (if _%entry145353%_
                          (eq? (cdr _%entry145353%_) '#t)
                          _%transparent?145351%_)))))
          (let* ((_%transparent?145208%_
                  (let ((__tmp148749
                         (if _%type-super145178%_
                             (not (let ((_%type145190%_ _%type-super145178%_))
                                    (if (let ()
                                          (declare (not safe))
                                          (##type? _%type145190%_))
                                        (let ((_%type145195%_ _%type145190%_))
                                          (__type-opaque? _%type145195%_))
                                        (begin
                                          (raise-contract-violation-error
                                           '"contract violation"
                                           'context:
                                           'gerbil/runtime/mop
                                           'contract:
                                           '##type?
                                           'value:
                                           _%type145190%_)
                                          '#!void))))
                             '#t)))
                    (declare (not safe))
                    (agetq__% 'transparent: _%properties145181%_ __tmp148749)))
                 (_%all-slots-printable?145210%_
                  (_%all-slots-property?145188%_
                   'print:
                   _%transparent?145208%_))
                 (_%printable145212%_
                  (if _%all-slots-printable?145210%_
                      '#f
                      (_%make-props!145187%_ 'print: _%transparent?145208%_)))
                 (_%all-slots-equalable?145214%_
                  (_%all-slots-property?145188%_
                   'equal:
                   _%transparent?145208%_))
                 (_%equalable145216%_
                  (if _%all-slots-equalable?145214%_
                      '#f
                      (_%make-props!145187%_ 'equal: _%transparent?145208%_)))
                 (_%first-new-field145218%_
                  (if (let ()
                        (declare (not safe))
                        (##structure-instance-of? _%type-super145178%_ 'class))
                      (let ((__tmp148750
                             (let ()
                               (declare (not safe))
                               (##unchecked-structure-ref
                                _%type-super145178%_
                                '7
                                '#f
                                '#f))))
                        (declare (not safe))
                        (##vector-length __tmp148750))
                      '1))
                 (_%field-info-length145220%_
                  (let ((__tmp148751
                         (let ((__tmp148752
                                (let ()
                                  (declare (not safe))
                                  (##vector-length _%slot-vector145180%_))))
                           (declare (not safe))
                           (##fx- __tmp148752 _%first-new-field145218%_))))
                    (declare (not safe))
                    (##fx* '3 __tmp148751)))
                 (_%field-info145222%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%field-info-length145220%_ '#f)))
                 (_%_145240%_
                  (let _%loop145224%_ ((_%i145226%_ _%first-new-field145218%_)
                                       (_%j145227%_ '0))
                    (if (let ()
                          (declare (not safe))
                          (##fx< _%j145227%_ _%field-info-length145220%_))
                        (let* ((_%slot145229%_
                                (let ()
                                  (declare (not safe))
                                  (##vector-ref
                                   _%slot-vector145180%_
                                   _%i145226%_)))
                               (_%flags145237%_
                                (let ((__tmp148754
                                       (if (or _%all-slots-printable?145210%_
                                               (let ()
                                                 (declare (not safe))
                                                 (symbolic-table-ref
                                                  _%printable145212%_
                                                  _%slot145229%_
                                                  '#f)))
                                           '0
                                           '1))
                                      (__tmp148753
                                       (if (or _%all-slots-equalable?145214%_
                                               (let ()
                                                 (declare (not safe))
                                                 (symbolic-table-ref
                                                  _%equalable145216%_
                                                  _%slot145229%_
                                                  '#f)))
                                           '0
                                           '4)))
                                  (declare (not safe))
                                  (##fxior __tmp148754 __tmp148753))))
                          (vector-set!
                           _%field-info145222%_
                           _%j145227%_
                           _%slot145229%_)
                          (vector-set!
                           _%field-info145222%_
                           (let () (declare (not safe)) (##fx+ _%j145227%_ '1))
                           _%flags145237%_)
                          (_%loop145224%_
                           (let () (declare (not safe)) (##fx+ _%i145226%_ '1))
                           (let ()
                             (declare (not safe))
                             (##fx+ _%j145227%_ '3))))
                        '#!void)))
                 (_%struct?145242%_
                  (let ()
                    (declare (not safe))
                    (agetq__0 'struct: _%properties145181%_)))
                 (_%final?145244%_
                  (let ()
                    (declare (not safe))
                    (agetq__0 'final: _%properties145181%_)))
                 (_%metaclass145251%_
                  (let ((_%$%metaclass145245145247%_
                         (let ()
                           (declare (not safe))
                           (agetq__0 'metaclass: _%properties145181%_))))
                    (if _%$%metaclass145245145247%_
                        (let ((_%metaclass145249%_
                               _%$%metaclass145245145247%_))
                          (if (let ()
                                (declare (not safe))
                                (##structure-instance-of?
                                 _%metaclass145249%_
                                 'class))
                              '#!void
                              (error '"metaclass is not a class type"
                                     'class:
                                     _%type-id145176%_
                                     'metaclass:
                                     _%metaclass145249%_))
                          _%metaclass145249%_)
                        '#f)))
                 (_%system?145253%_
                  (let ()
                    (declare (not safe))
                    (agetq__0 'system: _%properties145181%_)))
                 (_%opaque?145262%_
                  (let ((_%$e145259%_
                         (let ((_%eq-entry145255%_
                                (assq 'equal: _%properties145181%_)))
                           (if _%eq-entry145255%_
                               (not (cdr _%eq-entry145255%_))
                               (let ((_%tr-entry145257%_
                                      (assq 'transparent:
                                            _%properties145181%_)))
                                 (if _%tr-entry145257%_
                                     (not (cdr _%tr-entry145257%_))
                                     '#f))))))
                    (if _%$e145259%_
                        _%$e145259%_
                        (let ((__tmp148755
                               (let ()
                                 (declare (not safe))
                                 (agetq__%
                                  'direct-supers:
                                  _%properties145181%_
                                  '()))))
                          (declare (not safe))
                          (ormap__0 type-opaque? __tmp148755)))))
                 (_%acyclic?145264%_
                  (let ()
                    (declare (not safe))
                    (agetq__0 'acyclic: _%properties145181%_)))
                 (_%type-flags145266%_
                  (let ((__tmp148761
                         (if _%final?145244%_ '0 type-flag-extensible))
                        (__tmp148760
                         (if _%opaque?145262%_ type-flag-opaque '0))
                        (__tmp148759
                         (if _%struct?145242%_ class-type-flag-struct '0))
                        (__tmp148758
                         (if _%metaclass145251%_ class-type-flag-metaclass '0))
                        (__tmp148757
                         (if _%system?145253%_ class-type-flag-system '0))
                        (__tmp148756
                         (if _%acyclic?145264%_ class-type-flag-acyclic '0)))
                    (declare (not safe))
                    (##fxior type-flag-id
                             type-flag-concrete
                             __tmp148761
                             __tmp148760
                             __tmp148759
                             __tmp148758
                             __tmp148757
                             __tmp148756)))
                 (_%precedence-list145274%_
                  (let ((_%$e145268%_ (memq t::t _%precedence-list145179%_)))
                    (if _%$e145268%_
                        (if (null? (cdr _%$e145268%_))
                            _%precedence-list145179%_
                            (error '"BUG: t::t is not last in the precedence list"
                                   'precedence-list:
                                   _%precedence-list145179%_))
                        (let ((__tmp148762 (cons t::t '())))
                          (declare (not safe))
                          (##append _%precedence-list145179%_ __tmp148762)))))
                 (_%klass145315%_
                  (if _%metaclass145251%_
                      (let ((_%val145312%_
                             (let* ((_%klass145276%_ _%metaclass145251%_)
                                    (_%args145279%_
                                     (list _%type-id145176%_
                                           _%type-name145177%_
                                           _%type-flags145266%_
                                           _%type-super145178%_
                                           _%field-info145222%_
                                           _%precedence-list145274%_
                                           _%slot-vector145180%_
                                           _%slot-table145183%_
                                           _%properties145181%_
                                           _%constructor145182%_
                                           _%methods145184%_
                                           '#f
                                           '#f)))
                               (if (let ()
                                     (declare (not safe))
                                     (##structure-instance-of?
                                      _%klass145276%_
                                      'class))
                                   (let ((_%klass145284%_ _%klass145276%_))
                                     (declare (not safe))
                                     (##apply __make-instance
                                              _%klass145284%_
                                              _%args145279%_))
                                   (begin
                                     (raise-contract-violation-error
                                      '"contract violation"
                                      'context:
                                      'gerbil/runtime/mop
                                      'contract:
                                      'class-type?
                                      'value:
                                      _%klass145276%_)
                                     '#!void)))))
                        (if (let ()
                              (declare (not safe))
                              (##structure-instance-of? _%val145312%_ 'class))
                            _%val145312%_
                            (begin
                              (raise-contract-violation-error
                               '"contract violation"
                               'context:
                               '"\"gerbil/runtime/mop.ss\"@326.16-329.37"
                               'contract:
                               '(class-type? val)
                               'value:
                               _%val145312%_)
                              '#!void)))
                      (let ()
                        (declare (not safe))
                        (##structure
                         class::t
                         _%type-id145176%_
                         _%type-name145177%_
                         _%type-flags145266%_
                         _%type-super145178%_
                         _%field-info145222%_
                         _%precedence-list145274%_
                         _%slot-vector145180%_
                         _%slot-table145183%_
                         _%properties145181%_
                         _%constructor145182%_
                         _%methods145184%_
                         '#f
                         '#f)))))
            (for-each
             (lambda (_%super145318%_)
               (let ()
                 (declare (not interrupts-enabled))
                 (let _%again145322%_ ((_%spin145325%_ '0))
                   (if (let ((__tmp148763
                              (let ()
                                (declare (not safe))
                                (##vector-cas!
                                 __class-type-properties-lock
                                 '0
                                 '1
                                 '0))))
                         (declare (not safe))
                         (##fx= __tmp148763 '0))
                       (let ((__tmp148764 (current-thread)))
                         (declare (not safe))
                         (##vector-set!
                          __class-type-properties-lock
                          '1
                          __tmp148764))
                       (if (let ()
                             (declare (not safe))
                             (##fx< _%spin145325%_ '10))
                           (_%again145322%_
                            (let ()
                              (declare (not safe))
                              (##fx+ _%spin145325%_ '1)))
                           (let ((_%owner145331%_
                                  (let ()
                                    (declare (not safe))
                                    (##vector-ref
                                     __class-type-properties-lock
                                     '1))))
                             (if (eq? _%owner145331%_ (macro-current-thread))
                                 (let ()
                                   (declare (not safe))
                                   (##thread-deadlock-action!))
                                 (if (macro-thread-end-condvar _%owner145331%_)
                                     (let ()
                                       (let ()
                                         (declare (not safe))
                                         (##thread-yield!))
                                       (_%again145322%_ '0))
                                     (let ()
                                       (declare (not safe))
                                       (##thread-deadlock-action!)))))))))
               (let ((_%$r145345%_
                      (let* ((_%props145337%_
                              (let ()
                                (declare (not safe))
                                (##unchecked-structure-ref
                                 _%super145318%_
                                 '9
                                 '#f
                                 '#f)))
                             (_%$e145339%_
                              (assq 'subclasses: _%props145337%_)))
                        (if _%$e145339%_
                            (set-cdr!
                             _%$e145339%_
                             (cons _%klass145315%_ (cdr _%$e145339%_)))
                            (let ((__tmp148765
                                   (cons (cons 'subclasses:
                                               (cons _%klass145315%_ '()))
                                         _%props145337%_)))
                              (declare (not safe))
                              (##unchecked-structure-set!
                               _%super145318%_
                               __tmp148765
                               '9
                               '#f
                               '#f))))))
                 (let ()
                   (declare (not interrupts-enabled))
                   (begin
                     (let ()
                       (declare (not safe))
                       (##vector-set! __class-type-properties-lock '1 '#f))
                     (let ()
                       (declare (not safe))
                       (##vector-cas! __class-type-properties-lock '0 '0 '1))))
                 _%$r145345%_))
             (let ()
               (declare (not safe))
               (agetq__% 'direct-supers: _%properties145181%_ '())))
            _%klass145315%_))))
    (define class-type-id
      (lambda (_%klass145174%_)
        (##structure-ref _%klass145174%_ '1 class::t 'id)))
    (define &class-type-id
      (lambda (_%klass145172%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-ref _%klass145172%_ '1 class::t 'id))))
    (define class-type-id-set!
      (lambda (_%klass145169%_ _%val145170%_)
        (##structure-set! _%klass145169%_ _%val145170%_ '1 class::t 'id)))
    (define &class-type-id-set!
      (lambda (_%klass145164%_ _%val145166%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           _%klass145164%_
           _%val145166%_
           '1
           class::t
           'id))))
    (define class-type-name
      (lambda (_%klass145162%_)
        (##structure-ref _%klass145162%_ '2 class::t 'name)))
    (define &class-type-name
      (lambda (_%klass145160%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-ref _%klass145160%_ '2 class::t 'name))))
    (define class-type-name-set!
      (lambda (_%klass145157%_ _%val145158%_)
        (##structure-set! _%klass145157%_ _%val145158%_ '2 class::t 'name)))
    (define &class-type-name-set!
      (lambda (_%klass145152%_ _%val145154%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           _%klass145152%_
           _%val145154%_
           '2
           class::t
           'name))))
    (define class-type-flags
      (lambda (_%klass145150%_)
        (##structure-ref _%klass145150%_ '3 class::t 'flags)))
    (define &class-type-flags
      (lambda (_%klass145148%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-ref _%klass145148%_ '3 class::t 'flags))))
    (define class-type-flags-set!
      (lambda (_%klass145145%_ _%val145146%_)
        (##structure-set! _%klass145145%_ _%val145146%_ '3 class::t 'flags)))
    (define &class-type-flags-set!
      (lambda (_%klass145140%_ _%val145142%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           _%klass145140%_
           _%val145142%_
           '3
           class::t
           'flags))))
    (define class-type-super
      (lambda (_%klass145138%_)
        (##structure-ref _%klass145138%_ '4 class::t 'super)))
    (define &class-type-super
      (lambda (_%klass145136%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-ref _%klass145136%_ '4 class::t 'super))))
    (define class-type-super-set!
      (lambda (_%klass145133%_ _%val145134%_)
        (##structure-set! _%klass145133%_ _%val145134%_ '4 class::t 'super)))
    (define &class-type-super-set!
      (lambda (_%klass145128%_ _%val145130%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           _%klass145128%_
           _%val145130%_
           '4
           class::t
           'super))))
    (define class-type-fields
      (lambda (_%klass145126%_)
        (##structure-ref _%klass145126%_ '5 class::t 'fields)))
    (define &class-type-fields
      (lambda (_%klass145124%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-ref _%klass145124%_ '5 class::t 'fields))))
    (define class-type-fields-set!
      (lambda (_%klass145121%_ _%val145122%_)
        (##structure-set! _%klass145121%_ _%val145122%_ '5 class::t 'fields)))
    (define &class-type-fields-set!
      (lambda (_%klass145116%_ _%val145118%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           _%klass145116%_
           _%val145118%_
           '5
           class::t
           'fields))))
    (define class-type-precedence-list
      (lambda (_%klass145114%_)
        (##structure-ref _%klass145114%_ '6 class::t 'precedence-list)))
    (define &class-type-precedence-list
      (lambda (_%klass145112%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-ref
           _%klass145112%_
           '6
           class::t
           'precedence-list))))
    (define class-type-precedence-list-set!
      (lambda (_%klass145109%_ _%val145110%_)
        (##structure-set!
         _%klass145109%_
         _%val145110%_
         '6
         class::t
         'precedence-list)))
    (define &class-type-precedence-list-set!
      (lambda (_%klass145104%_ _%val145106%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           _%klass145104%_
           _%val145106%_
           '6
           class::t
           'precedence-list))))
    (define class-type-slot-vector
      (lambda (_%klass145102%_)
        (##structure-ref _%klass145102%_ '7 class::t 'slot-vector)))
    (define &class-type-slot-vector
      (lambda (_%klass145100%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-ref
           _%klass145100%_
           '7
           class::t
           'slot-vector))))
    (define class-type-slot-vector-set!
      (lambda (_%klass145097%_ _%val145098%_)
        (##structure-set!
         _%klass145097%_
         _%val145098%_
         '7
         class::t
         'slot-vector)))
    (define &class-type-slot-vector-set!
      (lambda (_%klass145092%_ _%val145094%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           _%klass145092%_
           _%val145094%_
           '7
           class::t
           'slot-vector))))
    (define class-type-slot-table
      (lambda (_%klass145090%_)
        (##structure-ref _%klass145090%_ '8 class::t 'slot-table)))
    (define &class-type-slot-table
      (lambda (_%klass145088%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-ref
           _%klass145088%_
           '8
           class::t
           'slot-table))))
    (define class-type-slot-table-set!
      (lambda (_%klass145085%_ _%val145086%_)
        (##structure-set!
         _%klass145085%_
         _%val145086%_
         '8
         class::t
         'slot-table)))
    (define &class-type-slot-table-set!
      (lambda (_%klass145080%_ _%val145082%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           _%klass145080%_
           _%val145082%_
           '8
           class::t
           'slot-table))))
    (define class-type-properties
      (lambda (_%klass145078%_)
        (##structure-ref _%klass145078%_ '9 class::t 'properties)))
    (define &class-type-properties
      (lambda (_%klass145076%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-ref
           _%klass145076%_
           '9
           class::t
           'properties))))
    (define class-type-properties-set!
      (lambda (_%klass145073%_ _%val145074%_)
        (##structure-set!
         _%klass145073%_
         _%val145074%_
         '9
         class::t
         'properties)))
    (define &class-type-properties-set!
      (lambda (_%klass145068%_ _%val145070%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           _%klass145068%_
           _%val145070%_
           '9
           class::t
           'properties))))
    (define class-type-constructor
      (lambda (_%klass145066%_)
        (##structure-ref _%klass145066%_ '10 class::t 'constructor)))
    (define &class-type-constructor
      (lambda (_%klass145064%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-ref
           _%klass145064%_
           '10
           class::t
           'constructor))))
    (define class-type-constructor-set!
      (lambda (_%klass145061%_ _%val145062%_)
        (##structure-set!
         _%klass145061%_
         _%val145062%_
         '10
         class::t
         'constructor)))
    (define &class-type-constructor-set!
      (lambda (_%klass145056%_ _%val145058%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           _%klass145056%_
           _%val145058%_
           '10
           class::t
           'constructor))))
    (define class-type-methods
      (lambda (_%klass145054%_)
        (##structure-ref _%klass145054%_ '11 class::t 'methods)))
    (define &class-type-methods
      (lambda (_%klass145052%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-ref _%klass145052%_ '11 class::t 'methods))))
    (define class-type-methods-set!
      (lambda (_%klass145049%_ _%val145050%_)
        (##structure-set!
         _%klass145049%_
         _%val145050%_
         '11
         class::t
         'methods)))
    (define &class-type-methods-set!
      (lambda (_%klass145044%_ _%val145046%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           _%klass145044%_
           _%val145046%_
           '11
           class::t
           'methods))))
    (define class-type-specializer
      (lambda (_%klass145042%_)
        (##structure-ref _%klass145042%_ '12 class::t 'specializer)))
    (define &class-type-specializer
      (lambda (_%klass145040%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-ref
           _%klass145040%_
           '12
           class::t
           'specializer))))
    (define class-type-specializer-set!
      (lambda (_%klass145037%_ _%val145038%_)
        (##structure-set!
         _%klass145037%_
         _%val145038%_
         '12
         class::t
         'specializer)))
    (define &class-type-specializer-set!
      (lambda (_%klass145032%_ _%val145034%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           _%klass145032%_
           _%val145034%_
           '12
           class::t
           'specializer))))
    (define class-type-interface
      (lambda (_%klass145030%_)
        (##structure-ref _%klass145030%_ '13 class::t 'interface)))
    (define &class-type-interface
      (lambda (_%klass145028%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-ref
           _%klass145028%_
           '13
           class::t
           'interface))))
    (define class-type-interface-set!
      (lambda (_%klass145025%_ _%val145026%_)
        (##structure-set!
         _%klass145025%_
         _%val145026%_
         '13
         class::t
         'interface)))
    (define &class-type-interface-set!
      (lambda (_%klass145020%_ _%val145022%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           _%klass145020%_
           _%val145022%_
           '13
           class::t
           'interface))))
    (define type-field-list
      (lambda (_%type144784%_)
        (letrec ((_%__fields->list144914%_
                  (lambda (_%fields144978%_)
                    (let* ((_%fields144981%_ _%fields144978%_)
                           (_%fields-len144990%_
                            (let ()
                              (declare (not safe))
                              (##vector-length _%fields144981%_))))
                      (let _%loop144992%_ ((_%i144994%_ '0) (_%r144995%_ '()))
                        (let* ((_%i144998%_ _%i144994%_)
                               (_%r145011%_ _%r144995%_))
                          (if (let ()
                                (declare (not safe))
                                (##fx< _%i144998%_ _%fields-len144990%_))
                              (_%loop144992%_
                               (let ()
                                 (declare (not safe))
                                 (##fx+ _%i144998%_ '3))
                               (cons (vector-ref _%fields144981%_ _%i144998%_)
                                     _%r145011%_))
                              (reverse! _%r145011%_)))))))
                 (_%fields->list144915%_
                  (lambda (_%fields144966%_)
                    (let ((_%fields144969%_ _%fields144966%_))
                      (_%__fields->list144914%_ _%fields144969%_)))))
          (let _%loop144917%_ ((_%type144919%_ _%type144784%_))
            (if (let () (declare (not safe)) (##type? _%type144919%_))
                (if (eq? _%type144919%_ ##type-type)
                    '()
                    (let ((_%$e144924%_
                           (let ()
                             (declare (not safe))
                             (##type-super _%type144919%_))))
                      (if _%$e144924%_
                          (let ((__tmp148767 (_%loop144917%_ _%$e144924%_))
                                (__tmp148766
                                 (let* ((_%fields144930%_
                                         (let ()
                                           (declare (not safe))
                                           (##type-fields _%type144919%_)))
                                        (_%fields144934%_ _%fields144930%_))
                                   (_%__fields->list144914%_
                                    _%fields144934%_))))
                            (declare (not safe))
                            (##append __tmp148767 __tmp148766))
                          (let* ((_%fields144951%_
                                  (let ()
                                    (declare (not safe))
                                    (##type-fields _%type144919%_)))
                                 (_%fields144955%_ _%fields144951%_))
                            (_%__fields->list144914%_ _%fields144955%_)))))
                '())))))
    (define __class-type-field-list
      (lambda (_%klass144752%_)
        (let ((_%klass144755%_ _%klass144752%_))
          (letrec ((_%get-fields!144764%_
                    (lambda (_%klass144779%_ _%type144780%_)
                      (let ((_%fields144782%_
                             (type-field-list _%type144780%_)))
                        (##structure-set!
                         _%klass144779%_
                         (cons (cons 'fields: _%fields144782%_)
                               (##structure-ref
                                _%klass144779%_
                                '9
                                class::t
                                '#f))
                         '9
                         class::t
                         '#f)
                        _%fields144782%_))))
            (let* ((_%props144766%_
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-ref _%klass144755%_ '9 '#f '#f)))
                   (_%$e144768%_
                    (let ()
                      (declare (not safe))
                      (agetq__0 'fields: _%props144766%_))))
              (if _%$e144768%_
                  _%$e144768%_
                  (let ((_%$e144771%_
                         (let ()
                           (declare (not safe))
                           (agetq__0 'system-type: _%props144766%_))))
                    (if _%$e144771%_
                        (_%get-fields!144764%_ _%klass144755%_ _%$e144771%_)
                        (_%get-fields!144764%_
                         _%klass144755%_
                         _%klass144755%_)))))))))
    (define class-type-field-list
      (lambda (_%klass144738%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass144738%_ 'class))
            (let ((_%klass144742%_ _%klass144738%_))
              (__class-type-field-list _%klass144742%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@427.30-427.35"
               'contract:
               'class-type?
               'value:
               _%klass144738%_)
              '#!void))))
    (define __class-type-slot-list
      (lambda (_%klass144726%_)
        (let ((_%klass144729%_ _%klass144726%_))
          (vector->list
           (let ()
             (declare (not safe))
             (##unchecked-structure-ref _%klass144729%_ '7 '#f '#f))
           '1))))
    (define class-type-slot-list
      (lambda (_%klass144712%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass144712%_ 'class))
            (let ((_%klass144716%_ _%klass144712%_))
              (__class-type-slot-list _%klass144716%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@443.29-443.34"
               'contract:
               'class-type?
               'value:
               _%klass144712%_)
              '#!void))))
    (define __class-type-field-count
      (lambda (_%klass144700%_)
        (let* ((_%klass144703%_ _%klass144700%_)
               (__tmp148768
                (let ((__tmp148769
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%klass144703%_
                          '7
                          '#f
                          '#f))))
                  (declare (not safe))
                  (##vector-length __tmp148769))))
          (declare (not safe))
          (##fx- __tmp148768 '1))))
    (define class-type-field-count
      (lambda (_%klass144686%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass144686%_ 'class))
            (let ((_%klass144690%_ _%klass144686%_))
              (__class-type-field-count _%klass144690%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@445.31-445.36"
               'contract:
               'class-type?
               'value:
               _%klass144686%_)
              '#!void))))
    (define __class-type-seal!
      (lambda (_%klass144674%_)
        (let ((_%klass144677%_ _%klass144674%_))
          (let ((__tmp148770
                 (let ((__tmp148771
                        (let ()
                          (declare (not safe))
                          (##type-flags _%klass144677%_))))
                   (declare (not safe))
                   (##fxior class-type-flag-sealed __tmp148771))))
            (declare (not safe))
            (##unchecked-structure-set!
             _%klass144677%_
             __tmp148770
             '3
             class::t
             class-type-seal!))
          '#!void)))
    (define class-type-seal!
      (lambda (_%klass144660%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass144660%_ 'class))
            (let ((_%klass144664%_ _%klass144660%_))
              (__class-type-seal! _%klass144664%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@448.25-448.30"
               'contract:
               'class-type?
               'value:
               _%klass144660%_)
              '#!void))))
    (define __class-type-properties-lock (vector '0 '#f))
    (define __class-type-properties-put!
      (lambda (_%klass144614%_ _%key144615%_ _%val144616%_)
        (let* ((_%klass144619%_ _%klass144614%_) (_%key144627%_ _%key144615%_))
          (let ()
            (declare (not interrupts-enabled))
            (let _%again144638%_ ((_%spin144641%_ '0))
              (if (let ((__tmp148772
                         (let ()
                           (declare (not safe))
                           (##vector-cas!
                            __class-type-properties-lock
                            '0
                            '1
                            '0))))
                    (declare (not safe))
                    (##fx= __tmp148772 '0))
                  (let ((__tmp148773 (current-thread)))
                    (declare (not safe))
                    (##vector-set!
                     __class-type-properties-lock
                     '1
                     __tmp148773))
                  (if (let () (declare (not safe)) (##fx< _%spin144641%_ '10))
                      (_%again144638%_
                       (let () (declare (not safe)) (##fx+ _%spin144641%_ '1)))
                      (let ((_%owner144647%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref
                                __class-type-properties-lock
                                '1))))
                        (if (eq? _%owner144647%_ (macro-current-thread))
                            (let ()
                              (declare (not safe))
                              (##thread-deadlock-action!))
                            (if (macro-thread-end-condvar _%owner144647%_)
                                (let ()
                                  (let ()
                                    (declare (not safe))
                                    (##thread-yield!))
                                  (_%again144638%_ '0))
                                (let ()
                                  (declare (not safe))
                                  (##thread-deadlock-action!)))))))))
          (let ((_%$r144655%_
                 (let ((_%props144653%_
                        (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%klass144619%_
                           '9
                           '#f
                           '#f))))
                   (if (assq _%key144627%_ _%props144653%_)
                       '#!void
                       (let ((__tmp148774
                              (cons (cons _%key144627%_ _%val144616%_)
                                    _%props144653%_)))
                         (declare (not safe))
                         (##unchecked-structure-set!
                          _%klass144619%_
                          __tmp148774
                          '9
                          '#f
                          '#f))))))
            (let ()
              (declare (not interrupts-enabled))
              (begin
                (let ()
                  (declare (not safe))
                  (##vector-set! __class-type-properties-lock '1 '#f))
                (let ()
                  (declare (not safe))
                  (##vector-cas! __class-type-properties-lock '0 '0 '1))))
            _%$r144655%_))))
    (define class-type-properties-put!
      (lambda (_%klass144588%_ _%key144589%_ _%val144590%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass144588%_ 'class))
            (let ((_%klass144594%_ _%klass144588%_))
              (if (keyword? _%key144589%_)
                  (let ((_%key144604%_ _%key144589%_))
                    (__class-type-properties-put!
                     _%klass144594%_
                     _%key144604%_
                     _%val144590%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@456.52-456.55"
                     'contract:
                     'keyword?
                     'value:
                     _%key144589%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@456.35-456.40"
               'contract:
               'class-type?
               'value:
               _%klass144588%_)
              '#!void))))
    (define __class-type-printable-slots
      (lambda (_%klass144482%_)
        (let ((_%klass144485%_ _%klass144482%_))
          (letrec ((_%get-field-vector144494%_
                    (lambda (_%type144572%_)
                      (let _%loop144574%_ ((_%type144576%_ _%type144572%_))
                        (let* ((_%fields144578%_
                                (let ()
                                  (declare (not safe))
                                  (##type-fields _%type144576%_)))
                               (_%$e144580%_
                                (let ()
                                  (declare (not safe))
                                  (##type-super _%type144576%_))))
                          (if _%$e144580%_
                              (let ((_%super-fields144585%_
                                     (_%loop144574%_ _%$e144580%_)))
                                (vector-append
                                 _%super-fields144585%_
                                 _%fields144578%_))
                              _%fields144578%_)))))
                   (_%get-printable-slot-alist144495%_
                    (lambda (_%type144555%_)
                      (let* ((_%fields144557%_
                              (_%get-field-vector144494%_ _%type144555%_))
                             (_%count144559%_
                              (vector-length _%fields144557%_)))
                        (let _%loop144562%_ ((_%i144564%_ '0)
                                             (_%offset144565%_ '1)
                                             (_%r144566%_ '()))
                          (if (let ()
                                (declare (not safe))
                                (##fx< _%i144564%_ _%count144559%_))
                              (let ((_%slot-name144568%_
                                     (vector-ref _%fields144557%_ _%i144564%_))
                                    (_%slot-flags144569%_
                                     (vector-ref
                                      _%fields144557%_
                                      (let ()
                                        (declare (not safe))
                                        (##fx+ _%i144564%_ '1))))
                                    (_%next-i144570%_
                                     (let ()
                                       (declare (not safe))
                                       (##fx+ _%i144564%_ '3))))
                                (if (let ((__tmp148775
                                           (let ()
                                             (declare (not safe))
                                             (##fxand _%slot-flags144569%_
                                                      '1))))
                                      (declare (not safe))
                                      (##fx= __tmp148775 '0))
                                    (_%loop144562%_
                                     _%next-i144570%_
                                     (let ()
                                       (declare (not safe))
                                       (##fx+ _%offset144565%_ '1))
                                     (cons (cons _%slot-name144568%_
                                                 _%offset144565%_)
                                           _%r144566%_))
                                    (_%loop144562%_
                                     _%next-i144570%_
                                     (let ()
                                       (declare (not safe))
                                       (##fx+ _%offset144565%_ '1))
                                     _%r144566%_)))
                              (reverse! _%r144566%_))))))
                   (_%get-printable-slots!144496%_
                    (lambda (_%klass144511%_ _%type144512%_)
                      (let ((_%printable144514%_
                             (_%get-printable-slot-alist144495%_
                              _%type144512%_)))
                        (let* ((_%klass144516%_ _%klass144511%_)
                               (_%key144519%_ 'printable-slots:)
                               (_%val144522%_ _%printable144514%_))
                          (if (let ()
                                (declare (not safe))
                                (##structure-instance-of?
                                 _%klass144516%_
                                 'class))
                              (let* ((_%klass144527%_ _%klass144516%_)
                                     (_%key144545%_ _%key144519%_))
                                (__class-type-properties-put!
                                 _%klass144527%_
                                 _%key144545%_
                                 _%val144522%_))
                              (begin
                                (raise-contract-violation-error
                                 '"contract violation"
                                 'context:
                                 'gerbil/runtime/mop
                                 'contract:
                                 'class-type?
                                 'value:
                                 _%klass144516%_)
                                '#!void)))
                        _%printable144514%_))))
            (let* ((_%props144498%_
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-ref _%klass144485%_ '9 '#f '#f)))
                   (_%$e144500%_
                    (let ()
                      (declare (not safe))
                      (agetq__0 'printable-slots: _%props144498%_))))
              (if _%$e144500%_
                  _%$e144500%_
                  (let ((_%$e144503%_
                         (let ()
                           (declare (not safe))
                           (agetq__0 'system-type: _%props144498%_))))
                    (if _%$e144503%_
                        (_%get-printable-slots!144496%_
                         _%klass144485%_
                         _%$e144503%_)
                        (_%get-printable-slots!144496%_
                         _%klass144485%_
                         _%klass144485%_)))))))))
    (define class-type-printable-slots
      (lambda (_%klass144468%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass144468%_ 'class))
            (let ((_%klass144472%_ _%klass144468%_))
              (__class-type-printable-slots _%klass144472%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@465.35-465.40"
               'contract:
               'class-type?
               'value:
               _%klass144468%_)
              '#!void))))
    (define __substruct?
      (lambda (_%maybe-sub-struct144437%_ _%maybe-super-struct144438%_)
        (let* ((_%maybe-sub-struct144441%_ _%maybe-sub-struct144437%_)
               (_%maybe-super-struct144449%_ _%maybe-super-struct144438%_)
               (_%maybe-super-struct-id144458%_
                (let ()
                  (declare (not safe))
                  (##type-id _%maybe-super-struct144449%_))))
          (let _%lp144460%_ ((_%super-struct144462%_
                              _%maybe-sub-struct144441%_))
            (if _%super-struct144462%_
                (if (eq? _%maybe-super-struct-id144458%_
                         (let ()
                           (declare (not safe))
                           (##type-id _%super-struct144462%_)))
                    '#t
                    (_%lp144460%_
                     (let ()
                       (declare (not safe))
                       (##type-super _%super-struct144462%_))))
                '#f)))))
    (define substruct?
      (lambda (_%maybe-sub-struct144412%_ _%maybe-super-struct144413%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%maybe-sub-struct144412%_ 'class))
            (let ((_%maybe-sub-struct144417%_ _%maybe-sub-struct144412%_))
              (if (let ()
                    (declare (not safe))
                    (##structure-instance-of?
                     _%maybe-super-struct144413%_
                     'class))
                  (let ((_%maybe-super-struct144427%_
                         _%maybe-super-struct144413%_))
                    (__substruct?
                     _%maybe-sub-struct144417%_
                     _%maybe-super-struct144427%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@509.47-509.65"
                     'contract:
                     'class-type?
                     'value:
                     _%maybe-super-struct144413%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@509.19-509.35"
               'contract:
               'class-type?
               'value:
               _%maybe-sub-struct144412%_)
              '#!void))))
    (define base-struct/1
      (lambda (_%klass144390%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass144390%_ 'class))
            (if (let* ((_%klass144393%_ _%klass144390%_)
                       (_%klass144398%_ _%klass144393%_))
                  (__class-type-struct? _%klass144398%_))
                _%klass144390%_
                (let () (declare (not safe)) (##type-super _%klass144390%_)))
            (if _%klass144390%_
                (error '"not a class or false" _%klass144390%_)
                '#f))))
    (define base-struct/2
      (lambda (_%klass1144313%_ _%klass2144314%_)
        (let ((_%s1144316%_ (base-struct/1 _%klass1144313%_))
              (_%s2144317%_ (base-struct/1 _%klass2144314%_)))
          (if (or (not _%s1144316%_)
                  (and _%s2144317%_
                       (let* ((_%maybe-sub-struct144322%_ _%s1144316%_)
                              (_%maybe-super-struct144325%_ _%s2144317%_))
                         (if (let ()
                               (declare (not safe))
                               (##structure-instance-of?
                                _%maybe-sub-struct144322%_
                                'class))
                             (let ((_%maybe-sub-struct144330%_
                                    _%maybe-sub-struct144322%_))
                               (if (let ()
                                     (declare (not safe))
                                     (##structure-instance-of?
                                      _%maybe-super-struct144325%_
                                      'class))
                                   (let ((_%maybe-super-struct144344%_
                                          _%maybe-super-struct144325%_))
                                     (__substruct?
                                      _%maybe-sub-struct144330%_
                                      _%maybe-super-struct144344%_))
                                   (begin
                                     (raise-contract-violation-error
                                      '"contract violation"
                                      'context:
                                      'gerbil/runtime/mop
                                      'contract:
                                      'class-type?
                                      'value:
                                      _%maybe-super-struct144325%_)
                                     '#!void)))
                             (begin
                               (raise-contract-violation-error
                                '"contract violation"
                                'context:
                                'gerbil/runtime/mop
                                'contract:
                                'class-type?
                                'value:
                                _%maybe-sub-struct144322%_)
                               '#!void)))))
              _%s2144317%_
              (if (or (not _%s2144317%_)
                      (and _%s1144316%_
                           (let* ((_%maybe-sub-struct144358%_ _%s2144317%_)
                                  (_%maybe-super-struct144361%_ _%s1144316%_))
                             (if (let ()
                                   (declare (not safe))
                                   (##structure-instance-of?
                                    _%maybe-sub-struct144358%_
                                    'class))
                                 (let ((_%maybe-sub-struct144366%_
                                        _%maybe-sub-struct144358%_))
                                   (if (let ()
                                         (declare (not safe))
                                         (##structure-instance-of?
                                          _%maybe-super-struct144361%_
                                          'class))
                                       (let ((_%maybe-super-struct144378%_
                                              _%maybe-super-struct144361%_))
                                         (__substruct?
                                          _%maybe-sub-struct144366%_
                                          _%maybe-super-struct144378%_))
                                       (begin
                                         (raise-contract-violation-error
                                          '"contract violation"
                                          'context:
                                          'gerbil/runtime/mop
                                          'contract:
                                          'class-type?
                                          'value:
                                          _%maybe-super-struct144361%_)
                                         '#!void)))
                                 (begin
                                   (raise-contract-violation-error
                                    '"contract violation"
                                    'context:
                                    'gerbil/runtime/mop
                                    'contract:
                                    'class-type?
                                    'value:
                                    _%maybe-sub-struct144358%_)
                                   '#!void)))))
                  _%s1144316%_
                  (error '"bad mixin: incompatible struct bases"
                         _%klass1144313%_
                         _%klass2144314%_
                         _%s1144316%_
                         _%s2144317%_))))))
    (define base-struct/list
      (lambda (_%all-supers144198%_)
        (let* ((_%$%all-supers144199144224%_ _%all-supers144198%_)
               (_%$%E144204144228%_
                (lambda ()
                  (error '"No clause matching"
                         _%$%all-supers144199144224%_
                         '([])
                         '([x])
                         '([x y])
                         '([x y ...]))
                  '#!void)))
          (let ((_%$%K144222144310%_ (lambda () '#f))
                (_%$%K144219144296%_
                 (lambda (_%x144294%_) (base-struct/1 _%x144294%_)))
                (_%$%K144214144273%_
                 (lambda (_%y144270%_ _%x144271%_)
                   (base-struct/2 _%x144271%_ _%y144270%_)))
                (_%$%K144205144235%_
                 (lambda (_%y144232%_ _%x144233%_)
                   (let ()
                     (declare (not safe))
                     (foldr__0 base-struct/2 _%x144233%_ _%y144232%_)))))
            (let* ((_%__match147535147536%_
                    (lambda (_%$%hd144206144238%_ _%$%tl144207144240%_)
                      (let ((_%x144243%_ _%$%hd144206144238%_))
                        (letrec ((_%$%splice-rest144209144245%_
                                  (lambda (_%$%rest144213144252%_ _%y144254%_)
                                    (if (null? _%$%rest144213144252%_)
                                        (_%$%K144205144235%_
                                         _%y144254%_
                                         _%x144243%_)
                                        (_%$%E144204144228%_))))
                                 (_%$%splice-try144211144247%_
                                  (lambda (_%$%hd144212144256%_
                                           _%$%rest144213144258%_
                                           _%$%y144208144259%_)
                                    (let ((_%y144261%_ _%$%hd144212144256%_))
                                      (_%$%splice-loop144210144249%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%rest144213144258%_))
                                       (cons _%y144261%_
                                             _%$%y144208144259%_)))))
                                 (_%$%splice-loop144210144249%_
                                  (lambda (_%$%rest144213144263%_
                                           _%$%y144208144264%_)
                                    (if (pair? _%$%rest144213144263%_)
                                        (_%$%splice-try144211144247%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%rest144213144263%_))
                                         _%$%rest144213144263%_
                                         _%$%y144208144264%_)
                                        (_%$%splice-rest144209144245%_
                                         _%$%rest144213144263%_
                                         (reverse _%$%y144208144264%_))))))
                          (_%$%splice-loop144210144249%_
                           _%$%tl144207144240%_
                           '())))))
                   (_%$%try-match144201144306%_
                    (lambda ()
                      (if (pair? _%$%all-supers144199144224%_)
                          (let ((_%$%tl144221144301%_
                                 (let ()
                                   (declare (not safe))
                                   (##cdr _%$%all-supers144199144224%_)))
                                (_%$%hd144220144299%_
                                 (let ()
                                   (declare (not safe))
                                   (##car _%$%all-supers144199144224%_))))
                            (if (null? _%$%tl144221144301%_)
                                (let ((_%x144304%_ _%$%hd144220144299%_))
                                  (base-struct/1 _%x144304%_))
                                (if (pair? _%$%tl144221144301%_)
                                    (let ((_%$%tl144218144285%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%tl144221144301%_)))
                                          (_%$%hd144217144283%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%tl144221144301%_))))
                                      (if (null? _%$%tl144218144285%_)
                                          (let ((_%x144281%_
                                                 _%$%hd144220144299%_)
                                                (_%y144288%_
                                                 _%$%hd144217144283%_))
                                            (_%$%K144214144273%_
                                             _%y144288%_
                                             _%x144281%_))
                                          (_%__match147535147536%_
                                           _%$%hd144220144299%_
                                           _%$%tl144221144301%_)))
                                    (_%__match147535147536%_
                                     _%$%hd144220144299%_
                                     _%$%tl144221144301%_))))
                          (_%$%E144204144228%_)))))
              (if (null? _%$%all-supers144199144224%_)
                  (_%$%K144222144310%_)
                  (_%$%try-match144201144306%_)))))))
    (define base-struct
      (lambda _%all-supers144196%_ (base-struct/list _%all-supers144196%_)))
    (define find-super-constructor
      (lambda (_%super144147%_)
        (let _%lp144149%_ ((_%rest144151%_ _%super144147%_)
                           (_%constructor144152%_ '#f))
          (let* ((_%$%rest144153144161%_ _%rest144151%_)
                 (_%$%else144155144169%_ (lambda () _%constructor144152%_))
                 (_%$%K144157144184%_
                  (lambda (_%rest144172%_ _%hd144173%_)
                    (let ((_%$e144175%_
                           (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%hd144173%_
                              '10
                              '#f
                              '#f))))
                      (if _%$e144175%_
                          (if (or (not _%constructor144152%_)
                                  (eq? _%constructor144152%_ _%$e144175%_))
                              (_%lp144149%_ _%rest144172%_ _%$e144175%_)
                              (error '"conflicting implicit constructors"
                                     _%constructor144152%_
                                     _%$e144175%_))
                          (_%lp144149%_
                           _%rest144172%_
                           _%constructor144152%_))))))
            (if (pair? _%$%rest144153144161%_)
                (let ((_%$%hd144158144187%_
                       (let ()
                         (declare (not safe))
                         (##car _%$%rest144153144161%_)))
                      (_%$%tl144159144189%_
                       (let ()
                         (declare (not safe))
                         (##cdr _%$%rest144153144161%_))))
                  (let* ((_%hd144192%_ _%$%hd144158144187%_)
                         (_%rest144194%_ _%$%tl144159144189%_))
                    (_%$%K144157144184%_ _%rest144194%_ _%hd144192%_)))
                (_%$%else144155144169%_))))))
    (define compute-class-slots
      (lambda (_%class-precedence-list144139%_ _%direct-slots144140%_)
        (let ((__tmp148777
               (lambda (_%mixin144142%_)
                 (let ((__tmp148778
                        (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%mixin144142%_
                           '9
                           '#f
                           '#f))))
                   (declare (not safe))
                   (agetq__% 'direct-slots: __tmp148778 '()))))
              (__tmp148776
               (lambda (_%slot-list144144%_ _%slot-table144145%_)
                 (values (list->vector _%slot-list144144%_)
                         _%slot-table144145%_))))
          (declare (not safe))
          (c4-compute-class-slots
           _%class-precedence-list144139%_
           _%direct-slots144140%_
           __tmp148777
           __tmp148776))))
    (define __make-class-type
      (lambda (_%id143966%_
               _%name143967%_
               _%direct-supers143968%_
               _%direct-slots143969%_
               _%properties143970%_
               _%constructor143971%_)
        (let* ((_%id143974%_ _%id143966%_)
               (_%name143982%_ _%name143967%_)
               (_%direct-supers143990%_ _%direct-supers143968%_)
               (_%direct-slots143998%_ _%direct-slots143969%_)
               (_%properties144006%_ _%properties143970%_)
               (_%constructor144014%_ _%constructor143971%_))
          (let ((_%$e144048%_
                 (let* ((_%pred144026%_
                         (lambda (_%$obj144023%_)
                           (not (let ()
                                  (declare (not safe))
                                  (##structure-instance-of?
                                   _%$obj144023%_
                                   'class)))))
                        (_%lst144029%_ _%direct-supers143990%_)
                        (_%pred144034%_ _%pred144026%_))
                   (declare (not safe))
                   (__find _%pred144034%_ _%lst144029%_))))
            (if _%$e144048%_
                (error '"Illegal super class; not a class descriptor"
                       (begin (##write _%id143966%_) (##newline) (##force-output) _%$e144048%_))
                (let ((_%$e144075%_
                       (let* ((_%pred144055%_ __class-type-final?)
                              (_%lst144058%_ _%direct-supers143990%_)
                              (_%pred144063%_ _%pred144055%_))
                         (declare (not safe))
                         (__find _%pred144063%_ _%lst144058%_))))
                  (if _%$e144075%_
                      (error '"Cannot extend final class" _%$e144075%_)
                      '#!void))))
          (let ((_g148779_ (compute-precedence-list _%direct-supers143990%_)))
            (begin
              (let ((_g148780_
                     (let ()
                       (declare (not safe))
                       (if (##values? _g148779_)
                           (##values-length _g148779_)
                           1))))
                (if (not (let () (declare (not safe)) (##fx= _g148780_ 2)))
                    (error "Context expects 2 values" _g148780_)))
              (let ((_%precedence-list144082%_
                     (let () (declare (not safe)) (##values-ref _g148779_ 0)))
                    (_%struct-super144083%_
                     (let () (declare (not safe)) (##values-ref _g148779_ 1))))
                (let ((_g148781_
                       (compute-class-slots
                        _%precedence-list144082%_
                        _%direct-slots143998%_)))
                  (begin
                    (let ((_g148782_
                           (let ()
                             (declare (not safe))
                             (if (##values? _g148781_)
                                 (##values-length _g148781_)
                                 1))))
                      (if (not (let ()
                                 (declare (not safe))
                                 (##fx= _g148782_ 2)))
                          (error "Context expects 2 values" _g148782_)))
                    (let ((_%slot-vector144085%_
                           (let ()
                             (declare (not safe))
                             (##values-ref _g148781_ 0)))
                          (_%slot-table144086%_
                           (let ()
                             (declare (not safe))
                             (##values-ref _g148781_ 1))))
                      (let* ((_%properties144088%_
                              (cons (cons 'direct-slots:
                                          _%direct-slots143998%_)
                                    (cons (cons 'direct-supers:
                                                _%direct-supers143990%_)
                                          _%properties144006%_)))
                             (_%constructor*144093%_
                              (let ((_%$e144090%_ _%constructor144014%_))
                                (if _%$e144090%_
                                    _%$e144090%_
                                    (find-super-constructor
                                     _%direct-supers143990%_))))
                             (_%precedence-list144136%_
                              (if (or (let ()
                                        (declare (not safe))
                                        (agetq__0
                                         'system:
                                         _%properties144088%_))
                                      (memq object::t
                                            _%precedence-list144082%_))
                                  _%precedence-list144082%_
                                  (let _%loop144098%_ ((_%tail144100%_
                                                        _%precedence-list144082%_)
                                                       (_%head144101%_ '()))
                                    (let* ((_%$%tail144102144110%_
                                            _%tail144100%_)
                                           (_%$%else144104144118%_
                                            (lambda ()
                                              (let ((__tmp148783
                                                     (cons object::t
                                                           (cons t::t '()))))
                                                (declare (not safe))
                                                (foldl__0
                                                 cons
                                                 __tmp148783
                                                 _%head144101%_))))
                                           (_%$%K144106144124%_
                                            (lambda (_%rest144121%_
                                                     _%hd144122%_)
                                              (if (eq? _%hd144122%_ t::t)
                                                  (let ((__tmp148784
                                                         (cons object::t
                                                               _%tail144100%_)))
                                                    (declare (not safe))
                                                    (foldl__0
                                                     cons
                                                     __tmp148784
                                                     _%head144101%_))
                                                  (_%loop144098%_
                                                   _%rest144121%_
                                                   (cons _%hd144122%_
                                                         _%head144101%_))))))
                                      (if (pair? _%$%tail144102144110%_)
                                          (let ((_%$%hd144107144127%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%tail144102144110%_)))
                                                (_%$%tl144108144129%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%tail144102144110%_))))
                                            (let* ((_%hd144132%_
                                                    _%$%hd144107144127%_)
                                                   (_%rest144134%_
                                                    _%$%tl144108144129%_))
                                              (_%$%K144106144124%_
                                               _%rest144134%_
                                               _%hd144132%_)))
                                          (_%$%else144104144118%_)))))))
                        (make-class-type-descriptor
                         _%id143974%_
                         _%name143982%_
                         _%struct-super144083%_
                         _%precedence-list144136%_
                         _%slot-vector144085%_
                         _%properties144088%_
                         _%constructor*144093%_
                         _%slot-table144086%_
                         '#f)))))))))))
    (define make-class-type
      (lambda (_%id143891%_
               _%name143892%_
               _%direct-supers143893%_
               _%direct-slots143894%_
               _%properties143895%_
               _%constructor143896%_)
        (if (symbol? _%id143891%_)
            (let ((_%id143900%_ _%id143891%_))
              (if (symbol? _%name143892%_)
                  (let ((_%name143910%_ _%name143892%_))
                    (if (list? _%direct-supers143893%_)
                        (let ((_%direct-supers143920%_
                               _%direct-supers143893%_))
                          (if (list? _%direct-slots143894%_)
                              (let ((_%direct-slots143930%_
                                     _%direct-slots143894%_))
                                (if (list? _%properties143895%_)
                                    (let ((_%properties143940%_
                                           _%properties143895%_))
                                      (if (or (not _%constructor143896%_)
                                              (symbol? _%constructor143896%_))
                                          (let ((_%constructor143956%_
                                                 _%constructor143896%_))
                                            (__make-class-type
                                             _%id143900%_
                                             _%name143910%_
                                             _%direct-supers143920%_
                                             _%direct-slots143930%_
                                             _%properties143940%_
                                             _%constructor143956%_))
                                          (begin
                                            (raise-contract-violation-error
                                             '"contract violation"
                                             'context:
                                             '"\"gerbil/runtime/mop.ss\"@590.24-590.35"
                                             'contract:
                                             '(? (or not symbol?))
                                             'value:
                                             _%constructor143896%_)
                                            '#!void)))
                                    (begin
                                      (raise-contract-violation-error
                                       '"contract violation"
                                       'context:
                                       '"\"gerbil/runtime/mop.ss\"@589.24-589.34"
                                       'contract:
                                       'list?
                                       'value:
                                       _%properties143895%_)
                                      '#!void)))
                              (begin
                                (raise-contract-violation-error
                                 '"contract violation"
                                 'context:
                                 '"\"gerbil/runtime/mop.ss\"@588.24-588.36"
                                 'contract:
                                 'list?
                                 'value:
                                 _%direct-slots143894%_)
                                '#!void)))
                        (begin
                          (raise-contract-violation-error
                           '"contract violation"
                           'context:
                           '"\"gerbil/runtime/mop.ss\"@587.24-587.37"
                           'contract:
                           'list?
                           'value:
                           _%direct-supers143893%_)
                          '#!void)))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@586.24-586.28"
                     'contract:
                     'symbol?
                     'value:
                     _%name143892%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@585.24-585.26"
               'contract:
               'symbol?
               'value:
               _%id143891%_)
              '#!void))))
    (define __class-precedence-list
      (lambda (_%klass143879%_)
        (let ((_%klass143882%_ _%klass143879%_))
          (cons _%klass143882%_
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-ref _%klass143882%_ '6 '#f '#f))))))
    (define class-precedence-list
      (lambda (_%klass143865%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass143865%_ 'class))
            (let ((_%klass143869%_ _%klass143865%_))
              (__class-precedence-list _%klass143869%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@623.30-623.35"
               'contract:
               'class-type?
               'value:
               _%klass143865%_)
              '#!void))))
    (define compute-precedence-list
      (lambda (_%direct-supers143862%_)
        (let ()
          (declare (not safe))
          (c4-linearize__%
           '#f
           class-precedence-list
           class-type-struct?
           eq?
           ##type-name
           '()
           _%direct-supers143862%_))))
    (define __make-class-predicate
      (lambda (_%klass143778%_)
        (let* ((_%klass143781%_ _%klass143778%_)
               (_%tid143790%_
                (let () (declare (not safe)) (##type-id _%klass143781%_))))
          (if (let* ((_%type143792%_ _%klass143781%_)
                     (_%type143797%_ _%type143792%_))
                (__class-type-final? _%type143797%_))
              (lambda (_%$%g143811143813%_)
                (let ()
                  (declare (not safe))
                  (##structure-direct-instance-of?
                   _%$%g143811143813%_
                   _%tid143790%_)))
              (if (let* ((_%klass143816%_ _%klass143781%_)
                         (_%klass143821%_ _%klass143816%_))
                    (__class-type-struct? _%klass143821%_))
                  (lambda (_%$%g143831143833%_)
                    (let ()
                      (declare (not safe))
                      (##structure-instance-of?
                       _%$%g143831143833%_
                       _%tid143790%_)))
                  (lambda (_%$%g143836143838%_)
                    (let* ((_%klass143841%_ _%klass143781%_)
                           (_%obj143844%_ _%$%g143836143838%_)
                           (_%klass143849%_ _%klass143841%_))
                      (__class-instance? _%klass143849%_ _%obj143844%_))))))))
    (define make-class-predicate
      (lambda (_%klass143764%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass143764%_ 'class))
            (let ((_%klass143768%_ _%klass143764%_))
              (__make-class-predicate _%klass143768%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@635.29-635.34"
               'contract:
               'class-type?
               'value:
               _%klass143764%_)
              '#!void))))
    (define __make-class-slot-accessor
      (lambda (_%klass143698%_ _%slot143699%_)
        (let* ((_%klass143702%_ _%klass143698%_)
               (_%slot143710%_ _%slot143699%_)
               (_%field143719%_
                (let ((__tmp148785
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%klass143702%_
                          '8
                          '#f
                          '#f))))
                  (declare (not safe))
                  (symbolic-table-ref __tmp148785 _%slot143710%_ '#f))))
          (if _%field143719%_
              (if (let* ((_%type143723%_ _%klass143702%_)
                         (_%type143728%_ _%type143723%_))
                    (__class-type-final? _%type143728%_))
                  (make-final-slot-accessor
                   _%klass143702%_
                   _%slot143710%_
                   _%field143719%_)
                  (if (let* ((_%klass143743%_ _%klass143702%_)
                             (_%klass143748%_ _%klass143743%_))
                        (__class-type-struct? _%klass143748%_))
                      (make-struct-slot-accessor
                       _%klass143702%_
                       _%slot143710%_
                       _%field143719%_)
                      (if (let ((_%strukt143759%_
                                 (base-struct/1 _%klass143702%_)))
                            (and (let ()
                                   (declare (not safe))
                                   (##structure-instance-of?
                                    _%strukt143759%_
                                    'class))
                                 (let ((__tmp148786
                                        (let ((__tmp148787
                                               (let ()
                                                 (declare (not safe))
                                                 (##unchecked-structure-ref
                                                  _%strukt143759%_
                                                  '7
                                                  '#f
                                                  '#f))))
                                          (declare (not safe))
                                          (##vector-length __tmp148787))))
                                   (declare (not safe))
                                   (##fx< _%field143719%_ __tmp148786))))
                          (make-struct-subclass-slot-accessor
                           _%klass143702%_
                           _%slot143710%_
                           _%field143719%_)
                          (make-class-cached-slot-accessor
                           _%klass143702%_
                           _%slot143710%_
                           _%field143719%_))))
              (let ()
                (error '"unknown slot"
                       'class:
                       _%klass143702%_
                       'slot:
                       _%slot143710%_)
                '#!void)))))
    (define make-class-slot-accessor
      (lambda (_%klass143673%_ _%slot143674%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass143673%_ 'class))
            (let ((_%klass143678%_ _%klass143673%_))
              (if (symbol? _%slot143674%_)
                  (let ((_%slot143688%_ _%slot143674%_))
                    (__make-class-slot-accessor
                     _%klass143678%_
                     _%slot143688%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@666.50-666.54"
                     'contract:
                     'symbol?
                     'value:
                     _%slot143674%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@666.33-666.38"
               'contract:
               'class-type?
               'value:
               _%klass143673%_)
              '#!void))))
    (define __make-class-slot-mutator
      (lambda (_%klass143607%_ _%slot143608%_)
        (let* ((_%klass143611%_ _%klass143607%_)
               (_%slot143619%_ _%slot143608%_)
               (_%field143628%_
                (let ((__tmp148788
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%klass143611%_
                          '8
                          '#f
                          '#f))))
                  (declare (not safe))
                  (symbolic-table-ref __tmp148788 _%slot143619%_ '#f))))
          (if _%field143628%_
              (if (let* ((_%type143632%_ _%klass143611%_)
                         (_%type143637%_ _%type143632%_))
                    (__class-type-final? _%type143637%_))
                  (make-final-slot-mutator
                   _%klass143611%_
                   _%slot143619%_
                   _%field143628%_)
                  (if (let* ((_%klass143652%_ _%klass143611%_)
                             (_%klass143657%_ _%klass143652%_))
                        (__class-type-struct? _%klass143657%_))
                      (make-struct-slot-mutator
                       _%klass143611%_
                       _%slot143619%_
                       _%field143628%_)
                      (if (let ((_%strukt143668%_
                                 (base-struct/1 _%klass143611%_)))
                            (and (let ()
                                   (declare (not safe))
                                   (##structure-instance-of?
                                    _%strukt143668%_
                                    'class))
                                 (let ((__tmp148789
                                        (let ((__tmp148790
                                               (let ()
                                                 (declare (not safe))
                                                 (##unchecked-structure-ref
                                                  _%strukt143668%_
                                                  '7
                                                  '#f
                                                  '#f))))
                                          (declare (not safe))
                                          (##vector-length __tmp148790))))
                                   (declare (not safe))
                                   (##fx< _%field143628%_ __tmp148789))))
                          (make-struct-subclass-slot-mutator
                           _%klass143611%_
                           _%slot143619%_
                           _%field143628%_)
                          (make-class-cached-slot-mutator
                           _%klass143611%_
                           _%slot143619%_
                           _%field143628%_))))
              (let ()
                (error '"unknown slot"
                       'class:
                       _%klass143611%_
                       'slot:
                       _%slot143619%_)
                '#!void)))))
    (define make-class-slot-mutator
      (lambda (_%klass143582%_ _%slot143583%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass143582%_ 'class))
            (let ((_%klass143587%_ _%klass143582%_))
              (if (symbol? _%slot143583%_)
                  (let ((_%slot143597%_ _%slot143583%_))
                    (__make-class-slot-mutator _%klass143587%_ _%slot143597%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@674.49-674.53"
                     'contract:
                     'symbol?
                     'value:
                     _%slot143583%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@674.32-674.37"
               'contract:
               'class-type?
               'value:
               _%klass143582%_)
              '#!void))))
    (define __make-class-slot-unchecked-accessor
      (lambda (_%klass143516%_ _%slot143517%_)
        (let* ((_%klass143520%_ _%klass143516%_)
               (_%slot143528%_ _%slot143517%_)
               (_%field143537%_
                (let ((__tmp148791
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%klass143520%_
                          '8
                          '#f
                          '#f))))
                  (declare (not safe))
                  (symbolic-table-ref __tmp148791 _%slot143528%_ '#f))))
          (if _%field143537%_
              (if (let* ((_%type143541%_ _%klass143520%_)
                         (_%type143546%_ _%type143541%_))
                    (__class-type-final? _%type143546%_))
                  (make-struct-slot-unchecked-accessor
                   _%klass143520%_
                   _%slot143528%_
                   _%field143537%_)
                  (if (let* ((_%klass143561%_ _%klass143520%_)
                             (_%klass143566%_ _%klass143561%_))
                        (__class-type-struct? _%klass143566%_))
                      (make-struct-slot-unchecked-accessor
                       _%klass143520%_
                       _%slot143528%_
                       _%field143537%_)
                      (if (let ((_%strukt143577%_
                                 (base-struct/1 _%klass143520%_)))
                            (and (let ()
                                   (declare (not safe))
                                   (##structure-instance-of?
                                    _%strukt143577%_
                                    'class))
                                 (let ((__tmp148792
                                        (let ((__tmp148793
                                               (let ()
                                                 (declare (not safe))
                                                 (##unchecked-structure-ref
                                                  _%strukt143577%_
                                                  '7
                                                  '#f
                                                  '#f))))
                                          (declare (not safe))
                                          (##vector-length __tmp148793))))
                                   (declare (not safe))
                                   (##fx< _%field143537%_ __tmp148792))))
                          (make-struct-slot-unchecked-accessor
                           _%klass143520%_
                           _%slot143528%_
                           _%field143537%_)
                          (make-class-cached-slot-unchecked-accessor
                           _%klass143520%_
                           _%slot143528%_
                           _%field143537%_))))
              (let ()
                (error '"unknown slot"
                       'class:
                       _%klass143520%_
                       'slot:
                       _%slot143528%_)
                '#!void)))))
    (define make-class-slot-unchecked-accessor
      (lambda (_%klass143491%_ _%slot143492%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass143491%_ 'class))
            (let ((_%klass143496%_ _%klass143491%_))
              (if (symbol? _%slot143492%_)
                  (let ((_%slot143506%_ _%slot143492%_))
                    (__make-class-slot-unchecked-accessor
                     _%klass143496%_
                     _%slot143506%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@682.60-682.64"
                     'contract:
                     'symbol?
                     'value:
                     _%slot143492%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@682.43-682.48"
               'contract:
               'class-type?
               'value:
               _%klass143491%_)
              '#!void))))
    (define __make-class-slot-unchecked-mutator
      (lambda (_%klass143425%_ _%slot143426%_)
        (let* ((_%klass143429%_ _%klass143425%_)
               (_%slot143437%_ _%slot143426%_)
               (_%field143446%_
                (let ((__tmp148794
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%klass143429%_
                          '8
                          '#f
                          '#f))))
                  (declare (not safe))
                  (symbolic-table-ref __tmp148794 _%slot143437%_ '#f))))
          (if _%field143446%_
              (if (let* ((_%type143450%_ _%klass143429%_)
                         (_%type143455%_ _%type143450%_))
                    (__class-type-final? _%type143455%_))
                  (make-struct-slot-unchecked-mutator
                   _%klass143429%_
                   _%slot143437%_
                   _%field143446%_)
                  (if (let* ((_%klass143470%_ _%klass143429%_)
                             (_%klass143475%_ _%klass143470%_))
                        (__class-type-struct? _%klass143475%_))
                      (make-struct-slot-unchecked-mutator
                       _%klass143429%_
                       _%slot143437%_
                       _%field143446%_)
                      (if (let ((_%strukt143486%_
                                 (base-struct/1 _%klass143429%_)))
                            (and (let ()
                                   (declare (not safe))
                                   (##structure-instance-of?
                                    _%strukt143486%_
                                    'class))
                                 (let ((__tmp148795
                                        (let ((__tmp148796
                                               (let ()
                                                 (declare (not safe))
                                                 (##unchecked-structure-ref
                                                  _%strukt143486%_
                                                  '7
                                                  '#f
                                                  '#f))))
                                          (declare (not safe))
                                          (##vector-length __tmp148796))))
                                   (declare (not safe))
                                   (##fx< _%field143446%_ __tmp148795))))
                          (make-struct-slot-unchecked-mutator
                           _%klass143429%_
                           _%slot143437%_
                           _%field143446%_)
                          (make-class-cached-slot-unchecked-mutator
                           _%klass143429%_
                           _%slot143437%_
                           _%field143446%_))))
              (let ()
                (error '"unknown slot"
                       'class:
                       _%klass143429%_
                       'slot:
                       _%slot143437%_)
                '#!void)))))
    (define make-class-slot-unchecked-mutator
      (lambda (_%klass143400%_ _%slot143401%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass143400%_ 'class))
            (let ((_%klass143405%_ _%klass143400%_))
              (if (symbol? _%slot143401%_)
                  (let ((_%slot143415%_ _%slot143401%_))
                    (__make-class-slot-unchecked-mutator
                     _%klass143405%_
                     _%slot143415%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@690.59-690.63"
                     'contract:
                     'symbol?
                     'value:
                     _%slot143401%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@690.42-690.47"
               'contract:
               'class-type?
               'value:
               _%klass143400%_)
              '#!void))))
    (define not-an-instance__%
      (lambda (_%object143384%_ _%class143385%_ _%slot143386%_)
        (apply error
               '"not an instance"
               'object:
               _%object143384%_
               'class:
               _%class143385%_
               (if _%slot143386%_
                   (cons 'slot: (cons _%slot143386%_ '()))
                   '()))))
    (define not-an-instance__0
      (lambda (_%object143391%_ _%class143392%_)
        (let ((_%slot143394%_ '#f))
          (not-an-instance__%
           _%object143391%_
           _%class143392%_
           _%slot143394%_))))
    (define not-an-instance
      (lambda _g148797_
        (let ((_g148798_ (let () (declare (not safe)) (##length _g148797_))))
          (cond ((let () (declare (not safe)) (##fx= _g148798_ 2))
                 (apply not-an-instance__0 _g148797_))
                ((let () (declare (not safe)) (##fx= _g148798_ 3))
                 (apply not-an-instance__% _g148797_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  not-an-instance
                  _g148797_))))))
    (define make-final-slot-accessor
      (lambda (_%klass143377%_ _%slot143378%_ _%field143379%_)
        (lambda (_%obj143381%_)
          (##direct-structure-ref
           _%obj143381%_
           _%field143379%_
           _%klass143377%_
           _%slot143378%_))))
    (define make-final-slot-mutator
      (lambda (_%klass143370%_ _%slot143371%_ _%field143372%_)
        (lambda (_%obj143374%_ _%val143375%_)
          (##direct-structure-set!
           _%obj143374%_
           _%val143375%_
           _%field143372%_
           _%klass143370%_
           _%slot143371%_))))
    (define make-struct-slot-accessor
      (lambda (_%klass143364%_ _%slot143365%_ _%field143366%_)
        (lambda (_%obj143368%_)
          (##structure-ref
           _%obj143368%_
           _%field143366%_
           _%klass143364%_
           _%slot143365%_))))
    (define make-struct-slot-mutator
      (lambda (_%klass143357%_ _%slot143358%_ _%field143359%_)
        (lambda (_%obj143361%_ _%val143362%_)
          (##structure-set!
           _%obj143361%_
           _%val143362%_
           _%field143359%_
           _%klass143357%_
           _%slot143358%_))))
    (define make-struct-slot-unchecked-accessor
      (lambda (_%klass143351%_ _%slot143352%_ _%field143353%_)
        (lambda (_%obj143355%_)
          (let ()
            (declare (not safe))
            (##unchecked-structure-ref
             _%obj143355%_
             _%field143353%_
             _%klass143351%_
             _%slot143352%_)))))
    (define make-struct-slot-unchecked-mutator
      (lambda (_%klass143344%_ _%slot143345%_ _%field143346%_)
        (lambda (_%obj143348%_ _%val143349%_)
          (let ()
            (declare (not safe))
            (##unchecked-structure-set!
             _%obj143348%_
             _%val143349%_
             _%field143346%_
             _%klass143344%_
             _%slot143345%_)))))
    (define make-struct-subclass-slot-accessor
      (lambda (_%klass143317%_ _%slot143318%_ _%field143319%_)
        (lambda (_%obj143321%_)
          (if (let* ((_%klass143323%_ _%klass143317%_)
                     (_%obj143326%_ _%obj143321%_))
                (if (let ()
                      (declare (not safe))
                      (##structure-instance-of? _%klass143323%_ 'class))
                    (let ((_%klass143331%_ _%klass143323%_))
                      (__class-instance? _%klass143331%_ _%obj143326%_))
                    (begin
                      (raise-contract-violation-error
                       '"contract violation"
                       'context:
                       'gerbil/runtime/mop
                       'contract:
                       'class-type?
                       'value:
                       _%klass143323%_)
                      '#!void)))
              (unchecked-slot-ref _%obj143321%_ _%field143319%_)
              (not-an-instance__%
               _%obj143321%_
               _%klass143317%_
               _%slot143318%_)))))
    (define make-struct-subclass-slot-mutator
      (lambda (_%klass143289%_ _%slot143290%_ _%field143291%_)
        (lambda (_%obj143293%_ _%val143294%_)
          (if (let* ((_%klass143296%_ _%klass143289%_)
                     (_%obj143299%_ _%obj143293%_))
                (if (let ()
                      (declare (not safe))
                      (##structure-instance-of? _%klass143296%_ 'class))
                    (let ((_%klass143304%_ _%klass143296%_))
                      (__class-instance? _%klass143304%_ _%obj143299%_))
                    (begin
                      (raise-contract-violation-error
                       '"contract violation"
                       'context:
                       'gerbil/runtime/mop
                       'contract:
                       'class-type?
                       'value:
                       _%klass143296%_)
                      '#!void)))
              (unchecked-field-set!
               _%obj143293%_
               _%field143291%_
               _%val143294%_)
              (not-an-instance__%
               _%obj143293%_
               _%klass143289%_
               _%slot143290%_)))))
    (define make-class-cached-slot-accessor
      (lambda (_%klass143240%_ _%slot143241%_ _%field143242%_)
        (lambda (_%obj143244%_)
          (if (let* ((_%klass143246%_ _%klass143240%_)
                     (_%obj143249%_ _%obj143244%_))
                (if (let ()
                      (declare (not safe))
                      (##structure-instance-of? _%klass143246%_ 'class))
                    (let ((_%klass143254%_ _%klass143246%_))
                      (__direct-instance? _%klass143254%_ _%obj143249%_))
                    (begin
                      (raise-contract-violation-error
                       '"contract violation"
                       'context:
                       'gerbil/runtime/mop
                       'contract:
                       'class-type?
                       'value:
                       _%klass143246%_)
                      '#!void)))
              (unchecked-field-ref _%obj143244%_ _%field143242%_)
              (if (let* ((_%klass143268%_ _%klass143240%_)
                         (_%obj143271%_ _%obj143244%_))
                    (if (let ()
                          (declare (not safe))
                          (##structure-instance-of? _%klass143268%_ 'class))
                        (let ((_%klass143276%_ _%klass143268%_))
                          (__class-instance? _%klass143276%_ _%obj143271%_))
                        (begin
                          (raise-contract-violation-error
                           '"contract violation"
                           'context:
                           'gerbil/runtime/mop
                           'contract:
                           'class-type?
                           'value:
                           _%klass143268%_)
                          '#!void)))
                  (unchecked-slot-ref _%obj143244%_ _%slot143241%_)
                  (not-an-instance__%
                   _%obj143244%_
                   _%klass143240%_
                   _%slot143241%_))))))
    (define make-class-cached-slot-mutator
      (lambda (_%klass143190%_ _%slot143191%_ _%field143192%_)
        (lambda (_%obj143194%_ _%val143195%_)
          (if (let* ((_%klass143197%_ _%klass143190%_)
                     (_%obj143200%_ _%obj143194%_))
                (if (let ()
                      (declare (not safe))
                      (##structure-instance-of? _%klass143197%_ 'class))
                    (let ((_%klass143205%_ _%klass143197%_))
                      (__direct-instance? _%klass143205%_ _%obj143200%_))
                    (begin
                      (raise-contract-violation-error
                       '"contract violation"
                       'context:
                       'gerbil/runtime/mop
                       'contract:
                       'class-type?
                       'value:
                       _%klass143197%_)
                      '#!void)))
              (unchecked-field-set!
               _%obj143194%_
               _%field143192%_
               _%val143195%_)
              (if (let* ((_%klass143219%_ _%klass143190%_)
                         (_%obj143222%_ _%obj143194%_))
                    (if (let ()
                          (declare (not safe))
                          (##structure-instance-of? _%klass143219%_ 'class))
                        (let ((_%klass143227%_ _%klass143219%_))
                          (__class-instance? _%klass143227%_ _%obj143222%_))
                        (begin
                          (raise-contract-violation-error
                           '"contract violation"
                           'context:
                           'gerbil/runtime/mop
                           'contract:
                           'class-type?
                           'value:
                           _%klass143219%_)
                          '#!void)))
                  (unchecked-slot-set!
                   _%obj143194%_
                   _%slot143191%_
                   _%val143195%_)
                  (not-an-instance__%
                   _%obj143194%_
                   _%klass143190%_
                   _%slot143191%_))))))
    (define make-class-cached-slot-unchecked-accessor
      (lambda (_%klass143163%_ _%slot143164%_ _%field143165%_)
        (lambda (_%obj143167%_)
          (if (let* ((_%klass143169%_ _%klass143163%_)
                     (_%obj143172%_ _%obj143167%_))
                (if (let ()
                      (declare (not safe))
                      (##structure-instance-of? _%klass143169%_ 'class))
                    (let ((_%klass143177%_ _%klass143169%_))
                      (__direct-instance? _%klass143177%_ _%obj143172%_))
                    (begin
                      (raise-contract-violation-error
                       '"contract violation"
                       'context:
                       'gerbil/runtime/mop
                       'contract:
                       'class-type?
                       'value:
                       _%klass143169%_)
                      '#!void)))
              (unchecked-field-ref _%obj143167%_ _%field143165%_)
              (unchecked-slot-ref _%obj143167%_ _%slot143164%_)))))
    (define make-class-cached-slot-unchecked-mutator
      (lambda (_%klass143135%_ _%slot143136%_ _%field143137%_)
        (lambda (_%obj143139%_ _%val143140%_)
          (if (let* ((_%klass143142%_ _%klass143135%_)
                     (_%obj143145%_ _%obj143139%_))
                (if (let ()
                      (declare (not safe))
                      (##structure-instance-of? _%klass143142%_ 'class))
                    (let ((_%klass143150%_ _%klass143142%_))
                      (__direct-instance? _%klass143150%_ _%obj143145%_))
                    (begin
                      (raise-contract-violation-error
                       '"contract violation"
                       'context:
                       'gerbil/runtime/mop
                       'contract:
                       'class-type?
                       'value:
                       _%klass143142%_)
                      '#!void)))
              (unchecked-field-set!
               _%obj143139%_
               _%field143137%_
               _%val143140%_)
              (unchecked-slot-set!
               _%obj143139%_
               _%slot143136%_
               _%val143140%_)))))
    (define __class-slot-offset
      (lambda (_%klass143114%_ _%slot143115%_)
        (let* ((_%klass143118%_ _%klass143114%_)
               (_%slot143126%_ _%slot143115%_)
               (__tmp148799
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-ref _%klass143118%_ '8 '#f '#f))))
          (declare (not safe))
          (symbolic-table-ref __tmp148799 _%slot143126%_ '#f))))
    (define class-slot-offset
      (lambda (_%klass143089%_ _%slot143090%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass143089%_ 'class))
            (let ((_%klass143094%_ _%klass143089%_))
              (if (let () (declare (not safe)) (symbolic? _%slot143090%_))
                  (let ((_%slot143104%_ _%slot143090%_))
                    (__class-slot-offset _%klass143094%_ _%slot143104%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@752.43-752.47"
                     'contract:
                     'symbolic?
                     'value:
                     _%slot143090%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@752.26-752.31"
               'contract:
               'class-type?
               'value:
               _%klass143089%_)
              '#!void))))
    (define __class-slot-ref
      (lambda (_%klass143014%_ _%obj143015%_ _%slot143016%_)
        (let* ((_%klass143019%_ _%klass143014%_)
               (_%slot143027%_ _%slot143016%_))
          (if (let* ((_%klass143036%_ _%klass143019%_)
                     (_%obj143039%_ _%obj143015%_)
                     (_%klass143044%_ _%klass143036%_))
                (__class-instance? _%klass143044%_ _%obj143039%_))
              (let ((_%off143087%_
                     (let* ((_%klass143058%_
                             (let ()
                               (declare (not safe))
                               (##structure-type _%obj143015%_)))
                            (_%slot143061%_ _%slot143027%_))
                       (if (let ()
                             (declare (not safe))
                             (##structure-instance-of? _%klass143058%_ 'class))
                           (let ((_%klass143066%_ _%klass143058%_))
                             (if (let ()
                                   (declare (not safe))
                                   (symbolic? _%slot143061%_))
                                 (let ((_%slot143077%_ _%slot143061%_))
                                   (__class-slot-offset
                                    _%klass143066%_
                                    _%slot143077%_))
                                 (begin
                                   (raise-contract-violation-error
                                    '"contract violation"
                                    'context:
                                    'gerbil/runtime/mop
                                    'contract:
                                    'symbolic?
                                    'value:
                                    _%slot143061%_)
                                   '#!void)))
                           (begin
                             (raise-contract-violation-error
                              '"contract violation"
                              'context:
                              'gerbil/runtime/mop
                              'contract:
                              'class-type?
                              'value:
                              _%klass143058%_)
                             '#!void)))))
                (declare (not safe))
                (##unchecked-structure-ref
                 _%obj143015%_
                 _%off143087%_
                 _%klass143019%_
                 _%slot143027%_))
              (not-an-instance__0 _%obj143015%_ _%klass143019%_)))))
    (define class-slot-ref
      (lambda (_%klass142988%_ _%obj142989%_ _%slot142990%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass142988%_ 'class))
            (let ((_%klass142994%_ _%klass142988%_))
              (if (let () (declare (not safe)) (symbolic? _%slot142990%_))
                  (let ((_%slot143004%_ _%slot142990%_))
                    (__class-slot-ref
                     _%klass142994%_
                     _%obj142989%_
                     _%slot143004%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@755.44-755.48"
                     'contract:
                     'symbolic?
                     'value:
                     _%slot142990%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@755.23-755.28"
               'contract:
               'class-type?
               'value:
               _%klass142988%_)
              '#!void))))
    (define __class-slot-set!
      (lambda (_%klass142912%_ _%obj142913%_ _%slot142914%_ _%val142915%_)
        (let* ((_%klass142918%_ _%klass142912%_)
               (_%slot142926%_ _%slot142914%_))
          (if (let* ((_%klass142935%_ _%klass142918%_)
                     (_%obj142938%_ _%obj142913%_)
                     (_%klass142943%_ _%klass142935%_))
                (__class-instance? _%klass142943%_ _%obj142938%_))
              (let ((_%off142986%_
                     (let* ((_%klass142957%_
                             (let ()
                               (declare (not safe))
                               (##structure-type _%obj142913%_)))
                            (_%slot142960%_ _%slot142926%_))
                       (if (let ()
                             (declare (not safe))
                             (##structure-instance-of? _%klass142957%_ 'class))
                           (let ((_%klass142965%_ _%klass142957%_))
                             (if (let ()
                                   (declare (not safe))
                                   (symbolic? _%slot142960%_))
                                 (let ((_%slot142976%_ _%slot142960%_))
                                   (__class-slot-offset
                                    _%klass142965%_
                                    _%slot142976%_))
                                 (begin
                                   (raise-contract-violation-error
                                    '"contract violation"
                                    'context:
                                    'gerbil/runtime/mop
                                    'contract:
                                    'symbolic?
                                    'value:
                                    _%slot142960%_)
                                   '#!void)))
                           (begin
                             (raise-contract-violation-error
                              '"contract violation"
                              'context:
                              'gerbil/runtime/mop
                              'contract:
                              'class-type?
                              'value:
                              _%klass142957%_)
                             '#!void)))))
                (declare (not safe))
                (##unchecked-structure-set!
                 _%obj142913%_
                 _%val142915%_
                 _%off142986%_
                 _%klass142918%_
                 _%slot142926%_))
              (not-an-instance__0 _%obj142913%_ _%klass142918%_)))))
    (define class-slot-set!
      (lambda (_%klass142885%_ _%obj142886%_ _%slot142887%_ _%val142888%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass142885%_ 'class))
            (let ((_%klass142892%_ _%klass142885%_))
              (if (let () (declare (not safe)) (symbolic? _%slot142887%_))
                  (let ((_%slot142902%_ _%slot142887%_))
                    (__class-slot-set!
                     _%klass142892%_
                     _%obj142886%_
                     _%slot142902%_
                     _%val142888%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@761.45-761.49"
                     'contract:
                     'symbolic?
                     'value:
                     _%slot142887%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@761.24-761.29"
               'contract:
               'class-type?
               'value:
               _%klass142885%_)
              '#!void))))
    (define unchecked-field-ref
      (lambda (_%obj142882%_ _%off142883%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-ref _%obj142882%_ _%off142883%_ '#f '#f))))
    (define unchecked-field-set!
      (lambda (_%obj142878%_ _%off142879%_ _%val142880%_)
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           _%obj142878%_
           _%val142880%_
           _%off142879%_
           '#f
           '#f))))
    (define unchecked-slot-ref
      (lambda (_%obj142875%_ _%slot142876%_)
        (unchecked-field-ref
         _%obj142875%_
         (__class-slot-offset
          (let () (declare (not safe)) (##structure-type _%obj142875%_))
          _%slot142876%_))))
    (define unchecked-slot-set!
      (lambda (_%obj142871%_ _%slot142872%_ _%val142873%_)
        (unchecked-field-set!
         _%obj142871%_
         (__class-slot-offset
          (let () (declare (not safe)) (##structure-type _%obj142871%_))
          _%slot142872%_)
         _%val142873%_)))
    (define __slot-error
      (lambda (_%obj142868%_ _%slot142869%_)
        (error '"Cannot find slot"
               'object:
               _%obj142868%_
               'slot:
               _%slot142869%_)))
    (define __slot-ref__%
      (lambda (_%obj142792%_ _%slot142793%_ _%E142794%_)
        (let* ((_%slot142797%_ _%slot142793%_)
               (_%E142805%_ _%E142794%_)
               (_%klass142814%_ (class-of _%obj142792%_))
               (_%$e142850%_
                (let* ((_%klass142817%_ _%klass142814%_)
                       (_%slot142820%_ _%slot142797%_)
                       (_%klass142825%_ _%klass142817%_))
                  (if (let () (declare (not safe)) (symbolic? _%slot142820%_))
                      (let ((_%slot142840%_ _%slot142820%_))
                        (__class-slot-offset _%klass142825%_ _%slot142840%_))
                      (begin
                        (raise-contract-violation-error
                         '"contract violation"
                         'context:
                         'gerbil/runtime/mop
                         'contract:
                         'symbolic?
                         'value:
                         _%slot142820%_)
                        '#!void)))))
          (if _%$e142850%_
              (unchecked-field-ref _%obj142792%_ _%$e142850%_)
              (let ()
                (declare (not safe))
                (_%E142805%_ _%obj142792%_ _%slot142797%_))))))
    (define __slot-ref__0
      (lambda (_%obj142859%_ _%slot142860%_)
        (let ((_%E142862%_ __slot-error))
          (__slot-ref__% _%obj142859%_ _%slot142860%_ _%E142862%_))))
    (define __slot-ref
      (lambda _g148800_
        (let ((_g148801_ (let () (declare (not safe)) (##length _g148800_))))
          (cond ((let () (declare (not safe)) (##fx= _g148801_ 2))
                 (apply __slot-ref__0 _g148800_))
                ((let () (declare (not safe)) (##fx= _g148801_ 3))
                 (apply __slot-ref__% _g148800_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  __slot-ref
                  _g148800_))))))
    (define slot-ref__%
      (lambda (_%obj142753%_ _%slot142754%_ _%E142755%_)
        (if (symbol? _%slot142754%_)
            (let ((_%slot142759%_ _%slot142754%_))
              (if (procedure? _%E142755%_)
                  (let ((_%E142769%_ _%E142755%_))
                    (__slot-ref__% _%obj142753%_ _%slot142759%_ _%E142769%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@787.38-787.39"
                     'contract:
                     'procedure?
                     'value:
                     _%E142755%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@787.21-787.25"
               'contract:
               'symbol?
               'value:
               _%slot142754%_)
              '#!void))))
    (define slot-ref__0
      (lambda (_%obj142782%_ _%slot142783%_)
        (let ((_%E142785%_ __slot-error))
          (slot-ref__% _%obj142782%_ _%slot142783%_ _%E142785%_))))
    (define slot-ref
      (lambda _g148802_
        (let ((_g148803_ (let () (declare (not safe)) (##length _g148802_))))
          (cond ((let () (declare (not safe)) (##fx= _g148803_ 2))
                 (apply slot-ref__0 _g148802_))
                ((let () (declare (not safe)) (##fx= _g148803_ 3))
                 (apply slot-ref__% _g148802_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  slot-ref
                  _g148802_))))))
    (define __slot-set!__%
      (lambda (_%obj142673%_ _%slot142674%_ _%val142675%_ _%E142676%_)
        (let* ((_%slot142679%_ _%slot142674%_)
               (_%E142687%_ _%E142676%_)
               (_%klass142696%_ (class-of _%obj142673%_))
               (_%$e142732%_
                (let* ((_%klass142699%_ _%klass142696%_)
                       (_%slot142702%_ _%slot142679%_)
                       (_%klass142707%_ _%klass142699%_))
                  (if (let () (declare (not safe)) (symbolic? _%slot142702%_))
                      (let ((_%slot142722%_ _%slot142702%_))
                        (__class-slot-offset _%klass142707%_ _%slot142722%_))
                      (begin
                        (raise-contract-violation-error
                         '"contract violation"
                         'context:
                         'gerbil/runtime/mop
                         'contract:
                         'symbolic?
                         'value:
                         _%slot142702%_)
                        '#!void)))))
          (if _%$e142732%_
              (unchecked-field-set! _%obj142673%_ _%$e142732%_ _%val142675%_)
              (let ()
                (declare (not safe))
                (_%E142687%_ _%obj142673%_ _%slot142679%_))))))
    (define __slot-set!__0
      (lambda (_%obj142741%_ _%slot142742%_ _%val142743%_)
        (let ((_%E142745%_ __slot-error))
          (__slot-set!__%
           _%obj142741%_
           _%slot142742%_
           _%val142743%_
           _%E142745%_))))
    (define __slot-set!
      (lambda _g148804_
        (let ((_g148805_ (let () (declare (not safe)) (##length _g148804_))))
          (cond ((let () (declare (not safe)) (##fx= _g148805_ 3))
                 (apply __slot-set!__0 _g148804_))
                ((let () (declare (not safe)) (##fx= _g148805_ 4))
                 (apply __slot-set!__% _g148804_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  __slot-set!
                  _g148804_))))))
    (define slot-set!__%
      (lambda (_%obj142631%_ _%slot142632%_ _%val142633%_ _%E142634%_)
        (if (symbol? _%slot142632%_)
            (let ((_%slot142638%_ _%slot142632%_))
              (if (procedure? _%E142634%_)
                  (let ((_%E142648%_ _%E142634%_))
                    (__slot-set!__%
                     _%obj142631%_
                     _%slot142638%_
                     _%val142633%_
                     _%E142648%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@789.43-789.44"
                     'contract:
                     'procedure?
                     'value:
                     _%E142634%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@789.22-789.26"
               'contract:
               'symbol?
               'value:
               _%slot142632%_)
              '#!void))))
    (define slot-set!__0
      (lambda (_%obj142661%_ _%slot142662%_ _%val142663%_)
        (let ((_%E142665%_ __slot-error))
          (slot-set!__%
           _%obj142661%_
           _%slot142662%_
           _%val142663%_
           _%E142665%_))))
    (define slot-set!
      (lambda _g148806_
        (let ((_g148807_ (let () (declare (not safe)) (##length _g148806_))))
          (cond ((let () (declare (not safe)) (##fx= _g148807_ 3))
                 (apply slot-set!__0 _g148806_))
                ((let () (declare (not safe)) (##fx= _g148807_ 4))
                 (apply slot-set!__% _g148806_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  slot-set!
                  _g148806_))))))
    (define __subclass?
      (lambda (_%maybe-sub-class142602%_ _%maybe-super-class142603%_)
        (let* ((_%maybe-sub-class142606%_ _%maybe-sub-class142602%_)
               (_%maybe-super-class142614%_ _%maybe-super-class142603%_)
               (_%maybe-super-class-id142623%_
                (let ()
                  (declare (not safe))
                  (##type-id _%maybe-super-class142614%_)))
               (_%$e142625%_
                (eq? _%maybe-super-class-id142623%_
                     (let ()
                       (declare (not safe))
                       (##type-id _%maybe-sub-class142606%_)))))
          (if _%$e142625%_
              _%$e142625%_
              (let ((__tmp148809
                     (lambda (_%super-class142628%_)
                       (eq? (let ()
                              (declare (not safe))
                              (##type-id _%super-class142628%_))
                            _%maybe-super-class-id142623%_)))
                    (__tmp148808
                     (let ()
                       (declare (not safe))
                       (##unchecked-structure-ref
                        _%maybe-sub-class142606%_
                        '6
                        '#f
                        '#f))))
                (declare (not safe))
                (ormap__0 __tmp148809 __tmp148808))))))
    (define subclass?
      (lambda (_%maybe-sub-class142577%_ _%maybe-super-class142578%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%maybe-sub-class142577%_ 'class))
            (let ((_%maybe-sub-class142582%_ _%maybe-sub-class142577%_))
              (if (let ()
                    (declare (not safe))
                    (##structure-instance-of?
                     _%maybe-super-class142578%_
                     'class))
                  (let ((_%maybe-super-class142592%_
                         _%maybe-super-class142578%_))
                    (__subclass?
                     _%maybe-sub-class142582%_
                     _%maybe-super-class142592%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@795.45-795.62"
                     'contract:
                     'class-type?
                     'value:
                     _%maybe-super-class142578%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@795.18-795.33"
               'contract:
               'class-type?
               'value:
               _%maybe-sub-class142577%_)
              '#!void))))
    (define object?
      (lambda (_%o142574%_)
        (if (let () (declare (not safe)) (##structure? _%o142574%_))
            (let ((__tmp148810
                   (let ()
                     (declare (not safe))
                     (##structure-type _%o142574%_))))
              (declare (not safe))
              (##structure-instance-of? __tmp148810 'class))
            '#f)))
    (define __direct-instance?
      (lambda (_%klass142561%_ _%obj142562%_)
        (let* ((_%klass142565%_ _%klass142561%_)
               (__tmp148811
                (let () (declare (not safe)) (##type-id _%klass142565%_))))
          (declare (not safe))
          (##structure-direct-instance-of? _%obj142562%_ __tmp148811))))
    (define direct-instance?
      (lambda (_%klass142546%_ _%obj142547%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass142546%_ 'class))
            (let ((_%klass142551%_ _%klass142546%_))
              (__direct-instance? _%klass142551%_ _%obj142547%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@809.25-809.30"
               'contract:
               'class-type?
               'value:
               _%klass142546%_)
              '#!void))))
    (define __struct-instance?
      (lambda (_%klass142533%_ _%obj142534%_)
        (let* ((_%klass142537%_ _%klass142533%_)
               (__tmp148812
                (let () (declare (not safe)) (##type-id _%klass142537%_))))
          (declare (not safe))
          (##structure-instance-of? _%obj142534%_ __tmp148812))))
    (define struct-instance?
      (lambda (_%klass142518%_ _%obj142519%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass142518%_ 'class))
            (let ((_%klass142523%_ _%klass142518%_))
              (__struct-instance? _%klass142523%_ _%obj142519%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@821.25-821.30"
               'contract:
               'class-type?
               'value:
               _%klass142518%_)
              '#!void))))
    (define __class-instance?
      (lambda (_%klass142470%_ _%obj142471%_)
        (let* ((_%klass142474%_ _%klass142470%_)
               (_%type142483%_ (class-of _%obj142471%_))
               (_%maybe-sub-class142485%_ _%type142483%_)
               (_%maybe-super-class142488%_ _%klass142474%_)
               (_%maybe-sub-class142493%_ _%maybe-sub-class142485%_)
               (_%maybe-super-class142508%_ _%maybe-super-class142488%_))
          (__subclass?
           _%maybe-sub-class142493%_
           _%maybe-super-class142508%_))))
    (define class-instance?
      (lambda (_%klass142455%_ _%obj142456%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass142455%_ 'class))
            (let ((_%klass142460%_ _%klass142455%_))
              (__class-instance? _%klass142460%_ _%obj142456%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@833.24-833.29"
               'contract:
               'class-type?
               'value:
               _%klass142455%_)
              '#!void))))
    (define __make-object
      (lambda (_%klass142414%_ _%k142415%_)
        (let* ((_%klass142418%_ _%klass142414%_) (_%k142426%_ _%k142415%_))
          (if (let* ((_%klass142435%_ _%klass142418%_)
                     (_%klass142440%_ _%klass142435%_))
                (__class-type-system? _%klass142440%_))
              (begin
                (error '"cannot instantiate system class"
                       'class:
                       _%klass142418%_)
                '#!void)
              (let ((_%obj142453%_
                     (let ()
                       (declare (not safe))
                       (##make-structure _%klass142418%_ _%k142426%_))))
                (__object-fill! _%obj142453%_ '#f))))))
    (define make-object
      (lambda (_%klass142389%_ _%k142390%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass142389%_ 'class))
            (let ((_%klass142394%_ _%klass142389%_))
              (if (fixnum? _%k142390%_)
                  (let ((_%k142404%_ _%k142390%_))
                    (__make-object _%klass142394%_ _%k142404%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@838.37-838.38"
                     'contract:
                     'fixnum?
                     'value:
                     _%k142390%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@838.20-838.25"
               'contract:
               'class-type?
               'value:
               _%klass142389%_)
              '#!void))))
    (define __object-class
      (lambda (_%obj142377%_)
        (let ((_%obj142380%_ _%obj142377%_))
          (declare (not safe))
          (##structure-type _%obj142380%_))))
    (define object-class
      (lambda (_%obj142363%_)
        (if (object? _%obj142363%_)
            (let ((_%obj142367%_ _%obj142363%_))
              (__object-class _%obj142367%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@858.21-858.24"
               'contract:
               'object?
               'value:
               _%obj142363%_)
              '#!void))))
    (define __object-fill!
      (lambda (_%obj142345%_ _%fill142346%_)
        (let ((_%obj142349%_ _%obj142345%_))
          (let _%loop142358%_ ((_%i142360%_
                                (let ((__tmp148813
                                       (let ()
                                         (declare (not safe))
                                         (##structure-length _%obj142349%_))))
                                  (declare (not safe))
                                  (##fx- __tmp148813 '1))))
            (if (let () (declare (not safe)) (##fx> _%i142360%_ '0))
                (begin
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-set!
                     _%obj142349%_
                     _%fill142346%_
                     _%i142360%_
                     '#f
                     '#f))
                  (_%loop142358%_
                   (let () (declare (not safe)) (##fx- _%i142360%_ '1))))
                _%obj142349%_)))))
    (define object-fill!
      (lambda (_%obj142330%_ _%fill142331%_)
        (if (object? _%obj142330%_)
            (let ((_%obj142335%_ _%obj142330%_))
              (__object-fill! _%obj142335%_ _%fill142331%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@863.21-863.24"
               'contract:
               'object?
               'value:
               _%obj142330%_)
              '#!void))))
    (define __new-instance
      (lambda (_%klass142286%_)
        (let* ((_%klass142289%_ _%klass142286%_)
               (_%klass142298%_ _%klass142289%_)
               (_%k142301%_
                (let ((__tmp148814
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%klass142289%_
                          '7
                          '#f
                          '#f))))
                  (declare (not safe))
                  (##vector-length __tmp148814)))
               (_%klass142306%_ _%klass142298%_)
               (_%k142320%_ _%k142301%_))
          (__make-object _%klass142306%_ _%k142320%_))))
    (define new-instance
      (lambda (_%klass142272%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass142272%_ 'class))
            (let ((_%klass142276%_ _%klass142272%_))
              (__new-instance _%klass142276%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@874.21-874.26"
               'contract:
               'class-type?
               'value:
               _%klass142272%_)
              '#!void))))
    (define __make-instance
      (lambda (_%klass142131%_ . _%args142132%_)
        (let* ((_%klass142135%_ _%klass142131%_)
               (_%$e142144%_
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-ref _%klass142135%_ '10 '#f '#f))))
          (if _%$e142144%_
              (let ((_%obj142169%_
                     (let* ((_%klass142149%_ _%klass142135%_)
                            (_%klass142154%_ _%klass142149%_))
                       (__new-instance _%klass142154%_))))
                (___constructor-init!
                 _%klass142135%_
                 _%$e142144%_
                 _%obj142169%_
                 _%args142132%_)
                _%obj142169%_)
              (if (let* ((_%klass142171%_ _%klass142135%_)
                         (_%klass142176%_ _%klass142171%_))
                    (__class-type-metaclass? _%klass142176%_))
                  (let ((_%obj142203%_
                         (let* ((_%klass142187%_ _%klass142135%_)
                                (_%klass142192%_ _%klass142187%_))
                           (__new-instance _%klass142192%_))))
                    (__metaclass-instance-init!
                     _%klass142135%_
                     _%obj142203%_
                     _%args142132%_)
                    _%obj142203%_)
                  (if (let* ((_%klass142205%_ _%klass142135%_)
                             (_%klass142210%_ _%klass142205%_))
                        (__class-type-struct? _%klass142210%_))
                      (if (let ((__tmp148816
                                 (let* ((_%klass142239%_ _%klass142135%_)
                                        (_%klass142244%_ _%klass142239%_))
                                   (__class-type-field-count _%klass142244%_)))
                                (__tmp148815
                                 (let ()
                                   (declare (not safe))
                                   (##length _%args142132%_))))
                            (declare (not safe))
                            (##fx= __tmp148816 __tmp148815))
                          (apply ##structure _%klass142135%_ _%args142132%_)
                          (let ()
                            (error '"arguments don't match object size"
                                   'class:
                                   _%klass142135%_
                                   'slots:
                                   (let* ((_%klass142256%_ _%klass142135%_)
                                          (_%klass142261%_ _%klass142256%_))
                                     (__class-type-slot-list _%klass142261%_))
                                   'args:
                                   _%args142132%_)
                            '#!void))
                      (let ((_%obj142237%_
                             (let* ((_%klass142221%_ _%klass142135%_)
                                    (_%klass142226%_ _%klass142221%_))
                               (__new-instance _%klass142226%_))))
                        (___class-instance-init!
                         _%klass142135%_
                         _%obj142237%_
                         _%args142132%_)
                        _%obj142237%_)))))))
    (define make-instance
      (lambda (_%klass142116%_ . _%args142117%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass142116%_ 'class))
            (let ((_%klass142121%_ _%klass142116%_))
              (declare (not safe))
              (##apply __make-instance _%klass142121%_ _%args142117%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@877.22-877.27"
               'contract:
               'class-type?
               'value:
               _%klass142116%_)
              '#!void))))
    (define make-class-instance make-instance)
    (define __struct-instance-init!
      (lambda (_%obj142103%_ . _%args142104%_)
        (let ((_%obj142107%_ _%obj142103%_))
          (if (let ((__tmp148818
                     (let () (declare (not safe)) (##length _%args142104%_)))
                    (__tmp148817
                     (let ()
                       (declare (not safe))
                       (##structure-length _%obj142107%_))))
                (declare (not safe))
                (##fx< __tmp148818 __tmp148817))
              (___struct-instance-init! _%obj142107%_ _%args142104%_)
              (error '"too many arguments for struct"
                     'object:
                     _%obj142107%_
                     'args:
                     _%args142104%_))
          '#!void)))
    (define struct-instance-init!
      (lambda (_%obj142088%_ . _%args142089%_)
        (if (object? _%obj142088%_)
            (let ((_%obj142093%_ _%obj142088%_))
              (declare (not safe))
              (##apply __struct-instance-init! _%obj142093%_ _%args142089%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@902.30-902.33"
               'contract:
               'object?
               'value:
               _%obj142088%_)
              '#!void))))
    (define ___struct-instance-init!
      (lambda (_%obj142047%_ _%args142048%_)
        (let _%lp142050%_ ((_%k142052%_ '1) (_%rest142053%_ _%args142048%_))
          (let* ((_%$%rest142054142062%_ _%rest142053%_)
                 (_%$%else142056142070%_ (lambda () _%obj142047%_))
                 (_%$%K142058142076%_
                  (lambda (_%rest142073%_ _%hd142074%_)
                    (unchecked-field-set!
                     _%obj142047%_
                     _%k142052%_
                     _%hd142074%_)
                    (_%lp142050%_
                     (let () (declare (not safe)) (##fx+ _%k142052%_ '1))
                     _%rest142073%_))))
            (if (pair? _%$%rest142054142062%_)
                (let ((_%$%hd142059142079%_
                       (let ()
                         (declare (not safe))
                         (##car _%$%rest142054142062%_)))
                      (_%$%tl142060142081%_
                       (let ()
                         (declare (not safe))
                         (##cdr _%$%rest142054142062%_))))
                  (let* ((_%hd142084%_ _%$%hd142059142079%_)
                         (_%rest142086%_ _%$%tl142060142081%_))
                    (_%$%K142058142076%_ _%rest142086%_ _%hd142084%_)))
                (_%$%else142056142070%_))))))
    (define __class-instance-init!
      (lambda (_%obj142034%_ . _%args142035%_)
        (let ((_%obj142038%_ _%obj142034%_))
          (___class-instance-init!
           (let () (declare (not safe)) (##structure-type _%obj142038%_))
           _%obj142038%_
           _%args142035%_)
          '#!void)))
    (define class-instance-init!
      (lambda (_%obj142019%_ . _%args142020%_)
        (if (object? _%obj142019%_)
            (let ((_%obj142024%_ _%obj142019%_))
              (declare (not safe))
              (##apply __class-instance-init! _%obj142024%_ _%args142020%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@942.29-942.32"
               'contract:
               'object?
               'value:
               _%obj142019%_)
              '#!void))))
    (define ___class-instance-init!
      (lambda (_%klass141961%_ _%obj141962%_ _%args141963%_)
        (let _%lp141965%_ ((_%rest141967%_ _%args141963%_))
          (let* ((_%$%rest141968141978%_ _%rest141967%_)
                 (_%$%else141970141986%_
                  (lambda ()
                    (if (null? _%rest141967%_)
                        _%obj141962%_
                        (error '"unexpected class initializer arguments"
                               'class:
                               _%klass141961%_
                               'rest:
                               _%rest141967%_))))
                 (_%$%K141972142000%_
                  (lambda (_%rest141989%_ _%val141990%_ _%key141991%_)
                    (if (keyword? _%key141991%_)
                        (let ((_%$e141994%_
                               (__class-slot-offset
                                _%klass141961%_
                                _%key141991%_)))
                          (if _%$e141994%_
                              (let ()
                                (unchecked-field-set!
                                 _%obj141962%_
                                 _%$e141994%_
                                 _%val141990%_)
                                (_%lp141965%_ _%rest141989%_))
                              (error '"unknown slot"
                                     'class:
                                     _%klass141961%_
                                     'slot:
                                     _%key141991%_)))
                        (error '"non keyword slot initializer"
                               'slot:
                               _%key141991%_)))))
            (if (pair? _%$%rest141968141978%_)
                (let ((_%$%hd141973142003%_
                       (let ()
                         (declare (not safe))
                         (##car _%$%rest141968141978%_)))
                      (_%$%tl141974142005%_
                       (let ()
                         (declare (not safe))
                         (##cdr _%$%rest141968141978%_))))
                  (let ((_%key142008%_ _%$%hd141973142003%_))
                    (if (pair? _%$%tl141974142005%_)
                        (let ((_%$%hd141975142010%_
                               (let ()
                                 (declare (not safe))
                                 (##car _%$%tl141974142005%_)))
                              (_%$%tl141976142012%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%$%tl141974142005%_))))
                          (let* ((_%val142015%_ _%$%hd141975142010%_)
                                 (_%rest142017%_ _%$%tl141976142012%_))
                            (_%$%K141972142000%_
                             _%rest142017%_
                             _%val142015%_
                             _%key142008%_)))
                        (_%$%else141970141986%_))))
                (_%$%else141970141986%_))))))
    (define __metaclass-instance-init!
      (lambda (_%klass141957%_ _%obj141958%_ _%args141959%_)
        (apply call-method
               _%klass141957%_
               'instance-init!
               _%obj141958%_
               _%args141959%_)))
    (define __constructor-init!
      (lambda (_%klass141926%_
               _%kons-id141927%_
               _%obj141928%_
               .
               _%args141929%_)
        (let* ((_%klass141932%_ _%klass141926%_)
               (_%kons-id141940%_ _%kons-id141927%_)
               (_%obj141948%_ _%obj141928%_))
          (___constructor-init!
           _%klass141932%_
           _%kons-id141940%_
           _%obj141948%_
           _%args141929%_)
          '#!void)))
    (define constructor-init!
      (lambda (_%klass141889%_
               _%kons-id141890%_
               _%obj141891%_
               .
               _%args141892%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass141889%_ 'class))
            (let ((_%klass141896%_ _%klass141889%_))
              (if (symbol? _%kons-id141890%_)
                  (let ((_%kons-id141906%_ _%kons-id141890%_))
                    (if (object? _%obj141891%_)
                        (let ((_%obj141916%_ _%obj141891%_))
                          (declare (not safe))
                          (##apply __constructor-init!
                                   _%klass141896%_
                                   _%kons-id141906%_
                                   _%obj141916%_
                                   _%args141892%_))
                        (begin
                          (raise-contract-violation-error
                           '"contract violation"
                           'context:
                           '"\"gerbil/runtime/mop.ss\"@966.63-966.66"
                           'contract:
                           'object?
                           'value:
                           _%obj141891%_)
                          '#!void)))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@966.43-966.50"
                     'contract:
                     'symbol?
                     'value:
                     _%kons-id141890%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@966.26-966.31"
               'contract:
               'class-type?
               'value:
               _%klass141889%_)
              '#!void))))
    (define ___constructor-init!
      (lambda (_%klass141878%_ _%kons-id141879%_ _%obj141880%_ _%args141881%_)
        (let ((_%$e141883%_
               (__find-method
                _%klass141878%_
                _%obj141880%_
                _%kons-id141879%_)))
          (if _%$e141883%_
              (let ()
                (apply _%$e141883%_ _%obj141880%_ _%args141881%_)
                _%obj141880%_)
              (error '"missing constructor"
                     'class:
                     _%klass141878%_
                     'method:
                     _%kons-id141879%_)))))
    (define __struct-copy
      (lambda (_%struct141866%_)
        (let ((_%struct141869%_ _%struct141866%_))
          (declare (not safe))
          (##structure-copy _%struct141869%_))))
    (define struct-copy
      (lambda (_%struct141852%_)
        (if (object? _%struct141852%_)
            (let ((_%struct141856%_ _%struct141852%_))
              (__struct-copy _%struct141856%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@980.20-980.26"
               'contract:
               'object?
               'value:
               _%struct141852%_)
              '#!void))))
    (define __struct->list
      (lambda (_%obj141833%_)
        (let* ((_%obj141836%_ _%obj141833%_)
               (_%len141845%_
                (let ()
                  (declare (not safe))
                  (##structure-length _%obj141836%_))))
          (let _%recur141847%_ ((_%i141849%_ '0))
            (if (let () (declare (not safe)) (##fx< _%i141849%_ _%len141845%_))
                (cons (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%obj141836%_
                         _%i141849%_
                         '#f
                         '#f))
                      (_%recur141847%_
                       (let () (declare (not safe)) (##fx+ _%i141849%_ '1))))
                '())))))
    (define struct->list
      (lambda (_%obj141819%_)
        (if (object? _%obj141819%_)
            (let ((_%obj141823%_ _%obj141819%_))
              (__struct->list _%obj141823%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@983.21-983.24"
               'contract:
               'object?
               'value:
               _%obj141819%_)
              '#!void))))
    (define __class->list
      (lambda (_%obj141771%_)
        (let* ((_%obj141774%_ _%obj141771%_)
               (_%klass141783%_
                (let () (declare (not safe)) (##structure-type _%obj141774%_)))
               (_%slot-vector141785%_
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-ref _%klass141783%_ '7 '#f '#f))))
          (let _%loop141787%_ ((_%index141789%_
                                (let ((__tmp148819
                                       (let ()
                                         (declare (not safe))
                                         (##vector-length
                                          _%slot-vector141785%_))))
                                  (declare (not safe))
                                  (##fx- __tmp148819 '1)))
                               (_%plist141790%_ '()))
            (if (let () (declare (not safe)) (##fx< _%index141789%_ '1))
                (cons _%klass141783%_ _%plist141790%_)
                (let ((_%slot141793%_
                       (let ()
                         (declare (not safe))
                         (##vector-ref
                          _%slot-vector141785%_
                          _%index141789%_))))
                  (_%loop141787%_
                   (let () (declare (not safe)) (##fx- _%index141789%_ '1))
                   (cons (let ((_%sym141795%_ _%slot141793%_))
                           (if (symbol? _%sym141795%_)
                               (let ((_%sym141800%_ _%sym141795%_))
                                 (declare (not safe))
                                 (__symbol->keyword _%sym141800%_))
                               (begin
                                 (raise-contract-violation-error
                                  '"contract violation"
                                  'context:
                                  'gerbil/runtime/mop
                                  'contract:
                                  'symbol?
                                  'value:
                                  _%sym141795%_)
                                 '#!void)))
                         (cons (unchecked-field-ref
                                _%obj141774%_
                                _%index141789%_)
                               _%plist141790%_)))))))))
    (define class->list
      (lambda (_%obj141757%_)
        (if (object? _%obj141757%_)
            (let ((_%obj141761%_ _%obj141757%_)) (__class->list _%obj141761%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@991.20-991.23"
               'contract:
               'object?
               'value:
               _%obj141757%_)
              '#!void))))
    (define __call-method
      (lambda (_%obj141707%_ _%id141708%_ . _%args141709%_)
        (let* ((_%id141712%_ _%id141708%_)
               (_%$e141743%_
                (let* ((_%obj141721%_ _%obj141707%_)
                       (_%id141724%_ _%id141712%_)
                       (_%id141729%_ _%id141724%_))
                  (__method-ref _%obj141721%_ _%id141729%_))))
          (if _%$e141743%_
              (let ((_%method141748%_ _%$e141743%_))
                (apply _%method141748%_ _%obj141707%_ _%args141709%_))
              (error '"cannot find method"
                     'object:
                     _%obj141707%_
                     'method:
                     _%id141712%_)))))
    (define call-method
      (lambda (_%obj141691%_ _%id141692%_ . _%args141693%_)
        (if (symbol? _%id141692%_)
            (let ((_%id141697%_ _%id141692%_))
              (declare (not safe))
              (##apply __call-method
                       _%obj141691%_
                       _%id141697%_
                       _%args141693%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@1006.24-1006.26"
               'contract:
               'symbol?
               'value:
               _%id141692%_)
              '#!void))))
    (define __method-ref
      (lambda (_%obj141642%_ _%id141643%_)
        (let* ((_%id141646%_ _%id141643%_)
               (_%klass141655%_ (class-of _%obj141642%_))
               (_%obj141658%_ _%obj141642%_)
               (_%id141661%_ _%id141646%_)
               (_%klass141666%_ _%klass141655%_)
               (_%id141681%_ _%id141661%_))
          (__find-method _%klass141666%_ _%obj141658%_ _%id141681%_))))
    (define method-ref
      (lambda (_%obj141627%_ _%id141628%_)
        (if (symbol? _%id141628%_)
            (let ((_%id141632%_ _%id141628%_))
              (__method-ref _%obj141627%_ _%id141632%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@1033.23-1033.25"
               'contract:
               'symbol?
               'value:
               _%id141628%_)
              '#!void))))
    (define checked-method-ref
      (lambda (_%obj141599%_ _%id141600%_)
        (let ((_%$e141624%_
               (let* ((_%obj141603%_ _%obj141599%_)
                      (_%id141606%_ _%id141600%_))
                 (if (symbol? _%id141606%_)
                     (let ((_%id141611%_ _%id141606%_))
                       (__method-ref _%obj141603%_ _%id141611%_))
                     (begin
                       (raise-contract-violation-error
                        '"contract violation"
                        'context:
                        'gerbil/runtime/mop
                        'contract:
                        'symbol?
                        'value:
                        _%id141606%_)
                       '#!void)))))
          (if _%$e141624%_
              _%$e141624%_
              (begin
                (error '"missing method"
                       'object:
                       _%obj141599%_
                       'method:
                       _%id141600%_)
                '#!void)))))
    (define __bound-method-ref
      (lambda (_%obj141548%_ _%id141549%_)
        (let* ((_%id141552%_ _%id141549%_)
               (_%$e141583%_
                (let* ((_%obj141561%_ _%obj141548%_)
                       (_%id141564%_ _%id141552%_)
                       (_%id141569%_ _%id141564%_))
                  (__method-ref _%obj141561%_ _%id141569%_))))
          (if _%$e141583%_
              (let ((_%method141588%_ _%$e141583%_))
                (lambda _%args141596%_
                  (apply _%method141588%_ _%obj141548%_ _%args141596%_)))
              '#f))))
    (define bound-method-ref
      (lambda (_%obj141533%_ _%id141534%_)
        (if (symbol? _%id141534%_)
            (let ((_%id141538%_ _%id141534%_))
              (__bound-method-ref _%obj141533%_ _%id141538%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@1041.29-1041.31"
               'contract:
               'symbol?
               'value:
               _%id141534%_)
              '#!void))))
    (define __checked-bound-method-ref
      (lambda (_%obj141516%_ _%id141517%_)
        (let* ((_%id141520%_ _%id141517%_)
               (_%method141529%_
                (checked-method-ref _%obj141516%_ _%id141520%_)))
          (lambda _%args141531%_
            (apply _%method141529%_ _%obj141516%_ _%args141531%_)))))
    (define checked-bound-method-ref
      (lambda (_%obj141501%_ _%id141502%_)
        (if (symbol? _%id141502%_)
            (let ((_%id141506%_ _%id141502%_))
              (__checked-bound-method-ref _%obj141501%_ _%id141506%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@1050.37-1050.39"
               'contract:
               'symbol?
               'value:
               _%id141502%_)
              '#!void))))
    (define __find-method
      (lambda (_%klass141370%_ _%obj141371%_ _%id141372%_)
        (let* ((_%klass141375%_ _%klass141370%_) (_%id141383%_ _%id141372%_))
          (if (let* ((_%klass141392%_ _%klass141375%_)
                     (_%klass141397%_ _%klass141392%_))
                (__class-type-sealed? _%klass141397%_))
              (let ((_%tab141427%_
                     (let* ((_%klass141411%_ _%klass141375%_)
                            (_%klass141416%_ _%klass141411%_))
                       (__specialize-class _%klass141416%_))))
                (declare (not safe))
                (symbolic-table-ref _%tab141427%_ _%id141383%_ '#f))
              (let ((_%$e141462%_
                     (let* ((_%klass141429%_ _%klass141375%_)
                            (_%obj141432%_ _%obj141371%_)
                            (_%id141435%_ _%id141383%_)
                            (_%klass141440%_ _%klass141429%_)
                            (_%id141452%_ _%id141435%_))
                       (__direct-method-ref
                        _%klass141440%_
                        _%obj141432%_
                        _%id141452%_))))
                (if _%$e141462%_
                    _%$e141462%_
                    (let* ((_%klass141466%_ _%klass141375%_)
                           (_%obj141469%_ _%obj141371%_)
                           (_%id141472%_ _%id141383%_)
                           (_%klass141477%_ _%klass141466%_)
                           (_%id141491%_ _%id141472%_))
                      (__mixin-method-ref
                       _%klass141477%_
                       _%obj141469%_
                       _%id141491%_))))))))
    (define find-method
      (lambda (_%klass141344%_ _%obj141345%_ _%id141346%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass141344%_ 'class))
            (let ((_%klass141350%_ _%klass141344%_))
              (if (symbol? _%id141346%_)
                  (let ((_%id141360%_ _%id141346%_))
                    (__find-method _%klass141350%_ _%obj141345%_ _%id141360%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@1055.41-1055.43"
                     'contract:
                     'symbol?
                     'value:
                     _%id141346%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@1055.20-1055.25"
               'contract:
               'class-type?
               'value:
               _%klass141344%_)
              '#!void))))
    (define __mixin-find-method
      (lambda (_%mixins141289%_ _%obj141290%_ _%id141291%_)
        (let* ((_%id141294%_ _%id141291%_)
               (__tmp148820
                (lambda (_%$%g141302141304%_)
                  (let* ((_%klass141307%_ _%$%g141302141304%_)
                         (_%obj141310%_ _%obj141290%_)
                         (_%id141313%_ _%id141294%_))
                    (if (let ()
                          (declare (not safe))
                          (##structure-instance-of? _%klass141307%_ 'class))
                        (let* ((_%klass141318%_ _%klass141307%_)
                               (_%id141334%_ _%id141313%_))
                          (__direct-method-ref
                           _%klass141318%_
                           _%obj141310%_
                           _%id141334%_))
                        (begin
                          (raise-contract-violation-error
                           '"contract violation"
                           'context:
                           'gerbil/runtime/mop
                           'contract:
                           'class-type?
                           'value:
                           _%klass141307%_)
                          '#!void))))))
          (declare (not safe))
          (ormap__0 __tmp148820 _%mixins141289%_))))
    (define mixin-find-method
      (lambda (_%mixins141273%_ _%obj141274%_ _%id141275%_)
        (if (symbol? _%id141275%_)
            (let ((_%id141279%_ _%id141275%_))
              (__mixin-find-method
               _%mixins141273%_
               _%obj141274%_
               _%id141279%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@1064.37-1064.39"
               'contract:
               'symbol?
               'value:
               _%id141275%_)
              '#!void))))
    (define __direct-method-ref
      (lambda (_%klass141166%_ _%obj141167%_ _%id141168%_)
        (let* ((_%klass141171%_ _%klass141166%_) (_%id141179%_ _%id141168%_))
          (letrec ((_%metaclass-resolve-method141188%_
                    (lambda ()
                      (let* ((_%obj141249%_ _%klass141171%_)
                             (_%id141252%_ 'direct-method-ref)
                             (_%args141255%_ (list _%obj141167%_ _%id141179%_))
                             (_%id141260%_ _%id141252%_))
                        (declare (not safe))
                        (##apply __call-method
                                 _%obj141249%_
                                 _%id141260%_
                                 _%args141255%_))))
                   (_%metaclass-resolve-method!141189%_
                    (lambda ()
                      (let ((_%method141246%_
                             (_%metaclass-resolve-method141188%_)))
                        (let ((__tmp148822
                               (let ()
                                 (declare (not safe))
                                 (##unchecked-structure-ref
                                  _%klass141171%_
                                  '11
                                  '#f
                                  '#f)))
                              (__tmp148821
                               (if _%method141246%_ 'resolved 'unknown)))
                          (declare (not safe))
                          (symbolic-table-set!
                           __tmp148822
                           _%id141179%_
                           __tmp148821))
                        _%method141246%_))))
            (let ((_%$e141191%_
                   (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref _%klass141171%_ '11 '#f '#f))))
              (if _%$e141191%_
                  (let ((_%method141196%_
                         (let ()
                           (declare (not safe))
                           (symbolic-table-ref
                            _%$e141191%_
                            _%id141179%_
                            '#f))))
                    (if (procedure? _%method141196%_)
                        _%method141196%_
                        (if (let* ((_%klass141199%_ _%klass141171%_)
                                   (_%klass141204%_ _%klass141199%_))
                              (__class-type-metaclass? _%klass141204%_))
                            (let ((_%$e141222%_ _%method141196%_))
                              (if (eq? 'resolved _%$e141222%_)
                                  (_%metaclass-resolve-method141188%_)
                                  (if (eq? 'unknown _%$e141222%_)
                                      '#f
                                      (_%metaclass-resolve-method!141189%_))))
                            '#f)))
                  (if (let* ((_%klass141226%_ _%klass141171%_)
                             (_%klass141231%_ _%klass141226%_))
                        (__class-type-metaclass? _%klass141231%_))
                      (let ((_%tab141242%_
                             (let ()
                               (declare (not safe))
                               (make-symbolic-table__% '#f '0))))
                        (let ()
                          (declare (not safe))
                          (##unchecked-structure-set!
                           _%klass141171%_
                           _%tab141242%_
                           '11
                           '#f
                           '#f))
                        (_%metaclass-resolve-method!141189%_))
                      '#f)))))))
    (define direct-method-ref
      (lambda (_%klass141140%_ _%obj141141%_ _%id141142%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass141140%_ 'class))
            (let ((_%klass141146%_ _%klass141140%_))
              (if (symbol? _%id141142%_)
                  (let ((_%id141156%_ _%id141142%_))
                    (__direct-method-ref
                     _%klass141146%_
                     _%obj141141%_
                     _%id141156%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@1067.47-1067.49"
                     'contract:
                     'symbol?
                     'value:
                     _%id141142%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@1067.26-1067.31"
               'contract:
               'class-type?
               'value:
               _%klass141140%_)
              '#!void))))
    (define __mixin-method-ref
      (lambda (_%klass141092%_ _%obj141093%_ _%id141094%_)
        (let* ((_%klass141097%_ _%klass141092%_)
               (_%id141105%_ _%id141094%_)
               (_%mixins141114%_
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-ref _%klass141097%_ '6 '#f '#f)))
               (_%obj141117%_ _%obj141093%_)
               (_%id141120%_ _%id141105%_)
               (_%id141125%_ _%id141120%_))
          (__mixin-find-method _%mixins141114%_ _%obj141117%_ _%id141125%_))))
    (define mixin-method-ref
      (lambda (_%klass141066%_ _%obj141067%_ _%id141068%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass141066%_ 'class))
            (let ((_%klass141072%_ _%klass141066%_))
              (if (symbol? _%id141068%_)
                  (let ((_%id141082%_ _%id141068%_))
                    (__mixin-method-ref
                     _%klass141072%_
                     _%obj141067%_
                     _%id141082%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@1097.46-1097.48"
                     'contract:
                     'symbol?
                     'value:
                     _%id141068%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@1097.25-1097.30"
               'contract:
               'class-type?
               'value:
               _%klass141066%_)
              '#!void))))
    (define __bind-method!__%
      (lambda (_%klass140947%_ _%id140948%_ _%proc140949%_ _%rebind?140950%_)
        (let* ((_%id140953%_ _%id140948%_) (_%proc140961%_ _%proc140949%_))
          (letrec ((_%flush-caches!140970%_
                    (lambda (_%klass141024%_)
                      (if (let ()
                            (declare (not safe))
                            (##unchecked-structure-ref
                             _%klass141024%_
                             '12
                             '#f
                             '#f))
                          (begin
                            (let ()
                              (declare (not safe))
                              (##unchecked-structure-set!
                               _%klass141024%_
                               '#f
                               '12
                               '#f
                               '#f))
                            (if (let ((_%klass141026%_ _%klass141024%_))
                                  (if (let ()
                                        (declare (not safe))
                                        (##structure-instance-of?
                                         _%klass141026%_
                                         'class))
                                      (let ((_%klass141031%_ _%klass141026%_))
                                        (__class-type-sealed? _%klass141031%_))
                                      (begin
                                        (raise-contract-violation-error
                                         '"contract violation"
                                         'context:
                                         'gerbil/runtime/mop
                                         'contract:
                                         'class-type?
                                         'value:
                                         _%klass141026%_)
                                        '#!void)))
                                (let ((__tmp148823
                                       (let ((__tmp148825
                                              (let ()
                                                (declare (not safe))
                                                (##fxnot class-type-flag-sealed)))
                                             (__tmp148824
                                              (let ()
                                                (declare (not safe))
                                                (##type-flags
                                                 _%klass141024%_))))
                                         (declare (not safe))
                                         (##fxand __tmp148825 __tmp148824))))
                                  (declare (not safe))
                                  (##unchecked-structure-set!
                                   _%klass141024%_
                                   __tmp148823
                                   '3
                                   class::t
                                   bind-method!))
                                '#!void))
                          '#!void)
                      (if (and _%rebind?140950%_
                               (let ()
                                 (declare (not safe))
                                 (##unchecked-structure-ref
                                  _%klass141024%_
                                  '13
                                  '#f
                                  '#f)))
                          (let ()
                            (declare (not safe))
                            (##unchecked-structure-set!
                             _%klass141024%_
                             '#f
                             '13
                             '#f
                             '#f))
                          '#!void)
                      (let ((_%$e141042%_
                             (let ()
                               (declare (not safe))
                               (##unchecked-structure-ref
                                _%klass141024%_
                                '9
                                '#f
                                '#f))))
                        (if _%$e141042%_
                            (let ((_%$e141047%_
                                   (let ()
                                     (declare (not safe))
                                     (agetq__0 'subclasses: _%$e141042%_))))
                              (if _%$e141047%_
                                  (for-each
                                   _%flush-caches!140970%_
                                   _%$e141047%_)
                                  '#!void))
                            '#!void))))
                   (_%bind!140971%_
                    (lambda (_%ht141022%_)
                      (if (if _%rebind?140950%_
                              '#f
                              (let ()
                                (declare (not safe))
                                (symbolic-table-ref
                                 _%ht141022%_
                                 _%id140953%_
                                 '#f)))
                          (error '"method already bound"
                                 'class:
                                 _%klass140947%_
                                 'method:
                                 _%id140953%_)
                          (begin
                            (let ()
                              (declare (not safe))
                              (symbolic-table-set!
                               _%ht141022%_
                               _%id140953%_
                               _%proc140961%_))
                            (_%flush-caches!140970%_ _%klass140947%_)
                            '#!void)))))
            (if (let ()
                  (declare (not safe))
                  (##structure-instance-of? _%klass140947%_ 'class))
                (let ((_%ht140974%_
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%klass140947%_
                          '11
                          '#f
                          '#f))))
                  (if _%ht140974%_
                      (_%bind!140971%_ _%ht140974%_)
                      (let ((_%ht140976%_
                             (let ()
                               (declare (not safe))
                               (make-symbolic-table__% '#f '0))))
                        (let ()
                          (declare (not safe))
                          (##unchecked-structure-set!
                           _%klass140947%_
                           _%ht140976%_
                           '11
                           '#f
                           '#f))
                        (_%bind!140971%_ _%ht140976%_))))
                (if (let () (declare (not safe)) (##type? _%klass140947%_))
                    (let* ((_%klass140979%_
                            (__shadow-class__0 _%klass140947%_))
                           (_%id140982%_ _%id140953%_)
                           (_%proc140985%_ _%proc140961%_)
                           (_%rebind?140988%_ _%rebind?140950%_)
                           (_%id140993%_ _%id140982%_)
                           (_%proc141011%_ _%proc140985%_))
                      (__bind-method!__%
                       _%klass140979%_
                       _%id140993%_
                       _%proc141011%_
                       _%rebind?140988%_))
                    (error '"bad class; expected class or builtin type"
                           _%klass140947%_)))))))
    (define __bind-method!__0
      (lambda (_%klass141055%_ _%id141056%_ _%proc141057%_)
        (let ((_%rebind?141059%_ '#f))
          (__bind-method!__%
           _%klass141055%_
           _%id141056%_
           _%proc141057%_
           _%rebind?141059%_))))
    (define __bind-method!
      (lambda _g148826_
        (let ((_g148827_ (let () (declare (not safe)) (##length _g148826_))))
          (cond ((let () (declare (not safe)) (##fx= _g148827_ 3))
                 (apply __bind-method!__0 _g148826_))
                ((let () (declare (not safe)) (##fx= _g148827_ 4))
                 (apply __bind-method!__% _g148826_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  __bind-method!
                  _g148826_))))))
    (define bind-method!__%
      (lambda (_%klass140905%_ _%id140906%_ _%proc140907%_ _%rebind?140908%_)
        (if (symbol? _%id140906%_)
            (let ((_%id140912%_ _%id140906%_))
              (if (procedure? _%proc140907%_)
                  (let ((_%proc140922%_ _%proc140907%_))
                    (__bind-method!__%
                     _%klass140905%_
                     _%id140912%_
                     _%proc140922%_
                     _%rebind?140908%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@1100.42-1100.46"
                     'contract:
                     'procedure?
                     'value:
                     _%proc140907%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@1100.27-1100.29"
               'contract:
               'symbol?
               'value:
               _%id140906%_)
              '#!void))))
    (define bind-method!__0
      (lambda (_%klass140935%_ _%id140936%_ _%proc140937%_)
        (let ((_%rebind?140939%_ '#f))
          (bind-method!__%
           _%klass140935%_
           _%id140936%_
           _%proc140937%_
           _%rebind?140939%_))))
    (define bind-method!
      (lambda _g148828_
        (let ((_g148829_ (let () (declare (not safe)) (##length _g148828_))))
          (cond ((let () (declare (not safe)) (##fx= _g148829_ 3))
                 (apply bind-method!__0 _g148828_))
                ((let () (declare (not safe)) (##fx= _g148829_ 4))
                 (apply bind-method!__% _g148828_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  bind-method!
                  _g148828_))))))
    (define make-method-specializer-table__%
      (lambda (_%size-hint140886%_ _%seed140887%_)
        (let ()
          (declare (not safe))
          (make-raw-table__1
           _%size-hint140886%_
           procedure-hash
           eq?
           _%seed140887%_))))
    (define make-method-specializer-table__0
      (lambda ()
        (let* ((_%size-hint140893%_ '#f) (_%seed140895%_ '0))
          (make-method-specializer-table__%
           _%size-hint140893%_
           _%seed140895%_))))
    (define make-method-specializer-table__1
      (lambda (_%size-hint140897%_)
        (let ((_%seed140899%_ '0))
          (make-method-specializer-table__%
           _%size-hint140897%_
           _%seed140899%_))))
    (define make-method-specializer-table
      (lambda _g148830_
        (let ((_g148831_ (let () (declare (not safe)) (##length _g148830_))))
          (cond ((let () (declare (not safe)) (##fx= _g148831_ 0))
                 (apply make-method-specializer-table__0 _g148830_))
                ((let () (declare (not safe)) (##fx= _g148831_ 1))
                 (apply make-method-specializer-table__1 _g148830_))
                ((let () (declare (not safe)) (##fx= _g148831_ 2))
                 (apply make-method-specializer-table__% _g148830_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  make-method-specializer-table
                  _g148830_))))))
    (define make-method-specializer-table/lock__%
      (lambda (_%size-hint140866%_ _%seed140868%_)
        (let ()
          (declare (not safe))
          (make-raw-table/lock__%
           _%size-hint140866%_
           procedure-hash
           eq?
           _%seed140868%_))))
    (define make-method-specializer-table/lock__0
      (lambda ()
        (let* ((_%size-hint140874%_ '#f) (_%seed140876%_ '0))
          (make-method-specializer-table/lock__%
           _%size-hint140874%_
           _%seed140876%_))))
    (define make-method-specializer-table/lock__1
      (lambda (_%size-hint140878%_)
        (let ((_%seed140880%_ '0))
          (make-method-specializer-table/lock__%
           _%size-hint140878%_
           _%seed140880%_))))
    (define make-method-specializer-table/lock
      (lambda _g148832_
        (let ((_g148833_ (let () (declare (not safe)) (##length _g148832_))))
          (cond ((let () (declare (not safe)) (##fx= _g148833_ 0))
                 (apply make-method-specializer-table/lock__0 _g148832_))
                ((let () (declare (not safe)) (##fx= _g148833_ 1))
                 (apply make-method-specializer-table/lock__1 _g148832_))
                ((let () (declare (not safe)) (##fx= _g148833_ 2))
                 (apply make-method-specializer-table/lock__% _g148832_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  make-method-specializer-table/lock
                  _g148832_))))))
    (define method-specializer-table-ref
      (lambda (_%tab140819%_ _%key140820%_ _%default140821%_)
        (let ((_%table140823%_
               (let () (declare (not safe)) (&raw-table-table _%tab140819%_)))
              (_%seed140824%_
               (let () (declare (not safe)) (&raw-table-seed _%tab140819%_))))
          (let* ((_%h140826%_
                  (fxxor (let ()
                           (declare (not safe))
                           (procedure-hash _%key140820%_))
                         _%seed140824%_))
                 (_%size140829%_ (vector-length _%table140823%_))
                 (_%entries140832%_
                  (let ()
                    (declare (not safe))
                    (##fxquotient _%size140829%_ '2)))
                 (_%start140835%_
                  (let ((__tmp148834
                         (let ()
                           (declare (not safe))
                           (##fxmodulo _%h140826%_ _%entries140832%_))))
                    (declare (not safe))
                    (##fxarithmetic-shift-left __tmp148834 '1))))
            (let _%loop140839%_ ((_%probe140842%_ _%start140835%_)
                                 (_%i140844%_ '1)
                                 (_%deleted140846%_ '#f))
              (let ((_%k140849%_ (vector-ref _%table140823%_ _%probe140842%_)))
                (if (eq? _%k140849%_ (macro-unused-obj))
                    _%default140821%_
                    (if (eq? _%k140849%_ (macro-deleted-obj))
                        (_%loop140839%_
                         (let ((_%next-probe140854%_
                                (fx+ _%start140835%_
                                     _%i140844%_
                                     (fx* _%i140844%_ _%i140844%_))))
                           (declare (not safe))
                           (##fxmodulo _%next-probe140854%_ _%size140829%_))
                         (let () (declare (not safe)) (##fx+ _%i140844%_ '1))
                         (let ((_%$e140857%_ _%deleted140846%_))
                           (if _%$e140857%_ _%$e140857%_ _%probe140842%_)))
                        (if (eq? _%key140820%_ _%k140849%_)
                            (vector-ref
                             _%table140823%_
                             (let ()
                               (declare (not safe))
                               (##fx+ _%probe140842%_ '1)))
                            (_%loop140839%_
                             (let ((_%next-probe140862%_
                                    (fx+ _%start140835%_
                                         _%i140844%_
                                         (fx* _%i140844%_ _%i140844%_))))
                               (declare (not safe))
                               (##fxmodulo
                                _%next-probe140862%_
                                _%size140829%_))
                             (let ()
                               (declare (not safe))
                               (##fx+ _%i140844%_ '1))
                             _%deleted140846%_))))))))))
    (define method-specializer-table-ref/lock
      (lambda (_%tab140790%_ _%key140791%_ _%default140792%_)
        (let ((_%lock140794%_
               (let () (declare (not safe)) (&raw-table-lock _%tab140790%_))))
          (let ()
            (declare (not interrupts-enabled))
            (let _%again140799%_ ((_%spin140802%_ '0))
              (if (let ((__tmp148835
                         (let ()
                           (declare (not safe))
                           (##vector-cas! _%lock140794%_ '0 '1 '0))))
                    (declare (not safe))
                    (##fx= __tmp148835 '0))
                  (let ((__tmp148836 (current-thread)))
                    (declare (not safe))
                    (##vector-set! _%lock140794%_ '1 __tmp148836))
                  (if (let () (declare (not safe)) (##fx< _%spin140802%_ '10))
                      (_%again140799%_
                       (let () (declare (not safe)) (##fx+ _%spin140802%_ '1)))
                      (let ((_%owner140808%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%lock140794%_ '1))))
                        (if (eq? _%owner140808%_ (macro-current-thread))
                            (let ()
                              (declare (not safe))
                              (##thread-deadlock-action!))
                            (if (macro-thread-end-condvar _%owner140808%_)
                                (let ()
                                  (let ()
                                    (declare (not safe))
                                    (##thread-yield!))
                                  (_%again140799%_ '0))
                                (let ()
                                  (declare (not safe))
                                  (##thread-deadlock-action!)))))))))
          (let ((_%$r140814%_
                 (method-specializer-table-ref
                  _%tab140790%_
                  _%key140791%_
                  _%default140792%_)))
            (let ()
              (declare (not interrupts-enabled))
              (begin
                (let ()
                  (declare (not safe))
                  (##vector-set! _%lock140794%_ '1 '#f))
                (let ()
                  (declare (not safe))
                  (##vector-cas! _%lock140794%_ '0 '0 '1))))
            _%$r140814%_))))
    (define __method-specializer-table-set!
      (lambda (_%tab140742%_ _%key140743%_ _%value140744%_)
        (let ((_%table140746%_
               (let () (declare (not safe)) (&raw-table-table _%tab140742%_)))
              (_%seed140747%_
               (let () (declare (not safe)) (&raw-table-seed _%tab140742%_))))
          (let* ((_%h140749%_
                  (fxxor (let ()
                           (declare (not safe))
                           (procedure-hash _%key140743%_))
                         _%seed140747%_))
                 (_%size140752%_ (vector-length _%table140746%_))
                 (_%entries140755%_
                  (let ()
                    (declare (not safe))
                    (##fxquotient _%size140752%_ '2)))
                 (_%start140758%_
                  (let ((__tmp148837
                         (let ()
                           (declare (not safe))
                           (##fxmodulo _%h140749%_ _%entries140755%_))))
                    (declare (not safe))
                    (##fxarithmetic-shift-left __tmp148837 '1))))
            (let _%loop140762%_ ((_%probe140765%_ _%start140758%_)
                                 (_%i140767%_ '1)
                                 (_%deleted140769%_ '#f))
              (let ((_%k140772%_ (vector-ref _%table140746%_ _%probe140765%_)))
                (if (eq? _%k140772%_ (macro-unused-obj))
                    (if _%deleted140769%_
                        (begin
                          (vector-set!
                           _%table140746%_
                           _%deleted140769%_
                           _%key140743%_)
                          (vector-set!
                           _%table140746%_
                           (let ()
                             (declare (not safe))
                             (##fx+ _%deleted140769%_ '1))
                           _%value140744%_)
                          (let ((__tmp148838
                                 (let ((__tmp148839
                                        (let ()
                                          (declare (not safe))
                                          (&raw-table-count _%tab140742%_))))
                                   (declare (not safe))
                                   (##fx+ __tmp148839 '1))))
                            (declare (not safe))
                            (&raw-table-count-set! _%tab140742%_ __tmp148838)))
                        (begin
                          (vector-set!
                           _%table140746%_
                           _%probe140765%_
                           _%key140743%_)
                          (vector-set!
                           _%table140746%_
                           (let ()
                             (declare (not safe))
                             (##fx+ _%probe140765%_ '1))
                           _%value140744%_)
                          (let ()
                            (let ((__tmp148840
                                   (let ((__tmp148841
                                          (let ()
                                            (declare (not safe))
                                            (&raw-table-free _%tab140742%_))))
                                     (declare (not safe))
                                     (##fx- __tmp148841 '1))))
                              (declare (not safe))
                              (&raw-table-free-set! _%tab140742%_ __tmp148840))
                            (let ((__tmp148842
                                   (let ((__tmp148843
                                          (let ()
                                            (declare (not safe))
                                            (&raw-table-count _%tab140742%_))))
                                     (declare (not safe))
                                     (##fx+ __tmp148843 '1))))
                              (declare (not safe))
                              (&raw-table-count-set!
                               _%tab140742%_
                               __tmp148842)))))
                    (if (eq? _%k140772%_ (macro-deleted-obj))
                        (_%loop140762%_
                         (let ((_%next-probe140779%_
                                (fx+ _%start140758%_
                                     _%i140767%_
                                     (fx* _%i140767%_ _%i140767%_))))
                           (declare (not safe))
                           (##fxmodulo _%next-probe140779%_ _%size140752%_))
                         (let () (declare (not safe)) (##fx+ _%i140767%_ '1))
                         (let ((_%$e140782%_ _%deleted140769%_))
                           (if _%$e140782%_ _%$e140782%_ _%probe140765%_)))
                        (if (eq? _%key140743%_ _%k140772%_)
                            (let ()
                              (vector-set!
                               _%table140746%_
                               _%probe140765%_
                               _%key140743%_)
                              (vector-set!
                               _%table140746%_
                               (let ()
                                 (declare (not safe))
                                 (##fx+ _%probe140765%_ '1))
                               _%value140744%_))
                            (_%loop140762%_
                             (let ((_%next-probe140787%_
                                    (fx+ _%start140758%_
                                         _%i140767%_
                                         (fx* _%i140767%_ _%i140767%_))))
                               (declare (not safe))
                               (##fxmodulo
                                _%next-probe140787%_
                                _%size140752%_))
                             (let ()
                               (declare (not safe))
                               (##fx+ _%i140767%_ '1))
                             _%deleted140769%_))))))))))
    (define method-specializer-table-set!
      (lambda (_%tab140738%_ _%key140739%_ _%value140740%_)
        (if (let ((__tmp148846
                   (let ()
                     (declare (not safe))
                     (&raw-table-free _%tab140738%_)))
                  (__tmp148844
                   (let ((__tmp148845
                          (vector-length
                           (let ()
                             (declare (not safe))
                             (&raw-table-table _%tab140738%_)))))
                     (declare (not safe))
                     (##fxquotient __tmp148845 '4))))
              (declare (not safe))
              (##fx< __tmp148846 __tmp148844))
            (let () (declare (not safe)) (__raw-table-rehash! _%tab140738%_))
            '#!void)
        (__method-specializer-table-set!
         _%tab140738%_
         _%key140739%_
         _%value140740%_)))
    (define method-specializer-table-set!/lock
      (lambda (_%tab140708%_ _%key140709%_ _%value140710%_)
        (let ((_%lock140713%_
               (let () (declare (not safe)) (&raw-table-lock _%tab140708%_))))
          (let ()
            (declare (not interrupts-enabled))
            (let _%again140718%_ ((_%spin140721%_ '0))
              (if (let ((__tmp148847
                         (let ()
                           (declare (not safe))
                           (##vector-cas! _%lock140713%_ '0 '1 '0))))
                    (declare (not safe))
                    (##fx= __tmp148847 '0))
                  (let ((__tmp148848 (current-thread)))
                    (declare (not safe))
                    (##vector-set! _%lock140713%_ '1 __tmp148848))
                  (if (let () (declare (not safe)) (##fx< _%spin140721%_ '10))
                      (_%again140718%_
                       (let () (declare (not safe)) (##fx+ _%spin140721%_ '1)))
                      (let ((_%owner140727%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%lock140713%_ '1))))
                        (if (eq? _%owner140727%_ (macro-current-thread))
                            (let ()
                              (declare (not safe))
                              (##thread-deadlock-action!))
                            (if (macro-thread-end-condvar _%owner140727%_)
                                (let ()
                                  (let ()
                                    (declare (not safe))
                                    (##thread-yield!))
                                  (_%again140718%_ '0))
                                (let ()
                                  (declare (not safe))
                                  (##thread-deadlock-action!)))))))))
          (let ((_%$r140733%_
                 (method-specializer-table-set!
                  _%tab140708%_
                  _%key140709%_
                  _%value140710%_)))
            (let ()
              (declare (not interrupts-enabled))
              (begin
                (let ()
                  (declare (not safe))
                  (##vector-set! _%lock140713%_ '1 '#f))
                (let ()
                  (declare (not safe))
                  (##vector-cas! _%lock140713%_ '0 '0 '1))))
            _%$r140733%_))))
    (define __method-specializer-table-update!
      (lambda (_%tab140659%_
               _%key140660%_
               _%method-specializer-table-update!140661%_
               _%default140662%_)
        (let ((_%table140664%_
               (let () (declare (not safe)) (&raw-table-table _%tab140659%_)))
              (_%seed140665%_
               (let () (declare (not safe)) (&raw-table-seed _%tab140659%_))))
          (let* ((_%h140667%_
                  (fxxor (let ()
                           (declare (not safe))
                           (procedure-hash _%key140660%_))
                         _%seed140665%_))
                 (_%size140670%_ (vector-length _%table140664%_))
                 (_%entries140673%_
                  (let ()
                    (declare (not safe))
                    (##fxquotient _%size140670%_ '2)))
                 (_%start140676%_
                  (let ((__tmp148849
                         (let ()
                           (declare (not safe))
                           (##fxmodulo _%h140667%_ _%entries140673%_))))
                    (declare (not safe))
                    (##fxarithmetic-shift-left __tmp148849 '1))))
            (let _%loop140680%_ ((_%probe140683%_ _%start140676%_)
                                 (_%i140685%_ '1)
                                 (_%deleted140687%_ '#f))
              (let ((_%k140690%_ (vector-ref _%table140664%_ _%probe140683%_)))
                (if (eq? _%k140690%_ (macro-unused-obj))
                    (if _%deleted140687%_
                        (begin
                          (vector-set!
                           _%table140664%_
                           _%deleted140687%_
                           _%key140660%_)
                          (vector-set!
                           _%table140664%_
                           (let ()
                             (declare (not safe))
                             (##fx+ _%deleted140687%_ '1))
                           (_%method-specializer-table-update!140661%_
                            _%default140662%_))
                          (let ((__tmp148850
                                 (let ((__tmp148851
                                        (let ()
                                          (declare (not safe))
                                          (&raw-table-count _%tab140659%_))))
                                   (declare (not safe))
                                   (##fx+ __tmp148851 '1))))
                            (declare (not safe))
                            (&raw-table-count-set! _%tab140659%_ __tmp148850)))
                        (begin
                          (vector-set!
                           _%table140664%_
                           _%probe140683%_
                           _%key140660%_)
                          (vector-set!
                           _%table140664%_
                           (let ()
                             (declare (not safe))
                             (##fx+ _%probe140683%_ '1))
                           (_%method-specializer-table-update!140661%_
                            _%default140662%_))
                          (let ()
                            (let ((__tmp148852
                                   (let ((__tmp148853
                                          (let ()
                                            (declare (not safe))
                                            (&raw-table-free _%tab140659%_))))
                                     (declare (not safe))
                                     (##fx- __tmp148853 '1))))
                              (declare (not safe))
                              (&raw-table-free-set! _%tab140659%_ __tmp148852))
                            (let ((__tmp148854
                                   (let ((__tmp148855
                                          (let ()
                                            (declare (not safe))
                                            (&raw-table-count _%tab140659%_))))
                                     (declare (not safe))
                                     (##fx+ __tmp148855 '1))))
                              (declare (not safe))
                              (&raw-table-count-set!
                               _%tab140659%_
                               __tmp148854)))))
                    (if (eq? _%k140690%_ (macro-deleted-obj))
                        (_%loop140680%_
                         (let ((_%next-probe140697%_
                                (fx+ _%start140676%_
                                     _%i140685%_
                                     (fx* _%i140685%_ _%i140685%_))))
                           (declare (not safe))
                           (##fxmodulo _%next-probe140697%_ _%size140670%_))
                         (let () (declare (not safe)) (##fx+ _%i140685%_ '1))
                         (let ((_%$e140700%_ _%deleted140687%_))
                           (if _%$e140700%_ _%$e140700%_ _%probe140683%_)))
                        (if (eq? _%key140660%_ _%k140690%_)
                            (let ()
                              (vector-set!
                               _%table140664%_
                               _%probe140683%_
                               _%key140660%_)
                              (vector-set!
                               _%table140664%_
                               (let ()
                                 (declare (not safe))
                                 (##fx+ _%probe140683%_ '1))
                               (_%method-specializer-table-update!140661%_
                                (vector-ref
                                 _%table140664%_
                                 (let ()
                                   (declare (not safe))
                                   (##fx+ _%probe140683%_ '1))))))
                            (_%loop140680%_
                             (let ((_%next-probe140705%_
                                    (fx+ _%start140676%_
                                         _%i140685%_
                                         (fx* _%i140685%_ _%i140685%_))))
                               (declare (not safe))
                               (##fxmodulo
                                _%next-probe140705%_
                                _%size140670%_))
                             (let ()
                               (declare (not safe))
                               (##fx+ _%i140685%_ '1))
                             _%deleted140687%_))))))))))
    (define method-specializer-table-update!
      (lambda (_%tab140654%_
               _%key140655%_
               _%method-specializer-table-update!140656%_
               _%default140657%_)
        (if (let ((__tmp148858
                   (let ()
                     (declare (not safe))
                     (&raw-table-free _%tab140654%_)))
                  (__tmp148856
                   (let ((__tmp148857
                          (vector-length
                           (let ()
                             (declare (not safe))
                             (&raw-table-table _%tab140654%_)))))
                     (declare (not safe))
                     (##fxquotient __tmp148857 '4))))
              (declare (not safe))
              (##fx< __tmp148858 __tmp148856))
            (let () (declare (not safe)) (__raw-table-rehash! _%tab140654%_))
            '#!void)
        (__method-specializer-table-update!
         _%tab140654%_
         _%key140655%_
         _%method-specializer-table-update!140656%_
         _%default140657%_)))
    (define method-specializer-table-update!/lock
      (lambda (_%tab140623%_
               _%key140624%_
               _%method-specializer-table-update!140625%_
               _%default140626%_)
        (let ((_%lock140629%_
               (let () (declare (not safe)) (&raw-table-lock _%tab140623%_))))
          (let ()
            (declare (not interrupts-enabled))
            (let _%again140634%_ ((_%spin140637%_ '0))
              (if (let ((__tmp148859
                         (let ()
                           (declare (not safe))
                           (##vector-cas! _%lock140629%_ '0 '1 '0))))
                    (declare (not safe))
                    (##fx= __tmp148859 '0))
                  (let ((__tmp148860 (current-thread)))
                    (declare (not safe))
                    (##vector-set! _%lock140629%_ '1 __tmp148860))
                  (if (let () (declare (not safe)) (##fx< _%spin140637%_ '10))
                      (_%again140634%_
                       (let () (declare (not safe)) (##fx+ _%spin140637%_ '1)))
                      (let ((_%owner140643%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%lock140629%_ '1))))
                        (if (eq? _%owner140643%_ (macro-current-thread))
                            (let ()
                              (declare (not safe))
                              (##thread-deadlock-action!))
                            (if (macro-thread-end-condvar _%owner140643%_)
                                (let ()
                                  (let ()
                                    (declare (not safe))
                                    (##thread-yield!))
                                  (_%again140634%_ '0))
                                (let ()
                                  (declare (not safe))
                                  (##thread-deadlock-action!)))))))))
          (let ((_%$r140649%_
                 (_%method-specializer-table-update!140625%_
                  _%tab140623%_
                  _%key140624%_
                  _%method-specializer-table-update!140625%_
                  _%default140626%_)))
            (let ()
              (declare (not interrupts-enabled))
              (begin
                (let ()
                  (declare (not safe))
                  (##vector-set! _%lock140629%_ '1 '#f))
                (let ()
                  (declare (not safe))
                  (##vector-cas! _%lock140629%_ '0 '0 '1))))
            _%$r140649%_))))
    (define method-specializer-table-delete!
      (lambda (_%tab140580%_ _%key140581%_)
        (let ((_%table140583%_
               (let () (declare (not safe)) (&raw-table-table _%tab140580%_)))
              (_%seed140585%_
               (let () (declare (not safe)) (&raw-table-seed _%tab140580%_))))
          (let* ((_%h140588%_
                  (fxxor (let ()
                           (declare (not safe))
                           (procedure-hash _%key140581%_))
                         _%seed140585%_))
                 (_%size140591%_ (vector-length _%table140583%_))
                 (_%entries140594%_
                  (let ()
                    (declare (not safe))
                    (##fxquotient _%size140591%_ '2)))
                 (_%start140597%_
                  (let ((__tmp148861
                         (let ()
                           (declare (not safe))
                           (##fxmodulo _%h140588%_ _%entries140594%_))))
                    (declare (not safe))
                    (##fxarithmetic-shift-left __tmp148861 '1))))
            (let _%loop140601%_ ((_%probe140604%_ _%start140597%_)
                                 (_%i140606%_ '1))
              (let ((_%k140609%_ (vector-ref _%table140583%_ _%probe140604%_)))
                (if (eq? _%k140609%_ (macro-unused-obj))
                    '#!void
                    (if (eq? _%k140609%_ (macro-deleted-obj))
                        (_%loop140601%_
                         (let ((_%next-probe140614%_
                                (fx+ _%start140597%_
                                     _%i140606%_
                                     (fx* _%i140606%_ _%i140606%_))))
                           (declare (not safe))
                           (##fxmodulo _%next-probe140614%_ _%size140591%_))
                         (let () (declare (not safe)) (##fx+ _%i140606%_ '1)))
                        (if (eq? _%key140581%_ _%k140609%_)
                            (let ()
                              (vector-set!
                               _%table140583%_
                               _%probe140604%_
                               (macro-deleted-obj))
                              (vector-set!
                               _%table140583%_
                               (let ()
                                 (declare (not safe))
                                 (##fx+ _%probe140604%_ '1))
                               (macro-absent-obj))
                              (let ((__tmp148862
                                     (let ((__tmp148863
                                            (let ()
                                              (declare (not safe))
                                              (&raw-table-count
                                               _%tab140580%_))))
                                       (declare (not safe))
                                       (##fx- __tmp148863 '1))))
                                (declare (not safe))
                                (&raw-table-count-set!
                                 _%tab140580%_
                                 __tmp148862)))
                            (_%loop140601%_
                             (let ((_%next-probe140620%_
                                    (fx+ _%start140597%_
                                         _%i140606%_
                                         (fx* _%i140606%_ _%i140606%_))))
                               (declare (not safe))
                               (##fxmodulo
                                _%next-probe140620%_
                                _%size140591%_))
                             (let ()
                               (declare (not safe))
                               (##fx+ _%i140606%_ '1))))))))))))
    (define method-specializer-table-delete!/lock
      (lambda (_%tab140550%_ _%key140552%_)
        (let ((_%lock140555%_
               (let () (declare (not safe)) (&raw-table-lock _%tab140550%_))))
          (let ()
            (declare (not interrupts-enabled))
            (let _%again140560%_ ((_%spin140563%_ '0))
              (if (let ((__tmp148864
                         (let ()
                           (declare (not safe))
                           (##vector-cas! _%lock140555%_ '0 '1 '0))))
                    (declare (not safe))
                    (##fx= __tmp148864 '0))
                  (let ((__tmp148865 (current-thread)))
                    (declare (not safe))
                    (##vector-set! _%lock140555%_ '1 __tmp148865))
                  (if (let () (declare (not safe)) (##fx< _%spin140563%_ '10))
                      (_%again140560%_
                       (let () (declare (not safe)) (##fx+ _%spin140563%_ '1)))
                      (let ((_%owner140569%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%lock140555%_ '1))))
                        (if (eq? _%owner140569%_ (macro-current-thread))
                            (let ()
                              (declare (not safe))
                              (##thread-deadlock-action!))
                            (if (macro-thread-end-condvar _%owner140569%_)
                                (let ()
                                  (let ()
                                    (declare (not safe))
                                    (##thread-yield!))
                                  (_%again140560%_ '0))
                                (let ()
                                  (declare (not safe))
                                  (##thread-deadlock-action!)))))))))
          (let ((_%$r140575%_
                 (method-specializer-table-delete!
                  _%tab140550%_
                  _%key140552%_)))
            (let ()
              (declare (not interrupts-enabled))
              (begin
                (let ()
                  (declare (not safe))
                  (##vector-set! _%lock140555%_ '1 '#f))
                (let ()
                  (declare (not safe))
                  (##vector-cas! _%lock140555%_ '0 '0 '1))))
            _%$r140575%_))))
    (define __method-specializers
      (make-method-specializer-table/lock__% '#f '0))
    (define bind-specializer!
      (lambda (_%method-proc140547%_ _%specializer140548%_)
        (method-specializer-table-set!/lock
         __method-specializers
         _%method-proc140547%_
         _%specializer140548%_)))
    (define __lookup-method-specializer
      (lambda (_%proc140545%_)
        (method-specializer-table-ref/lock
         __method-specializers
         _%proc140545%_
         '#f)))
    (define __specialize-class
      (lambda (_%klass140527%_)
        (let* ((_%klass140530%_ _%klass140527%_)
               (_%$e140539%_
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-ref _%klass140530%_ '12 '#f '#f))))
          (if _%$e140539%_
              _%$e140539%_
              (let ((_%method-table140543%_
                     (___specialize-class _%klass140530%_)))
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-set!
                   _%klass140530%_
                   _%method-table140543%_
                   '12
                   '#f
                   '#f))
                _%method-table140543%_)))))
    (define specialize-class
      (lambda (_%klass140513%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass140513%_ 'class))
            (let ((_%klass140517%_ _%klass140513%_))
              (__specialize-class _%klass140517%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@1174.25-1174.30"
               'contract:
               'class-type?
               'value:
               _%klass140513%_)
              '#!void))))
    (define __specialize-method
      (lambda (_%klass140497%_
               _%method-table140498%_
               _%method140499%_
               _%proc140500%_)
        (let ((_%$e140502%_
               (let ()
                 (declare (not safe))
                 (symbolic-table-ref
                  _%method-table140498%_
                  _%method140499%_
                  '#f))))
          (if _%$e140502%_
              _%$e140502%_
              (let ((_%$e140505%_
                     (__lookup-method-specializer _%proc140500%_)))
                (if _%$e140505%_
                    (let ((_%specialized-proc140510%_
                           (_%$e140505%_
                            _%klass140497%_
                            _%method-table140498%_)))
                      (declare (not safe))
                      (symbolic-table-set!
                       _%method-table140498%_
                       _%method140499%_
                       _%specialized-proc140510%_))
                    (let ()
                      (declare (not safe))
                      (symbolic-table-set!
                       _%method-table140498%_
                       _%method140499%_
                       _%proc140500%_))))))))
    (define ___specialize-class
      (lambda (_%klass140364%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass140364%_ 'class))
            (if (let* ((_%klass140367%_ _%klass140364%_)
                       (_%klass140372%_ _%klass140367%_))
                  (__class-type-metaclass? _%klass140372%_))
                (let* ((_%obj140384%_ _%klass140364%_)
                       (_%id140387%_ 'specialize-class)
                       (_%args140390%_ '())
                       (_%id140395%_ _%id140387%_))
                  (declare (not safe))
                  (##apply __call-method
                           _%obj140384%_
                           _%id140395%_
                           _%args140390%_))
                (if (let* ((_%pred140408%_ class-type-metaclass?)
                           (_%lst140411%_
                            (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%klass140364%_
                               '6
                               '#f
                               '#f)))
                           (_%pred140416%_ _%pred140408%_))
                      (declare (not safe))
                      (__find _%pred140416%_ _%lst140411%_))
                    (error '"cannot specialize class that extends metaclass without a metaclass"
                           _%klass140364%_)
                    (let ((_%method-table140429%_
                           (let ()
                             (declare (not safe))
                             (make-symbolic-table__% '#f '0))))
                      (let _%loop140431%_ ((_%rest140433%_
                                            (let* ((_%klass140480%_
                                                    _%klass140364%_)
                                                   (_%klass140485%_
                                                    _%klass140480%_))
                                              (__class-precedence-list
                                               _%klass140485%_))))
                        (let* ((_%$%rest140434140442%_ _%rest140433%_)
                               (_%$%else140436140450%_
                                (lambda () _%method-table140429%_))
                               (_%$%K140438140468%_
                                (lambda (_%rest140453%_ _%xklass140454%_)
                                  (let ((_%$%xmethod-table140455140457%_
                                         (let ()
                                           (declare (not safe))
                                           (##unchecked-structure-ref
                                            _%xklass140454%_
                                            '11
                                            '#f
                                            '#f))))
                                    (if _%$%xmethod-table140455140457%_
                                        (let* ((_%xmethod-table140459%_
                                                _%$%xmethod-table140455140457%_)
                                               (__tmp148866
                                                (lambda (_%$%g140460140463%_
                                                         _%$%g140461140465%_)
                                                  (__specialize-method
                                                   _%klass140364%_
                                                   _%method-table140429%_
                                                   _%$%g140460140463%_
                                                   _%$%g140461140465%_))))
                                          (declare (not safe))
                                          (raw-table-for-each
                                           _%xmethod-table140459%_
                                           __tmp148866))
                                        '#f))
                                  (_%loop140431%_ _%rest140453%_))))
                          (if (pair? _%$%rest140434140442%_)
                              (let ((_%$%hd140439140471%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%rest140434140442%_)))
                                    (_%$%tl140440140473%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%rest140434140442%_))))
                                (let* ((_%xklass140476%_ _%$%hd140439140471%_)
                                       (_%rest140478%_ _%$%tl140440140473%_))
                                  (_%$%K140438140468%_
                                   _%rest140478%_
                                   _%xklass140476%_)))
                              (_%$%else140436140450%_)))))))
            (if (let () (declare (not safe)) (##type? _%klass140364%_))
                (__specialize-class (__shadow-class__0 _%klass140364%_))
                (error '"bad class; cannot specialize" _%klass140364%_)))))
    (define __seal-class!
      (lambda (_%klass140227%_)
        (let ((_%klass140230%_ _%klass140227%_))
          (if (let* ((_%klass140239%_ _%klass140230%_)
                     (_%klass140244%_ _%klass140239%_))
                (__class-type-sealed? _%klass140244%_))
              '#!void
              (begin
                (if (let* ((_%klass140257%_ _%klass140230%_)
                           (_%klass140262%_ _%klass140257%_))
                      (__class-type-metaclass? _%klass140262%_))
                    (let ()
                      (let* ((_%obj140273%_ _%klass140230%_)
                             (_%id140276%_ 'seal-class!)
                             (_%args140279%_ '())
                             (_%id140284%_ _%id140276%_))
                        (declare (not safe))
                        (##apply __call-method
                                 _%obj140273%_
                                 _%id140284%_
                                 _%args140279%_))
                      (let* ((_%klass140297%_ _%klass140230%_)
                             (_%klass140302%_ _%klass140297%_))
                        (__specialize-class _%klass140302%_)))
                    (if (let* ((_%pred140312%_ class-type-metaclass?)
                               (_%lst140315%_
                                (let ()
                                  (declare (not safe))
                                  (##unchecked-structure-ref
                                   _%klass140230%_
                                   '6
                                   '#f
                                   '#f)))
                               (_%pred140320%_ _%pred140312%_))
                          (declare (not safe))
                          (__find _%pred140320%_ _%lst140315%_))
                        (error '"cannot seal class that extends metaclass without a metaclass"
                               _%klass140230%_)
                        (let* ((_%klass140333%_ _%klass140230%_)
                               (_%klass140338%_ _%klass140333%_))
                          (__specialize-class _%klass140338%_))))
                (let* ((_%klass140349%_ _%klass140230%_)
                       (_%klass140354%_ _%klass140349%_))
                  (__class-type-seal! _%klass140354%_)))))))
    (define seal-class!
      (lambda (_%klass140213%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%klass140213%_ 'class))
            (let ((_%klass140217%_ _%klass140213%_))
              (__seal-class! _%klass140217%_))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@1220.20-1220.25"
               'contract:
               'class-type?
               'value:
               _%klass140213%_)
              '#!void))))
    (define __next-method
      (lambda (_%subklass140101%_ _%obj140102%_ _%id140103%_)
        (let* ((_%subklass140106%_ _%subklass140101%_)
               (_%id140114%_ _%id140103%_))
          (letrec ((_%find-next-method140123%_
                    (lambda (_%klass140125%_)
                      (let _%lp140127%_ ((_%rest140129%_
                                          (let ((_%klass140198%_
                                                 _%klass140125%_))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (##structure-instance-of?
                                                   _%klass140198%_
                                                   'class))
                                                (let ((_%klass140203%_
                                                       _%klass140198%_))
                                                  (__class-precedence-list
                                                   _%klass140203%_))
                                                (begin
                                                  (raise-contract-violation-error
                                                   '"contract violation"
                                                   'context:
                                                   'gerbil/runtime/mop
                                                   'contract:
                                                   'class-type?
                                                   'value:
                                                   _%klass140198%_)
                                                  '#!void)))))
                        (let* ((_%$%rest140130140138%_ _%rest140129%_)
                               (_%$%else140132140146%_ (lambda () '#f))
                               (_%$%K140134140186%_
                                (lambda (_%rest140149%_ _%klass140150%_)
                                  (if (eq? (let ()
                                             (declare (not safe))
                                             (##type-id _%subklass140106%_))
                                           (let ()
                                             (declare (not safe))
                                             (##type-id _%klass140150%_)))
                                      (let* ((_%mixins140152%_ _%rest140149%_)
                                             (_%obj140155%_ _%obj140102%_)
                                             (_%id140158%_ _%id140114%_)
                                             (_%id140163%_ _%id140158%_))
                                        (__mixin-find-method
                                         _%mixins140152%_
                                         _%obj140155%_
                                         _%id140163%_))
                                      (_%lp140127%_ _%rest140149%_)))))
                          (if (pair? _%$%rest140130140138%_)
                              (let ((_%$%hd140135140189%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%rest140130140138%_)))
                                    (_%$%tl140136140191%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%rest140130140138%_))))
                                (let* ((_%klass140194%_ _%$%hd140135140189%_)
                                       (_%rest140196%_ _%$%tl140136140191%_))
                                  (_%$%K140134140186%_
                                   _%rest140196%_
                                   _%klass140194%_)))
                              (_%$%else140132140146%_)))))))
            (_%find-next-method140123%_ (class-of _%obj140102%_))))))
    (define next-method
      (lambda (_%subklass140075%_ _%obj140076%_ _%id140077%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%subklass140075%_ 'class))
            (let ((_%subklass140081%_ _%subklass140075%_))
              (if (symbol? _%id140077%_)
                  (let ((_%id140091%_ _%id140077%_))
                    (__next-method
                     _%subklass140081%_
                     _%obj140076%_
                     _%id140091%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@1242.44-1242.46"
                     'contract:
                     'symbol?
                     'value:
                     _%id140077%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@1242.20-1242.28"
               'contract:
               'class-type?
               'value:
               _%subklass140075%_)
              '#!void))))
    (define __call-next-method
      (lambda (_%subklass140010%_ _%obj140011%_ _%id140012%_ . _%args140013%_)
        (let* ((_%subklass140016%_ _%subklass140010%_)
               (_%id140024%_ _%id140012%_)
               (_%$e140069%_
                (let* ((_%subklass140033%_ _%subklass140016%_)
                       (_%obj140036%_ _%obj140011%_)
                       (_%id140039%_ _%id140024%_)
                       (_%subklass140044%_ _%subklass140033%_)
                       (_%id140059%_ _%id140039%_))
                  (__next-method
                   _%subklass140044%_
                   _%obj140036%_
                   _%id140059%_))))
          (if _%$e140069%_
              (apply _%$e140069%_ _%obj140011%_ _%args140013%_)
              (error '"cannot find next method"
                     'object:
                     _%obj140011%_
                     'method:
                     _%id140024%_)))))
    (define call-next-method
      (lambda (_%subklass139983%_ _%obj139984%_ _%id139985%_ . _%args139986%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%subklass139983%_ 'class))
            (let ((_%subklass139990%_ _%subklass139983%_))
              (if (symbol? _%id139985%_)
                  (let ((_%id140000%_ _%id139985%_))
                    (declare (not safe))
                    (##apply __call-next-method
                             _%subklass139990%_
                             _%obj139984%_
                             _%id140000%_
                             _%args139986%_))
                  (begin
                    (raise-contract-violation-error
                     '"contract violation"
                     'context:
                     '"\"gerbil/runtime/mop.ss\"@1253.49-1253.51"
                     'contract:
                     'symbol?
                     'value:
                     _%id139985%_)
                    '#!void)))
            (begin
              (raise-contract-violation-error
               '"contract violation"
               'context:
               '"\"gerbil/runtime/mop.ss\"@1253.25-1253.33"
               'contract:
               'class-type?
               'value:
               _%subklass139983%_)
              '#!void))))
    (define __shadow-classes
      (let () (declare (not safe)) (make-symbolic-table__% '#f '0)))
    (define __shadow-classes-lock (vector '0 '#f))
    (define __shadow-class__%
      (lambda (_%type139762%_ _%properties139763%_)
        (letrec ((_%shadow-type-id139765%_
                  (lambda (_%type139971%_)
                    (let ((__tmp148867
                           (let ()
                             (declare (not safe))
                             (##type-name _%type139971%_))))
                      (declare (not safe))
                      (make-symbol__1 __tmp148867 '"::t"))))
                 (_%shadow-type-name139766%_
                  (lambda (_%type139969%_)
                    (let ()
                      (declare (not safe))
                      (##type-name _%type139969%_))))
                 (_%make-shadow-class139767%_
                  (lambda (_%type139851%_ _%precedence-list139852%_)
                    (let* ((_%super139854%_
                            (if (pair? _%precedence-list139852%_)
                                (cons (let ()
                                        (declare (not safe))
                                        (##car _%precedence-list139852%_))
                                      '())
                                '()))
                           (_%klass139966%_
                            (let* ((_%id139856%_
                                    (_%shadow-type-id139765%_ _%type139851%_))
                                   (_%name139859%_
                                    (let ()
                                      (declare (not safe))
                                      (##type-name _%type139851%_)))
                                   (_%direct-supers139862%_ _%super139854%_)
                                   (_%direct-slots139865%_ '())
                                   (_%properties139891%_
                                    (cons (cons 'struct: '#t)
                                          (cons (cons 'system: '#t)
                                                (cons (cons 'system-type:
                                                            _%type139851%_)
                                                      (append (if (let ((_%type139868%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                 _%type139851%_))
                            (if (let ()
                                  (declare (not safe))
                                  (##type? _%type139868%_))
                                (let ((_%type139873%_ _%type139868%_))
                                  (__type-extensible? _%type139873%_))
                                (begin
                                  (raise-contract-violation-error
                                   '"contract violation"
                                   'context:
                                   'gerbil/runtime/mop
                                   'contract:
                                   '##type?
                                   'value:
                                   _%type139868%_)
                                  '#!void)))
                          '()
                          (cons (cons 'final: '#t) '()))
                      _%properties139763%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                   (_%constructor139894%_ '#f)
                                   (_%id139899%_ _%id139856%_))
                              (if (symbol? _%name139859%_)
                                  (let* ((_%name139910%_ _%name139859%_)
                                         (_%direct-supers139920%_
                                          _%direct-supers139862%_)
                                         (_%direct-slots139930%_
                                          _%direct-slots139865%_)
                                         (_%properties139940%_
                                          _%properties139891%_))
                                    (if (let ((_%$e139952%_ '#t))
                                          (and _%$e139952%_ _%$e139952%_))
                                        (let ((_%constructor139956%_
                                               _%constructor139894%_))
                                          (__make-class-type
                                           _%id139899%_
                                           _%name139910%_
                                           _%direct-supers139920%_
                                           _%direct-slots139930%_
                                           _%properties139940%_
                                           _%constructor139956%_))
                                        (begin
                                          (raise-contract-violation-error
                                           '"contract violation"
                                           'context:
                                           'gerbil/runtime/mop
                                           'contract:
                                           '(? (or not symbol?))
                                           'value:
                                           _%constructor139894%_)
                                          '#!void)))
                                  (begin
                                    (raise-contract-violation-error
                                     '"contract violation"
                                     'context:
                                     'gerbil/runtime/mop
                                     'contract:
                                     'symbol?
                                     'value:
                                     _%name139859%_)
                                    '#!void)))))
                      (let ((__tmp148868
                             (let ()
                               (declare (not safe))
                               (##type-id _%type139851%_))))
                        (declare (not safe))
                        (symbolic-table-set!
                         __shadow-classes
                         __tmp148868
                         _%klass139966%_))
                      _%klass139966%_))))
          (let ()
            (declare (not interrupts-enabled))
            (let _%again139771%_ ((_%spin139774%_ '0))
              (if (let ((__tmp148869
                         (let ()
                           (declare (not safe))
                           (##vector-cas! __shadow-classes-lock '0 '1 '0))))
                    (declare (not safe))
                    (##fx= __tmp148869 '0))
                  (let ((__tmp148870 (current-thread)))
                    (declare (not safe))
                    (##vector-set! __shadow-classes-lock '1 __tmp148870))
                  (if (let () (declare (not safe)) (##fx< _%spin139774%_ '10))
                      (_%again139771%_
                       (let () (declare (not safe)) (##fx+ _%spin139774%_ '1)))
                      (let ((_%owner139780%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref __shadow-classes-lock '1))))
                        (if (eq? _%owner139780%_ (macro-current-thread))
                            (let ()
                              (declare (not safe))
                              (##thread-deadlock-action!))
                            (if (macro-thread-end-condvar _%owner139780%_)
                                (let ()
                                  (let ()
                                    (declare (not safe))
                                    (##thread-yield!))
                                  (_%again139771%_ '0))
                                (let ()
                                  (declare (not safe))
                                  (##thread-deadlock-action!)))))))))
          (let ((_%$e139786%_
                 (let ((__tmp148871
                        (let ()
                          (declare (not safe))
                          (##type-id _%type139762%_))))
                   (declare (not safe))
                   (symbolic-table-ref __shadow-classes __tmp148871 '#f))))
            (if _%$e139786%_
                (let ()
                  (let ()
                    (declare (not interrupts-enabled))
                    (begin
                      (let ()
                        (declare (not safe))
                        (##vector-set! __shadow-classes-lock '1 '#f))
                      (let ()
                        (declare (not safe))
                        (##vector-cas! __shadow-classes-lock '0 '0 '1))))
                  _%$e139786%_)
                (let _%loop139794%_ ((_%super139796%_
                                      (let ()
                                        (declare (not safe))
                                        (##type-super _%type139762%_)))
                                     (_%hierarchy139797%_ '()))
                  (if _%super139796%_
                      (_%loop139794%_
                       (let ()
                         (declare (not safe))
                         (##type-super _%super139796%_))
                       (cons _%super139796%_ _%hierarchy139797%_))
                      (let _%loop139800%_ ((_%rest139802%_ _%hierarchy139797%_)
                                           (_%precedence-list139803%_ '()))
                        (let* ((_%$%rest139804139812%_ _%rest139802%_)
                               (_%$%else139806139824%_
                                (lambda ()
                                  (let ((_%klass139820%_
                                         (_%make-shadow-class139767%_
                                          _%type139762%_
                                          _%precedence-list139803%_)))
                                    (let ()
                                      (declare (not interrupts-enabled))
                                      (begin
                                        (let ()
                                          (declare (not safe))
                                          (##vector-set!
                                           __shadow-classes-lock
                                           '1
                                           '#f))
                                        (let ()
                                          (declare (not safe))
                                          (##vector-cas!
                                           __shadow-classes-lock
                                           '0
                                           '0
                                           '1))))
                                    _%klass139820%_)))
                               (_%$%K139808139838%_
                                (lambda (_%rest139827%_ _%type139828%_)
                                  (let ((_%$e139830%_
                                         (let ((__tmp148872
                                                (let ()
                                                  (declare (not safe))
                                                  (##type-id _%type139828%_))))
                                           (declare (not safe))
                                           (symbolic-table-ref
                                            __shadow-classes
                                            __tmp148872
                                            '#f))))
                                    (if _%$e139830%_
                                        (_%loop139800%_
                                         _%rest139827%_
                                         (cons _%$e139830%_
                                               _%precedence-list139803%_))
                                        (let ((_%klass139836%_
                                               (_%make-shadow-class139767%_
                                                _%type139828%_
                                                _%precedence-list139803%_)))
                                          (_%loop139800%_
                                           _%rest139827%_
                                           (cons _%klass139836%_
                                                 _%precedence-list139803%_))))))))
                          (if (pair? _%$%rest139804139812%_)
                              (let ((_%$%hd139809139841%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%rest139804139812%_)))
                                    (_%$%tl139810139843%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%rest139804139812%_))))
                                (let* ((_%type139846%_ _%$%hd139809139841%_)
                                       (_%rest139848%_ _%$%tl139810139843%_))
                                  (_%$%K139808139838%_
                                   _%rest139848%_
                                   _%type139846%_)))
                              (_%$%else139806139824%_)))))))))))
    (define __shadow-class__0
      (lambda (_%type139976%_)
        (let ((_%properties139978%_ '()))
          (__shadow-class__% _%type139976%_ _%properties139978%_))))
    (define __shadow-class
      (lambda _g148873_
        (let ((_g148874_ (let () (declare (not safe)) (##length _g148873_))))
          (cond ((let () (declare (not safe)) (##fx= _g148874_ 1))
                 (apply __shadow-class__0 _g148873_))
                ((let () (declare (not safe)) (##fx= _g148874_ 2))
                 (apply __shadow-class__% _g148873_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  __shadow-class
                  _g148873_))))))
    (define __type
      (let* ((_%tb139750%_
              (let ()
                (declare (not safe))
                (##c-code '"___RESULT = ___FIX(___TB);")))
             (_%$e139752%_ _%tb139750%_))
        (if (eq? '2 _%$e139752%_)
            '#(fixnum subtyped special pair)
            (if (eq? '3 _%$e139752%_)
                (let ((_%flonum-self-tagging-tags139755%_
                       (let ()
                         (declare (not safe))
                         (##c-code
                          '"___RESULT = ___FIX(___FLONUM_SELF_TAGGING_TAGS);")))
                      (_%fixnum-tag-bits139756%_
                       (let ()
                         (declare (not safe))
                         (##c-code
                          '"#ifdef ___USE_2_TAG_BITS_FOR_FIXNUMS\n___RESULT = ___FIX(2) ;\n#else\n___RESULT = ___FIX(3) ;\n#endif"))))
                  (let ((_%$e139758%_ _%flonum-self-tagging-tags139755%_))
                    (if (eq? '0 _%$e139758%_)
                        (if (let ()
                              (declare (not safe))
                              (##fx= _%fixnum-tag-bits139756%_ '2))
                            '#(fixnum
                               subtyped
                               special
                               vector
                               fixnum
                               pair
                               undefined
                               haflonum)
                            '#(fixnum
                               subtyped
                               undefined
                               vector
                               special
                               pair
                               undefined
                               haflonum))
                        (if (eq? '1 _%$e139758%_)
                            (if (let ()
                                  (declare (not safe))
                                  (##fx= _%fixnum-tag-bits139756%_ '2))
                                '#(fixnum
                                   subtyped
                                   special
                                   vector
                                   fixnum
                                   pair
                                   stflonum
                                   haflonum)
                                '#(fixnum
                                   subtyped
                                   undefined
                                   vector
                                   special
                                   pair
                                   stflonum
                                   haflonum))
                            (if (eq? '2 _%$e139758%_)
                                '#(fixnum
                                   subtyped
                                   stflonum
                                   haflonum
                                   special
                                   pair
                                   stflonum
                                   undefined)
                                (if (eq? '3 _%$e139758%_)
                                    '#(fixnum
                                       subtyped
                                       haflonum
                                       immedate-flonum
                                       special
                                       pair
                                       stflonum
                                       stflonum)
                                    (if (eq? '4 _%$e139758%_)
                                        '#(fixnum
                                           subtyped
                                           stflonum
                                           stflonum
                                           special
                                           pair
                                           stflonum
                                           stflonum)
                                        (error '"unexpected flonum self tagging tags"
                                               _%flonum-self-tagging-tags139755%_))))))))
                (error '"unexpected tag width" _%tb139750%_)))))
    (define __primitive-class
      (let ((__tmp148875 (vector-length __type)))
        (declare (not safe))
        (##make-vector __tmp148875 '#f)))
    (define __boxvalues-class
      (let () (declare (not safe)) (##make-vector '2 '#f)))
    (define __subtype-class
      (let () (declare (not safe)) (##make-vector '32 '#f)))
    (define __char-class '#f)
    (define __special-class
      (let () (declare (not safe)) (##make-vector '16 '#f)))
    (define __class-of
      (let* ((_%len139640%_ (vector-length __type))
             (_%cv139642%_
              (let () (declare (not safe)) (##make-vector _%len139640%_ '#f))))
        (let _%loop139645%_ ((_%i139647%_ '0))
          (if (let () (declare (not safe)) (##fx< _%i139647%_ _%len139640%_))
              (let* ((_%t139649%_
                      (let ()
                        (declare (not safe))
                        (##vector-ref __type _%i139647%_)))
                     (_%f139747%_
                      (if (eq? _%t139649%_ 'undefined)
                          (lambda (_%obj139652%_)
                            (error '"object type is undefined" _%obj139652%_))
                          (if (let ()
                                (declare (not safe))
                                (##memq _%t139649%_
                                        '(fixnum flonum
                                                 stflonum
                                                 haflonum
                                                 pair
                                                 vector)))
                              (lambda (_%obj139655%_)
                                (declare (not interrupts-enabled) (not safe))
                                (let ((_%$e139658%_
                                       (##vector-ref
                                        __primitive-class
                                        _%i139647%_)))
                                  (if _%$e139658%_
                                      _%$e139658%_
                                      (let ((_%klass139662%_
                                             (__system-class _%t139649%_)))
                                        (##vector-set!
                                         __primitive-class
                                         _%i139647%_
                                         _%klass139662%_)
                                        _%klass139662%_))))
                              (if (eq? _%t139649%_ 'subtyped)
                                  (lambda (_%obj139666%_)
                                    (declare
                                      (not interrupts-enabled)
                                      (not safe))
                                    (let ((_%st139669%_
                                           (##subtype _%obj139666%_)))
                                      (if (##fx= _%st139669%_
                                                 (macro-subtype-structure))
                                          (let ((_%klass139672%_
                                                 (##structure-type
                                                  _%obj139666%_)))
                                            (if (##structure-instance-of?
                                                 _%klass139672%_
                                                 'class)
                                                _%klass139672%_
                                                (__shadow-class__0
                                                 _%klass139672%_)))
                                          (if (##fx= _%st139669%_
                                                     (macro-subtype-boxvalues))
                                              (if (##fx= (##values-length
                                                          _%obj139666%_)
                                                         '1)
                                                  (let ((_%$e139675%_
                                                         (##vector-ref
                                                          __boxvalues-class
                                                          '0)))
                                                    (if _%$e139675%_
                                                        _%$e139675%_
                                                        (let ((_%klass139679%_
                                                               (__system-class
                                                                'box)))
                                                          (##vector-set!
                                                           __boxvalues-class
                                                           '0
                                                           _%klass139679%_)
                                                          _%klass139679%_)))
                                                  (let ((_%$e139682%_
                                                         (##vector-ref
                                                          __boxvalues-class
                                                          '1)))
                                                    (if _%$e139682%_
                                                        _%$e139682%_
                                                        (let ((_%klass139686%_
                                                               (__system-class
                                                                'values)))
                                                          (##vector-set!
                                                           __boxvalues-class
                                                           '1
                                                           _%klass139686%_)
                                                          _%klass139686%_))))
                                              (let ((_%$e139689%_
                                                     (##vector-ref
                                                      __subtype-class
                                                      _%st139669%_)))
                                                (if _%$e139689%_
                                                    _%$e139689%_
                                                    (let ((_%klass139706%_
                                                           (let ((_%$e139693%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (##vector-ref __subtype-id _%st139669%_)))
                     (if _%$e139693%_
                         (let ((_%$e139698%_
                                (##vector-ref __subtype-class _%st139669%_)))
                           (if _%$e139698%_
                               _%$e139698%_
                               (let ((_%klass139702%_
                                      (__system-class _%$e139693%_)))
                                 (##vector-set!
                                  __subtype-class
                                  _%st139669%_
                                  _%klass139702%_)
                                 _%klass139702%_)))
                         (error '"unknown class"
                                'object:
                                _%obj139666%_
                                'subtype:
                                _%st139669%_)))))
              (##vector-set! __subtype-class _%st139669%_ _%klass139706%_)
              _%klass139706%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                  (if (eq? _%t139649%_ 'special)
                                      (lambda (_%obj139710%_)
                                        (declare
                                          (not interrupts-enabled)
                                          (not safe))
                                        (let ((_%x139713%_
                                               (##type-cast _%obj139710%_ '0)))
                                          (if (##fx> _%x139713%_ '0)
                                              (let ((_%$e139716%_
                                                     __char-class))
                                                (if _%$e139716%_
                                                    _%$e139716%_
                                                    (let ((_%klass139720%_
                                                           (__system-class
                                                            'char)))
                                                      (set! __char-class
                                                            _%klass139720%_)
                                                      _%klass139720%_)))
                                              (let* ((_%t139723%_
                                                      (##fx- _%x139713%_))
                                                     (_%$e139726%_
                                                      (##vector-ref
                                                       __special-class
                                                       _%t139723%_)))
                                                (if _%$e139726%_
                                                    _%$e139726%_
                                                    (let ((_%klass139744%_
                                                           (if (eq? _%obj139710%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            '())
                       (__system-class 'null)
                       (if (eq? _%obj139710%_ '#f)
                           (__system-class 'false)
                           (if (eq? _%obj139710%_ '#t)
                               (__system-class 'true)
                               (if (eq? _%obj139710%_ '#!void)
                                   (__system-class 'void)
                                   (if (eq? _%obj139710%_ '#!eof)
                                       (__system-class 'eof)
                                       (if (eq? _%obj139710%_ '#!unbound)
                                           (__system-class 'unbound)
                                           (if (eq? _%obj139710%_ '#!unbound2)
                                               (__system-class 'unbound2)
                                               (if (eq? _%obj139710%_
                                                        '#!optional)
                                                   (__system-class 'optional)
                                                   (if (eq? _%obj139710%_
                                                            '#!rest)
                                                       (__system-class 'rest)
                                                       (if (eq? _%obj139710%_
                                                                '#!key)
                                                           (__system-class
                                                            'key)
                                                           (if (eq? _%obj139710%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (macro-unused-obj))
                       (__system-class 'unused)
                       (if (eq? _%obj139710%_ (macro-deleted-obj))
                           (__system-class 'deleted)
                           (if (eq? _%obj139710%_ (macro-absent-obj))
                               (__system-class 'absent)
                               (__system-class 'unknown))))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
              (##vector-set! __special-class _%t139723%_ _%klass139744%_)
              _%klass139744%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                      (error '"unexpected object type"
                                             _%t139649%_)))))))
                (let ()
                  (declare (not safe))
                  (##vector-set! _%cv139642%_ _%i139647%_ _%f139747%_))
                (_%loop139645%_
                 (let () (declare (not safe)) (##fx+ _%i139647%_ '1))))
              _%cv139642%_))))
    (define type-of
      (lambda (_%obj139636%_)
        (let ()
          (declare (not safe) (not interrupts-enabled))
          (##vector-ref __type (##type _%obj139636%_)))))
    (define class-of
      (lambda (_%obj139627%_)
        (let ()
          (declare (not safe) (not interrupts-enabled))
          (let* ((_%t139631%_ (##type _%obj139627%_))
                 (_%f139633%_ (##vector-ref __class-of _%t139631%_)))
            (_%f139633%_ _%obj139627%_)))))
    (define __subtype-id (let () (declare (not safe)) (##make-vector '32 '#f)))
    (vector-set! __subtype-id (macro-subtype-vector) 'vector)
    (vector-set! __subtype-id (macro-subtype-pair) 'pair)
    (vector-set! __subtype-id (macro-subtype-ratnum) 'ratnum)
    (vector-set! __subtype-id (macro-subtype-cpxnum) 'cpxnum)
    (vector-set! __subtype-id (macro-subtype-symbol) 'symbol)
    (vector-set! __subtype-id (macro-subtype-keyword) 'keyword)
    (vector-set! __subtype-id (macro-subtype-frame) 'frame)
    (vector-set! __subtype-id (macro-subtype-continuation) 'continuation)
    (vector-set! __subtype-id (macro-subtype-promise) 'promise)
    (vector-set! __subtype-id (macro-subtype-weak) 'weak)
    (vector-set! __subtype-id (macro-subtype-procedure) 'procedure)
    (vector-set! __subtype-id (macro-subtype-return) 'return)
    (vector-set! __subtype-id (macro-subtype-foreign) 'foreign)
    (vector-set! __subtype-id (macro-subtype-string) 'string)
    (vector-set! __subtype-id (macro-subtype-s8vector) 's8vector)
    (vector-set! __subtype-id (macro-subtype-u8vector) 'u8vector)
    (vector-set! __subtype-id (macro-subtype-s16vector) 's16vector)
    (vector-set! __subtype-id (macro-subtype-u16vector) 'u16vector)
    (vector-set! __subtype-id (macro-subtype-s32vector) 's32vector)
    (vector-set! __subtype-id (macro-subtype-u32vector) 'u32vector)
    (vector-set! __subtype-id (macro-subtype-f32vector) 'f32vector)
    (vector-set! __subtype-id (macro-subtype-s64vector) 's64vector)
    (vector-set! __subtype-id (macro-subtype-u64vector) 'u64vector)
    (vector-set! __subtype-id (macro-subtype-f64vector) 'f64vector)
    (vector-set! __subtype-id (macro-subtype-flonum) 'haflonum)
    (vector-set! __subtype-id (macro-subtype-bignum) 'bignum)
    (define __system-classes
      (let () (declare (not safe)) (make-symbolic-table__% '#f '0)))
    (define __system-class
      (lambda (_%id139621%_)
        (let ((_%$e139623%_
               (let ()
                 (declare (not safe))
                 (symbolic-table-ref __system-classes _%id139621%_ '#f))))
          (if _%$e139623%_
              _%$e139623%_
              (error '"unknown system class" _%id139621%_)))))
    (define __make-system-class
      (lambda (_%id139523%_ _%super139524%_ _%properties139525%_)
        (let ((_%klass139619%_
               (let* ((_%id139527%_ _%id139523%_)
                      (_%name139530%_ _%id139523%_)
                      (_%direct-supers139533%_ _%super139524%_)
                      (_%direct-slots139536%_ '())
                      (_%properties139539%_
                       (cons '(system: . #t) _%properties139525%_))
                      (_%constructor139542%_ '#f))
                 (if (symbol? _%id139527%_)
                     (let ((_%id139547%_ _%id139527%_))
                       (if (symbol? _%name139530%_)
                           (let ((_%name139563%_ _%name139530%_))
                             (if (list? _%direct-supers139533%_)
                                 (let* ((_%direct-supers139573%_
                                         _%direct-supers139533%_)
                                        (_%direct-slots139583%_
                                         _%direct-slots139536%_)
                                        (_%properties139593%_
                                         _%properties139539%_))
                                   (if (let ((_%$e139605%_ '#t))
                                         (and _%$e139605%_ _%$e139605%_))
                                       (let ((_%constructor139609%_
                                              _%constructor139542%_))
                                         (__make-class-type
                                          _%id139547%_
                                          _%name139563%_
                                          _%direct-supers139573%_
                                          _%direct-slots139583%_
                                          _%properties139593%_
                                          _%constructor139609%_))
                                       (begin
                                         (raise-contract-violation-error
                                          '"contract violation"
                                          'context:
                                          'gerbil/runtime/mop
                                          'contract:
                                          '(? (or not symbol?))
                                          'value:
                                          _%constructor139542%_)
                                         '#!void)))
                                 (begin
                                   (raise-contract-violation-error
                                    '"contract violation"
                                    'context:
                                    'gerbil/runtime/mop
                                    'contract:
                                    'list?
                                    'value:
                                    _%direct-supers139533%_)
                                   '#!void)))
                           (begin
                             (raise-contract-violation-error
                              '"contract violation"
                              'context:
                              'gerbil/runtime/mop
                              'contract:
                              'symbol?
                              'value:
                              _%name139530%_)
                             '#!void)))
                     (begin
                       (raise-contract-violation-error
                        '"contract violation"
                        'context:
                        'gerbil/runtime/mop
                        'contract:
                        'symbol?
                        'value:
                        _%id139527%_)
                       '#!void)))))
          (let ()
            (declare (not safe))
            (symbolic-table-set!
             __system-classes
             _%id139523%_
             _%klass139619%_))
          _%klass139619%_)))))
