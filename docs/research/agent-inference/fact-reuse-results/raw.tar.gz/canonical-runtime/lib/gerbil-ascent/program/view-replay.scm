(declare (block) (standard-bindings) (extended-bindings))
(begin (begin) (load-module "gerbil-ascent/program/view-replay~0"))
