prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/candidate

(begin
  (declare-class
   gerbil-ascent/candidate/datum#datum-frame::t
   (@class gerbil-ascent/candidate/datum#datum-frame::t
           ()
           (object::t t::t)
           (pair depth tail?)
           (pair depth tail?)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/candidate/datum#datum-frame::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/datum#datum-frame::t)
    'class::t))
  (declare-type
   gerbil-ascent/candidate/datum#datum-frame?
   (@predicate gerbil-ascent/candidate/datum#datum-frame::t))
  (declare-type
   gerbil-ascent/candidate/datum#make-datum-frame
   (@constructor gerbil-ascent/candidate/datum#datum-frame::t))
  (declare-type
   gerbil-ascent/candidate/datum#datum-frame-pair
   (@accessor gerbil-ascent/candidate/datum#datum-frame::t pair #t))
  (declare-type
   gerbil-ascent/candidate/datum#datum-frame-depth
   (@accessor gerbil-ascent/candidate/datum#datum-frame::t depth #t))
  (declare-type
   gerbil-ascent/candidate/datum#datum-frame-tail?
   (@accessor gerbil-ascent/candidate/datum#datum-frame::t tail? #t))
  (declare-type
   gerbil-ascent/candidate/datum#datum-frame-pair-set!
   (@mutator gerbil-ascent/candidate/datum#datum-frame::t pair #t))
  (declare-type
   gerbil-ascent/candidate/datum#datum-frame-depth-set!
   (@mutator gerbil-ascent/candidate/datum#datum-frame::t depth #t))
  (declare-type
   gerbil-ascent/candidate/datum#datum-frame-tail?-set!
   (@mutator gerbil-ascent/candidate/datum#datum-frame::t tail? #t))
  (declare-type
   gerbil-ascent/candidate/datum#&datum-frame-pair
   (@accessor gerbil-ascent/candidate/datum#datum-frame::t pair #f))
  (declare-type
   gerbil-ascent/candidate/datum#&datum-frame-depth
   (@accessor gerbil-ascent/candidate/datum#datum-frame::t depth #f))
  (declare-type
   gerbil-ascent/candidate/datum#&datum-frame-tail?
   (@accessor gerbil-ascent/candidate/datum#datum-frame::t tail? #f))
  (declare-type
   gerbil-ascent/candidate/datum#&datum-frame-pair-set!
   (@mutator gerbil-ascent/candidate/datum#datum-frame::t pair #f))
  (declare-type
   gerbil-ascent/candidate/datum#&datum-frame-depth-set!
   (@mutator gerbil-ascent/candidate/datum#datum-frame::t depth #f))
  (declare-type
   gerbil-ascent/candidate/datum#&datum-frame-tail?-set!
   (@mutator gerbil-ascent/candidate/datum#datum-frame::t tail? #f))
  (declare-type
   gerbil-ascent/candidate/datum#candidate-datum-scalar?
   (@lambda 1
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/datum)))
  (declare-type
   gerbil-ascent/candidate/datum#reasoning-bounded-data?
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/datum)))
  (declare-type
   gerbil-ascent/candidate/datum#candidate-copy-pairs
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/datum))))
