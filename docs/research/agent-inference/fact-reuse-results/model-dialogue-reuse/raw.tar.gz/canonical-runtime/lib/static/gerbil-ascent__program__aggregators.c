#ifdef ___LINKER_INFO
; File: "gerbil-ascent__program__aggregators.c", produced by Gambit v4.9.8
(
409008
(C)
"gerbil-ascent__program__aggregators"
("gerbil-ascent__program__aggregators")
()
(("gerbil-ascent__program__aggregators"))
( #|*/"*/"symbols|#
"gerbil-ascent/program/aggregators#gerbil-ascent-count"
"gerbil-ascent/program/aggregators#gerbil-ascent-max"
"gerbil-ascent/program/aggregators#gerbil-ascent-mean"
"gerbil-ascent/program/aggregators#gerbil-ascent-min"
"gerbil-ascent/program/aggregators#gerbil-ascent-sum"
"gerbil-ascent/program/aggregators#single-column-value"
"gerbil-ascent__program__aggregators"
"gerbil-ascent__program__aggregators#"
) #|*/"*/"symbols|#
( #|*/"*/"keywords|#
) #|*/"*/"keywords|#
( #|*/"*/"globals-s-d|#
"gerbil-ascent/program/aggregators#single-column-value"
"gerbil-ascent__program__aggregators#"
) #|*/"*/"globals-s-d|#
( #|*/"*/"globals-s-nd|#
"gerbil-ascent/program/aggregators#gerbil-ascent-count"
"gerbil-ascent/program/aggregators#gerbil-ascent-max"
"gerbil-ascent/program/aggregators#gerbil-ascent-mean"
"gerbil-ascent/program/aggregators#gerbil-ascent-min"
"gerbil-ascent/program/aggregators#gerbil-ascent-sum"
"gerbil-ascent/program/aggregators::timestamp"
) #|*/"*/"globals-s-nd|#
( #|*/"*/"globals-ns|#
"##apply"
"##dead-end"
"+"
"/"
"car"
"error"
"exact->inexact"
"foldl__0"
"for-each"
"length"
"map"
"max"
"min"
) #|*/"*/"globals-ns|#
( #|*/"*/"meta-info|#
) #|*/"*/"meta-info|#
)
#else
#define ___VERSION 409008
#define ___MODULE_NAME "gerbil-ascent__program__aggregators"
#define ___LINKER_ID ___LNK_gerbil_2d_ascent____program____aggregators
#define ___MH_PROC ___H_gerbil_2d_ascent____program____aggregators
#define ___SCRIPT_LINE 0
#define ___SYMCOUNT 8
#define ___GLOCOUNT 21
#define ___SUPCOUNT 8
#define ___SUBCOUNT 6
#define ___LBLCOUNT 87
#define ___MODDESCR ___REF_SUB(3)
#include "gambit.h"

___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
___NEED_SYM(___S_gerbil_2d_ascent____program____aggregators)
___NEED_SYM(___S_gerbil_2d_ascent____program____aggregators_23_)

___NEED_GLO(___G__23__23_apply)
___NEED_GLO(___G__23__23_dead_2d_end)
___NEED_GLO(___G__2b_)
___NEED_GLO(___G__2f_)
___NEED_GLO(___G_car)
___NEED_GLO(___G_error)
___NEED_GLO(___G_exact_2d__3e_inexact)
___NEED_GLO(___G_foldl____0)
___NEED_GLO(___G_for_2d_each)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_aggregators_3a__3a_timestamp)
___NEED_GLO(___G_gerbil_2d_ascent____program____aggregators_23_)
___NEED_GLO(___G_length)
___NEED_GLO(___G_map)
___NEED_GLO(___G_max)
___NEED_GLO(___G_min)

___BEGIN_SYM
___DEF_SYM(0,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count,"gerbil-ascent/program/aggregators#gerbil-ascent-count")

___DEF_SYM(1,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max,"gerbil-ascent/program/aggregators#gerbil-ascent-max")

___DEF_SYM(2,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,"gerbil-ascent/program/aggregators#gerbil-ascent-mean")

___DEF_SYM(3,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min,"gerbil-ascent/program/aggregators#gerbil-ascent-min")

___DEF_SYM(4,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,"gerbil-ascent/program/aggregators#gerbil-ascent-sum")

___DEF_SYM(5,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value,"gerbil-ascent/program/aggregators#single-column-value")

___DEF_SYM(6,___S_gerbil_2d_ascent____program____aggregators,"gerbil-ascent__program__aggregators")

___DEF_SYM(7,___S_gerbil_2d_ascent____program____aggregators_23_,"gerbil-ascent__program__aggregators#")

___END_SYM

#define ___SYM_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count ___SYM(0,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max ___SYM(1,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean ___SYM(2,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min ___SYM(3,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum ___SYM(4,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value ___SYM(5,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
#define ___SYM_gerbil_2d_ascent____program____aggregators ___SYM(6,___S_gerbil_2d_ascent____program____aggregators)
#define ___SYM_gerbil_2d_ascent____program____aggregators_23_ ___SYM(7,___S_gerbil_2d_ascent____program____aggregators_23_)

___BEGIN_GLO
___DEF_GLO(0,"gerbil-ascent/program/aggregators#gerbil-ascent-count")

___DEF_GLO(1,"gerbil-ascent/program/aggregators#gerbil-ascent-max")

___DEF_GLO(2,"gerbil-ascent/program/aggregators#gerbil-ascent-mean")

___DEF_GLO(3,"gerbil-ascent/program/aggregators#gerbil-ascent-min")

___DEF_GLO(4,"gerbil-ascent/program/aggregators#gerbil-ascent-sum")

___DEF_GLO(5,"gerbil-ascent/program/aggregators#single-column-value")

___DEF_GLO(6,"gerbil-ascent/program/aggregators::timestamp")

___DEF_GLO(7,"gerbil-ascent__program__aggregators#")

___DEF_GLO(8,"##apply")
___DEF_GLO(9,"##dead-end")
___DEF_GLO(10,"+")
___DEF_GLO(11,"/")
___DEF_GLO(12,"car")
___DEF_GLO(13,"error")
___DEF_GLO(14,"exact->inexact")
___DEF_GLO(15,"foldl__0")
___DEF_GLO(16,"for-each")
___DEF_GLO(17,"length")
___DEF_GLO(18,"map")
___DEF_GLO(19,"max")
___DEF_GLO(20,"min")
___END_GLO

#define ___GLO_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count ___GLO(0,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count ___PRM(0,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max ___GLO(1,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max ___PRM(1,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean ___GLO(2,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean ___PRM(2,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min ___GLO(3,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min ___PRM(3,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum ___GLO(4,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum ___PRM(4,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value ___GLO(5,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value ___PRM(5,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_aggregators_3a__3a_timestamp ___GLO(6,___G_gerbil_2d_ascent_2f_program_2f_aggregators_3a__3a_timestamp)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_aggregators_3a__3a_timestamp ___PRM(6,___G_gerbil_2d_ascent_2f_program_2f_aggregators_3a__3a_timestamp)
#define ___GLO_gerbil_2d_ascent____program____aggregators_23_ ___GLO(7,___G_gerbil_2d_ascent____program____aggregators_23_)
#define ___PRM_gerbil_2d_ascent____program____aggregators_23_ ___PRM(7,___G_gerbil_2d_ascent____program____aggregators_23_)
#define ___GLO__23__23_apply ___GLO(8,___G__23__23_apply)
#define ___PRM__23__23_apply ___PRM(8,___G__23__23_apply)
#define ___GLO__23__23_dead_2d_end ___GLO(9,___G__23__23_dead_2d_end)
#define ___PRM__23__23_dead_2d_end ___PRM(9,___G__23__23_dead_2d_end)
#define ___GLO__2b_ ___GLO(10,___G__2b_)
#define ___PRM__2b_ ___PRM(10,___G__2b_)
#define ___GLO__2f_ ___GLO(11,___G__2f_)
#define ___PRM__2f_ ___PRM(11,___G__2f_)
#define ___GLO_car ___GLO(12,___G_car)
#define ___PRM_car ___PRM(12,___G_car)
#define ___GLO_error ___GLO(13,___G_error)
#define ___PRM_error ___PRM(13,___G_error)
#define ___GLO_exact_2d__3e_inexact ___GLO(14,___G_exact_2d__3e_inexact)
#define ___PRM_exact_2d__3e_inexact ___PRM(14,___G_exact_2d__3e_inexact)
#define ___GLO_foldl____0 ___GLO(15,___G_foldl____0)
#define ___PRM_foldl____0 ___PRM(15,___G_foldl____0)
#define ___GLO_for_2d_each ___GLO(16,___G_for_2d_each)
#define ___PRM_for_2d_each ___PRM(16,___G_for_2d_each)
#define ___GLO_length ___GLO(17,___G_length)
#define ___PRM_length ___PRM(17,___G_length)
#define ___GLO_map ___GLO(18,___G_map)
#define ___PRM_map ___PRM(18,___G_map)
#define ___GLO_max ___GLO(19,___G_max)
#define ___PRM_max ___PRM(19,___G_max)
#define ___GLO_min ___GLO(20,___G_min)
#define ___PRM_min ___PRM(20,___G_min)

___DEF_SUB_BIGFIX(___X0,1UL)
               ___BIGFIX1(0x6acb08e8L)
___DEF_SUB_STR(___X1,42UL)
               ___STR8(65,83,67,69,78,84,32,97)
               ___STR8(103,103,114,101,103,97,116,111)
               ___STR8(114,32,101,120,112,101,99,116)
               ___STR8(115,32,111,110,101,32,105,110)
               ___STR8(112,117,116,32,99,111,108,117)
               ___STR2(109,110)
___DEF_SUB_STR(___X2,37UL)
               ___STR8(65,83,67,69,78,84,32,99)
               ___STR8(111,117,110,116,32,101,120,112)
               ___STR8(101,99,116,115,32,110,111,32)
               ___STR8(105,110,112,117,116,32,99,111)
               ___STR5(108,117,109,110,115)
___DEF_SUB_VEC(___X3,6UL)
               ___VEC1(___REF_SUB(4))
               ___VEC1(___REF_SUB(5))
               ___VEC1(___REF_NUL)
               ___VEC1(___REF_FIX(1))
               ___VEC1(___REF_PRC(1))
               ___VEC1(___REF_FAL)
               ___VEC0
___DEF_SUB_VEC(___X4,1UL)
               ___VEC1(___REF_SYM(6,___S_gerbil_2d_ascent____program____aggregators))
               ___VEC0
___DEF_SUB_VEC(___X5,0UL)
               ___VEC0

___BEGIN_SUB
 ___DEF_SUB(___X0)
,___DEF_SUB(___X1)
,___DEF_SUB(___X2)
,___DEF_SUB(___X3)
,___DEF_SUB(___X4)
,___DEF_SUB(___X5)
___END_SUB



#undef ___MD_ALL
#define ___MD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4 ___D_F64(___F64V1) ___D_F64( \
___F64V2) ___D_F64(___F64V3)
#undef ___MR_ALL
#define ___MR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___MW_ALL
#define ___MW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_M_COD
___BEGIN_M_HLBL
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent____program____aggregators_23_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_M_HLBL(___L11_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_M_HLBL(___L12_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_M_HLBL(___L13_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_M_HLBL(___L14_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_M_HLBL(___L15_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_M_HLBL(___L16_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_M_HLBL(___L11_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_M_HLBL(___L12_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_M_HLBL(___L11_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_M_HLBL(___L12_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L11_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L12_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L13_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L14_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L15_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L16_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L17_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L18_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L19_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L20_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L21_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L22_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_M_HLBL(___L23_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___END_M_HLBL

___BEGIN_M_SW

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent____program____aggregators_23_
#undef ___PH_LBL0
#define ___PH_LBL0 1
#undef ___PD_ALL
#define ___PD_ALL ___D_R0 ___D_R1
#undef ___PR_ALL
#define ___PR_ALL ___R_R0 ___R_R1
#undef ___PW_ALL
#define ___PW_ALL ___W_R1
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent____program____aggregators_23_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent____program____aggregators_23_)
   ___IF_NARGS_EQ(0,___NOTHING)
   ___WRONG_NARGS(0,0,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent____program____aggregators_23_)
   ___SET_GLO(6,___G_gerbil_2d_ascent_2f_program_2f_aggregators_3a__3a_timestamp,___BIGFIX(0,1791690984LL))
   ___SET_R1(___VOID)
   ___JUMPRET(___R0)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value
#undef ___PH_LBL0
#define ___PH_LBL0 3
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L2_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
   ___END_IF
   ___SET_R2(___CDR(___R1))
   ___SET_R3(___CAR(___R1))
   ___IF(___NULLP(___R2))
   ___GOTO(___L3_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
   ___END_IF
___DEF_GLBL(___L2_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
   ___SET_R2(___R1)
   ___SET_R1(___SUB(1))
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
   ___JUMPGLONOTSAFE(___SET_NARGS(2),13,___G_error)
___DEF_GLBL(___L3_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
   ___SET_R1(___R3)
   ___JUMPRET(___R0)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count
#undef ___PH_LBL0
#define ___PH_LBL0 6
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R0(___LBL(7))
   ___ADJFP(8)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___GOTO(___L11_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___SET_R1(___STK(-6))
   ___SET_R0(___STK(-7))
   ___ADJFP(-8)
___DEF_GLBL(___L10_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___SET_R1(___CDR(___R1))
   ___POLL(3)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_GLBL(___L11_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L13_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___END_IF
   ___SET_R2(___CAR(___R1))
   ___IF(___NOT(___NULLP(___R2)))
   ___GOTO(___L14_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___END_IF
___DEF_GLBL(___L12_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___SET_R1(___CDR(___R1))
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L13_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___END_IF
   ___SET_R2(___CAR(___R1))
   ___IF(___NULLP(___R2))
   ___GOTO(___L10_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___END_IF
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R1(___SUB(2))
   ___ADJFP(8)
   ___POLL(4)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___SET_R0(___LBL(2))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),13,___G_error)
___DEF_GLBL(___L13_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___SET_R1(___VOID)
   ___JUMPRET(___R0)
___DEF_GLBL(___L14_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R1(___SUB(2))
   ___ADJFP(8)
   ___POLL(5)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___SET_R0(___LBL(6))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),13,___G_error)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___SET_R1(___STK(-6))
   ___SET_R0(___STK(-7))
   ___ADJFP(-8)
   ___GOTO(___L12_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___SET_R1(___STK(-6))
   ___SET_R0(___LBL(8))
   ___ADJFP(-4)
   ___JUMPPRM(___SET_NARGS(1),___PRM_length)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___SET_R1(___CONS(___R1,___NUL))
   ___ADJFP(-3)
   ___CHECK_HEAP(9,4096)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count)
   ___ADJFP(-1)
   ___JUMPRET(___STK(1))
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum
#undef ___PH_LBL0
#define ___PH_LBL0 17
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4 ___D_F64(___F64V1) ___D_F64( \
___F64V2) ___D_F64(___F64V3)
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_P_HLBL(___L11_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_P_HLBL(___L12_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_P_HLBL(___L13_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_P_HLBL(___L14_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_P_HLBL(___L15_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_P_HLBL(___L16_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___IF(___NOT(___PROCEDUREP(___PRC(3))))
   ___GOTO(___L28_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___END_IF
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R2(___R1)
   ___SET_R0(___LBL(9))
   ___ADJFP(8)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___GOTO(___L18_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_GLBL(___L17_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___SET_R2(___CDR(___R2))
   ___POLL(2)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_GLBL(___L18_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___IF(___PAIRP(___R2))
   ___GOTO(___L17_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___END_IF
   ___IF(___NOT(___NULLP(___R2)))
   ___GOTO(___L22_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___END_IF
   ___POLL(3)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_GLBL(___L19_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L21_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___END_IF
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R1(___CAR(___R1))
   ___ADJFP(8)
   ___POLL(4)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___SET_R0(___LBL(5))
   ___JUMPINT(___SET_NARGS(1),___PRC(3),___L_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___SET_R1(___CDR(___STK(-6)))
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L20_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___END_IF
   ___SET_STK(-6,___R1)
   ___SET_R1(___CAR(___R1))
   ___SET_R0(___LBL(6))
   ___JUMPINT(___SET_NARGS(1),___PRC(3),___L_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___SET_R1(___CDR(___STK(-6)))
   ___SET_R0(___STK(-7))
   ___ADJFP(-8)
   ___POLL(7)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___GOTO(___L19_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_GLBL(___L20_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___SET_R1(___VOID)
   ___ADJFP(-8)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L21_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___SET_R1(___VOID)
   ___JUMPRET(___R0)
___DEF_GLBL(___L22_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___SET_R2(___R1)
   ___SET_R1(___PRC(3))
   ___POLL(8)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___JUMPPRM(___SET_NARGS(2),___PRM_for_2d_each)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___SET_R3(___STK(-6))
   ___SET_R1(___LBL(13))
   ___SET_R2(___FIX(0L))
   ___POLL(10)
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___SET_R0(___LBL(11))
   ___ADJFP(-4)
   ___JUMPGLONOTSAFE(___SET_NARGS(3),15,___G_foldl____0)
___DEF_SLBL(11,___L11_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___SET_R1(___CONS(___R1,___NUL))
   ___ADJFP(-3)
   ___CHECK_HEAP(12,4096)
___DEF_SLBL(12,___L12_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___ADJFP(-1)
   ___JUMPRET(___STK(1))
___DEF_SLBL(13,___L13_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___IF_NARGS_EQ(2,___NOTHING)
   ___WRONG_NARGS(13,2,0,0)
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L27_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___END_IF
   ___SET_R1(___CAR(___R1))
   ___IF(___NOT(___FIXNUMSP(___FIXNUMSP2(___FIXNUMSP1(___R1),___R2))))
   ___GOTO(___L23_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___END_IF
   ___IF(___FIXADDP_NOTFALSEP(___R3,___R1,___R2))
   ___GOTO(___L26_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___END_IF
   ___SET_R3(___FAL)
   ___GOTO(___L24_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
___DEF_GLBL(___L23_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___IF(___IFLONUMSP(___IFLONUMSP2(___IFLONUMSP1(___R1),___R2)))
   ___GOTO(___L25_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___END_IF
___DEF_GLBL(___L24_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___POLL(14)
___DEF_SLBL(14,___L14_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___JUMPPRM(___SET_NARGS(2),___PRM__2b_)
___DEF_GLBL(___L25_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___SET_F64(___F64V1,___F64UNBOXI(___R1))
   ___SET_F64(___F64V2,___F64UNBOXI(___R2))
   ___SET_F64(___F64V3,___F64ADD(___F64V1,___F64V2))
   ___SET_R1(___F64BOX(___F64V3))
   ___CHECK_HEAP_FLO(15,4096)
___DEF_SLBL(15,___L15_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___JUMPRET(___R0)
___DEF_GLBL(___L26_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___SET_R1(___R3)
   ___JUMPRET(___R0)
___DEF_GLBL(___L27_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R2)
   ___SET_R0(___LBL(16))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(1),___PRM_car)
___DEF_SLBL(16,___L16_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___SET_R0(___LBL(16))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L28_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R2(___R1)
   ___SET_R1(___PRC(3))
   ___SET_R0(___LBL(16))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM_for_2d_each)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min
#undef ___PH_LBL0
#define ___PH_LBL0 35
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_P_HLBL(___L11_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_P_HLBL(___L12_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___IF(___NOT(___PROCEDUREP(___PRC(3))))
   ___GOTO(___L19_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___END_IF
   ___SET_STK(1,___R0)
   ___SET_R2(___R1)
   ___SET_R0(___LBL(9))
   ___ADJFP(4)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___GOTO(___L14_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_GLBL(___L13_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___SET_R2(___CDR(___R2))
   ___POLL(2)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
___DEF_GLBL(___L14_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___IF(___PAIRP(___R2))
   ___GOTO(___L13_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___END_IF
   ___IF(___NOT(___NULLP(___R2)))
   ___GOTO(___L17_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___END_IF
   ___POLL(3)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L16_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___END_IF
___DEF_GLBL(___L15_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R1(___CAR(___R1))
   ___ADJFP(8)
   ___POLL(4)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___SET_R0(___LBL(5))
   ___JUMPINT(___SET_NARGS(1),___PRC(3),___L_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___SET_STK(-5,___R1)
   ___SET_R1(___CDR(___STK(-6)))
   ___SET_R0(___LBL(6))
   ___IF(___PAIRP(___R1))
   ___GOTO(___L15_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___END_IF
___DEF_GLBL(___L16_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___SET_R1(___NUL)
   ___JUMPRET(___R0)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___SET_R1(___CONS(___STK(-5),___R1))
   ___ADJFP(-7)
   ___CHECK_HEAP(7,4096)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___ADJFP(-1)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L17_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___SET_R2(___R1)
   ___SET_R1(___PRC(3))
   ___POLL(8)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___JUMPPRM(___SET_NARGS(2),___PRM_map)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___IF(___NULLP(___R1))
   ___GOTO(___L18_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___END_IF
   ___SET_R2(___R1)
   ___SET_R1(___PRM_min)
   ___SET_R0(___LBL(10))
   ___JUMPPRM(___SET_NARGS(2),___PRM__23__23_apply)
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___SET_R1(___CONS(___R1,___NUL))
   ___ADJFP(-3)
   ___CHECK_HEAP(11,4096)
___DEF_SLBL(11,___L11_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___ADJFP(-1)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L18_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___SET_R1(___NUL)
   ___ADJFP(-4)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L19_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___SET_STK(1,___R0)
   ___SET_R2(___R1)
   ___SET_R1(___PRC(3))
   ___SET_R0(___LBL(12))
   ___ADJFP(4)
   ___JUMPPRM(___SET_NARGS(2),___PRM_map)
___DEF_SLBL(12,___L12_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min)
   ___SET_R0(___LBL(12))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max
#undef ___PH_LBL0
#define ___PH_LBL0 49
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_P_HLBL(___L11_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_P_HLBL(___L12_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___IF(___NOT(___PROCEDUREP(___PRC(3))))
   ___GOTO(___L19_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___END_IF
   ___SET_STK(1,___R0)
   ___SET_R2(___R1)
   ___SET_R0(___LBL(9))
   ___ADJFP(4)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___GOTO(___L14_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_GLBL(___L13_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___SET_R2(___CDR(___R2))
   ___POLL(2)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
___DEF_GLBL(___L14_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___IF(___PAIRP(___R2))
   ___GOTO(___L13_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___END_IF
   ___IF(___NOT(___NULLP(___R2)))
   ___GOTO(___L17_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___END_IF
   ___POLL(3)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L16_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___END_IF
___DEF_GLBL(___L15_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R1(___CAR(___R1))
   ___ADJFP(8)
   ___POLL(4)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___SET_R0(___LBL(5))
   ___JUMPINT(___SET_NARGS(1),___PRC(3),___L_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___SET_STK(-5,___R1)
   ___SET_R1(___CDR(___STK(-6)))
   ___SET_R0(___LBL(6))
   ___IF(___PAIRP(___R1))
   ___GOTO(___L15_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___END_IF
___DEF_GLBL(___L16_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___SET_R1(___NUL)
   ___JUMPRET(___R0)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___SET_R1(___CONS(___STK(-5),___R1))
   ___ADJFP(-7)
   ___CHECK_HEAP(7,4096)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___ADJFP(-1)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L17_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___SET_R2(___R1)
   ___SET_R1(___PRC(3))
   ___POLL(8)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___JUMPPRM(___SET_NARGS(2),___PRM_map)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___IF(___NULLP(___R1))
   ___GOTO(___L18_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___END_IF
   ___SET_R2(___R1)
   ___SET_R1(___PRM_max)
   ___SET_R0(___LBL(10))
   ___JUMPPRM(___SET_NARGS(2),___PRM__23__23_apply)
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___SET_R1(___CONS(___R1,___NUL))
   ___ADJFP(-3)
   ___CHECK_HEAP(11,4096)
___DEF_SLBL(11,___L11_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___ADJFP(-1)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L18_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___SET_R1(___NUL)
   ___ADJFP(-4)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L19_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___SET_STK(1,___R0)
   ___SET_R2(___R1)
   ___SET_R1(___PRC(3))
   ___SET_R0(___LBL(12))
   ___ADJFP(4)
   ___JUMPPRM(___SET_NARGS(2),___PRM_map)
___DEF_SLBL(12,___L12_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max)
   ___SET_R0(___LBL(12))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean
#undef ___PH_LBL0
#define ___PH_LBL0 63
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4 ___D_F64(___F64V1) ___D_F64( \
___F64V2) ___D_F64(___F64V3)
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L11_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L12_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L13_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L14_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L15_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L16_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L17_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L18_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L19_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L20_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L21_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L22_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_P_HLBL(___L23_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___IF(___NOT(___PROCEDUREP(___PRC(3))))
   ___GOTO(___L46_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___END_IF
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R2(___R1)
   ___SET_R0(___LBL(9))
   ___ADJFP(8)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___GOTO(___L25_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_GLBL(___L24_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R2(___CDR(___R2))
   ___POLL(2)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_GLBL(___L25_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___IF(___PAIRP(___R2))
   ___GOTO(___L24_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___END_IF
   ___IF(___NOT(___NULLP(___R2)))
   ___GOTO(___L29_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___END_IF
   ___POLL(3)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_GLBL(___L26_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L28_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___END_IF
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R1(___CAR(___R1))
   ___ADJFP(8)
   ___POLL(4)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R0(___LBL(5))
   ___JUMPINT(___SET_NARGS(1),___PRC(3),___L_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R1(___CDR(___STK(-6)))
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L27_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___END_IF
   ___SET_STK(-6,___R1)
   ___SET_R1(___CAR(___R1))
   ___SET_R0(___LBL(6))
   ___JUMPINT(___SET_NARGS(1),___PRC(3),___L_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R1(___CDR(___STK(-6)))
   ___SET_R0(___STK(-7))
   ___ADJFP(-8)
   ___POLL(7)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___GOTO(___L26_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_GLBL(___L27_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R1(___VOID)
   ___ADJFP(-8)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L28_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R1(___VOID)
   ___JUMPRET(___R0)
___DEF_GLBL(___L29_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R2(___R1)
   ___SET_R1(___PRC(3))
   ___POLL(8)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___JUMPPRM(___SET_NARGS(2),___PRM_for_2d_each)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___IF(___NULLP(___STK(-6)))
   ___GOTO(___L45_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___END_IF
   ___SET_R1(___BOX(___FIX(0L)))
   ___SET_STK(-5,___ALLOC_CLO(1UL))
   ___BEGIN_SETUP_CLO(1,___STK(-5),19)
   ___ADD_CLO_ELEM(0,___R1)
   ___END_SETUP_CLO(1)
   ___SET_STK(-4,___R1)
   ___SET_R3(___STK(-6))
   ___SET_R1(___STK(-5))
   ___SET_R2(___FIX(0L))
   ___CHECK_HEAP(10,4096)
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___POLL(11)
___DEF_SLBL(11,___L11_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R0(___LBL(12))
   ___JUMPGLONOTSAFE(___SET_NARGS(3),15,___G_foldl____0)
___DEF_SLBL(12,___L12_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___IF(___NOT(___FIXNUMP(___R1)))
   ___GOTO(___L37_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___END_IF
   ___SET_F64(___F64V1,___F64FROMFIX(___R1))
   ___SET_R1(___F64BOX(___F64V1))
   ___CHECK_HEAP_FLO(13,4096)
___DEF_SLBL(13,___L13_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___GOTO(___L30_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_SLBL(14,___L14_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_GLBL(___L30_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R2(___UNBOX(___STK(-4)))
   ___IF(___NOT(___FIXNUMSP(___FIXNUMSP2(___FIXNUMSP1(___R1),___R2))))
   ___GOTO(___L34_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___END_IF
   ___IF(___AND(___FIXLE(___FIX(-1L),___R2),___FIXLE(___R2,___FIX(0L))))
   ___GOTO(___L35_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___END_IF
   ___SET_R3(___FIXQUO(___R1,___R2))
   ___SET_R4(___FIXREM(___R1,___R2))
   ___IF(___NOT(___FIXEQ(___R4,___FIX(0L))))
   ___GOTO(___L33_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___END_IF
   ___ADJFP(-4)
___DEF_GLBL(___L31_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R1(___R3)
___DEF_GLBL(___L32_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R1(___CONS(___R1,___NUL))
   ___ADJFP(-3)
   ___CHECK_HEAP(15,4096)
___DEF_SLBL(15,___L15_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___ADJFP(-1)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L33_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R0(___LBL(16))
   ___ADJFP(-4)
   ___JUMPPRM(___SET_NARGS(2),___PRM__2f_)
___DEF_SLBL(16,___L16_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R3(___R1)
   ___GOTO(___L31_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_GLBL(___L34_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___IF(___IFLONUMSP(___IFLONUMSP2(___IFLONUMSP1(___R1),___R2)))
   ___GOTO(___L36_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___END_IF
___DEF_GLBL(___L35_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R0(___LBL(17))
   ___ADJFP(-4)
   ___JUMPPRM(___SET_NARGS(2),___PRM__2f_)
___DEF_SLBL(17,___L17_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___GOTO(___L32_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_GLBL(___L36_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_F64(___F64V1,___F64UNBOXI(___R1))
   ___SET_F64(___F64V2,___F64UNBOXI(___R2))
   ___SET_F64(___F64V3,___F64DIV(___F64V1,___F64V2))
   ___SET_R1(___F64BOX(___F64V3))
   ___ADJFP(-4)
   ___CHECK_HEAP_FLO(18,4096)
___DEF_SLBL(18,___L18_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___GOTO(___L32_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_GLBL(___L37_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___IF(___IFLONUMP(___R1))
   ___GOTO(___L30_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___END_IF
   ___SET_R0(___LBL(14))
   ___JUMPPRM(___SET_NARGS(1),___PRM_exact_2d__3e_inexact)
___DEF_SLBL(19,___L19_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___IF_NARGS_EQ(2,___NOTHING)
   ___WRONG_NARGS(19,2,0,0)
   ___SET_R3(___CLO(___R4,1))
   ___SET_R3(___UNBOX(___R3))
   ___IF(___NOT(___FIXNUMP(___R3)))
   ___GOTO(___L44_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___END_IF
   ___ADJFP(1)
   ___IF(___NOT(___FIXADDPCONSTY_NOTFALSEP(___STK(0),___R3,___FIX(1L))))
   ___SET_STK(0,___FAL)
   ___GOTO(___L43_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___END_IF
   ___SET_R3(___STK(0))
   ___GOTO(___L38_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
___DEF_SLBL(20,___L20_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R3(___R1)
   ___SET_R4(___STK(-4))
   ___SET_R2(___STK(-5))
   ___SET_R1(___STK(-6))
   ___SET_R0(___STK(-7))
   ___ADJFP(-7)
___DEF_GLBL(___L38_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R4(___CLO(___R4,1))
   ___SETBOX(___R4,___R3)
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L42_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___END_IF
   ___SET_R1(___CAR(___R1))
   ___IF(___NOT(___FIXNUMSP(___FIXNUMSP2(___FIXNUMSP1(___R1),___R2))))
   ___GOTO(___L41_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___END_IF
   ___IF(___FIXADDP_NOTFALSEP(___R3,___R1,___R2))
   ___GOTO(___L40_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___END_IF
   ___SET_R3(___FAL)
___DEF_GLBL(___L39_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___POLL(21)
___DEF_SLBL(21,___L21_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___ADJFP(-1)
   ___JUMPPRM(___SET_NARGS(2),___PRM__2b_)
___DEF_GLBL(___L40_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R1(___R3)
   ___ADJFP(-1)
   ___JUMPRET(___R0)
___DEF_GLBL(___L41_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___IF(___NOT(___IFLONUMSP(___IFLONUMSP2(___IFLONUMSP1(___R1),___R2))))
   ___GOTO(___L39_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___END_IF
   ___SET_F64(___F64V1,___F64UNBOXI(___R1))
   ___SET_F64(___F64V2,___F64UNBOXI(___R2))
   ___SET_F64(___F64V3,___F64ADD(___F64V1,___F64V2))
   ___SET_R1(___F64BOX(___F64V3))
   ___ADJFP(-1)
   ___CHECK_HEAP_FLO(22,4096)
___DEF_SLBL(22,___L22_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___JUMPRET(___R0)
___DEF_GLBL(___L42_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_STK(0,___R0)
   ___SET_STK(1,___R2)
   ___SET_R0(___LBL(23))
   ___ADJFP(7)
   ___JUMPPRM(___SET_NARGS(1),___PRM_car)
___DEF_SLBL(23,___L23_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R0(___LBL(23))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L43_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_STK(0,___R0)
   ___SET_STK(1,___R1)
   ___SET_STK(2,___R2)
   ___SET_STK(3,___R4)
   ___SET_R1(___R3)
   ___SET_R2(___FIX(1L))
   ___SET_R0(___LBL(20))
   ___ADJFP(7)
   ___JUMPPRM(___SET_NARGS(2),___PRM__2b_)
___DEF_GLBL(___L44_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_STK(4,___R4)
   ___SET_R1(___R3)
   ___SET_R2(___FIX(1L))
   ___SET_R0(___LBL(20))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM__2b_)
___DEF_GLBL(___L45_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_R1(___NUL)
   ___ADJFP(-8)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L46_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R2(___R1)
   ___SET_R1(___PRC(3))
   ___SET_R0(___LBL(23))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM_for_2d_each)
___END_P_SW
___END_P_COD

___END_M_SW
___END_M_COD

___BEGIN_LBL
 ___DEF_LBL_INTRO(___H_gerbil_2d_ascent____program____aggregators_23_,___REF_SYM(7,___S_gerbil_2d_ascent____program____aggregators_23_),___REF_FAL,1,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____program____aggregators_23_,0,-1)
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value,___REF_SYM(5,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value),___REF_FAL,2,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count,___REF_SYM(0,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count),___REF_FAL,10,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count,___IFD(___RETI,1,0,0x3f1L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,___REF_SYM(4,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum),___REF_FAL,17,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,___IFD(___RETI,8,0,0x3f01L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,___IFD(___RETI,1,0,0x3f1L))
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,2,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min,___REF_SYM(3,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min),___REF_FAL,13,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min,___IFD(___RETI,4,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min,___IFD(___RETN,5,0,0x5L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min,___IFD(___RETI,1,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min,___IFD(___RETI,1,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max,___REF_SYM(1,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max),___REF_FAL,13,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max,___IFD(___RETI,4,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max,___IFD(___RETN,5,0,0x5L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max,___IFD(___RETI,1,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max,___IFD(___RETI,1,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___REF_SYM(2,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean),___REF_FAL,24,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETI,8,0,0x3f09L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETI,8,0,0x3f09L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETN,5,0,0x9L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETI,8,0,0x3f09L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETN,5,0,0x9L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETI,1,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETI,4,0,0x3f1L))
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,2,1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETN,5,0,0xfL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETI,1,4,0x3f0L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,___IFD(___RETN,5,0,0x3L))
___END_LBL

___BEGIN_MOD_PRM
___DEF_MOD_PRM(7,___G_gerbil_2d_ascent____program____aggregators_23_,1)
___DEF_MOD_PRM(5,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value,3)
___DEF_MOD_PRM(0,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count,6)
___DEF_MOD_PRM(4,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,17)
___DEF_MOD_PRM(3,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min,35)
___DEF_MOD_PRM(1,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max,49)
___DEF_MOD_PRM(2,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,63)
___END_MOD_PRM

___BEGIN_MOD_C_INIT
___END_MOD_C_INIT

___BEGIN_MOD_GLO
___DEF_MOD_GLO(7,___G_gerbil_2d_ascent____program____aggregators_23_,1)
___DEF_MOD_GLO(5,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value,3)
___DEF_MOD_GLO(0,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count,6)
___DEF_MOD_GLO(4,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,17)
___DEF_MOD_GLO(3,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min,35)
___DEF_MOD_GLO(1,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max,49)
___DEF_MOD_GLO(2,___G_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,63)
___END_MOD_GLO

___BEGIN_MOD_SYM_KEY
___DEF_MOD_SYM(0,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_count,"gerbil-ascent/program/aggregators#gerbil-ascent-count")

___DEF_MOD_SYM(1,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_max,"gerbil-ascent/program/aggregators#gerbil-ascent-max")

___DEF_MOD_SYM(2,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_mean,"gerbil-ascent/program/aggregators#gerbil-ascent-mean")

___DEF_MOD_SYM(3,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_min,"gerbil-ascent/program/aggregators#gerbil-ascent-min")

___DEF_MOD_SYM(4,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_gerbil_2d_ascent_2d_sum,"gerbil-ascent/program/aggregators#gerbil-ascent-sum")

___DEF_MOD_SYM(5,___S_gerbil_2d_ascent_2f_program_2f_aggregators_23_single_2d_column_2d_value,"gerbil-ascent/program/aggregators#single-column-value")

___DEF_MOD_SYM(6,___S_gerbil_2d_ascent____program____aggregators,"gerbil-ascent__program__aggregators")

___DEF_MOD_SYM(7,___S_gerbil_2d_ascent____program____aggregators_23_,"gerbil-ascent__program__aggregators#")

___END_MOD_SYM_KEY

#endif
