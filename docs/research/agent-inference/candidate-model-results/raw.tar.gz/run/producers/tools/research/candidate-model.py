#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 tao3k team and Contributors
# SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
"""Small candidate-feedback consumer; uses existing Library and provider IO."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import selectors
import subprocess
import sys
import time
import tarfile

ROOT = Path(__file__).resolve().parents[2]
RUNTIME = ROOT / '.cache/ascent/candidate-interaction/runtime'
PREPARED = ROOT / '.cache/ascent/evidence-interaction/runtime/lib'
CANONICAL = ROOT / '.cache/ascent/candidate-interaction/canonical-runtime/lib'
sys.path.insert(0, str(ROOT / 'python/src'))
from ascent_test_support.model_study import provider
from ascent_test_support.movie_study import provider_key

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def environment():
    env = os.environ.copy()
    env['GERBIL_PATH'] = str(CANONICAL.parent if CANONICAL.exists() else RUNTIME)
    env['GERBIL_LOADPATH'] = f'{CANONICAL}:{PREPARED}' if CANONICAL.exists() else f'{RUNTIME / "lib"}:{PREPARED}'
    for name in ('CC','CFLAGS','CPPFLAGS','LDFLAGS','NIX_CFLAGS_COMPILE','NIX_LDFLAGS','CPATH','SDKROOT'):
        env.pop(name, None)
    return env

class Consumer:
    def __init__(self, run):
        self.trace = []; self.run = run
        self.err = (run/'native-stderr.log').open('a')
        self.p = subprocess.Popen([str(RUNTIME/'bin/candidate-interaction'),'-:max-heap=1G,debug=q'],
            env=environment(), cwd=ROOT, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=self.err, text=True, bufsize=1)
        began=time.monotonic()
        try:
            if self.receive() != {'ready':True}: raise ValueError('native readiness mismatch')
            self.trace.append({'request':{'op':'module_load'},'answer':{'ready':True},'seconds':time.monotonic()-began})
        except Exception as error:
            save(run/'native-readiness-failure.json',{'error':str(error),'seconds':time.monotonic()-began,'deadline':20})
            self.close(); raise

    def receive(self):
        with selectors.DefaultSelector() as selector:
            selector.register(self.p.stdout, selectors.EVENT_READ)
            if not selector.select(20): raise TimeoutError('native 20-second deadline')
        line = self.p.stdout.readline()
        if not line: raise RuntimeError('native exit')
        try:
            return json.loads(line)
        except json.JSONDecodeError:
            with (self.run/'native-invalid-output.log').open('a') as log: log.write(line)
            raise

    def call(self, **request):
        began = time.monotonic()
        event={'request':request}
        self.trace.append(event);save(self.run/'native.json',self.trace)
        self.p.stdin.write(json.dumps(request)+'\n'); self.p.stdin.flush()
        try:
            answer = self.receive();event['answer']=answer
        except Exception as error:
            event['failure']=str(error);raise
        finally:
            event['seconds']=time.monotonic()-began;save(self.run/'native.json', self.trace)
        if isinstance(answer, dict) and 'error' in answer: raise ValueError(answer['error'])
        return answer

    def close(self):
        if self.p.poll() is None:
            self.p.terminate()
            try: self.p.wait(timeout=5)
            except subprocess.TimeoutExpired: self.p.kill(); self.p.wait(timeout=5)
        self.err.close()

TASKS = [
    {'case':0,'meaning':'path(x,y) iff a directed walk of positive length exists from x to y. Cycles can derive path(x,x); zero-length walks alone cannot.', 'derived':[['path',2]],'query':['path','?x','?y']},
    {'case':1,'meaning':'path(x,y) iff a directed walk of positive even length exists from x to y. Walks may repeat vertices. Length zero alone is excluded.', 'derived':[['path',2]],'query':['path','?x','?y']},
    {'case':2,'meaning':'path is directed positive-length reachability. both(z) iff there exist x in left and y in right such that path(x,z) AND path(y,z). left contains 0; right contains 1. Walks may repeat vertices.', 'derived':[['path',2],['both',1]],'query':['both','?z']},
]
TOOL = {'type':'function','name':'submit_rules','description':'Submit rules for the supplied fixed Datalog specification.',
    'parameters':{'type':'object','properties':{'rules':{'type':'array','minItems':1,'maxItems':4,
        'items':{'type':'array','minItems':2,'maxItems':5,'items':{'type':'array','minItems':2,'maxItems':3,
            'items':{'type':['string','integer']}}}}},'required':['rules'],'additionalProperties':False}}

def task(case, examples):
    return {**TASKS[case], 'sourceRelations':[['edge',2]]+([['left',1],['right',1]] if case==2 else []),
        'domain':[0,1,2], 'ruleEncoding':'A rule is [headAtom, bodyAtom1, ...]. An atom is [relationName, argument1, ...]. Strings beginning ? are variables. Other argument values are integer constants. All body atoms are positive and conjunctive. Rules are evaluated to their least fixed point using set semantics. Only declared relations are allowed. The host supplies declarations, the fixed query and limits; submit only rules.',
        'examples':[{'edges':r['edges'],'queryRows':r['expected']} for r in examples]}

def request(context):
    return {'model':'deepseek-flash','input':[{'role':'user','content':json.dumps(context,separators=(',',':'))}],
        'tools':[TOOL],'tool_choice':'auto','reasoning':{'effort':'low'},'max_output_tokens':8192,'stream':True,'store':False}

def call_model(folder, context, previous_cost=0):
    folder.mkdir(parents=True, exist_ok=False);req=request(context);save(folder/'request.json',req)
    reservation=len(json.dumps(req).encode())+4096+8192
    if previous_cost+reservation>32768: return {'failure':'budget_reservation','rules':None,'grossTokens':0}
    _,meta=provider(req,provider_key(),folder/'response.json');term=meta.get('terminal') or {}
    thinking='\n'.join(p.get('text','') for x in term.get('output',[]) if x.get('type')=='reasoning'
        for p in x.get('content',[]) if p.get('type')=='reasoning_text')
    (folder/'thinking.txt').write_text(thinking)
    result={'status':term.get('status'),'usage':term.get('usage'),'failure':None,'rules':None,'grossTokens':None}
    try:
        u=result['usage']
        if not isinstance(u,dict) or any(type(u.get(k)) is not int or u[k]<0 for k in ('input_tokens','output_tokens')):
            raise ValueError('unknown_usage')
        result['grossTokens']=u['input_tokens']+u['output_tokens']
        if previous_cost+result['grossTokens']>32768 or u['output_tokens']>8192: raise ValueError('budget_violation')
        if meta.get('error') or term.get('status')!='completed': raise ValueError('incomplete_provider')
        actions=[x for x in term.get('output',[]) if x.get('type')=='function_call']
        if len(actions)!=1 or actions[0].get('name')!='submit_rules': raise ValueError('expected_one_submission')
        args=json.loads(actions[0]['arguments'])
        if set(args)!={'rules'} or not isinstance(args['rules'],list) or not 1<=len(args['rules'])<=4:
            raise ValueError('invalid_submission')
        result['rules']=args['rules']
    except (ValueError,KeyError,TypeError) as error: result['failure']=str(error)
    save(folder/'receipt.json',result)
    return result

def freeze(run):
    run.mkdir(parents=True,exist_ok=False)
    native=Consumer(run)
    try:
        groups=[]
        try:
            for i in range(8):groups.append(native.call(op='qualify',group=i))
            if [g.get('checks') for g in groups] != [64]*7+[0]:
                raise ValueError('native qualification group failed')
            qualification={'checks':sum(g['checks'] for g in groups),
                'staleRejected':groups[7].get('staleRejected'),
                'boundedNotMatch':groups[7].get('boundedNotMatch')}
            if qualification != {'checks':448,'staleRejected':True,'boundedNotMatch':True}:
                raise ValueError('native qualification failed: '+json.dumps(qualification))
            qualified=True
        except ValueError as error:
            qualified=False
            qualification={'admitted':False,'error':str(error),'completedGroups':groups}
            save(run/'correct-control.json',native.call(op='feedback',case=0,
                rules=[[['path','?x','?y'],['edge','?x','?y']],
                       [['path','?x','?z'],['path','?x','?y'],['edge','?y','?z']]]))
        tasks=[task(i,native.call(op='feedback',case=i,rules=[])) for i in range(3)]
    finally: native.close()
    save(run/'qualification.json',qualification)
    paths=[ROOT/'tools/research/candidate-model.py',ROOT/'tools/research/candidate-interaction.ss',
           ROOT/'python/src/ascent_test_support/model_study.py',ROOT/'python/src/ascent_test_support/movie_study.py',
           ROOT/'tools/model-source-closure.ss']
    modules=json.loads((RUNTIME/'closure.json').read_text())['modules']
    if any('poo-flow' in m for m in modules): raise ValueError('workflow dependency in Library fixture')
    # Resolve only the compiler-reported runtime closure, not unrelated prepared modules.
    system=Path(subprocess.check_output(['/opt/homebrew/bin/gxi','-e','(display (path-expand "lib" (gerbil-home)))'],text=True).strip())
    for module in modules:
        rel=module.lstrip(':').split('~',1)[0]
        found=False
        for lib in [CANONICAL,RUNTIME/'lib',PREPARED,system]:
            prefix=lib/rel
            files=[p for p in prefix.parent.glob(prefix.name+'*') if p.is_file() and not p.name.endswith('.lock')]
            if files: paths+=files;found=True;break
        if not found: raise ValueError('unbound runtime module '+module)
        src=ROOT/(rel.removeprefix('gerbil-ascent/')+'.ss')
        captured=RUNTIME/'current-source'/src.relative_to(ROOT)
        if 'tools/research/' not in str(src) and captured.exists(): src=captured
        if src.exists():
            paths.append(src)
            relative=src.relative_to(RUNTIME/'current-source') if src.is_relative_to(RUNTIME/'current-source') else src.relative_to(ROOT)
            old=ROOT/'.cache/ascent/crosspath-search/snapshot'/relative
            if 'tools/research/' not in str(src) and old.exists() and src.read_bytes()!=old.read_bytes():
                receipt_path=RUNTIME/'current-source-build.json'
                receipts=json.loads(receipt_path.read_text()) if receipt_path.exists() else {}
                rebuilt=receipts.get(str(relative),{})
                if rebuilt.get('sourceSha256')!=digest(src) or not rebuilt.get('compiledC'):
                    raise ValueError('prepared source drift '+str(src))
                if rebuilt.get('compiledCSha256')!=digest(Path(rebuilt['compiledC'])):
                    raise ValueError('rebuilt module artifact drift '+str(src))
                if rebuilt['compiledC'] not in json.loads((RUNTIME/'native-object-sources.json').read_text()):
                    raise ValueError('rebuilt source absent from native link '+str(src))
                paths.append(receipt_path)
    paths += [RUNTIME/'bin/candidate-interaction',RUNTIME/'closure.json']
    native_sources=[Path(p) for p in json.loads((RUNTIME/'native-object-sources.json').read_text())]
    for module in modules:
        name=module.replace('/','__')+'.c'
        for static in (CANONICAL/'static',RUNTIME/'lib/static',PREPARED/'static',system/'static'):
            if (static/name).exists() and name not in {p.name for p in native_sources}:
                raise ValueError('runtime submodule omitted from native link: '+module)
    paths += native_sources
    paths += list((RUNTIME/'native-objects').glob('*.o'))
    capture=RUNTIME/'source-capture.json'
    if capture.exists():
        for relative,sha in json.loads(capture.read_text())['sourceSha256'].items():
            captured=RUNTIME/'current-source'/relative
            if digest(captured)!=sha: raise ValueError('captured source drift '+relative)
            paths.append(captured)
        paths.append(capture)
    binding={str(p):digest(p) for p in sorted(set(paths))}
    plan={'tasks':tasks,'tool':TOOL,'binding':binding,'model':'deepseek-flash','budgetPerTrajectory':32768,
        'nativeQualified':qualified,
        'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'librarySourceCapture':json.loads(capture.read_text()) if capture.exists() else None,
        'qualificationSha256':digest(run/'qualification.json'),
        'outputCap':8192,'developmentMasks':[0,1,3,9],'heldOutMasks':[i for i in range(64) if i not in (0,1,3,9)],
        'protocol':'One initial model proposal per task. Only a completed, known-cost proposal failing visible development rows receives one paired revision: same proposal/task, baseline without feedback versus native complete-row feedback. Hidden masks never drive repair. Charge shared initial cost to both trajectories; physical calls count once. No retries, anti-repetition instructions or search controller.',
        'limits':'Finite three-node synthesis/feedback integration gate, not corpus reproduction or proof of reduced thinking. If every development proposal passes, assistance comparison is unexercised. No new formal proof or current-head remote CI claim.'}
    save(run/'plan.json',plan);(run/'plan.sha256').write_text(digest(run/'plan.json')+'\n')
    for path in paths:
        if path.suffix=='.py' or path==ROOT/'tools/research/candidate-interaction.ss':
            dest=run/'producers'/path.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(path.read_bytes())
    save(run/'payload-review.json',{'destination':'https://api.deepseek.com/responses','payload':'Synthetic Datalog specifications, four visible graphs and candidate rules. No source files, private records or credentials.', 'requests':[request(t) for t in tasks]})
    print('FROZEN' if qualified else 'FROZEN_NOT_ADMITTED',qualification,digest(run/'plan.json'),flush=True)

def verify(run,plan):
    if digest(run/'plan.json')!=(run/'plan.sha256').read_text().strip(): raise ValueError('plan drift')
    if digest(run/'qualification.json')!=plan['qualificationSha256']: raise ValueError('qualification drift')
    for p,h in plan['binding'].items():
        if digest(Path(p))!=h: raise ValueError('producer drift '+p)

def solve(run):
    plan=json.loads((run/'plan.json').read_text());verify(run,plan)
    if plan.get('nativeQualified') is not True: raise ValueError('native qualification denied; model calls prohibited')
    if (run/'ledger.json').exists(): raise ValueError('already run; retain results')
    native=Consumer(run);rows=[]
    try:
        for t in plan['tasks']:
            i=t['case'];row={'case':i,'initial':{'failure':'not_completed','rules':None,'grossTokens':None},'revisions':[]}
            rows.append(row);save(run/'ledger.json',rows)
            initial=call_model(run/'calls'/f'{i}-initial',t);row['initial']=initial;save(run/'ledger.json',rows)
            if initial['rules'] is not None:
                dev=native.call(op='feedback',case=i,rules=initial['rules']);row['development']=dev
                # Repair is decided by visible data, before any hidden assessment.
                if any(x['status']!='match' for x in dev):
                    for arm in ('baseline','feedback'):
                        context={**t,'candidateRules':initial['rules']}
                        if arm=='feedback':context['executionFeedback']=dev
                        revision=call_model(run/'calls'/f'{i}-{arm}',context,initial['grossTokens'])
                        revised={'arm':arm,'call':revision};row['revisions'].append(revised);save(run/'ledger.json',rows)
                        revised['grade']=native.call(op='grade',case=i,rules=revision['rules']) if revision['rules'] is not None else None
                row['grade']=native.call(op='grade',case=i,rules=initial['rules'])
            save(run/'ledger.json',rows);print('TASK_DONE',i,'failure',initial['failure'],'paired',len(row['revisions']),flush=True)
    except Exception as error:
        row['interactionFailure']=str(error);save(run/'ledger.json',rows)
        save(run/'failure.json',{'case':row['case'],'error':str(error),'remainingTasks':'not run','retry':False})
        print('INTERACTION_STOPPED',row['case'],str(error),flush=True)
    finally: native.close()
    verify(run,plan)
    save(run/'integrity.json',{'bindingVerified':True,'files':{str(p.relative_to(run)):digest(p) for p in sorted(run.rglob('*')) if p.is_file() and p.name!='integrity.json'}})
    doc=ROOT/'docs/research/agent-inference/candidate-model-results';doc.mkdir(exist_ok=True)
    for name in ['plan.json','qualification.json','ledger.json','integrity.json']:(doc/name).write_bytes((run/name).read_bytes())
    lines=['# Finite Library candidate-feedback model gate','',plan['limits'],'',
           '| Task | Initial held-out matches / evaluated | Complete native attempts | Paired revisions |','|---|---:|---:|---:|']
    for r in rows:
        grade=r.get('grade');matches=f"{sum(x['status']=='match' for x in grade)} / {len(grade)}" if grade is not None else 'not evaluated'
        complete=sum(x['nativeStatus']=='complete' for x in grade) if grade is not None else 'not evaluated'
        lines.append(f"| {r['case']} | {matches} | {complete} | {len(r['revisions'])} |")
    for r in rows:
        if r['initial']['failure'] or r.get('interactionFailure'):lines.append(f"\nTask {r['case']} failure: {r.get('interactionFailure') or r['initial']['failure']}.\n")
    calls=[r['initial'] for r in rows]+[x['call'] for r in rows for x in r['revisions']]
    lines+=['',f"Known physical input + all-output tokens: {sum(c['grossTokens'] or 0 for c in calls)}; unknown-cost calls: {sum(c['grossTokens'] is None for c in calls)}. Unused budget is not savings.", '',
            'Full row differences, rejection/exhaustion, raw provider events, thinking and failures are retained. Only the initial proposal or one frozen development-driven revision is evaluated. No repeated-thinking reduction or search-depth benefit is claimed.']
    (doc/'report.md').write_text('\n'.join(lines)+'\n')
    with tarfile.open(doc/'raw.tar.gz','w:gz') as tar:
        tar.add(run,arcname='run');tar.add(RUNTIME,arcname='runtime')
        if CANONICAL.exists():tar.add(CANONICAL.parent,arcname='canonical-runtime')
        if (run.parent/'canonical-source').exists():tar.add(run.parent/'canonical-source',arcname='canonical-source')
        for failure in sorted(run.parent.glob('failed-*')):
            if failure.is_dir():tar.add(failure,arcname=failure.name)
        for log in run.parent.glob('*.log'):tar.add(log,arcname='logs/'+log.name)
        for receipt in run.parent.glob('*.json'):tar.add(receipt,arcname='receipts/'+receipt.name)
    save(doc/'archive.json',{'sha256':digest(doc/'raw.tar.gz'),'bytes':(doc/'raw.tar.gz').stat().st_size})
    print('COMPLETE',len(rows),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('command',choices=['freeze','solve']);parser.add_argument('--run-dir',type=Path,required=True)
    a=parser.parse_args();globals()[a.command](a.run_dir.resolve())
