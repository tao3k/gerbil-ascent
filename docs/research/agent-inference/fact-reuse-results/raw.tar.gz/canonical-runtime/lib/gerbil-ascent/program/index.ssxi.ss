prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/program

(begin
  (declare-class
   gerbil-ascent/program/index#row-indexes::t
   (@class gerbil-ascent/program/index#row-indexes::t
           ()
           (object::t t::t)
           (rows advance! plan! visit-parts)
           (rows advance! plan! visit-parts)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/program/index#row-indexes::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/index#row-indexes::t)
    'class::t))
  (declare-type
   gerbil-ascent/program/index#row-indexes?
   (@predicate gerbil-ascent/program/index#row-indexes::t))
  (declare-type
   gerbil-ascent/program/index#make-row-indexes
   (@constructor gerbil-ascent/program/index#row-indexes::t))
  (declare-type
   gerbil-ascent/program/index#row-indexes-rows
   (@accessor gerbil-ascent/program/index#row-indexes::t rows #t))
  (declare-type
   gerbil-ascent/program/index#row-indexes-advance!
   (@accessor gerbil-ascent/program/index#row-indexes::t advance! #t))
  (declare-type
   gerbil-ascent/program/index#row-indexes-plan!
   (@accessor gerbil-ascent/program/index#row-indexes::t plan! #t))
  (declare-type
   gerbil-ascent/program/index#row-indexes-visit-parts
   (@accessor gerbil-ascent/program/index#row-indexes::t visit-parts #t))
  (declare-type
   gerbil-ascent/program/index#row-indexes-rows-set!
   (@mutator gerbil-ascent/program/index#row-indexes::t rows #t))
  (declare-type
   gerbil-ascent/program/index#row-indexes-advance!-set!
   (@mutator gerbil-ascent/program/index#row-indexes::t advance! #t))
  (declare-type
   gerbil-ascent/program/index#row-indexes-plan!-set!
   (@mutator gerbil-ascent/program/index#row-indexes::t plan! #t))
  (declare-type
   gerbil-ascent/program/index#row-indexes-visit-parts-set!
   (@mutator gerbil-ascent/program/index#row-indexes::t visit-parts #t))
  (declare-type
   gerbil-ascent/program/index#&row-indexes-rows
   (@accessor gerbil-ascent/program/index#row-indexes::t rows #f))
  (declare-type
   gerbil-ascent/program/index#&row-indexes-advance!
   (@accessor gerbil-ascent/program/index#row-indexes::t advance! #f))
  (declare-type
   gerbil-ascent/program/index#&row-indexes-plan!
   (@accessor gerbil-ascent/program/index#row-indexes::t plan! #f))
  (declare-type
   gerbil-ascent/program/index#&row-indexes-visit-parts
   (@accessor gerbil-ascent/program/index#row-indexes::t visit-parts #f))
  (declare-type
   gerbil-ascent/program/index#&row-indexes-rows-set!
   (@mutator gerbil-ascent/program/index#row-indexes::t rows #f))
  (declare-type
   gerbil-ascent/program/index#&row-indexes-advance!-set!
   (@mutator gerbil-ascent/program/index#row-indexes::t advance! #f))
  (declare-type
   gerbil-ascent/program/index#&row-indexes-plan!-set!
   (@mutator gerbil-ascent/program/index#row-indexes::t plan! #f))
  (declare-type
   gerbil-ascent/program/index#&row-indexes-visit-parts-set!
   (@mutator gerbil-ascent/program/index#row-indexes::t visit-parts #f))
  (declare-type
   gerbil-ascent/program/index#row-indexes-plan-atoms!
   (@lambda 1
            #f
            signature:
            (return:
             procedure::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/index)))
  (declare-type
   gerbil-ascent/program/index#visit-action-atoms!
   (@lambda 2
            #f
            signature:
            (return:
             void::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/index)))
  (declare-type
   gerbil-ascent/program/index#collect-sharing-atoms
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/index)))
  (declare-class
   gerbil-ascent/program/index#provider-row-member::t
   (@class gerbil-ascent/program/index#provider-row-member::t
           ()
           (object::t t::t)
           (ordinal key occurrences)
           (ordinal key occurrences)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/program/index#provider-row-member::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/index#provider-row-member::t)
    'class::t))
  (declare-type
   gerbil-ascent/program/index#provider-row-member?
   (@predicate gerbil-ascent/program/index#provider-row-member::t))
  (declare-type
   gerbil-ascent/program/index#make-provider-row-member
   (@constructor gerbil-ascent/program/index#provider-row-member::t))
  (declare-type
   gerbil-ascent/program/index#provider-row-member-ordinal
   (@accessor gerbil-ascent/program/index#provider-row-member::t ordinal #t))
  (declare-type
   gerbil-ascent/program/index#provider-row-member-key
   (@accessor gerbil-ascent/program/index#provider-row-member::t key #t))
  (declare-type
   gerbil-ascent/program/index#provider-row-member-occurrences
   (@accessor
    gerbil-ascent/program/index#provider-row-member::t
    occurrences
    #t))
  (declare-type
   gerbil-ascent/program/index#provider-row-member-ordinal-set!
   (@mutator gerbil-ascent/program/index#provider-row-member::t ordinal #t))
  (declare-type
   gerbil-ascent/program/index#provider-row-member-key-set!
   (@mutator gerbil-ascent/program/index#provider-row-member::t key #t))
  (declare-type
   gerbil-ascent/program/index#provider-row-member-occurrences-set!
   (@mutator
    gerbil-ascent/program/index#provider-row-member::t
    occurrences
    #t))
  (declare-type
   gerbil-ascent/program/index#&provider-row-member-ordinal
   (@accessor gerbil-ascent/program/index#provider-row-member::t ordinal #f))
  (declare-type
   gerbil-ascent/program/index#&provider-row-member-key
   (@accessor gerbil-ascent/program/index#provider-row-member::t key #f))
  (declare-type
   gerbil-ascent/program/index#&provider-row-member-occurrences
   (@accessor
    gerbil-ascent/program/index#provider-row-member::t
    occurrences
    #f))
  (declare-type
   gerbil-ascent/program/index#&provider-row-member-ordinal-set!
   (@mutator gerbil-ascent/program/index#provider-row-member::t ordinal #f))
  (declare-type
   gerbil-ascent/program/index#&provider-row-member-key-set!
   (@mutator gerbil-ascent/program/index#provider-row-member::t key #f))
  (declare-type
   gerbil-ascent/program/index#&provider-row-member-occurrences-set!
   (@mutator
    gerbil-ascent/program/index#provider-row-member::t
    occurrences
    #f))
  (declare-class
   gerbil-ascent/program/index#provider-row-witness::t
   (@class gerbil-ascent/program/index#provider-row-witness::t
           ()
           (object::t t::t)
           (members counts)
           (members counts)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/program/index#provider-row-witness::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/index#provider-row-witness::t)
    'class::t))
  (declare-type
   gerbil-ascent/program/index#provider-row-witness?
   (@predicate gerbil-ascent/program/index#provider-row-witness::t))
  (declare-type
   gerbil-ascent/program/index#make-provider-row-witness
   (@constructor gerbil-ascent/program/index#provider-row-witness::t))
  (declare-type
   gerbil-ascent/program/index#provider-row-witness-members
   (@accessor gerbil-ascent/program/index#provider-row-witness::t members #t))
  (declare-type
   gerbil-ascent/program/index#provider-row-witness-counts
   (@accessor gerbil-ascent/program/index#provider-row-witness::t counts #t))
  (declare-type
   gerbil-ascent/program/index#provider-row-witness-members-set!
   (@mutator gerbil-ascent/program/index#provider-row-witness::t members #t))
  (declare-type
   gerbil-ascent/program/index#provider-row-witness-counts-set!
   (@mutator gerbil-ascent/program/index#provider-row-witness::t counts #t))
  (declare-type
   gerbil-ascent/program/index#&provider-row-witness-members
   (@accessor gerbil-ascent/program/index#provider-row-witness::t members #f))
  (declare-type
   gerbil-ascent/program/index#&provider-row-witness-counts
   (@accessor gerbil-ascent/program/index#provider-row-witness::t counts #f))
  (declare-type
   gerbil-ascent/program/index#&provider-row-witness-members-set!
   (@mutator gerbil-ascent/program/index#provider-row-witness::t members #f))
  (declare-type
   gerbil-ascent/program/index#&provider-row-witness-counts-set!
   (@mutator gerbil-ascent/program/index#provider-row-witness::t counts #f))
  (declare-type
   gerbil-ascent/program/index#checked-provider-rows
   (@lambda 4
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/index)))
  (declare-type
   gerbil-ascent/program/index#extend-provider-row-witness!
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/index)))
  (declare-type
   gerbil-ascent/program/index#build-provider-row-witness
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/index)))
  (declare-type
   gerbil-ascent/program/index#row-indexes-plan-rules!
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/index)))
  (declare-type
   gerbil-ascent/program/index#row-indexes-plan-actions!
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/index)))
  (declare-type
   gerbil-ascent/program/index#row-indexes-plan-positive-rules!
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/index)))
  (declare-type
   gerbil-ascent/program/index#empty-row-indexes
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/index#empty-row-indexes)
    'gerbil-ascent/program/index#row-indexes::t))
  (declare-class
   gerbil-ascent/program/index#physical-index-entry::t
   (@class gerbil-ascent/program/index#physical-index-entry::t
           ()
           (object::t t::t)
           (version lookup shared? witness)
           (version lookup shared? witness)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/program/index#physical-index-entry::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/index#physical-index-entry::t)
    'class::t))
  (declare-type
   gerbil-ascent/program/index#physical-index-entry?
   (@predicate gerbil-ascent/program/index#physical-index-entry::t))
  (declare-type
   gerbil-ascent/program/index#make-physical-index-entry
   (@constructor gerbil-ascent/program/index#physical-index-entry::t))
  (declare-type
   gerbil-ascent/program/index#physical-index-entry-version
   (@accessor gerbil-ascent/program/index#physical-index-entry::t version #t))
  (declare-type
   gerbil-ascent/program/index#physical-index-entry-lookup
   (@accessor gerbil-ascent/program/index#physical-index-entry::t lookup #t))
  (declare-type
   gerbil-ascent/program/index#physical-index-entry-shared?
   (@accessor gerbil-ascent/program/index#physical-index-entry::t shared? #t))
  (declare-type
   gerbil-ascent/program/index#physical-index-entry-witness
   (@accessor gerbil-ascent/program/index#physical-index-entry::t witness #t))
  (declare-type
   gerbil-ascent/program/index#physical-index-entry-version-set!
   (@mutator gerbil-ascent/program/index#physical-index-entry::t version #t))
  (declare-type
   gerbil-ascent/program/index#physical-index-entry-lookup-set!
   (@mutator gerbil-ascent/program/index#physical-index-entry::t lookup #t))
  (declare-type
   gerbil-ascent/program/index#physical-index-entry-shared?-set!
   (@mutator gerbil-ascent/program/index#physical-index-entry::t shared? #t))
  (declare-type
   gerbil-ascent/program/index#physical-index-entry-witness-set!
   (@mutator gerbil-ascent/program/index#physical-index-entry::t witness #t))
  (declare-type
   gerbil-ascent/program/index#&physical-index-entry-version
   (@accessor gerbil-ascent/program/index#physical-index-entry::t version #f))
  (declare-type
   gerbil-ascent/program/index#&physical-index-entry-lookup
   (@accessor gerbil-ascent/program/index#physical-index-entry::t lookup #f))
  (declare-type
   gerbil-ascent/program/index#&physical-index-entry-shared?
   (@accessor gerbil-ascent/program/index#physical-index-entry::t shared? #f))
  (declare-type
   gerbil-ascent/program/index#&physical-index-entry-witness
   (@accessor gerbil-ascent/program/index#physical-index-entry::t witness #f))
  (declare-type
   gerbil-ascent/program/index#&physical-index-entry-version-set!
   (@mutator gerbil-ascent/program/index#physical-index-entry::t version #f))
  (declare-type
   gerbil-ascent/program/index#&physical-index-entry-lookup-set!
   (@mutator gerbil-ascent/program/index#physical-index-entry::t lookup #f))
  (declare-type
   gerbil-ascent/program/index#&physical-index-entry-shared?-set!
   (@mutator gerbil-ascent/program/index#physical-index-entry::t shared? #f))
  (declare-type
   gerbil-ascent/program/index#&physical-index-entry-witness-set!
   (@mutator gerbil-ascent/program/index#physical-index-entry::t witness #f))
  (declare-class
   gerbil-ascent/program/index#atom-index-view::t
   (@class gerbil-ascent/program/index#atom-index-view::t
           ()
           (object::t t::t)
           (entry permutation)
           (entry permutation)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/program/index#atom-index-view::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/index#atom-index-view::t)
    'class::t))
  (declare-type
   gerbil-ascent/program/index#atom-index-view?
   (@predicate gerbil-ascent/program/index#atom-index-view::t))
  (declare-type
   gerbil-ascent/program/index#make-atom-index-view
   (@constructor gerbil-ascent/program/index#atom-index-view::t))
  (declare-type
   gerbil-ascent/program/index#atom-index-view-entry
   (@accessor gerbil-ascent/program/index#atom-index-view::t entry #t))
  (declare-type
   gerbil-ascent/program/index#atom-index-view-permutation
   (@accessor gerbil-ascent/program/index#atom-index-view::t permutation #t))
  (declare-type
   gerbil-ascent/program/index#atom-index-view-entry-set!
   (@mutator gerbil-ascent/program/index#atom-index-view::t entry #t))
  (declare-type
   gerbil-ascent/program/index#atom-index-view-permutation-set!
   (@mutator gerbil-ascent/program/index#atom-index-view::t permutation #t))
  (declare-type
   gerbil-ascent/program/index#&atom-index-view-entry
   (@accessor gerbil-ascent/program/index#atom-index-view::t entry #f))
  (declare-type
   gerbil-ascent/program/index#&atom-index-view-permutation
   (@accessor gerbil-ascent/program/index#atom-index-view::t permutation #f))
  (declare-type
   gerbil-ascent/program/index#&atom-index-view-entry-set!
   (@mutator gerbil-ascent/program/index#atom-index-view::t entry #f))
  (declare-type
   gerbil-ascent/program/index#&atom-index-view-permutation-set!
   (@mutator gerbil-ascent/program/index#atom-index-view::t permutation #f))
  (declare-type
   gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__%
   (@lambda 8
            #f
            signature:
            (return:
             gerbil-ascent/program/index#row-indexes::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/index)))
  (declare-type
   gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__0
   (@lambda 7
            #f
            signature:
            (return:
             gerbil-ascent/program/index#row-indexes::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/index)))
  (declare-type
   gerbil-ascent/program/index#gerbil-ascent-make-row-indexes
   (@case-lambda
    (7
     gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__0
     signature:
     (return:
      gerbil-ascent/program/index#row-indexes::t
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/program/index))
    (8
     gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__%
     signature:
     (return:
      gerbil-ascent/program/index#row-indexes::t
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/program/index))))
  (declare-type
   gerbil-ascent/program/index#make-required-row-indexes
   (@lambda 7
            #f
            signature:
            (return:
             gerbil-ascent/program/index#row-indexes::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/index))))
