(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/analysis::timestamp 1791691008)
  (begin
    (define gerbil-ascent/program/analysis#+program-analysis-cache+
      (let ((__tmp35977 (make-mutex 'ascent-program-analysis)))
        (declare (not safe))
        (make-hash-table-eq 'weak-keys: '#t 'lock: __tmp35977)))
    (define gerbil-ascent/program/analysis#+program-schema-cache+
      (let ((__tmp35978 (make-mutex 'ascent-program-schema)))
        (declare (not safe))
        (make-hash-table-eq 'weak-keys: '#t 'lock: __tmp35978)))
    (define gerbil-ascent/program/analysis#gerbil-ascent-program-analysis
      (lambda (_%program8104%_ _%relations8105%_ _%rules8106%_ _%build8107%_)
        (let ((_%cached8109%_
               (let ()
                 (declare (not safe))
                 (__hash-get
                  gerbil-ascent/program/analysis#+program-analysis-cache+
                  _%program8104%_))))
          (if (and _%cached8109%_
                   (eq? _%relations8105%_ (vector-ref _%cached8109%_ '0))
                   (eq? _%rules8106%_ (vector-ref _%cached8109%_ '1)))
              _%cached8109%_
              (let ((_%fresh8111%_ (_%build8107%_)))
                (let ()
                  (declare (not safe))
                  (__hash-put!
                   gerbil-ascent/program/analysis#+program-analysis-cache+
                   _%program8104%_
                   _%fresh8111%_))
                _%fresh8111%_)))))
    (define gerbil-ascent/program/analysis#gerbil-ascent-program-schema
      (lambda (_%program8049%_ _%relations8050%_)
        (let ((_%cached8052%_
               (let ()
                 (declare (not safe))
                 (__hash-get
                  gerbil-ascent/program/analysis#+program-schema-cache+
                  _%program8049%_))))
          (if (and _%cached8052%_
                   (eq? _%relations8050%_ (vector-ref _%cached8052%_ '0)))
              _%cached8052%_
              (let* ((_%count8054%_ (length _%relations8050%_))
                     (_%names8056%_
                      (let ()
                        (declare (not safe))
                        (##make-vector _%count8054%_ '#f)))
                     (_%arity8058%_
                      (let ()
                        (declare (not safe))
                        (##make-vector _%count8054%_ '#f)))
                     (_%field-checkers8060%_
                      (let ()
                        (declare (not safe))
                        (##make-vector _%count8054%_ '#f)))
                     (_%positions8062%_
                      (let () (declare (not safe)) (make-hash-table-eq)))
                     (_%index-providers8064%_
                      (let ()
                        (declare (not safe))
                        (##make-vector _%count8054%_ '#f)))
                     (_%storage-extensions8066%_
                      (let ()
                        (declare (not safe))
                        (##make-vector _%count8054%_ '#f)))
                     (_%lattice-joins8068%_
                      (let ()
                        (declare (not safe))
                        (##make-vector _%count8054%_ '#f)))
                     (_%kinds8070%_
                      (let ()
                        (declare (not safe))
                        (##make-vector _%count8054%_ '#f)))
                     (_%storage-providers8072%_
                      (let ()
                        (declare (not safe))
                        (##make-vector _%count8054%_ '#f))))
                (for-each
                 (lambda (_%relation8075%_ _%index8076%_)
                   (let* ((_%name8078%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref _%relation8075%_ 'name)))
                          (_%width8080%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref _%relation8075%_ 'arity)))
                          (_%kind8082%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%relation8075%_
                              'storage-kind)))
                          (_%predicates8084%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%relation8075%_
                              'field-predicates))))
                     (if (and (symbol? _%name8078%_)
                              (if (let ()
                                    (declare (not safe))
                                    (__hash-get
                                     _%positions8062%_
                                     _%name8078%_))
                                  '#f
                                  (and (exact-integer? _%width8080%_)
                                       (<= '0 _%width8080%_)
                                       (let ()
                                         (declare (not safe))
                                         (##memq _%kind8082%_
                                                 '(relation lattice)))
                                       (or (eq? _%kind8082%_ 'relation)
                                           (> _%width8080%_ '0))
                                       (list? _%predicates8084%_)
                                       (or (null? _%predicates8084%_)
                                           (= (let ()
                                                (declare (not safe))
                                                (##length _%predicates8084%_))
                                              _%width8080%_))
                                       (let ()
                                         (declare (not safe))
                                         (andmap__0
                                          procedure?
                                          _%predicates8084%_)))))
                         '#!void
                         (let ()
                           (declare (not safe))
                           (error '"invalid or duplicate ASCENT relation"
                                  _%name8078%_)))
                     (vector-set! _%names8056%_ _%index8076%_ _%name8078%_)
                     (vector-set! _%arity8058%_ _%index8076%_ _%width8080%_)
                     (vector-set! _%kinds8070%_ _%index8076%_ _%kind8082%_)
                     (let ((__tmp35979 (+ _%index8076%_ '1)))
                       (declare (not safe))
                       (__hash-put! _%positions8062%_ _%name8078%_ __tmp35979))
                     (if (pair? _%predicates8084%_)
                         (vector-set!
                          _%field-checkers8060%_
                          _%index8076%_
                          (lambda (_%row8093%_)
                            (let ((__tmp35980
                                   (lambda (_%predicate8095%_ _%value8096%_)
                                     (if (_%predicate8095%_ _%value8096%_)
                                         '#!void
                                         (let ()
                                           (declare (not safe))
                                           (error '"ASCENT relation field type mismatch"
                                                  _%name8078%_
                                                  _%row8093%_))))))
                              (declare (not safe))
                              (##for-each
                               __tmp35980
                               _%predicates8084%_
                               _%row8093%_))))
                         '#!void)
                     (vector-set!
                      _%index-providers8064%_
                      _%index8076%_
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref
                         _%relation8075%_
                         'index-provider)))
                     (if (eq? _%kind8082%_ 'lattice)
                         (let ((_%join8098%_
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/object#.ref
                                   _%relation8075%_
                                   'join))))
                           (if (procedure? _%join8098%_)
                               '#!void
                               (let ()
                                 (declare (not safe))
                                 (error '"invalid ASCENT lattice join"
                                        _%name8078%_)))
                           (vector-set!
                            _%lattice-joins8068%_
                            _%index8076%_
                            _%join8098%_))
                         (let ((_%provider8100%_
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/object#.ref
                                   _%relation8075%_
                                   'storage-provider))))
                           (vector-set!
                            _%storage-providers8072%_
                            _%index8076%_
                            _%provider8100%_)
                           (vector-set!
                            _%storage-extensions8066%_
                            _%index8076%_
                            (let ()
                              (declare (not safe))
                              (gerbil-ascent/table/storage#gerbil-ascent-storage-engine-extension
                               _%provider8100%_
                               _%width8080%_)))))))
                 _%relations8050%_
                 (let () (declare (not safe)) (##iota _%count8054%_)))
                (let ((_%fresh8102%_
                       (vector _%relations8050%_
                               _%names8056%_
                               _%arity8058%_
                               _%field-checkers8060%_
                               _%positions8062%_
                               _%index-providers8064%_
                               _%storage-extensions8066%_
                               _%lattice-joins8068%_
                               _%kinds8070%_
                               _%storage-providers8072%_)))
                  (let ()
                    (declare (not safe))
                    (__hash-put!
                     gerbil-ascent/program/analysis#+program-schema-cache+
                     _%program8049%_
                     _%fresh8102%_))
                  _%fresh8102%_))))))))
