prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/program

(begin
  (declare-class
   gerbil-ascent/program/source-state#source-state::t
   (@class gerbil-ascent/program/source-state#source-state::t
           ()
           (object::t t::t)
           (originals additions overrides snapshot)
           (originals additions overrides snapshot)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/program/source-state#source-state::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/source-state#source-state::t)
    'class::t))
  (declare-type
   gerbil-ascent/program/source-state#source-state?
   (@predicate gerbil-ascent/program/source-state#source-state::t))
  (declare-type
   gerbil-ascent/program/source-state#make-source-state
   (@constructor gerbil-ascent/program/source-state#source-state::t))
  (declare-type
   gerbil-ascent/program/source-state#source-state-originals
   (@accessor gerbil-ascent/program/source-state#source-state::t originals #t))
  (declare-type
   gerbil-ascent/program/source-state#source-state-additions
   (@accessor gerbil-ascent/program/source-state#source-state::t additions #t))
  (declare-type
   gerbil-ascent/program/source-state#source-state-overrides
   (@accessor gerbil-ascent/program/source-state#source-state::t overrides #t))
  (declare-type
   gerbil-ascent/program/source-state#source-state-snapshot
   (@accessor gerbil-ascent/program/source-state#source-state::t snapshot #t))
  (declare-type
   gerbil-ascent/program/source-state#source-state-originals-set!
   (@mutator gerbil-ascent/program/source-state#source-state::t originals #t))
  (declare-type
   gerbil-ascent/program/source-state#source-state-additions-set!
   (@mutator gerbil-ascent/program/source-state#source-state::t additions #t))
  (declare-type
   gerbil-ascent/program/source-state#source-state-overrides-set!
   (@mutator gerbil-ascent/program/source-state#source-state::t overrides #t))
  (declare-type
   gerbil-ascent/program/source-state#source-state-snapshot-set!
   (@mutator gerbil-ascent/program/source-state#source-state::t snapshot #t))
  (declare-type
   gerbil-ascent/program/source-state#&source-state-originals
   (@accessor gerbil-ascent/program/source-state#source-state::t originals #f))
  (declare-type
   gerbil-ascent/program/source-state#&source-state-additions
   (@accessor gerbil-ascent/program/source-state#source-state::t additions #f))
  (declare-type
   gerbil-ascent/program/source-state#&source-state-overrides
   (@accessor gerbil-ascent/program/source-state#source-state::t overrides #f))
  (declare-type
   gerbil-ascent/program/source-state#&source-state-snapshot
   (@accessor gerbil-ascent/program/source-state#source-state::t snapshot #f))
  (declare-type
   gerbil-ascent/program/source-state#&source-state-originals-set!
   (@mutator gerbil-ascent/program/source-state#source-state::t originals #f))
  (declare-type
   gerbil-ascent/program/source-state#&source-state-additions-set!
   (@mutator gerbil-ascent/program/source-state#source-state::t additions #f))
  (declare-type
   gerbil-ascent/program/source-state#&source-state-overrides-set!
   (@mutator gerbil-ascent/program/source-state#source-state::t overrides #f))
  (declare-type
   gerbil-ascent/program/source-state#&source-state-snapshot-set!
   (@mutator gerbil-ascent/program/source-state#source-state::t snapshot #f))
  (declare-type
   gerbil-ascent/program/source-state#gerbil-ascent-source-state
   (@lambda 2
            #f
            signature:
            (return:
             gerbil-ascent/program/source-state#source-state::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/source-state)))
  (declare-type
   gerbil-ascent/program/source-state#__gerbil-ascent-source-state-rows
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/source-state)))
  (declare-type
   gerbil-ascent/program/source-state#gerbil-ascent-source-state-rows
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             (t::t t::t)
             unchecked:
             gerbil-ascent/program/source-state#__gerbil-ascent-source-state-rows
             origin:
             gerbil-ascent/program/source-state)))
  (declare-type
   gerbil-ascent/program/source-state#__gerbil-ascent-prepare-source-replacement
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/source-state)))
  (declare-type
   gerbil-ascent/program/source-state#gerbil-ascent-prepare-source-replacement
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             (t::t t::t t::t)
             unchecked:
             gerbil-ascent/program/source-state#__gerbil-ascent-prepare-source-replacement
             origin:
             gerbil-ascent/program/source-state)))
  (declare-type
   gerbil-ascent/program/source-state#__gerbil-ascent-commit-source-replacement!
   (@lambda 4
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/source-state)))
  (declare-type
   gerbil-ascent/program/source-state#gerbil-ascent-commit-source-replacement!
   (@lambda 4
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             (t::t t::t t::t t::t)
             unchecked:
             gerbil-ascent/program/source-state#__gerbil-ascent-commit-source-replacement!
             origin:
             gerbil-ascent/program/source-state))))
