(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(define |gerbil-ascent/program/aggregators[:0:]#with-single-column|
  (lambda (_%$stx9915%_)
    (let* ((_%$%g99199947%_
            (lambda (_%$%g99209943%_)
              (let ()
                (declare (not safe))
                (gx#raise-syntax-error
                 '#f
                 '"Bad syntax; invalid match target"
                 _%$%g99209943%_))))
           (_%$%g991810045%_
            (lambda (_%$%g99209951%_)
              (if (let () (declare (not safe)) (gx#stx-pair? _%$%g99209951%_))
                  (let ((_%$%e99249954%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%$%g99209951%_))))
                    (let ((_%$%hd99259958%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e99249954%_)))
                          (_%$%tl99269961%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e99249954%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl99269961%_))
                          (let ((_%$%e99279964%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl99269961%_))))
                            (let ((_%$%hd99289968%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e99279964%_)))
                                  (_%$%tl99299971%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e99279964%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%tl99299971%_))
                                  (let ((_%$%e99309974%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%tl99299971%_))))
                                    (let ((_%$%hd99319978%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e99309974%_)))
                                          (_%$%tl99329981%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e99309974%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair/null?
                                             _%$%tl99329981%_))
                                          (let ((_g34051_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-split-splice
                                                    _%$%tl99329981%_
                                                    '0))))
                                            (begin
                                              (let ((_g34052_
                                                     (let ()
                                                       (declare (not safe))
                                                       (if (##values? _g34051_)
                                                           (##values-length
                                                            _g34051_)
                                                           1))))
                                                (if (not (let ()
                                                           (declare (not safe))
                                                           (##fx= _g34052_ 2)))
                                                    (error "Context expects 2 values"
                                                           _g34052_)))
                                              (let ((_%$%target99339984%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##values-ref
                                                        _g34051_
                                                        0)))
                                                    (_%$%tl99359987%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##values-ref
                                                        _g34051_
                                                        1))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl99359987%_))
                                                    (letrec ((_%$%loop99369990%_
                                                              (lambda (_%$%hd99349994%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               _%$%body99409997%_)
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair? _%$%hd99349994%_))
                            (let ((_%$%e99379999%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-e _%$%hd99349994%_))))
                              (let ((_%$%lp-hd993810003%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e99379999%_)))
                                    (_%$%lp-tl993910006%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e99379999%_))))
                                (_%$%loop99369990%_
                                 _%$%lp-tl993910006%_
                                 (cons _%$%lp-hd993810003%_
                                       _%$%body99409997%_))))
                            (let ((_%$%body994110009%_
                                   (reverse _%$%body99409997%_)))
                              (cons (let ()
                                      (declare (not safe))
                                      (gx#datum->syntax__0 '#f 'let))
                                    (cons (cons _%$%hd99319978%_
                                                (cons _%$%hd99289968%_ '()))
                                          (cons (cons (let ()
                                                        (declare (not safe))
                                                        (gx#datum->syntax__0
                                                         '#f
                                                         'for-each))
                                                      (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'single-column-value))
                                                            (cons _%$%hd99319978%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (let ((__tmp34053
                                                       (lambda (_%$%g1003610039%_
                                                                _%$%g1003710042%_)
                                                         (cons _%$%g1003610039%_
                                                               _%$%g1003710042%_))))
                                                  (declare (not safe))
                                                  (foldr__0
                                                   __tmp34053
                                                   '()
                                                   _%$%body994110009%_))))))))))
              (_%$%loop99369990%_ _%$%target99339984%_ '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%g99199947%_
                                                     _%$%g99209951%_)))))
                                          (_%$%g99199947%_ _%$%g99209951%_))))
                                  (_%$%g99199947%_ _%$%g99209951%_))))
                          (_%$%g99199947%_ _%$%g99209951%_))))
                  (_%$%g99199947%_ _%$%g99209951%_)))))
      (_%$%g991810045%_ _%$stx9915%_))))
