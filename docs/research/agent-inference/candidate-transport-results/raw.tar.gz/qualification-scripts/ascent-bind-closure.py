import importlib.util,json,subprocess,time
from pathlib import Path
p=Path.cwd()/'tools/research/candidate-model.py';spec=importlib.util.spec_from_file_location('m',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base=m.RUNTIME.parent;out=base/'load-repair-build';cmd=json.loads((base/'reuse-closure-corrected.json').read_text())['command'];began=time.monotonic()
r=subprocess.run(cmd,env=m.environment(),cwd=m.ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
(out/'closure.log').write_bytes(r.stdout+r.stderr);m.save(out/'closure-receipt.json',{'command':cmd,'exit':r.returncode,'seconds':time.monotonic()-began});assert r.returncode==0
closure=json.loads(r.stdout);assert 'gerbil-ascent/candidate/proof-frame' in closure['modules'];m.save(m.RUNTIME/'closure.json',closure)
sources=json.loads((m.RUNTIME/'native-object-sources.json').read_text());linked={Path(n).name for n in sources}
for name in closure['modules']:
 stem=name.replace('/','__')+'.c'
 for static in [m.CANONICAL/'static',m.PREPARED/'static']:
  assert not (static/stem).exists() or stem in linked, 'unlinked '+name
capture=json.loads((m.RUNTIME/'source-capture.json').read_text());receipts={}
for name,sha in capture['sourceSha256'].items():
 if name=='gerbil.pkg':continue
 c=m.CANONICAL/'static'/('gerbil-ascent__'+name[:-3].replace('/','__')+'.c')
 receipts[name]={'sourceSha256':sha,'compiledC':str(c),'compiledCSha256':m.digest(c),'compiler':'std/make current Library capture; load-repair-build receipts','exit':0}
m.save(m.RUNTIME/'current-source-build.json',receipts)
print('CURRENT_CLOSURE_OK',len(closure['modules']),len(receipts),flush=True)
