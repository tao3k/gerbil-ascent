(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/types[1]#_g34723_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34725_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34727_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34729_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34730_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34731_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34732_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-relations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34734_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34735_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34736_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34737_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-relations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34739_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34740_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34741_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34742_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-relations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34744_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34745_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34746_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34747_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-relations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34749_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34751_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-diagnostic
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34753_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34755_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic-code
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34756_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic-path
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34757_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic-detail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34759_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic-code-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34760_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic-path-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34761_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic-detail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34763_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-diagnostic-code
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34764_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-diagnostic-path
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34765_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-diagnostic-detail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34767_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-diagnostic-code-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34768_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-diagnostic-path-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34769_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-diagnostic-detail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34771_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34773_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-candidate
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34775_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34777_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-relations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34778_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-facts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34779_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-rules
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34780_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34781_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-limits
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34783_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-relations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34784_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-facts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34785_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-rules-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34786_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34787_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-limits-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34789_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-relations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34790_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-facts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34791_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-rules
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34792_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34793_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-limits
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34795_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-relations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34796_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-facts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34797_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-rules-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34798_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34799_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-limits-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34801_|
    (##structure
     gx#syntax-quote::t
     'candidate-rejection::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34803_|
    (##structure
     gx#syntax-quote::t
     'make-candidate-rejection
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34805_|
    (##structure
     gx#syntax-quote::t
     'candidate-rejection?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34807_|
    (##structure
     gx#syntax-quote::t
     'candidate-rejection-diagnostic
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34809_|
    (##structure
     gx#syntax-quote::t
     'candidate-rejection-diagnostic-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34811_|
    (##structure
     gx#syntax-quote::t
     '&candidate-rejection-diagnostic
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g34813_|
    (##structure
     gx#syntax-quote::t
     '&candidate-rejection-diagnostic-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/types[:0:]#reasoning-snapshot|
      (let ((__obj34690
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34690
           'gerbil-ascent/candidate/types#reasoning-snapshot::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34690
           'reasoning-snapshot
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34690
           '(identity generation digest relations)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34690
           '(identity generation digest relations)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34690 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34690 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34690 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34690 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34690 '#f '13 '#f '#f))
        (let ((__tmp34722 |gerbil-ascent/candidate/types[1]#_g34723_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34690 __tmp34722 '4 '#f '#f))
        (let ((__tmp34724 |gerbil-ascent/candidate/types[1]#_g34725_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34690 __tmp34724 '14 '#f '#f))
        (let ((__tmp34726 |gerbil-ascent/candidate/types[1]#_g34727_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34690 __tmp34726 '15 '#f '#f))
        (let ((__tmp34728
               (cons (cons 'identity
                           |gerbil-ascent/candidate/types[1]#_g34729_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/candidate/types[1]#_g34730_|)
                           (cons (cons 'digest
                                       |gerbil-ascent/candidate/types[1]#_g34731_|)
                                 (cons (cons 'relations
                                             |gerbil-ascent/candidate/types[1]#_g34732_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34690 __tmp34728 '16 '#f '#f))
        (let ((__tmp34733
               (cons (cons 'identity
                           |gerbil-ascent/candidate/types[1]#_g34734_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/candidate/types[1]#_g34735_|)
                           (cons (cons 'digest
                                       |gerbil-ascent/candidate/types[1]#_g34736_|)
                                 (cons (cons 'relations
                                             |gerbil-ascent/candidate/types[1]#_g34737_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34690 __tmp34733 '17 '#f '#f))
        (let ((__tmp34738
               (cons (cons 'identity
                           |gerbil-ascent/candidate/types[1]#_g34739_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/candidate/types[1]#_g34740_|)
                           (cons (cons 'digest
                                       |gerbil-ascent/candidate/types[1]#_g34741_|)
                                 (cons (cons 'relations
                                             |gerbil-ascent/candidate/types[1]#_g34742_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34690 __tmp34738 '18 '#f '#f))
        (let ((__tmp34743
               (cons (cons 'identity
                           |gerbil-ascent/candidate/types[1]#_g34744_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/candidate/types[1]#_g34745_|)
                           (cons (cons 'digest
                                       |gerbil-ascent/candidate/types[1]#_g34746_|)
                                 (cons (cons 'relations
                                             |gerbil-ascent/candidate/types[1]#_g34747_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34690 __tmp34743 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34690 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34690 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34690 '() '21 '#f '#f))
        __obj34690))
    (define |gerbil-ascent/candidate/types[:0:]#reasoning-diagnostic|
      (let ((__obj34691
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34691
           'gerbil-ascent/candidate/types#reasoning-diagnostic::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34691
           'reasoning-diagnostic
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34691
           '(code path detail)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34691
           '(code path detail)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34691 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34691 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34691 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34691 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34691 '#f '13 '#f '#f))
        (let ((__tmp34748 |gerbil-ascent/candidate/types[1]#_g34749_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34691 __tmp34748 '4 '#f '#f))
        (let ((__tmp34750 |gerbil-ascent/candidate/types[1]#_g34751_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34691 __tmp34750 '14 '#f '#f))
        (let ((__tmp34752 |gerbil-ascent/candidate/types[1]#_g34753_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34691 __tmp34752 '15 '#f '#f))
        (let ((__tmp34754
               (cons (cons 'code |gerbil-ascent/candidate/types[1]#_g34755_|)
                     (cons (cons 'path
                                 |gerbil-ascent/candidate/types[1]#_g34756_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/candidate/types[1]#_g34757_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34691 __tmp34754 '16 '#f '#f))
        (let ((__tmp34758
               (cons (cons 'code |gerbil-ascent/candidate/types[1]#_g34759_|)
                     (cons (cons 'path
                                 |gerbil-ascent/candidate/types[1]#_g34760_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/candidate/types[1]#_g34761_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34691 __tmp34758 '17 '#f '#f))
        (let ((__tmp34762
               (cons (cons 'code |gerbil-ascent/candidate/types[1]#_g34763_|)
                     (cons (cons 'path
                                 |gerbil-ascent/candidate/types[1]#_g34764_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/candidate/types[1]#_g34765_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34691 __tmp34762 '18 '#f '#f))
        (let ((__tmp34766
               (cons (cons 'code |gerbil-ascent/candidate/types[1]#_g34767_|)
                     (cons (cons 'path
                                 |gerbil-ascent/candidate/types[1]#_g34768_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/candidate/types[1]#_g34769_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34691 __tmp34766 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34691 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34691 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34691 '() '21 '#f '#f))
        __obj34691))
    (define |gerbil-ascent/candidate/types[:0:]#reasoning-candidate|
      (let ((__obj34692
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34692
           'gerbil-ascent/candidate/types#reasoning-candidate::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34692
           'reasoning-candidate
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34692
           '(relations facts rules query limits)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34692
           '(relations facts rules query limits)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34692 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34692 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34692 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34692 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34692 '#f '13 '#f '#f))
        (let ((__tmp34770 |gerbil-ascent/candidate/types[1]#_g34771_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34692 __tmp34770 '4 '#f '#f))
        (let ((__tmp34772 |gerbil-ascent/candidate/types[1]#_g34773_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34692 __tmp34772 '14 '#f '#f))
        (let ((__tmp34774 |gerbil-ascent/candidate/types[1]#_g34775_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34692 __tmp34774 '15 '#f '#f))
        (let ((__tmp34776
               (cons (cons 'relations
                           |gerbil-ascent/candidate/types[1]#_g34777_|)
                     (cons (cons 'facts
                                 |gerbil-ascent/candidate/types[1]#_g34778_|)
                           (cons (cons 'rules
                                       |gerbil-ascent/candidate/types[1]#_g34779_|)
                                 (cons (cons 'query
                                             |gerbil-ascent/candidate/types[1]#_g34780_|)
                                       (cons (cons 'limits
                                                   |gerbil-ascent/candidate/types[1]#_g34781_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34692 __tmp34776 '16 '#f '#f))
        (let ((__tmp34782
               (cons (cons 'relations
                           |gerbil-ascent/candidate/types[1]#_g34783_|)
                     (cons (cons 'facts
                                 |gerbil-ascent/candidate/types[1]#_g34784_|)
                           (cons (cons 'rules
                                       |gerbil-ascent/candidate/types[1]#_g34785_|)
                                 (cons (cons 'query
                                             |gerbil-ascent/candidate/types[1]#_g34786_|)
                                       (cons (cons 'limits
                                                   |gerbil-ascent/candidate/types[1]#_g34787_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34692 __tmp34782 '17 '#f '#f))
        (let ((__tmp34788
               (cons (cons 'relations
                           |gerbil-ascent/candidate/types[1]#_g34789_|)
                     (cons (cons 'facts
                                 |gerbil-ascent/candidate/types[1]#_g34790_|)
                           (cons (cons 'rules
                                       |gerbil-ascent/candidate/types[1]#_g34791_|)
                                 (cons (cons 'query
                                             |gerbil-ascent/candidate/types[1]#_g34792_|)
                                       (cons (cons 'limits
                                                   |gerbil-ascent/candidate/types[1]#_g34793_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34692 __tmp34788 '18 '#f '#f))
        (let ((__tmp34794
               (cons (cons 'relations
                           |gerbil-ascent/candidate/types[1]#_g34795_|)
                     (cons (cons 'facts
                                 |gerbil-ascent/candidate/types[1]#_g34796_|)
                           (cons (cons 'rules
                                       |gerbil-ascent/candidate/types[1]#_g34797_|)
                                 (cons (cons 'query
                                             |gerbil-ascent/candidate/types[1]#_g34798_|)
                                       (cons (cons 'limits
                                                   |gerbil-ascent/candidate/types[1]#_g34799_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34692 __tmp34794 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34692 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34692 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34692 '() '21 '#f '#f))
        __obj34692))
    (define |gerbil-ascent/candidate/types[:0:]#candidate-rejection|
      (let ((__obj34693
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34693
           'gerbil-ascent/candidate/types#candidate-rejection::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34693
           'candidate-rejection
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34693 '(diagnostic) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34693 '(diagnostic) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34693 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34693 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34693 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34693 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34693 '#f '13 '#f '#f))
        (let ((__tmp34800 |gerbil-ascent/candidate/types[1]#_g34801_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34693 __tmp34800 '4 '#f '#f))
        (let ((__tmp34802 |gerbil-ascent/candidate/types[1]#_g34803_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34693 __tmp34802 '14 '#f '#f))
        (let ((__tmp34804 |gerbil-ascent/candidate/types[1]#_g34805_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34693 __tmp34804 '15 '#f '#f))
        (let ((__tmp34806
               (cons (cons 'diagnostic
                           |gerbil-ascent/candidate/types[1]#_g34807_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj34693 __tmp34806 '16 '#f '#f))
        (let ((__tmp34808
               (cons (cons 'diagnostic
                           |gerbil-ascent/candidate/types[1]#_g34809_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj34693 __tmp34808 '17 '#f '#f))
        (let ((__tmp34810
               (cons (cons 'diagnostic
                           |gerbil-ascent/candidate/types[1]#_g34811_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj34693 __tmp34810 '18 '#f '#f))
        (let ((__tmp34812
               (cons (cons 'diagnostic
                           |gerbil-ascent/candidate/types[1]#_g34813_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj34693 __tmp34812 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34693 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34693 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34693 '() '21 '#f '#f))
        __obj34693))))
