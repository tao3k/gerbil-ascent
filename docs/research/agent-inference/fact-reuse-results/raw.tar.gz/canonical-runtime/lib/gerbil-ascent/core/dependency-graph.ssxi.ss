prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/core

(begin
  (declare-class
   gerbil-ascent/core/dependency-graph#graph-frame::t
   (@class gerbil-ascent/core/dependency-graph#graph-frame::t
           ()
           (object::t t::t)
           (node remaining parent)
           (node remaining parent)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/core/dependency-graph#graph-frame::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/core/dependency-graph#graph-frame::t)
    'class::t))
  (declare-type
   gerbil-ascent/core/dependency-graph#graph-frame?
   (@predicate gerbil-ascent/core/dependency-graph#graph-frame::t))
  (declare-type
   gerbil-ascent/core/dependency-graph#make-graph-frame
   (@constructor gerbil-ascent/core/dependency-graph#graph-frame::t))
  (declare-type
   gerbil-ascent/core/dependency-graph#graph-frame-node
   (@accessor gerbil-ascent/core/dependency-graph#graph-frame::t node #t))
  (declare-type
   gerbil-ascent/core/dependency-graph#graph-frame-remaining
   (@accessor gerbil-ascent/core/dependency-graph#graph-frame::t remaining #t))
  (declare-type
   gerbil-ascent/core/dependency-graph#graph-frame-parent
   (@accessor gerbil-ascent/core/dependency-graph#graph-frame::t parent #t))
  (declare-type
   gerbil-ascent/core/dependency-graph#graph-frame-node-set!
   (@mutator gerbil-ascent/core/dependency-graph#graph-frame::t node #t))
  (declare-type
   gerbil-ascent/core/dependency-graph#graph-frame-remaining-set!
   (@mutator gerbil-ascent/core/dependency-graph#graph-frame::t remaining #t))
  (declare-type
   gerbil-ascent/core/dependency-graph#graph-frame-parent-set!
   (@mutator gerbil-ascent/core/dependency-graph#graph-frame::t parent #t))
  (declare-type
   gerbil-ascent/core/dependency-graph#&graph-frame-node
   (@accessor gerbil-ascent/core/dependency-graph#graph-frame::t node #f))
  (declare-type
   gerbil-ascent/core/dependency-graph#&graph-frame-remaining
   (@accessor gerbil-ascent/core/dependency-graph#graph-frame::t remaining #f))
  (declare-type
   gerbil-ascent/core/dependency-graph#&graph-frame-parent
   (@accessor gerbil-ascent/core/dependency-graph#graph-frame::t parent #f))
  (declare-type
   gerbil-ascent/core/dependency-graph#&graph-frame-node-set!
   (@mutator gerbil-ascent/core/dependency-graph#graph-frame::t node #f))
  (declare-type
   gerbil-ascent/core/dependency-graph#&graph-frame-remaining-set!
   (@mutator gerbil-ascent/core/dependency-graph#graph-frame::t remaining #f))
  (declare-type
   gerbil-ascent/core/dependency-graph#&graph-frame-parent-set!
   (@mutator gerbil-ascent/core/dependency-graph#graph-frame::t parent #f))
  (declare-type
   gerbil-ascent/core/dependency-graph#gerbil-ascent-graph-close!
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/dependency-graph)))
  (declare-type
   gerbil-ascent/core/dependency-graph#gerbil-ascent-graph-components
   (@lambda 1
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/dependency-graph))))
