prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/program

(begin
  (declare-class
   gerbil-ascent/program/result#owned-publication::t
   (@class gerbil-ascent/program/result#owned-publication::t
           ()
           (object::t t::t)
           (result snapshots sizes position-of)
           (result snapshots sizes position-of)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/program/result#owned-publication::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/result#owned-publication::t)
    'class::t))
  (declare-type
   gerbil-ascent/program/result#owned-publication?
   (@predicate gerbil-ascent/program/result#owned-publication::t))
  (declare-type
   gerbil-ascent/program/result#make-owned-publication
   (@constructor gerbil-ascent/program/result#owned-publication::t))
  (declare-type
   gerbil-ascent/program/result#owned-publication-result
   (@accessor gerbil-ascent/program/result#owned-publication::t result #t))
  (declare-type
   gerbil-ascent/program/result#owned-publication-snapshots
   (@accessor gerbil-ascent/program/result#owned-publication::t snapshots #t))
  (declare-type
   gerbil-ascent/program/result#owned-publication-sizes
   (@accessor gerbil-ascent/program/result#owned-publication::t sizes #t))
  (declare-type
   gerbil-ascent/program/result#owned-publication-position-of
   (@accessor
    gerbil-ascent/program/result#owned-publication::t
    position-of
    #t))
  (declare-type
   gerbil-ascent/program/result#owned-publication-result-set!
   (@mutator gerbil-ascent/program/result#owned-publication::t result #t))
  (declare-type
   gerbil-ascent/program/result#owned-publication-snapshots-set!
   (@mutator gerbil-ascent/program/result#owned-publication::t snapshots #t))
  (declare-type
   gerbil-ascent/program/result#owned-publication-sizes-set!
   (@mutator gerbil-ascent/program/result#owned-publication::t sizes #t))
  (declare-type
   gerbil-ascent/program/result#owned-publication-position-of-set!
   (@mutator gerbil-ascent/program/result#owned-publication::t position-of #t))
  (declare-type
   gerbil-ascent/program/result#&owned-publication-result
   (@accessor gerbil-ascent/program/result#owned-publication::t result #f))
  (declare-type
   gerbil-ascent/program/result#&owned-publication-snapshots
   (@accessor gerbil-ascent/program/result#owned-publication::t snapshots #f))
  (declare-type
   gerbil-ascent/program/result#&owned-publication-sizes
   (@accessor gerbil-ascent/program/result#owned-publication::t sizes #f))
  (declare-type
   gerbil-ascent/program/result#&owned-publication-position-of
   (@accessor
    gerbil-ascent/program/result#owned-publication::t
    position-of
    #f))
  (declare-type
   gerbil-ascent/program/result#&owned-publication-result-set!
   (@mutator gerbil-ascent/program/result#owned-publication::t result #f))
  (declare-type
   gerbil-ascent/program/result#&owned-publication-snapshots-set!
   (@mutator gerbil-ascent/program/result#owned-publication::t snapshots #f))
  (declare-type
   gerbil-ascent/program/result#&owned-publication-sizes-set!
   (@mutator gerbil-ascent/program/result#owned-publication::t sizes #f))
  (declare-type
   gerbil-ascent/program/result#&owned-publication-position-of-set!
   (@mutator gerbil-ascent/program/result#owned-publication::t position-of #f))
  (declare-type
   gerbil-ascent/program/result#gerbil-ascent-publication-size
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/result)))
  (declare-type
   gerbil-ascent/program/result#gerbil-ascent-publication-reader
   (@lambda 2
            #f
            signature:
            (return:
             (nullable procedure::t)
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/result)))
  (declare-type
   gerbil-ascent/program/result#gerbil-ascent-make-owned-result
   (@lambda 9
            #f
            signature:
            (return:
             values::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/result)))
  (declare-type
   gerbil-ascent/program/result#gerbil-ascent-publication-cache
   (@lambda 1
            #f
            signature:
            (return:
             vector::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/result)))
  (declare-type
   gerbil-ascent/program/result#gerbil-ascent-publish-rows__%
   (@lambda 3
            #f
            signature:
            (return:
             vector::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/result)))
  (declare-type
   gerbil-ascent/program/result#gerbil-ascent-publish-rows__0
   (@lambda 2
            #f
            signature:
            (return:
             vector::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/result)))
  (declare-type
   gerbil-ascent/program/result#gerbil-ascent-publish-rows
   (@case-lambda
    (2
     gerbil-ascent/program/result#gerbil-ascent-publish-rows__0
     signature:
     (return:
      vector::t
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/program/result))
    (3
     gerbil-ascent/program/result#gerbil-ascent-publish-rows__%
     signature:
     (return:
      vector::t
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/program/result))))
  (declare-type
   gerbil-ascent/program/result#publish-index!
   (@lambda 6
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/result)))
  (declare-type
   gerbil-ascent/program/result#gerbil-ascent-snapshot-rows
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/result)))
  (declare-type
   gerbil-ascent/program/result#gerbil-ascent-public-snapshot-rows
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/result)))
  (declare-type
   gerbil-ascent/program/result#gerbil-ascent-snapshot-sizes
   (@lambda 2
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/result)))
  (declare-type
   gerbil-ascent/program/result#gerbil-ascent-result-observation
   (@lambda 4
            #f
            signature:
            (return:
             vector::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/result)))
  (declare-type
   gerbil-ascent/program/result#gerbil-ascent-visit-snapshot!
   (@lambda 5
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/result)))
  (declare-type
   gerbil-ascent/program/result#gerbil-ascent-make-published-result
   (@lambda 9
            #f
            signature:
            (return:
             clan/poo/object#object::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/result))))
