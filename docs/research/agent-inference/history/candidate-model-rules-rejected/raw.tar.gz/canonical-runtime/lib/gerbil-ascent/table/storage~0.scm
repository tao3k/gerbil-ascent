(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/storage::timestamp 1791687878)
  (begin
    (define gerbil-ascent/table/storage#+make-state+
      (let ((__tmp35100 (lambda (_%_value3512%_ _%_context3513%_) '())))
        (declare (not safe))
        (core/types#poo-flow-predicate-contract
         'ascent/storage-make-state
         procedure?
         __tmp35100)))
    (define gerbil-ascent/table/storage#+extend+
      (let ((__tmp35101 (lambda (_%_value3509%_ _%_context3510%_) '())))
        (declare (not safe))
        (core/types#poo-flow-predicate-contract
         'ascent/storage-extend
         procedure?
         __tmp35101)))
    (define gerbil-ascent/table/storage#GerbilAscentStorageProviderContract
      (let ((__obj35094
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp35103
               (list (cons 'sexp
                           (let ((__tmp35104
                                  (lambda (_%@3455%_)
                                    'GerbilAscentStorageProviderContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35104)))
                     (cons 'identity
                           (let ((__tmp35105
                                  (lambda (_%@3461%_)
                                    'ascent/storage-provider)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35105)))
                     (cons 'proto
                           (let ((__tmp35106
                                  (lambda (_%@3466%_)
                                    (let ((__obj35092
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35108 (list))
                                            (__tmp35107 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35108
                                         __tmp35107
                                         __obj35092))
                                      __obj35092))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35106)))
                     (cons 'responsibilities
                           (let ((__tmp35109
                                  (lambda (_%@3480%_)
                                    (let ((__obj35093
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp35111
                                             (list (cons '.make-state
                                                         (let ((__tmp35112
                                                                (lambda (_%self3497%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/table/storage#+make-state+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35112)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.extend-rows
                                                         (let ((__tmp35113
                                                                (lambda (_%self3504%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/table/storage#+extend+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp35113)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35110 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp35111
                                         __tmp35110
                                         __obj35093))
                                      __obj35093))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp35109)))))
              (__tmp35102 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp35103
           __tmp35102
           __obj35094))
        __obj35094))
    (define gerbil-ascent/table/storage#StorageProvider.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/table/storage#GerbilAscentStorageProviderContract
         'proto)))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-make-state
      (lambda (_%provider3440%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%provider3440%_ '.make-state)))))
    (define gerbil-ascent/table/storage#gerbil-ascent-set-batch-admit!
      (lambda (_%source-log3408%_
               _%count3409%_
               _%seen3410%_
               _%share-source?3411%_)
        (letrec ((_%admit3413%_
                  (lambda (_%present3423%_)
                    (let ((_%source-order3431%_
                           (let _%collect3425%_ ((_%cursor3427%_
                                                  _%source-log3408%_)
                                                 (_%left3428%_ _%count3409%_)
                                                 (_%ordered3429%_ '()))
                             (if (= _%left3428%_ '0)
                                 _%ordered3429%_
                                 (_%collect3425%_
                                  (cdr _%cursor3427%_)
                                  (let ()
                                    (declare (not safe))
                                    (##fx- _%left3428%_ '1))
                                  (cons (car _%cursor3427%_)
                                        _%ordered3429%_))))))
                      (let _%deduplicate3433%_ ((_%remaining3435%_
                                                 _%source-order3431%_)
                                                (_%accepted3436%_ '()))
                        (if (null? _%remaining3435%_)
                            (values _%accepted3436%_ _%present3423%_)
                            (let ((_%row3438%_ (car _%remaining3435%_)))
                              (if (let ()
                                    (declare (not safe))
                                    (hash-get _%present3423%_ _%row3438%_))
                                  (_%deduplicate3433%_
                                   (cdr _%remaining3435%_)
                                   _%accepted3436%_)
                                  (begin
                                    (let ()
                                      (declare (not safe))
                                      (hash-put!
                                       _%present3423%_
                                       _%row3438%_
                                       '#t))
                                    (_%deduplicate3433%_
                                     (cdr _%remaining3435%_)
                                     (cons _%row3438%_
                                           _%accepted3436%_)))))))))))
          (if (and _%share-source?3411%_
                   (= (let () (declare (not safe)) (hash-length _%seen3410%_))
                      '0))
              (let ((_%present3415%_
                     (let ()
                       (declare (not safe))
                       (make-hash-table__%
                        '#f
                        _%count3409%_
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value))))
                (let _%scan3417%_ ((_%cursor3419%_ _%source-log3408%_)
                                   (_%left3420%_ _%count3409%_)
                                   (_%next-size3421%_ '1))
                  (if (= _%left3420%_ '0)
                      (if (null? _%cursor3419%_)
                          (values _%source-log3408%_ _%present3415%_)
                          (begin
                            (let ()
                              (declare (not safe))
                              (__hash-clear! _%present3415%_))
                            (_%admit3413%_ _%present3415%_)))
                      (begin
                        (let ((__tmp35114 (car _%cursor3419%_)))
                          (declare (not safe))
                          (__hash-put! _%present3415%_ __tmp35114 '#t))
                        (if (= (let ()
                                 (declare (not safe))
                                 (__hash-length _%present3415%_))
                               _%next-size3421%_)
                            (_%scan3417%_
                             (cdr _%cursor3419%_)
                             (let ()
                               (declare (not safe))
                               (##fx- _%left3420%_ '1))
                             (let ()
                               (declare (not safe))
                               (##fx+ _%next-size3421%_ '1)))
                            (begin
                              (let ()
                                (declare (not safe))
                                (__hash-clear! _%present3415%_))
                              (_%admit3413%_ _%present3415%_)))))))
              (_%admit3413%_ _%seen3410%_)))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-extend
      (lambda (_%provider3401%_
               _%state3402%_
               _%all3403%_
               _%pending3404%_
               _%row3405%_
               _%budget3406%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%provider3401%_ '.extend-rows))
         _%state3402%_
         _%all3403%_
         _%pending3404%_
         _%row3405%_
         _%budget3406%_)))
    (define gerbil-ascent/table/storage#+canonical-set-storage-provider+
      (let ((__tmp35115
             (let ((__obj35095
                    (let ()
                      (declare (not safe))
                      (##structure
                       clan/poo/object#object::t
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f))))
               (let ((__tmp35117
                      (list (cons '.make-state
                                  (let ((__tmp35118
                                         (lambda (_%@3383%_) (lambda () '#f))))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp35118)))
                            (cons '.extend-rows
                                  (let ((__tmp35119
                                         (lambda (_%@3390%_)
                                           (lambda (_%_state3395%_
                                                    _%_all3396%_
                                                    _%_pending3397%_
                                                    _%row3398%_
                                                    _%_budget3399%_)
                                             (list _%row3398%_)))))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp35119)))))
                     (__tmp35116 (list)))
                 (declare (not safe))
                 (clan/poo/object#object:::init!__%
                  '#f
                  gerbil-ascent/table/storage#StorageProvider.
                  __tmp35117
                  __tmp35116
                  __obj35095))
               __obj35095)))
        (declare (not safe))
        (clan/poo/mop#validate
         gerbil-ascent/table/storage#GerbilAscentStorageProviderContract
         __tmp35115)))
    (define gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider
      gerbil-ascent/table/storage#+canonical-set-storage-provider+)
    (define gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
      (lambda (_%value3370%_)
        (eq? _%value3370%_
             gerbil-ascent/table/storage#+canonical-set-storage-provider+)))
    (define gerbil-ascent/table/storage#gerbil-ascent-eqrel-storage-provider
      (let ((__tmp35120
             (let ((__obj35096
                    (let ()
                      (declare (not safe))
                      (##structure
                       clan/poo/object#object::t
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f))))
               (let ((__tmp35122
                      (list (cons '.make-state
                                  (let ((__tmp35123
                                         (lambda (_%@3359%_)
                                           gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-state)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp35123)))
                            (cons '.extend-rows
                                  (let ((__tmp35124
                                         (lambda (_%@3365%_)
                                           gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-extension)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp35124)))))
                     (__tmp35121 (list)))
                 (declare (not safe))
                 (clan/poo/object#object:::init!__%
                  '#f
                  gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider
                  __tmp35122
                  __tmp35121
                  __obj35096))
               __obj35096)))
        (declare (not safe))
        (clan/poo/mop#validate
         gerbil-ascent/table/storage#GerbilAscentStorageProviderContract
         __tmp35120)))
    (define gerbil-ascent/table/storage#gerbil-ascent-trrel-storage-provider
      (let ((__tmp35125
             (let ((__obj35097
                    (let ()
                      (declare (not safe))
                      (##structure
                       clan/poo/object#object::t
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f))))
               (let ((__tmp35127
                      (list (cons '.make-state
                                  (let ((__tmp35128
                                         (lambda (_%@3337%_)
                                           gerbil-ascent/table/trrel#gerbil-ascent-trrel-state)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp35128)))
                            (cons '.extend-rows
                                  (let ((__tmp35129
                                         (lambda (_%@3343%_)
                                           gerbil-ascent/table/trrel#gerbil-ascent-trrel-extension)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp35129)))))
                     (__tmp35126 (list)))
                 (declare (not safe))
                 (clan/poo/object#object:::init!__%
                  '#f
                  gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider
                  __tmp35127
                  __tmp35126
                  __obj35097))
               __obj35097)))
        (declare (not safe))
        (clan/poo/mop#validate
         gerbil-ascent/table/storage#GerbilAscentStorageProviderContract
         __tmp35125)))
    (define gerbil-ascent/table/storage#gerbil-ascent-trrel-uf-storage-provider
      (let ((__tmp35130
             (let ((__obj35098
                    (let ()
                      (declare (not safe))
                      (##structure
                       clan/poo/object#object::t
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f))))
               (let ((__tmp35132
                      (list (cons '.make-state
                                  (let ((__tmp35133
                                         (lambda (_%@3315%_)
                                           gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-state)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp35133)))
                            (cons '.extend-rows
                                  (let ((__tmp35134
                                         (lambda (_%@3321%_)
                                           gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-extension)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp35134)))))
                     (__tmp35131 (list)))
                 (declare (not safe))
                 (clan/poo/object#object:::init!__%
                  '#f
                  gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider
                  __tmp35132
                  __tmp35131
                  __obj35098))
               __obj35098)))
        (declare (not safe))
        (clan/poo/mop#validate
         gerbil-ascent/table/storage#GerbilAscentStorageProviderContract
         __tmp35130)))
    (define gerbil-ascent/table/storage#+native-storage-providers+
      (list gerbil-ascent/table/storage#+canonical-set-storage-provider+
            gerbil-ascent/table/storage#gerbil-ascent-eqrel-storage-provider
            gerbil-ascent/table/storage#gerbil-ascent-trrel-storage-provider
            gerbil-ascent/table/storage#gerbil-ascent-trrel-uf-storage-provider))
    (define gerbil-ascent/table/storage#storage-state-owner::t
      (let ((__tmp35136 (list)) (__tmp35135 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/storage#storage-state-owner::t
         'storage-state-owner
         __tmp35136
         '(value phase)
         __tmp35135
         '#f)))
    (define gerbil-ascent/table/storage#storage-state-owner?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/table/storage#storage-state-owner::t)))
    (define gerbil-ascent/table/storage#make-storage-state-owner
      (lambda _%$args3301%_
        (apply make-instance
               gerbil-ascent/table/storage#storage-state-owner::t
               _%$args3301%_)))
    (define gerbil-ascent/table/storage#storage-state-owner-value
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/storage#storage-state-owner::t
         'value)))
    (define gerbil-ascent/table/storage#storage-state-owner-phase
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/storage#storage-state-owner::t
         'phase)))
    (define gerbil-ascent/table/storage#storage-state-owner-value-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/storage#storage-state-owner::t
         'value)))
    (define gerbil-ascent/table/storage#storage-state-owner-phase-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/storage#storage-state-owner::t
         'phase)))
    (define gerbil-ascent/table/storage#&storage-state-owner-value
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/storage#storage-state-owner::t
         'value)))
    (define gerbil-ascent/table/storage#&storage-state-owner-phase
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/storage#storage-state-owner::t
         'phase)))
    (define gerbil-ascent/table/storage#&storage-state-owner-value-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/storage#storage-state-owner::t
         'value)))
    (define gerbil-ascent/table/storage#&storage-state-owner-phase-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/storage#storage-state-owner::t
         'phase)))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-engine-state
      (lambda (_%provider3297%_)
        (let ((_%state3299%_
               (gerbil-ascent/table/storage#gerbil-ascent-storage-make-state
                _%provider3297%_)))
          (if (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
               _%provider3297%_)
              _%state3299%_
              (let ()
                (declare (not safe))
                (##structure
                 gerbil-ascent/table/storage#storage-state-owner::t
                 _%state3299%_
                 'ready))))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-owned-states
      (lambda (_%states3295%_)
        (let ((__tmp35137 (vector->list _%states3295%_)))
          (declare (not safe))
          (##filter
           gerbil-ascent/table/storage#storage-state-owner?
           __tmp35137))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-check-state!
      (lambda (_%state3293%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-instance-of?
                    _%state3293%_
                    'gerbil-ascent/table/storage#storage-state-owner::t))
                 (not (eq? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%state3293%_
                              '2
                              '#f
                              '#f))
                           'ready)))
            (let ()
              (declare (not safe))
              (error '"ASCENT storage state requires source replay"))
            '#!void)))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-admit-state!
      (lambda (_%state3291%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%state3291%_
               'gerbil-ascent/table/storage#storage-state-owner::t))
            (let ()
              (declare (not safe))
              (##unchecked-structure-set! _%state3291%_ 'ready '2 '#f '#f))
            '#!void)))
    (define gerbil-ascent/table/storage#owned-storage-rows
      (lambda (_%rows3287%_)
        (map (lambda (_%row3289%_) (map values _%row3289%_)) _%rows3287%_)))
    (define gerbil-ascent/table/storage#call-with-storage-state
      (lambda (_%state3281%_ _%invoke3282%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%state3281%_
               'gerbil-ascent/table/storage#storage-state-owner::t))
            (begin
              (if (eq? (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref _%state3281%_ '2 '#f '#f))
                       'failed)
                  (let ()
                    (declare (not safe))
                    (error '"ASCENT storage state requires source replay"))
                  '#!void)
              (let ()
                (declare (not safe))
                (##unchecked-structure-set!
                 _%state3281%_
                 'pending
                 '2
                 '#f
                 '#f)))
            '#!void)
        (let ((__tmp35139
               (lambda (_%failure3284%_)
                 (if (let ()
                       (declare (not safe))
                       (##structure-instance-of?
                        _%state3281%_
                        'gerbil-ascent/table/storage#storage-state-owner::t))
                     (let ()
                       (declare (not safe))
                       (##unchecked-structure-set!
                        _%state3281%_
                        'failed
                        '2
                        '#f
                        '#f))
                     '#!void)
                 (let () (declare (not safe)) (raise _%failure3284%_))))
              (__tmp35138
               (lambda ()
                 (_%invoke3282%_
                  (if (let ()
                        (declare (not safe))
                        (##structure-instance-of?
                         _%state3281%_
                         'gerbil-ascent/table/storage#storage-state-owner::t))
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref _%state3281%_ '1 '#f '#f))
                      _%state3281%_)))))
          (declare (not safe))
          (__with-catch __tmp35139 __tmp35138))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-extension
      (lambda (_%provider3254%_ _%width3255%_)
        (let ((_%extend3257%_
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%provider3254%_ '.extend-rows))))
          (if (let ()
                (declare (not safe))
                (##memq _%provider3254%_
                        gerbil-ascent/table/storage#+native-storage-providers+))
              _%extend3257%_
              (lambda (_%state3259%_
                       _%all3260%_
                       _%pending3261%_
                       _%row3262%_
                       _%budget3263%_)
                (gerbil-ascent/table/storage#call-with-storage-state
                 _%state3259%_
                 (lambda (_%raw-state3265%_)
                   (let* ((_%owned-all3267%_
                           (gerbil-ascent/table/storage#owned-storage-rows
                            _%all3260%_))
                          (_%owned-pending3269%_
                           (if (eq? _%all3260%_ _%pending3261%_)
                               _%owned-all3267%_
                               (gerbil-ascent/table/storage#owned-storage-rows
                                _%pending3261%_)))
                          (_%expanded3271%_
                           (_%extend3257%_
                            _%raw-state3265%_
                            _%owned-all3267%_
                            _%owned-pending3269%_
                            (map values _%row3262%_)
                            _%budget3263%_)))
                     (if (list? _%expanded3271%_)
                         '#!void
                         (let ()
                           (declare (not safe))
                           (error '"ASCENT storage provider returned non-list rows")))
                     (for-each
                      (lambda (_%stored3274%_)
                        (let _%loop3276%_ ((_%remaining3278%_ _%stored3274%_)
                                           (_%left3279%_ _%width3255%_))
                          (if (= _%left3279%_ '0)
                              (if (null? _%remaining3278%_)
                                  '#!void
                                  (let ()
                                    (declare (not safe))
                                    (error '"invalid ASCENT storage provider row")))
                              (if (pair? _%remaining3278%_)
                                  (_%loop3276%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%remaining3278%_))
                                   (- _%left3279%_ '1))
                                  (let ()
                                    (declare (not safe))
                                    (error '"invalid ASCENT storage provider row"))))))
                      _%expanded3271%_)
                     (gerbil-ascent/table/storage#owned-storage-rows
                      _%expanded3271%_)))))))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-engine-extension
      (lambda (_%provider3241%_ _%width3242%_)
        (if (and (let ()
                   (declare (not safe))
                   (##memq _%provider3241%_
                           gerbil-ascent/table/storage#+native-storage-providers+))
                 (not (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                       _%provider3241%_)))
            (let ((_%extend3244%_
                   (let ()
                     (declare (not safe))
                     (clan/poo/object#.ref _%provider3241%_ '.extend-rows))))
              (lambda (_%state3246%_
                       _%all3247%_
                       _%pending3248%_
                       _%row3249%_
                       _%budget3250%_)
                (gerbil-ascent/table/storage#call-with-storage-state
                 _%state3246%_
                 (lambda (_%raw-state3252%_)
                   (_%extend3244%_
                    _%raw-state3252%_
                    _%all3247%_
                    _%pending3248%_
                    _%row3249%_
                    _%budget3250%_)))))
            (gerbil-ascent/table/storage#gerbil-ascent-storage-extension
             _%provider3241%_
             _%width3242%_))))
    (define gerbil-ascent/table/storage#gerbil-ascent-canonical-view-storage-provider?
      (lambda (_%provider3236%_)
        (let ((_%$e3238%_
               (eq? _%provider3236%_
                    gerbil-ascent/table/storage#+canonical-eqrel-storage-provider+)))
          (if _%$e3238%_
              _%$e3238%_
              (gerbil-ascent/table/storage#gerbil-ascent-canonical-uf-storage-provider?
               _%provider3236%_)))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-eqrel-state?
      (lambda (_%state3234%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%state3234%_
               'gerbil-ascent/table/storage#storage-state-owner::t))
            (let ((__tmp35140
                   (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref _%state3234%_ '1 '#f '#f))))
              (declare (not safe))
              (##structure-instance-of?
               __tmp35140
               'gerbil-ascent/table/eqrel#eqrel-state::t))
            '#f)))
    (define gerbil-ascent/table/storage#+canonical-eqrel-storage-provider+
      gerbil-ascent/table/storage#gerbil-ascent-eqrel-storage-provider)
    (define gerbil-ascent/table/storage#+canonical-uf-storage-provider+
      gerbil-ascent/table/storage#gerbil-ascent-trrel-uf-storage-provider)
    (define gerbil-ascent/table/storage#gerbil-ascent-canonical-uf-storage-provider?
      (lambda (_%provider3232%_)
        (eq? _%provider3232%_
             gerbil-ascent/table/storage#+canonical-uf-storage-provider+)))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-view-extension!
      (lambda (_%state3226%_ _%row3227%_ _%budget3228%_)
        (gerbil-ascent/table/storage#call-with-storage-state
         _%state3226%_
         (lambda (_%raw3230%_)
           (if (let ()
                 (declare (not safe))
                 (##structure-instance-of?
                  _%raw3230%_
                  'gerbil-ascent/table/eqrel#eqrel-state::t))
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-insert!
                  _%raw3230%_
                  _%row3227%_
                  _%budget3228%_))
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-insert!
                  _%raw3230%_
                  _%row3227%_
                  _%budget3228%_)))))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__%
      (lambda (_%state3211%_ _%indexed?3212%_)
        (if (eq? (##structure-ref
                  _%state3211%_
                  '2
                  gerbil-ascent/table/storage#storage-state-owner::t
                  '#f)
                 'failed)
            (let ()
              (declare (not safe))
              (error '"ASCENT storage state requires source replay"))
            '#!void)
        (let ((_%raw3214%_
               (##structure-ref
                _%state3211%_
                '1
                gerbil-ascent/table/storage#storage-state-owner::t
                '#f)))
          (if (let ()
                (declare (not safe))
                (##structure-instance-of?
                 _%raw3214%_
                 'gerbil-ascent/table/eqrel#eqrel-state::t))
              (let ()
                (declare (not safe))
                (gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze__%
                 _%raw3214%_
                 _%indexed?3212%_))
              (let ()
                (declare (not safe))
                (gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__%
                 _%raw3214%_
                 _%indexed?3212%_))))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__0
      (lambda (_%state3219%_)
        (let ((_%indexed?3221%_ '#t))
          (gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__%
           _%state3219%_
           _%indexed?3221%_))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view
      (lambda _g35141_
        (let ((_g35142_ (let () (declare (not safe)) (##length _g35141_))))
          (cond ((let () (declare (not safe)) (##fx= _g35142_ 1))
                 (apply gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__0
                        _g35141_))
                ((let () (declare (not safe)) (##fx= _g35142_ 2))
                 (apply gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__%
                        _g35141_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view
                  _g35141_))))))
    (define gerbil-ascent/table/storage#gerbil-ascent-storage-publish-view!
      (lambda (_%state3205%_ _%frontier3206%_ _%count3207%_ _%indexed?3208%_)
        (if (eq? (##structure-ref
                  _%state3205%_
                  '2
                  gerbil-ascent/table/storage#storage-state-owner::t
                  '#f)
                 'failed)
            (let ()
              (declare (not safe))
              (error '"ASCENT storage state requires source replay"))
            '#!void)
        (if (gerbil-ascent/table/storage#gerbil-ascent-storage-eqrel-state?
             _%state3205%_)
            (let ((__tmp35143
                   (##structure-ref
                    _%state3205%_
                    '1
                    gerbil-ascent/table/storage#storage-state-owner::t
                    '#f)))
              (declare (not safe))
              (gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!__%
               __tmp35143
               _%count3207%_
               _%indexed?3208%_))
            (begin
              (if (= _%count3207%_
                     (let ()
                       (declare (not safe))
                       (gerbil-ascent/core/relation-view#gerbil-ascent-row-count
                        _%frontier3206%_)))
                  '#!void
                  (let ()
                    (declare (not safe))
                    (error '"ASCENT UF frontier count mismatch")))
              (values (gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__%
                       _%state3205%_
                       _%indexed?3208%_)
                      _%frontier3206%_)))))))
