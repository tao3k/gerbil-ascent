(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/objects::timestamp 1791689694)
  (begin
    (define gerbil-ascent/program/objects#current-declaration-check
      (make-parameter clan/poo/mop#validate))
    (define gerbil-ascent/program/objects#declaration-check
      (lambda (_%contract11282%_ _%value11283%_)
        ((let ()
           (declare (not safe))
           (gerbil-ascent/program/objects#current-declaration-check))
         _%contract11282%_
         _%value11283%_)))
    (define gerbil-ascent/program/objects#receive-inert-declarations
      (lambda (_%construct11274%_ _%receive11275%_)
        (call-with-values
         (lambda ()
           (let ((__tmp35901 (lambda () (_%construct11274%_)))
                 (__tmp35900
                  (lambda (_%_contract11279%_ _%value11280%_) _%value11280%_)))
             (declare (not safe))
             (call-with-parameters__1
              __tmp35901
              gerbil-ascent/program/objects#current-declaration-check
              __tmp35900)))
         _%receive11275%_)))
    (define gerbil-ascent/program/objects#validate-inert-root
      (lambda (_%contract11271%_ _%value11272%_)
        (let ((__tmp35902
               (if (null? (let ()
                            (declare (not safe))
                            (clan/poo/object#.ref _%value11272%_ 'rules)))
                   _%contract11271%_
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/program/types#gerbil-ascent-owned-root-contract
                      _%contract11271%_)))))
          (declare (not safe))
          (clan/poo/mop#validate __tmp35902 _%value11272%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-construct-inert-program
      (lambda (_%construct11262%_)
        (gerbil-ascent/program/objects#receive-inert-declarations
         _%construct11262%_
         (lambda _g35903_
           (let ((_g35904_ (let () (declare (not safe)) (##length _g35903_))))
             (cond ((let () (declare (not safe)) (##fx= _g35904_ 1))
                    (apply (lambda (_%program11264%_)
                             (gerbil-ascent/program/objects#validate-inert-root
                              gerbil-ascent/program/types#GerbilAscentProgramContract
                              _%program11264%_))
                           _g35903_))
                   ((let () (declare (not safe)) (##fx= _g35904_ 2))
                    (apply (lambda (_%program11266%_ _%output11267%_)
                             (let ((_%checked11269%_
                                    (gerbil-ascent/program/objects#validate-inert-root
                                     gerbil-ascent/program/types#GerbilAscentProgramContract
                                     _%program11266%_)))
                               (values _%checked11269%_ _%output11267%_)))
                           _g35903_))
                   (else
                    (##raise-wrong-number-of-arguments-exception
                     'case-lambda-dispatch
                     _g35903_))))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-construct-inert-fragment
      (lambda (_%construct11258%_)
        (gerbil-ascent/program/objects#receive-inert-declarations
         _%construct11258%_
         (lambda (_%fragment11260%_)
           (gerbil-ascent/program/objects#validate-inert-root
            gerbil-ascent/program/types#GerbilAscentFragmentContract
            _%fragment11260%_)))))
    (define gerbil-ascent/program/objects#Relation.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentRelationContract
         'proto)))
    (define gerbil-ascent/program/objects#Lattice.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentLatticeContract
         'proto)))
    (define gerbil-ascent/program/objects#Term.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentTermContract
         'proto)))
    (define gerbil-ascent/program/objects#Atom.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentAtomContract
         'proto)))
    (define gerbil-ascent/program/objects#Guard.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentGuardContract
         'proto)))
    (define gerbil-ascent/program/objects#Generator.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentGeneratorContract
         'proto)))
    (define gerbil-ascent/program/objects#Binding.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentBindingContract
         'proto)))
    (define gerbil-ascent/program/objects#Negation.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentNegationContract
         'proto)))
    (define gerbil-ascent/program/objects#Aggregate.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentAggregateContract
         'proto)))
    (define gerbil-ascent/program/objects#Rule.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentRuleContract
         'proto)))
    (define gerbil-ascent/program/objects#Fragment.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentFragmentContract
         'proto)))
    (define gerbil-ascent/program/objects#Program.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentProgramContract
         'proto)))
    (define gerbil-ascent/program/objects#gerbil-ascent-clause-plan
      (lambda (_%clause11254%_ _%atom-plan11255%_ _%bound11256%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%clause11254%_ '.plan))
         _%atom-plan11255%_
         _%bound11256%_)))
    (define gerbil-ascent/program/objects#name-index
      (lambda (_%names11246%_)
        (let ((_%index11248%_
               (let () (declare (not safe)) (make-hash-table-eq))))
          (for-each
           (lambda (_%$%g1124911251%_)
             (let ()
               (declare (not safe))
               (__hash-put! _%index11248%_ _%$%g1124911251%_ '#t)))
           _%names11246%_)
          _%index11248%_)))
    (define gerbil-ascent/program/objects#wide-scope?
      (lambda (_%names11236%_)
        (letrec ((_%enough?11238%_
                  (lambda (_%remaining11240%_ _%left11241%_)
                    (if (pair? _%remaining11240%_)
                        (let ((_%$e11243%_
                               (let ()
                                 (declare (not safe))
                                 (##fx= _%left11241%_ '1))))
                          (if _%$e11243%_
                              _%$e11243%_
                              (_%enough?11238%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%remaining11240%_))
                               (let ()
                                 (declare (not safe))
                                 (##fx- _%left11241%_ '1)))))
                        '#f))))
          (_%enough?11238%_ _%names11236%_ '32))))
    (define gerbil-ascent/program/objects#gerbil-ascent-bound-membership
      (lambda (_%names11227%_)
        (if (gerbil-ascent/program/objects#wide-scope? _%names11227%_)
            (let ((_%index11231%_ '#f) (_%reads11232%_ '0))
              (lambda (_%name11234%_)
                (if _%index11231%_
                    (let ()
                      (declare (not safe))
                      (hash-get _%index11231%_ _%name11234%_))
                    (begin
                      (set! _%reads11232%_
                            (let ()
                              (declare (not safe))
                              (##fx+ _%reads11232%_ '1)))
                      (if (let ()
                            (declare (not safe))
                            (##fx= _%reads11232%_ '32))
                          (begin
                            (set! _%index11231%_
                                  (gerbil-ascent/program/objects#name-index
                                   _%names11227%_))
                            (let ()
                              (declare (not safe))
                              (hash-get _%index11231%_ _%name11234%_)))
                          (if (memq _%name11234%_ _%names11227%_) '#t '#f))))))
            (lambda (_%name11229%_)
              (if (memq _%name11229%_ _%names11227%_) '#t '#f)))))
    (define gerbil-ascent/program/objects#require-bound
      (lambda (_%names11222%_ _%bound?11223%_)
        (for-each
         (lambda (_%name11225%_)
           (if (_%bound?11223%_ _%name11225%_)
               '#!void
               (let ()
                 (declare (not safe))
                 (error '"unbound ASCENT clause variable" _%name11225%_))))
         _%names11222%_)))
    (define gerbil-ascent/program/objects#pattern-outputs
      (lambda (_%term11220%_)
        (if (eq? (car _%term11220%_) 'pattern)
            (vector-ref (cdr _%term11220%_) '0)
            '#f)))
    (define gerbil-ascent/program/objects#indexed-atom
      (lambda (_%plan11173%_ _%bound11174%_)
        (let* ((_%wide?11176%_
                (gerbil-ascent/program/objects#wide-scope?
                 (vector-ref _%plan11173%_ '1)))
               (_%prior?11178%_
                (gerbil-ascent/program/objects#gerbil-ascent-bound-membership
                 _%bound11174%_))
               (_%seen-bound11180%_
                (if _%wide?11176%_
                    (gerbil-ascent/program/objects#name-index _%bound11174%_)
                    _%bound11174%_)))
          (letrec ((_%seen?11183%_
                    (lambda (_%name11218%_)
                      (if _%wide?11176%_
                          (let ()
                            (declare (not safe))
                            (hash-get _%seen-bound11180%_ _%name11218%_))
                          (memq _%name11218%_ _%seen-bound11180%_)))))
            (let _%loop11185%_ ((_%terms11187%_ (vector-ref _%plan11173%_ '1))
                                (_%column11188%_ '0)
                                (_%columns11189%_ '())
                                (_%bindings11190%_ '())
                                (_%key-terms11191%_ '()))
              (if (null? _%terms11187%_)
                  (vector (vector-ref _%plan11173%_ '0)
                          (vector-ref _%plan11173%_ '1)
                          (reverse _%columns11189%_)
                          (reverse _%bindings11190%_)
                          (reverse _%key-terms11191%_))
                  (let* ((_%term11193%_ (car _%terms11187%_))
                         (_%kind11195%_ (car _%term11193%_))
                         (_%inputs11197%_
                          (if (eq? _%kind11195%_ 'expression)
                              (vector-ref (cdr _%term11193%_) '0)
                              '#f)))
                    (if _%inputs11197%_
                        (gerbil-ascent/program/objects#require-bound
                         _%inputs11197%_
                         _%seen?11183%_)
                        '#!void)
                    (let* ((_%indexed?11206%_
                            (let ((_%$e11200%_ (eq? _%kind11195%_ 'literal)))
                              (if _%$e11200%_
                                  _%$e11200%_
                                  (let ((_%$e11203%_
                                         (if (eq? _%kind11195%_ 'variable)
                                             (let ((__tmp35905
                                                    (cdr _%term11193%_)))
                                               (declare (not safe))
                                               (_%prior?11178%_ __tmp35905))
                                             '#f)))
                                    (if _%$e11203%_
                                        _%$e11203%_
                                        (if _%inputs11197%_
                                            (let ()
                                              (declare (not safe))
                                              (andmap__0
                                               _%prior?11178%_
                                               _%inputs11197%_))
                                            '#f))))))
                           (_%binding11208%_
                            (if (and (eq? _%kind11195%_ 'variable)
                                     (not (_%seen?11183%_
                                           (cdr _%term11193%_))))
                                (cons 'fresh-variable (cdr _%term11193%_))
                                _%term11193%_)))
                      (let ((_%$e11211%_ _%kind11195%_))
                        (if (eq? 'variable _%$e11211%_)
                            (if _%wide?11176%_
                                (let ((__tmp35906 (cdr _%term11193%_)))
                                  (declare (not safe))
                                  (hash-put!
                                   _%seen-bound11180%_
                                   __tmp35906
                                   '#t))
                                (set! _%seen-bound11180%_
                                      (cons (cdr _%term11193%_)
                                            _%seen-bound11180%_)))
                            (if (eq? 'pattern _%$e11211%_)
                                (if _%wide?11176%_
                                    (for-each
                                     (lambda (_%$%g1121311215%_)
                                       (let ()
                                         (declare (not safe))
                                         (hash-put!
                                          _%seen-bound11180%_
                                          _%$%g1121311215%_
                                          '#t)))
                                     (gerbil-ascent/program/objects#pattern-outputs
                                      _%term11193%_))
                                    (set! _%seen-bound11180%_
                                          (append (gerbil-ascent/program/objects#pattern-outputs
                                                   _%term11193%_)
                                                  _%seen-bound11180%_)))
                                '#!void)))
                      (_%loop11185%_
                       (cdr _%terms11187%_)
                       (+ _%column11188%_ '1)
                       (if _%indexed?11206%_
                           (cons _%column11188%_ _%columns11189%_)
                           _%columns11189%_)
                       (cons _%binding11208%_ _%bindings11190%_)
                       (if _%indexed?11206%_
                           (cons _%term11193%_ _%key-terms11191%_)
                           _%key-terms11191%_))))))))))
    (define gerbil-ascent/program/objects#atom-clause-plan
      (lambda (_%clause11153%_ _%atom-plan11154%_ _%bound11155%_)
        (let* ((_%plan11157%_
                (gerbil-ascent/program/objects#indexed-atom
                 (_%atom-plan11154%_ _%clause11153%_)
                 _%bound11155%_))
               (_%next-bound11170%_
                (let ((__tmp35908
                       (lambda (_%term11159%_ _%prior11160%_)
                         (if (eq? (car _%term11159%_) 'variable)
                             (cons (cdr _%term11159%_) _%prior11160%_)
                             (if (eq? (car _%term11159%_) 'pattern)
                                 (let _%loop11164%_ ((_%outputs11166%_
                                                      (gerbil-ascent/program/objects#pattern-outputs
                                                       _%term11159%_))
                                                     (_%next11167%_
                                                      _%prior11160%_))
                                   (if (null? _%outputs11166%_)
                                       _%next11167%_
                                       (begin
                                         (if (memq (car _%outputs11166%_)
                                                   _%next11167%_)
                                             (let ((__tmp35909
                                                    (car _%outputs11166%_)))
                                               (declare (not safe))
                                               (error '"ASCENT pattern variable already bound"
                                                      __tmp35909))
                                             '#!void)
                                         (_%loop11164%_
                                          (cdr _%outputs11166%_)
                                          (cons (car _%outputs11166%_)
                                                _%next11167%_)))))
                                 _%prior11160%_))))
                      (__tmp35907 (vector-ref _%plan11157%_ '1)))
                  (declare (not safe))
                  (foldl__0 __tmp35908 _%bound11155%_ __tmp35907))))
          (vector (vector 'atom _%plan11157%_) _%next-bound11170%_ '1))))
    (define gerbil-ascent/program/objects#negation-clause-plan
      (lambda (_%clause11144%_ _%atom-plan11145%_ _%bound11146%_)
        (let ((_%plan11148%_
               (gerbil-ascent/program/objects#indexed-atom
                (_%atom-plan11145%_ _%clause11144%_)
                _%bound11146%_))
              (_%bound?11149%_
               (gerbil-ascent/program/objects#gerbil-ascent-bound-membership
                _%bound11146%_)))
          (for-each
           (lambda (_%term11151%_)
             (if (eq? (car _%term11151%_) 'pattern)
                 (let ()
                   (declare (not safe))
                   (error '"ASCENT pattern cannot bind in negation"))
                 '#!void)
             (if (and (eq? (car _%term11151%_) 'variable)
                      (not (let ((__tmp35910 (cdr _%term11151%_)))
                             (declare (not safe))
                             (_%bound?11149%_ __tmp35910))))
                 (let ((__tmp35911 (cdr _%term11151%_)))
                   (declare (not safe))
                   (error '"unsafe ASCENT negation variable" __tmp35911))
                 '#!void))
           (vector-ref _%plan11148%_ '1))
          (vector (vector 'negation _%plan11148%_) _%bound11146%_ '0))))
    (define gerbil-ascent/program/objects#computed-clause-plan
      (lambda (_%clause11123%_
               _%kind11124%_
               _%function-slot11125%_
               _%bound11126%_)
        (let* ((_%inputs11128%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%clause11123%_ 'variables)))
               (_%name11130%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%clause11123%_ 'variable)))
               (_%names11132%_
                (if (and (eq? _%kind11124%_ 'generator) (list? _%name11130%_))
                    _%name11130%_
                    (list _%name11130%_))))
          (gerbil-ascent/program/objects#require-bound
           _%inputs11128%_
           (gerbil-ascent/program/objects#gerbil-ascent-bound-membership
            _%bound11126%_))
          (let ((_%known11135%_
                 (if (gerbil-ascent/program/objects#wide-scope? _%names11132%_)
                     (gerbil-ascent/program/objects#name-index _%bound11126%_)
                     '#f)))
            (let _%loop11137%_ ((_%remaining11139%_ _%names11132%_)
                                (_%next-bound11140%_ _%bound11126%_))
              (if (null? _%remaining11139%_)
                  (vector (vector _%kind11124%_
                                  (if (list? _%name11130%_)
                                      (let ((__tmp35912
                                             (lambda (_%output11142%_)
                                               (cons 'variable
                                                     _%output11142%_))))
                                        (declare (not safe))
                                        (##map __tmp35912 _%name11130%_))
                                      _%name11130%_)
                                  _%inputs11128%_
                                  (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref
                                     _%clause11123%_
                                     _%function-slot11125%_)))
                          _%next-bound11140%_
                          '0)
                  (begin
                    (if (if _%known11135%_
                            (let ((__tmp35913 (car _%remaining11139%_)))
                              (declare (not safe))
                              (__hash-get _%known11135%_ __tmp35913))
                            (memq (car _%remaining11139%_)
                                  _%next-bound11140%_))
                        (let ((__tmp35914 (car _%remaining11139%_)))
                          (declare (not safe))
                          (error '"ASCENT computed variable already bound"
                                 __tmp35914))
                        '#!void)
                    (if _%known11135%_
                        (let ((__tmp35915 (car _%remaining11139%_)))
                          (declare (not safe))
                          (__hash-put! _%known11135%_ __tmp35915 '#t))
                        '#!void)
                    (_%loop11137%_
                     (cdr _%remaining11139%_)
                     (cons (car _%remaining11139%_)
                           _%next-bound11140%_)))))))))
    (define gerbil-ascent/program/objects#aggregate-clause-plan
      (lambda (_%clause11093%_ _%atom-plan11094%_ _%bound11095%_)
        (let* ((_%plan11097%_
                (gerbil-ascent/program/objects#indexed-atom
                 (_%atom-plan11094%_ _%clause11093%_)
                 _%bound11095%_))
               (_%name11099%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%clause11093%_ 'variable)))
               (_%names11101%_
                (if (list? _%name11099%_) _%name11099%_ (list _%name11099%_)))
               (_%inputs11103%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%clause11093%_ 'variables)))
               (_%terms11105%_ (vector-ref _%plan11097%_ '1)))
          (if (let ()
                (declare (not safe))
                (ormap__0
                 gerbil-ascent/program/objects#pattern-outputs
                 _%terms11105%_))
              (let ()
                (declare (not safe))
                (error '"ASCENT pattern cannot bind in aggregate"))
              '#!void)
          (let ((_%known11108%_
                 (if (gerbil-ascent/program/objects#wide-scope? _%names11101%_)
                     (gerbil-ascent/program/objects#name-index _%bound11095%_)
                     '#f)))
            (let _%loop11110%_ ((_%remaining11112%_ _%names11101%_)
                                (_%next-bound11113%_ _%bound11095%_))
              (if (null? _%remaining11112%_)
                  '#!void
                  (begin
                    (if (if _%known11108%_
                            (let ((__tmp35916 (car _%remaining11112%_)))
                              (declare (not safe))
                              (__hash-get _%known11108%_ __tmp35916))
                            (memq (car _%remaining11112%_)
                                  _%next-bound11113%_))
                        (let ((__tmp35917 (car _%remaining11112%_)))
                          (declare (not safe))
                          (error '"ASCENT aggregate variable already bound"
                                 __tmp35917))
                        '#!void)
                    (if _%known11108%_
                        (let ((__tmp35918 (car _%remaining11112%_)))
                          (declare (not safe))
                          (__hash-put! _%known11108%_ __tmp35918 '#t))
                        '#!void)
                    (_%loop11110%_
                     (cdr _%remaining11112%_)
                     (cons (car _%remaining11112%_) _%next-bound11113%_))))))
          (let ((_%variables11117%_
                 (if (gerbil-ascent/program/objects#wide-scope?
                      _%inputs11103%_)
                     (gerbil-ascent/program/objects#name-index
                      (let ((__tmp35919
                             (lambda (_%term11115%_)
                               (if (eq? (car _%term11115%_) 'variable)
                                   (cdr _%term11115%_)
                                   '#f))))
                        (declare (not safe))
                        (filter-map__0 __tmp35919 _%terms11105%_)))
                     '#f)))
            (for-each
             (lambda (_%input11119%_)
               (if (if _%variables11117%_
                       (let ()
                         (declare (not safe))
                         (__hash-get _%variables11117%_ _%input11119%_))
                       (let ((__tmp35920
                              (lambda (_%term11121%_)
                                (and (eq? (car _%term11121%_) 'variable)
                                     (eq? (cdr _%term11121%_)
                                          _%input11119%_)))))
                         (declare (not safe))
                         (ormap__0 __tmp35920 _%terms11105%_)))
                   '#!void
                   (let ()
                     (declare (not safe))
                     (error '"ASCENT aggregate input absent from atom"
                            _%input11119%_))))
             _%inputs11103%_))
          (vector (vector 'aggregate
                          _%plan11097%_
                          _%name11099%_
                          _%inputs11103%_
                          (let ()
                            (declare (not safe))
                            (clan/poo/object#.ref _%clause11093%_ 'aggregate))
                          (let ()
                            (declare (not safe))
                            (clan/poo/object#.ref
                             _%clause11093%_
                             'output-pattern)))
                  (append _%names11101%_ _%bound11095%_)
                  '0))))
    (define gerbil-ascent/program/objects#gerbil-ascent-relation__%
      (lambda (_%relation-name10965%_
               _%column-count10966%_
               _%source-rows10967%_
               _%provider-value10968%_
               _%storage-value10969%_
               _%field-predicates-value10970%_
               _%domain-descriptor10971%_)
        (if (and (symbol? _%relation-name10965%_)
                 (exact-integer? _%column-count10966%_)
                 (<= '0 _%column-count10966%_)
                 (list? _%source-rows10967%_)
                 (list? _%field-predicates-value10970%_)
                 (or (null? _%field-predicates-value10970%_)
                     (= (let ()
                          (declare (not safe))
                          (##length _%field-predicates-value10970%_))
                        _%column-count10966%_))
                 (let ()
                   (declare (not safe))
                   (andmap__0 procedure? _%field-predicates-value10970%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT relation declaration"
                     _%relation-name10965%_
                     _%column-count10966%_)))
        (for-each
         (lambda (_%row10976%_)
           (if (and (list? _%row10976%_)
                    (= (let () (declare (not safe)) (##length _%row10976%_))
                       _%column-count10966%_))
               '#!void
               (let ()
                 (declare (not safe))
                 (error '"invalid ASCENT relation row"
                        _%relation-name10965%_
                        _%row10976%_
                        _%column-count10966%_)))
           (if (pair? _%field-predicates-value10970%_)
               (let ((__tmp35921
                      (lambda (_%predicate10978%_ _%value10979%_)
                        (if (_%predicate10978%_ _%value10979%_)
                            '#!void
                            (let ()
                              (declare (not safe))
                              (error '"ASCENT relation source field type mismatch"
                                     _%relation-name10965%_
                                     _%row10976%_))))))
                 (declare (not safe))
                 (##for-each
                  __tmp35921
                  _%field-predicates-value10970%_
                  _%row10976%_))
               '#!void))
         _%source-rows10967%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentRelationContract
         (let ((__obj35884
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp35923
                  (list (cons 'name
                              (let ((__tmp35924
                                     (lambda (_%@10999%_)
                                       _%relation-name10965%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35924)))
                        (cons 'arity
                              (let ((__tmp35925
                                     (lambda (_%@11005%_)
                                       _%column-count10966%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35925)))
                        (cons 'rows
                              (let ((__tmp35926
                                     (lambda (_%@11010%_)
                                       _%source-rows10967%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35926)))
                        (cons 'field-predicates
                              (let ((__tmp35927
                                     (lambda (_%@11015%_)
                                       _%field-predicates-value10970%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35927)))
                        (cons 'checked-domain
                              (let ((__tmp35928
                                     (lambda (_%@11020%_)
                                       _%domain-descriptor10971%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35928)))
                        (cons 'storage-kind
                              (let ((__tmp35929
                                     (lambda (_%@11025%_) 'relation)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35929)))
                        (cons 'index-provider
                              (let ((__tmp35930
                                     (lambda (_%@11030%_)
                                       _%provider-value10968%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35930)))
                        (cons 'storage-provider
                              (let ((__tmp35931
                                     (lambda (_%@11035%_)
                                       _%storage-value10969%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35931)))))
                 (__tmp35922 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Relation.
              __tmp35923
              __tmp35922
              __obj35884))
           __obj35884))))
    (define gerbil-ascent/program/objects#gerbil-ascent-relation__0
      (lambda (_%relation-name11043%_
               _%column-count11044%_
               _%source-rows11045%_)
        (let* ((_%provider-value11047%_
                gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider)
               (_%storage-value11049%_
                gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider)
               (_%field-predicates-value11051%_ '())
               (_%domain-descriptor11053%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-relation__%
           _%relation-name11043%_
           _%column-count11044%_
           _%source-rows11045%_
           _%provider-value11047%_
           _%storage-value11049%_
           _%field-predicates-value11051%_
           _%domain-descriptor11053%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-relation__1
      (lambda (_%relation-name11055%_
               _%column-count11056%_
               _%source-rows11057%_
               _%provider-value11058%_)
        (let* ((_%storage-value11060%_
                gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider)
               (_%field-predicates-value11062%_ '())
               (_%domain-descriptor11064%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-relation__%
           _%relation-name11055%_
           _%column-count11056%_
           _%source-rows11057%_
           _%provider-value11058%_
           _%storage-value11060%_
           _%field-predicates-value11062%_
           _%domain-descriptor11064%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-relation__2
      (lambda (_%relation-name11066%_
               _%column-count11067%_
               _%source-rows11068%_
               _%provider-value11069%_
               _%storage-value11070%_)
        (let* ((_%field-predicates-value11072%_ '())
               (_%domain-descriptor11074%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-relation__%
           _%relation-name11066%_
           _%column-count11067%_
           _%source-rows11068%_
           _%provider-value11069%_
           _%storage-value11070%_
           _%field-predicates-value11072%_
           _%domain-descriptor11074%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-relation__3
      (lambda (_%relation-name11076%_
               _%column-count11077%_
               _%source-rows11078%_
               _%provider-value11079%_
               _%storage-value11080%_
               _%field-predicates-value11081%_)
        (let ((_%domain-descriptor11083%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-relation__%
           _%relation-name11076%_
           _%column-count11077%_
           _%source-rows11078%_
           _%provider-value11079%_
           _%storage-value11080%_
           _%field-predicates-value11081%_
           _%domain-descriptor11083%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-relation
      (lambda _g35932_
        (let ((_g35933_ (let () (declare (not safe)) (##length _g35932_))))
          (cond ((let () (declare (not safe)) (##fx= _g35933_ 3))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-relation__0
                        _g35932_))
                ((let () (declare (not safe)) (##fx= _g35933_ 4))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-relation__1
                        _g35932_))
                ((let () (declare (not safe)) (##fx= _g35933_ 5))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-relation__2
                        _g35932_))
                ((let () (declare (not safe)) (##fx= _g35933_ 6))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-relation__3
                        _g35932_))
                ((let () (declare (not safe)) (##fx= _g35933_ 7))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-relation__%
                        _g35932_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-relation
                  _g35932_))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-lattice__%
      (lambda (_%relation-name10824%_
               _%column-count10825%_
               _%source-rows10826%_
               _%join-procedure10827%_
               _%provider-value10828%_
               _%field-predicates-value10829%_
               _%operator-descriptor10830%_
               _%domain-descriptor10831%_)
        (if (and (symbol? _%relation-name10824%_)
                 (exact-integer? _%column-count10825%_)
                 (> _%column-count10825%_ '0)
                 (list? _%source-rows10826%_)
                 (procedure? _%join-procedure10827%_)
                 (list? _%field-predicates-value10829%_)
                 (or (null? _%field-predicates-value10829%_)
                     (= (let ()
                          (declare (not safe))
                          (##length _%field-predicates-value10829%_))
                        _%column-count10825%_))
                 (let ()
                   (declare (not safe))
                   (andmap__0 procedure? _%field-predicates-value10829%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT lattice declaration"
                     _%relation-name10824%_
                     _%column-count10825%_)))
        (for-each
         (lambda (_%row10836%_)
           (if (and (list? _%row10836%_)
                    (= (let () (declare (not safe)) (##length _%row10836%_))
                       _%column-count10825%_))
               '#!void
               (let ()
                 (declare (not safe))
                 (error '"invalid ASCENT lattice row"
                        _%relation-name10824%_
                        _%row10836%_
                        _%column-count10825%_)))
           (if (pair? _%field-predicates-value10829%_)
               (let ((__tmp35934
                      (lambda (_%predicate10838%_ _%value10839%_)
                        (if (_%predicate10838%_ _%value10839%_)
                            '#!void
                            (let ()
                              (declare (not safe))
                              (error '"ASCENT lattice source field type mismatch"
                                     _%relation-name10824%_
                                     _%row10836%_))))))
                 (declare (not safe))
                 (##for-each
                  __tmp35934
                  _%field-predicates-value10829%_
                  _%row10836%_))
               '#!void))
         _%source-rows10826%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentLatticeContract
         (let ((__obj35885
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp35936
                  (list (cons 'name
                              (let ((__tmp35937
                                     (lambda (_%@10860%_)
                                       _%relation-name10824%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35937)))
                        (cons 'arity
                              (let ((__tmp35938
                                     (lambda (_%@10866%_)
                                       _%column-count10825%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35938)))
                        (cons 'rows
                              (let ((__tmp35939
                                     (lambda (_%@10871%_)
                                       _%source-rows10826%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35939)))
                        (cons 'field-predicates
                              (let ((__tmp35940
                                     (lambda (_%@10876%_)
                                       _%field-predicates-value10829%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35940)))
                        (cons 'checked-domain
                              (let ((__tmp35941
                                     (lambda (_%@10881%_)
                                       _%domain-descriptor10831%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35941)))
                        (cons 'storage-kind
                              (let ((__tmp35942
                                     (lambda (_%@10886%_) 'lattice)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35942)))
                        (cons 'join
                              (let ((__tmp35943
                                     (lambda (_%@10891%_)
                                       _%join-procedure10827%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35943)))
                        (cons 'checked-operator
                              (let ((__tmp35944
                                     (lambda (_%@10896%_)
                                       _%operator-descriptor10830%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35944)))
                        (cons 'index-provider
                              (let ((__tmp35945
                                     (lambda (_%@10901%_)
                                       _%provider-value10828%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35945)))))
                 (__tmp35935 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Lattice.
              __tmp35936
              __tmp35935
              __obj35885))
           __obj35885))))
    (define gerbil-ascent/program/objects#gerbil-ascent-lattice__0
      (lambda (_%relation-name10909%_
               _%column-count10910%_
               _%source-rows10911%_
               _%join-procedure10912%_)
        (let* ((_%provider-value10914%_
                gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider)
               (_%field-predicates-value10916%_ '())
               (_%operator-descriptor10918%_ '#f)
               (_%domain-descriptor10920%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-lattice__%
           _%relation-name10909%_
           _%column-count10910%_
           _%source-rows10911%_
           _%join-procedure10912%_
           _%provider-value10914%_
           _%field-predicates-value10916%_
           _%operator-descriptor10918%_
           _%domain-descriptor10920%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-lattice__1
      (lambda (_%relation-name10922%_
               _%column-count10923%_
               _%source-rows10924%_
               _%join-procedure10925%_
               _%provider-value10926%_)
        (let* ((_%field-predicates-value10928%_ '())
               (_%operator-descriptor10930%_ '#f)
               (_%domain-descriptor10932%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-lattice__%
           _%relation-name10922%_
           _%column-count10923%_
           _%source-rows10924%_
           _%join-procedure10925%_
           _%provider-value10926%_
           _%field-predicates-value10928%_
           _%operator-descriptor10930%_
           _%domain-descriptor10932%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-lattice__2
      (lambda (_%relation-name10934%_
               _%column-count10935%_
               _%source-rows10936%_
               _%join-procedure10937%_
               _%provider-value10938%_
               _%field-predicates-value10939%_)
        (let* ((_%operator-descriptor10941%_ '#f)
               (_%domain-descriptor10943%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-lattice__%
           _%relation-name10934%_
           _%column-count10935%_
           _%source-rows10936%_
           _%join-procedure10937%_
           _%provider-value10938%_
           _%field-predicates-value10939%_
           _%operator-descriptor10941%_
           _%domain-descriptor10943%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-lattice__3
      (lambda (_%relation-name10945%_
               _%column-count10946%_
               _%source-rows10947%_
               _%join-procedure10948%_
               _%provider-value10949%_
               _%field-predicates-value10950%_
               _%operator-descriptor10951%_)
        (let ((_%domain-descriptor10953%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-lattice__%
           _%relation-name10945%_
           _%column-count10946%_
           _%source-rows10947%_
           _%join-procedure10948%_
           _%provider-value10949%_
           _%field-predicates-value10950%_
           _%operator-descriptor10951%_
           _%domain-descriptor10953%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-lattice
      (lambda _g35946_
        (let ((_g35947_ (let () (declare (not safe)) (##length _g35946_))))
          (cond ((let () (declare (not safe)) (##fx= _g35947_ 4))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-lattice__0
                        _g35946_))
                ((let () (declare (not safe)) (##fx= _g35947_ 5))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-lattice__1
                        _g35946_))
                ((let () (declare (not safe)) (##fx= _g35947_ 6))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-lattice__2
                        _g35946_))
                ((let () (declare (not safe)) (##fx= _g35947_ 7))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-lattice__3
                        _g35946_))
                ((let () (declare (not safe)) (##fx= _g35947_ 8))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-lattice__%
                        _g35946_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-lattice
                  _g35946_))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-variable
      (lambda (_%name10798%_)
        (if (symbol? _%name10798%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"ASCENT variable name must be a symbol" _%name10798%_)))
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentTermContract
         (let ((__obj35886
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp35949
                  (list (cons 'kind
                              (let ((__tmp35950
                                     (lambda (_%@10812%_) 'variable)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35950)))
                        (cons 'value
                              (let ((__tmp35951
                                     (lambda (_%@10818%_) _%name10798%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35951)))))
                 (__tmp35948 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Term.
              __tmp35949
              __tmp35948
              __obj35886))
           __obj35886))))
    (define gerbil-ascent/program/objects#gerbil-ascent-wildcard
      (lambda ()
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentTermContract
         (let ((__obj35887
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp35953
                  (list (cons 'kind
                              (let ((__tmp35954
                                     (lambda (_%@10787%_) 'wildcard)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35954)))
                        (cons 'value
                              (let ((__tmp35955 (lambda (_%@10793%_) '#f)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35955)))))
                 (__tmp35952 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Term.
              __tmp35953
              __tmp35952
              __obj35887))
           __obj35887))))
    (define gerbil-ascent/program/objects#gerbil-ascent-literal
      (lambda (_%literal-value10749%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentTermContract
         (let ((__obj35888
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp35957
                  (list (cons 'kind
                              (let ((__tmp35958
                                     (lambda (_%@10763%_) 'literal)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35958)))
                        (cons 'value
                              (let ((__tmp35959
                                     (lambda (_%@10769%_)
                                       _%literal-value10749%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35959)))))
                 (__tmp35956 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Term.
              __tmp35957
              __tmp35956
              __obj35888))
           __obj35888))))
    (define gerbil-ascent/program/objects#gerbil-ascent-expression
      (lambda (_%input-variables10723%_ _%compute10724%_)
        (if (and (list? _%input-variables10723%_)
                 (let ()
                   (declare (not safe))
                   (andmap__0 symbol? _%input-variables10723%_))
                 (procedure? _%compute10724%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT head expression"
                     _%input-variables10723%_
                     _%compute10724%_)))
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentTermContract
         (let ((__obj35889
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp35961
                  (list (cons 'kind
                              (let ((__tmp35962
                                     (lambda (_%@10738%_) 'expression)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35962)))
                        (cons 'value
                              (let ((__tmp35963
                                     (lambda (_%@10744%_)
                                       (vector _%input-variables10723%_
                                               _%compute10724%_))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35963)))))
                 (__tmp35960 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Term.
              __tmp35961
              __tmp35960
              __obj35889))
           __obj35889))))
    (define gerbil-ascent/program/objects#gerbil-ascent-pattern
      (lambda (_%output-variables10697%_ _%matcher10698%_)
        (if (and (list? _%output-variables10697%_)
                 (let ()
                   (declare (not safe))
                   (andmap__0 symbol? _%output-variables10697%_))
                 (procedure? _%matcher10698%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT pattern"
                     _%output-variables10697%_
                     _%matcher10698%_)))
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentTermContract
         (let ((__obj35890
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp35965
                  (list (cons 'kind
                              (let ((__tmp35966
                                     (lambda (_%@10712%_) 'pattern)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35966)))
                        (cons 'value
                              (let ((__tmp35967
                                     (lambda (_%@10718%_)
                                       (vector _%output-variables10697%_
                                               _%matcher10698%_))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35967)))))
                 (__tmp35964 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Term.
              __tmp35965
              __tmp35964
              __obj35890))
           __obj35890))))
    (define gerbil-ascent/program/objects#gerbil-ascent-atom
      (lambda (_%relation-name10656%_ _%atom-terms10657%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentAtomContract
         (let ((__obj35891
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp35969
                  (list (cons 'ascent-clause-kind
                              (let ((__tmp35970
                                     (lambda (_%self10673%_) 'atom)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35970)))
                        (cons 'relation
                              (let ((__tmp35971
                                     (lambda (_%self10679%_)
                                       _%relation-name10656%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35971)))
                        (cons 'terms
                              (let ((__tmp35972
                                     (lambda (_%self10684%_)
                                       _%atom-terms10657%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35972)))
                        (cons '.plan
                              (let ((__tmp35973
                                     (lambda (_%self10689%_)
                                       (lambda (_%atom-plan10694%_
                                                _%bound10695%_)
                                         (gerbil-ascent/program/objects#atom-clause-plan
                                          _%self10689%_
                                          _%atom-plan10694%_
                                          _%bound10695%_)))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35973)))))
                 (__tmp35968 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Atom.
              __tmp35969
              __tmp35968
              __obj35891))
           __obj35891))))
    (define gerbil-ascent/program/objects#gerbil-ascent-guard__%
      (lambda (_%input-variables10596%_
               _%guard-procedure10597%_
               _%operator-descriptor10598%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentGuardContract
         (let ((__obj35892
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp35975
                  (list (cons 'ascent-clause-kind
                              (let ((__tmp35976
                                     (lambda (_%self10615%_) 'guard)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35976)))
                        (cons 'variables
                              (let ((__tmp35977
                                     (lambda (_%self10621%_)
                                       _%input-variables10596%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35977)))
                        (cons 'predicate
                              (let ((__tmp35978
                                     (lambda (_%self10626%_)
                                       _%guard-procedure10597%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35978)))
                        (cons 'checked-operator
                              (let ((__tmp35979
                                     (lambda (_%self10631%_)
                                       _%operator-descriptor10598%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35979)))
                        (cons '.plan
                              (let ((__tmp35980
                                     (lambda (_%self10636%_)
                                       (lambda (_%_atom-plan10641%_
                                                _%bound10642%_)
                                         (gerbil-ascent/program/objects#require-bound
                                          (let ()
                                            (declare (not safe))
                                            (clan/poo/object#.ref
                                             _%self10636%_
                                             'variables))
                                          (gerbil-ascent/program/objects#gerbil-ascent-bound-membership
                                           _%bound10642%_))
                                         (vector (vector 'guard
                                                         (let ()
                                                           (declare (not safe))
                                                           (clan/poo/object#.ref
                                                            _%self10636%_
                                                            'variables))
                                                         (let ()
                                                           (declare (not safe))
                                                           (clan/poo/object#.ref
                                                            _%self10636%_
                                                            'predicate)))
                                                 _%bound10642%_
                                                 '0)))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35980)))))
                 (__tmp35974 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Guard.
              __tmp35975
              __tmp35974
              __obj35892))
           __obj35892))))
    (define gerbil-ascent/program/objects#gerbil-ascent-guard__0
      (lambda (_%input-variables10647%_ _%guard-procedure10648%_)
        (let ((_%operator-descriptor10650%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-guard__%
           _%input-variables10647%_
           _%guard-procedure10648%_
           _%operator-descriptor10650%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-guard
      (lambda _g35981_
        (let ((_g35982_ (let () (declare (not safe)) (##length _g35981_))))
          (cond ((let () (declare (not safe)) (##fx= _g35982_ 2))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-guard__0
                        _g35981_))
                ((let () (declare (not safe)) (##fx= _g35982_ 3))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-guard__%
                        _g35981_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-guard
                  _g35981_))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-generator
      (lambda (_%output-variable10547%_
               _%input-variables10548%_
               _%generator-procedure10549%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentGeneratorContract
         (let ((__obj35893
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp35984
                  (list (cons 'ascent-clause-kind
                              (let ((__tmp35985
                                     (lambda (_%self10566%_) 'generator)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35985)))
                        (cons 'variable
                              (let ((__tmp35986
                                     (lambda (_%self10572%_)
                                       _%output-variable10547%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35986)))
                        (cons 'variables
                              (let ((__tmp35987
                                     (lambda (_%self10577%_)
                                       _%input-variables10548%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35987)))
                        (cons 'generate
                              (let ((__tmp35988
                                     (lambda (_%self10582%_)
                                       _%generator-procedure10549%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35988)))
                        (cons '.plan
                              (let ((__tmp35989
                                     (lambda (_%self10587%_)
                                       (lambda (_%_atom-plan10592%_
                                                _%bound10593%_)
                                         (gerbil-ascent/program/objects#computed-clause-plan
                                          _%self10587%_
                                          'generator
                                          'generate
                                          _%bound10593%_)))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35989)))))
                 (__tmp35983 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Generator.
              __tmp35984
              __tmp35983
              __obj35893))
           __obj35893))))
    (define gerbil-ascent/program/objects#gerbil-ascent-binding__%
      (lambda (_%output-variable10478%_
               _%input-variables10479%_
               _%binding-procedure10480%_
               _%operator-descriptor10481%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentBindingContract
         (let ((__obj35894
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp35991
                  (list (cons 'ascent-clause-kind
                              (let ((__tmp35992
                                     (lambda (_%self10499%_) 'binding)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35992)))
                        (cons 'variable
                              (let ((__tmp35993
                                     (lambda (_%self10505%_)
                                       _%output-variable10478%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35993)))
                        (cons 'variables
                              (let ((__tmp35994
                                     (lambda (_%self10510%_)
                                       _%input-variables10479%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35994)))
                        (cons 'compute
                              (let ((__tmp35995
                                     (lambda (_%self10515%_)
                                       _%binding-procedure10480%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35995)))
                        (cons 'checked-operator
                              (let ((__tmp35996
                                     (lambda (_%self10520%_)
                                       _%operator-descriptor10481%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35996)))
                        (cons '.plan
                              (let ((__tmp35997
                                     (lambda (_%self10525%_)
                                       (lambda (_%_atom-plan10530%_
                                                _%bound10531%_)
                                         (gerbil-ascent/program/objects#computed-clause-plan
                                          _%self10525%_
                                          'binding
                                          'compute
                                          _%bound10531%_)))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp35997)))))
                 (__tmp35990 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Binding.
              __tmp35991
              __tmp35990
              __obj35894))
           __obj35894))))
    (define gerbil-ascent/program/objects#gerbil-ascent-binding__0
      (lambda (_%output-variable10536%_
               _%input-variables10537%_
               _%binding-procedure10538%_)
        (let ((_%operator-descriptor10540%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-binding__%
           _%output-variable10536%_
           _%input-variables10537%_
           _%binding-procedure10538%_
           _%operator-descriptor10540%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-binding
      (lambda _g35998_
        (let ((_g35999_ (let () (declare (not safe)) (##length _g35998_))))
          (cond ((let () (declare (not safe)) (##fx= _g35999_ 3))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-binding__0
                        _g35998_))
                ((let () (declare (not safe)) (##fx= _g35999_ 4))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-binding__%
                        _g35998_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-binding
                  _g35998_))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-negation
      (lambda (_%relation-name10436%_ _%atom-terms10437%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentNegationContract
         (let ((__obj35895
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36001
                  (list (cons 'ascent-clause-kind
                              (let ((__tmp36002
                                     (lambda (_%self10453%_) 'negation)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36002)))
                        (cons 'relation
                              (let ((__tmp36003
                                     (lambda (_%self10459%_)
                                       _%relation-name10436%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36003)))
                        (cons 'terms
                              (let ((__tmp36004
                                     (lambda (_%self10464%_)
                                       _%atom-terms10437%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36004)))
                        (cons '.plan
                              (let ((__tmp36005
                                     (lambda (_%self10469%_)
                                       (lambda (_%atom-plan10474%_
                                                _%bound10475%_)
                                         (gerbil-ascent/program/objects#negation-clause-plan
                                          _%self10469%_
                                          _%atom-plan10474%_
                                          _%bound10475%_)))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36005)))))
                 (__tmp36000 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Negation.
              __tmp36001
              __tmp36000
              __obj35895))
           __obj35895))))
    (define gerbil-ascent/program/objects#gerbil-ascent-aggregate__%
      (lambda (_%output-variable10327%_
               _%relation-name10328%_
               _%atom-terms10329%_
               _%value-variables10330%_
               _%aggregate-procedure10331%_
               _%matcher10332%_
               _%operator-descriptor10333%_)
        (if (or (and (symbol? _%output-variable10327%_) (not _%matcher10332%_))
                (and (pair? _%output-variable10327%_)
                     (let ()
                       (declare (not safe))
                       (andmap__0 symbol? _%output-variable10327%_))
                     (procedure? _%matcher10332%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT aggregate output"
                     _%output-variable10327%_
                     _%matcher10332%_)))
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentAggregateContract
         (let ((__obj35896
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36007
                  (list (cons 'ascent-clause-kind
                              (let ((__tmp36008
                                     (lambda (_%self10357%_) 'aggregate)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36008)))
                        (cons 'variable
                              (let ((__tmp36009
                                     (lambda (_%self10363%_)
                                       _%output-variable10327%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36009)))
                        (cons 'relation
                              (let ((__tmp36010
                                     (lambda (_%self10368%_)
                                       _%relation-name10328%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36010)))
                        (cons 'terms
                              (let ((__tmp36011
                                     (lambda (_%self10373%_)
                                       _%atom-terms10329%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36011)))
                        (cons 'variables
                              (let ((__tmp36012
                                     (lambda (_%self10378%_)
                                       _%value-variables10330%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36012)))
                        (cons 'aggregate
                              (let ((__tmp36013
                                     (lambda (_%self10383%_)
                                       _%aggregate-procedure10331%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36013)))
                        (cons 'output-pattern
                              (let ((__tmp36014
                                     (lambda (_%self10388%_)
                                       _%matcher10332%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36014)))
                        (cons 'checked-operator
                              (let ((__tmp36015
                                     (lambda (_%self10393%_)
                                       _%operator-descriptor10333%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36015)))
                        (cons '.plan
                              (let ((__tmp36016
                                     (lambda (_%self10398%_)
                                       (lambda (_%atom-plan10403%_
                                                _%bound10404%_)
                                         (gerbil-ascent/program/objects#aggregate-clause-plan
                                          _%self10398%_
                                          _%atom-plan10403%_
                                          _%bound10404%_)))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36016)))))
                 (__tmp36006 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Aggregate.
              __tmp36007
              __tmp36006
              __obj35896))
           __obj35896))))
    (define gerbil-ascent/program/objects#gerbil-ascent-aggregate__0
      (lambda (_%output-variable10409%_
               _%relation-name10410%_
               _%atom-terms10411%_
               _%value-variables10412%_
               _%aggregate-procedure10413%_)
        (let* ((_%matcher10415%_ '#f) (_%operator-descriptor10417%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-aggregate__%
           _%output-variable10409%_
           _%relation-name10410%_
           _%atom-terms10411%_
           _%value-variables10412%_
           _%aggregate-procedure10413%_
           _%matcher10415%_
           _%operator-descriptor10417%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-aggregate__1
      (lambda (_%output-variable10419%_
               _%relation-name10420%_
               _%atom-terms10421%_
               _%value-variables10422%_
               _%aggregate-procedure10423%_
               _%matcher10424%_)
        (let ((_%operator-descriptor10426%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-aggregate__%
           _%output-variable10419%_
           _%relation-name10420%_
           _%atom-terms10421%_
           _%value-variables10422%_
           _%aggregate-procedure10423%_
           _%matcher10424%_
           _%operator-descriptor10426%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-aggregate
      (lambda _g36017_
        (let ((_g36018_ (let () (declare (not safe)) (##length _g36017_))))
          (cond ((let () (declare (not safe)) (##fx= _g36018_ 5))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-aggregate__0
                        _g36017_))
                ((let () (declare (not safe)) (##fx= _g36018_ 6))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-aggregate__1
                        _g36017_))
                ((let () (declare (not safe)) (##fx= _g36018_ 7))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-aggregate__%
                        _g36017_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-aggregate
                  _g36017_))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-rule
      (lambda (_%head-atoms10300%_ _%body-atoms10301%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentRuleContract
         (let ((__obj35897
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36020
                  (list (cons 'heads
                              (let ((__tmp36021
                                     (lambda (_%@10315%_)
                                       _%head-atoms10300%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36021)))
                        (cons 'body
                              (let ((__tmp36022
                                     (lambda (_%@10321%_)
                                       _%body-atoms10301%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36022)))))
                 (__tmp36019 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Rule.
              __tmp36020
              __tmp36019
              __obj35897))
           __obj35897))))
    (define gerbil-ascent/program/objects#fragment-export-resolver
      (lambda (_%export-values10289%_)
        (if (list? _%export-values10289%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT fragment exports"
                     _%export-values10289%_)))
        (let ((_%entries10291%_
               (let () (declare (not safe)) (make-hash-table-eq))))
          (for-each
           (lambda (_%entry10293%_)
             (if (and (pair? _%entry10293%_)
                      (symbol? (let ()
                                 (declare (not safe))
                                 (##car _%entry10293%_)))
                      (symbol? (let ()
                                 (declare (not safe))
                                 (##cdr _%entry10293%_)))
                      (not (let ((__tmp36023
                                  (let ()
                                    (declare (not safe))
                                    (##car _%entry10293%_))))
                             (declare (not safe))
                             (__hash-get _%entries10291%_ __tmp36023))))
                 '#!void
                 (let ()
                   (declare (not safe))
                   (error '"invalid or duplicate ASCENT fragment export"
                          _%entry10293%_)))
             (let ((__tmp36025 (car _%entry10293%_))
                   (__tmp36024 (cdr _%entry10293%_)))
               (declare (not safe))
               (__hash-put! _%entries10291%_ __tmp36025 __tmp36024)))
           _%export-values10289%_)
          (lambda (_%label10295%_)
            (let ((_%$e10297%_
                   (let ()
                     (declare (not safe))
                     (__hash-get _%entries10291%_ _%label10295%_))))
              (if _%$e10297%_
                  _%$e10297%_
                  (let ()
                    (declare (not safe))
                    (error '"unknown relational fragment export"
                           _%label10295%_))))))))
    (define gerbil-ascent/program/objects#declared-name-membership
      (lambda (_%relations10271%_)
        (let ((_%remaining10273%_ _%relations10271%_)
              (_%names10274%_
               (let () (declare (not safe)) (make-hash-table-eq))))
          (lambda (_%name10276%_)
            (let ((_%$e10278%_
                   (let ()
                     (declare (not safe))
                     (__hash-get _%names10274%_ _%name10276%_))))
              (if _%$e10278%_
                  _%$e10278%_
                  (let _%scan10281%_ ()
                    (if (null? _%remaining10273%_)
                        '#f
                        (let ((_%found10284%_
                               (let ((__tmp36026 (car _%remaining10273%_)))
                                 (declare (not safe))
                                 (clan/poo/object#.ref __tmp36026 'name))))
                          (set! _%remaining10273%_ (cdr _%remaining10273%_))
                          (let ()
                            (declare (not safe))
                            (__hash-put! _%names10274%_ _%found10284%_ '#t))
                          (let ((_%$e10286%_
                                 (eq? _%found10284%_ _%name10276%_)))
                            (if _%$e10286%_
                                _%$e10286%_
                                (_%scan10281%_))))))))))))
    (define gerbil-ascent/program/objects#checked-source-handles
      (lambda (_%relations10258%_ _%source-handle-values10259%_)
        (if (list? _%source-handle-values10259%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT source handles"
                     _%source-handle-values10259%_)))
        (letrec* ((_%seen10261%_
                   (let () (declare (not safe)) (make-hash-table-eq)))
                  (_%declared?10262%_
                   (gerbil-ascent/program/objects#declared-name-membership
                    _%relations10258%_)))
          (let _%loop10264%_ ((_%remaining10266%_
                               _%source-handle-values10259%_)
                              (_%copied10267%_ '()))
            (if (null? _%remaining10266%_)
                (reverse _%copied10267%_)
                (let ((_%name10269%_ (car _%remaining10266%_)))
                  (if (and (symbol? _%name10269%_)
                           (if (let ()
                                 (declare (not safe))
                                 (__hash-get _%seen10261%_ _%name10269%_))
                               '#f
                               (let ()
                                 (declare (not safe))
                                 (_%declared?10262%_ _%name10269%_))))
                      '#!void
                      (let ()
                        (declare (not safe))
                        (error '"invalid or duplicate ASCENT source handle"
                               _%name10269%_)))
                  (let ()
                    (declare (not safe))
                    (__hash-put! _%seen10261%_ _%name10269%_ '#t))
                  (_%loop10264%_
                   (cdr _%remaining10266%_)
                   (cons _%name10269%_ _%copied10267%_))))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-fragment__%
      (lambda (_%relation-values10197%_
               _%rule-values10198%_
               _%export-values10199%_
               _%source-handle-values10200%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentFragmentContract
         (let ((__obj35898
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36028
                  (list (cons 'relations
                              (let ((__tmp36029
                                     (lambda (_%@10216%_)
                                       _%relation-values10197%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36029)))
                        (cons 'rules
                              (let ((__tmp36030
                                     (lambda (_%@10222%_)
                                       _%rule-values10198%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36030)))
                        (cons 'exports
                              (let ((__tmp36031
                                     (lambda (_%@10227%_)
                                       (gerbil-ascent/program/objects#fragment-export-resolver
                                        _%export-values10199%_))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36031)))
                        (cons 'source-handles
                              (let ((__tmp36032
                                     (lambda (_%@10232%_)
                                       (gerbil-ascent/program/objects#checked-source-handles
                                        _%relation-values10197%_
                                        _%source-handle-values10200%_))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36032)))))
                 (__tmp36027 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Fragment.
              __tmp36028
              __tmp36027
              __obj35898))
           __obj35898))))
    (define gerbil-ascent/program/objects#gerbil-ascent-fragment__0
      (lambda (_%relation-values10240%_ _%rule-values10241%_)
        (let* ((_%export-values10243%_ '())
               (_%source-handle-values10245%_ '()))
          (gerbil-ascent/program/objects#gerbil-ascent-fragment__%
           _%relation-values10240%_
           _%rule-values10241%_
           _%export-values10243%_
           _%source-handle-values10245%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-fragment__1
      (lambda (_%relation-values10247%_
               _%rule-values10248%_
               _%export-values10249%_)
        (let ((_%source-handle-values10251%_ '()))
          (gerbil-ascent/program/objects#gerbil-ascent-fragment__%
           _%relation-values10247%_
           _%rule-values10248%_
           _%export-values10249%_
           _%source-handle-values10251%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-fragment
      (lambda _g36033_
        (let ((_g36034_ (let () (declare (not safe)) (##length _g36033_))))
          (cond ((let () (declare (not safe)) (##fx= _g36034_ 2))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-fragment__0
                        _g36033_))
                ((let () (declare (not safe)) (##fx= _g36034_ 3))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-fragment__1
                        _g36033_))
                ((let () (declare (not safe)) (##fx= _g36034_ 4))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-fragment__%
                        _g36033_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-fragment
                  _g36033_))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-program__%
      (lambda (_%declared-relations10123%_
               _%declared-rules10124%_
               _%input-fact-limit10125%_
               _%derived-fact-limit10126%_
               _%output-fact-limit10127%_
               _%source-handle-values10128%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentProgramContract
         (let ((__obj35899
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36036
                  (list (cons 'relations
                              (let ((__tmp36037
                                     (lambda (_%@10147%_)
                                       _%declared-relations10123%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36037)))
                        (cons 'rules
                              (let ((__tmp36038
                                     (lambda (_%@10153%_)
                                       _%declared-rules10124%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36038)))
                        (cons 'source-handles
                              (let ((__tmp36039
                                     (lambda (_%@10158%_)
                                       (gerbil-ascent/program/objects#checked-source-handles
                                        _%declared-relations10123%_
                                        _%source-handle-values10128%_))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36039)))
                        (cons 'max-input-facts
                              (let ((__tmp36040
                                     (lambda (_%@10163%_)
                                       _%input-fact-limit10125%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36040)))
                        (cons 'max-derived-facts
                              (let ((__tmp36041
                                     (lambda (_%@10168%_)
                                       _%derived-fact-limit10126%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36041)))
                        (cons 'max-output-facts
                              (let ((__tmp36042
                                     (lambda (_%@10173%_)
                                       _%output-fact-limit10127%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36042)))))
                 (__tmp36035 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Program.
              __tmp36036
              __tmp36035
              __obj35899))
           __obj35899))))
    (define gerbil-ascent/program/objects#gerbil-ascent-program__0
      (lambda (_%declared-relations10181%_
               _%declared-rules10182%_
               _%input-fact-limit10183%_
               _%derived-fact-limit10184%_
               _%output-fact-limit10185%_)
        (let ((_%source-handle-values10187%_ '()))
          (gerbil-ascent/program/objects#gerbil-ascent-program__%
           _%declared-relations10181%_
           _%declared-rules10182%_
           _%input-fact-limit10183%_
           _%derived-fact-limit10184%_
           _%output-fact-limit10185%_
           _%source-handle-values10187%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-program
      (lambda _g36043_
        (let ((_g36044_ (let () (declare (not safe)) (##length _g36043_))))
          (cond ((let () (declare (not safe)) (##fx= _g36044_ 5))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-program__0
                        _g36043_))
                ((let () (declare (not safe)) (##fx= _g36044_ 6))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-program__%
                        _g36043_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-program
                  _g36043_))))))))
