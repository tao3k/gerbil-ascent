(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/certificate-limits::timestamp 1791687861)
  (begin
    (define gerbil-ascent/candidate/certificate-limits#+max-certificate-relations+
      '64)
    (define gerbil-ascent/candidate/certificate-limits#+max-certificate-rows+
      '4096)
    (define gerbil-ascent/candidate/certificate-limits#+max-certificate-cells+
      '32768)
    (define gerbil-ascent/candidate/certificate-limits#+max-certificate-row-arity+
      '1024)
    (define gerbil-ascent/candidate/certificate-limits#certificate-material::t
      (let ((__tmp33990 (list)) (__tmp33989 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/certificate-limits#certificate-material::t
         'certificate-material
         __tmp33990
         '(rows cells)
         __tmp33989
         '#f)))
    (define gerbil-ascent/candidate/certificate-limits#certificate-material?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/certificate-limits#certificate-material::t)))
    (define gerbil-ascent/candidate/certificate-limits#make-certificate-material
      (lambda _%$args27311%_
        (apply make-instance
               gerbil-ascent/candidate/certificate-limits#certificate-material::t
               _%$args27311%_)))
    (define gerbil-ascent/candidate/certificate-limits#certificate-material-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/certificate-limits#certificate-material::t
         'rows)))
    (define gerbil-ascent/candidate/certificate-limits#certificate-material-cells
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/certificate-limits#certificate-material::t
         'cells)))
    (define gerbil-ascent/candidate/certificate-limits#certificate-material-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/certificate-limits#certificate-material::t
         'rows)))
    (define gerbil-ascent/candidate/certificate-limits#certificate-material-cells-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/certificate-limits#certificate-material::t
         'cells)))
    (define gerbil-ascent/candidate/certificate-limits#&certificate-material-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/certificate-limits#certificate-material::t
         'rows)))
    (define gerbil-ascent/candidate/certificate-limits#&certificate-material-cells
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/certificate-limits#certificate-material::t
         'cells)))
    (define gerbil-ascent/candidate/certificate-limits#&certificate-material-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/certificate-limits#certificate-material::t
         'rows)))
    (define gerbil-ascent/candidate/certificate-limits#&certificate-material-cells-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/certificate-limits#certificate-material::t
         'cells)))
    (define gerbil-ascent/candidate/certificate-limits#make-certificate-material-budget
      (lambda ()
        (let ()
          (declare (not safe))
          (##structure
           gerbil-ascent/candidate/certificate-limits#certificate-material::t
           '0
           '0))))
    (define gerbil-ascent/candidate/certificate-limits#certificate-material-reserve!
      (lambda (_%budget27305%_ _%row27306%_)
        (let ((_%width27308%_
               (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                _%row27306%_
                gerbil-ascent/candidate/certificate-limits#+max-certificate-row-arity+)))
          (if _%width27308%_
              (if (< (##structure-ref
                      _%budget27305%_
                      '1
                      gerbil-ascent/candidate/certificate-limits#certificate-material::t
                      '#f)
                     gerbil-ascent/candidate/certificate-limits#+max-certificate-rows+)
                  (if (<= (+ (##structure-ref
                              _%budget27305%_
                              '2
                              gerbil-ascent/candidate/certificate-limits#certificate-material::t
                              '#f)
                             _%width27308%_)
                          gerbil-ascent/candidate/certificate-limits#+max-certificate-cells+)
                      (begin
                        (##structure-set!
                         _%budget27305%_
                         (+ (##structure-ref
                             _%budget27305%_
                             '1
                             gerbil-ascent/candidate/certificate-limits#certificate-material::t
                             '#f)
                            '1)
                         '1
                         gerbil-ascent/candidate/certificate-limits#certificate-material::t
                         '#f)
                        (##structure-set!
                         _%budget27305%_
                         (+ (##structure-ref
                             _%budget27305%_
                             '2
                             gerbil-ascent/candidate/certificate-limits#certificate-material::t
                             '#f)
                            _%width27308%_)
                         '2
                         gerbil-ascent/candidate/certificate-limits#certificate-material::t
                         '#f)
                        '#t)
                      '#f)
                  '#f)
              '#f))))
    (define gerbil-ascent/candidate/certificate-limits#bounded-list-length
      (lambda (_%items27289%_ _%maximum27290%_)
        (let _%$loop27292%_ ((_%rest27295%_ _%items27289%_)
                             (_%count27296%_ '0))
          (if (or (null? _%rest27295%_)
                  (not (pair? _%rest27295%_))
                  (>= _%count27296%_ _%maximum27290%_))
              (if (null? _%rest27295%_) _%count27296%_ '#f)
              (_%$loop27292%_ (cdr _%rest27295%_) (+ _%count27296%_ '1))))))
    (define gerbil-ascent/candidate/certificate-limits#unique-rows?
      (lambda (_%rows27283%_)
        (let* ((_%seen27285%_
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value)))
               (__tmp33991
                (lambda (_%row27287%_)
                  (if (let ()
                        (declare (not safe))
                        (__hash-get _%seen27285%_ _%row27287%_))
                      '#f
                      (begin
                        (let ()
                          (declare (not safe))
                          (__hash-put! _%seen27285%_ _%row27287%_ '#t))
                        '#t)))))
          (declare (not safe))
          (andmap__0 __tmp33991 _%rows27283%_))))
    (define gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
      (lambda (_%proceed?27272%_ _%visit27273%_ _%items27274%_)
        (let _%walk27276%_ ((_%remaining27278%_ _%items27274%_))
          (if (_%proceed?27272%_)
              (if (null? _%remaining27278%_)
                  '#t
                  (let ()
                    (_%visit27273%_ (car _%remaining27278%_))
                    (_%walk27276%_ (cdr _%remaining27278%_))))
              '#f))))))
