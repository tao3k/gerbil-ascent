(declare (block) (standard-bindings) (extended-bindings))
(begin (begin) (load-module "gerbil-ascent/program/source-log~0"))
