(define original-make-class-type __make-class-type)
(set! __make-class-type (lambda args (display (car args) (current-error-port)) (newline (current-error-port)) (force-output (current-error-port)) (apply original-make-class-type args)))
