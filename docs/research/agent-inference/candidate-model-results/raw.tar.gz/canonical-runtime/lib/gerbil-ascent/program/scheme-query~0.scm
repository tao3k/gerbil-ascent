(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/scheme-query::timestamp 1791689697)
  (begin
    (define gerbil-ascent/program/scheme-query#relational-solution::t
      (let ((__tmp36236 (list)) (__tmp36235 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/scheme-query#relational-solution::t
         'relational-solution
         __tmp36236
         '(result)
         __tmp36235
         '#f)))
    (define gerbil-ascent/program/scheme-query#relational-solution?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/scheme-query#relational-solution::t)))
    (define gerbil-ascent/program/scheme-query#make-relational-solution
      (lambda _%$args20202%_
        (apply make-instance
               gerbil-ascent/program/scheme-query#relational-solution::t
               _%$args20202%_)))
    (define gerbil-ascent/program/scheme-query#relational-solution-result
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-query#relational-solution::t
         'result)))
    (define gerbil-ascent/program/scheme-query#relational-solution-result-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-query#relational-solution::t
         'result)))
    (define gerbil-ascent/program/scheme-query#&relational-solution-result
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-query#relational-solution::t
         'result)))
    (define gerbil-ascent/program/scheme-query#&relational-solution-result-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-query#relational-solution::t
         'result)))
    (define gerbil-ascent/program/scheme-query#relational-program-solution::t
      (let ((__tmp36238 (list)) (__tmp36237 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/scheme-query#relational-program-solution::t
         'relational-program-solution
         __tmp36238
         '(result)
         __tmp36237
         '#f)))
    (define gerbil-ascent/program/scheme-query#relational-program-solution?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/scheme-query#relational-program-solution::t)))
    (define gerbil-ascent/program/scheme-query#make-relational-program-solution
      (lambda _%$args20199%_
        (apply make-instance
               gerbil-ascent/program/scheme-query#relational-program-solution::t
               _%$args20199%_)))
    (define gerbil-ascent/program/scheme-query#relational-program-solution-result
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-query#relational-program-solution::t
         'result)))
    (define gerbil-ascent/program/scheme-query#relational-program-solution-result-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-query#relational-program-solution::t
         'result)))
    (define gerbil-ascent/program/scheme-query#&relational-program-solution-result
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-query#relational-program-solution::t
         'result)))
    (define gerbil-ascent/program/scheme-query#&relational-program-solution-result-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-query#relational-program-solution::t
         'result)))
    (define gerbil-ascent/program/scheme-query#copy-query-rows
      (lambda (_%rows20195%_)
        (map (lambda (_%row20197%_) (map identity _%row20197%_))
             _%rows20195%_)))
    (define gerbil-ascent/program/scheme-query#relational-result-rows
      (lambda (_%result20192%_ _%name20193%_)
        (if (let ()
              (declare (not safe))
              (clan/poo/object#.ref _%result20192%_ 'finished))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational query requires a completed result")))
        (gerbil-ascent/program/scheme-query#copy-query-rows
         ((let ()
            (declare (not safe))
            (clan/poo/object#.ref _%result20192%_ 'rows-of))
          _%name20193%_))))
    (define gerbil-ascent/program/scheme-query#relational-export
      (lambda (_%fragment20189%_ _%label20190%_)
        (let ()
          (declare (not safe))
          (clan/poo/mop#validate
           gerbil-ascent/program/types#GerbilAscentFragmentContract
           _%fragment20189%_))
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%fragment20189%_ 'exports))
         _%label20190%_)))
    (define gerbil-ascent/program/scheme-query#checked-solution-result
      (lambda (_%solution20185%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%solution20185%_
               'gerbil-ascent/program/scheme-query#relational-solution::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational query requires a solved value"
                     _%solution20185%_)))
        (let ((_%result20187%_
               (##structure-ref
                _%solution20185%_
                '1
                gerbil-ascent/program/scheme-query#relational-solution::t
                '#f)))
          (if (let ()
                (declare (not safe))
                (clan/poo/object#.ref _%result20187%_ 'finished))
              '#!void
              (let ()
                (declare (not safe))
                (error '"relational query requires a completed result")))
          _%result20187%_)))
    (define gerbil-ascent/program/scheme-query#relational-prepare-query
      (lambda (_%fragment20176%_ _%label20177%_)
        (let ((_%name20179%_
               (gerbil-ascent/program/scheme-query#relational-export
                _%fragment20176%_
                _%label20177%_)))
          (lambda (_%solution20181%_)
            (let ((_%rows-of20183%_
                   (let ((__tmp36239
                          (gerbil-ascent/program/scheme-query#checked-solution-result
                           _%solution20181%_)))
                     (declare (not safe))
                     (clan/poo/object#.ref __tmp36239 'rows-of))))
              (gerbil-ascent/program/scheme-query#copy-query-rows
               (_%rows-of20183%_ _%name20179%_)))))))
    (define gerbil-ascent/program/scheme-query#relational-prepare-queries
      (lambda (_%fragment20159%_ _%labels20160%_)
        (if (and (list? _%labels20160%_)
                 (let ()
                   (declare (not safe))
                   (andmap__0 symbol? _%labels20160%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational query view requires exported labels"
                     _%labels20160%_)))
        (let ()
          (declare (not safe))
          (clan/poo/mop#validate
           gerbil-ascent/program/types#GerbilAscentFragmentContract
           _%fragment20159%_))
        (let* ((_%exports20162%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%fragment20159%_ 'exports)))
               (_%names20164%_ (map _%exports20162%_ _%labels20160%_)))
          (lambda (_%solution20167%_)
            (let* ((_%result20169%_
                    (gerbil-ascent/program/scheme-query#checked-solution-result
                     _%solution20167%_))
                   (_%rows-of20171%_
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%result20169%_ 'rows-of)))
                   (__tmp36240
                    (lambda (_%name20174%_)
                      (gerbil-ascent/program/scheme-query#copy-query-rows
                       (_%rows-of20171%_ _%name20174%_)))))
              (declare (not safe))
              (##map __tmp36240 _%names20164%_))))))
    (define gerbil-ascent/program/scheme-query#relational-query
      (lambda (_%solution20153%_ _%fragment20154%_ _%label20155%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%solution20153%_
               'gerbil-ascent/program/scheme-query#relational-solution::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational query requires a solved value"
                     _%solution20153%_)))
        (let ((_%result20157%_
               (##structure-ref
                _%solution20153%_
                '1
                gerbil-ascent/program/scheme-query#relational-solution::t
                '#f)))
          (gerbil-ascent/program/scheme-query#relational-result-rows
           _%result20157%_
           (gerbil-ascent/program/scheme-query#relational-export
            _%fragment20154%_
            _%label20155%_)))))
    (define gerbil-ascent/program/scheme-query#relational-query-name
      (lambda (_%solution20148%_ _%name20149%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-instance-of?
                    _%solution20148%_
                    'gerbil-ascent/program/scheme-query#relational-solution::t))
                 (symbol? _%name20149%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational named query requires a solved value"
                     _%name20149%_)))
        (let ((_%result20151%_
               (##structure-ref
                _%solution20148%_
                '1
                gerbil-ascent/program/scheme-query#relational-solution::t
                '#f)))
          (gerbil-ascent/program/scheme-query#relational-result-rows
           _%result20151%_
           _%name20149%_))))
    (define gerbil-ascent/program/scheme-query#relational-program-query
      (lambda (_%solution20143%_ _%name20144%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-instance-of?
                    _%solution20143%_
                    'gerbil-ascent/program/scheme-query#relational-program-solution::t))
                 (symbol? _%name20144%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational program query requires a named solution"
                     _%name20144%_)))
        (let ((_%result20146%_
               (##structure-ref
                _%solution20143%_
                '1
                gerbil-ascent/program/scheme-query#relational-program-solution::t
                '#f)))
          (gerbil-ascent/program/scheme-query#relational-result-rows
           _%result20146%_
           _%name20144%_))))))
