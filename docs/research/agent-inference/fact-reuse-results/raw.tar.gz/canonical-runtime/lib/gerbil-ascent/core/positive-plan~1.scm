(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/core/positive-plan[:0:]#match-value!|
    (lambda (_%$stx8463%_)
      (let* ((_%$%g84678489%_
              (lambda (_%$%g84688485%_)
                (let ()
                  (declare (not safe))
                  (gx#raise-syntax-error
                   '#f
                   '"Bad syntax; invalid match target"
                   _%$%g84688485%_))))
             (_%$%g84668559%_
              (lambda (_%$%g84688493%_)
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair? _%$%g84688493%_))
                    (let ((_%$%e84728496%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%$%g84688493%_))))
                      (let ((_%$%hd84738500%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e84728496%_)))
                            (_%$%tl84748503%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e84728496%_))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair? _%$%tl84748503%_))
                            (let ((_%$%e84758506%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-e _%$%tl84748503%_))))
                              (let ((_%$%hd84768510%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e84758506%_)))
                                    (_%$%tl84778513%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e84758506%_))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%tl84778513%_))
                                    (let ((_%$%e84788516%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e _%$%tl84778513%_))))
                                      (let ((_%$%hd84798520%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e84788516%_)))
                                            (_%$%tl84808523%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e84788516%_))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair? _%$%tl84808523%_))
                                            (let ((_%$%e84818526%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl84808523%_))))
                                              (let ((_%$%hd84828530%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e84818526%_)))
                                                    (_%$%tl84838533%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e84818526%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl84838533%_))
                                                    (cons (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#datum->syntax__0
                                                             '#f
                                                             'let))
                                                          (cons (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                      (declare (not safe))
                                      (gx#datum->syntax__0 '#f 'selected))
                                    (cons _%$%hd84768510%_ '()))
                              (cons (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0 '#f 'stored))
                                          (cons _%$%hd84798520%_ '()))
                                    (cons (cons (let ()
                                                  (declare (not safe))
                                                  (gx#datum->syntax__0
                                                   '#f
                                                   'bindings))
                                                (cons _%$%hd84828530%_ '()))
                                          '())))
                        (cons (cons (let ()
                                      (declare (not safe))
                                      (gx#datum->syntax__0 '#f 'case))
                                    (cons (cons (let ()
                                                  (declare (not safe))
                                                  (gx#datum->syntax__0
                                                   '#f
                                                   'car))
                                                (cons (let ()
                                                        (declare (not safe))
                                                        (gx#datum->syntax__0
                                                         '#f
                                                         'selected))
                                                      '()))
                                          (cons (cons (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'fresh))
                                                            '())
                                                      (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (declare (not safe))
                            (gx#datum->syntax__0 '#f 'vector-set!))
                          (cons (let ()
                                  (declare (not safe))
                                  (gx#datum->syntax__0 '#f 'bindings))
                                (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0 '#f 'cdr))
                                            (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'selected))
                                                  '()))
                                      (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'stored))
                                            '()))))
                    (cons '#t '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (cons (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (declare (not safe))
                            (gx#datum->syntax__0 '#f 'bound))
                          '())
                    (cons (cons (let ()
                                  (declare (not safe))
                                  (gx#datum->syntax__0 '#f 'equal?))
                                (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'vector-ref))
                                            (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'bindings))
                                                  (cons (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'cdr))
                      (cons (let ()
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'selected))
                            '()))
                '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                      (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'stored))
                                            '())))
                          '()))
              (cons (cons (cons (let ()
                                  (declare (not safe))
                                  (gx#datum->syntax__0 '#f 'literal))
                                '())
                          (cons (cons (let ()
                                        (declare (not safe))
                                        (gx#datum->syntax__0 '#f 'equal?))
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'cdr))
                                                  (cons (let ()
                                                          (declare (not safe))
                                                          (gx#datum->syntax__0
                                                           '#f
                                                           'selected))
                                                        '()))
                                            (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'stored))
                                                  '())))
                                '()))
                    (cons (cons (cons (let ()
                                        (declare (not safe))
                                        (gx#datum->syntax__0 '#f 'expression))
                                      '())
                                (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'equal?))
                                            (cons (cons (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'cdr))
                      (cons (let ()
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'selected))
                            '()))
                (cons (let ()
                        (declare (not safe))
                        (gx#datum->syntax__0 '#f 'bindings))
                      '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons (let ()
                                                          (declare (not safe))
                                                          (gx#datum->syntax__0
                                                           '#f
                                                           'stored))
                                                        '())))
                                      '()))
                          (cons (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'wildcard))
                                            '())
                                      (cons '#t '()))
                                '())))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                              '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%g84678489%_
                                                     _%$%g84688493%_))))
                                            (_%$%g84678489%_
                                             _%$%g84688493%_))))
                                    (_%$%g84678489%_ _%$%g84688493%_))))
                            (_%$%g84678489%_ _%$%g84688493%_))))
                    (_%$%g84678489%_ _%$%g84688493%_)))))
        (_%$%g84668559%_ _%$stx8463%_))))
  (define |gerbil-ascent/core/positive-plan[:0:]#parts-matcher|
    (lambda (_%$stx8563%_)
      (let* ((_%$%g85678608%_
              (lambda (_%$%g85688604%_)
                (let ()
                  (declare (not safe))
                  (gx#raise-syntax-error
                   '#f
                   '"Bad syntax; invalid match target"
                   _%$%g85688604%_))))
             (_%$%g85668745%_
              (lambda (_%$%g85688612%_)
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair? _%$%g85688612%_))
                    (let ((_%$%e85768615%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%$%g85688612%_))))
                      (let ((_%$%hd85778619%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e85768615%_)))
                            (_%$%tl85788622%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e85768615%_))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair? _%$%tl85788622%_))
                            (let ((_%$%e85798625%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-e _%$%tl85788622%_))))
                              (let ((_%$%hd85808629%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e85798625%_)))
                                    (_%$%tl85818632%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e85798625%_))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%tl85818632%_))
                                    (let ((_%$%e85828635%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e _%$%tl85818632%_))))
                                      (let ((_%$%hd85838639%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e85828635%_)))
                                            (_%$%tl85848642%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e85828635%_))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair? _%$%hd85838639%_))
                                            (let ((_%$%e85858645%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%hd85838639%_))))
                                              (let ((_%$%hd85868649%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e85858645%_)))
                                                    (_%$%tl85878652%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e85858645%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair?
                                                       _%$%tl85878652%_))
                                                    (let ((_%$%e85888655%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-e
                                                              _%$%tl85878652%_))))
                                                      (let ((_%$%hd85898659%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##car _%$%e85888655%_)))
                    (_%$%tl85908662%_
                     (let () (declare (not safe)) (##cdr _%$%e85888655%_))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair? _%$%tl85908662%_))
                    (let ((_%$%e85918665%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%$%tl85908662%_))))
                      (let ((_%$%hd85928669%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e85918665%_)))
                            (_%$%tl85938672%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e85918665%_))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair? _%$%tl85938672%_))
                            (let ((_%$%e85948675%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-e _%$%tl85938672%_))))
                              (let ((_%$%hd85958679%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e85948675%_)))
                                    (_%$%tl85968682%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e85948675%_))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl85968682%_))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%tl85848642%_))
                                        (let ((_%$%e85978685%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%tl85848642%_))))
                                          (let ((_%$%hd85988689%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e85978685%_)))
                                                (_%$%tl85998692%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e85978685%_))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair?
                                                   _%$%tl85998692%_))
                                                (let ((_%$%e86008695%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-e
                                                          _%$%tl85998692%_))))
                                                  (let ((_%$%hd86018699%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e86008695%_)))
                                                        (_%$%tl86028702%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e86008695%_))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl86028702%_))
                                                        (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'lambda))
                      (cons (cons _%$%hd85868649%_
                                  (cons _%$%hd85898659%_
                                        (cons _%$%hd85928669%_
                                              (cons _%$%hd85958679%_ '()))))
                            (cons (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'if))
                                        (cons _%$%hd85988689%_
                                              (cons _%$%hd86018699%_
                                                    (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'match-parts!))
                        (cons _%$%hd85808629%_
                              (cons _%$%hd85868649%_
                                    (cons _%$%hd85898659%_
                                          (cons _%$%hd85928669%_
                                                (cons _%$%hd85958679%_
                                                      '()))))))
                  '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                  '())))
                (_%$%g85678608%_ _%$%g85688612%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (_%$%g85678608%_
                                                 _%$%g85688612%_))))
                                        (_%$%g85678608%_ _%$%g85688612%_))
                                    (_%$%g85678608%_ _%$%g85688612%_))))
                            (_%$%g85678608%_ _%$%g85688612%_))))
                    (_%$%g85678608%_ _%$%g85688612%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%g85678608%_
                                                     _%$%g85688612%_))))
                                            (_%$%g85678608%_
                                             _%$%g85688612%_))))
                                    (_%$%g85678608%_ _%$%g85688612%_))))
                            (_%$%g85678608%_ _%$%g85688612%_))))
                    (_%$%g85678608%_ _%$%g85688612%_)))))
        (_%$%g85668745%_ _%$stx8563%_)))))
