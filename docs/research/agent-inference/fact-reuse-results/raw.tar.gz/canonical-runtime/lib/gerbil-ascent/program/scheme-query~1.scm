(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/scheme-query[1]#_g36793_|
    (##structure
     gx#syntax-quote::t
     'relational-solution::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36795_|
    (##structure
     gx#syntax-quote::t
     'make-relational-solution
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36797_|
    (##structure
     gx#syntax-quote::t
     'relational-solution?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36799_|
    (##structure
     gx#syntax-quote::t
     'relational-solution-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36801_|
    (##structure
     gx#syntax-quote::t
     'relational-solution-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36803_|
    (##structure
     gx#syntax-quote::t
     '&relational-solution-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36805_|
    (##structure
     gx#syntax-quote::t
     '&relational-solution-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36807_|
    (##structure
     gx#syntax-quote::t
     'relational-program-solution::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36809_|
    (##structure
     gx#syntax-quote::t
     'make-relational-program-solution
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36811_|
    (##structure
     gx#syntax-quote::t
     'relational-program-solution?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36813_|
    (##structure
     gx#syntax-quote::t
     'relational-program-solution-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36815_|
    (##structure
     gx#syntax-quote::t
     'relational-program-solution-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36817_|
    (##structure
     gx#syntax-quote::t
     '&relational-program-solution-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36819_|
    (##structure
     gx#syntax-quote::t
     '&relational-program-solution-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/scheme-query[:0:]#relational-solution|
      (let ((__obj36676
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36676
           'gerbil-ascent/program/scheme-query#relational-solution::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36676
           'relational-solution
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36676 '(result) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36676 '(result) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36676 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36676 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36676 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36676 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36676 '#f '13 '#f '#f))
        (let ((__tmp36792 |gerbil-ascent/program/scheme-query[1]#_g36793_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36676 __tmp36792 '4 '#f '#f))
        (let ((__tmp36794 |gerbil-ascent/program/scheme-query[1]#_g36795_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36676 __tmp36794 '14 '#f '#f))
        (let ((__tmp36796 |gerbil-ascent/program/scheme-query[1]#_g36797_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36676 __tmp36796 '15 '#f '#f))
        (let ((__tmp36798
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36799_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36676 __tmp36798 '16 '#f '#f))
        (let ((__tmp36800
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36801_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36676 __tmp36800 '17 '#f '#f))
        (let ((__tmp36802
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36803_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36676 __tmp36802 '18 '#f '#f))
        (let ((__tmp36804
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36805_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36676 __tmp36804 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36676 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36676 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36676 '() '21 '#f '#f))
        __obj36676))
    (define |gerbil-ascent/program/scheme-query[:0:]#relational-program-solution|
      (let ((__obj36677
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36677
           'gerbil-ascent/program/scheme-query#relational-program-solution::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36677
           'relational-program-solution
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36677 '(result) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36677 '(result) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36677 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36677 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36677 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36677 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36677 '#f '13 '#f '#f))
        (let ((__tmp36806 |gerbil-ascent/program/scheme-query[1]#_g36807_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36677 __tmp36806 '4 '#f '#f))
        (let ((__tmp36808 |gerbil-ascent/program/scheme-query[1]#_g36809_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36677 __tmp36808 '14 '#f '#f))
        (let ((__tmp36810 |gerbil-ascent/program/scheme-query[1]#_g36811_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36677 __tmp36810 '15 '#f '#f))
        (let ((__tmp36812
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36813_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36677 __tmp36812 '16 '#f '#f))
        (let ((__tmp36814
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36815_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36677 __tmp36814 '17 '#f '#f))
        (let ((__tmp36816
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36817_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36677 __tmp36816 '18 '#f '#f))
        (let ((__tmp36818
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36819_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36677 __tmp36818 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36677 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36677 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36677 '() '21 '#f '#f))
        __obj36677))))
