prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/core

(begin
  (declare-type
   gerbil-ascent/core/expression-plan#gerbil-ascent-compile-frame-call
   (@lambda 2
            #f
            signature:
            (return:
             procedure::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/expression-plan)))
  (declare-type
   gerbil-ascent/core/expression-plan#gerbil-ascent-compile-frame-sequence
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/expression-plan)))
  (declare-type
   gerbil-ascent/core/expression-plan#gerbil-ascent-compile-input-guard
   (@lambda 1
            #f
            signature:
            (return:
             procedure::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/core/expression-plan))))
