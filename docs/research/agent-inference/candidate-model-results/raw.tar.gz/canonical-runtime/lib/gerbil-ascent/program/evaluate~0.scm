(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/evaluate::timestamp 1791689704)
  (begin
    (define gerbil-ascent/program/evaluate#Session.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentSessionContract
         'proto)))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine__%
      (lambda (_%previous19661%_
               _%candidate19662%_
               _%completed19663%_
               _%analysis19664%_
               _%schema19665%_
               _%measure-rule-times?19666%_
               _%source-cut19667%_
               _%publication19668%_)
        (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__5
         _%candidate19662%_
         '#t
         _%analysis19664%_
         _%schema19665%_
         _%measure-rule-times?19666%_
         '#f
         (let ()
           (declare (not safe))
           (gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__%
            _%previous19661%_
            _%candidate19662%_
            _%completed19663%_
            _%analysis19664%_
            _%source-cut19667%_
            _%publication19668%_)))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine__0
      (lambda (_%previous19673%_
               _%candidate19674%_
               _%completed19675%_
               _%analysis19676%_
               _%schema19677%_
               _%measure-rule-times?19678%_)
        (let* ((_%source-cut19680%_ '#f) (_%publication19682%_ '#f))
          (gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine__%
           _%previous19673%_
           _%candidate19674%_
           _%completed19675%_
           _%analysis19676%_
           _%schema19677%_
           _%measure-rule-times?19678%_
           _%source-cut19680%_
           _%publication19682%_))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine__1
      (lambda (_%previous19684%_
               _%candidate19685%_
               _%completed19686%_
               _%analysis19687%_
               _%schema19688%_
               _%measure-rule-times?19689%_
               _%source-cut19690%_)
        (let ((_%publication19692%_ '#f))
          (gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine__%
           _%previous19684%_
           _%candidate19685%_
           _%completed19686%_
           _%analysis19687%_
           _%schema19688%_
           _%measure-rule-times?19689%_
           _%source-cut19690%_
           _%publication19692%_))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine
      (lambda _g37286_
        (let ((_g37287_ (let () (declare (not safe)) (##length _g37286_))))
          (cond ((let () (declare (not safe)) (##fx= _g37287_ 6))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine__0
                        _g37286_))
                ((let () (declare (not safe)) (##fx= _g37287_ 7))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine__1
                        _g37286_))
                ((let () (declare (not safe)) (##fx= _g37287_ 8))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine__%
                        _g37286_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine
                  _g37286_))))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
      (lambda (_%program18577%_
               _%session?18578%_
               _%analysis-override18579%_
               _%schema-override18580%_
               _%measure-rule-times?18581%_
               _%plan-error18582%_
               _%reuse18583%_
               _%workers18584%_
               _%canceled?18585%_)
        (if (or (not _%canceled?18585%_) (procedure? _%canceled?18585%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT cancellation predicate"
                     _%canceled?18585%_)))
        (if (and _%canceled?18585%_
                 (or _%session?18578%_
                     _%reuse18583%_
                     _%measure-rule-times?18581%_))
            (let ()
              (declare (not safe))
              (error '"ASCENT cancellation requires a fresh untimed evaluator"))
            '#!void)
        (if (and (exact-integer? _%workers18584%_)
                 (> _%workers18584%_ '0)
                 (or (= _%workers18584%_ '1)
                     (if _%session?18578%_
                         '#f
                         (if _%reuse18583%_
                             '#f
                             (not _%measure-rule-times?18581%_)))))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT parallel evaluation option"
                     _%workers18584%_)))
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%program18577%_
               'clan/poo/object#object::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT program" _%program18577%_)))
        (let* ((_%relations18599%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%program18577%_ 'relations)))
               (_%rules18601%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%program18577%_ 'rules)))
               (_%input-limit18603%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%program18577%_ 'max-input-facts)))
               (_%derived-limit18605%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%program18577%_ 'max-derived-facts)))
               (_%output-limit18607%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%program18577%_ 'max-output-facts))))
          (if (and (list? _%relations18599%_)
                   (list? _%rules18601%_)
                   (exact-integer? _%input-limit18603%_)
                   (> _%input-limit18603%_ '0)
                   (exact-integer? _%derived-limit18605%_)
                   (> _%derived-limit18605%_ '0)
                   (exact-integer? _%output-limit18607%_)
                   (> _%output-limit18607%_ '0)
                   (boolean? _%measure-rule-times?18581%_))
              '#!void
              (let ()
                (declare (not safe))
                (error '"invalid ASCENT program bounds")))
          (let* ((_%count18610%_ (length _%relations18599%_))
                 (_%schema18615%_
                  (let ((_%$e18612%_ _%schema-override18580%_))
                    (if _%$e18612%_
                        _%$e18612%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/program/analysis#gerbil-ascent-program-schema
                           _%program18577%_
                           _%relations18599%_)))))
                 (_%names18617%_ (vector-ref _%schema18615%_ '1))
                 (_%arity18619%_ (vector-ref _%schema18615%_ '2))
                 (_%field-checkers18621%_ (vector-ref _%schema18615%_ '3))
                 (_%positions18623%_ (vector-ref _%schema18615%_ '4))
                 (_%all18625%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18610%_ '())))
                 (_%delta18627%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18610%_ '())))
                 (_%all-version18629%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18610%_ '0)))
                 (_%delta-version18631%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18610%_ '0)))
                 (_%all-size18633%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18610%_ '0)))
                 (_%delta-size18635%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18610%_ '0)))
                 (_%index-providers18637%_ (vector-ref _%schema18615%_ '5))
                 (_%indexes18639%_
                  (let ((__tmp37288 (pair? _%rules18601%_)))
                    (declare (not safe))
                    (gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__%
                     _%all18625%_
                     _%delta18627%_
                     _%all-size18633%_
                     _%delta-size18635%_
                     _%all-version18629%_
                     _%delta-version18631%_
                     _%index-providers18637%_
                     __tmp37288)))
                 (_%storage-extensions18641%_ (vector-ref _%schema18615%_ '6))
                 (_%storage-states18643%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18610%_ '#f)))
                 (_%seen18645%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18610%_ '#f)))
                 (_%lattice-joins18647%_ (vector-ref _%schema18615%_ '7))
                 (_%kinds18649%_ (vector-ref _%schema18615%_ '8))
                 (_%storage-providers18651%_ (vector-ref _%schema18615%_ '9))
                 (_%lattice-rows18653%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18610%_ '#f)))
                 (_%view-generation18655%_
                  (let () (declare (not safe)) (##gensym 'ascent-source)))
                 (_%view-journals18657%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18610%_ '())))
                 (_%view-routing18659%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18610%_ '#f)))
                 (_%source-count18661%_ '0)
                 (_%source-materialized-count18663%_ '0)
                 (_%derived-count18665%_ '0)
                 (_%publication-failed?18667%_ '#f))
            (letrec* ((_%position-of18670%_
                       (if (= _%count18610%_ '1)
                           (lambda (_%name19543%_)
                             (if (eq? _%name19543%_
                                      (vector-ref _%names18617%_ '0))
                                 '0
                                 (let ()
                                   (declare (not safe))
                                   (error '"unknown ASCENT relation"
                                          _%name19543%_))))
                           (lambda (_%name19545%_)
                             (let ((_%slot19547%_
                                    (let ()
                                      (declare (not safe))
                                      (hash-get
                                       _%positions18623%_
                                       _%name19545%_))))
                               (if _%slot19547%_
                                   '#!void
                                   (let ()
                                     (declare (not safe))
                                     (error '"unknown ASCENT relation"
                                            _%name19545%_)))
                               (- _%slot19547%_ '1)))))
                      (_%indexed-rows18671%_
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%indexes18639%_
                          '1
                          '#f
                          '#f)))
                      (_%callback-rows18672%_
                       (lambda (_%atom19538%_
                                _%environment19539%_
                                _%use-delta?19540%_
                                _%slot-terms19541%_)
                         (_%indexed-rows18671%_
                          _%atom19538%_
                          _%environment19539%_
                          _%use-delta?19540%_
                          _%slot-terms19541%_
                          '#t)))
                      (_%view-relation?18673%_
                       (lambda (_%index19536%_)
                         (let ((__tmp37290
                                (vector-ref
                                 _%storage-providers18651%_
                                 _%index19536%_))
                               (__tmp37289
                                (vector-ref
                                 _%index-providers18637%_
                                 _%index19536%_)))
                           (declare (not safe))
                           (gerbil-ascent/program/view-state#gerbil-ascent-view-relation?
                            __tmp37290
                            __tmp37289))))
                      (_%commit-view!18674%_
                       (lambda (_%index19533%_ _%frontier19534%_)
                         (let ((__tmp37295
                                (vector-ref
                                 _%storage-states18643%_
                                 _%index19533%_))
                               (__tmp37294
                                (vector-ref _%names18617%_ _%index19533%_))
                               (__tmp37293
                                (cons _%view-generation18655%_
                                      _%source-count18661%_))
                               (__tmp37292
                                (vector-ref
                                 _%view-journals18657%_
                                 _%index19533%_))
                               (__tmp37291
                                (vector-ref
                                 _%view-routing18659%_
                                 _%index19533%_)))
                           (declare (not safe))
                           (gerbil-ascent/program/view-state#gerbil-ascent-commit-view!__%
                            _%index19533%_
                            __tmp37295
                            _%frontier19534%_
                            _%all18625%_
                            _%delta18627%_
                            _%all-size18633%_
                            _%delta-size18635%_
                            _%all-version18629%_
                            _%delta-version18631%_
                            __tmp37294
                            __tmp37293
                            __tmp37292
                            __tmp37291))))
                      (_%advance-all-indexes!18675%_
                       (let* ((_%advance!19511%_
                               (let ()
                                 (declare (not safe))
                                 (##unchecked-structure-ref
                                  _%indexes18639%_
                                  '2
                                  '#f
                                  '#f)))
                              (_%$%opt-lambda1951219521%_
                               (lambda (_%index19514%_
                                        _%rows19515%_
                                        _%reverse-order?19516%_)
                                 (let ((__tmp37297
                                        (lambda (_%failure19518%_)
                                          (set! _%publication-failed?18667%_
                                                '#t)
                                          (let ()
                                            (declare (not safe))
                                            (raise _%failure19518%_))))
                                       (__tmp37296
                                        (lambda ()
                                          (_%advance!19511%_
                                           _%index19514%_
                                           _%rows19515%_
                                           _%reverse-order?19516%_))))
                                   (declare (not safe))
                                   (__with-catch __tmp37297 __tmp37296)))))
                         (lambda _g37298_
                           (let ((_g37299_
                                  (let ()
                                    (declare (not safe))
                                    (##length _g37298_))))
                             (cond ((let ()
                                      (declare (not safe))
                                      (##fx= _g37299_ 2))
                                    (apply (lambda (_%index19524%_
                                                    _%rows19525%_)
                                             (let ((_%reverse-order?19527%_
                                                    '#f))
                                               (_%$%opt-lambda1951219521%_
                                                _%index19524%_
                                                _%rows19525%_
                                                _%reverse-order?19527%_)))
                                           _g37298_))
                                   ((let ()
                                      (declare (not safe))
                                      (##fx= _g37299_ 3))
                                    (apply _%$%opt-lambda1951219521%_
                                           _g37298_))
                                   (else
                                    (##raise-wrong-number-of-arguments-exception
                                     'case-lambda-dispatch
                                     _g37298_)))))))
                      (_g37300_
                       (let ((_g37301_
                              (let ((__tmp37304
                                     (lambda ()
                                       (let ((__tmp37305
                                              (let ()
                                                (declare (not safe))
                                                (##structure
                                                 gerbil-ascent/program/initialization#initial-source-state::t
                                                 _%all18625%_
                                                 _%delta18627%_
                                                 _%all-size18633%_
                                                 _%delta-size18635%_
                                                 _%storage-states18643%_
                                                 _%seen18645%_
                                                 _%lattice-rows18653%_))))
                                         (declare (not safe))
                                         (gerbil-ascent/program/initialization#gerbil-ascent-initialize-sources!
                                          _%relations18599%_
                                          _%schema18615%_
                                          __tmp37305
                                          _%input-limit18603%_
                                          _%output-limit18607%_))))
                                    (__tmp37303
                                     (lambda (_%inputs18678%_
                                              _%materialized18679%_)
                                       (set! _%source-count18661%_
                                             _%inputs18678%_)
                                       (set! _%source-materialized-count18663%_
                                             _%materialized18679%_))))
                                (declare (not safe))
                                (##call-with-values __tmp37304 __tmp37303))))
                         #!void
                         _g37301_))
                      (_%view-state18680%_
                       (let ((__tmp37306
                              (cons _%view-generation18655%_
                                    _%source-count18661%_)))
                         (declare (not safe))
                         (##structure
                          gerbil-ascent/program/view-state#view-routing-state::t
                          _%storage-states18643%_
                          _%all18625%_
                          _%delta18627%_
                          _%all-version18629%_
                          _%names18617%_
                          __tmp37306
                          _%view-journals18657%_
                          _%view-routing18659%_))))
              (begin
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/program/view-state#gerbil-ascent-initialize-view-cuts!
                   _%relations18599%_
                   _%view-relation?18673%_
                   _%view-state18680%_))
                (if _%reuse18583%_
                    (set! _%derived-count18665%_
                          (let ((__tmp37307
                                 (let ()
                                   (declare (not safe))
                                   (##structure
                                    gerbil-ascent/program/reuse#closure-seed-state::t
                                    _%all18625%_
                                    _%seen18645%_
                                    _%delta18627%_
                                    _%all-size18633%_
                                    _%delta-size18635%_
                                    _%lattice-rows18653%_))))
                            (declare (not safe))
                            (gerbil-ascent/program/reuse#gerbil-ascent-seed-native-reuse!
                             _%reuse18583%_
                             _%schema18615%_
                             __tmp37307
                             _%source-materialized-count18663%_
                             _%derived-limit18605%_
                             _%output-limit18607%_)))
                    '#!void)
                (let* ((_%storage-owners18682%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/table/storage#gerbil-ascent-storage-owned-states
                           _%storage-states18643%_)))
                       (_%analysis18688%_
                        (let ((_%$e18684%_ _%analysis-override18579%_))
                          (if _%$e18684%_
                              _%$e18684%_
                              (let ((__tmp37308
                                     (lambda ()
                                       (let ()
                                         (declare (not safe))
                                         (gerbil-ascent/program/planning#gerbil-ascent-prepare-program
                                          _%relations18599%_
                                          _%rules18601%_
                                          _%schema18615%_
                                          _%plan-error18582%_)))))
                                (declare (not safe))
                                (gerbil-ascent/program/analysis#gerbil-ascent-program-analysis
                                 _%program18577%_
                                 _%relations18599%_
                                 _%rules18601%_
                                 __tmp37308)))))
                       (_%rule-plans18690%_ (vector-ref _%analysis18688%_ '2))
                       (_%_index-layout18692%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/program/index#row-indexes-plan-rules!
                           _%indexes18639%_
                           _%rule-plans18690%_)))
                       (_%rule-ticks18694%_
                        (if _%measure-rule-times?18581%_
                            (let ((__tmp37309 (length _%rules18601%_)))
                              (declare (not safe))
                              (##make-vector __tmp37309 '0))
                            '#f))
                       (_%strata18696%_ (vector-ref _%analysis18688%_ '3))
                       (_%all-active18698%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/program/reuse#gerbil-ascent-activate-rules
                           _%analysis18688%_)))
                       (_%ordered-execution?18700%_
                        (not (let ((__tmp37310
                                    (let ((__tmp37311
                                           (let ()
                                             (declare (not safe))
                                             (##vector->list
                                              _%all-active18698%_))))
                                      (declare (not safe))
                                      (##apply append __tmp37311))))
                               (declare (not safe))
                               (gerbil-ascent/program/actor-round#gerbil-ascent-actor-round-eligible?
                                __tmp37310
                                _%storage-providers18651%_
                                _%index-providers18637%_
                                _%lattice-joins18647%_
                                _%field-checkers18621%_))))
                       (_%_routed-sources18702%_
                        (if _%ordered-execution?18700%_
                            '#!void
                            (let ()
                              (declare (not safe))
                              (gerbil-ascent/program/view-state#gerbil-ascent-route-view-sources!
                               _%rule-plans18690%_
                               _%view-relation?18673%_
                               _%view-state18680%_))))
                       (_%active-by-stratum18704%_
                        (if _%reuse18583%_
                            (let ((__tmp37312
                                   (##structure-ref
                                    _%reuse18583%_
                                    '2
                                    gerbil-ascent/program/reuse#native-reuse::t
                                    '#f)))
                              (declare (not safe))
                              (gerbil-ascent/program/reuse#gerbil-ascent-activate-selected-rules
                               _%analysis18688%_
                               __tmp37312))
                            _%all-active18698%_))
                       (_%highest-stratum18706%_
                        (- (vector-length _%active-by-stratum18704%_) '1))
                       (_%lattice-feeds-relation?18708%_
                        (if _%session?18578%_
                            (let ()
                              (declare (not safe))
                              (gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-feeds-relation?
                               _%rule-plans18690%_
                               _%kinds18649%_))
                            '#f))
                       (_%positive-rules?18714%_
                        (if _%session?18578%_
                            (let ((__tmp37313
                                   (lambda (_%rule18710%_)
                                     (let ((__tmp37315
                                            (lambda (_%clause18712%_)
                                              (eq? (vector-ref
                                                    _%clause18712%_
                                                    '0)
                                                   'atom)))
                                           (__tmp37314
                                            (vector-ref _%rule18710%_ '1)))
                                       (declare (not safe))
                                       (andmap__0 __tmp37315 __tmp37314)))))
                              (declare (not safe))
                              (andmap__0 __tmp37313 _%rule-plans18690%_))
                            '#f))
                       (_%single-set-source?18716%_
                        (if _%positive-rules?18714%_
                            (if (= _%count18610%_ '1)
                                (if (vector-ref _%lattice-joins18647%_ '0)
                                    '#f
                                    (let ((__tmp37316
                                           (vector-ref
                                            _%storage-providers18651%_
                                            '0)))
                                      (declare (not safe))
                                      (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                                       __tmp37316)))
                                '#f)
                            '#f))
                       (_%source-state18718%_
                        (if _%session?18578%_
                            (let ()
                              (declare (not safe))
                              (gerbil-ascent/program/source-state#gerbil-ascent-source-state
                               _%program18577%_
                               _%relations18599%_))
                            '#f))
                       (_%source-originals18720%_
                        (if _%session?18578%_
                            (##direct-structure-ref
                             _%source-state18718%_
                             '1
                             gerbil-ascent/program/source-state#source-state::t
                             '#f)
                            '#f))
                       (_%source-additions18722%_
                        (if _%session?18578%_
                            (##direct-structure-ref
                             _%source-state18718%_
                             '2
                             gerbil-ascent/program/source-state#source-state::t
                             '#f)
                            '#f))
                       (_%staged-set-counts18724%_
                        (if _%session?18578%_
                            (let ()
                              (declare (not safe))
                              (##make-vector _%count18610%_ '0))
                            '#f))
                       (_%staged-total18726%_ '0)
                       (_%source-overrides18728%_
                        (if _%session?18578%_
                            (##direct-structure-ref
                             _%source-state18718%_
                             '3
                             gerbil-ascent/program/source-state#source-state::t
                             '#f)
                            '#f))
                       (_%recompute-from-source?18730%_ '#f)
                       (_%resume-stratum18732%_ '#f)
                       (_%resume-round18734%_ '0)
                       (_%materialized-dirty?18736%_ '#f)
                       (_%first-run?18738%_ '#t)
                       (_%dirty?18740%_ '#t)
                       (_%last-result18742%_ '#f)
                       (_%owned-publication18744%_ '#f))
                  (letrec* ((_%flush-staged-set-rows!18747%_
                             (lambda ()
                               (if _%session?18578%_
                                   (let ((_%accepted-any?19487%_ '#f))
                                     (let _%flush19489%_ ((_%index19491%_ '0))
                                       (if (< _%index19491%_ _%count18610%_)
                                           (begin
                                             (let ((_%staged-count19493%_
                                                    (vector-ref
                                                     _%staged-set-counts18724%_
                                                     _%index19491%_)))
                                               (if (> _%staged-count19493%_ '0)
                                                   (begin
                                                     (let ((_g37317_
                                                            (let ((__tmp37321
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (vector-ref
                            _%source-additions18722%_
                            _%index19491%_))
                          (__tmp37320
                           (vector-ref _%seen18645%_ _%index19491%_))
                          (__tmp37319
                           (if (null? (vector-ref _%all18625%_ _%index19491%_))
                               (null? (vector-ref
                                       _%source-originals18720%_
                                       _%index19491%_))
                               '#f)))
                      (declare (not safe))
                      (gerbil-ascent/table/storage#gerbil-ascent-set-batch-admit!
                       __tmp37321
                       _%staged-count19493%_
                       __tmp37320
                       __tmp37319))))
               (begin
                 (let ((_g37318_
                        (let ()
                          (declare (not safe))
                          (if (##values? _g37317_)
                              (##values-length _g37317_)
                              1))))
                   (if (not (let () (declare (not safe)) (##fx= _g37318_ 2)))
                       (error "Context expects 2 values" _g37318_)))
                 (let ((_%accepted19495%_
                        (let ()
                          (declare (not safe))
                          (##values-ref _g37317_ 0)))
                       (_%present19496%_
                        (let ()
                          (declare (not safe))
                          (##values-ref _g37317_ 1))))
                   (begin
                     (vector-set!
                      _%seen18645%_
                      _%index19491%_
                      _%present19496%_)
                     (if (pair? _%accepted19495%_)
                         (begin
                           (set! _%accepted-any?19487%_ '#t)
                           (set! _%materialized-dirty?18736%_ '#t)
                           (let* ((_%new-count19498%_
                                   (let ()
                                     (declare (not safe))
                                     (##length _%accepted19495%_)))
                                  (_%old-all19500%_
                                   (vector-ref _%all18625%_ _%index19491%_))
                                  (_%old-delta19502%_
                                   (vector-ref _%delta18627%_ _%index19491%_))
                                  (_%shared-tail?19504%_
                                   (eq? _%old-all19500%_ _%old-delta19502%_))
                                  (_%new-delta19506%_
                                   (if _%shared-tail?19504%_
                                       '#f
                                       (append _%accepted19495%_
                                               _%old-delta19502%_))))
                             (let ()
                               (declare (not safe))
                               (_%advance-all-indexes!18675%_
                                _%index19491%_
                                _%accepted19495%_
                                '#t))
                             (let ((_%new-all19509%_
                                    (append! _%accepted19495%_
                                             _%old-all19500%_)))
                               (vector-set!
                                _%all18625%_
                                _%index19491%_
                                _%new-all19509%_)
                               (vector-set!
                                _%delta18627%_
                                _%index19491%_
                                (if _%shared-tail?19504%_
                                    _%new-all19509%_
                                    _%new-delta19506%_)))
                             (set! _%source-materialized-count18663%_
                                   (+ _%source-materialized-count18663%_
                                      _%new-count19498%_))
                             (vector-set!
                              _%all-size18633%_
                              _%index19491%_
                              (+ (vector-ref _%all-size18633%_ _%index19491%_)
                                 _%new-count19498%_))
                             (vector-set!
                              _%delta-size18635%_
                              _%index19491%_
                              (+ (vector-ref
                                  _%delta-size18635%_
                                  _%index19491%_)
                                 _%new-count19498%_))
                             (vector-set!
                              _%all-version18629%_
                              _%index19491%_
                              (+ '1
                                 (vector-ref
                                  _%all-version18629%_
                                  _%index19491%_)))
                             (vector-set!
                              _%delta-version18631%_
                              _%index19491%_
                              (+ '1
                                 (vector-ref
                                  _%delta-version18631%_
                                  _%index19491%_)))))
                         '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (vector-set!
                                                      _%staged-set-counts18724%_
                                                      _%index19491%_
                                                      '0))
                                                   '#!void))
                                             (_%flush19489%_
                                              (+ _%index19491%_ '1)))
                                           '#!void))
                                     (set! _%staged-total18726%_ '0)
                                     (if (if _%first-run?18738%_
                                             '#f
                                             (if _%materialized-dirty?18736%_
                                                 '#f
                                                 (not _%accepted-any?19487%_)))
                                         (set! _%dirty?18740%_ '#f)
                                         '#!void))
                                   '#!void)))
                            (_%run-retained!__3728137282%_
                             (lambda (_%deadline19064%_)
                               (let ()
                                 (declare (not safe))
                                 (##for-each
                                  gerbil-ascent/table/storage#gerbil-ascent-storage-check-state!
                                  _%storage-owners18682%_))
                               (if _%publication-failed?18667%_
                                   (let ()
                                     (declare (not safe))
                                     (error '"ASCENT engine publication requires source replay"))
                                   '#!void)
                               (if _%dirty?18740%_
                                   (_%flush-staged-set-rows!18747%_)
                                   '#!void)
                               (let ((_%complete?19066%_ '#t))
                                 (if _%dirty?18740%_
                                     (begin
                                       (if _%active-by-stratum18704%_
                                           '#!void
                                           (set! _%active-by-stratum18704%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gerbil-ascent/program/reuse#gerbil-ascent-activate-rules
                                                    _%analysis18688%_))))
                                       (let ((_%pending19068%_
                                              (let ()
                                                (declare (not safe))
                                                (##make-vector
                                                 _%count18610%_
                                                 '())))
                                             (_%pending-seen19069%_
                                              (let ()
                                                (declare (not safe))
                                                (##make-vector
                                                 _%count18610%_
                                                 '#f)))
                                             (_%pending-injections19070%_
                                              (let ()
                                                (declare (not safe))
                                                (##make-vector
                                                 _%count18610%_
                                                 '())))
                                             (_%pending-lattices19071%_
                                              (let ()
                                                (declare (not safe))
                                                (##make-vector
                                                 _%count18610%_
                                                 '#f)))
                                             (_%pending-count19072%_ '0)
                                             (_%component-mode?19073%_
                                              (let ()
                                                (declare (not safe))
                                                (gerbil-ascent/program/component-plan#gerbil-ascent-component-mode?
                                                 _%session?18578%_
                                                 _%workers18584%_
                                                 _%canceled?18585%_
                                                 _%analysis18688%_
                                                 _%schema18615%_))))
                                         (letrec ((_%admit-stored!19075%_
                                                   (lambda (_%index19451%_
                                                            _%pending-table19452%_
                                                            _%stored19453%_)
                                                     (if (and (list? _%stored19453%_)
                                                              (= (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (declare (not safe))
                           (##length _%stored19453%_))
                         (vector-ref _%arity18619%_ _%index19451%_)))
                 '#!void
                 (let ()
                   (declare (not safe))
                   (error '"invalid ASCENT storage provider row"
                          _%stored19453%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (let ((_%check19455%_
                                                            (vector-ref
                                                             _%field-checkers18621%_
                                                             _%index19451%_)))
                                                       (if _%check19455%_
                                                           (_%check19455%_
                                                            _%stored19453%_)
                                                           '#!void))
                                                     (if (or (let ((__tmp37322
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (vector-ref _%seen18645%_ _%index19451%_)))
                       (declare (not safe))
                       (hash-get __tmp37322 _%stored19453%_))
                     (let ()
                       (declare (not safe))
                       (hash-get _%pending-table19452%_ _%stored19453%_)))
                 '#!void
                 (begin
                   (let ()
                     (declare (not safe))
                     (hash-put! _%pending-table19452%_ _%stored19453%_ '#t))
                   (set! _%pending-count19072%_ (+ _%pending-count19072%_ '1))
                   (vector-set!
                    _%pending19068%_
                    _%index19451%_
                    (cons _%stored19453%_
                          (vector-ref _%pending19068%_ _%index19451%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%emit-row!19076%_
                                                   (lambda (_%atom19357%_
                                                            _%row19358%_)
                                                     (let* ((_%index19360%_
                                                             (vector-ref
                                                              _%atom19357%_
                                                              '0))
                                                            (_%pending-table19367%_
                                                             (if (vector-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          _%lattice-joins18647%_
                          _%index19360%_)
                         '#f
                         (let ((_%$e19362%_
                                (vector-ref
                                 _%pending-seen19069%_
                                 _%index19360%_)))
                           (if _%$e19362%_
                               _%$e19362%_
                               (let ((_%fresh19365%_
                                      (let ()
                                        (declare (not safe))
                                        (make-hash-table__%
                                         '#f
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value))))
                                 (vector-set!
                                  _%pending-seen19069%_
                                  _%index19360%_
                                  _%fresh19365%_)
                                 _%fresh19365%_))))))
               (let ((_%check19370%_
                      (vector-ref _%field-checkers18621%_ _%index19360%_)))
                 (if _%check19370%_ (_%check19370%_ _%row19358%_) '#!void))
               (if (_%view-relation?18673%_ _%index19360%_)
                   (let ((_%frontier19373%_
                          (let ((__tmp37325
                                 (vector-ref
                                  _%storage-states18643%_
                                  _%index19360%_))
                                (__tmp37324
                                 (- _%output-limit18607%_
                                    (+ _%source-materialized-count18663%_
                                       _%derived-count18665%_
                                       _%pending-count19072%_)))
                                (__tmp37323
                                 (vector-ref
                                  _%field-checkers18621%_
                                  _%index19360%_)))
                            (declare (not safe))
                            (gerbil-ascent/program/view-state#gerbil-ascent-stage-view!
                             __tmp37325
                             _%row19358%_
                             __tmp37324
                             __tmp37323))))
                     (if (> (let ()
                              (declare (not safe))
                              (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                               _%frontier19373%_))
                            '0)
                         (vector-set!
                          _%pending-injections19070%_
                          _%index19360%_
                          (cons (map values _%row19358%_)
                                (vector-ref
                                 _%pending-injections19070%_
                                 _%index19360%_)))
                         '#!void)
                     (set! _%pending-count19072%_
                           (+ _%pending-count19072%_
                              (let ()
                                (declare (not safe))
                                (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                                 _%frontier19373%_))))
                     (vector-set!
                      _%pending19068%_
                      _%index19360%_
                      (let ((__tmp37326
                             (vector-ref _%pending19068%_ _%index19360%_)))
                        (declare (not safe))
                        (gerbil-ascent/program/view-state#gerbil-ascent-add-frontier
                         __tmp37326
                         _%frontier19373%_))))
                   (if (vector-ref _%lattice-joins18647%_ _%index19360%_)
                       (let* ((_%frontier19381%_
                               (let ((_%$e19376%_
                                      (vector-ref
                                       _%pending-lattices19071%_
                                       _%index19360%_)))
                                 (if _%$e19376%_
                                     _%$e19376%_
                                     (let ((_%fresh19379%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/program/lattice-frontier#make-lattice-frontier))))
                                       (vector-set!
                                        _%pending-lattices19071%_
                                        _%index19360%_
                                        _%fresh19379%_)
                                       _%fresh19379%_))))
                              (_%key19383%_
                               (let ()
                                 (declare (not safe))
                                 (gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-key
                                  _%row19358%_)))
                              (_%staged19409%_
                               (let* ((_%frontier19385%_ _%frontier19381%_)
                                      (_%key19388%_ _%key19383%_)
                                      (_%frontier19392%_ _%frontier19385%_))
                                 (declare (not safe))
                                 (gerbil-ascent/program/lattice-frontier#__lattice-frontier-ref
                                  _%frontier19392%_
                                  _%key19388%_)))
                              (_%prior19414%_
                               (let ((_%$e19411%_ _%staged19409%_))
                                 (if _%$e19411%_
                                     _%$e19411%_
                                     (let ((__tmp37327
                                            (vector-ref
                                             _%lattice-rows18653%_
                                             _%index19360%_)))
                                       (declare (not safe))
                                       (hash-get __tmp37327 _%key19383%_)))))
                              (_%merged19416%_
                               (if _%prior19414%_
                                   (let ((__tmp37328
                                          ((vector-ref
                                            _%lattice-joins18647%_
                                            _%index19360%_)
                                           (last _%prior19414%_)
                                           (last _%row19358%_))))
                                     (declare (not safe))
                                     (gerbil-ascent/core/rule-semantics#gerbil-ascent-joined-row
                                      _%key19383%_
                                      __tmp37328))
                                   _%row19358%_)))
                         (let ((_%check19419%_
                                (vector-ref
                                 _%field-checkers18621%_
                                 _%index19360%_)))
                           (if _%check19419%_
                               (_%check19419%_ _%merged19416%_)
                               '#!void))
                         (if (and _%prior19414%_
                                  (equal? _%merged19416%_ _%prior19414%_))
                             '#!void
                             (if (let* ((_%frontier19421%_ _%frontier19381%_)
                                        (_%key19424%_ _%key19383%_)
                                        (_%row19427%_ _%merged19416%_)
                                        (_%frontier19431%_ _%frontier19421%_))
                                   (declare (not safe))
                                   (gerbil-ascent/program/lattice-frontier#__lattice-frontier-stage!
                                    _%frontier19431%_
                                    _%key19424%_
                                    _%row19427%_))
                                 (set! _%pending-count19072%_
                                       (+ _%pending-count19072%_ '1))
                                 '#!void)))
                       (if (let ((__tmp37329
                                  (vector-ref
                                   _%storage-providers18651%_
                                   _%index19360%_)))
                             (declare (not safe))
                             (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                              __tmp37329))
                           (_%admit-stored!19075%_
                            _%index19360%_
                            _%pending-table19367%_
                            _%row19358%_)
                           (let ((_%expanded19447%_
                                  ((vector-ref
                                    _%storage-extensions18641%_
                                    _%index19360%_)
                                   (vector-ref
                                    _%storage-states18643%_
                                    _%index19360%_)
                                   (vector-ref _%all18625%_ _%index19360%_)
                                   (vector-ref _%pending19068%_ _%index19360%_)
                                   _%row19358%_
                                   (- _%output-limit18607%_
                                      (+ _%source-materialized-count18663%_
                                         _%derived-count18665%_
                                         _%pending-count19072%_)))))
                             (if (list? _%expanded19447%_)
                                 '#!void
                                 (let ()
                                   (declare (not safe))
                                   (error '"ASCENT storage provider returned non-list rows")))
                             (for-each
                              (lambda (_%stored19449%_)
                                (_%admit-stored!19075%_
                                 _%index19360%_
                                 _%pending-table19367%_
                                 _%stored19449%_))
                              _%expanded19447%_)))))
               (if (> (+ _%derived-count18665%_ _%pending-count19072%_)
                      _%derived-limit18605%_)
                   (let ()
                     (declare (not safe))
                     (error '"ASCENT derived fact budget exceeded"))
                   '#!void)
               (if (> (+ _%source-materialized-count18663%_
                         _%derived-count18665%_
                         _%pending-count19072%_)
                      _%output-limit18607%_)
                   (let ()
                     (declare (not safe))
                     (error '"ASCENT output fact budget exceeded"))
                   '#!void))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%visit-body19077%_
                                                   (lambda (_%body19253%_
                                                            _%delta-at19254%_
                                                            _%depth19255%_
                                                            _%environment19256%_
                                                            _%consume19257%_)
                                                     (if (null? _%body19253%_)
                                                         (_%consume19257%_
                                                          _%environment19256%_)
                                                         (let ((_%clause19259%_
                                                                (car _%body19253%_)))
                                                           (if (eq? (vector-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             _%clause19259%_
                             '0)
                            'atom)
                       (let* ((_%atom19262%_ (vector-ref _%clause19259%_ '1))
                              (_%rows19264%_
                               (_%callback-rows18672%_
                                _%atom19262%_
                                _%environment19256%_
                                (= _%depth19255%_ _%delta-at19254%_)
                                '#f))
                              (__tmp37330
                               (lambda (_%row19267%_)
                                 (let ((_%bound19269%_
                                        (let ((__tmp37331
                                               (vector-ref _%atom19262%_ '3)))
                                          (declare (not safe))
                                          (gerbil-ascent/core/rule-bindings#gerbil-ascent-bind-row
                                           __tmp37331
                                           _%row19267%_
                                           _%environment19256%_))))
                                   (if _%bound19269%_
                                       (_%visit-body19077%_
                                        (cdr _%body19253%_)
                                        _%delta-at19254%_
                                        (+ _%depth19255%_ '1)
                                        _%bound19269%_
                                        _%consume19257%_)
                                       '#!void)))))
                         (declare (not safe))
                         (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
                          __tmp37330
                          _%rows19264%_))
                       (if (eq? (vector-ref _%clause19259%_ '0) 'negation)
                           (let* ((_%atom19272%_
                                   (vector-ref _%clause19259%_ '1))
                                  (_%rows19274%_
                                   (_%callback-rows18672%_
                                    _%atom19272%_
                                    _%environment19256%_
                                    '#f
                                    '#f)))
                             (if (let ((__tmp37332
                                        (lambda (_%row19277%_)
                                          (let ((__tmp37333
                                                 (vector-ref
                                                  _%atom19272%_
                                                  '3)))
                                            (declare (not safe))
                                            (gerbil-ascent/core/rule-bindings#gerbil-ascent-bind-row
                                             __tmp37333
                                             _%row19277%_
                                             _%environment19256%_)))))
                                   (declare (not safe))
                                   (gerbil-ascent/core/relation-view#gerbil-ascent-any-row?
                                    __tmp37332
                                    _%rows19274%_))
                                 '#!void
                                 (_%visit-body19077%_
                                  (cdr _%body19253%_)
                                  _%delta-at19254%_
                                  _%depth19255%_
                                  _%environment19256%_
                                  _%consume19257%_)))
                           (if (eq? (vector-ref _%clause19259%_ '0) 'aggregate)
                               (let* ((_%atom19280%_
                                       (vector-ref _%clause19259%_ '1))
                                      (_%rows19282%_
                                       (_%callback-rows18672%_
                                        _%atom19280%_
                                        _%environment19256%_
                                        '#f
                                        '#f))
                                      (_%variables19284%_
                                       (vector-ref _%clause19259%_ '3))
                                      (_%tuples19286%_ '()))
                                 (let ((__tmp37334
                                        (lambda (_%row19289%_)
                                          (let ((_%bound19291%_
                                                 (let ((__tmp37335
                                                        (vector-ref
                                                         _%atom19280%_
                                                         '3)))
                                                   (declare (not safe))
                                                   (gerbil-ascent/core/rule-bindings#gerbil-ascent-bind-row
                                                    __tmp37335
                                                    _%row19289%_
                                                    _%environment19256%_))))
                                            (if _%bound19291%_
                                                (set! _%tuples19286%_
                                                      (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gerbil-ascent/core/rule-bindings#gerbil-ascent-binding-values
                                                               _%variables19284%_
                                                               _%bound19291%_
                                                               '"unbound ASCENT clause variable"))
                                                            _%tuples19286%_))
                                                '#!void)))))
                                   (declare (not safe))
                                   (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
                                    __tmp37334
                                    _%rows19282%_))
                                 (let ((_%values19293%_
                                        ((vector-ref _%clause19259%_ '4)
                                         (let ()
                                           (declare (not safe))
                                           (##reverse _%tuples19286%_)))))
                                   (if (list? _%values19293%_)
                                       '#!void
                                       (let ()
                                         (declare (not safe))
                                         (error '"ASCENT aggregator must return a list"
                                                _%values19293%_)))
                                   (for-each
                                    (lambda (_%value19295%_)
                                      (let* ((_%output19297%_
                                              (vector-ref _%clause19259%_ '2))
                                             (_%matcher19299%_
                                              (vector-ref _%clause19259%_ '5))
                                             (_%next-environment19303%_
                                              (if _%matcher19299%_
                                                  (let ((_%matched19301%_
                                                         (_%matcher19299%_
                                                          _%value19295%_)))
                                                    (declare (not safe))
                                                    (gerbil-ascent/core/rule-bindings#gerbil-ascent-extend-pattern
                                                     _%output19297%_
                                                     _%matched19301%_
                                                     _%environment19256%_
                                                     '"ASCENT aggregate pattern returned invalid bindings"))
                                                  (cons (cons _%output19297%_
                                                              _%value19295%_)
                                                        _%environment19256%_))))
                                        (_%visit-body19077%_
                                         (cdr _%body19253%_)
                                         _%delta-at19254%_
                                         _%depth19255%_
                                         _%next-environment19303%_
                                         _%consume19257%_)))
                                    _%values19293%_)))
                               (if (eq? (vector-ref _%clause19259%_ '0) 'guard)
                                   (let ((_%pass?19307%_
                                          (let ((__tmp37337
                                                 (vector-ref
                                                  _%clause19259%_
                                                  '2))
                                                (__tmp37336
                                                 (vector-ref
                                                  _%clause19259%_
                                                  '1)))
                                            (declare (not safe))
                                            (gerbil-ascent/core/rule-bindings#gerbil-ascent-call-with-bindings
                                             __tmp37337
                                             __tmp37336
                                             _%environment19256%_
                                             '"unbound ASCENT clause variable"))))
                                     (if (boolean? _%pass?19307%_)
                                         '#!void
                                         (let ()
                                           (declare (not safe))
                                           (error '"ASCENT guard must return a boolean"
                                                  _%pass?19307%_)))
                                     (if _%pass?19307%_
                                         (_%visit-body19077%_
                                          (cdr _%body19253%_)
                                          _%delta-at19254%_
                                          _%depth19255%_
                                          _%environment19256%_
                                          _%consume19257%_)
                                         '#!void))
                                   (if (eq? (vector-ref _%clause19259%_ '0)
                                            'generator)
                                       (let* ((_%values19310%_
                                               (let ((__tmp37339
                                                      (vector-ref
                                                       _%clause19259%_
                                                       '3))
                                                     (__tmp37338
                                                      (vector-ref
                                                       _%clause19259%_
                                                       '2)))
                                                 (declare (not safe))
                                                 (gerbil-ascent/core/rule-bindings#gerbil-ascent-call-with-bindings
                                                  __tmp37339
                                                  __tmp37338
                                                  _%environment19256%_
                                                  '"unbound ASCENT clause variable")))
                                              (_%$it1931119313%_
                                               (let ()
                                                 (declare (not safe))
                                                 (std/iter/iterators#iter
                                                  _%values19310%_)))
                                              (_%$it1931119315%_
                                               _%$it1931119313%_))
                                         (let _%loop19326%_ ()
                                           (let ((_%next19341%_
                                                  (let ((_%self1148019330%_
                                                         _%$it1931119315%_))
                                                    (declare (not safe))
                                                    (let ((_%object1933319338%_
                                                           (##unchecked-structure-ref
                                                            _%self1148019330%_
                                                            '1
                                                            '#f
                                                            'next!))
                                                          (_%method1933419339%_
                                                           (##unchecked-structure-ref
                                                            _%self1148019330%_
                                                            '2
                                                            '#f
                                                            'next!)))
                                                      (_%method1933419339%_
                                                       _%object1933319338%_)))))
                                             (if (eq? _%next19341%_ '#!eof)
                                                 '#!void
                                                 (begin
                                                   (let* ((_%output19347%_
                                                           (vector-ref
                                                            _%clause19259%_
                                                            '1))
                                                          (_%next-environment19351%_
                                                           (if (list? _%output19347%_)
                                                               (let ((_%row19349%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (if (vector? _%next19341%_)
                                  (let ()
                                    (declare (not safe))
                                    (##vector->list _%next19341%_))
                                  _%next19341%_)))
                         (if (and (list? _%row19349%_)
                                  (= (let ()
                                       (declare (not safe))
                                       (##length _%row19349%_))
                                     (let ()
                                       (declare (not safe))
                                       (##length _%output19347%_))))
                             '#!void
                             (let ()
                               (declare (not safe))
                               (error '"ASCENT generator tuple arity mismatch"
                                      _%next19341%_)))
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/core/rule-bindings#gerbil-ascent-bind-row
                            _%output19347%_
                            _%row19349%_
                            _%environment19256%_)))
                       (cons (cons _%output19347%_ _%next19341%_)
                             _%environment19256%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (_%visit-body19077%_
                                                      (cdr _%body19253%_)
                                                      _%delta-at19254%_
                                                      _%depth19255%_
                                                      _%next-environment19351%_
                                                      _%consume19257%_))
                                                   (_%loop19326%_))))))
                                       (if (eq? (vector-ref _%clause19259%_ '0)
                                                'binding)
                                           (let ((_%value19355%_
                                                  (let ((__tmp37341
                                                         (vector-ref
                                                          _%clause19259%_
                                                          '3))
                                                        (__tmp37340
                                                         (vector-ref
                                                          _%clause19259%_
                                                          '2)))
                                                    (declare (not safe))
                                                    (gerbil-ascent/core/rule-bindings#gerbil-ascent-call-with-bindings
                                                     __tmp37341
                                                     __tmp37340
                                                     _%environment19256%_
                                                     '"unbound ASCENT clause variable"))))
                                             (_%visit-body19077%_
                                              (cdr _%body19253%_)
                                              _%delta-at19254%_
                                              _%depth19255%_
                                              (cons (cons (vector-ref
                                                           _%clause19259%_
                                                           '1)
                                                          _%value19355%_)
                                                    _%environment19256%_)
                                              _%consume19257%_))
                                           '#!void)))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           (let ((__tmp37342
                                                  (lambda (_%return19079%_)
                                                    (let _%evaluate-stratum19081%_ ((_%stratum19083%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                             (let ((_%$e19250%_
                                                    _%resume-stratum18732%_))
                                               (if _%$e19250%_
                                                   _%$e19250%_
                                                   '0))))
              (if (<= _%stratum19083%_ _%highest-stratum18706%_)
                  (let ((_%active-rules19085%_
                         (vector-ref
                          _%active-by-stratum18704%_
                          _%stratum19083%_))
                        (_%active?19086%_ '#t)
                        (_%round19087%_
                         (if _%resume-stratum18732%_
                             _%resume-round18734%_
                             '0)))
                    (if _%resume-stratum18732%_
                        '#!void
                        (let _%reset-delta19089%_ ((_%index19091%_ '0))
                          (if (< _%index19091%_ _%count18610%_)
                              (begin
                                (vector-set!
                                 _%delta18627%_
                                 _%index19091%_
                                 (if (= (vector-ref
                                         _%strata18696%_
                                         _%index19091%_)
                                        _%stratum19083%_)
                                     (if (or _%first-run?18738%_
                                             (> _%stratum19083%_ '0))
                                         (vector-ref
                                          _%all18625%_
                                          _%index19091%_)
                                         (vector-ref
                                          _%delta18627%_
                                          _%index19091%_))
                                     '()))
                                (vector-set!
                                 _%delta-size18635%_
                                 _%index19091%_
                                 (let ((__tmp37343
                                        (vector-ref
                                         _%delta18627%_
                                         _%index19091%_)))
                                   (declare (not safe))
                                   (gerbil-ascent/core/relation-view#gerbil-ascent-row-count
                                    __tmp37343)))
                                (vector-set!
                                 _%delta-version18631%_
                                 _%index19091%_
                                 (+ '1
                                    (vector-ref
                                     _%delta-version18631%_
                                     _%index19091%_)))
                                (_%reset-delta19089%_ (+ _%index19091%_ '1)))
                              '#!void)))
                    (let _%loop19096%_ ()
                      (if _%active?19086%_
                          (begin
                            (set! _%round19087%_ (+ _%round19087%_ '1))
                            (set! _%pending-count19072%_ '0)
                            (if _%component-mode?19073%_
                                (let ((__tmp37344
                                       (let ((_%$e19100%_ _%canceled?18585%_))
                                         (if _%$e19100%_
                                             _%$e19100%_
                                             (lambda () '#f)))))
                                  (declare (not safe))
                                  (gerbil-ascent/program/positive-components#gerbil-ascent-run-positive-components!
                                   _%analysis18688%_
                                   _%schema18615%_
                                   _%all18625%_
                                   _%workers18584%_
                                   _%emit-row!19076%_
                                   __tmp37344))
                                (if (and (or (> _%workers18584%_ '1)
                                             _%canceled?18585%_)
                                         (if _%ordered-execution?18700%_
                                             '#f
                                             (let ()
                                               (declare (not safe))
                                               (gerbil-ascent/program/actor-round#gerbil-ascent-actor-round-eligible?
                                                _%active-rules19085%_
                                                _%storage-providers18651%_
                                                _%index-providers18637%_
                                                _%lattice-joins18647%_
                                                _%field-checkers18621%_))))
                                    (let ((_%frozen-all19107%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-copy _%all18625%_)))
                                          (_%frozen-delta19108%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-copy _%delta18627%_)))
                                          (_%frozen-all-size19109%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-copy
                                              _%all-size18633%_)))
                                          (_%frozen-delta-size19110%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-copy
                                              _%delta-size18635%_)))
                                          (_%frozen-all-version19111%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-copy
                                              _%all-version18629%_)))
                                          (_%frozen-delta-version19112%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-copy
                                              _%delta-version18631%_))))
                                      (let ((__tmp37349
                                             (vector _%program18577%_
                                                     _%stratum19083%_
                                                     _%round19087%_
                                                     _%frozen-all19107%_
                                                     _%frozen-delta19108%_))
                                            (__tmp37346
                                             (lambda (_%rule19114%_
                                                      _%emit!19115%_
                                                      _%checkpoint!19116%_)
                                               (let* ((_%plan19118%_
                                                       (vector-ref
                                                        _%rule19114%_
                                                        '5))
                                                      (_%frame19120%_
                                                       (make-vector
                                                        (vector-ref
                                                         _%plan19118%_
                                                         '2)
                                                        '#f))
                                                      (_%private-indexes19122%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__0
                                                          _%frozen-all19107%_
                                                          _%frozen-delta19108%_
                                                          _%frozen-all-size19109%_
                                                          _%frozen-delta-size19110%_
                                                          _%frozen-all-version19111%_
                                                          _%frozen-delta-version19112%_
                                                          _%index-providers18637%_)))
                                                      (_%_private-layout19124%_
                                                       (let ((__tmp37347
                                                              (vector-ref
                                                               _%plan19118%_
                                                               '1)))
                                                         (declare (not safe))
                                                         (gerbil-ascent/program/index#row-indexes-plan-actions!
                                                          _%private-indexes19122%_
                                                          __tmp37347)))
                                                      (_%rows19126%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##unchecked-structure-ref
                                                          _%private-indexes19122%_
                                                          '1
                                                          '#f
                                                          '#f)))
                                                      (_%pivots19128%_
                                                       (vector-ref
                                                        _%rule19114%_
                                                        '2))
                                                      (_%prunable19130%_
                                                       (vector-ref
                                                        _%rule19114%_
                                                        '4)))
                                                 (letrec ((_%visit!19133%_
                                                           (lambda (_%pivot19140%_)
                                                             (let ((__tmp37348
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%private-indexes19122%_
                               '4
                               '#f
                               '#f))))
                       (declare (not safe))
                       (gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__%
                        _%plan19118%_
                        _%frame19120%_
                        _%pivot19140%_
                        _%rows19126%_
                        _%emit!19115%_
                        _%checkpoint!19116%_
                        __tmp37348)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (if (null? _%pivots19128%_)
                                                       (if (and (= _%round19087%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           '1)
                        _%first-run?18738%_)
                   (_%visit!19133%_ '-1)
                   '#!void)
               (if (and (= _%round19087%_ '1)
                        (or _%first-run?18738%_ (> _%stratum19083%_ '0)))
                   (_%visit!19133%_ '-1)
                   (for-each
                    (lambda (_%pivot19138%_)
                      (if (and (< _%pivot19138%_
                                  (vector-length _%prunable19130%_))
                               (= (vector-ref
                                   _%frozen-delta-size19110%_
                                   (vector-ref
                                    _%prunable19130%_
                                    _%pivot19138%_))
                                  '0))
                          '#!void
                          (_%visit!19133%_ _%pivot19138%_)))
                    _%pivots19128%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp37345
                                             (let ((_%$e19142%_
                                                    _%canceled?18585%_))
                                               (if _%$e19142%_
                                                   _%$e19142%_
                                                   (lambda () '#f)))))
                                        (declare (not safe))
                                        (gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__1
                                         __tmp37349
                                         _%active-rules19085%_
                                         _%workers18584%_
                                         __tmp37346
                                         _%emit-row!19076%_
                                         __tmp37345)))
                                    (begin
                                      (if _%canceled?18585%_
                                          (let ()
                                            (declare (not safe))
                                            (error '"ASCENT cancellation requires pure Set worker rules"))
                                          '#!void)
                                      (for-each
                                       (lambda (_%rule19146%_)
                                         (let ((_%started19148%_
                                                (if _%rule-ticks18694%_
                                                    (current-jiffy)
                                                    '#f))
                                               (_%heads19149%_
                                                (vector-ref _%rule19146%_ '0))
                                               (_%body19150%_
                                                (vector-ref _%rule19146%_ '1))
                                               (_%positions19151%_
                                                (vector-ref _%rule19146%_ '2))
                                               (_%prunable19152%_
                                                (vector-ref _%rule19146%_ '4))
                                               (_%positive-plan19153%_
                                                (vector-ref _%rule19146%_ '5))
                                               (_%frame19154%_
                                                (vector-ref _%rule19146%_ '6)))
                                           (let ((_%rows-access19156%_
                                                  (if _%ordered-execution?18700%_
                                                      _%callback-rows18672%_
                                                      _%indexed-rows18671%_))
                                                 (_%parts-access19157%_
                                                  (if _%ordered-execution?18700%_
                                                      '#f
                                                      (let ()
                                                        (declare (not safe))
                                                        (##unchecked-structure-ref
                                                         _%indexes18639%_
                                                         '4
                                                         '#f
                                                         '#f)))))
                                             (if (null? _%positions19151%_)
                                                 (if (and (= _%round19087%_ '1)
                                                          _%first-run?18738%_)
                                                     (if _%positive-plan19153%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__%
                                                            _%positive-plan19153%_
                                                            _%frame19154%_
                                                            '-1
                                                            _%rows-access19156%_
                                                            _%emit-row!19076%_
                                                            '#f
                                                            _%parts-access19157%_))
                                                         (_%visit-body19077%_
                                                          _%body19150%_
                                                          '-1
                                                          '0
                                                          '()
                                                          (lambda (_%environment19159%_)
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (gerbil-ascent/core/positive-plan#gerbil-ascent-emit-heads!
                                                               _%heads19149%_
                                                               _%environment19159%_
                                                               _%emit-row!19076%_)))))
                                                     '#!void)
                                                 (if (and (= _%round19087%_ '1)
                                                          (or _%first-run?18738%_
                                                              (> _%stratum19083%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '0)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (if _%positive-plan19153%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__%
                                                            _%positive-plan19153%_
                                                            _%frame19154%_
                                                            '-1
                                                            _%rows-access19156%_
                                                            _%emit-row!19076%_
                                                            '#f
                                                            _%parts-access19157%_))
                                                         (_%visit-body19077%_
                                                          _%body19150%_
                                                          '-1
                                                          '0
                                                          '()
                                                          (lambda (_%environment19164%_)
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (gerbil-ascent/core/positive-plan#gerbil-ascent-emit-heads!
                                                               _%heads19149%_
                                                               _%environment19164%_
                                                               _%emit-row!19076%_)))))
                                                     (for-each
                                                      (lambda (_%delta-at19166%_)
                                                        (if (and (< _%delta-at19166%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (vector-length _%prunable19152%_))
                         (= (vector-ref
                             _%delta-size18635%_
                             (vector-ref _%prunable19152%_ _%delta-at19166%_))
                            '0))
                    '#!void
                    (if _%positive-plan19153%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__%
                           _%positive-plan19153%_
                           _%frame19154%_
                           _%delta-at19166%_
                           _%rows-access19156%_
                           _%emit-row!19076%_
                           '#f
                           _%parts-access19157%_))
                        (_%visit-body19077%_
                         _%body19150%_
                         _%delta-at19166%_
                         '0
                         '()
                         (lambda (_%environment19168%_)
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/core/positive-plan#gerbil-ascent-emit-heads!
                              _%heads19149%_
                              _%environment19168%_
                              _%emit-row!19076%_)))))))
              _%positions19151%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           (if _%started19148%_
                                               (let ((_%index19170%_
                                                      (vector-ref
                                                       _%rule19146%_
                                                       '3)))
                                                 (vector-set!
                                                  _%rule-ticks18694%_
                                                  _%index19170%_
                                                  (+ (vector-ref
                                                      _%rule-ticks18694%_
                                                      _%index19170%_)
                                                     (- (current-jiffy)
                                                        _%started19148%_))))
                                               '#!void)))
                                       _%active-rules19085%_))))
                            (set! _%active?19086%_ '#f)
                            (let _%commit19172%_ ((_%index19174%_ '0))
                              (if (< _%index19174%_ _%count18610%_)
                                  (begin
                                    (if (_%view-relation?18673%_
                                         _%index19174%_)
                                        (let ((_%frontier19176%_
                                               (vector-ref
                                                _%pending19068%_
                                                _%index19174%_)))
                                          (if (> (let ()
                                                   (declare (not safe))
                                                   (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                                                    _%frontier19176%_))
                                                 '0)
                                              (begin
                                                (vector-set!
                                                 _%view-journals18657%_
                                                 _%index19174%_
                                                 (cons (let ((__tmp37352
                                                              (reverse (vector-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                _%pending-injections19070%_
                                _%index19174%_)))
                     (__tmp37350
                      (let ((__tmp37351
                             (vector-ref
                              _%storage-states18643%_
                              _%index19174%_)))
                        (declare (not safe))
                        (gerbil-ascent/table/storage#gerbil-ascent-storage-eqrel-state?
                         __tmp37351))))
                 (declare (not safe))
                 (gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event__%
                  'derived
                  __tmp37352
                  __tmp37350))
               (vector-ref _%view-journals18657%_ _%index19174%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (_%commit-view!18674%_
                                                 _%index19174%_
                                                 _%frontier19176%_)
                                                (set! _%derived-count18665%_
                                                      (+ _%derived-count18665%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                                                            _%frontier19176%_))))
                                                (set! _%active?19086%_ '#t))
                                              (begin
                                                (let ((_%total19178%_
                                                       (vector-ref
                                                        _%all18625%_
                                                        _%index19174%_)))
                                                  (vector-set!
                                                   _%delta18627%_
                                                   _%index19174%_
                                                   (let ((__tmp37355
                                                          (##structure-ref
                                                           _%total19178%_
                                                           '1
                                                           gerbil-ascent/core/relation-view#relation-view::t
                                                           '#f))
                                                         (__tmp37354
                                                          (##structure-ref
                                                           _%total19178%_
                                                           '2
                                                           gerbil-ascent/core/relation-view#relation-view::t
                                                           '#f))
                                                         (__tmp37353
                                                          (##structure-ref
                                                           _%total19178%_
                                                           '3
                                                           gerbil-ascent/core/relation-view#relation-view::t
                                                           '#f)))
                                                     (declare (not safe))
                                                     (gerbil-ascent/core/relation-view#gerbil-ascent-view-bind
                                                      gerbil-ascent/program/view-state#gerbil-ascent-empty-view
                                                      __tmp37355
                                                      __tmp37354
                                                      __tmp37353
                                                      'delta))))
                                                (vector-set!
                                                 _%delta-size18635%_
                                                 _%index19174%_
                                                 '0)))
                                          (vector-set!
                                           _%pending19068%_
                                           _%index19174%_
                                           '())
                                          (vector-set!
                                           _%pending-injections19070%_
                                           _%index19174%_
                                           '()))
                                        (begin
                                          (if (vector-ref
                                               _%lattice-joins18647%_
                                               _%index19174%_)
                                              (let* ((_%frontier19180%_
                                                      (vector-ref
                                                       _%pending-lattices19071%_
                                                       _%index19174%_))
                                                     (_%staged-rows19208%_
                                                      (if _%frontier19180%_
                                                          (let* ((_%frontier19182%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          _%frontier19180%_)
                         (_%frontier19186%_ _%frontier19182%_))
                    (declare (not safe))
                    (gerbil-ascent/program/lattice-frontier#__lattice-frontier-rows
                     _%frontier19186%_))
                  '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (vector-set!
                                                 _%pending19068%_
                                                 _%index19174%_
                                                 _%staged-rows19208%_)
                                                (if (null? _%staged-rows19208%_)
                                                    '#!void
                                                    (begin
                                                      (vector-set!
                                                       _%all18625%_
                                                       _%index19174%_
                                                       (let ((__tmp37357
                                                              (reverse _%staged-rows19208%_))
                                                             (__tmp37356
                                                              (filter (lambda (_%existing19210%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                (not (let* ((_%frontier19212%_
                                             _%frontier19180%_)
                                            (_%key19215%_
                                             (let ()
                                               (declare (not safe))
                                               (gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-key
                                                _%existing19210%_)))
                                            (_%frontier19219%_
                                             _%frontier19212%_))
                                       (declare (not safe))
                                       (gerbil-ascent/program/lattice-frontier#__lattice-frontier-ref
                                        _%frontier19219%_
                                        _%key19215%_))))
                              (vector-ref _%all18625%_ _%index19174%_))))
                 (declare (not safe))
                 (##append __tmp37357 __tmp37356)))
              (for-each
               (lambda (_%row19231%_)
                 (let ((__tmp37359
                        (vector-ref _%lattice-rows18653%_ _%index19174%_))
                       (__tmp37358
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-key
                           _%row19231%_))))
                   (declare (not safe))
                   (hash-put! __tmp37359 __tmp37358 _%row19231%_))
                 (let ((__tmp37360 (vector-ref _%seen18645%_ _%index19174%_)))
                   (declare (not safe))
                   (hash-put! __tmp37360 _%row19231%_ '#t))
                 (set! _%derived-count18665%_ (+ _%derived-count18665%_ '1))
                 (set! _%active?19086%_ '#t))
               _%staged-rows19208%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (for-each
                                               (lambda (_%row19233%_)
                                                 (let ((__tmp37361
                                                        (vector-ref
                                                         _%seen18645%_
                                                         _%index19174%_)))
                                                   (declare (not safe))
                                                   (hash-put!
                                                    __tmp37361
                                                    _%row19233%_
                                                    '#t))
                                                 (vector-set!
                                                  _%all18625%_
                                                  _%index19174%_
                                                  (cons _%row19233%_
                                                        (vector-ref
                                                         _%all18625%_
                                                         _%index19174%_)))
                                                 (set! _%derived-count18665%_
                                                       (+ _%derived-count18665%_
                                                          '1))
                                                 (set! _%active?19086%_ '#t))
                                               (vector-ref
                                                _%pending19068%_
                                                _%index19174%_)))
                                          (let ((_%batch-size19235%_
                                                 (length (vector-ref
                                                          _%pending19068%_
                                                          _%index19174%_))))
                                            (if (= _%batch-size19235%_ '0)
                                                '#!void
                                                (begin
                                                  (if (vector-ref
                                                       _%lattice-joins18647%_
                                                       _%index19174%_)
                                                      '#!void
                                                      (let ((__tmp37362
                                                             (vector-ref
                                                              _%pending19068%_
                                                              _%index19174%_)))
                                                        (declare (not safe))
                                                        (_%advance-all-indexes!18675%_
                                                         _%index19174%_
                                                         __tmp37362)))
                                                  (vector-set!
                                                   _%all-version18629%_
                                                   _%index19174%_
                                                   (+ '1
                                                      (vector-ref
                                                       _%all-version18629%_
                                                       _%index19174%_)))
                                                  (vector-set!
                                                   _%all-size18633%_
                                                   _%index19174%_
                                                   (if (if (vector-ref
                                                            _%lattice-joins18647%_
                                                            _%index19174%_)
                                                           '#f
                                                           (and (let ((__tmp37363
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               (vector-ref
                                _%storage-providers18651%_
                                _%index19174%_)))
                          (declare (not safe))
                          (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                           __tmp37363))
                        (let ((__tmp37364
                               (vector-ref
                                _%index-providers18637%_
                                _%index19174%_)))
                          (declare (not safe))
                          (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                           __tmp37364))))
               (+ (vector-ref _%all-size18633%_ _%index19174%_)
                  _%batch-size19235%_)
               (length (vector-ref _%all18625%_ _%index19174%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (vector-set!
                                             _%delta18627%_
                                             _%index19174%_
                                             (vector-ref
                                              _%pending19068%_
                                              _%index19174%_))
                                            (vector-set!
                                             _%delta-size18635%_
                                             _%index19174%_
                                             _%batch-size19235%_)
                                            (vector-set!
                                             _%delta-version18631%_
                                             _%index19174%_
                                             (+ '1
                                                (vector-ref
                                                 _%delta-version18631%_
                                                 _%index19174%_))))
                                          (if (pair? (vector-ref
                                                      _%pending19068%_
                                                      _%index19174%_))
                                              (begin
                                                (vector-set!
                                                 _%pending19068%_
                                                 _%index19174%_
                                                 '())
                                                (if (vector-ref
                                                     _%lattice-joins18647%_
                                                     _%index19174%_)
                                                    (let* ((_%frontier19237%_
                                                            (vector-ref
                                                             _%pending-lattices19071%_
                                                             _%index19174%_))
                                                           (_%frontier19241%_
                                                            _%frontier19237%_))
                                                      (declare (not safe))
                                                      (gerbil-ascent/program/lattice-frontier#__lattice-frontier-clear!
                                                       _%frontier19241%_))
                                                    (let ((__tmp37365
                                                           (vector-ref
                                                            _%pending-seen19069%_
                                                            _%index19174%_)))
                                                      (declare (not safe))
                                                      (hash-clear!
                                                       __tmp37365))))
                                              '#!void)))
                                    (_%commit19172%_ (+ _%index19174%_ '1)))
                                  '#!void))
                            (let ()
                              (declare (not safe))
                              (##for-each
                               gerbil-ascent/table/storage#gerbil-ascent-storage-admit-state!
                               _%storage-owners18682%_))
                            (if _%component-mode?19073%_
                                (set! _%active?19086%_ '#f)
                                '#!void)
                            (if (and _%active?19086%_
                                     (if (vector? _%deadline19064%_)
                                         (vector-ref _%deadline19064%_ '0)
                                         _%deadline19064%_)
                                     (>= (current-jiffy)
                                         (if (vector? _%deadline19064%_)
                                             (vector-ref _%deadline19064%_ '0)
                                             _%deadline19064%_)))
                                (begin
                                  (set! _%resume-stratum18732%_
                                        _%stratum19083%_)
                                  (set! _%resume-round18734%_ _%round19087%_)
                                  (set! _%complete?19066%_ '#f)
                                  (_%return19079%_ '#f))
                                '#!void)
                            (_%loop19096%_))
                          '#!void))
                    (set! _%resume-stratum18732%_ '#f)
                    (set! _%resume-round18734%_ '0)
                    (_%evaluate-stratum19081%_ (+ _%stratum19083%_ '1)))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (declare (not safe))
                                             (##call-with-current-continuation
                                              __tmp37342))))
                                       (if _%complete?19066%_
                                           (begin
                                             (set! _%first-run?18738%_ '#f)
                                             (set! _%dirty?18740%_ '#f)
                                             (set! _%materialized-dirty?18736%_
                                                   '#f))
                                           '#!void)
                                       (let* ((_%snapshots19462%_
                                               (if (vector? _%deadline19064%_)
                                                   (let ()
                                                     (declare (not safe))
                                                     (gerbil-ascent/program/result#gerbil-ascent-publish-rows__%
                                                      _%all18625%_
                                                      _%deadline19064%_
                                                      _%all-size18633%_))
                                                   (vector-map
                                                    (lambda (_%rows19460%_)
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (##structure-instance-of?
                                                             _%rows19460%_
                                                             'gerbil-ascent/core/relation-view#relation-view::t))
                                                          _%rows19460%_
                                                          (reverse _%rows19460%_)))
                                                    _%all18625%_)))
                                              (_%sizes19464%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##vector-copy
                                                  _%all-size18633%_)))
                                              (_%representations19470%_
                                               (let ((__tmp37425
                                                      (lambda (_%name19466%_
                                                               _%rows19467%_
                                                               _%size19468%_)
                                                        (list _%name19466%_
                                                              (if (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (declare (not safe))
                            (##structure-instance-of?
                             _%rows19467%_
                             'gerbil-ascent/core/relation-view#relation-view::t))
                          'rectangles
                          'explicit)
                      _%size19468%_
                      (if (let ()
                            (declare (not safe))
                            (##structure-instance-of?
                             _%rows19467%_
                             'gerbil-ascent/core/relation-view#relation-view::t))
                          (let ()
                            (declare (not safe))
                            (##unchecked-structure-ref
                             _%rows19467%_
                             '6
                             '#f
                             '#f))
                          _%size19468%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (__tmp37424
                                                      (vector->list
                                                       _%names18617%_))
                                                     (__tmp37423
                                                      (let ()
                                                        (declare (not safe))
                                                        (##vector->list
                                                         _%all18625%_)))
                                                     (__tmp37422
                                                      (let ()
                                                        (declare (not safe))
                                                        (##vector->list
                                                         _%sizes19464%_))))
                                                 (declare (not safe))
                                                 (##map __tmp37425
                                                        __tmp37424
                                                        __tmp37423
                                                        __tmp37422)))
                                              (_%observation19472%_
                                               (let ((__tmp37426
                                                      (if _%reuse18583%_
                                                          (##structure-ref
                                                           _%reuse18583%_
                                                           '2
                                                           gerbil-ascent/program/reuse#native-reuse::t
                                                           '#f)
                                                          '#f)))
                                                 (declare (not safe))
                                                 (gerbil-ascent/program/result#gerbil-ascent-result-observation
                                                  __tmp37426
                                                  _%names18617%_
                                                  _%active-by-stratum18704%_
                                                  _%rule-ticks18694%_)))
                                              (_g37427_
                                               (let ()
                                                 (declare (not safe))
                                                 (gerbil-ascent/program/result#gerbil-ascent-make-owned-result
                                                  _%names18617%_
                                                  _%arity18619%_
                                                  _%snapshots19462%_
                                                  _%sizes19464%_
                                                  _%representations19470%_
                                                  _%observation19472%_
                                                  _%position-of18670%_
                                                  _%complete?19066%_
                                                  _%session?18578%_))))
                                         (begin
                                           (let ((_g37428_
                                                  (let ()
                                                    (declare (not safe))
                                                    (if (##values? _g37427_)
                                                        (##values-length
                                                         _g37427_)
                                                        1))))
                                             (if (not (let ()
                                                        (declare (not safe))
                                                        (##fx= _g37428_ 2)))
                                                 (error "Context expects 2 values"
                                                        _g37428_)))
                                           (let ((_%result19475%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (##values-ref _g37427_ 0)))
                                                 (_%publication19476%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (##values-ref
                                                     _g37427_
                                                     1))))
                                             (begin
                                               (set! _%owned-publication18744%_
                                                     _%publication19476%_)
                                               (set! _%last-result18742%_
                                                     _%result19475%_))))))
                                     '#!void)
                                 (if (and _%reuse18583%_ _%complete?19066%_)
                                     (begin
                                       (set! _%active-by-stratum18704%_ '#f)
                                       (set! _%reuse18583%_ '#f))
                                     '#!void)
                                 _%last-result18742%_)))
                            (_%run-retained!__0__3728337284%_
                             (lambda ()
                               (let ((_%deadline19482%_ '#f))
                                 (_%run-retained!__3728137282%_
                                  _%deadline19482%_))))
                            (_%run-retained!18748%_
                             (lambda _g37429_
                               (let ((_g37430_
                                      (let ()
                                        (declare (not safe))
                                        (##length _g37429_))))
                                 (cond ((let ()
                                          (declare (not safe))
                                          (##fx= _g37430_ 0))
                                        (apply _%run-retained!__0__3728337284%_
                                               _g37429_))
                                       ((let ()
                                          (declare (not safe))
                                          (##fx= _g37430_ 1))
                                        (apply _%run-retained!__3728137282%_
                                               _g37429_))
                                       (else
                                        (##raise-wrong-number-of-arguments-exception
                                         'case-lambda-dispatch
                                         _g37429_))))))
                            (_%run!18749%_
                             (lambda ()
                               (if _%recompute-from-source?18730%_
                                   _%last-result18742%_
                                   (_%run-retained!__0__3728337284%_)))))
                    (if _%session?18578%_
                        (let ((_%published18751%_
                               (let ()
                                 (declare (not safe))
                                 (gerbil-ascent/program/result#gerbil-ascent-publication-cache
                                  _%count18610%_))))
                          (letrec ((_%replay-source!18753%_
                                    (lambda (_%mode18989%_
                                             _%index18990%_
                                             _%rows18991%_)
                                      (let* ((_%cut19015%_
                                              (let* ((_%state18993%_
                                                      _%source-state18718%_)
                                                     (_%index18996%_
                                                      _%index18990%_)
                                                     (_%rows18999%_
                                                      _%rows18991%_)
                                                     (_%state19003%_
                                                      _%state18993%_))
                                                (declare (not safe))
                                                (gerbil-ascent/program/source-state#__gerbil-ascent-prepare-source-replacement
                                                 _%state19003%_
                                                 _%index18996%_
                                                 _%rows18999%_)))
                                             (_%candidate19017%_
                                              (##direct-structure-ref
                                               _%cut19015%_
                                               '2
                                               gerbil-ascent/program/source-snapshot#source-snapshot::t
                                               '#f))
                                             (_%next-count19024%_
                                              (let ((_%$e19019%_
                                                     _%mode18989%_))
                                                (if (eq? 'append _%$e19019%_)
                                                    '#f
                                                    (if (eq? 'replace
                                                             _%$e19019%_)
                                                        (let ((__tmp37431
                                                               (map (lambda (_%relation19022%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (length (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%relation19022%_
                                         'rows))))
                            (let ()
                              (declare (not safe))
                              (clan/poo/object#.ref
                               _%candidate19017%_
                               'relations)))))
                  (declare (not safe))
                  (##apply + __tmp37431))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        (if (and (eq? _%mode18989%_ 'replace)
                                                 (> _%next-count19024%_
                                                    _%input-limit18603%_))
                                            (let ()
                                              (declare (not safe))
                                              (error '"ASCENT session input fact budget exceeded"))
                                            '#!void)
                                        (let ((_%result19027%_
                                               ((let ((__tmp37432
                                                       (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__3
                                                        _%candidate19017%_
                                                        '#t
                                                        _%analysis18688%_
                                                        _%schema18615%_
                                                        _%measure-rule-times?18581%_)))
                                                  (declare (not safe))
                                                  (clan/poo/object#.ref
                                                   __tmp37432
                                                   '.run)))))
                                          (set! _%source-count18661%_
                                                (let ((_%$e19029%_
                                                       _%next-count19024%_))
                                                  (if _%$e19029%_
                                                      _%$e19029%_
                                                      (+ _%source-count18661%_
                                                         '1))))
                                          (let* ((_%state19032%_
                                                  _%source-state18718%_)
                                                 (_%index19035%_
                                                  _%index18990%_)
                                                 (_%rows19038%_ _%rows18991%_)
                                                 (_%cut19041%_ _%cut19015%_)
                                                 (_%state19045%_
                                                  _%state19032%_))
                                            (declare (not safe))
                                            (gerbil-ascent/program/source-state#__gerbil-ascent-commit-source-replacement!
                                             _%state19045%_
                                             _%index19035%_
                                             _%rows19038%_
                                             _%cut19041%_))
                                          (set! _%recompute-from-source?18730%_
                                                '#t)
                                          (if (eq? _%mode18989%_ 'replace)
                                              (set! _%publication-failed?18667%_
                                                    '#f)
                                              '#!void)
                                          (set! _%dirty?18740%_ '#f)
                                          (set! _%owned-publication18744%_ '#f)
                                          (set! _%last-result18742%_
                                                _%result19027%_)))))
                                   (_%append-set-source!18754%_
                                    (lambda (_%index18986%_ _%row18987%_)
                                      (if (> (+ _%source-materialized-count18663%_
                                                _%derived-count18665%_
                                                _%staged-total18726%_
                                                '1)
                                             _%output-limit18607%_)
                                          (_%flush-staged-set-rows!18747%_)
                                          '#!void)
                                      (if (and (>= (+ _%source-materialized-count18663%_
                                                      _%derived-count18665%_)
                                                   _%output-limit18607%_)
                                               (not (let ((__tmp37433
                                                           (vector-ref
                                                            _%seen18645%_
                                                            _%index18986%_)))
                                                      (declare (not safe))
                                                      (hash-get
                                                       __tmp37433
                                                       _%row18987%_))))
                                          (let ()
                                            (declare (not safe))
                                            (error '"ASCENT session output fact budget exceeded"))
                                          '#!void)
                                      (set! _%source-count18661%_
                                            (+ _%source-count18661%_ '1))
                                      (vector-set!
                                       _%source-additions18722%_
                                       _%index18986%_
                                       (cons _%row18987%_
                                             (vector-ref
                                              _%source-additions18722%_
                                              _%index18986%_)))
                                      (vector-set!
                                       _%staged-set-counts18724%_
                                       _%index18986%_
                                       (+ '1
                                          (vector-ref
                                           _%staged-set-counts18724%_
                                           _%index18986%_)))
                                      (set! _%staged-total18726%_
                                            (+ _%staged-total18726%_ '1))
                                      (set! _%dirty?18740%_ '#t)))
                                   (_%append-source!18755%_
                                    (lambda (_%name18919%_ _%row18920%_)
                                      (if _%recompute-from-source?18730%_
                                          '#!void
                                          (begin
                                            (let ()
                                              (declare (not safe))
                                              (##for-each
                                               gerbil-ascent/table/storage#gerbil-ascent-storage-check-state!
                                               _%storage-owners18682%_))
                                            (if _%publication-failed?18667%_
                                                (let ()
                                                  (declare (not safe))
                                                  (error '"ASCENT engine publication requires source replay"))
                                                '#!void)))
                                      (if _%first-run?18738%_
                                          (let ()
                                            (declare (not safe))
                                            (error '"ASCENT session must run before source updates"))
                                          '#!void)
                                      (let* ((_%index18922%_
                                              (_%position-of18670%_
                                               _%name18919%_))
                                             (_%width18924%_
                                              (vector-ref
                                               _%arity18619%_
                                               _%index18922%_))
                                             (_%built-in-set?18926%_
                                              (let ((__tmp37434
                                                     (vector-ref
                                                      _%storage-providers18651%_
                                                      _%index18922%_)))
                                                (declare (not safe))
                                                (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                                                 __tmp37434))))
                                        (if (and (list? _%row18920%_)
                                                 (= (let ()
                                                      (declare (not safe))
                                                      (##length _%row18920%_))
                                                    _%width18924%_))
                                            '#!void
                                            (let ()
                                              (declare (not safe))
                                              (error '"invalid ASCENT session source row"
                                                     _%name18919%_
                                                     _%row18920%_)))
                                        (let ((_%check18929%_
                                               (vector-ref
                                                _%field-checkers18621%_
                                                _%index18922%_)))
                                          (if _%check18929%_
                                              (_%check18929%_ _%row18920%_)
                                              '#!void))
                                        (if (>= _%source-count18661%_
                                                _%input-limit18603%_)
                                            (let ()
                                              (declare (not safe))
                                              (error '"ASCENT session input fact budget exceeded"))
                                            '#!void)
                                        (if (or (not _%positive-rules?18714%_)
                                                _%lattice-feeds-relation?18708%_
                                                _%recompute-from-source?18730%_
                                                (vector-ref
                                                 _%lattice-joins18647%_
                                                 _%index18922%_))
                                            (_%replay-source!18753%_
                                             'append
                                             _%index18922%_
                                             (let ((__tmp37436
                                                    (let* ((_%state18941%_
                                                            _%source-state18718%_)
                                                           (_%index18944%_
                                                            _%index18922%_)
                                                           (_%state18948%_
                                                            _%state18941%_))
                                                      (declare (not safe))
                                                      (gerbil-ascent/program/source-state#__gerbil-ascent-source-state-rows
                                                       _%state18948%_
                                                       _%index18944%_)))
                                                   (__tmp37435
                                                    (list _%row18920%_)))
                                               (declare (not safe))
                                               (##append
                                                __tmp37436
                                                __tmp37435)))
                                            (if (_%view-relation?18673%_
                                                 _%index18922%_)
                                                (let ()
                                                  (_%flush-staged-set-rows!18747%_)
                                                  (let ((_%frontier18966%_
                                                         (let ((__tmp37439
                                                                (vector-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%storage-states18643%_
                         _%index18922%_))
                       (__tmp37438
                        (- _%output-limit18607%_
                           (+ _%source-materialized-count18663%_
                              _%derived-count18665%_)))
                       (__tmp37437
                        (vector-ref _%field-checkers18621%_ _%index18922%_)))
                   (declare (not safe))
                   (gerbil-ascent/program/view-state#gerbil-ascent-stage-view!
                    __tmp37439
                    _%row18920%_
                    __tmp37438
                    __tmp37437))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (set! _%source-count18661%_
                                                          (+ _%source-count18661%_
                                                             '1))
                                                    (if (> (let ()
                                                             (declare
                                                               (not safe))
                                                             (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                                                              _%frontier18966%_))
                                                           '0)
                                                        (begin
                                                          (set! _%dirty?18740%_
                                                                '#t)
                                                          (set! _%materialized-dirty?18736%_
                                                                '#t)
                                                          (set! _%source-materialized-count18663%_
                                                                (+ _%source-materialized-count18663%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                              _%frontier18966%_))))
                  (vector-set!
                   _%view-journals18657%_
                   _%index18922%_
                   (cons (let ((__tmp37442 (list _%row18920%_))
                               (__tmp37440
                                (let ((__tmp37441
                                       (vector-ref
                                        _%storage-states18643%_
                                        _%index18922%_)))
                                  (declare (not safe))
                                  (gerbil-ascent/table/storage#gerbil-ascent-storage-eqrel-state?
                                   __tmp37441))))
                           (declare (not safe))
                           (gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event__%
                            'source
                            __tmp37442
                            __tmp37440))
                         (vector-ref _%view-journals18657%_ _%index18922%_)))
                  (_%commit-view!18674%_
                   _%index18922%_
                   (let ((__tmp37443
                          (vector-ref _%delta18627%_ _%index18922%_)))
                     (declare (not safe))
                     (gerbil-ascent/program/view-state#gerbil-ascent-add-frontier
                      __tmp37443
                      _%frontier18966%_))))
                '#!void)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (if _%built-in-set?18926%_
                                                    (_%append-set-source!18754%_
                                                     _%index18922%_
                                                     _%row18920%_)
                                                    (let ()
                                                      (_%flush-staged-set-rows!18747%_)
                                                      (let* ((_%expanded18970%_
                                                              ((vector-ref
                                                                _%storage-extensions18641%_
                                                                _%index18922%_)
                                                               (vector-ref
                                                                _%storage-states18643%_
                                                                _%index18922%_)
                                                               (vector-ref
                                                                _%all18625%_
                                                                _%index18922%_)
                                                               (vector-ref
                                                                _%delta18627%_
                                                                _%index18922%_)
                                                               _%row18920%_
                                                               (- _%output-limit18607%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (+ _%source-materialized-count18663%_
                             _%derived-count18665%_))))
                     (_%present18972%_
                      (vector-ref _%seen18645%_ _%index18922%_))
                     (_g37444_
                      (let ((__tmp37447
                             (vector-ref
                              _%field-checkers18621%_
                              _%index18922%_))
                            (__tmp37446
                             (+ _%source-materialized-count18663%_
                                _%derived-count18665%_)))
                        (declare (not safe))
                        (gerbil-ascent/program/admission#gerbil-ascent-prepare-storage-batch
                         _%expanded18970%_
                         _%width18924%_
                         __tmp37447
                         _%present18972%_
                         __tmp37446
                         _%output-limit18607%_))))
                (begin
                  (let ((_g37445_
                         (let ()
                           (declare (not safe))
                           (if (##values? _g37444_)
                               (##values-length _g37444_)
                               1))))
                    (if (not (let () (declare (not safe)) (##fx= _g37445_ 2)))
                        (error "Context expects 2 values" _g37445_)))
                  (let ((_%new-rows18975%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g37444_ 0)))
                        (_%added-count18976%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g37444_ 1))))
                    (begin
                      (set! _%source-count18661%_ (+ _%source-count18661%_ '1))
                      (let ((_%new-all18978%_
                             (vector-ref _%all18625%_ _%index18922%_))
                            (_%new-delta18979%_
                             (vector-ref _%delta18627%_ _%index18922%_)))
                        (for-each
                         (lambda (_%stored18981%_)
                           (let ()
                             (declare (not safe))
                             (hash-put! _%present18972%_ _%stored18981%_ '#t))
                           (set! _%new-all18978%_
                                 (cons _%stored18981%_ _%new-all18978%_))
                           (set! _%new-delta18979%_
                                 (cons _%stored18981%_ _%new-delta18979%_)))
                         _%new-rows18975%_)
                        (vector-set!
                         _%all18625%_
                         _%index18922%_
                         _%new-all18978%_)
                        (vector-set!
                         _%delta18627%_
                         _%index18922%_
                         _%new-delta18979%_))
                      (set! _%source-materialized-count18663%_
                            (+ _%source-materialized-count18663%_
                               _%added-count18976%_))
                      (if (pair? _%new-rows18975%_)
                          (begin
                            (set! _%dirty?18740%_ '#t)
                            (set! _%materialized-dirty?18736%_ '#t)
                            (let ()
                              (declare (not safe))
                              (_%advance-all-indexes!18675%_
                               _%index18922%_
                               _%new-rows18975%_))
                            (vector-set!
                             _%all-size18633%_
                             _%index18922%_
                             (+ (vector-ref _%all-size18633%_ _%index18922%_)
                                _%added-count18976%_))
                            (vector-set!
                             _%delta-size18635%_
                             _%index18922%_
                             (+ (vector-ref _%delta-size18635%_ _%index18922%_)
                                _%added-count18976%_))
                            (vector-set!
                             _%all-version18629%_
                             _%index18922%_
                             (+ '1
                                (vector-ref
                                 _%all-version18629%_
                                 _%index18922%_)))
                            (vector-set!
                             _%delta-version18631%_
                             _%index18922%_
                             (+ '1
                                (vector-ref
                                 _%delta-version18631%_
                                 _%index18922%_))))
                          '#!void)))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        (if (or (vector-ref
                                                 _%source-overrides18728%_
                                                 _%index18922%_)
                                                _%built-in-set?18926%_)
                                            '#!void
                                            (vector-set!
                                             _%source-additions18722%_
                                             _%index18922%_
                                             (cons _%row18920%_
                                                   (vector-ref
                                                    _%source-additions18722%_
                                                    _%index18922%_))))
                                        (let ((__tmp37448
                                               (vector-ref
                                                _%storage-states18643%_
                                                _%index18922%_)))
                                          (declare (not safe))
                                          (gerbil-ascent/table/storage#gerbil-ascent-storage-admit-state!
                                           __tmp37448)))))
                                   (_%append-single-set-source!18756%_
                                    (lambda (_%name18914%_ _%row18915%_)
                                      (if _%publication-failed?18667%_
                                          (let ()
                                            (declare (not safe))
                                            (error '"ASCENT engine publication requires source replay"))
                                          '#!void)
                                      (if _%recompute-from-source?18730%_
                                          (_%append-source!18755%_
                                           _%name18914%_
                                           _%row18915%_)
                                          (begin
                                            (if _%first-run?18738%_
                                                (let ()
                                                  (declare (not safe))
                                                  (error '"ASCENT session must run before source updates"))
                                                '#!void)
                                            (if (eq? _%name18914%_
                                                     (vector-ref
                                                      _%names18617%_
                                                      '0))
                                                '#!void
                                                (let ()
                                                  (declare (not safe))
                                                  (error '"unknown ASCENT relation"
                                                         _%name18914%_)))
                                            (if (and (list? _%row18915%_)
                                                     (= (let ()
                                                          (declare (not safe))
                                                          (##length
                                                           _%row18915%_))
                                                        (vector-ref
                                                         _%arity18619%_
                                                         '0)))
                                                '#!void
                                                (let ()
                                                  (declare (not safe))
                                                  (error '"invalid ASCENT session source row"
                                                         _%name18914%_
                                                         _%row18915%_)))
                                            (let ((_%check18917%_
                                                   (vector-ref
                                                    _%field-checkers18621%_
                                                    '0)))
                                              (if _%check18917%_
                                                  (_%check18917%_ _%row18915%_)
                                                  '#!void))
                                            (if (>= _%source-count18661%_
                                                    _%input-limit18603%_)
                                                (let ()
                                                  (declare (not safe))
                                                  (error '"ASCENT session input fact budget exceeded"))
                                                '#!void)
                                            (_%append-set-source!18754%_
                                             '0
                                             _%row18915%_)))))
                                   (_%replace-source!18757%_
                                    (lambda (_%name18906%_ _%rows18907%_)
                                      (if _%first-run?18738%_
                                          (let ()
                                            (declare (not safe))
                                            (error '"ASCENT session must run before source updates"))
                                          '#!void)
                                      (let* ((_%index18909%_
                                              (_%position-of18670%_
                                               _%name18906%_))
                                             (_%width18911%_
                                              (vector-ref
                                               _%arity18619%_
                                               _%index18909%_)))
                                        (let ((__tmp37449
                                               (vector-ref
                                                _%field-checkers18621%_
                                                _%index18909%_)))
                                          (declare (not safe))
                                          (gerbil-ascent/program/admission#gerbil-ascent-check-replacement-rows!
                                           _%name18906%_
                                           _%rows18907%_
                                           _%width18911%_
                                           __tmp37449))
                                        (_%replay-source!18753%_
                                         'replace
                                         _%index18909%_
                                         _%rows18907%_))))
                                   (_%run-session!18758%_
                                    (lambda ()
                                      (if _%recompute-from-source?18730%_
                                          _%last-result18742%_
                                          (begin
                                            (vector-set!
                                             _%published18751%_
                                             '0
                                             '#f)
                                            (_%run-retained!__3728137282%_
                                             _%published18751%_)))))
                                   (_%run-timeout!18759%_
                                    (lambda (_%duration-nanoseconds18903%_)
                                      (if (and (exact-integer?
                                                _%duration-nanoseconds18903%_)
                                               (>= _%duration-nanoseconds18903%_
                                                   '0))
                                          '#!void
                                          (let ()
                                            (declare (not safe))
                                            (error '"invalid ASCENT timeout in nanoseconds"
                                                   _%duration-nanoseconds18903%_)))
                                      (if _%recompute-from-source?18730%_
                                          _%last-result18742%_
                                          (begin
                                            (vector-set!
                                             _%published18751%_
                                             '0
                                             (+ (current-jiffy)
                                                (quotient
                                                 (* _%duration-nanoseconds18903%_
                                                    (jiffies-per-second))
                                                 '1000000000)))
                                            (_%run-retained!__3728137282%_
                                             _%published18751%_))))))
                            (let ((__tmp37450
                                   (let ((__obj37285
                                          (let ()
                                            (declare (not safe))
                                            (##structure
                                             clan/poo/object#object::t
                                             '#f
                                             '#f
                                             '#f
                                             '#f
                                             '#f
                                             '#f
                                             '#f))))
                                     (let ((__tmp37452
                                            (list (cons '.append-source!
                                                        (let ((__tmp37453
                                                               (lambda (_%@18850%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (if _%single-set-source?18716%_
                             _%append-single-set-source!18756%_
                             _%append-source!18755%_))))
                  (declare (not safe))
                  (##structure clan/poo/object#$self-slot-spec::t __tmp37453)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons '.replace-source!
                                                        (let ((__tmp37454
                                                               (lambda (_%@18856%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%replace-source!18757%_)))
                  (declare (not safe))
                  (##structure clan/poo/object#$self-slot-spec::t __tmp37454)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons '.run
                                                        (let ((__tmp37455
                                                               (lambda (_%@18861%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%run-session!18758%_)))
                  (declare (not safe))
                  (##structure clan/poo/object#$self-slot-spec::t __tmp37455)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons '.run-timeout
                                                        (let ((__tmp37456
                                                               (lambda (_%@18866%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%run-timeout!18759%_)))
                  (declare (not safe))
                  (##structure clan/poo/object#$self-slot-spec::t __tmp37456)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons '.analysis
                                                        (let ((__tmp37457
                                                               (lambda (_%@18871%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%analysis18688%_)))
                  (declare (not safe))
                  (##structure clan/poo/object#$self-slot-spec::t __tmp37457)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons '.schema
                                                        (let ((__tmp37458
                                                               (lambda (_%@18876%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%schema18615%_)))
                  (declare (not safe))
                  (##structure clan/poo/object#$self-slot-spec::t __tmp37458)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons '.native-publication
                                                        (let ((__tmp37459
                                                               (lambda (_%@18881%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (lambda () _%owned-publication18744%_))))
                  (declare (not safe))
                  (##structure clan/poo/object#$self-slot-spec::t __tmp37459)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons '.recomputed?
                                                        (let ((__tmp37460
                                                               (lambda (_%@18887%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (lambda () _%recompute-from-source?18730%_))))
                  (declare (not safe))
                  (##structure clan/poo/object#$self-slot-spec::t __tmp37460)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons '.source-additions
                                                        (let ((__tmp37461
                                                               (lambda (_%@18893%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%source-additions18722%_)))
                  (declare (not safe))
                  (##structure clan/poo/object#$self-slot-spec::t __tmp37461)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons '.source-overrides
                                                        (let ((__tmp37462
                                                               (lambda (_%@18898%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%source-overrides18728%_)))
                  (declare (not safe))
                  (##structure
                   clan/poo/object#$self-slot-spec::t
                   __tmp37462)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           (__tmp37451 (list)))
                                       (declare (not safe))
                                       (clan/poo/object#object:::init!__%
                                        '#f
                                        gerbil-ascent/program/evaluate#Session.
                                        __tmp37452
                                        __tmp37451
                                        __obj37285))
                                     __obj37285)))
                              (declare (not safe))
                              (clan/poo/mop#validate
                               gerbil-ascent/program/types#GerbilAscentSessionContract
                               __tmp37450))))
                        _%run!18749%_)))))))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__0
      (lambda (_%program19552%_ _%session?19553%_)
        (let* ((_%analysis-override19555%_ '#f)
               (_%schema-override19557%_ '#f)
               (_%measure-rule-times?19559%_ '#f)
               (_%plan-error19561%_ '#f)
               (_%reuse19563%_ '#f)
               (_%workers19565%_ '1)
               (_%canceled?19567%_ '#f))
          (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
           _%program19552%_
           _%session?19553%_
           _%analysis-override19555%_
           _%schema-override19557%_
           _%measure-rule-times?19559%_
           _%plan-error19561%_
           _%reuse19563%_
           _%workers19565%_
           _%canceled?19567%_))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__1
      (lambda (_%program19569%_ _%session?19570%_ _%analysis-override19571%_)
        (let* ((_%schema-override19573%_ '#f)
               (_%measure-rule-times?19575%_ '#f)
               (_%plan-error19577%_ '#f)
               (_%reuse19579%_ '#f)
               (_%workers19581%_ '1)
               (_%canceled?19583%_ '#f))
          (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
           _%program19569%_
           _%session?19570%_
           _%analysis-override19571%_
           _%schema-override19573%_
           _%measure-rule-times?19575%_
           _%plan-error19577%_
           _%reuse19579%_
           _%workers19581%_
           _%canceled?19583%_))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__2
      (lambda (_%program19585%_
               _%session?19586%_
               _%analysis-override19587%_
               _%schema-override19588%_)
        (let* ((_%measure-rule-times?19590%_ '#f)
               (_%plan-error19592%_ '#f)
               (_%reuse19594%_ '#f)
               (_%workers19596%_ '1)
               (_%canceled?19598%_ '#f))
          (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
           _%program19585%_
           _%session?19586%_
           _%analysis-override19587%_
           _%schema-override19588%_
           _%measure-rule-times?19590%_
           _%plan-error19592%_
           _%reuse19594%_
           _%workers19596%_
           _%canceled?19598%_))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__3
      (lambda (_%program19600%_
               _%session?19601%_
               _%analysis-override19602%_
               _%schema-override19603%_
               _%measure-rule-times?19604%_)
        (let* ((_%plan-error19606%_ '#f)
               (_%reuse19608%_ '#f)
               (_%workers19610%_ '1)
               (_%canceled?19612%_ '#f))
          (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
           _%program19600%_
           _%session?19601%_
           _%analysis-override19602%_
           _%schema-override19603%_
           _%measure-rule-times?19604%_
           _%plan-error19606%_
           _%reuse19608%_
           _%workers19610%_
           _%canceled?19612%_))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__4
      (lambda (_%program19614%_
               _%session?19615%_
               _%analysis-override19616%_
               _%schema-override19617%_
               _%measure-rule-times?19618%_
               _%plan-error19619%_)
        (let* ((_%reuse19621%_ '#f)
               (_%workers19623%_ '1)
               (_%canceled?19625%_ '#f))
          (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
           _%program19614%_
           _%session?19615%_
           _%analysis-override19616%_
           _%schema-override19617%_
           _%measure-rule-times?19618%_
           _%plan-error19619%_
           _%reuse19621%_
           _%workers19623%_
           _%canceled?19625%_))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__5
      (lambda (_%program19627%_
               _%session?19628%_
               _%analysis-override19629%_
               _%schema-override19630%_
               _%measure-rule-times?19631%_
               _%plan-error19632%_
               _%reuse19633%_)
        (let* ((_%workers19635%_ '1) (_%canceled?19637%_ '#f))
          (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
           _%program19627%_
           _%session?19628%_
           _%analysis-override19629%_
           _%schema-override19630%_
           _%measure-rule-times?19631%_
           _%plan-error19632%_
           _%reuse19633%_
           _%workers19635%_
           _%canceled?19637%_))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__6
      (lambda (_%program19639%_
               _%session?19640%_
               _%analysis-override19641%_
               _%schema-override19642%_
               _%measure-rule-times?19643%_
               _%plan-error19644%_
               _%reuse19645%_
               _%workers19646%_)
        (let ((_%canceled?19648%_ '#f))
          (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
           _%program19639%_
           _%session?19640%_
           _%analysis-override19641%_
           _%schema-override19642%_
           _%measure-rule-times?19643%_
           _%plan-error19644%_
           _%reuse19645%_
           _%workers19646%_
           _%canceled?19648%_))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-engine
      (lambda _g37463_
        (let ((_g37464_ (let () (declare (not safe)) (##length _g37463_))))
          (cond ((let () (declare (not safe)) (##fx= _g37464_ 2))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__0
                        _g37463_))
                ((let () (declare (not safe)) (##fx= _g37464_ 3))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__1
                        _g37463_))
                ((let () (declare (not safe)) (##fx= _g37464_ 4))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__2
                        _g37463_))
                ((let () (declare (not safe)) (##fx= _g37464_ 5))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__3
                        _g37463_))
                ((let () (declare (not safe)) (##fx= _g37464_ 6))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__4
                        _g37463_))
                ((let () (declare (not safe)) (##fx= _g37464_ 7))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__5
                        _g37463_))
                ((let () (declare (not safe)) (##fx= _g37464_ 8))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__6
                        _g37463_))
                ((let () (declare (not safe)) (##fx= _g37464_ 9))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
                        _g37463_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/evaluate#gerbil-ascent-make-engine
                  _g37463_))))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-evaluate-program__%
      (lambda (_%@@keywords18551%_
               _%$%measure-rule-times?1854618552%_
               _%$%workers1854718553%_
               _%$%canceled?1854818554%_
               _%program18555%_)
        (let* ((_%measure-rule-times?18557%_
                (if (eq? _%$%measure-rule-times?1854618552%_ absent-value)
                    '#f
                    _%$%measure-rule-times?1854618552%_))
               (_%workers18559%_
                (if (eq? _%$%workers1854718553%_ absent-value)
                    '1
                    _%$%workers1854718553%_))
               (_%canceled?18561%_
                (if (eq? _%$%canceled?1854818554%_ absent-value)
                    '#f
                    _%$%canceled?1854818554%_)))
          (if (boolean? _%measure-rule-times?18557%_)
              '#!void
              (let ()
                (declare (not safe))
                (error '"invalid ASCENT rule timing option"
                       _%measure-rule-times?18557%_)))
          ((gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
            _%program18555%_
            '#f
            '#f
            '#f
            _%measure-rule-times?18557%_
            '#f
            '#f
            _%workers18559%_
            _%canceled?18561%_)))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-evaluate-program__@
      (lambda (_%@@keywords18566%_ . _%args18567%_)
        (apply gerbil-ascent/program/evaluate#gerbil-ascent-evaluate-program__%
               _%@@keywords18566%_
               (let ()
                 (declare (not safe))
                 (symbolic-table-ref
                  _%@@keywords18566%_
                  'measure-rule-times?:
                  absent-value))
               (let ()
                 (declare (not safe))
                 (symbolic-table-ref
                  _%@@keywords18566%_
                  'workers:
                  absent-value))
               (let ()
                 (declare (not safe))
                 (symbolic-table-ref
                  _%@@keywords18566%_
                  'canceled?:
                  absent-value))
               _%args18567%_)))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-evaluate-program
      (lambda _%$%args1854918573%_
        (apply keyword-dispatch
               '#(measure-rule-times?: #f workers: canceled?: #f #f)
               gerbil-ascent/program/evaluate#gerbil-ascent-evaluate-program__@
               _%$%args1854918573%_)))))
