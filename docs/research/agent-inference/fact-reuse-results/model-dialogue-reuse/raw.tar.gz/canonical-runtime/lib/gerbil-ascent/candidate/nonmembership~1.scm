(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34206_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34208_|
    (##structure
     gx#syntax-quote::t
     'make-positive-nonmembership
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34210_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34212_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34213_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34214_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34215_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34216_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34217_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-program-fingerprint
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34218_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34219_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34220_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-closure
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34222_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34223_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34224_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34225_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34226_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34227_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-program-fingerprint-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34228_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34229_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34230_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-closure-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34232_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34233_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34234_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34235_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34236_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34237_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-program-fingerprint
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34238_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34239_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34240_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-closure
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34242_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34243_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34244_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34245_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34246_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34247_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-program-fingerprint-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34248_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34249_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g34250_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-closure-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[:0:]#positive-nonmembership|
    (let ((__obj34160
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34160
         'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34160
         'positive-nonmembership
         '3
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34160
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  program-fingerprint
                  query
                  work-budget
                  closure)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34160
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  program-fingerprint
                  query
                  work-budget
                  closure)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34160 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34160 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34160 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34160 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34160 '#f '13 '#f '#f))
      (let ((__tmp34205 |gerbil-ascent/candidate/nonmembership[1]#_g34206_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34160 __tmp34205 '4 '#f '#f))
      (let ((__tmp34207 |gerbil-ascent/candidate/nonmembership[1]#_g34208_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34160 __tmp34207 '14 '#f '#f))
      (let ((__tmp34209 |gerbil-ascent/candidate/nonmembership[1]#_g34210_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34160 __tmp34209 '15 '#f '#f))
      (let ((__tmp34211
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g34212_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g34213_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g34214_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g34215_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g34216_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g34217_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g34218_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g34219_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g34220_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj34160 __tmp34211 '16 '#f '#f))
      (let ((__tmp34221
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g34222_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g34223_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g34224_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g34225_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g34226_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g34227_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g34228_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g34229_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g34230_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj34160 __tmp34221 '17 '#f '#f))
      (let ((__tmp34231
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g34232_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g34233_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g34234_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g34235_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g34236_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g34237_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g34238_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g34239_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g34240_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj34160 __tmp34231 '18 '#f '#f))
      (let ((__tmp34241
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g34242_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g34243_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g34244_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g34245_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g34246_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g34247_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g34248_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g34249_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g34250_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj34160 __tmp34241 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34160 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34160 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34160 '() '21 '#f '#f))
      __obj34160)))
