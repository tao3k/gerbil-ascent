# SPDX-FileCopyrightText: 2026 tao3k team and Contributors
# SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
"""Fail-closed answer and literal annotation admission for the diagnostic."""
import unittest
from ascent_test_support.evidence_chain_study import (
    shared_action, shared_validate_label, shared_tasks, shared_truth)


class SharedPremiseTest(unittest.TestCase):
    def message(self, payload):
        return {'output': [{'type': 'message', 'content': [{'type': 'output_text', 'text': payload}]}]}

    def test_answer_rejects_salvage_duplicates_and_boolean_ids(self):
        for raw in ('```json\n{"permitted":[0]}\n```', '{"permitted":[0,0]}',
                    '{"permitted":[true]}', '{"permitted":[0],"permitted":[]}',
                    '{"permitted":[],"why":"ok"}'):
            with self.subTest(raw=raw), self.assertRaises((ValueError, AssertionError)):
                shared_action(self.message(raw))

    def test_distinct_residuals_and_directed_absence(self):
        a,b=shared_tasks()
        self.assertTrue(shared_truth(a,['path',0,2]))
        self.assertTrue(shared_truth(b,['path',0,2]))
        self.assertTrue(shared_truth(a,['ready',2]))
        self.assertFalse(shared_truth(b,['ready',2]))
        self.assertTrue(shared_truth(b,['ready',3]))
        self.assertFalse(shared_truth(a,['path',2,0]))

    def test_repeat_is_across_questions_but_mentions_are_not_derivations(self):
        text='edge(0,1) and edge(1,2) imply path(0,2).'
        item={'quote':text,'occurrence':0,'category':'positive_derivation',
              'atom':['path',0,2],'premises':[['edge',0,1],['edge',1,2]]}
        first=shared_validate_label(text,item,shared_tasks()[0],[],[])
        second=shared_validate_label(text,item,shared_tasks()[0],[],[first])
        self.assertTrue(second['repeatFact']);self.assertTrue(second['exactRepeat'])
        mention={**item,'quote':'path(0,2)','premises':[]}
        with self.assertRaises(AssertionError):
            shared_validate_label('path(0,2)',mention,shared_tasks()[0],[],[])

    def test_label_name_cannot_make_old_or_supplied_atom_new(self):
        text='edge(0,1) and edge(1,2) imply path(0,2).'
        item={'quote':text,'occurrence':0,'category':'new_residual',
              'atom':['path',0,2],'premises':[['edge',0,1],['edge',1,2]]}
        label=shared_validate_label(text,item,shared_tasks()[0],[['path',0,2]],[])
        self.assertFalse(label['newConsequence'])
        self.assertTrue(label['suppliedPremiseRederived'])

    def test_invented_chain_and_nonliteral_endpoint_rejected(self):
        text='edge(0,1) implies path(0,2).'
        item={'quote':text,'occurrence':0,'category':'positive_derivation',
              'atom':['path',0,2],'premises':[['edge',0,1]]}
        with self.assertRaises(AssertionError):shared_validate_label(text,item,shared_tasks()[0],[],[])
        item['premises']=[['edge',0,10],['edge',10,2]]
        with self.assertRaises(AssertionError):shared_validate_label(text,item,shared_tasks()[0],[],[])


if __name__ == '__main__': unittest.main()
