(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/component-worker[1]#_g36357_|
    (##structure
     gx#syntax-quote::t
     'component-snapshot::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36359_|
    (##structure
     gx#syntax-quote::t
     'make-component-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36361_|
    (##structure
     gx#syntax-quote::t
     'component-snapshot?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36363_|
    (##structure
     gx#syntax-quote::t
     'component-snapshot-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36364_|
    (##structure
     gx#syntax-quote::t
     'component-snapshot-sizes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36366_|
    (##structure
     gx#syntax-quote::t
     'component-snapshot-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36367_|
    (##structure
     gx#syntax-quote::t
     'component-snapshot-sizes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36369_|
    (##structure
     gx#syntax-quote::t
     '&component-snapshot-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36370_|
    (##structure
     gx#syntax-quote::t
     '&component-snapshot-sizes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36372_|
    (##structure
     gx#syntax-quote::t
     '&component-snapshot-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36373_|
    (##structure
     gx#syntax-quote::t
     '&component-snapshot-sizes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[:0:]#component-snapshot|
    (let ((__obj36220
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj36220
         'gerbil-ascent/program/component-worker#component-snapshot::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36220 'component-snapshot '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36220 '(rows sizes) '6 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36220 '(rows sizes) '8 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36220 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36220 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36220 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36220 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36220 '#f '13 '#f '#f))
      (let ((__tmp36356 |gerbil-ascent/program/component-worker[1]#_g36357_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj36220 __tmp36356 '4 '#f '#f))
      (let ((__tmp36358 |gerbil-ascent/program/component-worker[1]#_g36359_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj36220 __tmp36358 '14 '#f '#f))
      (let ((__tmp36360 |gerbil-ascent/program/component-worker[1]#_g36361_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj36220 __tmp36360 '15 '#f '#f))
      (let ((__tmp36362
             (cons (cons 'rows
                         |gerbil-ascent/program/component-worker[1]#_g36363_|)
                   (cons (cons 'sizes
                               |gerbil-ascent/program/component-worker[1]#_g36364_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36220 __tmp36362 '16 '#f '#f))
      (let ((__tmp36365
             (cons (cons 'rows
                         |gerbil-ascent/program/component-worker[1]#_g36366_|)
                   (cons (cons 'sizes
                               |gerbil-ascent/program/component-worker[1]#_g36367_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36220 __tmp36365 '17 '#f '#f))
      (let ((__tmp36368
             (cons (cons 'rows
                         |gerbil-ascent/program/component-worker[1]#_g36369_|)
                   (cons (cons 'sizes
                               |gerbil-ascent/program/component-worker[1]#_g36370_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36220 __tmp36368 '18 '#f '#f))
      (let ((__tmp36371
             (cons (cons 'rows
                         |gerbil-ascent/program/component-worker[1]#_g36372_|)
                   (cons (cons 'sizes
                               |gerbil-ascent/program/component-worker[1]#_g36373_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36220 __tmp36371 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36220 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36220 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36220 '() '21 '#f '#f))
      __obj36220)))
