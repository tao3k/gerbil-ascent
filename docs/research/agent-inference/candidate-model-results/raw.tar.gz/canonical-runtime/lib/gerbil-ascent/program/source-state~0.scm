(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/source-state::timestamp 1791689701)
  (begin
    (define gerbil-ascent/program/source-state#source-state::t
      (let ((__tmp36825 (list))
            (__tmp36824
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/source-state#source-state::t
         'source-state
         __tmp36825
         '(originals additions overrides snapshot)
         __tmp36824
         '#f)))
    (define gerbil-ascent/program/source-state#source-state?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/source-state#source-state::t)))
    (define gerbil-ascent/program/source-state#make-source-state
      (lambda _%$args17485%_
        (apply make-instance
               gerbil-ascent/program/source-state#source-state::t
               _%$args17485%_)))
    (define gerbil-ascent/program/source-state#source-state-originals
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-state#source-state::t
         'originals)))
    (define gerbil-ascent/program/source-state#source-state-additions
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-state#source-state::t
         'additions)))
    (define gerbil-ascent/program/source-state#source-state-overrides
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-state#source-state::t
         'overrides)))
    (define gerbil-ascent/program/source-state#source-state-snapshot
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-state#source-state::t
         'snapshot)))
    (define gerbil-ascent/program/source-state#source-state-originals-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-state#source-state::t
         'originals)))
    (define gerbil-ascent/program/source-state#source-state-additions-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-state#source-state::t
         'additions)))
    (define gerbil-ascent/program/source-state#source-state-overrides-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-state#source-state::t
         'overrides)))
    (define gerbil-ascent/program/source-state#source-state-snapshot-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-state#source-state::t
         'snapshot)))
    (define gerbil-ascent/program/source-state#&source-state-originals
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-state#source-state::t
         'originals)))
    (define gerbil-ascent/program/source-state#&source-state-additions
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-state#source-state::t
         'additions)))
    (define gerbil-ascent/program/source-state#&source-state-overrides
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-state#source-state::t
         'overrides)))
    (define gerbil-ascent/program/source-state#&source-state-snapshot
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-state#source-state::t
         'snapshot)))
    (define gerbil-ascent/program/source-state#&source-state-originals-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-state#source-state::t
         'originals)))
    (define gerbil-ascent/program/source-state#&source-state-additions-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-state#source-state::t
         'additions)))
    (define gerbil-ascent/program/source-state#&source-state-overrides-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-state#source-state::t
         'overrides)))
    (define gerbil-ascent/program/source-state#&source-state-snapshot-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-state#source-state::t
         'snapshot)))
    (define gerbil-ascent/program/source-state#gerbil-ascent-source-state
      (lambda (_%program17475%_ _%relations17476%_)
        (let* ((_%originals17480%_
                (list->vector
                 (map (lambda (_%relation17478%_)
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref _%relation17478%_ 'rows)))
                      _%relations17476%_)))
               (_%count17482%_
                (let ()
                  (declare (not safe))
                  (##vector-length _%originals17480%_))))
          (let ((__tmp36828
                 (let ()
                   (declare (not safe))
                   (##make-vector _%count17482%_ '())))
                (__tmp36827
                 (let ()
                   (declare (not safe))
                   (##make-vector _%count17482%_ '#f)))
                (__tmp36826
                 (let ()
                   (declare (not safe))
                   (gerbil-ascent/program/source-snapshot#gerbil-ascent-source-snapshot
                    _%program17475%_))))
            (declare (not safe))
            (##structure
             gerbil-ascent/program/source-state#source-state::t
             _%originals17480%_
             __tmp36828
             __tmp36827
             __tmp36826)))))
    (define gerbil-ascent/program/source-state#__gerbil-ascent-source-state-rows
      (lambda (_%state17459%_ _%index17460%_)
        (let* ((_%state17463%_ _%state17459%_)
               (_%$e17472%_
                (vector-ref
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%state17463%_ '3 '#f '#f))
                 _%index17460%_)))
          (if _%$e17472%_
              _%$e17472%_
              (let ((__tmp36830
                     (vector-ref
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref _%state17463%_ '1 '#f '#f))
                      _%index17460%_))
                    (__tmp36829
                     (vector-ref
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref _%state17463%_ '2 '#f '#f))
                      _%index17460%_)))
                (declare (not safe))
                (gerbil-ascent/program/source-log#gerbil-ascent-source-log-rows
                 __tmp36830
                 __tmp36829))))))
    (define gerbil-ascent/program/source-state#gerbil-ascent-source-state-rows
      (lambda (_%state17446%_ _%index17447%_)
        (let ((_%state17450%_ _%state17446%_))
          (gerbil-ascent/program/source-state#__gerbil-ascent-source-state-rows
           _%state17450%_
           _%index17447%_))))
    (define gerbil-ascent/program/source-state#__gerbil-ascent-prepare-source-replacement
      (lambda (_%state17316%_ _%index17317%_ _%rows17318%_)
        (let* ((_%state17321%_ _%state17316%_)
               (_%logs17330%_
                (let ((__tmp36831
                       (vector-length
                        (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%state17321%_
                           '1
                           '#f
                           '#f)))))
                  (declare (not safe))
                  (##make-vector __tmp36831))))
          (let ((_%$start17332%_ '0)
                (_%$end17334%_
                 (let ()
                   (declare (not safe))
                   (##vector-length _%logs17330%_))))
            (if (> _%$start17332%_ _%$end17334%_)
                (let ((_%$start17337%_ '0)
                      (_%$end17339%_
                       (let ()
                         (declare (not safe))
                         (##vector-length _%logs17330%_)))
                      (_%$step17341%_ '-1))
                  (if (> _%$step17341%_ '0)
                      (let _%loop17345%_ ((_%k17348%_ _%$start17337%_))
                        (if (< _%k17348%_ _%$end17339%_)
                            (begin
                              (vector-set!
                               _%logs17330%_
                               _%k17348%_
                               (if (= _%k17348%_ _%index17317%_)
                                   (cons _%rows17318%_ '())
                                   (let ((_%$e17355%_
                                          (vector-ref
                                           (let ()
                                             (declare (not safe))
                                             (##unchecked-structure-ref
                                              _%state17321%_
                                              '3
                                              '#f
                                              '#f))
                                           _%k17348%_)))
                                     (if _%$e17355%_
                                         (cons _%$e17355%_ '())
                                         (cons (vector-ref
                                                (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%state17321%_
                                                   '1
                                                   '#f
                                                   '#f))
                                                _%k17348%_)
                                               (vector-ref
                                                (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%state17321%_
                                                   '2
                                                   '#f
                                                   '#f))
                                                _%k17348%_))))))
                              (_%loop17345%_ (+ _%k17348%_ _%$step17341%_)))
                            '#!void))
                      (if (< _%$step17341%_ '0)
                          (let _%loop17364%_ ((_%k17366%_ _%$start17337%_))
                            (if (> _%k17366%_ _%$end17339%_)
                                (begin
                                  (vector-set!
                                   _%logs17330%_
                                   _%k17366%_
                                   (if (= _%k17366%_ _%index17317%_)
                                       (cons _%rows17318%_ '())
                                       (let ((_%$e17372%_
                                              (vector-ref
                                               (let ()
                                                 (declare (not safe))
                                                 (##unchecked-structure-ref
                                                  _%state17321%_
                                                  '3
                                                  '#f
                                                  '#f))
                                               _%k17366%_)))
                                         (if _%$e17372%_
                                             (cons _%$e17372%_ '())
                                             (cons (vector-ref
                                                    (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%state17321%_
                                                       '1
                                                       '#f
                                                       '#f))
                                                    _%k17366%_)
                                                   (vector-ref
                                                    (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%state17321%_
                                                       '2
                                                       '#f
                                                       '#f))
                                                    _%k17366%_))))))
                                  (_%loop17364%_
                                   (+ _%k17366%_ _%$step17341%_)))
                                '#!void))
                          (let ()
                            (raise-contract-violation-error
                             '"contract violation"
                             'context:
                             'gerbil-ascent/program/source-state
                             'contract:
                             '(not (zero? -1))
                             'value:
                             _%$step17341%_)
                            '#!void))))
                (let ((_%$start17381%_ '0)
                      (_%$end17383%_
                       (let ()
                         (declare (not safe))
                         (##vector-length _%logs17330%_)))
                      (_%$step17385%_ '1))
                  (if (> _%$step17385%_ '0)
                      (let _%loop17389%_ ((_%k17392%_ _%$start17381%_))
                        (if (< _%k17392%_ _%$end17383%_)
                            (begin
                              (vector-set!
                               _%logs17330%_
                               _%k17392%_
                               (if (= _%k17392%_ _%index17317%_)
                                   (cons _%rows17318%_ '())
                                   (let ((_%$e17399%_
                                          (vector-ref
                                           (let ()
                                             (declare (not safe))
                                             (##unchecked-structure-ref
                                              _%state17321%_
                                              '3
                                              '#f
                                              '#f))
                                           _%k17392%_)))
                                     (if _%$e17399%_
                                         (cons _%$e17399%_ '())
                                         (cons (vector-ref
                                                (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%state17321%_
                                                   '1
                                                   '#f
                                                   '#f))
                                                _%k17392%_)
                                               (vector-ref
                                                (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%state17321%_
                                                   '2
                                                   '#f
                                                   '#f))
                                                _%k17392%_))))))
                              (_%loop17389%_ (+ _%k17392%_ _%$step17385%_)))
                            '#!void))
                      (if (< _%$step17385%_ '0)
                          (let _%loop17408%_ ((_%k17410%_ _%$start17381%_))
                            (if (> _%k17410%_ _%$end17383%_)
                                (begin
                                  (vector-set!
                                   _%logs17330%_
                                   _%k17410%_
                                   (if (= _%k17410%_ _%index17317%_)
                                       (cons _%rows17318%_ '())
                                       (let ((_%$e17416%_
                                              (vector-ref
                                               (let ()
                                                 (declare (not safe))
                                                 (##unchecked-structure-ref
                                                  _%state17321%_
                                                  '3
                                                  '#f
                                                  '#f))
                                               _%k17410%_)))
                                         (if _%$e17416%_
                                             (cons _%$e17416%_ '())
                                             (cons (vector-ref
                                                    (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%state17321%_
                                                       '1
                                                       '#f
                                                       '#f))
                                                    _%k17410%_)
                                                   (vector-ref
                                                    (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%state17321%_
                                                       '2
                                                       '#f
                                                       '#f))
                                                    _%k17410%_))))))
                                  (_%loop17408%_
                                   (+ _%k17410%_ _%$step17385%_)))
                                '#!void))
                          (let ()
                            (raise-contract-violation-error
                             '"contract violation"
                             'context:
                             'gerbil-ascent/program/source-state
                             'contract:
                             '(not (zero? 1))
                             'value:
                             _%$step17385%_)
                            '#!void))))))
          (let* ((_%snapshot17425%_
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%state17321%_ '4 '#f '#f)))
                 (_%logs17428%_ _%logs17330%_)
                 (_%snapshot17432%_ _%snapshot17425%_))
            (declare (not safe))
            (gerbil-ascent/program/source-snapshot#__gerbil-ascent-prepare-source-log-snapshot
             _%snapshot17432%_
             _%logs17428%_)))))
    (define gerbil-ascent/program/source-state#gerbil-ascent-prepare-source-replacement
      (lambda (_%state17302%_ _%index17303%_ _%rows17304%_)
        (let ((_%state17307%_ _%state17302%_))
          (gerbil-ascent/program/source-state#__gerbil-ascent-prepare-source-replacement
           _%state17307%_
           _%index17303%_
           _%rows17304%_))))
    (define gerbil-ascent/program/source-state#__gerbil-ascent-commit-source-replacement!
      (lambda (_%state17287%_ _%index17288%_ _%rows17289%_ _%cut17290%_)
        (let ((_%state17293%_ _%state17287%_))
          (let ()
            (declare (not safe))
            (##unchecked-structure-set!
             _%state17293%_
             _%cut17290%_
             '4
             '#f
             '#f))
          (vector-set!
           (let ()
             (declare (not safe))
             (##unchecked-structure-ref _%state17293%_ '3 '#f '#f))
           _%index17288%_
           _%rows17289%_)
          (vector-set!
           (let ()
             (declare (not safe))
             (##unchecked-structure-ref _%state17293%_ '2 '#f '#f))
           _%index17288%_
           '()))))
    (define gerbil-ascent/program/source-state#gerbil-ascent-commit-source-replacement!
      (lambda (_%state17272%_ _%index17273%_ _%rows17274%_ _%cut17275%_)
        (let ((_%state17278%_ _%state17272%_))
          (gerbil-ascent/program/source-state#__gerbil-ascent-commit-source-replacement!
           _%state17278%_
           _%index17273%_
           _%rows17274%_
           _%cut17275%_))))))
