(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/component-plan[1]#_g36128_|
    (##structure
     gx#syntax-quote::t
     'positive-component::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g36130_|
    (##structure
     gx#syntax-quote::t
     'make-positive-component
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g36132_|
    (##structure
     gx#syntax-quote::t
     'positive-component?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g36134_|
    (##structure
     gx#syntax-quote::t
     'positive-component-id
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g36135_|
    (##structure
     gx#syntax-quote::t
     'positive-component-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g36136_|
    (##structure
     gx#syntax-quote::t
     'positive-component-rules
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g36137_|
    (##structure
     gx#syntax-quote::t
     'positive-component-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g36139_|
    (##structure
     gx#syntax-quote::t
     'positive-component-id-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g36140_|
    (##structure
     gx#syntax-quote::t
     'positive-component-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g36141_|
    (##structure
     gx#syntax-quote::t
     'positive-component-rules-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g36142_|
    (##structure
     gx#syntax-quote::t
     'positive-component-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g36144_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-id
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g36145_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g36146_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-rules
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g36147_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g36149_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-id-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g36150_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g36151_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-rules-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g36152_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[:0:]#positive-component|
    (let ((__obj35990
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj35990
         'gerbil-ascent/program/component-plan#positive-component::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35990 'positive-component '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj35990
         '(id members rules predecessors)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj35990
         '(id members rules predecessors)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35990 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35990 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35990 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35990 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35990 '#f '13 '#f '#f))
      (let ((__tmp36127 |gerbil-ascent/program/component-plan[1]#_g36128_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35990 __tmp36127 '4 '#f '#f))
      (let ((__tmp36129 |gerbil-ascent/program/component-plan[1]#_g36130_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35990 __tmp36129 '14 '#f '#f))
      (let ((__tmp36131 |gerbil-ascent/program/component-plan[1]#_g36132_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35990 __tmp36131 '15 '#f '#f))
      (let ((__tmp36133
             (cons (cons 'id
                         |gerbil-ascent/program/component-plan[1]#_g36134_|)
                   (cons (cons 'members
                               |gerbil-ascent/program/component-plan[1]#_g36135_|)
                         (cons (cons 'rules
                                     |gerbil-ascent/program/component-plan[1]#_g36136_|)
                               (cons (cons 'predecessors
                                           |gerbil-ascent/program/component-plan[1]#_g36137_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35990 __tmp36133 '16 '#f '#f))
      (let ((__tmp36138
             (cons (cons 'id
                         |gerbil-ascent/program/component-plan[1]#_g36139_|)
                   (cons (cons 'members
                               |gerbil-ascent/program/component-plan[1]#_g36140_|)
                         (cons (cons 'rules
                                     |gerbil-ascent/program/component-plan[1]#_g36141_|)
                               (cons (cons 'predecessors
                                           |gerbil-ascent/program/component-plan[1]#_g36142_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35990 __tmp36138 '17 '#f '#f))
      (let ((__tmp36143
             (cons (cons 'id
                         |gerbil-ascent/program/component-plan[1]#_g36144_|)
                   (cons (cons 'members
                               |gerbil-ascent/program/component-plan[1]#_g36145_|)
                         (cons (cons 'rules
                                     |gerbil-ascent/program/component-plan[1]#_g36146_|)
                               (cons (cons 'predecessors
                                           |gerbil-ascent/program/component-plan[1]#_g36147_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35990 __tmp36143 '18 '#f '#f))
      (let ((__tmp36148
             (cons (cons 'id
                         |gerbil-ascent/program/component-plan[1]#_g36149_|)
                   (cons (cons 'members
                               |gerbil-ascent/program/component-plan[1]#_g36150_|)
                         (cons (cons 'rules
                                     |gerbil-ascent/program/component-plan[1]#_g36151_|)
                               (cons (cons 'predecessors
                                           |gerbil-ascent/program/component-plan[1]#_g36152_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35990 __tmp36148 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35990 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35990 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35990 '() '21 '#f '#f))
      __obj35990)))
