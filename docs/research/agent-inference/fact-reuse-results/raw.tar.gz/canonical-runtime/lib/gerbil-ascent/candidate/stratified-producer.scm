(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/candidate/datum")
    (load-module "gerbil-ascent/candidate/closure-index")
    (load-module "std/hash/misc")
    (load-module "gerbil-ascent/candidate/types")
    (load-module "gerbil-ascent/candidate/program")
    (load-module "gerbil-ascent/candidate/funs")
    (load-module "gerbil-ascent/candidate/finite-evidence")
    (load-module "gerbil-ascent/candidate/stratified-proof"))
  (load-module "gerbil-ascent/candidate/stratified-producer~0"))
