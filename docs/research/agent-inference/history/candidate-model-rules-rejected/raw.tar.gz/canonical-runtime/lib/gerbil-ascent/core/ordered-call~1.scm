(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/core/ordered-call[:0:]#ordered-call-values|
    (lambda (_%$stx5653%_)
      (let* ((_%__stx3322133222%_ _%$stx5653%_)
             (_%$%g56585747%_
              (lambda ()
                (gx#raise-syntax-error
                 '#f
                 '"Bad syntax; invalid match target"
                 _%__stx3322133222%_))))
        (let ((_%__kont3322433225%_
               (lambda (_%$%g56606056%_
                        _%$%g56616058%_
                        _%$%g56626059%_
                        _%$%g56636060%_)
                 (cons _%$%g56636060%_
                       (let ((__tmp33479
                              (lambda (_%$%g60886091%_ _%$%g60896094%_)
                                (cons _%$%g60886091%_ _%$%g60896094%_))))
                         (declare (not safe))
                         (foldr__0 __tmp33479 '() _%$%g56606056%_)))))
              (_%__kont3322833229%_
               (lambda (_%$%g56945890%_
                        _%$%g56955892%_
                        _%$%g56965893%_
                        _%$%g56975894%_
                        _%$%g56985895%_
                        _%$%g56995896%_)
                 (cons (gx#datum->syntax '#f 'let*)
                       (cons (cons (cons _%$%g56985895%_
                                         (cons _%$%g56955892%_ '()))
                                   (cons (cons (gx#datum->syntax '#f 'next)
                                               (cons _%$%g56975894%_ '()))
                                         '()))
                             (cons (cons (gx#datum->syntax
                                          '#f
                                          'ordered-call-values)
                                         (cons _%$%g56995896%_
                                               (cons (cons _%$%g56985895%_
                                                           (cons _%$%g56975894%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (cons (let ((__tmp33481
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (lambda (_%$%g59345939%_ _%$%g59355942%_)
                            (cons _%$%g59345939%_ _%$%g59355942%_)))
                         (__tmp33480 (cons (gx#datum->syntax '#f 'next) '())))
                     (declare (not safe))
                     (foldr__0 __tmp33481 __tmp33480 _%$%g56965893%_))
                   (cons (let ((__tmp33482
                                (lambda (_%$%g59365945%_ _%$%g59375948%_)
                                  (cons _%$%g59365945%_ _%$%g59375948%_))))
                           (declare (not safe))
                           (foldr__0 __tmp33482 '() _%$%g56945890%_))
                         '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                   '()))))))
          (let* ((_%__match3332633327%_
                  (lambda (_%$%e57005754%_
                           _%$%hd57015758%_
                           _%$%tl57025761%_
                           _%$%e57035764%_
                           _%$%hd57045768%_
                           _%$%tl57055771%_
                           _%$%e57065774%_
                           _%$%hd57075778%_
                           _%$%tl57085781%_
                           _%$%e57095784%_
                           _%$%hd57105788%_
                           _%$%tl57115791%_
                           _%$%e57125794%_
                           _%$%hd57135798%_
                           _%$%tl57145801%_
                           _%$%e57155804%_
                           _%$%hd57165808%_
                           _%$%tl57175811%_
                           _%__splice3323033231%_
                           _%$%target57185814%_
                           _%$%tl57205817%_)
                    (letrec ((_%$%loop57215820%_
                              (lambda (_%$%hd57195824%_ _%$%value57255827%_)
                                (if (gx#stx-pair? _%$%hd57195824%_)
                                    (let ((_%$%e57225829%_
                                           (gx#syntax-e _%$%hd57195824%_)))
                                      (let ((_%$%lp-tl57245836%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e57225829%_)))
                                            (_%$%lp-hd57235833%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e57225829%_))))
                                        (_%$%loop57215820%_
                                         _%$%lp-tl57245836%_
                                         (cons _%$%lp-hd57235833%_
                                               _%$%value57255827%_))))
                                    (let ((_%$%value57265839%_
                                           (reverse _%$%value57255827%_)))
                                      (if (gx#stx-pair? _%$%tl57175811%_)
                                          (let ((_%$%e57275842%_
                                                 (gx#syntax-e
                                                  _%$%tl57175811%_)))
                                            (let ((_%$%tl57295849%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e57275842%_)))
                                                  (_%$%hd57285846%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e57275842%_))))
                                              (if (gx#stx-pair?
                                                   _%$%hd57285846%_)
                                                  (let ((_%$%e57305852%_
                                                         (gx#syntax-e
                                                          _%$%hd57285846%_)))
                                                    (let ((_%$%tl57325859%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e57305852%_)))
                                                          (_%$%hd57315856%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e57305852%_))))
                                                      (if (gx#stx-pair/null?
                                                           _%$%tl57325859%_)
                                                          (let ((_%__splice3323233233%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (gx#syntax-split-splice->vector _%$%tl57325859%_ '0)))
                    (let ((_%$%tl57355865%_
                           (let ()
                             (declare (not safe))
                             (##vector-ref _%__splice3323233233%_ '1)))
                          (_%$%target57335862%_
                           (let ()
                             (declare (not safe))
                             (##vector-ref _%__splice3323233233%_ '0))))
                      (if (gx#stx-null? _%$%tl57355865%_)
                          (letrec ((_%$%loop57365868%_
                                    (lambda (_%$%hd57345872%_
                                             _%$%rest57405875%_)
                                      (if (gx#stx-pair? _%$%hd57345872%_)
                                          (let ((_%$%e57375877%_
                                                 (gx#syntax-e
                                                  _%$%hd57345872%_)))
                                            (let ((_%$%lp-tl57395884%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e57375877%_)))
                                                  (_%$%lp-hd57385881%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e57375877%_))))
                                              (_%$%loop57365868%_
                                               _%$%lp-tl57395884%_
                                               (cons _%$%lp-hd57385881%_
                                                     _%$%rest57405875%_))))
                                          (let ((_%$%rest57415887%_
                                                 (reverse _%$%rest57405875%_)))
                                            (if (gx#stx-null? _%$%tl57295849%_)
                                                (_%__kont3322833229%_
                                                 _%$%rest57415887%_
                                                 _%$%hd57315856%_
                                                 _%$%value57265839%_
                                                 _%$%hd57135798%_
                                                 _%$%hd57105788%_
                                                 _%$%hd57045768%_)
                                                (let ()
                                                  (declare (not safe))
                                                  (_%$%g56585747%_))))))))
                            (_%$%loop57365868%_ _%$%target57335862%_ '()))
                          (let () (declare (not safe)) (_%$%g56585747%_)))))
                  (let () (declare (not safe)) (_%$%g56585747%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (let ()
                                                    (declare (not safe))
                                                    (_%$%g56585747%_)))))
                                          (let ()
                                            (declare (not safe))
                                            (_%$%g56585747%_))))))))
                      (_%$%loop57215820%_ _%$%target57185814%_ '()))))
                 (_%__match3328033281%_
                  (lambda (_%$%e56645958%_
                           _%$%hd56655962%_
                           _%$%tl56665965%_
                           _%$%e56675968%_
                           _%$%hd56685972%_
                           _%$%tl56695975%_
                           _%$%e56705978%_
                           _%$%hd56715982%_
                           _%$%tl56725985%_
                           _%$%e56735988%_
                           _%$%hd56745992%_
                           _%$%tl56755995%_
                           _%$%e56765998%_
                           _%$%hd56776002%_
                           _%$%tl56786005%_
                           _%$%e56796008%_
                           _%$%hd56806012%_
                           _%$%tl56816015%_
                           _%__splice3322633227%_
                           _%$%target56826018%_
                           _%$%tl56846021%_)
                    (letrec ((_%$%loop56856024%_
                              (lambda (_%$%hd56836028%_ _%$%value56896031%_)
                                (if (gx#stx-pair? _%$%hd56836028%_)
                                    (let ((_%$%e56866033%_
                                           (gx#syntax-e _%$%hd56836028%_)))
                                      (let ((_%$%lp-tl56886040%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e56866033%_)))
                                            (_%$%lp-hd56876037%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e56866033%_))))
                                        (_%$%loop56856024%_
                                         _%$%lp-tl56886040%_
                                         (cons _%$%lp-hd56876037%_
                                               _%$%value56896031%_))))
                                    (let ((_%$%value56906043%_
                                           (reverse _%$%value56896031%_)))
                                      (if (gx#stx-pair? _%$%tl56816015%_)
                                          (let ((_%$%e56916046%_
                                                 (gx#syntax-e
                                                  _%$%tl56816015%_)))
                                            (let ((_%$%tl56936053%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e56916046%_)))
                                                  (_%$%hd56926050%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e56916046%_))))
                                              (if (gx#stx-null?
                                                   _%$%hd56926050%_)
                                                  (if (gx#stx-null?
                                                       _%$%tl56936053%_)
                                                      (_%__kont3322433225%_
                                                       _%$%value56906043%_
                                                       _%$%hd56776002%_
                                                       _%$%hd56745992%_
                                                       _%$%hd56685972%_)
                                                      (_%__match3332633327%_
                                                       _%$%e56645958%_
                                                       _%$%hd56655962%_
                                                       _%$%tl56665965%_
                                                       _%$%e56675968%_
                                                       _%$%hd56685972%_
                                                       _%$%tl56695975%_
                                                       _%$%e56705978%_
                                                       _%$%hd56715982%_
                                                       _%$%tl56725985%_
                                                       _%$%e56735988%_
                                                       _%$%hd56745992%_
                                                       _%$%tl56755995%_
                                                       _%$%e56765998%_
                                                       _%$%hd56776002%_
                                                       _%$%tl56786005%_
                                                       _%$%e56796008%_
                                                       _%$%hd56806012%_
                                                       _%$%tl56816015%_
                                                       _%__splice3322633227%_
                                                       _%$%target56826018%_
                                                       _%$%tl56846021%_))
                                                  (_%__match3332633327%_
                                                   _%$%e56645958%_
                                                   _%$%hd56655962%_
                                                   _%$%tl56665965%_
                                                   _%$%e56675968%_
                                                   _%$%hd56685972%_
                                                   _%$%tl56695975%_
                                                   _%$%e56705978%_
                                                   _%$%hd56715982%_
                                                   _%$%tl56725985%_
                                                   _%$%e56735988%_
                                                   _%$%hd56745992%_
                                                   _%$%tl56755995%_
                                                   _%$%e56765998%_
                                                   _%$%hd56776002%_
                                                   _%$%tl56786005%_
                                                   _%$%e56796008%_
                                                   _%$%hd56806012%_
                                                   _%$%tl56816015%_
                                                   _%__splice3322633227%_
                                                   _%$%target56826018%_
                                                   _%$%tl56846021%_))))
                                          (_%__match3332633327%_
                                           _%$%e56645958%_
                                           _%$%hd56655962%_
                                           _%$%tl56665965%_
                                           _%$%e56675968%_
                                           _%$%hd56685972%_
                                           _%$%tl56695975%_
                                           _%$%e56705978%_
                                           _%$%hd56715982%_
                                           _%$%tl56725985%_
                                           _%$%e56735988%_
                                           _%$%hd56745992%_
                                           _%$%tl56755995%_
                                           _%$%e56765998%_
                                           _%$%hd56776002%_
                                           _%$%tl56786005%_
                                           _%$%e56796008%_
                                           _%$%hd56806012%_
                                           _%$%tl56816015%_
                                           _%__splice3322633227%_
                                           _%$%target56826018%_
                                           _%$%tl56846021%_)))))))
                      (_%$%loop56856024%_ _%$%target56826018%_ '())))))
            (if (gx#stx-pair? _%__stx3322133222%_)
                (let ((_%$%e56645958%_ (gx#syntax-e _%__stx3322133222%_)))
                  (let ((_%$%tl56665965%_
                         (let () (declare (not safe)) (##cdr _%$%e56645958%_)))
                        (_%$%hd56655962%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%e56645958%_))))
                    (if (gx#stx-pair? _%$%tl56665965%_)
                        (let ((_%$%e56675968%_ (gx#syntax-e _%$%tl56665965%_)))
                          (let ((_%$%tl56695975%_
                                 (let ()
                                   (declare (not safe))
                                   (##cdr _%$%e56675968%_)))
                                (_%$%hd56685972%_
                                 (let ()
                                   (declare (not safe))
                                   (##car _%$%e56675968%_))))
                            (if (gx#stx-pair? _%$%tl56695975%_)
                                (let ((_%$%e56705978%_
                                       (gx#syntax-e _%$%tl56695975%_)))
                                  (let ((_%$%tl56725985%_
                                         (let ()
                                           (declare (not safe))
                                           (##cdr _%$%e56705978%_)))
                                        (_%$%hd56715982%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%e56705978%_))))
                                    (if (gx#stx-pair? _%$%hd56715982%_)
                                        (let ((_%$%e56735988%_
                                               (gx#syntax-e _%$%hd56715982%_)))
                                          (let ((_%$%tl56755995%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e56735988%_)))
                                                (_%$%hd56745992%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e56735988%_))))
                                            (if (gx#stx-pair? _%$%tl56755995%_)
                                                (let ((_%$%e56765998%_
                                                       (gx#syntax-e
                                                        _%$%tl56755995%_)))
                                                  (let ((_%$%tl56786005%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e56765998%_)))
                                                        (_%$%hd56776002%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e56765998%_))))
                                                    (if (gx#stx-null?
                                                         _%$%tl56786005%_)
                                                        (if (gx#stx-pair?
                                                             _%$%tl56725985%_)
                                                            (let ((_%$%e56796008%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (gx#syntax-e _%$%tl56725985%_)))
                      (let ((_%$%tl56816015%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e56796008%_)))
                            (_%$%hd56806012%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e56796008%_))))
                        (if (gx#stx-pair/null? _%$%hd56806012%_)
                            (let ((_%__splice3322633227%_
                                   (gx#syntax-split-splice->vector
                                    _%$%hd56806012%_
                                    '0)))
                              (let ((_%$%tl56846021%_
                                     (let ()
                                       (declare (not safe))
                                       (##vector-ref
                                        _%__splice3322633227%_
                                        '1)))
                                    (_%$%target56826018%_
                                     (let ()
                                       (declare (not safe))
                                       (##vector-ref
                                        _%__splice3322633227%_
                                        '0))))
                                (if (gx#stx-null? _%$%tl56846021%_)
                                    (_%__match3328033281%_
                                     _%$%e56645958%_
                                     _%$%hd56655962%_
                                     _%$%tl56665965%_
                                     _%$%e56675968%_
                                     _%$%hd56685972%_
                                     _%$%tl56695975%_
                                     _%$%e56705978%_
                                     _%$%hd56715982%_
                                     _%$%tl56725985%_
                                     _%$%e56735988%_
                                     _%$%hd56745992%_
                                     _%$%tl56755995%_
                                     _%$%e56765998%_
                                     _%$%hd56776002%_
                                     _%$%tl56786005%_
                                     _%$%e56796008%_
                                     _%$%hd56806012%_
                                     _%$%tl56816015%_
                                     _%__splice3322633227%_
                                     _%$%target56826018%_
                                     _%$%tl56846021%_)
                                    (let ()
                                      (declare (not safe))
                                      (_%$%g56585747%_)))))
                            (let () (declare (not safe)) (_%$%g56585747%_)))))
                    (let () (declare (not safe)) (_%$%g56585747%_)))
                (let () (declare (not safe)) (_%$%g56585747%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (let ()
                                                  (declare (not safe))
                                                  (_%$%g56585747%_)))))
                                        (let ()
                                          (declare (not safe))
                                          (_%$%g56585747%_)))))
                                (let ()
                                  (declare (not safe))
                                  (_%$%g56585747%_)))))
                        (let () (declare (not safe)) (_%$%g56585747%_)))))
                (let () (declare (not safe)) (_%$%g56585747%_))))))))
  (define |gerbil-ascent/core/ordered-call[:0:]#dispatch-ordered-call|
    (lambda (_%$stx6104%_)
      (let* ((_%$%g61086150%_
              (lambda (_%$%g61096146%_)
                (gx#raise-syntax-error
                 '#f
                 '"Bad syntax; invalid match target"
                 _%$%g61096146%_)))
             (_%$%g61076339%_
              (lambda (_%$%g61096154%_)
                (if (gx#stx-pair? _%$%g61096154%_)
                    (let ((_%$%e61156157%_ (gx#syntax-e _%$%g61096154%_)))
                      (let ((_%$%hd61166161%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e61156157%_)))
                            (_%$%tl61176164%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e61156157%_))))
                        (if (gx#stx-pair? _%$%tl61176164%_)
                            (let ((_%$%e61186167%_
                                   (gx#syntax-e _%$%tl61176164%_)))
                              (let ((_%$%hd61196171%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e61186167%_)))
                                    (_%$%tl61206174%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e61186167%_))))
                                (if (gx#stx-pair/null? _%$%hd61196171%_)
                                    (let ((_g33483_
                                           (gx#syntax-split-splice
                                            _%$%hd61196171%_
                                            '0)))
                                      (begin
                                        (let ((_g33484_
                                               (let ()
                                                 (declare (not safe))
                                                 (if (##values? _g33483_)
                                                     (##values-length _g33483_)
                                                     1))))
                                          (if (not (let ()
                                                     (declare (not safe))
                                                     (##fx= _g33484_ 2)))
                                              (error "Context expects 2 values"
                                                     _g33484_)))
                                        (let ((_%$%target61216177%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##values-ref _g33483_ 0)))
                                              (_%$%tl61236180%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##values-ref _g33483_ 1))))
                                          (if (gx#stx-null? _%$%tl61236180%_)
                                              (letrec ((_%$%loop61246183%_
                                                        (lambda (_%$%hd61226187%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%$%wrap61286190%_)
                  (if (gx#stx-pair? _%$%hd61226187%_)
                      (let ((_%$%e61256192%_ (gx#syntax-e _%$%hd61226187%_)))
                        (let ((_%$%lp-hd61266196%_
                               (let ()
                                 (declare (not safe))
                                 (##car _%$%e61256192%_)))
                              (_%$%lp-tl61276199%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%$%e61256192%_))))
                          (_%$%loop61246183%_
                           _%$%lp-tl61276199%_
                           (cons _%$%lp-hd61266196%_ _%$%wrap61286190%_))))
                      (let ((_%$%wrap61296202%_ (reverse _%$%wrap61286190%_)))
                        (if (gx#stx-pair? _%$%tl61206174%_)
                            (let ((_%$%e61306205%_
                                   (gx#syntax-e _%$%tl61206174%_)))
                              (let ((_%$%hd61316209%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e61306205%_)))
                                    (_%$%tl61326212%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e61306205%_))))
                                (if (gx#stx-pair? _%$%tl61326212%_)
                                    (let ((_%$%e61336215%_
                                           (gx#syntax-e _%$%tl61326212%_)))
                                      (let ((_%$%hd61346219%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e61336215%_)))
                                            (_%$%tl61356222%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e61336215%_))))
                                        (if (gx#stx-pair? _%$%tl61356222%_)
                                            (let ((_%$%e61366225%_
                                                   (gx#syntax-e
                                                    _%$%tl61356222%_)))
                                              (let ((_%$%hd61376229%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e61366225%_)))
                                                    (_%$%tl61386232%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e61366225%_))))
                                                (if (gx#stx-pair?
                                                     _%$%hd61376229%_)
                                                    (let ((_%$%e61396235%_
                                                           (gx#syntax-e
                                                            _%$%hd61376229%_)))
                                                      (let ((_%$%hd61406239%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##car _%$%e61396235%_)))
                    (_%$%tl61416242%_
                     (let () (declare (not safe)) (##cdr _%$%e61396235%_))))
                (if (gx#stx-pair? _%$%tl61416242%_)
                    (let ((_%$%e61426245%_ (gx#syntax-e _%$%tl61416242%_)))
                      (let ((_%$%hd61436249%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e61426245%_)))
                            (_%$%tl61446252%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e61426245%_))))
                        (if (gx#stx-null? _%$%tl61446252%_)
                            (if (gx#stx-null? _%$%tl61386232%_)
                                (cons (gx#datum->syntax '#f 'match)
                                      (cons _%$%hd61346219%_
                                            (cons (cons (cons (gx#datum->syntax
                                                               '#f
                                                               '@list)
                                                              '())
                                                        (cons (let ((__tmp33486
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (lambda (_%$%g62906303%_ _%$%g62916306%_)
                               (cons _%$%g62906303%_ _%$%g62916306%_)))
                            (__tmp33485
                             (cons (cons (gx#datum->syntax
                                          '#f
                                          'ordered-call-values)
                                         (cons _%$%hd61316209%_
                                               (cons (cons _%$%hd61406239%_
                                                           (cons _%$%hd61436249%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (cons '()
                                                           (cons '() '())))))
                                   '())))
                        (declare (not safe))
                        (foldr__0 __tmp33486 __tmp33485 _%$%wrap61296202%_))
                      '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons (cons (cons (gx#datum->syntax
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             '#f
                             '@list)
                            (cons (gx#datum->syntax '#f 'one) '()))
                      (cons (let ((__tmp33488
                                   (lambda (_%$%g62926309%_ _%$%g62936312%_)
                                     (cons _%$%g62926309%_ _%$%g62936312%_)))
                                  (__tmp33487
                                   (cons (cons (gx#datum->syntax
                                                '#f
                                                'ordered-call-values)
                                               (cons _%$%hd61316209%_
                                                     (cons (cons _%$%hd61406239%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (cons _%$%hd61436249%_ '()))
                   (cons '()
                         (cons (cons (gx#datum->syntax '#f 'one) '()) '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                         '())))
                              (declare (not safe))
                              (foldr__0
                               __tmp33488
                               __tmp33487
                               _%$%wrap61296202%_))
                            '()))
                (cons (cons (cons (gx#datum->syntax '#f '@list)
                                  (cons (gx#datum->syntax '#f 'one)
                                        (cons (gx#datum->syntax '#f 'two)
                                              '())))
                            (cons (let ((__tmp33490
                                         (lambda (_%$%g62946315%_
                                                  _%$%g62956318%_)
                                           (cons _%$%g62946315%_
                                                 _%$%g62956318%_)))
                                        (__tmp33489
                                         (cons (cons (gx#datum->syntax
                                                      '#f
                                                      'ordered-call-values)
                                                     (cons _%$%hd61316209%_
                                                           (cons (cons _%$%hd61406239%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               (cons _%$%hd61436249%_ '()))
                         (cons '()
                               (cons (cons (gx#datum->syntax '#f 'one)
                                           (cons (gx#datum->syntax '#f 'two)
                                                 '()))
                                     '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               '())))
                                    (declare (not safe))
                                    (foldr__0
                                     __tmp33490
                                     __tmp33489
                                     _%$%wrap61296202%_))
                                  '()))
                      (cons (cons (cons (gx#datum->syntax '#f '@list)
                                        (cons (gx#datum->syntax '#f 'one)
                                              (cons (gx#datum->syntax '#f 'two)
                                                    (cons (gx#datum->syntax
                                                           '#f
                                                           'three)
                                                          '()))))
                                  (cons (let ((__tmp33492
                                               (lambda (_%$%g62966321%_
                                                        _%$%g62976324%_)
                                                 (cons _%$%g62966321%_
                                                       _%$%g62976324%_)))
                                              (__tmp33491
                                               (cons (cons (gx#datum->syntax
                                                            '#f
                                                            'ordered-call-values)
                                                           (cons _%$%hd61316209%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (cons (cons _%$%hd61406239%_
                                     (cons _%$%hd61436249%_ '()))
                               (cons '()
                                     (cons (cons (gx#datum->syntax '#f 'one)
                                                 (cons (gx#datum->syntax
                                                        '#f
                                                        'two)
                                                       (cons (gx#datum->syntax
                                                              '#f
                                                              'three)
                                                             '())))
                                           '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     '())))
                                          (declare (not safe))
                                          (foldr__0
                                           __tmp33492
                                           __tmp33491
                                           _%$%wrap61296202%_))
                                        '()))
                            (cons (cons (cons (gx#datum->syntax '#f '@list)
                                              (cons (gx#datum->syntax '#f 'one)
                                                    (cons (gx#datum->syntax
                                                           '#f
                                                           'two)
                                                          (cons (gx#datum->syntax
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '#f
                         'three)
                        (cons (gx#datum->syntax '#f 'four) '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        (cons (let ((__tmp33494
                                                     (lambda (_%$%g62986327%_
                                                              _%$%g62996330%_)
                                                       (cons _%$%g62986327%_
                                                             _%$%g62996330%_)))
                                                    (__tmp33493
                                                     (cons (cons (gx#datum->syntax
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          '#f
                          'ordered-call-values)
                         (cons _%$%hd61316209%_
                               (cons (cons _%$%hd61406239%_
                                           (cons _%$%hd61436249%_ '()))
                                     (cons '()
                                           (cons (cons (gx#datum->syntax
                                                        '#f
                                                        'one)
                                                       (cons (gx#datum->syntax
                                                              '#f
                                                              'two)
                                                             (cons (gx#datum->syntax
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            '#f
                            'three)
                           (cons (gx#datum->syntax '#f 'four) '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 '())))))
                   '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (declare (not safe))
                                                (foldr__0
                                                 __tmp33494
                                                 __tmp33493
                                                 _%$%wrap61296202%_))
                                              '()))
                                  (cons (cons (gx#datum->syntax '#f 'else)
                                              (cons (let ((__tmp33496
                                                           (lambda (_%$%g63006333%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%$%g63016336%_)
                     (cons _%$%g63006333%_ _%$%g63016336%_)))
                  (__tmp33495
                   (cons (cons (gx#datum->syntax '#f 'apply)
                               (cons _%$%hd61316209%_
                                     (cons (cons (gx#datum->syntax '#f 'map)
                                                 (cons (cons (gx#datum->syntax
                                                              '#f
                                                              'lambda)
                                                             (cons (cons _%$%hd61406239%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                 '())
                           (cons _%$%hd61436249%_ '())))
               (cons _%$%hd61346219%_ '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           '())))
                         '())))
              (declare (not safe))
              (foldr__0 __tmp33496 __tmp33495 _%$%wrap61296202%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '()))
                                        '()))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                (_%$%g61086150%_ _%$%g61096154%_))
                            (_%$%g61086150%_ _%$%g61096154%_))))
                    (_%$%g61086150%_ _%$%g61096154%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%g61086150%_
                                                     _%$%g61096154%_))))
                                            (_%$%g61086150%_
                                             _%$%g61096154%_))))
                                    (_%$%g61086150%_ _%$%g61096154%_))))
                            (_%$%g61086150%_ _%$%g61096154%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (_%$%loop61246183%_
                                                 _%$%target61216177%_
                                                 '()))
                                              (_%$%g61086150%_
                                               _%$%g61096154%_)))))
                                    (_%$%g61086150%_ _%$%g61096154%_))))
                            (_%$%g61086150%_ _%$%g61096154%_))))
                    (_%$%g61086150%_ _%$%g61096154%_)))))
        (_%$%g61076339%_ _%$stx6104%_)))))
