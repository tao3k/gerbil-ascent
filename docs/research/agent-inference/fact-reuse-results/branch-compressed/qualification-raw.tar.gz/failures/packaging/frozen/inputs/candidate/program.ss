;;; -*- Gerbil -*-
;;; SPDX-FileCopyrightText: 2026 tao3k team and Contributors
;;; SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later

;;; Bounded, inert rule proposals against a caller-owned snapshot.
;;; A receipt is an observation of one candidate, not source admission.
;;; Inspect inert proposal data, then lower the checked form into the
;;; trusted Scheme relational language. This module never evaluates a
;;; candidate-supplied procedure.
(import (only-in :gerbil-ascent/candidate/datum reasoning-bounded-data? candidate-copy-pairs)
        (only-in :gerbil-ascent/candidate/types
                 reasoning-snapshot-relations
                 make-reasoning-diagnostic make-candidate-rejection
                 make-reasoning-candidate reasoning-candidate-relations
                 reasoning-candidate-facts reasoning-candidate-rules
                 reasoning-candidate-query reasoning-candidate-limits
                 +max-relations+ +max-rules+ +max-input-facts+
                 +max-derived-facts+ +max-output-facts+)
        (only-in :gerbil-ascent/program/objects
                 gerbil-ascent-relation gerbil-ascent-atom
                 gerbil-ascent-negation gerbil-ascent-rule
                 gerbil-ascent-program gerbil-ascent-construct-inert-program
                 gerbil-ascent-variable
                 gerbil-ascent-wildcard gerbil-ascent-literal)
        (only-in :gerbil-ascent/program/scheme-checked
                 relational-where relational-compute relational-reducer))

(export scalar? candidate-variable? candidate-inspect candidate-program
        candidate-planner-path candidate-language-description)

(def (scalar? value)
  (or (exact-integer? value) (boolean? value) (symbol? value) (char? value)))

;; : (forall (a) (-> Symbol (List Datum) Datum a))
;;; Rejection exits inspection with a located diagnostic.
(def (reject code path detail)
  (raise
   (make-candidate-rejection
    (make-reasoning-diagnostic code path detail))))

;; : (-> Datum Boolean)
(def (candidate-variable? value)
  (and (symbol? value)
       (let (spelling (symbol->string value))
         (and (> (string-length spelling) 1)
              (char=? (string-ref spelling 0) #\?)))))

(def (candidate-term? value)
  (and (scalar? value)
       (not (eq? value '?))))

;;; Keep the data grammar restricted to fixed, inspectable operations from
;;; the trusted Scheme DSL. No candidate procedure or operator body runs.
;;; Clause indexes survive lowering so a rejected proposal can be revised
;;; without guessing which relation or body atom caused the failure.
(def (candidate-parse datum)
  (unless (and (reasoning-bounded-data? datum 16384 128)
               (list? datum) (pair? datum)
               (eq? (car datum) 'candidate)
               (<= (length (cdr datum)) 256))
    (reject 'invalid-candidate '(candidate) 'expected-inert-candidate-list))
  (let loop ((clauses (cdr datum)) (index 1)
             (relations []) (facts []) (rules [])
             (query #f) (limits #f))
    (if (null? clauses)
      (begin
        (unless query (reject 'missing-query '(query) 'required))
        (unless limits (reject 'missing-limits '(limits) 'required))
        (when (> (length relations) +max-relations+)
          (reject 'relation-limit '(relations) +max-relations+))
        (when (> (length rules) +max-rules+)
          (reject 'rule-limit '(rules) +max-rules+))
        (make-reasoning-candidate
         (reverse relations) (reverse facts) (reverse rules)
         query limits))
      (let ((clause (car clauses))
            (path (list 'clause index)))
        (unless (and (list? clause) (pair? clause)
                     (symbol? (car clause)))
          (reject 'invalid-clause path clause))
        (case (car clause)
          ((relation)
           (unless (and (= (length clause) 3)
                        (symbol? (cadr clause))
                        (exact-integer? (caddr clause))
                        (<= 0 (caddr clause)))
             (reject 'invalid-relation path clause))
           (loop (cdr clauses) (+ index 1)
                 (cons (cons (cadr clause) (caddr clause)) relations)
                 facts rules query limits))
          ((fact)
           (unless (and (>= (length clause) 2)
                        (symbol? (cadr clause))
                        (andmap (lambda (value)
                                  (and (scalar? value)
                                       (not (candidate-variable? value))
                                       (not (eq? value '?))))
                                (cddr clause)))
             (reject 'invalid-fact path clause))
           (loop (cdr clauses) (+ index 1) relations
                 (cons (vector (cadr clause) (cddr clause) index) facts)
                 rules query limits))
          ((rule)
           (unless (>= (length clause) 3)
             (reject 'invalid-rule path clause))
           (loop (cdr clauses) (+ index 1) relations facts
                 (cons (vector (cadr clause) (cddr clause) index) rules)
                 query limits))
          ((query)
           (when query (reject 'duplicate-query path clause))
           (unless (>= (length clause) 2)
             (reject 'invalid-query path clause))
           (loop (cdr clauses) (+ index 1) relations facts rules
                 (vector (cdr clause) index) limits))
          ((limits)
           (when limits (reject 'duplicate-limits path clause))
           (unless (and (= (length clause) 4)
                        (andmap (lambda (value)
                                  (and (exact-integer? value) (> value 0)))
                                (cdr clause))
                        (<= (cadr clause) +max-input-facts+)
                        (<= (caddr clause) +max-derived-facts+)
                        (<= (cadddr clause) +max-output-facts+))
             (reject 'invalid-limits path clause))
           (loop (cdr clauses) (+ index 1) relations facts rules query
                 (cdr clause)))
          (else
           (reject 'unsupported-construct path (car clause))))))))

;;; One inspection owns name resolution and source/derived write authority.
;;; Public candidate records stay inert; these indexes never escape inspection.
(defstruct candidate-declaration (arity source?))
(def (candidate-schema source derived)
  (let (schema (make-hash-table-eq))
    (for-each
     (lambda (entry)
       (unless (hash-get schema (car entry))
         (hash-put! schema (car entry)
                    (make-candidate-declaration (cadr entry) #t))))
     source)
    (for-each
     (lambda (entry)
       (when (hash-get schema (car entry))
         (reject 'duplicate-relation '(relations) (car entry)))
       (hash-put! schema (car entry)
                  (make-candidate-declaration (cdr entry) #f)))
     derived)
    schema))

(def (candidate-bind! bound term)
  (when (logic-variable? term) (hash-put! bound term #t))
  bound)

(def (atom-check atom schema path)
  (unless (and (list? atom) (pair? atom) (symbol? (car atom)))
    (reject 'invalid-atom path atom))
  (let (declaration (hash-get schema (car atom)))
    (unless declaration
      (reject 'unknown-relation path (car atom)))
    (unless (= (length (cdr atom)) (candidate-declaration-arity declaration))
      (reject 'arity-mismatch path (car atom)))
    (for-each
     (lambda (term position)
       (unless (candidate-term? term)
         (reject 'invalid-term (append path (list 'term position)) term)))
     (cdr atom) (iota (length (cdr atom)) 1))))

(def (logic-variable? value)
  (and (candidate-variable? value) (not (eq? value '?_))))

(def (require-bound-inputs inputs bound path)
  (for-each
   (lambda (input position)
     (unless (and (logic-variable? input) (hash-get bound input))
       (reject 'unbound-operator-input
               (append path (list 'input position)) input)))
   inputs (iota (length inputs) 1)))

(def +candidate-reducer-specs+ '((count 0) (sum 1) (min 1) (max 1)))

(def +candidate-operator-specs+
  '((where (even? 1) (< 2)) (compute (identity 1) (+ 2))))

;;; A fresh inert projection of the parser contract, never executable code.
;;; Operator admission and this public description share the same registry.
(def (candidate-language-description)
  (candidate-copy-pairs
   (list 'candidate-language 'v1
         '(forms (relation NAME ARITY) (fact SOURCE TERM ...)
                 (rule HEAD BODY ...) (query RELATION TERM ...)
                 (limits INPUT DERIVED OUTPUT))
         '(body (RELATION TERM ...) (not (RELATION TERM ...))
                (where (OP INPUT ...)) (compute OUTPUT (OP INPUT ...))
                (reduce OUTPUT (MODE INPUT ...) (RELATION TERM ...)))
         (cons 'operators +candidate-operator-specs+)
         (cons 'reducers +candidate-reducer-specs+)
         '(binding positive-atoms-bind negation-and-operators-read-bound
                   compute-and-reduce-bind-fresh)
         '(operator-inputs bound-variables-only)
         '(diagnostic-index-base 1)
         '(scope syntax-description-not-source-authority-or-task-intent))))

(def (checked-operation form mode bound path)
  (unless (and (list? form) (pair? form) (symbol? (car form)))
    (reject 'invalid-operator path form))
  (let ((operation (car form))
        (inputs (cdr form)))
    (let* ((tier (assq mode +candidate-operator-specs+))
           (spec (and tier (assq operation (cdr tier)))))
      (unless (and spec (= (length inputs) (cadr spec)))
        (reject 'unsupported-operator path form)))
    (require-bound-inputs inputs bound path)))

;;; Inspect body clauses in evaluation order. Positive atoms bind variables;
;;; negation and fixed scalar tests only read prior bindings; computation
;;; and reduction add one fresh binding. The planner remains authoritative
;;; for combined dependencies and aggregate stratum requirements.
(def (candidate-check-body-clause clause schema bound path)
  (unless (and (list? clause) (pair? clause) (symbol? (car clause)))
    (reject 'invalid-body-clause path clause))
  (case (car clause)
    ((not)
     (unless (= (length clause) 2)
       (reject 'invalid-negation path clause))
     (let (atom (cadr clause))
       (atom-check atom schema path)
       (for-each
        (lambda (term position)
          (when (and (logic-variable? term) (not (hash-get bound term)))
            (reject 'unsafe-negation
                    (append path (list 'term position)) term)))
        (cdr atom) (iota (length (cdr atom)) 1)))
     bound)
    ((where)
     (unless (= (length clause) 2)
       (reject 'invalid-filter path clause))
     (checked-operation (cadr clause) 'where bound path)
     bound)
    ((compute)
     (unless (and (= (length clause) 3)
                  (logic-variable? (cadr clause)))
       (reject 'invalid-computation path clause))
     (when (hash-get bound (cadr clause))
       (reject 'duplicate-binding path (cadr clause)))
     (checked-operation (caddr clause) 'compute bound path)
     (candidate-bind! bound (cadr clause)))
    ((reduce)
     (unless (and (= (length clause) 4)
                  (logic-variable? (cadr clause))
                  (list? (caddr clause))
                  (pair? (caddr clause)))
       (reject 'invalid-reduction path clause))
     (when (hash-get bound (cadr clause))
       (reject 'duplicate-binding path (cadr clause)))
     (let* ((mode (caaddr clause))
            (inputs (cdaddr clause))
            (atom (cadddr clause)))
       (unless (and (symbol? mode)
                    (let (spec (assq mode +candidate-reducer-specs+))
                      (and spec (= (length inputs) (cadr spec))))
                    (andmap logic-variable? inputs))
         (reject 'unsupported-reduction path (caddr clause)))
       (atom-check atom schema (append path '(aggregate)))
       (for-each
        (lambda (input)
          (unless (memq input (cdr atom))
            (reject 'reduction-input-absent path input)))
        inputs))
     (candidate-bind! bound (cadr clause)))
    (else
     (atom-check clause schema path)
     (for-each (cut candidate-bind! bound <>) (cdr clause))
     bound)))

;;; Inspection must resolve every symbol against the copied source schema
;;; before a planner sees the proposal. Only source names accept candidate
;;; facts; a rule may write only a newly declared derived relation.
;; : (-> ReasoningSnapshot Datum ReasoningCandidate)
(def (candidate-inspect snapshot candidate)
  (let* ((spec (candidate-parse candidate))
         (source (reasoning-snapshot-relations snapshot))
         (derived (reasoning-candidate-relations spec))
         (schema (candidate-schema source derived)))
    (for-each
     (lambda (fact)
       (let ((name (vector-ref fact 0))
             (row (vector-ref fact 1))
             (path (list 'clause (vector-ref fact 2))))
         (let (declaration (hash-get schema name))
           (unless (and declaration (candidate-declaration-source? declaration))
             (reject 'fact-needs-source path name))
           (unless (= (length row) (candidate-declaration-arity declaration))
             (reject 'arity-mismatch path name)))))
     (reasoning-candidate-facts spec))
    (for-each
     (lambda (rule)
       (let* ((head (vector-ref rule 0))
              (body (vector-ref rule 1))
              (path (list 'clause (vector-ref rule 2)))
              (bound (make-hash-table-eq)))
         (atom-check head schema (append path '(head)))
         (when (candidate-declaration-source? (hash-ref schema (car head)))
           (reject 'rule-writes-source (append path '(head)) (car head)))
         (for-each
          (lambda (clause position)
            (set! bound
              (candidate-check-body-clause
               clause schema bound (append path (list 'body position)))))
          body (iota (length body) 1))
         (for-each
          (lambda (term position)
            (cond
             ((eq? term '?_)
              (reject 'wildcard-head
                      (append path (list 'head 'term position)) term))
             ((and (candidate-variable? term)
                   (not (hash-get bound term)))
              (reject 'unbound-head-variable
                      (append path (list 'head 'term position)) term))))
          (cdr head) (iota (length (cdr head)) 1))))
     (reasoning-candidate-rules spec))
    (let* ((query (vector-ref (reasoning-candidate-query spec) 0))
           (path (list 'clause
                       (vector-ref (reasoning-candidate-query spec) 1))))
      (atom-check query schema path))
    (let ((source-count
           (apply + (map (lambda (entry) (length (caddr entry))) source)))
          (candidate-count (length (reasoning-candidate-facts spec))))
      (when (> (+ source-count candidate-count)
               (car (reasoning-candidate-limits spec)))
        (reject 'input-budget '(limits input) (+ source-count candidate-count))))
    spec))

(def (candidate-term->object term)
  (cond
   ((eq? term '?_) (gerbil-ascent-wildcard))
   ((candidate-variable? term) (gerbil-ascent-variable term))
   (else (gerbil-ascent-literal term))))

(def (candidate-atom->object atom)
  (gerbil-ascent-atom
   (car atom) (map candidate-term->object (cdr atom))))

(def (candidate-body->object clause)
  (case (car clause)
    ((not)
     (let (atom (cadr clause))
       (gerbil-ascent-negation
        (car atom) (map candidate-term->object (cdr atom)))))
    ((where)
     (relational-where (caadr clause) (cdadr clause)))
    ((compute)
     (relational-compute
      (cadr clause) (caaddr clause) (cdaddr clause)))
    ((reduce)
     (let ((operator (caddr clause))
           (atom (cadddr clause)))
       (relational-reducer
        (cadr clause) (car operator) (cdr operator)
        (car atom) (map candidate-term->object (cdr atom)))))
    (else (candidate-atom->object clause))))

;;; Group once, then restore each source's candidate order at publication.
;;; Rows and duplicate occurrences are retained; no source authority is added.
(def (candidate-fact-partition facts)
  (and (pair? facts)
       (let (groups (make-hash-table-eq))
         (for-each
          (lambda (fact)
            (with ((vector name row _) fact)
              (hash-put! groups name (cons row (hash-ref groups name [])))))
          facts)
         groups)))

;;; Lower the checked data into POO declarations with no caller procedures.
;;; The source-handle list marks only copied inputs as replaceable; derived
;;; relations remain private to this one attempt.
;; : (-> ReasoningSnapshot ReasoningCandidate RelationalProgram)
(def (candidate-program snapshot spec)
  (gerbil-ascent-construct-inert-program
   (cut candidate-lower-program snapshot spec)))

(def (candidate-lower-program snapshot spec)
  (let* ((source (reasoning-snapshot-relations snapshot))
         (facts (candidate-fact-partition (reasoning-candidate-facts spec)))
         (derived (reasoning-candidate-relations spec))
         (source-relations
          (map (lambda (entry)
                 (let (name (car entry))
                   (gerbil-ascent-relation
                    name (cadr entry)
                    (append (caddr entry)
                            (if facts (reverse (hash-ref facts name [])) [])))))
               source))
         (derived-relations
          (map (lambda (entry)
                 (gerbil-ascent-relation (car entry) (cdr entry) []))
               derived))
         (relations (append source-relations derived-relations))
         (rules
          (map (lambda (rule)
                 (gerbil-ascent-rule
                  (list (candidate-atom->object (vector-ref rule 0)))
                  (map candidate-body->object (vector-ref rule 1))))
               (reasoning-candidate-rules spec)))
         (limits (reasoning-candidate-limits spec)))
    (gerbil-ascent-program
     relations rules (car limits) (cadr limits) (caddr limits)
     (map car source))))

;;; Planner positions are zero-based in the lowered rule list. Map them
;;; back to the candidate's one-based source-clause and body positions.
(def (candidate-planner-path spec path)
  (if (and (list? path) (= (length path) 4)
           (eq? (car path) 'rule)
           (exact-integer? (cadr path))
           (<= 0 (cadr path))
           (< (cadr path) (length (reasoning-candidate-rules spec)))
           (memq (caddr path) '(body head))
           (exact-integer? (cadddr path)))
    (list 'clause
          (vector-ref
           (list-ref (reasoning-candidate-rules spec) (cadr path)) 2)
          (caddr path) (+ 1 (cadddr path)))
    path))
