(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/result::timestamp 1791687862)
  (begin
    (define gerbil-ascent/program/result#owned-publication::t
      (let ((__tmp34188 (list))
            (__tmp34187
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/result#owned-publication::t
         'owned-publication
         __tmp34188
         '(result snapshots sizes position-of)
         __tmp34187
         '#f)))
    (define gerbil-ascent/program/result#owned-publication?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/result#owned-publication::t)))
    (define gerbil-ascent/program/result#make-owned-publication
      (lambda _%$args14045%_
        (apply make-instance
               gerbil-ascent/program/result#owned-publication::t
               _%$args14045%_)))
    (define gerbil-ascent/program/result#owned-publication-result
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/result#owned-publication::t
         'result)))
    (define gerbil-ascent/program/result#owned-publication-snapshots
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/result#owned-publication::t
         'snapshots)))
    (define gerbil-ascent/program/result#owned-publication-sizes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/result#owned-publication::t
         'sizes)))
    (define gerbil-ascent/program/result#owned-publication-position-of
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/result#owned-publication::t
         'position-of)))
    (define gerbil-ascent/program/result#owned-publication-result-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/result#owned-publication::t
         'result)))
    (define gerbil-ascent/program/result#owned-publication-snapshots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/result#owned-publication::t
         'snapshots)))
    (define gerbil-ascent/program/result#owned-publication-sizes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/result#owned-publication::t
         'sizes)))
    (define gerbil-ascent/program/result#owned-publication-position-of-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/result#owned-publication::t
         'position-of)))
    (define gerbil-ascent/program/result#&owned-publication-result
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/result#owned-publication::t
         'result)))
    (define gerbil-ascent/program/result#&owned-publication-snapshots
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/result#owned-publication::t
         'snapshots)))
    (define gerbil-ascent/program/result#&owned-publication-sizes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/result#owned-publication::t
         'sizes)))
    (define gerbil-ascent/program/result#&owned-publication-position-of
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/result#owned-publication::t
         'position-of)))
    (define gerbil-ascent/program/result#&owned-publication-result-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/result#owned-publication::t
         'result)))
    (define gerbil-ascent/program/result#&owned-publication-snapshots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/result#owned-publication::t
         'snapshots)))
    (define gerbil-ascent/program/result#&owned-publication-sizes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/result#owned-publication::t
         'sizes)))
    (define gerbil-ascent/program/result#&owned-publication-position-of-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/result#owned-publication::t
         'position-of)))
    (define gerbil-ascent/program/result#gerbil-ascent-publication-size
      (lambda (_%publication14034%_ _%completed14035%_ _%name14036%_)
        (if (let ()
              (declare (not safe))
              (##structure-direct-instance-of?
               _%publication14034%_
               'gerbil-ascent/program/result#owned-publication::t))
            (let ((_%publication14038%_ _%publication14034%_))
              (if (eq? _%completed14035%_
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%publication14038%_
                          '1
                          '#f
                          '#f)))
                  (vector-ref
                   (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref
                      _%publication14038%_
                      '3
                      '#f
                      '#f))
                   ((let ()
                      (declare (not safe))
                      (##unchecked-structure-ref
                       _%publication14038%_
                       '4
                       '#f
                       '#f))
                    _%name14036%_))
                  '#f))
            '#f)))
    (define gerbil-ascent/program/result#gerbil-ascent-publication-reader
      (lambda (_%publication14022%_ _%completed14023%_)
        (if (let ()
              (declare (not safe))
              (##structure-direct-instance-of?
               _%publication14022%_
               'gerbil-ascent/program/result#owned-publication::t))
            (let ((_%publication14025%_ _%publication14022%_))
              (if (eq? _%completed14023%_
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%publication14025%_
                          '1
                          '#f
                          '#f)))
                  (lambda (_%name14032%_)
                    (gerbil-ascent/program/result#gerbil-ascent-snapshot-rows
                     (vector-ref
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%publication14025%_
                         '2
                         '#f
                         '#f))
                      ((let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%publication14025%_
                          '4
                          '#f
                          '#f))
                       _%name14032%_))))
                  '#f))
            '#f)))
    (define gerbil-ascent/program/result#gerbil-ascent-make-owned-result
      (lambda (_%names14010%_
               _%arity14011%_
               _%snapshots14012%_
               _%sizes14013%_
               _%representations14014%_
               _%observation14015%_
               _%position-of14016%_
               _%complete?14017%_
               _%session?14018%_)
        (let ((_%result14020%_
               (gerbil-ascent/program/result#gerbil-ascent-make-published-result
                _%names14010%_
                _%arity14011%_
                _%snapshots14012%_
                _%sizes14013%_
                _%representations14014%_
                _%observation14015%_
                _%position-of14016%_
                _%complete?14017%_
                _%session?14018%_)))
          (values _%result14020%_
                  (if _%session?14018%_
                      (let ()
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/program/result#owned-publication::t
                         _%result14020%_
                         _%snapshots14012%_
                         _%sizes14013%_
                         _%position-of14016%_))
                      '#f)))))
    (define gerbil-ascent/program/result#gerbil-ascent-publication-cache
      (lambda (_%count14008%_)
        (vector '#f
                (make-vector _%count14008%_ '#f)
                (make-vector _%count14008%_ '#f))))
    (define gerbil-ascent/program/result#gerbil-ascent-publish-rows__%
      (lambda (_%all13990%_ _%cache13991%_ _%sizes13992%_)
        (let ((_%snapshots13994%_
               (let ((__tmp34189 (vector-length _%all13990%_)))
                 (declare (not safe))
                 (##make-vector __tmp34189 '()))))
          (gerbil-ascent/program/result#publish-index!
           _%all13990%_
           (vector-ref _%cache13991%_ '1)
           (vector-ref _%cache13991%_ '2)
           _%snapshots13994%_
           '0
           _%sizes13992%_)
          _%snapshots13994%_)))
    (define gerbil-ascent/program/result#gerbil-ascent-publish-rows__0
      (lambda (_%all13999%_ _%cache14000%_)
        (let ((_%sizes14002%_ '#f))
          (gerbil-ascent/program/result#gerbil-ascent-publish-rows__%
           _%all13999%_
           _%cache14000%_
           _%sizes14002%_))))
    (define gerbil-ascent/program/result#gerbil-ascent-publish-rows
      (lambda _g34190_
        (let ((_g34191_ (let () (declare (not safe)) (##length _g34190_))))
          (cond ((let () (declare (not safe)) (##fx= _g34191_ 2))
                 (apply gerbil-ascent/program/result#gerbil-ascent-publish-rows__0
                        _g34190_))
                ((let () (declare (not safe)) (##fx= _g34191_ 3))
                 (apply gerbil-ascent/program/result#gerbil-ascent-publish-rows__%
                        _g34190_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/result#gerbil-ascent-publish-rows
                  _g34190_))))))
    (define gerbil-ascent/program/result#publish-index!
      (lambda (_%all13979%_
               _%roots13980%_
               _%ordered13981%_
               _%snapshots13982%_
               _%index13983%_
               _%sizes13984%_)
        (if (< _%index13983%_ (vector-length _%all13979%_))
            (begin
              (let ((_%rows13986%_ (vector-ref _%all13979%_ _%index13983%_)))
                (if (eq? _%rows13986%_
                         (vector-ref _%roots13980%_ _%index13983%_))
                    '#!void
                    (begin
                      (vector-set!
                       _%ordered13981%_
                       _%index13983%_
                       (if (let ()
                             (declare (not safe))
                             (##structure-instance-of?
                              _%rows13986%_
                              'gerbil-ascent/core/relation-view#relation-view::t))
                           _%rows13986%_
                           (let ((__tmp34193
                                  (let ((__tmp34194
                                         (lambda () (reverse _%rows13986%_))))
                                    (declare (not safe))
                                    (__make-promise __tmp34194)))
                                 (__tmp34192
                                  (if _%sizes13984%_
                                      (vector-ref
                                       _%sizes13984%_
                                       _%index13983%_)
                                      (length _%rows13986%_))))
                             (declare (not safe))
                             (gerbil-ascent/core/relation-view#gerbil-ascent-lazy-explicit-view
                              __tmp34193
                              __tmp34192))))
                      (vector-set!
                       _%roots13980%_
                       _%index13983%_
                       _%rows13986%_)))
                (vector-set!
                 _%snapshots13982%_
                 _%index13983%_
                 (vector-ref _%ordered13981%_ _%index13983%_)))
              (gerbil-ascent/program/result#publish-index!
               _%all13979%_
               _%roots13980%_
               _%ordered13981%_
               _%snapshots13982%_
               (+ _%index13983%_ '1)
               _%sizes13984%_))
            '#!void)))
    (define gerbil-ascent/program/result#gerbil-ascent-snapshot-rows
      (lambda (_%rows13974%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%rows13974%_
               'gerbil-ascent/core/relation-view#relation-view::t))
            (let ()
              (declare (not safe))
              (gerbil-ascent/core/relation-view#gerbil-ascent-view-rows
               _%rows13974%_))
            (if (promise? _%rows13974%_)
                (force _%rows13974%_)
                _%rows13974%_))))
    (define gerbil-ascent/program/result#gerbil-ascent-public-snapshot-rows
      (lambda (_%snapshot13967%_ _%session?13968%_)
        (let ((_%stored13970%_
               (gerbil-ascent/program/result#gerbil-ascent-snapshot-rows
                _%snapshot13967%_)))
          (if (and _%session?13968%_
                   (not (let ()
                          (declare (not safe))
                          (##structure-instance-of?
                           _%snapshot13967%_
                           'gerbil-ascent/core/relation-view#relation-view::t))))
              (map (lambda (_%row13972%_) (map identity _%row13972%_))
                   _%stored13970%_)
              _%stored13970%_))))
    (define gerbil-ascent/program/result#gerbil-ascent-snapshot-sizes
      (lambda (_%names13961%_ _%snapshots13962%_)
        (let ((__tmp34197
               (lambda (_%name13964%_ _%rows13965%_)
                 (cons _%name13964%_
                       (if (let ()
                             (declare (not safe))
                             (##structure-instance-of?
                              _%rows13965%_
                              'gerbil-ascent/core/relation-view#relation-view::t))
                           (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%rows13965%_
                              '5
                              '#f
                              '#f))
                           (length (gerbil-ascent/program/result#gerbil-ascent-snapshot-rows
                                    _%rows13965%_))))))
              (__tmp34196 (vector->list _%names13961%_))
              (__tmp34195 (vector->list _%snapshots13962%_)))
          (declare (not safe))
          (##map __tmp34197 __tmp34196 __tmp34195))))
    (define gerbil-ascent/program/result#gerbil-ascent-result-observation
      (lambda (_%affected13952%_
               _%names13953%_
               _%active13954%_
               _%rule-ticks13955%_)
        (vector (if _%affected13952%_
                    'stratified-dependency-invalidation
                    'stratified-semi-naive)
                (if _%affected13952%_
                    (let ((__tmp34200
                           (lambda (_%index13957%_)
                             (if (vector-ref _%affected13952%_ _%index13957%_)
                                 '#f
                                 (vector-ref _%names13953%_ _%index13957%_))))
                          (__tmp34198
                           (let ((__tmp34199 (vector-length _%names13953%_)))
                             (declare (not safe))
                             (##iota __tmp34199))))
                      (declare (not safe))
                      (filter-map__0 __tmp34200 __tmp34198))
                    '())
                (let ((__tmp34201
                       (let ((__tmp34202 (vector->list _%active13954%_)))
                         (declare (not safe))
                         (##map length __tmp34202))))
                  (declare (not safe))
                  (##apply + __tmp34201))
                (if _%rule-ticks13955%_
                    (let ((__tmp34204
                           (lambda (_%ticks13959%_)
                             (quotient
                              (* _%ticks13959%_ '1000000000)
                              (jiffies-per-second))))
                          (__tmp34203 (vector->list _%rule-ticks13955%_)))
                      (declare (not safe))
                      (##map __tmp34204 __tmp34203))
                    '#f))))
    (define gerbil-ascent/program/result#gerbil-ascent-visit-snapshot!
      (lambda (_%snapshot13939%_
               _%width13940%_
               _%columns13941%_
               _%key13942%_
               _%consume13943%_)
        (if (and (list? _%columns13941%_)
                 (list? _%key13942%_)
                 (= (let () (declare (not safe)) (##length _%columns13941%_))
                    (let () (declare (not safe)) (##length _%key13942%_)))
                 (let ((__tmp34205
                        (lambda (_%column13945%_)
                          (and (exact-integer? _%column13945%_)
                               (<= '0 _%column13945%_)
                               (< _%column13945%_ _%width13940%_)))))
                   (declare (not safe))
                   (andmap__0 __tmp34205 _%columns13941%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"ASCENT result selection requires in-range columns and matching keys")))
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%snapshot13939%_
               'gerbil-ascent/core/relation-view#relation-view::t))
            (let ((__tmp34206
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/core/relation-view#gerbil-ascent-view-select
                      _%snapshot13939%_
                      _%columns13941%_
                      _%key13942%_))))
              (declare (not safe))
              (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
               _%consume13943%_
               __tmp34206))
            (for-each
             (lambda (_%row13947%_)
               (if (let ((__tmp34207
                          (lambda (_%column13949%_ _%value13950%_)
                            (equal? (list-ref _%row13947%_ _%column13949%_)
                                    _%value13950%_))))
                     (declare (not safe))
                     (andmap__1 __tmp34207 _%columns13941%_ _%key13942%_))
                   (_%consume13943%_ (map identity _%row13947%_))
                   '#!void))
             (gerbil-ascent/program/result#gerbil-ascent-snapshot-rows
              _%snapshot13939%_)))))
    (define gerbil-ascent/program/result#gerbil-ascent-make-published-result
      (lambda (_%names13844%_
               _%arity13845%_
               _%snapshots13846%_
               _%sizes13847%_
               _%representations13848%_
               _%observation13849%_
               _%position-of13850%_
               _%complete?13851%_
               _%session?13852%_)
        (let ((__obj34186
               (let ()
                 (declare (not safe))
                 (##structure
                  clan/poo/object#object::t
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f))))
          (let ((__tmp34209
                 (list (cons 'relation-names
                             (let ((__tmp34210
                                    (lambda (_%self13874%_)
                                      (vector->list _%names13844%_))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34210)))
                       (cons 'finished
                             (let ((__tmp34211
                                    (lambda (_%self13881%_)
                                      _%complete?13851%_)))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34211)))
                       (cons 'evaluation-path
                             (let ((__tmp34212
                                    (lambda (_%self13886%_)
                                      (vector-ref _%observation13849%_ '0))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34212)))
                       (cons 'reused-relations
                             (let ((__tmp34213
                                    (lambda (_%self13891%_)
                                      (vector-ref _%observation13849%_ '1))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34213)))
                       (cons 'active-rule-count
                             (let ((__tmp34214
                                    (lambda (_%self13896%_)
                                      (vector-ref _%observation13849%_ '2))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34214)))
                       (cons 'rule-time-nanoseconds
                             (let ((__tmp34215
                                    (lambda (_%self13901%_)
                                      (vector-ref _%observation13849%_ '3))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34215)))
                       (cons 'representation-observation
                             (let ((__tmp34216
                                    (lambda (_%self13906%_)
                                      (lambda ()
                                        (map (lambda (_%row13912%_)
                                               (map values _%row13912%_))
                                             _%representations13848%_)))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34216)))
                       (cons 'relation-sizes
                             (let ((__tmp34217
                                    (lambda (_%self13914%_)
                                      (lambda ()
                                        (let ((__tmp34219
                                               (vector->list _%names13844%_))
                                              (__tmp34218
                                               (vector->list _%sizes13847%_)))
                                          (declare (not safe))
                                          (##map cons
                                                 __tmp34219
                                                 __tmp34218))))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34217)))
                       (cons 'visit-rows
                             (let ((__tmp34220
                                    (lambda (_%self13920%_)
                                      (lambda (_%name13925%_
                                               _%columns13926%_
                                               _%key13927%_
                                               _%consume13928%_)
                                        (let ((_%index13930%_
                                               (_%position-of13850%_
                                                _%name13925%_)))
                                          (gerbil-ascent/program/result#gerbil-ascent-visit-snapshot!
                                           (vector-ref
                                            _%snapshots13846%_
                                            _%index13930%_)
                                           (vector-ref
                                            _%arity13845%_
                                            _%index13930%_)
                                           _%columns13926%_
                                           _%key13927%_
                                           _%consume13928%_))))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34220)))
                       (cons 'rows-of
                             (let ((__tmp34221
                                    (lambda (_%self13932%_)
                                      (lambda (_%name13937%_)
                                        (gerbil-ascent/program/result#gerbil-ascent-public-snapshot-rows
                                         (vector-ref
                                          _%snapshots13846%_
                                          (_%position-of13850%_ _%name13937%_))
                                         _%session?13852%_)))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp34221)))))
                (__tmp34208 (list)))
            (declare (not safe))
            (clan/poo/object#object:::init!__%
             '#f
             '()
             __tmp34209
             __tmp34208
             __obj34186))
          __obj34186)))))
