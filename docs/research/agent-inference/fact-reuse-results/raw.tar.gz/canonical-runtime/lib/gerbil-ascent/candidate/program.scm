(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/candidate/datum")
    (load-module "gerbil-ascent/candidate/types")
    (load-module "gerbil-ascent/program/objects")
    (load-module "gerbil-ascent/program/scheme-checked"))
  (load-module "gerbil-ascent/candidate/program~0"))
