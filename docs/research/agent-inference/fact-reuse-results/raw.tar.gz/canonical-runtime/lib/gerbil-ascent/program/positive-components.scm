(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/program/component-plan")
    (load-module "gerbil-ascent/program/component-worker")
    (load-module "gerbil-ascent/program/actor-round"))
  (load-module "gerbil-ascent/program/positive-components~0"))
