# SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
"""Paid bounded pilot: Python owns byte IO/cost; frozen Scheme owns semantics."""
import argparse, hashlib, json, os, selectors, subprocess, time, shutil
from datetime import datetime, timezone
from pathlib import Path
from .model_study import provider, response_outcome
from .movie_study import provider_key
from ascent_engine.conversation import ResponseHistory
ROOT = Path.cwd().resolve()
BASE = ROOT / '.cache/ascent/crosspath-search'
SNAP = BASE / 'snapshot'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def save(p, x):
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n')

class Native:

    def __init__(self):
        env = os.environ.copy()
        env['GERBIL_PATH'] = str(SNAP / '.gerbil')
        env['GERBIL_LOADPATH'] = str(SNAP / '.gerbil/lib')
        env['LIBRARY_PATH'] = subprocess.check_output(['brew', '--prefix', 'openssl@3'], text=True).strip() + '/lib'
        for k in ('CC', 'CFLAGS', 'CPPFLAGS', 'LDFLAGS', 'CPATH', 'C_INCLUDE_PATH', 'CPLUS_INCLUDE_PATH', 'NIX_CFLAGS_COMPILE', 'NIX_LDFLAGS', 'DEVELOPER_DIR', 'SDKROOT'):
            env.pop(k, None)
        self.err = (BASE / 'native-stderr.log').open('a')
        self.p = subprocess.Popen([str(SNAP / '.gerbil/bin/crosspath-search'), '-:max-heap=1G,debug=q'], cwd=SNAP, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.err, text=True, bufsize=1)

    def call(self, **kw):
        began = time.monotonic()
        self.p.stdin.write(json.dumps(kw) + '\n')
        self.p.stdin.flush()
        s = selectors.DefaultSelector()
        s.register(self.p.stdout, selectors.EVENT_READ)
        if not s.select(20):
            self.close()
            raise TimeoutError('native reply deadline')
        s.close()
        line = self.p.stdout.readline()
        if not line:
            raise RuntimeError('native exited; see native-stderr.log')
        r = json.loads(line)
        if 'error' in r:
            raise RuntimeError(r['error'])
        return (r, time.monotonic() - began)

    def close(self):
        if self.p.poll() is None:
            self.p.terminate()
            try:
                self.p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.p.kill()
                self.p.wait(timeout=5)
        self.err.close()
def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False)

def input_reserve(request):
    return len(canonical(request).encode()) + 4096 + 128 * len(request['input'])

def charge_usage(usage):
    if not isinstance(usage, dict) or not all((type(usage.get(k)) is int and usage[k] >= 0 for k in ('input_tokens', 'output_tokens'))):
        raise ValueError('missing_usage_budget_unknown')
    total = usage['input_tokens'] + usage['output_tokens']
    if 'total_tokens' in usage and usage['total_tokens'] != total:
        raise ValueError('inconsistent_total_usage')
    for field, detail, limit in [('output_tokens_details', 'reasoning_tokens', 'output_tokens'), ('input_tokens_details', 'cached_tokens', 'input_tokens')]:
        value = usage.get(field, {}).get(detail) if isinstance(usage.get(field, {}), dict) else None
        if value is not None and (type(value) is not int or not 0 <= value <= usage[limit]):
            raise ValueError('inconsistent_usage_breakdown')
    return total

import random, itertools

EDGES = [[0,2],[1,2],[2,4],[2,5],[4,7],[5,7],[3,6],[6,8],[7,9],[8,9],[9,11],[10,11]]
NEEDS = [[i,*v] for i,v in enumerate([(0,7,1,9),(2,9,3,11),(4,11,5,9),(0,11,3,9),(1,7,6,11),(2,7,8,11),(3,8,9,11),(0,9,10,11),(0,8,1,7),(3,7,2,9),(4,8,5,11),(10,9,0,7)])]

def task(seed, label, stages=7):
    rng=random.Random(seed)
    options=[{'id':s*5+j,'stage':s,'fragment':(s+j*2)%8 if j<4 else 8+s%4,
              'cost':rng.randint(3,12),'risk':rng.randint(1,8),
              'values':[rng.randint(15,45),rng.randint(15,45)]} for s in range(stages) for j in range(5)]
    bonuses=[]
    for s in range(stages):
        for t in range(s+1,stages):
            for _ in range(2):
                bonuses.append([s*5+rng.randrange(4),t*5+rng.randrange(4),rng.randint(4,23)])
    goals=[{'index':i,'stages':stages,'costLimit':stages*8-i*2,'riskLimit':stages*5+i,
            'bonuses':bonuses if i==0 else [[a,b,28-v] for a,b,v in bonuses]} for i in range(2)]
    return {'id':label,'edges':EDGES,'needs':NEEDS,'options':options,'goals':goals}
CASES=[task(71439,'shared-cert-search-1'),task(92781,'shared-cert-search-2')]
TOOLS=[{'type':'function','name':name,'description':desc,'parameters':{'type':'object','properties':props,'required':list(props),'additionalProperties':False}} for name,desc,props in [
 ('fragment','Check conjunction F{id}, returning two independently checked path requirements and a source-bound certificate.',{'id':{'type':'integer'}}),
 ('inspect','Check a partial choice (one option per ordered stage); return feasible next options. No optimum access.',{'selection':{'type':'array','items':{'type':'integer'}}}),
 ('evaluate','Check complete selection; return value/cost/risk. Maximize value, obey budgets and fragment eligibility.',{'selection':{'type':'array','items':{'type':'integer'}}}),
 ('submit','Submit best complete selection.',{'selection':{'type':'array','items':{'type':'integer'}}})]]
INSTRUCTIONS='''Search for a high-value complete plan: choose exactly one option per stage, in stage order. Option is eligible iff BOTH directed paths of its fragment F{id} exist in the original source graph. Paths require at least one edge. Costs and risks add, obey both limits. Value sums current goal values plus every bonus whose two options are selected. Maximize value. Different branches deliberately share conjunction fragments and their path derivations. Use verified facts when available; they are valid only for this source digest. A reference to an established fact does not require a new derivation. Reason about eligibility and useful alternatives, delegate arithmetic and prefix checks to tools, do not internally enumerate all combinations. In your first response evaluate at least one complete candidate and inspect two different prefixes. At most two reasoning construction/refinement calls then one non-thinking final submit. The controller gives final submit only best evaluated candidate, never optimum. Same total budget 65536 gross input+output tokens including thinking, all repeated inputs and evidence; at most 32 tool calls, 8192 output tokens per construction call. For auditability, when your reasoning establishes or reuses an eligibility claim, identify F{id}, and path endpoints. Distinguish a derivation from simply citing a checked result; do not invent derivations merely to satisfy audit instructions. Optimize best found, not proof of global optimum.'''
ANNOTATION_RUBRIC='''Annotate ONLY the supplied model reasoning text, in chronological order. You are blind to experiment arm, grade and token use. F{id} means BOTH directed path requirements specified in needs. Extract short EXACT contiguous quotes containing actual reasoning about those path facts/conjunctions, not unrelated value arithmetic. For each quote give fragment integer id (or null if only a path is mentioned), claim string, paths as endpoint integer pairs, kind: derive, reuse, mention, conditional_recheck, uncertain. Add ready boolean for a conjunction conclusion, otherwise null. Add premiseEdges: the actual ordered direct edges stated in this quote as support (empty if support is only the two path requirements). Do not silently fill missing edge chains from source data. derive requires a conclusion plus actual support/premise chain or conjunction reasoning, not merely listing a known truth. reuse explicitly cites an established/checkable result without deriving it. mention has no inference. conditional_recheck depends on a changed selection/budget/goal condition and is not duplicate proof. uncertain is ambiguous. Set prior to index of an earlier annotation ONLY when this is a new derivation of the SAME conclusion from SAME premises and SAME source context; then kind must be derive. First derivation has prior null; two different branches with same source-bound qualification can be duplicates; simply restating an ID is not. Never infer unseen thinking. Include every explicit relevant episode you can identify, retaining uncertain cases. Quotes must occur verbatim in the text; occurrence is zero-based occurrence number when same quote occurs multiple times. Claim truth is not your authority: native raw-source check validates endpoints/fragment separately. Omit an episode rather than invent an absent span. Return annotations via annotate tool. Full text is reviewed even if truncated by provider; completeness of semantic extraction is unvalidated.'''
ANNOTATOR_TOOL={'type':'function','name':'annotate','description':'Record source-anchored reasoning episodes.','parameters':{'type':'object','properties':{'annotations':{'type':'array','items':{'type':'object','properties':{'quote':{'type':'string'},'occurrence':{'type':'integer'},'fragment':{'type':['integer','null']},'claim':{'type':'string'},'ready':{'type':['boolean','null']},'premiseEdges':{'type':'array','items':{'type':'array','items':{'type':'integer'}}},'paths':{'type':'array','items':{'type':'array','items':{'type':'integer'}}},'kind':{'type':'string','enum':['derive','reuse','mention','conditional_recheck','uncertain']},'prior':{'type':['integer','null']},'explanation':{'type':'string'}},'required':['quote','occurrence','fragment','claim','ready','premiseEdges','paths','kind','prior','explanation'],'additionalProperties':False}}},'required':['annotations'],'additionalProperties':False}}
PRODUCERS=['tools/crosspath-search.ss','tools/crosspath-search-oracle.ss','tools/crosspath-search-build.ss','python/src/ascent_test_support/crosspath_search.py','python/src/ascent_test_support/crosspath_annotation.py','python/src/ascent_test_support/crosspath_report.py','python/src/ascent_test_support/model_study.py','python/src/ascent_test_support/movie_study.py','python/src/ascent_engine/conversation.py']

def init(native,c,arm):
    return native.call(op='init',identity=c['id'],arm=arm,edges=c['edges'],needs=c['needs'],options=c['options'])[0]

def packet(native,folder):
    raw,seconds=native.call(op='packet')
    cert=raw['certificate'];payload=canonical(cert).encode();h=sha(payload)
    store=folder/'proof-store';store.mkdir(exist_ok=True);(store/(h+'.json')).write_bytes(payload)
    ready=next(x[2] for x in cert['finiteClosure'] if x[0]=='ready')
    evidence={'sourceDigest':cert['sourceDigest'],'certificateSha256':h,'readyFragments':sorted(x[0] for x in ready),'finiteComplete':True,
              'candidateDigest':cert['candidateDigest'],'query':cert['query'],'roots':sorted(cert['roots']),
              'columns':['id','kind','relation','row','ruleOrSourceIndex','inputs'],
              'derivationNodes':[[n[k] for k in ('id','kind','relation','row','ruleOrSourceIndex','inputs')] for n in sorted(cert['nodes'],key=lambda n:n['id'])]}
    return evidence,{'reused':raw['reused'],'nativeSeconds':seconds,'proofSha256':h,'proofBytes':len(payload)}

def qualify():
    receipts=[];pairs=[];ns=Native()
    try:
        hand={'id':'hand-contract','edges':[[0,1],[1,2]],'needs':[[0,0,1,1,2],[1,0,3,1,2]],
              'options':[{'id':0,'stage':0,'fragment':0,'cost':2,'risk':1,'values':[3,6]},
                         {'id':1,'stage':0,'fragment':1,'cost':1,'risk':1,'values':[99,99]},
                         {'id':2,'stage':1,'fragment':0,'cost':3,'risk':1,'values':[4,9]},
                         {'id':3,'stage':1,'fragment':0,'cost':5,'risk':6,'values':[99,99]}]}
        g={'index':0,'stages':2,'costLimit':5,'riskLimit':2,'bonuses':[[0,2,7]]}
        init(ns,hand,'fresh');check=ns.call(op='grade',goal=g,selection=[0,2])[0]
        if not (check['valid'] and check['value']==14 and check['cost']==5 and check['risk']==2 and check['gap']==0 and check['oracle']['feasibleLeaves']==1):raise RuntimeError('hand arithmetic/budget mismatch')
        for bad in ([2,0],[0,0],[1,2],[0,3],[0,99],[]):
            if ns.call(op='evaluate',goal=g,selection=bad)[0]['valid']:raise RuntimeError('invalid candidate accepted')
        receipts.append({'handContract':check,'invalidCases':6})
        # Exhaustive unpruned enumeration vs resource-pruned oracle, all raw source.
        for seed in range(10):
            c=task(seed,'qualification-'+str(seed),stages=3);init(ns,c,'fresh')
            receipts.append(ns.call(op='qualify',goal=c['goals'][0])[0])
        for c in CASES:
            expected=None;source=None
            for arm in ('fresh','retained','baseline'):
                source=init(ns,c,arm)
                folder=BASE/'qualification-packets'/c['id']/arm;folder.mkdir(parents=True,exist_ok=False)
                a,ar=packet(ns,folder);b,br=packet(ns,folder)
                if a!=b or ar['reused'] or br['reused']!=(arm=='retained'):raise RuntimeError('packet/state mismatch')
                if expected is not None and expected!=a:raise RuntimeError('arm evidence differs')
                expected=a
                for f in range(12):
                    raw,_=ns.call(op='fragment',id=f)
                    # Native qualification below checks full enumerators; fragment facts vs native raw oracle probes.
                    probe={'index':0,'stages':1,'costLimit':100,'riskLimit':100,'bonuses':[]}
                    tmp={'id':'probe','edges':c['edges'],'needs':c['needs'],'options':[{'id':0,'stage':0,'fragment':f,'cost':1,'risk':1,'values':[1,1]}]}
                    fresh=Native()
                    try:
                        init(fresh,tmp,'baseline');truth=fresh.call(op='evaluate',goal=probe,selection=[0])[0]['valid']
                    finally:fresh.close()
                    if raw['ready']!=truth or raw['ready']!=(f in a['readyFragments']):raise RuntimeError('ASCENT/raw-source fact mismatch')
            init(ns,c,'fresh')
            oracle=[ns.call(op='oracle',goal=g)[0] for g in c['goals']]
            if any(x['feasibleLeaves']<500 for x in oracle):raise RuntimeError('search space too small')
            pairs.append({'task':c['id'],'packetSha256':sha(canonical(expected).encode()),'sourceDigest':source['sourceDigest'],'oracle':oracle})
        # Cyclic source and reflexivity boundary: positive-length cycle supports 0->0; empty graph does not.
        for edge,truth in [([],False),([[0,1],[1,0]],True)]:
            c={'id':'cycle-check','edges':edge,'needs':[[0,0,0,0,1]],'options':[{'id':0,'stage':0,'fragment':0,'cost':1,'risk':1,'values':[7,7]}]}
            init(ns,c,'fresh');raw,_=ns.call(op='fragment',id=0)
            if raw['ready']!=truth:raise RuntimeError('cycle/reflexivity mismatch')
        save(BASE/'qualification.json',{'schema':'ascent.crosspath.qualification.v1','enumeratorChecks':receipts,'matchedPackets':pairs,'cycleChecks':2})
    finally:ns.close()
    print('CROSSPATH-QUALIFICATION-OK',flush=True)

def bound_files():
    files={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in map(lambda x:ROOT/x,PRODUCERS)}
    for p in sorted((SNAP/'.gerbil/lib').rglob('*')):
        if p.is_file() and not p.name.endswith('.lock'):files[str(p.relative_to(ROOT))]=sha(p.read_bytes())
    for p in [SNAP/'.gerbil/bin/crosspath-search',*sorted((SNAP/'candidate').glob('*.ss'))]:
        files[str(p.relative_to(ROOT))]=sha(p.read_bytes())
    for name in ('crosspath-search.ss','crosspath-search-oracle.ss','crosspath-search-build.ss'):
        p=SNAP/'tools'/name
        if p.read_bytes()!=(ROOT/'tools'/name).read_bytes():raise RuntimeError('native source differs')
        files[str(p.relative_to(ROOT))]=sha(p.read_bytes())
    for p in (SNAP/'candidate').glob('*.ss'):
        if p.read_bytes()!=(ROOT/'candidate'/p.name).read_bytes():raise RuntimeError('candidate kernel source drift')
    return files

def freeze():
    path=BASE/'frozen-plan.json'
    if path.exists():raise RuntimeError('frozen plan already exists; create a new study for changes')
    q=BASE/'qualification.json'
    order=[{'case':c['id'],'arm':a} for i,c in enumerate(CASES) for a in (['baseline','fresh','retained'] if i==0 else ['retained','fresh','baseline'])]
    plan={'schema':'ascent.crosspath.v1','frozenAtUtc':datetime.now(timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
          'cases':CASES,'order':order,'model':'deepseek-flash','reasoningEffort':'low','finalReasoningEffort':'none','totalTokenBudget':65536,'perCallOutputCap':8192,'finalOutputCap':2048,'calls':3,'toolActions':32,
          'instructions':INSTRUCTIONS,'tools':TOOLS,'annotationRubric':ANNOTATION_RUBRIC,'annotatorTool':ANNOTATOR_TOOL,'annotationOutputCap':4096,
          'qualificationSha256':sha(q.read_bytes()),'binding':bound_files(),
          'inputReservation':'compact request UTF-8 bytes +4096 +128 per input item; empirical conservative reserve, actual provider gross usage authoritative; fail-stop on overshoot/unknown usage. Prefix discounts do not discount token budget.',
          'qualityEndpoint':'best independently verified candidate and submitted candidate separately; never successful task without valid submit; retain censoring/errors/missing submission.',
          'buildScope':'New native bridge/independent raw-source exhaustive grader against inherited frozen production candidate kernel and dependencies; current candidate source bytes checked; not full checkout build.',
          'causalBoundary':'Baseline sees raw task/edges/needs but no initial admitted packet; fragment tool available in all arms. Fresh/retained have byte-identical packets and policy: state-only contrast measures native work; stochastic thinking differences are descriptive.',
          'annotationScope':'Direct external model reasoning text, blinded same-provider non-thinking annotator, source anchored exact quotes and prior links, native truth checks; extraction completeness/inter-rater agreement not established. No hidden/unreturned thought inferred. Annotation cost separate measurement overhead, never solver budget.',
          'failurePolicy':'Exclusive raw files, no solver or annotation retries, unknown usage/invalid spans retained; no post-outcome task or rubric changes.',
          'design':'2 fixed seven-stage tasks, 2 changed goals each, 3 arms, 12 phases. Two construction/refinement calls and one final submit. No paid calibration or task selection.'}
    save(path,plan);(BASE/'frozen-plan.sha256').write_text(sha(path.read_bytes())+'\n')
    print('CROSSPATH-FROZEN',sha(path.read_bytes()),flush=True)

def verify(plan):
    if sha((BASE/'frozen-plan.json').read_bytes())!=(BASE/'frozen-plan.sha256').read_text().strip():raise RuntimeError('frozen plan drift')
    if sha((BASE/'qualification.json').read_bytes())!=plan['qualificationSha256']:raise RuntimeError('qualification drift')
    for p,h in plan['binding'].items():
        if sha((ROOT/p).read_bytes())!=h:raise RuntimeError('bound producer/artifact drift '+p)
    for p in (SNAP/'candidate').glob('*.ss'):
        if p.read_bytes()!=(ROOT/'candidate'/p.name).read_bytes():raise RuntimeError('current candidate drift')

def thinking_text(meta):
    terminal=meta.get('terminal') or {}
    text='\n'.join(x.get('text','') for item in terminal.get('output',[]) if item.get('type')=='reasoning' for x in item.get('content',[]) if x.get('type')=='reasoning_text')
    # Incomplete output may lack a terminal reasoning item; recover exact stream text deltas separately.
    return text

def run_phase(plan,c,phase,arm,native,folder):
    folder.mkdir()
    evidence=None;build=None
    if arm!='baseline':
        evidence,build=packet(native,folder)
        exp=next(x['packetSha256'] for x in json.loads((BASE/'qualification.json').read_text())['matchedPackets'] if x['task']==c['id'])
        if sha(canonical(evidence).encode())!=exp:raise RuntimeError('packet differs from qualification')
    q=canonical({'task':c['id'],'source':{'edges':c['edges'],'needs':c['needs']},'options':c['options'],'goal':c['goals'][phase],'evidence':evidence,'guidance':'New goal; reset conversation, same source. Maximize value under two budgets.'})
    save(folder/'initial-input.json',json.loads(q))
    history=ResponseHistory(q);used=0;best=None;submitted=None;seen=set();key=provider_key()
    row={'case':c['id'],'phase':phase,'arm':arm,'packet':build,'initialInputSha256':sha(q.encode()),'calls':[],'tools':[],'failure':None,'totalTokenBudget':plan['totalTokenBudget']}
    for turn in range(plan['calls']):
        final=turn==plan['calls']-1
        if final:history.append_feedback({'instruction':'Submit best evaluated complete candidate now. No further optimization.','bestEvaluated':best[1] if best else None,'bestValue':best[0] if best else None})
        request={'model':plan['model'],'input':history.input(),'instructions':plan['instructions'],'tools':plan['tools'],'tool_choice':{'type':'function','name':'submit'} if final else 'auto','reasoning':{'effort':plan['finalReasoningEffort'] if final else plan['reasoningEffort']},'stream':True,'store':False}
        reserve=input_reserve(request);cap=min(plan['finalOutputCap'] if final else plan['perCallOutputCap'],plan['totalTokenBudget']-used-reserve)
        if cap<256 or len(row['tools'])>=plan['toolActions']:
            row['failure']='total_budget_reservation_stop';break
        request['max_output_tokens']=cap;save(folder/f'{turn}.request.json',request)
        _,meta=provider(request,key,folder/f'{turn}.response.json');term=meta.get('terminal') or {};usage=term.get('usage')
        call={'turn':turn,'usage':usage,'inputReserve':reserve,'outputCap':cap,'seconds':meta['providerSeconds'],'outcome':response_outcome(meta),'responseFile':str((folder/f'{turn}.response.json').relative_to(BASE))}
        row['calls'].append(call)
        text=thinking_text(meta);(folder/f'{turn}.thinking.txt').write_text(text)
        call['thinkingSha256']=sha(text.encode());call['thinkingChars']=len(text)
        try:
            used+=charge_usage(usage)
            if usage['input_tokens']>reserve or usage['output_tokens']>cap or used>plan['totalTokenBudget']:row['failure']='budget_protocol_violation'
        except ValueError as e:row['failure']=str(e)
        save(folder/'receipt.json',row)
        if row['failure']:break
        if meta.get('error') or term.get('status')!='completed':row['failure']=call['outcome'];break
        try:calls=history.append_response(term)
        except Exception as e:row['failure']='invalid_conversation:'+str(e);break
        if not calls:row['failure']='no_submit';break
        for fc in calls:
            log={'name':fc['name'],'rawArguments':fc['arguments']};name=fc['name']
            try:
                args=json.loads(fc['arguments']);log['arguments']=args;sig=(name,canonical(args));log['duplicateToolRequest']=sig in seen;seen.add(sig)
                if len(row['tools'])>=plan['toolActions']:result={'error':'tool budget exhausted'}
                elif name=='fragment':
                    raw,seconds=native.call(op='fragment',**args);cert=raw.pop('certificate');payload=canonical(cert).encode();h=sha(payload)
                    store=folder/'proof-store';store.mkdir(exist_ok=True);(store/(h+'.json')).write_bytes(payload)
                    log.update(nativeSeconds=seconds,nativeReused=raw.pop('reused'),proofSha256=h)
                    need=next(n for n in c['needs'] if n[0]==args['id']);result={**raw,'requirements':[need[1:3],need[3:5]],'certificateSha256':h}
                elif name in ('inspect','evaluate','submit'):
                    result,seconds=native.call(op='inspect' if name=='inspect' else 'evaluate',goal=c['goals'][phase],**args);log['nativeSeconds']=seconds
                    if name!='inspect' and result['valid'] and (best is None or result['value']>best[0]):best=(result['value'],args['selection'])
                    if name=='submit':submitted=args['selection']
                else:raise ValueError('unknown tool')
            except Exception as e:result={'error':str(e)[:2000]};log['failure']=str(e)[:2000]
            log['result']=result;row['tools'].append(log);history.append_result(fc['call_id'],result)
        save(folder/'receipt.json',row)
        if submitted is not None:break
    row['submitted']=submitted is not None;row['candidate']=submitted if submitted is not None else (best[1] if best else [])
    row['bestObserved']=best[1] if best else []
    row['observedTotalTokens']=used
    row['grade'],row['graderSeconds']=native.call(op='grade',goal=c['goals'][phase],selection=row['candidate'])
    row['bestGrade'],_=native.call(op='grade',goal=c['goals'][phase],selection=row['bestObserved'])
    if not row['submitted'] and not row['failure']:row['failure']='call_limit_exhausted'
    save(folder/'receipt.json',row)
    print('\nPHASE',c['id'],phase,arm,'tokens',used,'gap',row['bestGrade'].get('gap'),'failure',row['failure'],flush=True)
    return row

def run(plan):
    verify(plan);paid=BASE/'paid';paid.mkdir(exist_ok=False);rows=[]
    for x in plan['order']:
        c=next(c for c in plan['cases'] if c['id']==x['case']);native=Native()
        try:
            init(native,c,x['arm'])
            for phase in range(2):rows.append(run_phase(plan,c,phase,x['arm'],native,paid/f"{c['id']}-{x['arm']}-{phase}"))
        finally:native.close()
        save(BASE/'ledger.json',{'planSha256':sha((BASE/'frozen-plan.json').read_bytes()),'phases':rows})
    verify(plan);save(BASE/'post-run-binding.json',{'planSha256':sha((BASE/'frozen-plan.json').read_bytes()),'verified':True,'boundFiles':len(plan['binding'])})
    print('CROSSPATH-RUN-OK',len(rows),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('command',choices=['qualify','freeze','run']);a=p.parse_args()
    if a.command=='qualify':qualify()
    elif a.command=='freeze':freeze()
    else:run(json.loads((BASE/'frozen-plan.json').read_text()))
