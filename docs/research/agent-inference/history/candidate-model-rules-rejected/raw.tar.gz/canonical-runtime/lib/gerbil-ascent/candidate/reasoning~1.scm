(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/reasoning[1]#_g39254_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39256_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-receipt
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39258_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39260_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39261_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39262_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39263_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39264_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39265_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39266_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39267_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-diagnostics
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39268_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39269_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39270_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-nonmembership
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39271_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-stratified
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39273_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39274_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39275_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39276_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39277_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39278_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39279_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39280_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-diagnostics-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39281_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39282_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39283_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-nonmembership-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39284_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-stratified-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39286_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39287_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39288_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39289_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39290_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39291_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39292_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39293_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-diagnostics
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39294_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39295_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39296_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-nonmembership
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39297_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-stratified
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39299_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39300_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39301_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39302_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39303_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39304_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39305_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39306_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-diagnostics-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39307_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39308_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39309_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-nonmembership-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39310_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-stratified-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39312_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39314_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39316_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39318_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39319_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-support
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39320_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-reachable
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39322_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39323_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-support-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39324_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-reachable-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39326_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39327_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-support
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39328_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-reachable
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39330_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39331_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-support-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39332_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-reachable-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39334_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39336_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-stratified-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39338_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39340_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39341_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-finite
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39342_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39343_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39345_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39346_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-finite-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39347_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39348_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39350_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39351_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-finite
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39352_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39353_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39355_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39356_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-finite-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39357_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39358_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39360_|
    (##structure
     gx#syntax-quote::t
     'captured-stage::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39362_|
    (##structure
     gx#syntax-quote::t
     'make-captured-stage
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39364_|
    (##structure
     gx#syntax-quote::t
     'captured-stage?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39366_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-ok?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39367_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39369_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-ok?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39370_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39372_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-ok?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39373_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39375_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-ok?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39376_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39378_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39380_|
    (##structure
     gx#syntax-quote::t
     'make-attempt-observation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39382_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39384_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39385_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39387_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39388_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39390_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39391_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39393_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39394_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/reasoning[:0:]#reasoning-receipt|
      (let ((__obj39172
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39172
           'gerbil-ascent/candidate/reasoning#reasoning-receipt::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39172
           'reasoning-receipt
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39172
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    rows
                    diagnostics
                    evidence
                    proof
                    nonmembership
                    stratified)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39172
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    rows
                    diagnostics
                    evidence
                    proof
                    nonmembership
                    stratified)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39172 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39172 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39172 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39172 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39172 '#f '13 '#f '#f))
        (let ((__tmp39253 |gerbil-ascent/candidate/reasoning[1]#_g39254_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39172 __tmp39253 '4 '#f '#f))
        (let ((__tmp39255 |gerbil-ascent/candidate/reasoning[1]#_g39256_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39172 __tmp39255 '14 '#f '#f))
        (let ((__tmp39257 |gerbil-ascent/candidate/reasoning[1]#_g39258_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39172 __tmp39257 '15 '#f '#f))
        (let ((__tmp39259
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39260_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g39261_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g39262_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g39263_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g39264_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g39265_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g39266_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g39267_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g39268_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g39269_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g39270_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g39271_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj39172 __tmp39259 '16 '#f '#f))
        (let ((__tmp39272
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39273_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g39274_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g39275_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g39276_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g39277_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g39278_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g39279_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g39280_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g39281_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g39282_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g39283_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g39284_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj39172 __tmp39272 '17 '#f '#f))
        (let ((__tmp39285
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39286_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g39287_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g39288_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g39289_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g39290_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g39291_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g39292_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g39293_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g39294_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g39295_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g39296_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g39297_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj39172 __tmp39285 '18 '#f '#f))
        (let ((__tmp39298
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39299_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g39300_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g39301_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g39302_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g39303_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g39304_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g39305_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g39306_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g39307_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g39308_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g39309_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g39310_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj39172 __tmp39298 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39172 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39172 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39172 '() '21 '#f '#f))
        __obj39172))
    (define |gerbil-ascent/candidate/reasoning[:0:]#reasoning-evidence|
      (let ((__obj39173
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39173
           'gerbil-ascent/candidate/reasoning#reasoning-evidence::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39173
           'reasoning-evidence
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39173
           '(kind support reachable)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39173
           '(kind support reachable)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39173 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39173 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39173 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39173 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39173 '#f '13 '#f '#f))
        (let ((__tmp39311 |gerbil-ascent/candidate/reasoning[1]#_g39312_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39173 __tmp39311 '4 '#f '#f))
        (let ((__tmp39313 |gerbil-ascent/candidate/reasoning[1]#_g39314_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39173 __tmp39313 '14 '#f '#f))
        (let ((__tmp39315 |gerbil-ascent/candidate/reasoning[1]#_g39316_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39173 __tmp39315 '15 '#f '#f))
        (let ((__tmp39317
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g39318_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g39319_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g39320_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39173 __tmp39317 '16 '#f '#f))
        (let ((__tmp39321
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g39322_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g39323_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g39324_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39173 __tmp39321 '17 '#f '#f))
        (let ((__tmp39325
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g39326_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g39327_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g39328_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39173 __tmp39325 '18 '#f '#f))
        (let ((__tmp39329
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g39330_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g39331_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g39332_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39173 __tmp39329 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39173 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39173 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39173 '() '21 '#f '#f))
        __obj39173))
    (define |gerbil-ascent/candidate/reasoning[:0:]#reasoning-stratified-evidence|
      (let ((__obj39174
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39174
           'gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39174
           'reasoning-stratified-evidence
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39174
           '(status finite proof work-budget)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39174
           '(status finite proof work-budget)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39174 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39174 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39174 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39174 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39174 '#f '13 '#f '#f))
        (let ((__tmp39333 |gerbil-ascent/candidate/reasoning[1]#_g39334_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39174 __tmp39333 '4 '#f '#f))
        (let ((__tmp39335 |gerbil-ascent/candidate/reasoning[1]#_g39336_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39174 __tmp39335 '14 '#f '#f))
        (let ((__tmp39337 |gerbil-ascent/candidate/reasoning[1]#_g39338_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39174 __tmp39337 '15 '#f '#f))
        (let ((__tmp39339
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39340_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g39341_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g39342_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g39343_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39174 __tmp39339 '16 '#f '#f))
        (let ((__tmp39344
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39345_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g39346_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g39347_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g39348_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39174 __tmp39344 '17 '#f '#f))
        (let ((__tmp39349
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39350_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g39351_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g39352_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g39353_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39174 __tmp39349 '18 '#f '#f))
        (let ((__tmp39354
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39355_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g39356_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g39357_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g39358_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39174 __tmp39354 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39174 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39174 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39174 '() '21 '#f '#f))
        __obj39174))
    (define |gerbil-ascent/candidate/reasoning[:0:]#captured-stage|
      (let ((__obj39175
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39175
           'gerbil-ascent/candidate/reasoning#captured-stage::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39175 'captured-stage '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39175 '(ok? value) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39175 '(ok? value) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39175 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39175 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39175 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39175 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39175 '#f '13 '#f '#f))
        (let ((__tmp39359 |gerbil-ascent/candidate/reasoning[1]#_g39360_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39175 __tmp39359 '4 '#f '#f))
        (let ((__tmp39361 |gerbil-ascent/candidate/reasoning[1]#_g39362_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39175 __tmp39361 '14 '#f '#f))
        (let ((__tmp39363 |gerbil-ascent/candidate/reasoning[1]#_g39364_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39175 __tmp39363 '15 '#f '#f))
        (let ((__tmp39365
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g39366_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g39367_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39175 __tmp39365 '16 '#f '#f))
        (let ((__tmp39368
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g39369_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g39370_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39175 __tmp39368 '17 '#f '#f))
        (let ((__tmp39371
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g39372_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g39373_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39175 __tmp39371 '18 '#f '#f))
        (let ((__tmp39374
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g39375_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g39376_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39175 __tmp39374 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39175 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39175 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39175 '() '21 '#f '#f))
        __obj39175))
    (define |gerbil-ascent/candidate/reasoning[:0:]#attempt-observation|
      (let ((__obj39176
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39176
           'gerbil-ascent/candidate/reasoning#attempt-observation::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39176
           'attempt-observation
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39176 '(rows evidence) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39176 '(rows evidence) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39176 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39176 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39176 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39176 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39176 '#f '13 '#f '#f))
        (let ((__tmp39377 |gerbil-ascent/candidate/reasoning[1]#_g39378_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39176 __tmp39377 '4 '#f '#f))
        (let ((__tmp39379 |gerbil-ascent/candidate/reasoning[1]#_g39380_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39176 __tmp39379 '14 '#f '#f))
        (let ((__tmp39381 |gerbil-ascent/candidate/reasoning[1]#_g39382_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39176 __tmp39381 '15 '#f '#f))
        (let ((__tmp39383
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g39384_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g39385_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39176 __tmp39383 '16 '#f '#f))
        (let ((__tmp39386
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g39387_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g39388_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39176 __tmp39386 '17 '#f '#f))
        (let ((__tmp39389
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g39390_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g39391_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39176 __tmp39389 '18 '#f '#f))
        (let ((__tmp39392
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g39393_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g39394_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39176 __tmp39392 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39176 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39176 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39176 '() '21 '#f '#f))
        __obj39176))))
