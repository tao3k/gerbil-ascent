(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "std/test")
    (load-module "clan/poo/mop")
    (load-module "gerbil-ascent/program/types")
    (load-module "gerbil-ascent/candidate/program")
    (load-module "gerbil-ascent/candidate/feedback")
    (load-module "gerbil-ascent/candidate/reasoning"))
  (load-module
   "gerbil-ascent/t/qualification/ascent-candidate-feedback-test~0"))
