(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/datum[1]#_g34007_|
    (##structure
     gx#syntax-quote::t
     'datum-frame::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34009_|
    (##structure
     gx#syntax-quote::t
     'make-datum-frame
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34011_|
    (##structure
     gx#syntax-quote::t
     'datum-frame?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34013_|
    (##structure
     gx#syntax-quote::t
     'datum-frame-pair
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34014_|
    (##structure
     gx#syntax-quote::t
     'datum-frame-depth
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34015_|
    (##structure
     gx#syntax-quote::t
     'datum-frame-tail?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34017_|
    (##structure
     gx#syntax-quote::t
     'datum-frame-pair-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34018_|
    (##structure
     gx#syntax-quote::t
     'datum-frame-depth-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34019_|
    (##structure
     gx#syntax-quote::t
     'datum-frame-tail?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34021_|
    (##structure
     gx#syntax-quote::t
     '&datum-frame-pair
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34022_|
    (##structure
     gx#syntax-quote::t
     '&datum-frame-depth
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34023_|
    (##structure
     gx#syntax-quote::t
     '&datum-frame-tail?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34025_|
    (##structure
     gx#syntax-quote::t
     '&datum-frame-pair-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34026_|
    (##structure
     gx#syntax-quote::t
     '&datum-frame-depth-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34027_|
    (##structure
     gx#syntax-quote::t
     '&datum-frame-tail?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[:0:]#datum-frame|
    (let ((__obj33867
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj33867
         'gerbil-ascent/candidate/datum#datum-frame::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33867 'datum-frame '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33867 '(pair depth tail?) '6 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33867 '(pair depth tail?) '8 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33867 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33867 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33867 '#t '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33867 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33867 '#f '13 '#f '#f))
      (let ((__tmp34006 |gerbil-ascent/candidate/datum[1]#_g34007_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj33867 __tmp34006 '4 '#f '#f))
      (let ((__tmp34008 |gerbil-ascent/candidate/datum[1]#_g34009_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj33867 __tmp34008 '14 '#f '#f))
      (let ((__tmp34010 |gerbil-ascent/candidate/datum[1]#_g34011_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj33867 __tmp34010 '15 '#f '#f))
      (let ((__tmp34012
             (cons (cons 'pair |gerbil-ascent/candidate/datum[1]#_g34013_|)
                   (cons (cons 'depth
                               |gerbil-ascent/candidate/datum[1]#_g34014_|)
                         (cons (cons 'tail?
                                     |gerbil-ascent/candidate/datum[1]#_g34015_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33867 __tmp34012 '16 '#f '#f))
      (let ((__tmp34016
             (cons (cons 'pair |gerbil-ascent/candidate/datum[1]#_g34017_|)
                   (cons (cons 'depth
                               |gerbil-ascent/candidate/datum[1]#_g34018_|)
                         (cons (cons 'tail?
                                     |gerbil-ascent/candidate/datum[1]#_g34019_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33867 __tmp34016 '17 '#f '#f))
      (let ((__tmp34020
             (cons (cons 'pair |gerbil-ascent/candidate/datum[1]#_g34021_|)
                   (cons (cons 'depth
                               |gerbil-ascent/candidate/datum[1]#_g34022_|)
                         (cons (cons 'tail?
                                     |gerbil-ascent/candidate/datum[1]#_g34023_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33867 __tmp34020 '18 '#f '#f))
      (let ((__tmp34024
             (cons (cons 'pair |gerbil-ascent/candidate/datum[1]#_g34025_|)
                   (cons (cons 'depth
                               |gerbil-ascent/candidate/datum[1]#_g34026_|)
                         (cons (cons 'tail?
                                     |gerbil-ascent/candidate/datum[1]#_g34027_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33867 __tmp34024 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33867 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33867 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33867 '() '21 '#f '#f))
      __obj33867)))
