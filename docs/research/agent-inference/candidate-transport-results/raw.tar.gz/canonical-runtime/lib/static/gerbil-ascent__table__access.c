#ifdef ___LINKER_INFO
; File: "gerbil-ascent__table__access.c", produced by Gambit v4.9.8
(
409008
(C)
"gerbil-ascent__table__access"
("gerbil-ascent__table__access")
()
(("gerbil-ascent__table__access"))
( #|*/"*/"symbols|#
"gerbil-ascent/table/access#extend-scalar-index!"
"gerbil-ascent/table/access#gerbil-ascent-physical-index-build"
"gerbil-ascent/table/access#gerbil-ascent-physical-index-extend!"
"gerbil-ascent/table/access#gerbil-ascent-physical-index-rows"
"gerbil-ascent/table/access#gerbil-ascent-physical-index-single-rows"
"gerbil-ascent__table__access"
"gerbil-ascent__table__access#"
) #|*/"*/"symbols|#
( #|*/"*/"keywords|#
) #|*/"*/"keywords|#
( #|*/"*/"globals-s-d|#
"gerbil-ascent/table/access#extend-scalar-index!"
"gerbil-ascent__table__access#"
) #|*/"*/"globals-s-d|#
( #|*/"*/"globals-s-nd|#
"gerbil-ascent/table/access#gerbil-ascent-physical-index-build"
"gerbil-ascent/table/access#gerbil-ascent-physical-index-extend!"
"gerbil-ascent/table/access#gerbil-ascent-physical-index-rows"
"gerbil-ascent/table/access#gerbil-ascent-physical-index-single-rows"
"gerbil-ascent/table/access::timestamp"
) #|*/"*/"globals-s-nd|#
( #|*/"*/"globals-ns|#
"##dead-end"
"##list?"
"absent-value"
"car"
"error"
"gerbil-ascent/table/funs#gerbil-ascent-index-build"
"gerbil-ascent/table/funs#gerbil-ascent-index-extend!"
"gerbil-ascent/table/funs#gerbil-ascent-index-order!"
"gerbil-ascent/table/funs#gerbil-ascent-index-row-snapshot"
"gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?"
"gerbil-ascent/table/provider#gerbil-ascent-index-provider-build"
"gerbil-ascent/table/provider#gerbil-ascent-index-provider-extend!"
"gerbil-ascent/table/provider#gerbil-ascent-index-provider-lookup"
"hash-get"
"hash-update!__%"
"list-ref"
"make-hash-table__%"
"vector-ref"
"vector-set!"
) #|*/"*/"globals-ns|#
( #|*/"*/"meta-info|#
) #|*/"*/"meta-info|#
)
#else
#define ___VERSION 409008
#define ___MODULE_NAME "gerbil-ascent__table__access"
#define ___LINKER_ID ___LNK_gerbil_2d_ascent____table____access
#define ___MH_PROC ___H_gerbil_2d_ascent____table____access
#define ___SCRIPT_LINE 0
#define ___SYMCOUNT 7
#define ___GLOCOUNT 26
#define ___SUPCOUNT 7
#define ___SUBCOUNT 5
#define ___LBLCOUNT 62
#define ___OFDCOUNT 3
#define ___MODDESCR ___REF_SUB(2)
#include "gambit.h"

___NEED_SYM(___S_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___NEED_SYM(___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___NEED_SYM(___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___NEED_SYM(___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___NEED_SYM(___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows)
___NEED_SYM(___S_gerbil_2d_ascent____table____access)
___NEED_SYM(___S_gerbil_2d_ascent____table____access_23_)

___NEED_GLO(___G__23__23_dead_2d_end)
___NEED_GLO(___G__23__23_list_3f_)
___NEED_GLO(___G_absent_2d_value)
___NEED_GLO(___G_car)
___NEED_GLO(___G_error)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_access_3a__3a_timestamp)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_build)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_extend_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_order_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_row_2d_snapshot)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
___NEED_GLO(___G_gerbil_2d_ascent____table____access_23_)
___NEED_GLO(___G_hash_2d_get)
___NEED_GLO(___G_hash_2d_update_21______25_)
___NEED_GLO(___G_list_2d_ref)
___NEED_GLO(___G_make_2d_hash_2d_table_____25_)
___NEED_GLO(___G_vector_2d_ref)
___NEED_GLO(___G_vector_2d_set_21_)

___BEGIN_SYM
___DEF_SYM(0,___S_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,"gerbil-ascent/table/access#extend-scalar-index!")

___DEF_SYM(1,___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,"gerbil-ascent/table/access#gerbil-ascent-physical-index-build")

___DEF_SYM(2,___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_,"gerbil-ascent/table/access#gerbil-ascent-physical-index-extend!")

___DEF_SYM(3,___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows,"gerbil-ascent/table/access#gerbil-ascent-physical-index-rows")

___DEF_SYM(4,___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows,"gerbil-ascent/table/access#gerbil-ascent-physical-index-single-rows")

___DEF_SYM(5,___S_gerbil_2d_ascent____table____access,"gerbil-ascent__table__access")
___DEF_SYM(6,___S_gerbil_2d_ascent____table____access_23_,"gerbil-ascent__table__access#")

___END_SYM

#define ___SYM_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_ ___SYM(0,___S_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
#define ___SYM_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build ___SYM(1,___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
#define ___SYM_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_ ___SYM(2,___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
#define ___SYM_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows ___SYM(3,___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
#define ___SYM_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows ___SYM(4,___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows)
#define ___SYM_gerbil_2d_ascent____table____access ___SYM(5,___S_gerbil_2d_ascent____table____access)
#define ___SYM_gerbil_2d_ascent____table____access_23_ ___SYM(6,___S_gerbil_2d_ascent____table____access_23_)

___BEGIN_GLO
___DEF_GLO(0,"gerbil-ascent/table/access#extend-scalar-index!")

___DEF_GLO(1,"gerbil-ascent/table/access#gerbil-ascent-physical-index-build")

___DEF_GLO(2,"gerbil-ascent/table/access#gerbil-ascent-physical-index-extend!")

___DEF_GLO(3,"gerbil-ascent/table/access#gerbil-ascent-physical-index-rows")

___DEF_GLO(4,"gerbil-ascent/table/access#gerbil-ascent-physical-index-single-rows")

___DEF_GLO(5,"gerbil-ascent/table/access::timestamp")

___DEF_GLO(6,"gerbil-ascent__table__access#")
___DEF_GLO(7,"##dead-end")
___DEF_GLO(8,"##list?")
___DEF_GLO(9,"absent-value")
___DEF_GLO(10,"car")
___DEF_GLO(11,"error")
___DEF_GLO(12,"gerbil-ascent/table/funs#gerbil-ascent-index-build")

___DEF_GLO(13,"gerbil-ascent/table/funs#gerbil-ascent-index-extend!")

___DEF_GLO(14,"gerbil-ascent/table/funs#gerbil-ascent-index-order!")

___DEF_GLO(15,"gerbil-ascent/table/funs#gerbil-ascent-index-row-snapshot")

___DEF_GLO(16,"gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?")

___DEF_GLO(17,"gerbil-ascent/table/provider#gerbil-ascent-index-provider-build")

___DEF_GLO(18,"gerbil-ascent/table/provider#gerbil-ascent-index-provider-extend!")

___DEF_GLO(19,"gerbil-ascent/table/provider#gerbil-ascent-index-provider-lookup")

___DEF_GLO(20,"hash-get")
___DEF_GLO(21,"hash-update!__%")
___DEF_GLO(22,"list-ref")
___DEF_GLO(23,"make-hash-table__%")
___DEF_GLO(24,"vector-ref")
___DEF_GLO(25,"vector-set!")
___END_GLO

#define ___GLO_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_ ___GLO(0,___G_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_ ___PRM(0,___G_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build ___GLO(1,___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build ___PRM(1,___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_ ___GLO(2,___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_ ___PRM(2,___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows ___GLO(3,___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows ___PRM(3,___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows ___GLO(4,___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows ___PRM(4,___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_access_3a__3a_timestamp ___GLO(5,___G_gerbil_2d_ascent_2f_table_2f_access_3a__3a_timestamp)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_access_3a__3a_timestamp ___PRM(5,___G_gerbil_2d_ascent_2f_table_2f_access_3a__3a_timestamp)
#define ___GLO_gerbil_2d_ascent____table____access_23_ ___GLO(6,___G_gerbil_2d_ascent____table____access_23_)
#define ___PRM_gerbil_2d_ascent____table____access_23_ ___PRM(6,___G_gerbil_2d_ascent____table____access_23_)
#define ___GLO__23__23_dead_2d_end ___GLO(7,___G__23__23_dead_2d_end)
#define ___PRM__23__23_dead_2d_end ___PRM(7,___G__23__23_dead_2d_end)
#define ___GLO__23__23_list_3f_ ___GLO(8,___G__23__23_list_3f_)
#define ___PRM__23__23_list_3f_ ___PRM(8,___G__23__23_list_3f_)
#define ___GLO_absent_2d_value ___GLO(9,___G_absent_2d_value)
#define ___PRM_absent_2d_value ___PRM(9,___G_absent_2d_value)
#define ___GLO_car ___GLO(10,___G_car)
#define ___PRM_car ___PRM(10,___G_car)
#define ___GLO_error ___GLO(11,___G_error)
#define ___PRM_error ___PRM(11,___G_error)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_build ___GLO(12,___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_build)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_build ___PRM(12,___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_build)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_extend_21_ ___GLO(13,___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_extend_21_)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_extend_21_ ___PRM(13,___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_extend_21_)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_order_21_ ___GLO(14,___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_order_21_)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_order_21_ ___PRM(14,___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_order_21_)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_row_2d_snapshot ___GLO(15,___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_row_2d_snapshot)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_row_2d_snapshot ___PRM(15,___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_row_2d_snapshot)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_ ___GLO(16,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_ ___PRM(16,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build ___GLO(17,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build ___PRM(17,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_ ___GLO(18,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_ ___PRM(18,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
#define ___GLO_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup ___GLO(19,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
#define ___PRM_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup ___PRM(19,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
#define ___GLO_hash_2d_get ___GLO(20,___G_hash_2d_get)
#define ___PRM_hash_2d_get ___PRM(20,___G_hash_2d_get)
#define ___GLO_hash_2d_update_21______25_ ___GLO(21,___G_hash_2d_update_21______25_)
#define ___PRM_hash_2d_update_21______25_ ___PRM(21,___G_hash_2d_update_21______25_)
#define ___GLO_list_2d_ref ___GLO(22,___G_list_2d_ref)
#define ___PRM_list_2d_ref ___PRM(22,___G_list_2d_ref)
#define ___GLO_make_2d_hash_2d_table_____25_ ___GLO(23,___G_make_2d_hash_2d_table_____25_)
#define ___PRM_make_2d_hash_2d_table_____25_ ___PRM(23,___G_make_2d_hash_2d_table_____25_)
#define ___GLO_vector_2d_ref ___GLO(24,___G_vector_2d_ref)
#define ___PRM_vector_2d_ref ___PRM(24,___G_vector_2d_ref)
#define ___GLO_vector_2d_set_21_ ___GLO(25,___G_vector_2d_set_21_)
#define ___PRM_vector_2d_set_21_ ___PRM(25,___G_vector_2d_set_21_)

___DEF_SUB_BIGFIX(___X0,1UL)
               ___BIGFIX1(0x6acb08fdL)
___DEF_SUB_STR(___X1,44UL)
               ___STR8(65,83,67,69,78,84,32,105)
               ___STR8(110,100,101,120,32,112,114,111)
               ___STR8(118,105,100,101,114,32,114,101)
               ___STR8(116,117,114,110,101,100,32,110)
               ___STR8(111,110,45,108,105,115,116,32)
               ___STR4(114,111,119,115)
___DEF_SUB_VEC(___X2,6UL)
               ___VEC1(___REF_SUB(3))
               ___VEC1(___REF_SUB(4))
               ___VEC1(___REF_NUL)
               ___VEC1(___REF_FIX(1))
               ___VEC1(___REF_PRC(1))
               ___VEC1(___REF_FAL)
               ___VEC0
___DEF_SUB_VEC(___X3,1UL)
               ___VEC1(___REF_SYM(5,___S_gerbil_2d_ascent____table____access))
               ___VEC0
___DEF_SUB_VEC(___X4,0UL)
               ___VEC0

___BEGIN_SUB
 ___DEF_SUB(___X0)
,___DEF_SUB(___X1)
,___DEF_SUB(___X2)
,___DEF_SUB(___X3)
,___DEF_SUB(___X4)
___END_SUB



#undef ___MD_ALL
#define ___MD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___MR_ALL
#define ___MR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___MW_ALL
#define ___MW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_M_COD
___BEGIN_M_HLBL
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent____table____access_23_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_M_HLBL(___L11_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_M_HLBL(___L12_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_M_HLBL(___L13_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_M_HLBL(___L11_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_M_HLBL(___L12_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_M_HLBL(___L13_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_M_HLBL(___L11_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_M_HLBL(___L11_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___END_M_HLBL

___BEGIN_M_SW

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent____table____access_23_
#undef ___PH_LBL0
#define ___PH_LBL0 1
#undef ___PD_ALL
#define ___PD_ALL ___D_R0 ___D_R1
#undef ___PR_ALL
#define ___PR_ALL ___R_R0 ___R_R1
#undef ___PW_ALL
#define ___PW_ALL ___W_R1
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent____table____access_23_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent____table____access_23_)
   ___IF_NARGS_EQ(0,___NOTHING)
   ___WRONG_NARGS(0,0,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent____table____access_23_)
   ___SET_GLO(5,___G_gerbil_2d_ascent_2f_table_2f_access_3a__3a_timestamp,___BIGFIX(0,1791691005LL))
   ___SET_R1(___VOID)
   ___JUMPRET(___R0)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_
#undef ___PH_LBL0
#define ___PH_LBL0 3
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_P_HLBL(___L11_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_P_HLBL(___L12_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_P_HLBL(___L13_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___IF_NARGS_EQ(3,___NOTHING)
   ___WRONG_NARGS(0,3,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___BEGIN_ALLOC_VECTOR(1UL)
   ___ADD_VECTOR_ELEM(0,___FAL)
   ___END_ALLOC_VECTOR(1)
   ___SET_R4(___GET_VECTOR(1))
   ___SET_STK(1,___ALLOC_CLO(1UL))
   ___BEGIN_SETUP_CLO(1,___STK(1),11)
   ___ADD_CLO_ELEM(0,___R4)
   ___END_SETUP_CLO(1)
   ___SET_STK(2,___R0)
   ___SET_STK(3,___R1)
   ___SET_STK(9,___R1)
   ___SET_STK(10,___R3)
   ___SET_R3(___R2)
   ___SET_R2(___STK(1))
   ___SET_R1(___R4)
   ___SET_R0(___LBL(10))
   ___ADJFP(10)
   ___CHECK_HEAP(1,4096)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___POLL(2)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___GOTO(___L14_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___SET_R3(___CDR(___STK(-6)))
   ___SET_R2(___STK(-7))
   ___SET_R1(___STK(-8))
   ___SET_R0(___STK(-9))
   ___ADJFP(-10)
   ___POLL(4)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_GLBL(___L14_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___IF(___NOT(___PAIRP(___R3)))
   ___GOTO(___L17_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___END_IF
   ___SET_R4(___CAR(___R3))
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_STK(4,___R3)
   ___SET_STK(5,___R4)
   ___SET_R2(___STK(0))
   ___SET_R1(___R4)
   ___SET_R0(___LBL(5))
   ___ADJFP(10)
   ___JUMPPRM(___SET_NARGS(2),___PRM_list_2d_ref)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___IF(___NOT(___VECTORP(___STK(-8))))
   ___GOTO(___L15_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___END_IF
   ___IF(___NOT(___MUTABLEP(___STK(-8))))
   ___GOTO(___L15_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___END_IF
   ___IF(___NOT(___VECTORINBOUNDSP(___STK(-8),___FIX(0L))))
   ___GOTO(___L15_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___END_IF
   ___VECTORSET(___STK(-8),___FIX(0L),___STK(-5))
   ___SET_STK(1,___STK(-11))
   ___SET_R2(___STK(-7))
   ___SET_R3(___FAL)
   ___ADJFP(1)
   ___POLL(6)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___SET_R0(___LBL(7))
   ___JUMPGLONOTSAFE(___SET_NARGS(4),21,___G_hash_2d_update_21______25_)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___SET_R1(___CDR(___STK(-6)))
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L16_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___END_IF
   ___SET_R2(___CAR(___R1))
   ___SET_STK(-6,___R1)
   ___SET_STK(-5,___R2)
   ___SET_R2(___STK(-10))
   ___SET_R1(___STK(-5))
   ___SET_R0(___LBL(8))
   ___JUMPPRM(___SET_NARGS(2),___PRM_list_2d_ref)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___IF(___NOT(___VECTORP(___STK(-8))))
   ___GOTO(___L15_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___END_IF
   ___IF(___NOT(___MUTABLEP(___STK(-8))))
   ___GOTO(___L15_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___END_IF
   ___IF(___NOT(___VECTORINBOUNDSP(___STK(-8),___FIX(0L))))
   ___GOTO(___L15_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___END_IF
   ___VECTORSET(___STK(-8),___FIX(0L),___STK(-5))
   ___SET_STK(1,___STK(-11))
   ___SET_R2(___STK(-7))
   ___SET_R3(___FAL)
   ___SET_R0(___LBL(3))
   ___ADJFP(1)
   ___JUMPGLONOTSAFE(___SET_NARGS(4),21,___G_hash_2d_update_21______25_)
___DEF_GLBL(___L15_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___SET_STK(-4,___R1)
   ___SET_R3(___STK(-5))
   ___SET_R1(___STK(-8))
   ___SET_R2(___FIX(0L))
   ___SET_R0(___LBL(9))
   ___JUMPPRM(___SET_NARGS(3),___PRM_vector_2d_set_21_)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___SET_R0(___LBL(9))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L16_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___SET_R1(___VOID)
   ___ADJFP(-12)
   ___JUMPRET(___STK(3))
___DEF_GLBL(___L17_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___SET_R1(___VOID)
   ___ADJFP(-2)
   ___JUMPRET(___R0)
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___SET_R1(___STK(-5))
   ___ADJFP(-8)
   ___JUMPRET(___STK(2))
___DEF_SLBL(11,___L11_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(11,1,0,0)
   ___SET_R3(___CLO(___R4,1))
   ___IF(___NOT(___VECTORP(___R3)))
   ___GOTO(___L19_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___END_IF
   ___SET_R3(___CLO(___R4,1))
   ___IF(___NOT(___VECTORINBOUNDSP(___R3,___FIX(0L))))
   ___GOTO(___L19_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___END_IF
   ___SET_R4(___CLO(___R4,1))
   ___SET_R2(___VECTORREF(___R4,___FIX(0L)))
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L18_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___END_IF
   ___SET_R1(___NUL)
___DEF_GLBL(___L18_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___SET_R1(___CONS(___R2,___R1))
   ___CHECK_HEAP(12,4096)
___DEF_SLBL(12,___L12_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___JUMPRET(___R0)
___DEF_GLBL(___L19_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R1(___CLO(___R4,1))
   ___SET_R2(___FIX(0L))
   ___SET_R0(___LBL(13))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM_vector_2d_ref)
___DEF_SLBL(13,___L13_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
   ___SET_R0(___LBL(13))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows
#undef ___PH_LBL0
#define ___PH_LBL0 18
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_FP ___W_R0 ___W_R1 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows)
   ___IF_NARGS_EQ(2,___NOTHING)
   ___WRONG_NARGS(0,2,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows)
   ___SET_STK(1,___R0)
   ___ADJFP(4)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows)
   ___SET_R0(___LBL(2))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),20,___G_hash_2d_get)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L3_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows)
   ___END_IF
   ___ADJFP(-4)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L3_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows)
   ___SET_R1(___NUL)
   ___ADJFP(-4)
   ___JUMPRET(___STK(1))
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build
#undef ___PH_LBL0
#define ___PH_LBL0 22
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_P_HLBL(___L11_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_P_HLBL(___L12_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_P_HLBL(___L13_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___IF_NARGS_EQ(3,___NOTHING)
   ___WRONG_NARGS(0,3,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_STK(4,___R3)
   ___ADJFP(8)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___SET_R0(___LBL(2))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),16,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L17_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___END_IF
   ___IF(___NOT(___PAIRP(___STK(-4))))
   ___GOTO(___L14_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___END_IF
   ___SET_R1(___CDR(___STK(-4)))
   ___IF(___NULLP(___R1))
   ___GOTO(___L15_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___END_IF
___DEF_GLBL(___L14_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___SET_R2(___STK(-4))
   ___SET_R1(___STK(-5))
   ___SET_R0(___STK(-7))
   ___POLL(3)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___ADJFP(-8)
   ___JUMPGLONOTSAFE(___SET_NARGS(2),12,___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_build)
___DEF_GLBL(___L15_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___SET_STK(1,___FAL)
   ___SET_STK(2,___GLO_absent_2d_value)
   ___SET_STK(3,___GLO_absent_2d_value)
   ___SET_STK(4,___GLO_absent_2d_value)
   ___SET_STK(5,___GLO_absent_2d_value)
   ___SET_STK(6,___GLO_absent_2d_value)
   ___SET_R3(___GLO_absent_2d_value)
   ___SET_R2(___GLO_absent_2d_value)
   ___SET_R1(___GLO_absent_2d_value)
   ___SET_R0(___LBL(4))
   ___ADJFP(6)
   ___JUMPGLONOTSAFE(___SET_NARGS(9),23,___G_make_2d_hash_2d_table_____25_)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___SET_STK(-6,___R1)
   ___IF(___PAIRP(___STK(-4)))
   ___GOTO(___L16_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___END_IF
   ___SET_R1(___STK(-4))
   ___SET_R0(___LBL(5))
   ___JUMPPRM(___SET_NARGS(1),___PRM_car)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___SET_R0(___LBL(5))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L16_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___SET_R1(___CAR(___STK(-4)))
   ___SET_R3(___R1)
   ___SET_R2(___STK(-5))
   ___SET_R1(___STK(-6))
   ___SET_R0(___LBL(6))
   ___ADJFP(-4)
   ___JUMPINT(___SET_NARGS(3),___PRC(3),___L_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___SET_R0(___STK(-3))
   ___POLL(7)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___ADJFP(-4)
   ___JUMPGLONOTSAFE(___SET_NARGS(1),14,___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_order_21_)
___DEF_GLBL(___L17_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___SET_R1(___STK(-5))
   ___SET_R0(___LBL(8))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),15,___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_row_2d_snapshot)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___SET_STK(-5,___R1)
   ___SET_R1(___STK(-4))
   ___SET_R0(___LBL(12))
   ___IF(___PAIRP(___R1))
   ___GOTO(___L19_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___END_IF
   ___GOTO(___L20_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_GLBL(___L18_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L20_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___END_IF
___DEF_GLBL(___L19_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___SET_R2(___CAR(___R1))
   ___SET_R2(___R2)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R2)
   ___SET_R1(___CDR(___R1))
   ___SET_R0(___LBL(10))
   ___ADJFP(8)
   ___POLL(9)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___GOTO(___L18_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___SET_R1(___CONS(___STK(-6),___R1))
   ___ADJFP(-7)
   ___CHECK_HEAP(11,4096)
___DEF_SLBL(11,___L11_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___ADJFP(-1)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L20_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___SET_R1(___NUL)
   ___JUMPRET(___R0)
___DEF_SLBL(12,___L12_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___SET_R3(___R1)
   ___SET_R2(___STK(-5))
   ___SET_R1(___STK(-6))
   ___SET_R0(___STK(-7))
   ___POLL(13)
___DEF_SLBL(13,___L13_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build)
   ___ADJFP(-8)
   ___JUMPGLONOTSAFE(___SET_NARGS(3),17,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_build)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_
#undef ___PH_LBL0
#define ___PH_LBL0 37
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_P_HLBL(___L11_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___IF_NARGS_EQ(4,___NOTHING)
   ___WRONG_NARGS(0,4,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_STK(4,___R3)
   ___SET_R1(___STK(0))
   ___ADJFP(7)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___SET_R0(___LBL(2))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),16,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L14_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___END_IF
   ___IF(___NOT(___PAIRP(___STK(-3))))
   ___GOTO(___L13_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___END_IF
   ___SET_R1(___CDR(___STK(-3)))
   ___IF(___NOT(___NULLP(___R1)))
   ___GOTO(___L13_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___END_IF
   ___IF(___NOT(___PAIRP(___STK(-3))))
   ___GOTO(___L12_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___END_IF
   ___SET_R1(___CAR(___STK(-3)))
   ___SET_R3(___R1)
   ___SET_R2(___STK(-4))
   ___SET_R1(___STK(-5))
   ___SET_R0(___STK(-6))
   ___POLL(3)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___ADJFP(-8)
   ___JUMPINT(___SET_NARGS(3),___PRC(3),___L_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_)
___DEF_GLBL(___L12_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___SET_R1(___STK(-3))
   ___SET_R0(___LBL(4))
   ___JUMPPRM(___SET_NARGS(1),___PRM_car)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___SET_R0(___LBL(4))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L13_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___SET_R3(___STK(-3))
   ___SET_R2(___STK(-4))
   ___SET_R1(___STK(-5))
   ___SET_R0(___STK(-6))
   ___POLL(5)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___ADJFP(-8)
   ___JUMPGLONOTSAFE(___SET_NARGS(3),13,___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_extend_21_)
___DEF_GLBL(___L14_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___SET_R1(___STK(-4))
   ___SET_R0(___LBL(6))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),15,___G_gerbil_2d_ascent_2f_table_2f_funs_23_gerbil_2d_ascent_2d_index_2d_row_2d_snapshot)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___SET_STK(-4,___R1)
   ___SET_R1(___STK(-3))
   ___SET_R0(___LBL(10))
   ___IF(___PAIRP(___R1))
   ___GOTO(___L16_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___END_IF
   ___GOTO(___L17_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_GLBL(___L15_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L17_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___END_IF
___DEF_GLBL(___L16_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___SET_R2(___CAR(___R1))
   ___SET_R2(___R2)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R2)
   ___SET_R1(___CDR(___R1))
   ___SET_R0(___LBL(8))
   ___ADJFP(8)
   ___POLL(7)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___GOTO(___L15_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___SET_R1(___CONS(___STK(-6),___R1))
   ___ADJFP(-7)
   ___CHECK_HEAP(9,4096)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___ADJFP(-1)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L17_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___SET_R1(___NUL)
   ___JUMPRET(___R0)
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___SET_R3(___R1)
   ___SET_R2(___STK(-4))
   ___SET_R1(___STK(-5))
   ___SET_R0(___STK(-6))
   ___POLL(11)
___DEF_SLBL(11,___L11_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_)
   ___ADJFP(-7)
   ___JUMPGLONOTSAFE(___SET_NARGS(4),18,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_extend_21_)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows
#undef ___PH_LBL0
#define ___PH_LBL0 50
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_P_HLBL(___L11_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___IF_NARGS_EQ(3,___NOTHING)
   ___WRONG_NARGS(0,3,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_STK(4,___R3)
   ___ADJFP(8)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___SET_R0(___LBL(2))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),16,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_canonical_2d_hash_2d_index_2d_provider_3f_)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L15_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___END_IF
   ___IF(___NOT(___PAIRP(___STK(-4))))
   ___GOTO(___L14_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___END_IF
   ___SET_R1(___CDR(___STK(-4)))
   ___IF(___NOT(___NULLP(___R1)))
   ___GOTO(___L14_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___END_IF
   ___IF(___PAIRP(___STK(-4)))
   ___GOTO(___L12_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___END_IF
   ___SET_R1(___STK(-4))
   ___SET_R0(___LBL(3))
   ___JUMPPRM(___SET_NARGS(1),___PRM_car)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___SET_R0(___LBL(3))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L12_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___SET_R1(___CAR(___STK(-4)))
   ___SET_R2(___R1)
   ___SET_R1(___STK(-5))
   ___SET_R0(___LBL(4))
   ___ADJFP(-4)
   ___JUMPGLONOTSAFE(___SET_NARGS(2),20,___G_hash_2d_get)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L13_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___END_IF
   ___ADJFP(-4)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L13_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___SET_R1(___NUL)
   ___ADJFP(-4)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L14_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___SET_R2(___STK(-4))
   ___SET_R1(___STK(-5))
   ___SET_R0(___LBL(4))
   ___ADJFP(-4)
   ___JUMPGLONOTSAFE(___SET_NARGS(2),20,___G_hash_2d_get)
___DEF_GLBL(___L15_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___SET_R1(___STK(-4))
   ___SET_R0(___LBL(8))
   ___IF(___PAIRP(___R1))
   ___GOTO(___L17_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___END_IF
   ___GOTO(___L18_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_GLBL(___L16_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L18_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___END_IF
___DEF_GLBL(___L17_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___SET_R2(___CAR(___R1))
   ___SET_R2(___R2)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R2)
   ___SET_R1(___CDR(___R1))
   ___SET_R0(___LBL(6))
   ___ADJFP(8)
   ___POLL(5)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___GOTO(___L16_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___SET_R1(___CONS(___STK(-6),___R1))
   ___ADJFP(-7)
   ___CHECK_HEAP(7,4096)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___ADJFP(-1)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L18_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___SET_R1(___NUL)
   ___JUMPRET(___R0)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___SET_R3(___R1)
   ___SET_R2(___STK(-5))
   ___SET_R1(___STK(-6))
   ___SET_R0(___LBL(9))
   ___ADJFP(-4)
   ___JUMPGLONOTSAFE(___SET_NARGS(3),19,___G_gerbil_2d_ascent_2f_table_2f_provider_23_gerbil_2d_ascent_2d_index_2d_provider_2d_lookup)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___SET_STK(-2,___R1)
   ___SET_R0(___LBL(10))
   ___ADJFP(4)
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_list_3f_)
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L19_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___END_IF
   ___SET_R2(___STK(-6))
   ___SET_R1(___SUB(1))
   ___SET_R0(___LBL(11))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),11,___G_error)
___DEF_SLBL(11,___L11_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
___DEF_GLBL(___L19_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows)
   ___SET_R1(___STK(-6))
   ___ADJFP(-8)
   ___JUMPRET(___STK(1))
___END_P_SW
___END_P_COD

___END_M_SW
___END_M_COD

___BEGIN_LBL
 ___DEF_LBL_INTRO(___H_gerbil_2d_ascent____table____access_23_,___REF_SYM(6,___S_gerbil_2d_ascent____table____access_23_),___REF_FAL,1,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____table____access_23_,0,-1)
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,___REF_SYM(0,___S_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_),___REF_FAL,14,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,3,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,___OFD(___RETI,10,1,0x3f306L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,___OFD(___RETI,10,1,0x3f306L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,___IFD(___RETN,9,2,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,___IFD(___RETI,2,4,0x3f3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,___IFD(___RETN,9,2,0x7fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,___OFD(___RETI,13,2,0x3f103fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,___IFD(___RETN,9,2,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,___IFD(___RETN,9,2,0x7fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,___IFD(___RETN,9,2,0xbfL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,___IFD(___RETN,5,1,0x6L))
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,1,1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows,___REF_SYM(4,___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows),___REF_FAL,3,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows,2,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows,___IFD(___RETI,4,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,___REF_SYM(1,___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build),___REF_FAL,14,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,3,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,___IFD(___RETI,8,0,0x3f0fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,___IFD(___RETN,5,0,0xfL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,___IFD(___RETI,8,8,0x3f00L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,___IFD(___RETN,5,0,0xdL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,___IFD(___RETI,4,4,0x3f0L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,___IFD(___RETN,5,0,0xbL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,___IFD(___RETI,1,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,___IFD(___RETI,8,8,0x3f00L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_,___REF_SYM(2,___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_),___REF_FAL,12,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_,4,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_,___IFD(___RETI,8,1,0x3f1fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_,___IFD(___RETN,5,1,0x1fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_,___IFD(___RETI,8,8,0x3f00L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_,___IFD(___RETN,5,1,0xeL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_,___IFD(___RETI,8,8,0x3f00L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_,___IFD(___RETN,5,1,0x17L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_,___IFD(___RETI,1,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_,___IFD(___RETN,5,1,0xfL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_,___IFD(___RETI,8,8,0x3f01L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows,___REF_SYM(3,___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows),___REF_FAL,12,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows,3,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows,___IFD(___RETI,8,0,0x3f0fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows,___IFD(___RETN,5,0,0xfL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows,___IFD(___RETN,5,0,0x5L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows,___IFD(___RETI,1,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows,___IFD(___RETN,5,0,0x3L))
___END_LBL

___BEGIN_OFD
 ___DEF_OFD(___RETI,10,1)
               ___GCMAP1(0x3f306L)
,___DEF_OFD(___RETI,10,1)
               ___GCMAP1(0x3f306L)
,___DEF_OFD(___RETI,13,2)
               ___GCMAP1(0x3f103fL)
___END_OFD

___BEGIN_MOD_PRM
___DEF_MOD_PRM(6,___G_gerbil_2d_ascent____table____access_23_,1)
___DEF_MOD_PRM(0,___G_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,3)
___DEF_MOD_PRM(4,___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows,18)
___DEF_MOD_PRM(1,___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,22)
___DEF_MOD_PRM(2,___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_,37)
___DEF_MOD_PRM(3,___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows,50)
___END_MOD_PRM

___BEGIN_MOD_C_INIT
___END_MOD_C_INIT

___BEGIN_MOD_GLO
___DEF_MOD_GLO(6,___G_gerbil_2d_ascent____table____access_23_,1)
___DEF_MOD_GLO(0,___G_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,3)
___DEF_MOD_GLO(4,___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows,18)
___DEF_MOD_GLO(1,___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,22)
___DEF_MOD_GLO(2,___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_,37)
___DEF_MOD_GLO(3,___G_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows,50)
___END_MOD_GLO

___BEGIN_MOD_SYM_KEY
___DEF_MOD_SYM(0,___S_gerbil_2d_ascent_2f_table_2f_access_23_extend_2d_scalar_2d_index_21_,"gerbil-ascent/table/access#extend-scalar-index!")

___DEF_MOD_SYM(1,___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_build,"gerbil-ascent/table/access#gerbil-ascent-physical-index-build")

___DEF_MOD_SYM(2,___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_extend_21_,"gerbil-ascent/table/access#gerbil-ascent-physical-index-extend!")

___DEF_MOD_SYM(3,___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_rows,"gerbil-ascent/table/access#gerbil-ascent-physical-index-rows")

___DEF_MOD_SYM(4,___S_gerbil_2d_ascent_2f_table_2f_access_23_gerbil_2d_ascent_2d_physical_2d_index_2d_single_2d_rows,"gerbil-ascent/table/access#gerbil-ascent-physical-index-single-rows")

___DEF_MOD_SYM(5,___S_gerbil_2d_ascent____table____access,"gerbil-ascent__table__access")
___DEF_MOD_SYM(6,___S_gerbil_2d_ascent____table____access_23_,"gerbil-ascent__table__access#")

___END_MOD_SYM_KEY

#endif
