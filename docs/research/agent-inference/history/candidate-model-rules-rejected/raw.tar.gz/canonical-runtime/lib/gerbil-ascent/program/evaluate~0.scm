(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/evaluate::timestamp 1791687888)
  (begin
    (define gerbil-ascent/program/evaluate#Session.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentSessionContract
         'proto)))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine__%
      (lambda (_%previous19643%_
               _%candidate19644%_
               _%completed19645%_
               _%analysis19646%_
               _%schema19647%_
               _%measure-rule-times?19648%_
               _%source-cut19649%_
               _%publication19650%_)
        (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__5
         _%candidate19644%_
         '#t
         _%analysis19646%_
         _%schema19647%_
         _%measure-rule-times?19648%_
         '#f
         (let ()
           (declare (not safe))
           (gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__%
            _%previous19643%_
            _%candidate19644%_
            _%completed19645%_
            _%analysis19646%_
            _%source-cut19649%_
            _%publication19650%_)))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine__0
      (lambda (_%previous19655%_
               _%candidate19656%_
               _%completed19657%_
               _%analysis19658%_
               _%schema19659%_
               _%measure-rule-times?19660%_)
        (let* ((_%source-cut19662%_ '#f) (_%publication19664%_ '#f))
          (gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine__%
           _%previous19655%_
           _%candidate19656%_
           _%completed19657%_
           _%analysis19658%_
           _%schema19659%_
           _%measure-rule-times?19660%_
           _%source-cut19662%_
           _%publication19664%_))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine__1
      (lambda (_%previous19666%_
               _%candidate19667%_
               _%completed19668%_
               _%analysis19669%_
               _%schema19670%_
               _%measure-rule-times?19671%_
               _%source-cut19672%_)
        (let ((_%publication19674%_ '#f))
          (gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine__%
           _%previous19666%_
           _%candidate19667%_
           _%completed19668%_
           _%analysis19669%_
           _%schema19670%_
           _%measure-rule-times?19671%_
           _%source-cut19672%_
           _%publication19674%_))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine
      (lambda _g37321_
        (let ((_g37322_ (let () (declare (not safe)) (##length _g37321_))))
          (cond ((let () (declare (not safe)) (##fx= _g37322_ 6))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine__0
                        _g37321_))
                ((let () (declare (not safe)) (##fx= _g37322_ 7))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine__1
                        _g37321_))
                ((let () (declare (not safe)) (##fx= _g37322_ 8))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine__%
                        _g37321_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine
                  _g37321_))))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
      (lambda (_%program18559%_
               _%session?18560%_
               _%analysis-override18561%_
               _%schema-override18562%_
               _%measure-rule-times?18563%_
               _%plan-error18564%_
               _%reuse18565%_
               _%workers18566%_
               _%canceled?18567%_)
        (if (or (not _%canceled?18567%_) (procedure? _%canceled?18567%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT cancellation predicate"
                     _%canceled?18567%_)))
        (if (and _%canceled?18567%_
                 (or _%session?18560%_
                     _%reuse18565%_
                     _%measure-rule-times?18563%_))
            (let ()
              (declare (not safe))
              (error '"ASCENT cancellation requires a fresh untimed evaluator"))
            '#!void)
        (if (and (exact-integer? _%workers18566%_)
                 (> _%workers18566%_ '0)
                 (or (= _%workers18566%_ '1)
                     (if _%session?18560%_
                         '#f
                         (if _%reuse18565%_
                             '#f
                             (not _%measure-rule-times?18563%_)))))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT parallel evaluation option"
                     _%workers18566%_)))
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%program18559%_
               'clan/poo/object#object::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT program" _%program18559%_)))
        (let* ((_%relations18581%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%program18559%_ 'relations)))
               (_%rules18583%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%program18559%_ 'rules)))
               (_%input-limit18585%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%program18559%_ 'max-input-facts)))
               (_%derived-limit18587%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%program18559%_ 'max-derived-facts)))
               (_%output-limit18589%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%program18559%_ 'max-output-facts))))
          (if (and (list? _%relations18581%_)
                   (list? _%rules18583%_)
                   (exact-integer? _%input-limit18585%_)
                   (> _%input-limit18585%_ '0)
                   (exact-integer? _%derived-limit18587%_)
                   (> _%derived-limit18587%_ '0)
                   (exact-integer? _%output-limit18589%_)
                   (> _%output-limit18589%_ '0)
                   (boolean? _%measure-rule-times?18563%_))
              '#!void
              (let ()
                (declare (not safe))
                (error '"invalid ASCENT program bounds")))
          (let* ((_%count18592%_ (length _%relations18581%_))
                 (_%schema18597%_
                  (let ((_%$e18594%_ _%schema-override18562%_))
                    (if _%$e18594%_
                        _%$e18594%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/program/analysis#gerbil-ascent-program-schema
                           _%program18559%_
                           _%relations18581%_)))))
                 (_%names18599%_ (vector-ref _%schema18597%_ '1))
                 (_%arity18601%_ (vector-ref _%schema18597%_ '2))
                 (_%field-checkers18603%_ (vector-ref _%schema18597%_ '3))
                 (_%positions18605%_ (vector-ref _%schema18597%_ '4))
                 (_%all18607%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18592%_ '())))
                 (_%delta18609%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18592%_ '())))
                 (_%all-version18611%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18592%_ '0)))
                 (_%delta-version18613%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18592%_ '0)))
                 (_%all-size18615%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18592%_ '0)))
                 (_%delta-size18617%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18592%_ '0)))
                 (_%index-providers18619%_ (vector-ref _%schema18597%_ '5))
                 (_%indexes18621%_
                  (let ((__tmp37323 (pair? _%rules18583%_)))
                    (declare (not safe))
                    (gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__%
                     _%all18607%_
                     _%delta18609%_
                     _%all-size18615%_
                     _%delta-size18617%_
                     _%all-version18611%_
                     _%delta-version18613%_
                     _%index-providers18619%_
                     __tmp37323)))
                 (_%storage-extensions18623%_ (vector-ref _%schema18597%_ '6))
                 (_%storage-states18625%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18592%_ '#f)))
                 (_%seen18627%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18592%_ '#f)))
                 (_%lattice-joins18629%_ (vector-ref _%schema18597%_ '7))
                 (_%kinds18631%_ (vector-ref _%schema18597%_ '8))
                 (_%storage-providers18633%_ (vector-ref _%schema18597%_ '9))
                 (_%lattice-rows18635%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18592%_ '#f)))
                 (_%view-generation18637%_
                  (let () (declare (not safe)) (##gensym 'ascent-source)))
                 (_%view-journals18639%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18592%_ '())))
                 (_%view-routing18641%_
                  (let ()
                    (declare (not safe))
                    (##make-vector _%count18592%_ '#f)))
                 (_%source-count18643%_ '0)
                 (_%source-materialized-count18645%_ '0)
                 (_%derived-count18647%_ '0)
                 (_%publication-failed?18649%_ '#f))
            (letrec* ((_%position-of18652%_
                       (if (= _%count18592%_ '1)
                           (lambda (_%name19525%_)
                             (if (eq? _%name19525%_
                                      (vector-ref _%names18599%_ '0))
                                 '0
                                 (let ()
                                   (declare (not safe))
                                   (error '"unknown ASCENT relation"
                                          _%name19525%_))))
                           (lambda (_%name19527%_)
                             (let ((_%slot19529%_
                                    (let ()
                                      (declare (not safe))
                                      (hash-get
                                       _%positions18605%_
                                       _%name19527%_))))
                               (if _%slot19529%_
                                   '#!void
                                   (let ()
                                     (declare (not safe))
                                     (error '"unknown ASCENT relation"
                                            _%name19527%_)))
                               (- _%slot19529%_ '1)))))
                      (_%indexed-rows18653%_
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%indexes18621%_
                          '1
                          '#f
                          '#f)))
                      (_%callback-rows18654%_
                       (lambda (_%atom19520%_
                                _%environment19521%_
                                _%use-delta?19522%_
                                _%slot-terms19523%_)
                         (_%indexed-rows18653%_
                          _%atom19520%_
                          _%environment19521%_
                          _%use-delta?19522%_
                          _%slot-terms19523%_
                          '#t)))
                      (_%view-relation?18655%_
                       (lambda (_%index19518%_)
                         (let ((__tmp37325
                                (vector-ref
                                 _%storage-providers18633%_
                                 _%index19518%_))
                               (__tmp37324
                                (vector-ref
                                 _%index-providers18619%_
                                 _%index19518%_)))
                           (declare (not safe))
                           (gerbil-ascent/program/view-state#gerbil-ascent-view-relation?
                            __tmp37325
                            __tmp37324))))
                      (_%commit-view!18656%_
                       (lambda (_%index19515%_ _%frontier19516%_)
                         (let ((__tmp37330
                                (vector-ref
                                 _%storage-states18625%_
                                 _%index19515%_))
                               (__tmp37329
                                (vector-ref _%names18599%_ _%index19515%_))
                               (__tmp37328
                                (cons _%view-generation18637%_
                                      _%source-count18643%_))
                               (__tmp37327
                                (vector-ref
                                 _%view-journals18639%_
                                 _%index19515%_))
                               (__tmp37326
                                (vector-ref
                                 _%view-routing18641%_
                                 _%index19515%_)))
                           (declare (not safe))
                           (gerbil-ascent/program/view-state#gerbil-ascent-commit-view!__%
                            _%index19515%_
                            __tmp37330
                            _%frontier19516%_
                            _%all18607%_
                            _%delta18609%_
                            _%all-size18615%_
                            _%delta-size18617%_
                            _%all-version18611%_
                            _%delta-version18613%_
                            __tmp37329
                            __tmp37328
                            __tmp37327
                            __tmp37326))))
                      (_%advance-all-indexes!18657%_
                       (let* ((_%advance!19493%_
                               (let ()
                                 (declare (not safe))
                                 (##unchecked-structure-ref
                                  _%indexes18621%_
                                  '2
                                  '#f
                                  '#f)))
                              (_%$%opt-lambda1949419503%_
                               (lambda (_%index19496%_
                                        _%rows19497%_
                                        _%reverse-order?19498%_)
                                 (let ((__tmp37332
                                        (lambda (_%failure19500%_)
                                          (set! _%publication-failed?18649%_
                                                '#t)
                                          (let ()
                                            (declare (not safe))
                                            (raise _%failure19500%_))))
                                       (__tmp37331
                                        (lambda ()
                                          (_%advance!19493%_
                                           _%index19496%_
                                           _%rows19497%_
                                           _%reverse-order?19498%_))))
                                   (declare (not safe))
                                   (__with-catch __tmp37332 __tmp37331)))))
                         (lambda _g37333_
                           (let ((_g37334_
                                  (let ()
                                    (declare (not safe))
                                    (##length _g37333_))))
                             (cond ((let ()
                                      (declare (not safe))
                                      (##fx= _g37334_ 2))
                                    (apply (lambda (_%index19506%_
                                                    _%rows19507%_)
                                             (let ((_%reverse-order?19509%_
                                                    '#f))
                                               (_%$%opt-lambda1949419503%_
                                                _%index19506%_
                                                _%rows19507%_
                                                _%reverse-order?19509%_)))
                                           _g37333_))
                                   ((let ()
                                      (declare (not safe))
                                      (##fx= _g37334_ 3))
                                    (apply _%$%opt-lambda1949419503%_
                                           _g37333_))
                                   (else
                                    (##raise-wrong-number-of-arguments-exception
                                     'case-lambda-dispatch
                                     _g37333_)))))))
                      (_g37335_
                       (let ((_g37336_
                              (let ((__tmp37339
                                     (lambda ()
                                       (let ((__tmp37340
                                              (let ()
                                                (declare (not safe))
                                                (##structure
                                                 gerbil-ascent/program/initialization#initial-source-state::t
                                                 _%all18607%_
                                                 _%delta18609%_
                                                 _%all-size18615%_
                                                 _%delta-size18617%_
                                                 _%storage-states18625%_
                                                 _%seen18627%_
                                                 _%lattice-rows18635%_))))
                                         (declare (not safe))
                                         (gerbil-ascent/program/initialization#gerbil-ascent-initialize-sources!
                                          _%relations18581%_
                                          _%schema18597%_
                                          __tmp37340
                                          _%input-limit18585%_
                                          _%output-limit18589%_))))
                                    (__tmp37338
                                     (lambda (_%inputs18660%_
                                              _%materialized18661%_)
                                       (set! _%source-count18643%_
                                             _%inputs18660%_)
                                       (set! _%source-materialized-count18645%_
                                             _%materialized18661%_))))
                                (declare (not safe))
                                (##call-with-values __tmp37339 __tmp37338))))
                         #!void
                         _g37336_))
                      (_%view-state18662%_
                       (let ((__tmp37341
                              (cons _%view-generation18637%_
                                    _%source-count18643%_)))
                         (declare (not safe))
                         (##structure
                          gerbil-ascent/program/view-state#view-routing-state::t
                          _%storage-states18625%_
                          _%all18607%_
                          _%delta18609%_
                          _%all-version18611%_
                          _%names18599%_
                          __tmp37341
                          _%view-journals18639%_
                          _%view-routing18641%_))))
              (begin
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/program/view-state#gerbil-ascent-initialize-view-cuts!
                   _%relations18581%_
                   _%view-relation?18655%_
                   _%view-state18662%_))
                (if _%reuse18565%_
                    (set! _%derived-count18647%_
                          (let ((__tmp37342
                                 (let ()
                                   (declare (not safe))
                                   (##structure
                                    gerbil-ascent/program/reuse#closure-seed-state::t
                                    _%all18607%_
                                    _%seen18627%_
                                    _%delta18609%_
                                    _%all-size18615%_
                                    _%delta-size18617%_
                                    _%lattice-rows18635%_))))
                            (declare (not safe))
                            (gerbil-ascent/program/reuse#gerbil-ascent-seed-native-reuse!
                             _%reuse18565%_
                             _%schema18597%_
                             __tmp37342
                             _%source-materialized-count18645%_
                             _%derived-limit18587%_
                             _%output-limit18589%_)))
                    '#!void)
                (let* ((_%storage-owners18664%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/table/storage#gerbil-ascent-storage-owned-states
                           _%storage-states18625%_)))
                       (_%analysis18670%_
                        (let ((_%$e18666%_ _%analysis-override18561%_))
                          (if _%$e18666%_
                              _%$e18666%_
                              (let ((__tmp37343
                                     (lambda ()
                                       (let ()
                                         (declare (not safe))
                                         (gerbil-ascent/program/planning#gerbil-ascent-prepare-program
                                          _%relations18581%_
                                          _%rules18583%_
                                          _%schema18597%_
                                          _%plan-error18564%_)))))
                                (declare (not safe))
                                (gerbil-ascent/program/analysis#gerbil-ascent-program-analysis
                                 _%program18559%_
                                 _%relations18581%_
                                 _%rules18583%_
                                 __tmp37343)))))
                       (_%rule-plans18672%_ (vector-ref _%analysis18670%_ '2))
                       (_%_index-layout18674%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/program/index#row-indexes-plan-rules!
                           _%indexes18621%_
                           _%rule-plans18672%_)))
                       (_%rule-ticks18676%_
                        (if _%measure-rule-times?18563%_
                            (let ((__tmp37344 (length _%rules18583%_)))
                              (declare (not safe))
                              (##make-vector __tmp37344 '0))
                            '#f))
                       (_%strata18678%_ (vector-ref _%analysis18670%_ '3))
                       (_%all-active18680%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/program/reuse#gerbil-ascent-activate-rules
                           _%analysis18670%_)))
                       (_%ordered-execution?18682%_
                        (not (let ((__tmp37345
                                    (let ((__tmp37346
                                           (let ()
                                             (declare (not safe))
                                             (##vector->list
                                              _%all-active18680%_))))
                                      (declare (not safe))
                                      (##apply append __tmp37346))))
                               (declare (not safe))
                               (gerbil-ascent/program/actor-round#gerbil-ascent-actor-round-eligible?
                                __tmp37345
                                _%storage-providers18633%_
                                _%index-providers18619%_
                                _%lattice-joins18629%_
                                _%field-checkers18603%_))))
                       (_%_routed-sources18684%_
                        (if _%ordered-execution?18682%_
                            '#!void
                            (let ()
                              (declare (not safe))
                              (gerbil-ascent/program/view-state#gerbil-ascent-route-view-sources!
                               _%rule-plans18672%_
                               _%view-relation?18655%_
                               _%view-state18662%_))))
                       (_%active-by-stratum18686%_
                        (if _%reuse18565%_
                            (let ((__tmp37347
                                   (##structure-ref
                                    _%reuse18565%_
                                    '2
                                    gerbil-ascent/program/reuse#native-reuse::t
                                    '#f)))
                              (declare (not safe))
                              (gerbil-ascent/program/reuse#gerbil-ascent-activate-selected-rules
                               _%analysis18670%_
                               __tmp37347))
                            _%all-active18680%_))
                       (_%highest-stratum18688%_
                        (- (vector-length _%active-by-stratum18686%_) '1))
                       (_%lattice-feeds-relation?18690%_
                        (if _%session?18560%_
                            (let ()
                              (declare (not safe))
                              (gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-feeds-relation?
                               _%rule-plans18672%_
                               _%kinds18631%_))
                            '#f))
                       (_%positive-rules?18696%_
                        (if _%session?18560%_
                            (let ((__tmp37348
                                   (lambda (_%rule18692%_)
                                     (let ((__tmp37350
                                            (lambda (_%clause18694%_)
                                              (eq? (vector-ref
                                                    _%clause18694%_
                                                    '0)
                                                   'atom)))
                                           (__tmp37349
                                            (vector-ref _%rule18692%_ '1)))
                                       (declare (not safe))
                                       (andmap__0 __tmp37350 __tmp37349)))))
                              (declare (not safe))
                              (andmap__0 __tmp37348 _%rule-plans18672%_))
                            '#f))
                       (_%single-set-source?18698%_
                        (if _%positive-rules?18696%_
                            (if (= _%count18592%_ '1)
                                (if (vector-ref _%lattice-joins18629%_ '0)
                                    '#f
                                    (let ((__tmp37351
                                           (vector-ref
                                            _%storage-providers18633%_
                                            '0)))
                                      (declare (not safe))
                                      (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                                       __tmp37351)))
                                '#f)
                            '#f))
                       (_%source-state18700%_
                        (if _%session?18560%_
                            (let ()
                              (declare (not safe))
                              (gerbil-ascent/program/source-state#gerbil-ascent-source-state
                               _%program18559%_
                               _%relations18581%_))
                            '#f))
                       (_%source-originals18702%_
                        (if _%session?18560%_
                            (##direct-structure-ref
                             _%source-state18700%_
                             '1
                             gerbil-ascent/program/source-state#source-state::t
                             '#f)
                            '#f))
                       (_%source-additions18704%_
                        (if _%session?18560%_
                            (##direct-structure-ref
                             _%source-state18700%_
                             '2
                             gerbil-ascent/program/source-state#source-state::t
                             '#f)
                            '#f))
                       (_%staged-set-counts18706%_
                        (if _%session?18560%_
                            (let ()
                              (declare (not safe))
                              (##make-vector _%count18592%_ '0))
                            '#f))
                       (_%staged-total18708%_ '0)
                       (_%source-overrides18710%_
                        (if _%session?18560%_
                            (##direct-structure-ref
                             _%source-state18700%_
                             '3
                             gerbil-ascent/program/source-state#source-state::t
                             '#f)
                            '#f))
                       (_%recompute-from-source?18712%_ '#f)
                       (_%resume-stratum18714%_ '#f)
                       (_%resume-round18716%_ '0)
                       (_%materialized-dirty?18718%_ '#f)
                       (_%first-run?18720%_ '#t)
                       (_%dirty?18722%_ '#t)
                       (_%last-result18724%_ '#f)
                       (_%owned-publication18726%_ '#f))
                  (letrec* ((_%flush-staged-set-rows!18729%_
                             (lambda ()
                               (if _%session?18560%_
                                   (let ((_%accepted-any?19469%_ '#f))
                                     (let _%flush19471%_ ((_%index19473%_ '0))
                                       (if (< _%index19473%_ _%count18592%_)
                                           (begin
                                             (let ((_%staged-count19475%_
                                                    (vector-ref
                                                     _%staged-set-counts18706%_
                                                     _%index19473%_)))
                                               (if (> _%staged-count19475%_ '0)
                                                   (begin
                                                     (let ((_g37352_
                                                            (let ((__tmp37356
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (vector-ref
                            _%source-additions18704%_
                            _%index19473%_))
                          (__tmp37355
                           (vector-ref _%seen18627%_ _%index19473%_))
                          (__tmp37354
                           (if (null? (vector-ref _%all18607%_ _%index19473%_))
                               (null? (vector-ref
                                       _%source-originals18702%_
                                       _%index19473%_))
                               '#f)))
                      (declare (not safe))
                      (gerbil-ascent/table/storage#gerbil-ascent-set-batch-admit!
                       __tmp37356
                       _%staged-count19475%_
                       __tmp37355
                       __tmp37354))))
               (begin
                 (let ((_g37353_
                        (let ()
                          (declare (not safe))
                          (if (##values? _g37352_)
                              (##values-length _g37352_)
                              1))))
                   (if (not (let () (declare (not safe)) (##fx= _g37353_ 2)))
                       (error "Context expects 2 values" _g37353_)))
                 (let ((_%accepted19477%_
                        (let ()
                          (declare (not safe))
                          (##values-ref _g37352_ 0)))
                       (_%present19478%_
                        (let ()
                          (declare (not safe))
                          (##values-ref _g37352_ 1))))
                   (begin
                     (vector-set!
                      _%seen18627%_
                      _%index19473%_
                      _%present19478%_)
                     (if (pair? _%accepted19477%_)
                         (begin
                           (set! _%accepted-any?19469%_ '#t)
                           (set! _%materialized-dirty?18718%_ '#t)
                           (let* ((_%new-count19480%_
                                   (let ()
                                     (declare (not safe))
                                     (##length _%accepted19477%_)))
                                  (_%old-all19482%_
                                   (vector-ref _%all18607%_ _%index19473%_))
                                  (_%old-delta19484%_
                                   (vector-ref _%delta18609%_ _%index19473%_))
                                  (_%shared-tail?19486%_
                                   (eq? _%old-all19482%_ _%old-delta19484%_))
                                  (_%new-delta19488%_
                                   (if _%shared-tail?19486%_
                                       '#f
                                       (append _%accepted19477%_
                                               _%old-delta19484%_))))
                             (let ()
                               (declare (not safe))
                               (_%advance-all-indexes!18657%_
                                _%index19473%_
                                _%accepted19477%_
                                '#t))
                             (let ((_%new-all19491%_
                                    (append! _%accepted19477%_
                                             _%old-all19482%_)))
                               (vector-set!
                                _%all18607%_
                                _%index19473%_
                                _%new-all19491%_)
                               (vector-set!
                                _%delta18609%_
                                _%index19473%_
                                (if _%shared-tail?19486%_
                                    _%new-all19491%_
                                    _%new-delta19488%_)))
                             (set! _%source-materialized-count18645%_
                                   (+ _%source-materialized-count18645%_
                                      _%new-count19480%_))
                             (vector-set!
                              _%all-size18615%_
                              _%index19473%_
                              (+ (vector-ref _%all-size18615%_ _%index19473%_)
                                 _%new-count19480%_))
                             (vector-set!
                              _%delta-size18617%_
                              _%index19473%_
                              (+ (vector-ref
                                  _%delta-size18617%_
                                  _%index19473%_)
                                 _%new-count19480%_))
                             (vector-set!
                              _%all-version18611%_
                              _%index19473%_
                              (+ '1
                                 (vector-ref
                                  _%all-version18611%_
                                  _%index19473%_)))
                             (vector-set!
                              _%delta-version18613%_
                              _%index19473%_
                              (+ '1
                                 (vector-ref
                                  _%delta-version18613%_
                                  _%index19473%_)))))
                         '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (vector-set!
                                                      _%staged-set-counts18706%_
                                                      _%index19473%_
                                                      '0))
                                                   '#!void))
                                             (_%flush19471%_
                                              (+ _%index19473%_ '1)))
                                           '#!void))
                                     (set! _%staged-total18708%_ '0)
                                     (if (if _%first-run?18720%_
                                             '#f
                                             (if _%materialized-dirty?18718%_
                                                 '#f
                                                 (not _%accepted-any?19469%_)))
                                         (set! _%dirty?18722%_ '#f)
                                         '#!void))
                                   '#!void)))
                            (_%run-retained!__3731637317%_
                             (lambda (_%deadline19046%_)
                               (let ()
                                 (declare (not safe))
                                 (##for-each
                                  gerbil-ascent/table/storage#gerbil-ascent-storage-check-state!
                                  _%storage-owners18664%_))
                               (if _%publication-failed?18649%_
                                   (let ()
                                     (declare (not safe))
                                     (error '"ASCENT engine publication requires source replay"))
                                   '#!void)
                               (if _%dirty?18722%_
                                   (_%flush-staged-set-rows!18729%_)
                                   '#!void)
                               (let ((_%complete?19048%_ '#t))
                                 (if _%dirty?18722%_
                                     (begin
                                       (if _%active-by-stratum18686%_
                                           '#!void
                                           (set! _%active-by-stratum18686%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gerbil-ascent/program/reuse#gerbil-ascent-activate-rules
                                                    _%analysis18670%_))))
                                       (let ((_%pending19050%_
                                              (let ()
                                                (declare (not safe))
                                                (##make-vector
                                                 _%count18592%_
                                                 '())))
                                             (_%pending-seen19051%_
                                              (let ()
                                                (declare (not safe))
                                                (##make-vector
                                                 _%count18592%_
                                                 '#f)))
                                             (_%pending-injections19052%_
                                              (let ()
                                                (declare (not safe))
                                                (##make-vector
                                                 _%count18592%_
                                                 '())))
                                             (_%pending-lattices19053%_
                                              (let ()
                                                (declare (not safe))
                                                (##make-vector
                                                 _%count18592%_
                                                 '#f)))
                                             (_%pending-count19054%_ '0)
                                             (_%component-mode?19055%_
                                              (let ()
                                                (declare (not safe))
                                                (gerbil-ascent/program/component-plan#gerbil-ascent-component-mode?
                                                 _%session?18560%_
                                                 _%workers18566%_
                                                 _%canceled?18567%_
                                                 _%analysis18670%_
                                                 _%schema18597%_))))
                                         (letrec ((_%admit-stored!19057%_
                                                   (lambda (_%index19433%_
                                                            _%pending-table19434%_
                                                            _%stored19435%_)
                                                     (if (and (list? _%stored19435%_)
                                                              (= (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (declare (not safe))
                           (##length _%stored19435%_))
                         (vector-ref _%arity18601%_ _%index19433%_)))
                 '#!void
                 (let ()
                   (declare (not safe))
                   (error '"invalid ASCENT storage provider row"
                          _%stored19435%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (let ((_%check19437%_
                                                            (vector-ref
                                                             _%field-checkers18603%_
                                                             _%index19433%_)))
                                                       (if _%check19437%_
                                                           (_%check19437%_
                                                            _%stored19435%_)
                                                           '#!void))
                                                     (if (or (let ((__tmp37357
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (vector-ref _%seen18627%_ _%index19433%_)))
                       (declare (not safe))
                       (hash-get __tmp37357 _%stored19435%_))
                     (let ()
                       (declare (not safe))
                       (hash-get _%pending-table19434%_ _%stored19435%_)))
                 '#!void
                 (begin
                   (let ()
                     (declare (not safe))
                     (hash-put! _%pending-table19434%_ _%stored19435%_ '#t))
                   (set! _%pending-count19054%_ (+ _%pending-count19054%_ '1))
                   (vector-set!
                    _%pending19050%_
                    _%index19433%_
                    (cons _%stored19435%_
                          (vector-ref _%pending19050%_ _%index19433%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%emit-row!19058%_
                                                   (lambda (_%atom19339%_
                                                            _%row19340%_)
                                                     (let* ((_%index19342%_
                                                             (vector-ref
                                                              _%atom19339%_
                                                              '0))
                                                            (_%pending-table19349%_
                                                             (if (vector-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          _%lattice-joins18629%_
                          _%index19342%_)
                         '#f
                         (let ((_%$e19344%_
                                (vector-ref
                                 _%pending-seen19051%_
                                 _%index19342%_)))
                           (if _%$e19344%_
                               _%$e19344%_
                               (let ((_%fresh19347%_
                                      (let ()
                                        (declare (not safe))
                                        (make-hash-table__%
                                         '#f
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value))))
                                 (vector-set!
                                  _%pending-seen19051%_
                                  _%index19342%_
                                  _%fresh19347%_)
                                 _%fresh19347%_))))))
               (let ((_%check19352%_
                      (vector-ref _%field-checkers18603%_ _%index19342%_)))
                 (if _%check19352%_ (_%check19352%_ _%row19340%_) '#!void))
               (if (_%view-relation?18655%_ _%index19342%_)
                   (let ((_%frontier19355%_
                          (let ((__tmp37360
                                 (vector-ref
                                  _%storage-states18625%_
                                  _%index19342%_))
                                (__tmp37359
                                 (- _%output-limit18589%_
                                    (+ _%source-materialized-count18645%_
                                       _%derived-count18647%_
                                       _%pending-count19054%_)))
                                (__tmp37358
                                 (vector-ref
                                  _%field-checkers18603%_
                                  _%index19342%_)))
                            (declare (not safe))
                            (gerbil-ascent/program/view-state#gerbil-ascent-stage-view!
                             __tmp37360
                             _%row19340%_
                             __tmp37359
                             __tmp37358))))
                     (if (> (let ()
                              (declare (not safe))
                              (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                               _%frontier19355%_))
                            '0)
                         (vector-set!
                          _%pending-injections19052%_
                          _%index19342%_
                          (cons (map values _%row19340%_)
                                (vector-ref
                                 _%pending-injections19052%_
                                 _%index19342%_)))
                         '#!void)
                     (set! _%pending-count19054%_
                           (+ _%pending-count19054%_
                              (let ()
                                (declare (not safe))
                                (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                                 _%frontier19355%_))))
                     (vector-set!
                      _%pending19050%_
                      _%index19342%_
                      (let ((__tmp37361
                             (vector-ref _%pending19050%_ _%index19342%_)))
                        (declare (not safe))
                        (gerbil-ascent/program/view-state#gerbil-ascent-add-frontier
                         __tmp37361
                         _%frontier19355%_))))
                   (if (vector-ref _%lattice-joins18629%_ _%index19342%_)
                       (let* ((_%frontier19363%_
                               (let ((_%$e19358%_
                                      (vector-ref
                                       _%pending-lattices19053%_
                                       _%index19342%_)))
                                 (if _%$e19358%_
                                     _%$e19358%_
                                     (let ((_%fresh19361%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/program/lattice-frontier#make-lattice-frontier))))
                                       (vector-set!
                                        _%pending-lattices19053%_
                                        _%index19342%_
                                        _%fresh19361%_)
                                       _%fresh19361%_))))
                              (_%key19365%_
                               (let ()
                                 (declare (not safe))
                                 (gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-key
                                  _%row19340%_)))
                              (_%staged19391%_
                               (let* ((_%frontier19367%_ _%frontier19363%_)
                                      (_%key19370%_ _%key19365%_)
                                      (_%frontier19374%_ _%frontier19367%_))
                                 (declare (not safe))
                                 (gerbil-ascent/program/lattice-frontier#__lattice-frontier-ref
                                  _%frontier19374%_
                                  _%key19370%_)))
                              (_%prior19396%_
                               (let ((_%$e19393%_ _%staged19391%_))
                                 (if _%$e19393%_
                                     _%$e19393%_
                                     (let ((__tmp37362
                                            (vector-ref
                                             _%lattice-rows18635%_
                                             _%index19342%_)))
                                       (declare (not safe))
                                       (hash-get __tmp37362 _%key19365%_)))))
                              (_%merged19398%_
                               (if _%prior19396%_
                                   (let ((__tmp37363
                                          ((vector-ref
                                            _%lattice-joins18629%_
                                            _%index19342%_)
                                           (last _%prior19396%_)
                                           (last _%row19340%_))))
                                     (declare (not safe))
                                     (gerbil-ascent/core/rule-semantics#gerbil-ascent-joined-row
                                      _%key19365%_
                                      __tmp37363))
                                   _%row19340%_)))
                         (let ((_%check19401%_
                                (vector-ref
                                 _%field-checkers18603%_
                                 _%index19342%_)))
                           (if _%check19401%_
                               (_%check19401%_ _%merged19398%_)
                               '#!void))
                         (if (and _%prior19396%_
                                  (equal? _%merged19398%_ _%prior19396%_))
                             '#!void
                             (if (let* ((_%frontier19403%_ _%frontier19363%_)
                                        (_%key19406%_ _%key19365%_)
                                        (_%row19409%_ _%merged19398%_)
                                        (_%frontier19413%_ _%frontier19403%_))
                                   (declare (not safe))
                                   (gerbil-ascent/program/lattice-frontier#__lattice-frontier-stage!
                                    _%frontier19413%_
                                    _%key19406%_
                                    _%row19409%_))
                                 (set! _%pending-count19054%_
                                       (+ _%pending-count19054%_ '1))
                                 '#!void)))
                       (if (let ((__tmp37364
                                  (vector-ref
                                   _%storage-providers18633%_
                                   _%index19342%_)))
                             (declare (not safe))
                             (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                              __tmp37364))
                           (_%admit-stored!19057%_
                            _%index19342%_
                            _%pending-table19349%_
                            _%row19340%_)
                           (let ((_%expanded19429%_
                                  ((vector-ref
                                    _%storage-extensions18623%_
                                    _%index19342%_)
                                   (vector-ref
                                    _%storage-states18625%_
                                    _%index19342%_)
                                   (vector-ref _%all18607%_ _%index19342%_)
                                   (vector-ref _%pending19050%_ _%index19342%_)
                                   _%row19340%_
                                   (- _%output-limit18589%_
                                      (+ _%source-materialized-count18645%_
                                         _%derived-count18647%_
                                         _%pending-count19054%_)))))
                             (if (list? _%expanded19429%_)
                                 '#!void
                                 (let ()
                                   (declare (not safe))
                                   (error '"ASCENT storage provider returned non-list rows")))
                             (for-each
                              (lambda (_%stored19431%_)
                                (_%admit-stored!19057%_
                                 _%index19342%_
                                 _%pending-table19349%_
                                 _%stored19431%_))
                              _%expanded19429%_)))))
               (if (> (+ _%derived-count18647%_ _%pending-count19054%_)
                      _%derived-limit18587%_)
                   (let ()
                     (declare (not safe))
                     (error '"ASCENT derived fact budget exceeded"))
                   '#!void)
               (if (> (+ _%source-materialized-count18645%_
                         _%derived-count18647%_
                         _%pending-count19054%_)
                      _%output-limit18589%_)
                   (let ()
                     (declare (not safe))
                     (error '"ASCENT output fact budget exceeded"))
                   '#!void))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%visit-body19059%_
                                                   (lambda (_%body19235%_
                                                            _%delta-at19236%_
                                                            _%depth19237%_
                                                            _%environment19238%_
                                                            _%consume19239%_)
                                                     (if (null? _%body19235%_)
                                                         (_%consume19239%_
                                                          _%environment19238%_)
                                                         (let ((_%clause19241%_
                                                                (car _%body19235%_)))
                                                           (if (eq? (vector-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             _%clause19241%_
                             '0)
                            'atom)
                       (let* ((_%atom19244%_ (vector-ref _%clause19241%_ '1))
                              (_%rows19246%_
                               (_%callback-rows18654%_
                                _%atom19244%_
                                _%environment19238%_
                                (= _%depth19237%_ _%delta-at19236%_)
                                '#f))
                              (__tmp37365
                               (lambda (_%row19249%_)
                                 (let ((_%bound19251%_
                                        (let ((__tmp37366
                                               (vector-ref _%atom19244%_ '3)))
                                          (declare (not safe))
                                          (gerbil-ascent/core/rule-bindings#gerbil-ascent-bind-row
                                           __tmp37366
                                           _%row19249%_
                                           _%environment19238%_))))
                                   (if _%bound19251%_
                                       (_%visit-body19059%_
                                        (cdr _%body19235%_)
                                        _%delta-at19236%_
                                        (+ _%depth19237%_ '1)
                                        _%bound19251%_
                                        _%consume19239%_)
                                       '#!void)))))
                         (declare (not safe))
                         (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
                          __tmp37365
                          _%rows19246%_))
                       (if (eq? (vector-ref _%clause19241%_ '0) 'negation)
                           (let* ((_%atom19254%_
                                   (vector-ref _%clause19241%_ '1))
                                  (_%rows19256%_
                                   (_%callback-rows18654%_
                                    _%atom19254%_
                                    _%environment19238%_
                                    '#f
                                    '#f)))
                             (if (let ((__tmp37367
                                        (lambda (_%row19259%_)
                                          (let ((__tmp37368
                                                 (vector-ref
                                                  _%atom19254%_
                                                  '3)))
                                            (declare (not safe))
                                            (gerbil-ascent/core/rule-bindings#gerbil-ascent-bind-row
                                             __tmp37368
                                             _%row19259%_
                                             _%environment19238%_)))))
                                   (declare (not safe))
                                   (gerbil-ascent/core/relation-view#gerbil-ascent-any-row?
                                    __tmp37367
                                    _%rows19256%_))
                                 '#!void
                                 (_%visit-body19059%_
                                  (cdr _%body19235%_)
                                  _%delta-at19236%_
                                  _%depth19237%_
                                  _%environment19238%_
                                  _%consume19239%_)))
                           (if (eq? (vector-ref _%clause19241%_ '0) 'aggregate)
                               (let* ((_%atom19262%_
                                       (vector-ref _%clause19241%_ '1))
                                      (_%rows19264%_
                                       (_%callback-rows18654%_
                                        _%atom19262%_
                                        _%environment19238%_
                                        '#f
                                        '#f))
                                      (_%variables19266%_
                                       (vector-ref _%clause19241%_ '3))
                                      (_%tuples19268%_ '()))
                                 (let ((__tmp37369
                                        (lambda (_%row19271%_)
                                          (let ((_%bound19273%_
                                                 (let ((__tmp37370
                                                        (vector-ref
                                                         _%atom19262%_
                                                         '3)))
                                                   (declare (not safe))
                                                   (gerbil-ascent/core/rule-bindings#gerbil-ascent-bind-row
                                                    __tmp37370
                                                    _%row19271%_
                                                    _%environment19238%_))))
                                            (if _%bound19273%_
                                                (set! _%tuples19268%_
                                                      (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gerbil-ascent/core/rule-bindings#gerbil-ascent-binding-values
                                                               _%variables19266%_
                                                               _%bound19273%_
                                                               '"unbound ASCENT clause variable"))
                                                            _%tuples19268%_))
                                                '#!void)))))
                                   (declare (not safe))
                                   (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
                                    __tmp37369
                                    _%rows19264%_))
                                 (let ((_%values19275%_
                                        ((vector-ref _%clause19241%_ '4)
                                         (let ()
                                           (declare (not safe))
                                           (##reverse _%tuples19268%_)))))
                                   (if (list? _%values19275%_)
                                       '#!void
                                       (let ()
                                         (declare (not safe))
                                         (error '"ASCENT aggregator must return a list"
                                                _%values19275%_)))
                                   (for-each
                                    (lambda (_%value19277%_)
                                      (let* ((_%output19279%_
                                              (vector-ref _%clause19241%_ '2))
                                             (_%matcher19281%_
                                              (vector-ref _%clause19241%_ '5))
                                             (_%next-environment19285%_
                                              (if _%matcher19281%_
                                                  (let ((_%matched19283%_
                                                         (_%matcher19281%_
                                                          _%value19277%_)))
                                                    (declare (not safe))
                                                    (gerbil-ascent/core/rule-bindings#gerbil-ascent-extend-pattern
                                                     _%output19279%_
                                                     _%matched19283%_
                                                     _%environment19238%_
                                                     '"ASCENT aggregate pattern returned invalid bindings"))
                                                  (cons (cons _%output19279%_
                                                              _%value19277%_)
                                                        _%environment19238%_))))
                                        (_%visit-body19059%_
                                         (cdr _%body19235%_)
                                         _%delta-at19236%_
                                         _%depth19237%_
                                         _%next-environment19285%_
                                         _%consume19239%_)))
                                    _%values19275%_)))
                               (if (eq? (vector-ref _%clause19241%_ '0) 'guard)
                                   (let ((_%pass?19289%_
                                          (let ((__tmp37372
                                                 (vector-ref
                                                  _%clause19241%_
                                                  '2))
                                                (__tmp37371
                                                 (vector-ref
                                                  _%clause19241%_
                                                  '1)))
                                            (declare (not safe))
                                            (gerbil-ascent/core/rule-bindings#gerbil-ascent-call-with-bindings
                                             __tmp37372
                                             __tmp37371
                                             _%environment19238%_
                                             '"unbound ASCENT clause variable"))))
                                     (if (boolean? _%pass?19289%_)
                                         '#!void
                                         (let ()
                                           (declare (not safe))
                                           (error '"ASCENT guard must return a boolean"
                                                  _%pass?19289%_)))
                                     (if _%pass?19289%_
                                         (_%visit-body19059%_
                                          (cdr _%body19235%_)
                                          _%delta-at19236%_
                                          _%depth19237%_
                                          _%environment19238%_
                                          _%consume19239%_)
                                         '#!void))
                                   (if (eq? (vector-ref _%clause19241%_ '0)
                                            'generator)
                                       (let* ((_%values19292%_
                                               (let ((__tmp37374
                                                      (vector-ref
                                                       _%clause19241%_
                                                       '3))
                                                     (__tmp37373
                                                      (vector-ref
                                                       _%clause19241%_
                                                       '2)))
                                                 (declare (not safe))
                                                 (gerbil-ascent/core/rule-bindings#gerbil-ascent-call-with-bindings
                                                  __tmp37374
                                                  __tmp37373
                                                  _%environment19238%_
                                                  '"unbound ASCENT clause variable")))
                                              (_%$it1929319295%_
                                               (let ()
                                                 (declare (not safe))
                                                 (std/iter/iterators#iter
                                                  _%values19292%_)))
                                              (_%$it1929319297%_
                                               _%$it1929319295%_))
                                         (let _%loop19308%_ ()
                                           (let ((_%next19323%_
                                                  (let ((_%self1148019312%_
                                                         _%$it1929319297%_))
                                                    (declare (not safe))
                                                    (let ((_%object1931519320%_
                                                           (##unchecked-structure-ref
                                                            _%self1148019312%_
                                                            '1
                                                            '#f
                                                            'next!))
                                                          (_%method1931619321%_
                                                           (##unchecked-structure-ref
                                                            _%self1148019312%_
                                                            '2
                                                            '#f
                                                            'next!)))
                                                      (_%method1931619321%_
                                                       _%object1931519320%_)))))
                                             (if (eq? _%next19323%_ '#!eof)
                                                 '#!void
                                                 (begin
                                                   (let* ((_%output19329%_
                                                           (vector-ref
                                                            _%clause19241%_
                                                            '1))
                                                          (_%next-environment19333%_
                                                           (if (list? _%output19329%_)
                                                               (let ((_%row19331%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (if (vector? _%next19323%_)
                                  (let ()
                                    (declare (not safe))
                                    (##vector->list _%next19323%_))
                                  _%next19323%_)))
                         (if (and (list? _%row19331%_)
                                  (= (let ()
                                       (declare (not safe))
                                       (##length _%row19331%_))
                                     (let ()
                                       (declare (not safe))
                                       (##length _%output19329%_))))
                             '#!void
                             (let ()
                               (declare (not safe))
                               (error '"ASCENT generator tuple arity mismatch"
                                      _%next19323%_)))
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/core/rule-bindings#gerbil-ascent-bind-row
                            _%output19329%_
                            _%row19331%_
                            _%environment19238%_)))
                       (cons (cons _%output19329%_ _%next19323%_)
                             _%environment19238%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (_%visit-body19059%_
                                                      (cdr _%body19235%_)
                                                      _%delta-at19236%_
                                                      _%depth19237%_
                                                      _%next-environment19333%_
                                                      _%consume19239%_))
                                                   (_%loop19308%_))))))
                                       (if (eq? (vector-ref _%clause19241%_ '0)
                                                'binding)
                                           (let ((_%value19337%_
                                                  (let ((__tmp37376
                                                         (vector-ref
                                                          _%clause19241%_
                                                          '3))
                                                        (__tmp37375
                                                         (vector-ref
                                                          _%clause19241%_
                                                          '2)))
                                                    (declare (not safe))
                                                    (gerbil-ascent/core/rule-bindings#gerbil-ascent-call-with-bindings
                                                     __tmp37376
                                                     __tmp37375
                                                     _%environment19238%_
                                                     '"unbound ASCENT clause variable"))))
                                             (_%visit-body19059%_
                                              (cdr _%body19235%_)
                                              _%delta-at19236%_
                                              _%depth19237%_
                                              (cons (cons (vector-ref
                                                           _%clause19241%_
                                                           '1)
                                                          _%value19337%_)
                                                    _%environment19238%_)
                                              _%consume19239%_))
                                           '#!void)))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           (let ((__tmp37377
                                                  (lambda (_%return19061%_)
                                                    (let _%evaluate-stratum19063%_ ((_%stratum19065%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                             (let ((_%$e19232%_
                                                    _%resume-stratum18714%_))
                                               (if _%$e19232%_
                                                   _%$e19232%_
                                                   '0))))
              (if (<= _%stratum19065%_ _%highest-stratum18688%_)
                  (let ((_%active-rules19067%_
                         (vector-ref
                          _%active-by-stratum18686%_
                          _%stratum19065%_))
                        (_%active?19068%_ '#t)
                        (_%round19069%_
                         (if _%resume-stratum18714%_
                             _%resume-round18716%_
                             '0)))
                    (if _%resume-stratum18714%_
                        '#!void
                        (let _%reset-delta19071%_ ((_%index19073%_ '0))
                          (if (< _%index19073%_ _%count18592%_)
                              (begin
                                (vector-set!
                                 _%delta18609%_
                                 _%index19073%_
                                 (if (= (vector-ref
                                         _%strata18678%_
                                         _%index19073%_)
                                        _%stratum19065%_)
                                     (if (or _%first-run?18720%_
                                             (> _%stratum19065%_ '0))
                                         (vector-ref
                                          _%all18607%_
                                          _%index19073%_)
                                         (vector-ref
                                          _%delta18609%_
                                          _%index19073%_))
                                     '()))
                                (vector-set!
                                 _%delta-size18617%_
                                 _%index19073%_
                                 (let ((__tmp37378
                                        (vector-ref
                                         _%delta18609%_
                                         _%index19073%_)))
                                   (declare (not safe))
                                   (gerbil-ascent/core/relation-view#gerbil-ascent-row-count
                                    __tmp37378)))
                                (vector-set!
                                 _%delta-version18613%_
                                 _%index19073%_
                                 (+ '1
                                    (vector-ref
                                     _%delta-version18613%_
                                     _%index19073%_)))
                                (_%reset-delta19071%_ (+ _%index19073%_ '1)))
                              '#!void)))
                    (let _%loop19078%_ ()
                      (if _%active?19068%_
                          (begin
                            (set! _%round19069%_ (+ _%round19069%_ '1))
                            (set! _%pending-count19054%_ '0)
                            (if _%component-mode?19055%_
                                (let ((__tmp37379
                                       (let ((_%$e19082%_ _%canceled?18567%_))
                                         (if _%$e19082%_
                                             _%$e19082%_
                                             (lambda () '#f)))))
                                  (declare (not safe))
                                  (gerbil-ascent/program/positive-components#gerbil-ascent-run-positive-components!
                                   _%analysis18670%_
                                   _%schema18597%_
                                   _%all18607%_
                                   _%workers18566%_
                                   _%emit-row!19058%_
                                   __tmp37379))
                                (if (and (or (> _%workers18566%_ '1)
                                             _%canceled?18567%_)
                                         (if _%ordered-execution?18682%_
                                             '#f
                                             (let ()
                                               (declare (not safe))
                                               (gerbil-ascent/program/actor-round#gerbil-ascent-actor-round-eligible?
                                                _%active-rules19067%_
                                                _%storage-providers18633%_
                                                _%index-providers18619%_
                                                _%lattice-joins18629%_
                                                _%field-checkers18603%_))))
                                    (let ((_%frozen-all19089%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-copy _%all18607%_)))
                                          (_%frozen-delta19090%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-copy _%delta18609%_)))
                                          (_%frozen-all-size19091%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-copy
                                              _%all-size18615%_)))
                                          (_%frozen-delta-size19092%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-copy
                                              _%delta-size18617%_)))
                                          (_%frozen-all-version19093%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-copy
                                              _%all-version18611%_)))
                                          (_%frozen-delta-version19094%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-copy
                                              _%delta-version18613%_))))
                                      (let ((__tmp37384
                                             (vector _%program18559%_
                                                     _%stratum19065%_
                                                     _%round19069%_
                                                     _%frozen-all19089%_
                                                     _%frozen-delta19090%_))
                                            (__tmp37381
                                             (lambda (_%rule19096%_
                                                      _%emit!19097%_
                                                      _%checkpoint!19098%_)
                                               (let* ((_%plan19100%_
                                                       (vector-ref
                                                        _%rule19096%_
                                                        '5))
                                                      (_%frame19102%_
                                                       (make-vector
                                                        (vector-ref
                                                         _%plan19100%_
                                                         '2)
                                                        '#f))
                                                      (_%private-indexes19104%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__0
                                                          _%frozen-all19089%_
                                                          _%frozen-delta19090%_
                                                          _%frozen-all-size19091%_
                                                          _%frozen-delta-size19092%_
                                                          _%frozen-all-version19093%_
                                                          _%frozen-delta-version19094%_
                                                          _%index-providers18619%_)))
                                                      (_%_private-layout19106%_
                                                       (let ((__tmp37382
                                                              (vector-ref
                                                               _%plan19100%_
                                                               '1)))
                                                         (declare (not safe))
                                                         (gerbil-ascent/program/index#row-indexes-plan-actions!
                                                          _%private-indexes19104%_
                                                          __tmp37382)))
                                                      (_%rows19108%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##unchecked-structure-ref
                                                          _%private-indexes19104%_
                                                          '1
                                                          '#f
                                                          '#f)))
                                                      (_%pivots19110%_
                                                       (vector-ref
                                                        _%rule19096%_
                                                        '2))
                                                      (_%prunable19112%_
                                                       (vector-ref
                                                        _%rule19096%_
                                                        '4)))
                                                 (letrec ((_%visit!19115%_
                                                           (lambda (_%pivot19122%_)
                                                             (let ((__tmp37383
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%private-indexes19104%_
                               '4
                               '#f
                               '#f))))
                       (declare (not safe))
                       (gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__%
                        _%plan19100%_
                        _%frame19102%_
                        _%pivot19122%_
                        _%rows19108%_
                        _%emit!19097%_
                        _%checkpoint!19098%_
                        __tmp37383)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (if (null? _%pivots19110%_)
                                                       (if (and (= _%round19069%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           '1)
                        _%first-run?18720%_)
                   (_%visit!19115%_ '-1)
                   '#!void)
               (if (and (= _%round19069%_ '1)
                        (or _%first-run?18720%_ (> _%stratum19065%_ '0)))
                   (_%visit!19115%_ '-1)
                   (for-each
                    (lambda (_%pivot19120%_)
                      (if (and (< _%pivot19120%_
                                  (vector-length _%prunable19112%_))
                               (= (vector-ref
                                   _%frozen-delta-size19092%_
                                   (vector-ref
                                    _%prunable19112%_
                                    _%pivot19120%_))
                                  '0))
                          '#!void
                          (_%visit!19115%_ _%pivot19120%_)))
                    _%pivots19110%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp37380
                                             (let ((_%$e19124%_
                                                    _%canceled?18567%_))
                                               (if _%$e19124%_
                                                   _%$e19124%_
                                                   (lambda () '#f)))))
                                        (declare (not safe))
                                        (gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__1
                                         __tmp37384
                                         _%active-rules19067%_
                                         _%workers18566%_
                                         __tmp37381
                                         _%emit-row!19058%_
                                         __tmp37380)))
                                    (begin
                                      (if _%canceled?18567%_
                                          (let ()
                                            (declare (not safe))
                                            (error '"ASCENT cancellation requires pure Set worker rules"))
                                          '#!void)
                                      (for-each
                                       (lambda (_%rule19128%_)
                                         (let ((_%started19130%_
                                                (if _%rule-ticks18676%_
                                                    (current-jiffy)
                                                    '#f))
                                               (_%heads19131%_
                                                (vector-ref _%rule19128%_ '0))
                                               (_%body19132%_
                                                (vector-ref _%rule19128%_ '1))
                                               (_%positions19133%_
                                                (vector-ref _%rule19128%_ '2))
                                               (_%prunable19134%_
                                                (vector-ref _%rule19128%_ '4))
                                               (_%positive-plan19135%_
                                                (vector-ref _%rule19128%_ '5))
                                               (_%frame19136%_
                                                (vector-ref _%rule19128%_ '6)))
                                           (let ((_%rows-access19138%_
                                                  (if _%ordered-execution?18682%_
                                                      _%callback-rows18654%_
                                                      _%indexed-rows18653%_))
                                                 (_%parts-access19139%_
                                                  (if _%ordered-execution?18682%_
                                                      '#f
                                                      (let ()
                                                        (declare (not safe))
                                                        (##unchecked-structure-ref
                                                         _%indexes18621%_
                                                         '4
                                                         '#f
                                                         '#f)))))
                                             (if (null? _%positions19133%_)
                                                 (if (and (= _%round19069%_ '1)
                                                          _%first-run?18720%_)
                                                     (if _%positive-plan19135%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__%
                                                            _%positive-plan19135%_
                                                            _%frame19136%_
                                                            '-1
                                                            _%rows-access19138%_
                                                            _%emit-row!19058%_
                                                            '#f
                                                            _%parts-access19139%_))
                                                         (_%visit-body19059%_
                                                          _%body19132%_
                                                          '-1
                                                          '0
                                                          '()
                                                          (lambda (_%environment19141%_)
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (gerbil-ascent/core/positive-plan#gerbil-ascent-emit-heads!
                                                               _%heads19131%_
                                                               _%environment19141%_
                                                               _%emit-row!19058%_)))))
                                                     '#!void)
                                                 (if (and (= _%round19069%_ '1)
                                                          (or _%first-run?18720%_
                                                              (> _%stratum19065%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '0)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (if _%positive-plan19135%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__%
                                                            _%positive-plan19135%_
                                                            _%frame19136%_
                                                            '-1
                                                            _%rows-access19138%_
                                                            _%emit-row!19058%_
                                                            '#f
                                                            _%parts-access19139%_))
                                                         (_%visit-body19059%_
                                                          _%body19132%_
                                                          '-1
                                                          '0
                                                          '()
                                                          (lambda (_%environment19146%_)
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (gerbil-ascent/core/positive-plan#gerbil-ascent-emit-heads!
                                                               _%heads19131%_
                                                               _%environment19146%_
                                                               _%emit-row!19058%_)))))
                                                     (for-each
                                                      (lambda (_%delta-at19148%_)
                                                        (if (and (< _%delta-at19148%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (vector-length _%prunable19134%_))
                         (= (vector-ref
                             _%delta-size18617%_
                             (vector-ref _%prunable19134%_ _%delta-at19148%_))
                            '0))
                    '#!void
                    (if _%positive-plan19135%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__%
                           _%positive-plan19135%_
                           _%frame19136%_
                           _%delta-at19148%_
                           _%rows-access19138%_
                           _%emit-row!19058%_
                           '#f
                           _%parts-access19139%_))
                        (_%visit-body19059%_
                         _%body19132%_
                         _%delta-at19148%_
                         '0
                         '()
                         (lambda (_%environment19150%_)
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/core/positive-plan#gerbil-ascent-emit-heads!
                              _%heads19131%_
                              _%environment19150%_
                              _%emit-row!19058%_)))))))
              _%positions19133%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           (if _%started19130%_
                                               (let ((_%index19152%_
                                                      (vector-ref
                                                       _%rule19128%_
                                                       '3)))
                                                 (vector-set!
                                                  _%rule-ticks18676%_
                                                  _%index19152%_
                                                  (+ (vector-ref
                                                      _%rule-ticks18676%_
                                                      _%index19152%_)
                                                     (- (current-jiffy)
                                                        _%started19130%_))))
                                               '#!void)))
                                       _%active-rules19067%_))))
                            (set! _%active?19068%_ '#f)
                            (let _%commit19154%_ ((_%index19156%_ '0))
                              (if (< _%index19156%_ _%count18592%_)
                                  (begin
                                    (if (_%view-relation?18655%_
                                         _%index19156%_)
                                        (let ((_%frontier19158%_
                                               (vector-ref
                                                _%pending19050%_
                                                _%index19156%_)))
                                          (if (> (let ()
                                                   (declare (not safe))
                                                   (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                                                    _%frontier19158%_))
                                                 '0)
                                              (begin
                                                (vector-set!
                                                 _%view-journals18639%_
                                                 _%index19156%_
                                                 (cons (let ((__tmp37387
                                                              (reverse (vector-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                _%pending-injections19052%_
                                _%index19156%_)))
                     (__tmp37385
                      (let ((__tmp37386
                             (vector-ref
                              _%storage-states18625%_
                              _%index19156%_)))
                        (declare (not safe))
                        (gerbil-ascent/table/storage#gerbil-ascent-storage-eqrel-state?
                         __tmp37386))))
                 (declare (not safe))
                 (gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event__%
                  'derived
                  __tmp37387
                  __tmp37385))
               (vector-ref _%view-journals18639%_ _%index19156%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (_%commit-view!18656%_
                                                 _%index19156%_
                                                 _%frontier19158%_)
                                                (set! _%derived-count18647%_
                                                      (+ _%derived-count18647%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                                                            _%frontier19158%_))))
                                                (set! _%active?19068%_ '#t))
                                              (begin
                                                (let ((_%total19160%_
                                                       (vector-ref
                                                        _%all18607%_
                                                        _%index19156%_)))
                                                  (vector-set!
                                                   _%delta18609%_
                                                   _%index19156%_
                                                   (let ((__tmp37390
                                                          (##structure-ref
                                                           _%total19160%_
                                                           '1
                                                           gerbil-ascent/core/relation-view#relation-view::t
                                                           '#f))
                                                         (__tmp37389
                                                          (##structure-ref
                                                           _%total19160%_
                                                           '2
                                                           gerbil-ascent/core/relation-view#relation-view::t
                                                           '#f))
                                                         (__tmp37388
                                                          (##structure-ref
                                                           _%total19160%_
                                                           '3
                                                           gerbil-ascent/core/relation-view#relation-view::t
                                                           '#f)))
                                                     (declare (not safe))
                                                     (gerbil-ascent/core/relation-view#gerbil-ascent-view-bind
                                                      gerbil-ascent/program/view-state#gerbil-ascent-empty-view
                                                      __tmp37390
                                                      __tmp37389
                                                      __tmp37388
                                                      'delta))))
                                                (vector-set!
                                                 _%delta-size18617%_
                                                 _%index19156%_
                                                 '0)))
                                          (vector-set!
                                           _%pending19050%_
                                           _%index19156%_
                                           '())
                                          (vector-set!
                                           _%pending-injections19052%_
                                           _%index19156%_
                                           '()))
                                        (begin
                                          (if (vector-ref
                                               _%lattice-joins18629%_
                                               _%index19156%_)
                                              (let* ((_%frontier19162%_
                                                      (vector-ref
                                                       _%pending-lattices19053%_
                                                       _%index19156%_))
                                                     (_%staged-rows19190%_
                                                      (if _%frontier19162%_
                                                          (let* ((_%frontier19164%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          _%frontier19162%_)
                         (_%frontier19168%_ _%frontier19164%_))
                    (declare (not safe))
                    (gerbil-ascent/program/lattice-frontier#__lattice-frontier-rows
                     _%frontier19168%_))
                  '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (vector-set!
                                                 _%pending19050%_
                                                 _%index19156%_
                                                 _%staged-rows19190%_)
                                                (if (null? _%staged-rows19190%_)
                                                    '#!void
                                                    (begin
                                                      (vector-set!
                                                       _%all18607%_
                                                       _%index19156%_
                                                       (let ((__tmp37392
                                                              (reverse _%staged-rows19190%_))
                                                             (__tmp37391
                                                              (filter (lambda (_%existing19192%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                (not (let* ((_%frontier19194%_
                                             _%frontier19162%_)
                                            (_%key19197%_
                                             (let ()
                                               (declare (not safe))
                                               (gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-key
                                                _%existing19192%_)))
                                            (_%frontier19201%_
                                             _%frontier19194%_))
                                       (declare (not safe))
                                       (gerbil-ascent/program/lattice-frontier#__lattice-frontier-ref
                                        _%frontier19201%_
                                        _%key19197%_))))
                              (vector-ref _%all18607%_ _%index19156%_))))
                 (declare (not safe))
                 (##append __tmp37392 __tmp37391)))
              (for-each
               (lambda (_%row19213%_)
                 (let ((__tmp37394
                        (vector-ref _%lattice-rows18635%_ _%index19156%_))
                       (__tmp37393
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-key
                           _%row19213%_))))
                   (declare (not safe))
                   (hash-put! __tmp37394 __tmp37393 _%row19213%_))
                 (let ((__tmp37395 (vector-ref _%seen18627%_ _%index19156%_)))
                   (declare (not safe))
                   (hash-put! __tmp37395 _%row19213%_ '#t))
                 (set! _%derived-count18647%_ (+ _%derived-count18647%_ '1))
                 (set! _%active?19068%_ '#t))
               _%staged-rows19190%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (for-each
                                               (lambda (_%row19215%_)
                                                 (let ((__tmp37396
                                                        (vector-ref
                                                         _%seen18627%_
                                                         _%index19156%_)))
                                                   (declare (not safe))
                                                   (hash-put!
                                                    __tmp37396
                                                    _%row19215%_
                                                    '#t))
                                                 (vector-set!
                                                  _%all18607%_
                                                  _%index19156%_
                                                  (cons _%row19215%_
                                                        (vector-ref
                                                         _%all18607%_
                                                         _%index19156%_)))
                                                 (set! _%derived-count18647%_
                                                       (+ _%derived-count18647%_
                                                          '1))
                                                 (set! _%active?19068%_ '#t))
                                               (vector-ref
                                                _%pending19050%_
                                                _%index19156%_)))
                                          (let ((_%batch-size19217%_
                                                 (length (vector-ref
                                                          _%pending19050%_
                                                          _%index19156%_))))
                                            (if (= _%batch-size19217%_ '0)
                                                '#!void
                                                (begin
                                                  (if (vector-ref
                                                       _%lattice-joins18629%_
                                                       _%index19156%_)
                                                      '#!void
                                                      (let ((__tmp37397
                                                             (vector-ref
                                                              _%pending19050%_
                                                              _%index19156%_)))
                                                        (declare (not safe))
                                                        (_%advance-all-indexes!18657%_
                                                         _%index19156%_
                                                         __tmp37397)))
                                                  (vector-set!
                                                   _%all-version18611%_
                                                   _%index19156%_
                                                   (+ '1
                                                      (vector-ref
                                                       _%all-version18611%_
                                                       _%index19156%_)))
                                                  (vector-set!
                                                   _%all-size18615%_
                                                   _%index19156%_
                                                   (if (if (vector-ref
                                                            _%lattice-joins18629%_
                                                            _%index19156%_)
                                                           '#f
                                                           (and (let ((__tmp37398
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               (vector-ref
                                _%storage-providers18633%_
                                _%index19156%_)))
                          (declare (not safe))
                          (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                           __tmp37398))
                        (let ((__tmp37399
                               (vector-ref
                                _%index-providers18619%_
                                _%index19156%_)))
                          (declare (not safe))
                          (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                           __tmp37399))))
               (+ (vector-ref _%all-size18615%_ _%index19156%_)
                  _%batch-size19217%_)
               (length (vector-ref _%all18607%_ _%index19156%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (vector-set!
                                             _%delta18609%_
                                             _%index19156%_
                                             (vector-ref
                                              _%pending19050%_
                                              _%index19156%_))
                                            (vector-set!
                                             _%delta-size18617%_
                                             _%index19156%_
                                             _%batch-size19217%_)
                                            (vector-set!
                                             _%delta-version18613%_
                                             _%index19156%_
                                             (+ '1
                                                (vector-ref
                                                 _%delta-version18613%_
                                                 _%index19156%_))))
                                          (if (pair? (vector-ref
                                                      _%pending19050%_
                                                      _%index19156%_))
                                              (begin
                                                (vector-set!
                                                 _%pending19050%_
                                                 _%index19156%_
                                                 '())
                                                (if (vector-ref
                                                     _%lattice-joins18629%_
                                                     _%index19156%_)
                                                    (let* ((_%frontier19219%_
                                                            (vector-ref
                                                             _%pending-lattices19053%_
                                                             _%index19156%_))
                                                           (_%frontier19223%_
                                                            _%frontier19219%_))
                                                      (declare (not safe))
                                                      (gerbil-ascent/program/lattice-frontier#__lattice-frontier-clear!
                                                       _%frontier19223%_))
                                                    (let ((__tmp37400
                                                           (vector-ref
                                                            _%pending-seen19051%_
                                                            _%index19156%_)))
                                                      (declare (not safe))
                                                      (hash-clear!
                                                       __tmp37400))))
                                              '#!void)))
                                    (_%commit19154%_ (+ _%index19156%_ '1)))
                                  '#!void))
                            (let ()
                              (declare (not safe))
                              (##for-each
                               gerbil-ascent/table/storage#gerbil-ascent-storage-admit-state!
                               _%storage-owners18664%_))
                            (if _%component-mode?19055%_
                                (set! _%active?19068%_ '#f)
                                '#!void)
                            (if (and _%active?19068%_
                                     (if (vector? _%deadline19046%_)
                                         (vector-ref _%deadline19046%_ '0)
                                         _%deadline19046%_)
                                     (>= (current-jiffy)
                                         (if (vector? _%deadline19046%_)
                                             (vector-ref _%deadline19046%_ '0)
                                             _%deadline19046%_)))
                                (begin
                                  (set! _%resume-stratum18714%_
                                        _%stratum19065%_)
                                  (set! _%resume-round18716%_ _%round19069%_)
                                  (set! _%complete?19048%_ '#f)
                                  (_%return19061%_ '#f))
                                '#!void)
                            (_%loop19078%_))
                          '#!void))
                    (set! _%resume-stratum18714%_ '#f)
                    (set! _%resume-round18716%_ '0)
                    (_%evaluate-stratum19063%_ (+ _%stratum19065%_ '1)))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (declare (not safe))
                                             (##call-with-current-continuation
                                              __tmp37377))))
                                       (if _%complete?19048%_
                                           (begin
                                             (set! _%first-run?18720%_ '#f)
                                             (set! _%dirty?18722%_ '#f)
                                             (set! _%materialized-dirty?18718%_
                                                   '#f))
                                           '#!void)
                                       (let* ((_%snapshots19444%_
                                               (if (vector? _%deadline19046%_)
                                                   (let ()
                                                     (declare (not safe))
                                                     (gerbil-ascent/program/result#gerbil-ascent-publish-rows__%
                                                      _%all18607%_
                                                      _%deadline19046%_
                                                      _%all-size18615%_))
                                                   (vector-map
                                                    (lambda (_%rows19442%_)
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (##structure-instance-of?
                                                             _%rows19442%_
                                                             'gerbil-ascent/core/relation-view#relation-view::t))
                                                          _%rows19442%_
                                                          (reverse _%rows19442%_)))
                                                    _%all18607%_)))
                                              (_%sizes19446%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##vector-copy
                                                  _%all-size18615%_)))
                                              (_%representations19452%_
                                               (let ((__tmp37404
                                                      (lambda (_%name19448%_
                                                               _%rows19449%_
                                                               _%size19450%_)
                                                        (list _%name19448%_
                                                              (if (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (declare (not safe))
                            (##structure-instance-of?
                             _%rows19449%_
                             'gerbil-ascent/core/relation-view#relation-view::t))
                          'rectangles
                          'explicit)
                      _%size19450%_
                      (if (let ()
                            (declare (not safe))
                            (##structure-instance-of?
                             _%rows19449%_
                             'gerbil-ascent/core/relation-view#relation-view::t))
                          (let ()
                            (declare (not safe))
                            (##unchecked-structure-ref
                             _%rows19449%_
                             '6
                             '#f
                             '#f))
                          _%size19450%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (__tmp37403
                                                      (vector->list
                                                       _%names18599%_))
                                                     (__tmp37402
                                                      (let ()
                                                        (declare (not safe))
                                                        (##vector->list
                                                         _%all18607%_)))
                                                     (__tmp37401
                                                      (let ()
                                                        (declare (not safe))
                                                        (##vector->list
                                                         _%sizes19446%_))))
                                                 (declare (not safe))
                                                 (##map __tmp37404
                                                        __tmp37403
                                                        __tmp37402
                                                        __tmp37401)))
                                              (_%observation19454%_
                                               (let ((__tmp37405
                                                      (if _%reuse18565%_
                                                          (##structure-ref
                                                           _%reuse18565%_
                                                           '2
                                                           gerbil-ascent/program/reuse#native-reuse::t
                                                           '#f)
                                                          '#f)))
                                                 (declare (not safe))
                                                 (gerbil-ascent/program/result#gerbil-ascent-result-observation
                                                  __tmp37405
                                                  _%names18599%_
                                                  _%active-by-stratum18686%_
                                                  _%rule-ticks18676%_)))
                                              (_g37406_
                                               (let ()
                                                 (declare (not safe))
                                                 (gerbil-ascent/program/result#gerbil-ascent-make-owned-result
                                                  _%names18599%_
                                                  _%arity18601%_
                                                  _%snapshots19444%_
                                                  _%sizes19446%_
                                                  _%representations19452%_
                                                  _%observation19454%_
                                                  _%position-of18652%_
                                                  _%complete?19048%_
                                                  _%session?18560%_))))
                                         (begin
                                           (let ((_g37407_
                                                  (let ()
                                                    (declare (not safe))
                                                    (if (##values? _g37406_)
                                                        (##values-length
                                                         _g37406_)
                                                        1))))
                                             (if (not (let ()
                                                        (declare (not safe))
                                                        (##fx= _g37407_ 2)))
                                                 (error "Context expects 2 values"
                                                        _g37407_)))
                                           (let ((_%result19457%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (##values-ref _g37406_ 0)))
                                                 (_%publication19458%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (##values-ref
                                                     _g37406_
                                                     1))))
                                             (begin
                                               (set! _%owned-publication18726%_
                                                     _%publication19458%_)
                                               (set! _%last-result18724%_
                                                     _%result19457%_))))))
                                     '#!void)
                                 (if (and _%reuse18565%_ _%complete?19048%_)
                                     (begin
                                       (set! _%active-by-stratum18686%_ '#f)
                                       (set! _%reuse18565%_ '#f))
                                     '#!void)
                                 _%last-result18724%_)))
                            (_%run-retained!__0__3731837319%_
                             (lambda ()
                               (let ((_%deadline19464%_ '#f))
                                 (_%run-retained!__3731637317%_
                                  _%deadline19464%_))))
                            (_%run-retained!18730%_
                             (lambda _g37408_
                               (let ((_g37409_
                                      (let ()
                                        (declare (not safe))
                                        (##length _g37408_))))
                                 (cond ((let ()
                                          (declare (not safe))
                                          (##fx= _g37409_ 0))
                                        (apply _%run-retained!__0__3731837319%_
                                               _g37408_))
                                       ((let ()
                                          (declare (not safe))
                                          (##fx= _g37409_ 1))
                                        (apply _%run-retained!__3731637317%_
                                               _g37408_))
                                       (else
                                        (##raise-wrong-number-of-arguments-exception
                                         'case-lambda-dispatch
                                         _g37408_))))))
                            (_%run!18731%_
                             (lambda ()
                               (if _%recompute-from-source?18712%_
                                   _%last-result18724%_
                                   (_%run-retained!__0__3731837319%_)))))
                    (if _%session?18560%_
                        (let ((_%published18733%_
                               (let ()
                                 (declare (not safe))
                                 (gerbil-ascent/program/result#gerbil-ascent-publication-cache
                                  _%count18592%_))))
                          (letrec ((_%replay-source!18735%_
                                    (lambda (_%mode18971%_
                                             _%index18972%_
                                             _%rows18973%_)
                                      (let* ((_%cut18997%_
                                              (let* ((_%state18975%_
                                                      _%source-state18700%_)
                                                     (_%index18978%_
                                                      _%index18972%_)
                                                     (_%rows18981%_
                                                      _%rows18973%_)
                                                     (_%state18985%_
                                                      _%state18975%_))
                                                (declare (not safe))
                                                (gerbil-ascent/program/source-state#__gerbil-ascent-prepare-source-replacement
                                                 _%state18985%_
                                                 _%index18978%_
                                                 _%rows18981%_)))
                                             (_%candidate18999%_
                                              (##direct-structure-ref
                                               _%cut18997%_
                                               '2
                                               gerbil-ascent/program/source-snapshot#source-snapshot::t
                                               '#f))
                                             (_%next-count19006%_
                                              (let ((_%$e19001%_
                                                     _%mode18971%_))
                                                (if (eq? 'append _%$e19001%_)
                                                    '#f
                                                    (if (eq? 'replace
                                                             _%$e19001%_)
                                                        (let ((__tmp37512
                                                               (map (lambda (_%relation19004%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (length (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%relation19004%_
                                         'rows))))
                            (let ()
                              (declare (not safe))
                              (clan/poo/object#.ref
                               _%candidate18999%_
                               'relations)))))
                  (declare (not safe))
                  (##apply + __tmp37512))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        (if (and (eq? _%mode18971%_ 'replace)
                                                 (> _%next-count19006%_
                                                    _%input-limit18585%_))
                                            (let ()
                                              (declare (not safe))
                                              (error '"ASCENT session input fact budget exceeded"))
                                            '#!void)
                                        (let ((_%result19009%_
                                               ((let ((__tmp37513
                                                       (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__3
                                                        _%candidate18999%_
                                                        '#t
                                                        _%analysis18670%_
                                                        _%schema18597%_
                                                        _%measure-rule-times?18563%_)))
                                                  (declare (not safe))
                                                  (clan/poo/object#.ref
                                                   __tmp37513
                                                   '.run)))))
                                          (set! _%source-count18643%_
                                                (let ((_%$e19011%_
                                                       _%next-count19006%_))
                                                  (if _%$e19011%_
                                                      _%$e19011%_
                                                      (+ _%source-count18643%_
                                                         '1))))
                                          (let* ((_%state19014%_
                                                  _%source-state18700%_)
                                                 (_%index19017%_
                                                  _%index18972%_)
                                                 (_%rows19020%_ _%rows18973%_)
                                                 (_%cut19023%_ _%cut18997%_)
                                                 (_%state19027%_
                                                  _%state19014%_))
                                            (declare (not safe))
                                            (gerbil-ascent/program/source-state#__gerbil-ascent-commit-source-replacement!
                                             _%state19027%_
                                             _%index19017%_
                                             _%rows19020%_
                                             _%cut19023%_))
                                          (set! _%recompute-from-source?18712%_
                                                '#t)
                                          (if (eq? _%mode18971%_ 'replace)
                                              (set! _%publication-failed?18649%_
                                                    '#f)
                                              '#!void)
                                          (set! _%dirty?18722%_ '#f)
                                          (set! _%owned-publication18726%_ '#f)
                                          (set! _%last-result18724%_
                                                _%result19009%_)))))
                                   (_%append-set-source!18736%_
                                    (lambda (_%index18968%_ _%row18969%_)
                                      (if (> (+ _%source-materialized-count18645%_
                                                _%derived-count18647%_
                                                _%staged-total18708%_
                                                '1)
                                             _%output-limit18589%_)
                                          (_%flush-staged-set-rows!18729%_)
                                          '#!void)
                                      (if (and (>= (+ _%source-materialized-count18645%_
                                                      _%derived-count18647%_)
                                                   _%output-limit18589%_)
                                               (not (let ((__tmp37514
                                                           (vector-ref
                                                            _%seen18627%_
                                                            _%index18968%_)))
                                                      (declare (not safe))
                                                      (hash-get
                                                       __tmp37514
                                                       _%row18969%_))))
                                          (let ()
                                            (declare (not safe))
                                            (error '"ASCENT session output fact budget exceeded"))
                                          '#!void)
                                      (set! _%source-count18643%_
                                            (+ _%source-count18643%_ '1))
                                      (vector-set!
                                       _%source-additions18704%_
                                       _%index18968%_
                                       (cons _%row18969%_
                                             (vector-ref
                                              _%source-additions18704%_
                                              _%index18968%_)))
                                      (vector-set!
                                       _%staged-set-counts18706%_
                                       _%index18968%_
                                       (+ '1
                                          (vector-ref
                                           _%staged-set-counts18706%_
                                           _%index18968%_)))
                                      (set! _%staged-total18708%_
                                            (+ _%staged-total18708%_ '1))
                                      (set! _%dirty?18722%_ '#t)))
                                   (_%append-source!18737%_
                                    (lambda (_%name18901%_ _%row18902%_)
                                      (if _%recompute-from-source?18712%_
                                          '#!void
                                          (begin
                                            (let ()
                                              (declare (not safe))
                                              (##for-each
                                               gerbil-ascent/table/storage#gerbil-ascent-storage-check-state!
                                               _%storage-owners18664%_))
                                            (if _%publication-failed?18649%_
                                                (let ()
                                                  (declare (not safe))
                                                  (error '"ASCENT engine publication requires source replay"))
                                                '#!void)))
                                      (if _%first-run?18720%_
                                          (let ()
                                            (declare (not safe))
                                            (error '"ASCENT session must run before source updates"))
                                          '#!void)
                                      (let* ((_%index18904%_
                                              (_%position-of18652%_
                                               _%name18901%_))
                                             (_%width18906%_
                                              (vector-ref
                                               _%arity18601%_
                                               _%index18904%_))
                                             (_%built-in-set?18908%_
                                              (let ((__tmp37515
                                                     (vector-ref
                                                      _%storage-providers18633%_
                                                      _%index18904%_)))
                                                (declare (not safe))
                                                (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                                                 __tmp37515))))
                                        (if (and (list? _%row18902%_)
                                                 (= (let ()
                                                      (declare (not safe))
                                                      (##length _%row18902%_))
                                                    _%width18906%_))
                                            '#!void
                                            (let ()
                                              (declare (not safe))
                                              (error '"invalid ASCENT session source row"
                                                     _%name18901%_
                                                     _%row18902%_)))
                                        (let ((_%check18911%_
                                               (vector-ref
                                                _%field-checkers18603%_
                                                _%index18904%_)))
                                          (if _%check18911%_
                                              (_%check18911%_ _%row18902%_)
                                              '#!void))
                                        (if (>= _%source-count18643%_
                                                _%input-limit18585%_)
                                            (let ()
                                              (declare (not safe))
                                              (error '"ASCENT session input fact budget exceeded"))
                                            '#!void)
                                        (if (or (not _%positive-rules?18696%_)
                                                _%lattice-feeds-relation?18690%_
                                                _%recompute-from-source?18712%_
                                                (vector-ref
                                                 _%lattice-joins18629%_
                                                 _%index18904%_))
                                            (_%replay-source!18735%_
                                             'append
                                             _%index18904%_
                                             (let ((__tmp37517
                                                    (let* ((_%state18923%_
                                                            _%source-state18700%_)
                                                           (_%index18926%_
                                                            _%index18904%_)
                                                           (_%state18930%_
                                                            _%state18923%_))
                                                      (declare (not safe))
                                                      (gerbil-ascent/program/source-state#__gerbil-ascent-source-state-rows
                                                       _%state18930%_
                                                       _%index18926%_)))
                                                   (__tmp37516
                                                    (list _%row18902%_)))
                                               (declare (not safe))
                                               (##append
                                                __tmp37517
                                                __tmp37516)))
                                            (if (_%view-relation?18655%_
                                                 _%index18904%_)
                                                (let ()
                                                  (_%flush-staged-set-rows!18729%_)
                                                  (let ((_%frontier18948%_
                                                         (let ((__tmp37520
                                                                (vector-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%storage-states18625%_
                         _%index18904%_))
                       (__tmp37519
                        (- _%output-limit18589%_
                           (+ _%source-materialized-count18645%_
                              _%derived-count18647%_)))
                       (__tmp37518
                        (vector-ref _%field-checkers18603%_ _%index18904%_)))
                   (declare (not safe))
                   (gerbil-ascent/program/view-state#gerbil-ascent-stage-view!
                    __tmp37520
                    _%row18902%_
                    __tmp37519
                    __tmp37518))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (set! _%source-count18643%_
                                                          (+ _%source-count18643%_
                                                             '1))
                                                    (if (> (let ()
                                                             (declare
                                                               (not safe))
                                                             (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                                                              _%frontier18948%_))
                                                           '0)
                                                        (begin
                                                          (set! _%dirty?18722%_
                                                                '#t)
                                                          (set! _%materialized-dirty?18718%_
                                                                '#t)
                                                          (set! _%source-materialized-count18645%_
                                                                (+ _%source-materialized-count18645%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/program/view-state#gerbil-ascent-frontier-count
                              _%frontier18948%_))))
                  (vector-set!
                   _%view-journals18639%_
                   _%index18904%_
                   (cons (let ((__tmp37523 (list _%row18902%_))
                               (__tmp37521
                                (let ((__tmp37522
                                       (vector-ref
                                        _%storage-states18625%_
                                        _%index18904%_)))
                                  (declare (not safe))
                                  (gerbil-ascent/table/storage#gerbil-ascent-storage-eqrel-state?
                                   __tmp37522))))
                           (declare (not safe))
                           (gerbil-ascent/program/view-state#gerbil-ascent-view-journal-event__%
                            'source
                            __tmp37523
                            __tmp37521))
                         (vector-ref _%view-journals18639%_ _%index18904%_)))
                  (_%commit-view!18656%_
                   _%index18904%_
                   (let ((__tmp37524
                          (vector-ref _%delta18609%_ _%index18904%_)))
                     (declare (not safe))
                     (gerbil-ascent/program/view-state#gerbil-ascent-add-frontier
                      __tmp37524
                      _%frontier18948%_))))
                '#!void)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (if _%built-in-set?18908%_
                                                    (_%append-set-source!18736%_
                                                     _%index18904%_
                                                     _%row18902%_)
                                                    (let ()
                                                      (_%flush-staged-set-rows!18729%_)
                                                      (let* ((_%expanded18952%_
                                                              ((vector-ref
                                                                _%storage-extensions18623%_
                                                                _%index18904%_)
                                                               (vector-ref
                                                                _%storage-states18625%_
                                                                _%index18904%_)
                                                               (vector-ref
                                                                _%all18607%_
                                                                _%index18904%_)
                                                               (vector-ref
                                                                _%delta18609%_
                                                                _%index18904%_)
                                                               _%row18902%_
                                                               (- _%output-limit18589%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (+ _%source-materialized-count18645%_
                             _%derived-count18647%_))))
                     (_%present18954%_
                      (vector-ref _%seen18627%_ _%index18904%_))
                     (_g37525_
                      (let ((__tmp37528
                             (vector-ref
                              _%field-checkers18603%_
                              _%index18904%_))
                            (__tmp37527
                             (+ _%source-materialized-count18645%_
                                _%derived-count18647%_)))
                        (declare (not safe))
                        (gerbil-ascent/program/admission#gerbil-ascent-prepare-storage-batch
                         _%expanded18952%_
                         _%width18906%_
                         __tmp37528
                         _%present18954%_
                         __tmp37527
                         _%output-limit18589%_))))
                (begin
                  (let ((_g37526_
                         (let ()
                           (declare (not safe))
                           (if (##values? _g37525_)
                               (##values-length _g37525_)
                               1))))
                    (if (not (let () (declare (not safe)) (##fx= _g37526_ 2)))
                        (error "Context expects 2 values" _g37526_)))
                  (let ((_%new-rows18957%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g37525_ 0)))
                        (_%added-count18958%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g37525_ 1))))
                    (begin
                      (set! _%source-count18643%_ (+ _%source-count18643%_ '1))
                      (let ((_%new-all18960%_
                             (vector-ref _%all18607%_ _%index18904%_))
                            (_%new-delta18961%_
                             (vector-ref _%delta18609%_ _%index18904%_)))
                        (for-each
                         (lambda (_%stored18963%_)
                           (let ()
                             (declare (not safe))
                             (hash-put! _%present18954%_ _%stored18963%_ '#t))
                           (set! _%new-all18960%_
                                 (cons _%stored18963%_ _%new-all18960%_))
                           (set! _%new-delta18961%_
                                 (cons _%stored18963%_ _%new-delta18961%_)))
                         _%new-rows18957%_)
                        (vector-set!
                         _%all18607%_
                         _%index18904%_
                         _%new-all18960%_)
                        (vector-set!
                         _%delta18609%_
                         _%index18904%_
                         _%new-delta18961%_))
                      (set! _%source-materialized-count18645%_
                            (+ _%source-materialized-count18645%_
                               _%added-count18958%_))
                      (if (pair? _%new-rows18957%_)
                          (begin
                            (set! _%dirty?18722%_ '#t)
                            (set! _%materialized-dirty?18718%_ '#t)
                            (let ()
                              (declare (not safe))
                              (_%advance-all-indexes!18657%_
                               _%index18904%_
                               _%new-rows18957%_))
                            (vector-set!
                             _%all-size18615%_
                             _%index18904%_
                             (+ (vector-ref _%all-size18615%_ _%index18904%_)
                                _%added-count18958%_))
                            (vector-set!
                             _%delta-size18617%_
                             _%index18904%_
                             (+ (vector-ref _%delta-size18617%_ _%index18904%_)
                                _%added-count18958%_))
                            (vector-set!
                             _%all-version18611%_
                             _%index18904%_
                             (+ '1
                                (vector-ref
                                 _%all-version18611%_
                                 _%index18904%_)))
                            (vector-set!
                             _%delta-version18613%_
                             _%index18904%_
                             (+ '1
                                (vector-ref
                                 _%delta-version18613%_
                                 _%index18904%_))))
                          '#!void)))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        (if (or (vector-ref
                                                 _%source-overrides18710%_
                                                 _%index18904%_)
                                                _%built-in-set?18908%_)
                                            '#!void
                                            (vector-set!
                                             _%source-additions18704%_
                                             _%index18904%_
                                             (cons _%row18902%_
                                                   (vector-ref
                                                    _%source-additions18704%_
                                                    _%index18904%_))))
                                        (let ((__tmp37529
                                               (vector-ref
                                                _%storage-states18625%_
                                                _%index18904%_)))
                                          (declare (not safe))
                                          (gerbil-ascent/table/storage#gerbil-ascent-storage-admit-state!
                                           __tmp37529)))))
                                   (_%append-single-set-source!18738%_
                                    (lambda (_%name18896%_ _%row18897%_)
                                      (if _%publication-failed?18649%_
                                          (let ()
                                            (declare (not safe))
                                            (error '"ASCENT engine publication requires source replay"))
                                          '#!void)
                                      (if _%recompute-from-source?18712%_
                                          (_%append-source!18737%_
                                           _%name18896%_
                                           _%row18897%_)
                                          (begin
                                            (if _%first-run?18720%_
                                                (let ()
                                                  (declare (not safe))
                                                  (error '"ASCENT session must run before source updates"))
                                                '#!void)
                                            (if (eq? _%name18896%_
                                                     (vector-ref
                                                      _%names18599%_
                                                      '0))
                                                '#!void
                                                (let ()
                                                  (declare (not safe))
                                                  (error '"unknown ASCENT relation"
                                                         _%name18896%_)))
                                            (if (and (list? _%row18897%_)
                                                     (= (let ()
                                                          (declare (not safe))
                                                          (##length
                                                           _%row18897%_))
                                                        (vector-ref
                                                         _%arity18601%_
                                                         '0)))
                                                '#!void
                                                (let ()
                                                  (declare (not safe))
                                                  (error '"invalid ASCENT session source row"
                                                         _%name18896%_
                                                         _%row18897%_)))
                                            (let ((_%check18899%_
                                                   (vector-ref
                                                    _%field-checkers18603%_
                                                    '0)))
                                              (if _%check18899%_
                                                  (_%check18899%_ _%row18897%_)
                                                  '#!void))
                                            (if (>= _%source-count18643%_
                                                    _%input-limit18585%_)
                                                (let ()
                                                  (declare (not safe))
                                                  (error '"ASCENT session input fact budget exceeded"))
                                                '#!void)
                                            (_%append-set-source!18736%_
                                             '0
                                             _%row18897%_)))))
                                   (_%replace-source!18739%_
                                    (lambda (_%name18888%_ _%rows18889%_)
                                      (if _%first-run?18720%_
                                          (let ()
                                            (declare (not safe))
                                            (error '"ASCENT session must run before source updates"))
                                          '#!void)
                                      (let* ((_%index18891%_
                                              (_%position-of18652%_
                                               _%name18888%_))
                                             (_%width18893%_
                                              (vector-ref
                                               _%arity18601%_
                                               _%index18891%_)))
                                        (let ((__tmp37530
                                               (vector-ref
                                                _%field-checkers18603%_
                                                _%index18891%_)))
                                          (declare (not safe))
                                          (gerbil-ascent/program/admission#gerbil-ascent-check-replacement-rows!
                                           _%name18888%_
                                           _%rows18889%_
                                           _%width18893%_
                                           __tmp37530))
                                        (_%replay-source!18735%_
                                         'replace
                                         _%index18891%_
                                         _%rows18889%_))))
                                   (_%run-session!18740%_
                                    (lambda ()
                                      (if _%recompute-from-source?18712%_
                                          _%last-result18724%_
                                          (begin
                                            (vector-set!
                                             _%published18733%_
                                             '0
                                             '#f)
                                            (_%run-retained!__3731637317%_
                                             _%published18733%_)))))
                                   (_%run-timeout!18741%_
                                    (lambda (_%duration-nanoseconds18885%_)
                                      (if (and (exact-integer?
                                                _%duration-nanoseconds18885%_)
                                               (>= _%duration-nanoseconds18885%_
                                                   '0))
                                          '#!void
                                          (let ()
                                            (declare (not safe))
                                            (error '"invalid ASCENT timeout in nanoseconds"
                                                   _%duration-nanoseconds18885%_)))
                                      (if _%recompute-from-source?18712%_
                                          _%last-result18724%_
                                          (begin
                                            (vector-set!
                                             _%published18733%_
                                             '0
                                             (+ (current-jiffy)
                                                (quotient
                                                 (* _%duration-nanoseconds18885%_
                                                    (jiffies-per-second))
                                                 '1000000000)))
                                            (_%run-retained!__3731637317%_
                                             _%published18733%_))))))
                            (let ((__tmp37531
                                   (let ((__obj37320
                                          (let ()
                                            (declare (not safe))
                                            (##structure
                                             clan/poo/object#object::t
                                             '#f
                                             '#f
                                             '#f
                                             '#f
                                             '#f
                                             '#f
                                             '#f))))
                                     (let ((__tmp37533
                                            (list (cons '.append-source!
                                                        (let ((__tmp37534
                                                               (lambda (_%@18832%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (if _%single-set-source?18698%_
                             _%append-single-set-source!18738%_
                             _%append-source!18737%_))))
                  (declare (not safe))
                  (##structure clan/poo/object#$self-slot-spec::t __tmp37534)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons '.replace-source!
                                                        (let ((__tmp37535
                                                               (lambda (_%@18838%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%replace-source!18739%_)))
                  (declare (not safe))
                  (##structure clan/poo/object#$self-slot-spec::t __tmp37535)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons '.run
                                                        (let ((__tmp37536
                                                               (lambda (_%@18843%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%run-session!18740%_)))
                  (declare (not safe))
                  (##structure clan/poo/object#$self-slot-spec::t __tmp37536)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons '.run-timeout
                                                        (let ((__tmp37537
                                                               (lambda (_%@18848%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%run-timeout!18741%_)))
                  (declare (not safe))
                  (##structure clan/poo/object#$self-slot-spec::t __tmp37537)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons '.analysis
                                                        (let ((__tmp37538
                                                               (lambda (_%@18853%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%analysis18670%_)))
                  (declare (not safe))
                  (##structure clan/poo/object#$self-slot-spec::t __tmp37538)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons '.schema
                                                        (let ((__tmp37539
                                                               (lambda (_%@18858%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%schema18597%_)))
                  (declare (not safe))
                  (##structure clan/poo/object#$self-slot-spec::t __tmp37539)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons '.native-publication
                                                        (let ((__tmp37540
                                                               (lambda (_%@18863%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (lambda () _%owned-publication18726%_))))
                  (declare (not safe))
                  (##structure clan/poo/object#$self-slot-spec::t __tmp37540)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons '.recomputed?
                                                        (let ((__tmp37541
                                                               (lambda (_%@18869%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (lambda () _%recompute-from-source?18712%_))))
                  (declare (not safe))
                  (##structure clan/poo/object#$self-slot-spec::t __tmp37541)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons '.source-additions
                                                        (let ((__tmp37542
                                                               (lambda (_%@18875%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%source-additions18704%_)))
                  (declare (not safe))
                  (##structure clan/poo/object#$self-slot-spec::t __tmp37542)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons '.source-overrides
                                                        (let ((__tmp37543
                                                               (lambda (_%@18880%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%source-overrides18710%_)))
                  (declare (not safe))
                  (##structure
                   clan/poo/object#$self-slot-spec::t
                   __tmp37543)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           (__tmp37532 (list)))
                                       (declare (not safe))
                                       (clan/poo/object#object:::init!__%
                                        '#f
                                        gerbil-ascent/program/evaluate#Session.
                                        __tmp37533
                                        __tmp37532
                                        __obj37320))
                                     __obj37320)))
                              (declare (not safe))
                              (clan/poo/mop#validate
                               gerbil-ascent/program/types#GerbilAscentSessionContract
                               __tmp37531))))
                        _%run!18731%_)))))))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__0
      (lambda (_%program19534%_ _%session?19535%_)
        (let* ((_%analysis-override19537%_ '#f)
               (_%schema-override19539%_ '#f)
               (_%measure-rule-times?19541%_ '#f)
               (_%plan-error19543%_ '#f)
               (_%reuse19545%_ '#f)
               (_%workers19547%_ '1)
               (_%canceled?19549%_ '#f))
          (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
           _%program19534%_
           _%session?19535%_
           _%analysis-override19537%_
           _%schema-override19539%_
           _%measure-rule-times?19541%_
           _%plan-error19543%_
           _%reuse19545%_
           _%workers19547%_
           _%canceled?19549%_))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__1
      (lambda (_%program19551%_ _%session?19552%_ _%analysis-override19553%_)
        (let* ((_%schema-override19555%_ '#f)
               (_%measure-rule-times?19557%_ '#f)
               (_%plan-error19559%_ '#f)
               (_%reuse19561%_ '#f)
               (_%workers19563%_ '1)
               (_%canceled?19565%_ '#f))
          (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
           _%program19551%_
           _%session?19552%_
           _%analysis-override19553%_
           _%schema-override19555%_
           _%measure-rule-times?19557%_
           _%plan-error19559%_
           _%reuse19561%_
           _%workers19563%_
           _%canceled?19565%_))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__2
      (lambda (_%program19567%_
               _%session?19568%_
               _%analysis-override19569%_
               _%schema-override19570%_)
        (let* ((_%measure-rule-times?19572%_ '#f)
               (_%plan-error19574%_ '#f)
               (_%reuse19576%_ '#f)
               (_%workers19578%_ '1)
               (_%canceled?19580%_ '#f))
          (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
           _%program19567%_
           _%session?19568%_
           _%analysis-override19569%_
           _%schema-override19570%_
           _%measure-rule-times?19572%_
           _%plan-error19574%_
           _%reuse19576%_
           _%workers19578%_
           _%canceled?19580%_))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__3
      (lambda (_%program19582%_
               _%session?19583%_
               _%analysis-override19584%_
               _%schema-override19585%_
               _%measure-rule-times?19586%_)
        (let* ((_%plan-error19588%_ '#f)
               (_%reuse19590%_ '#f)
               (_%workers19592%_ '1)
               (_%canceled?19594%_ '#f))
          (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
           _%program19582%_
           _%session?19583%_
           _%analysis-override19584%_
           _%schema-override19585%_
           _%measure-rule-times?19586%_
           _%plan-error19588%_
           _%reuse19590%_
           _%workers19592%_
           _%canceled?19594%_))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__4
      (lambda (_%program19596%_
               _%session?19597%_
               _%analysis-override19598%_
               _%schema-override19599%_
               _%measure-rule-times?19600%_
               _%plan-error19601%_)
        (let* ((_%reuse19603%_ '#f)
               (_%workers19605%_ '1)
               (_%canceled?19607%_ '#f))
          (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
           _%program19596%_
           _%session?19597%_
           _%analysis-override19598%_
           _%schema-override19599%_
           _%measure-rule-times?19600%_
           _%plan-error19601%_
           _%reuse19603%_
           _%workers19605%_
           _%canceled?19607%_))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__5
      (lambda (_%program19609%_
               _%session?19610%_
               _%analysis-override19611%_
               _%schema-override19612%_
               _%measure-rule-times?19613%_
               _%plan-error19614%_
               _%reuse19615%_)
        (let* ((_%workers19617%_ '1) (_%canceled?19619%_ '#f))
          (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
           _%program19609%_
           _%session?19610%_
           _%analysis-override19611%_
           _%schema-override19612%_
           _%measure-rule-times?19613%_
           _%plan-error19614%_
           _%reuse19615%_
           _%workers19617%_
           _%canceled?19619%_))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__6
      (lambda (_%program19621%_
               _%session?19622%_
               _%analysis-override19623%_
               _%schema-override19624%_
               _%measure-rule-times?19625%_
               _%plan-error19626%_
               _%reuse19627%_
               _%workers19628%_)
        (let ((_%canceled?19630%_ '#f))
          (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
           _%program19621%_
           _%session?19622%_
           _%analysis-override19623%_
           _%schema-override19624%_
           _%measure-rule-times?19625%_
           _%plan-error19626%_
           _%reuse19627%_
           _%workers19628%_
           _%canceled?19630%_))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-make-engine
      (lambda _g37544_
        (let ((_g37545_ (let () (declare (not safe)) (##length _g37544_))))
          (cond ((let () (declare (not safe)) (##fx= _g37545_ 2))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__0
                        _g37544_))
                ((let () (declare (not safe)) (##fx= _g37545_ 3))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__1
                        _g37544_))
                ((let () (declare (not safe)) (##fx= _g37545_ 4))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__2
                        _g37544_))
                ((let () (declare (not safe)) (##fx= _g37545_ 5))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__3
                        _g37544_))
                ((let () (declare (not safe)) (##fx= _g37545_ 6))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__4
                        _g37544_))
                ((let () (declare (not safe)) (##fx= _g37545_ 7))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__5
                        _g37544_))
                ((let () (declare (not safe)) (##fx= _g37545_ 8))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__6
                        _g37544_))
                ((let () (declare (not safe)) (##fx= _g37545_ 9))
                 (apply gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
                        _g37544_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/evaluate#gerbil-ascent-make-engine
                  _g37544_))))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-evaluate-program__%
      (lambda (_%@@keywords18533%_
               _%$%measure-rule-times?1852818534%_
               _%$%workers1852918535%_
               _%$%canceled?1853018536%_
               _%program18537%_)
        (let* ((_%measure-rule-times?18539%_
                (if (eq? _%$%measure-rule-times?1852818534%_ absent-value)
                    '#f
                    _%$%measure-rule-times?1852818534%_))
               (_%workers18541%_
                (if (eq? _%$%workers1852918535%_ absent-value)
                    '1
                    _%$%workers1852918535%_))
               (_%canceled?18543%_
                (if (eq? _%$%canceled?1853018536%_ absent-value)
                    '#f
                    _%$%canceled?1853018536%_)))
          (if (boolean? _%measure-rule-times?18539%_)
              '#!void
              (let ()
                (declare (not safe))
                (error '"invalid ASCENT rule timing option"
                       _%measure-rule-times?18539%_)))
          ((gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__%
            _%program18537%_
            '#f
            '#f
            '#f
            _%measure-rule-times?18539%_
            '#f
            '#f
            _%workers18541%_
            _%canceled?18543%_)))))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-evaluate-program__@
      (lambda (_%@@keywords18548%_ . _%args18549%_)
        (apply gerbil-ascent/program/evaluate#gerbil-ascent-evaluate-program__%
               _%@@keywords18548%_
               (let ()
                 (declare (not safe))
                 (symbolic-table-ref
                  _%@@keywords18548%_
                  'measure-rule-times?:
                  absent-value))
               (let ()
                 (declare (not safe))
                 (symbolic-table-ref
                  _%@@keywords18548%_
                  'workers:
                  absent-value))
               (let ()
                 (declare (not safe))
                 (symbolic-table-ref
                  _%@@keywords18548%_
                  'canceled?:
                  absent-value))
               _%args18549%_)))
    (define gerbil-ascent/program/evaluate#gerbil-ascent-evaluate-program
      (lambda _%$%args1853118555%_
        (apply keyword-dispatch
               '#(measure-rule-times?: #f workers: canceled?: #f #f)
               gerbil-ascent/program/evaluate#gerbil-ascent-evaluate-program__@
               _%$%args1853118555%_)))))
