(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/scheme-checked::timestamp 1791689697)
  (begin
    (define gerbil-ascent/program/scheme-checked#+stable-procedures+
      (let ((__tmp36296 (make-mutex)))
        (declare (not safe))
        (make-hash-table__%
         '#f
         absent-value
         absent-value
         eq?
         absent-value
         __tmp36296
         absent-value
         '#t
         absent-value)))
    (define gerbil-ascent/program/scheme-checked#relational-stable
      (lambda (_%procedure11904%_)
        (let ()
          (declare (not safe))
          (__hash-put!
           gerbil-ascent/program/scheme-checked#+stable-procedures+
           _%procedure11904%_
           '#t))
        _%procedure11904%_))
    (define gerbil-ascent/program/scheme-checked#relational-stable-procedure?
      (lambda (_%procedure11902%_)
        (if (procedure? _%procedure11902%_)
            (if (let ()
                  (declare (not safe))
                  (__hash-get
                   gerbil-ascent/program/scheme-checked#+stable-procedures+
                   _%procedure11902%_))
                '#t
                '#f)
            '#f)))
    (define gerbil-ascent/program/scheme-checked#relational-scalar?
      (lambda (_%value11891%_)
        (let ((_%$e11893%_ (exact-integer? _%value11891%_)))
          (if _%$e11893%_
              _%$e11893%_
              (let ((_%$e11896%_ (boolean? _%value11891%_)))
                (if _%$e11896%_
                    _%$e11896%_
                    (let ((_%$e11899%_ (symbol? _%value11891%_)))
                      (if _%$e11899%_
                          _%$e11899%_
                          (char? _%value11891%_)))))))))
    (define gerbil-ascent/program/scheme-checked#relational-check-row-shape!
      (lambda (_%row11888%_ _%arity11889%_)
        (if (and (list? _%row11888%_)
                 (= (let () (declare (not safe)) (##length _%row11888%_))
                    _%arity11889%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational row has wrong arity or non-scalar value"
                     _%row11888%_)))
        _%row11888%_))
    (define gerbil-ascent/program/scheme-checked#relational-check-row!
      (lambda (_%row11885%_ _%arity11886%_)
        (gerbil-ascent/program/scheme-checked#relational-check-row-shape!
         _%row11885%_
         _%arity11886%_)
        (if (let ()
              (declare (not safe))
              (andmap__0
               gerbil-ascent/program/scheme-checked#relational-scalar?
               _%row11885%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational row has wrong arity or non-scalar value"
                     _%row11885%_)))
        _%row11885%_))
    (define gerbil-ascent/program/scheme-checked#relational-copy-row
      (lambda (_%row11880%_ _%arity11881%_)
        (gerbil-ascent/program/scheme-checked#relational-check-row-shape!
         _%row11880%_
         _%arity11881%_)
        (map (lambda (_%value11883%_)
               (if (gerbil-ascent/program/scheme-checked#relational-scalar?
                    _%value11883%_)
                   '#!void
                   (let ()
                     (declare (not safe))
                     (error '"relational row has wrong arity or non-scalar value"
                            _%row11880%_)))
               _%value11883%_)
             _%row11880%_)))
    (define gerbil-ascent/program/scheme-checked#relational-copy-rows
      (lambda (_%rows11875%_ _%arity11876%_)
        (if (and (exact-integer? _%arity11876%_)
                 (<= '0 _%arity11876%_)
                 (list? _%rows11875%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid relational row signature" _%arity11876%_)))
        (map (lambda (_%row11878%_)
               (gerbil-ascent/program/scheme-checked#relational-copy-row
                _%row11878%_
                _%arity11876%_))
             _%rows11875%_)))
    (define gerbil-ascent/program/scheme-checked#relational-finite-rows
      (lambda (_%input-arity11867%_ _%output-arity11868%_ _%entries11869%_)
        (if (and (exact-integer? _%input-arity11867%_)
                 (<= '0 _%input-arity11867%_)
                 (exact-integer? _%output-arity11868%_)
                 (<= '0 _%output-arity11868%_)
                 (list? _%entries11869%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid finite view signature")))
        (map (lambda (_%entry11871%_)
               (if (and (list? _%entry11871%_)
                        (= (let ()
                             (declare (not safe))
                             (##length _%entry11871%_))
                           '2))
                   '#!void
                   (let ()
                     (declare (not safe))
                     (error '"finite view entry needs input and output rows"
                            _%entry11871%_)))
               (let* ((_%input11873%_
                       (gerbil-ascent/program/scheme-checked#relational-check-row!
                        (car _%entry11871%_)
                        _%input-arity11867%_))
                      (__tmp36297
                       (gerbil-ascent/program/scheme-checked#relational-copy-row
                        (cadr _%entry11871%_)
                        _%output-arity11868%_)))
                 (declare (not safe))
                 (##append _%input11873%_ __tmp36297)))
             _%entries11869%_)))
    (define gerbil-ascent/program/scheme-checked#relational-source
      (lambda (_%name11863%_ _%arity11864%_ _%rows11865%_)
        (gerbil-ascent/program/scheme-checked#relational-owned-source
         _%name11863%_
         _%arity11864%_
         (gerbil-ascent/program/scheme-checked#relational-copy-rows
          _%rows11865%_
          _%arity11864%_))))
    (define gerbil-ascent/program/scheme-checked#relational-owned-source
      (lambda (_%name11859%_ _%arity11860%_ _%rows11861%_)
        (let ((__tmp36298
               (make-list
                _%arity11860%_
                gerbil-ascent/program/scheme-checked#relational-scalar?)))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-relation__3
           _%name11859%_
           _%arity11860%_
           _%rows11861%_
           gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider
           gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider
           __tmp36298))))
    (define gerbil-ascent/program/scheme-checked#relational-domain-copy
      (lambda (_%arity11854%_ _%domains11855%_)
        (if (and (list? _%domains11855%_)
                 (= (let () (declare (not safe)) (##length _%domains11855%_))
                    _%arity11854%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"finite domain column count mismatch")))
        (map (lambda (_%atoms11857%_)
               (if (and (list? _%atoms11857%_)
                        (<= (let ()
                              (declare (not safe))
                              (##length _%atoms11857%_))
                            '4096)
                        (let ()
                          (declare (not safe))
                          (andmap__0
                           gerbil-ascent/program/scheme-checked#relational-scalar?
                           _%atoms11857%_)))
                   '#!void
                   (let ()
                     (declare (not safe))
                     (error '"invalid finite scalar domain")))
               (map identity _%atoms11857%_))
             _%domains11855%_)))
    (define gerbil-ascent/program/scheme-checked#relational-domain-predicates
      (lambda (_%domains11848%_)
        (map (lambda (_%atoms11850%_)
               (lambda (_%value11852%_)
                 (if (member _%value11852%_ _%atoms11850%_) '#t '#f)))
             _%domains11848%_)))
    (define gerbil-ascent/program/scheme-checked#relational-finite-source
      (lambda (_%name11841%_ _%arity11842%_ _%rows11843%_ _%domains11844%_)
        (let ((_%copied11846%_
               (gerbil-ascent/program/scheme-checked#relational-domain-copy
                _%arity11842%_
                _%domains11844%_)))
          (let ((__tmp36301
                 (gerbil-ascent/program/scheme-checked#relational-copy-rows
                  _%rows11843%_
                  _%arity11842%_))
                (__tmp36300
                 (gerbil-ascent/program/scheme-checked#relational-domain-predicates
                  _%copied11846%_))
                (__tmp36299 (vector 'finite-domain _%copied11846%_)))
            (declare (not safe))
            (gerbil-ascent/program/objects#gerbil-ascent-relation__%
             _%name11841%_
             _%arity11842%_
             __tmp36301
             gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider
             gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider
             __tmp36300
             __tmp36299)))))
    (define gerbil-ascent/program/scheme-checked#relational-finite-lattice
      (lambda (_%name11833%_
               _%arity11834%_
               _%rows11835%_
               _%mode11836%_
               _%domains11837%_)
        (if (> _%arity11834%_ '0)
            '#!void
            (let ()
              (declare (not safe))
              (error '"finite lattice needs a value column")))
        (let ((_%copied11839%_
               (gerbil-ascent/program/scheme-checked#relational-domain-copy
                _%arity11834%_
                _%domains11837%_)))
          (if (let ((__tmp36302 (last _%copied11839%_)))
                (declare (not safe))
                (andmap__0 exact-integer? __tmp36302))
              '#!void
              (let ()
                (declare (not safe))
                (error '"finite lattice value domain must contain exact integers")))
          (let ((__tmp36307
                 (gerbil-ascent/program/scheme-checked#relational-copy-rows
                  _%rows11835%_
                  _%arity11834%_))
                (__tmp36306
                 (gerbil-ascent/program/scheme-checked#relational-lattice-join
                  _%mode11836%_))
                (__tmp36305
                 (gerbil-ascent/program/scheme-checked#relational-domain-predicates
                  _%copied11839%_))
                (__tmp36304 (vector 'lattice _%mode11836%_))
                (__tmp36303 (vector 'finite-domain _%copied11839%_)))
            (declare (not safe))
            (gerbil-ascent/program/objects#gerbil-ascent-lattice__%
             _%name11833%_
             _%arity11834%_
             __tmp36307
             __tmp36306
             gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider
             __tmp36305
             __tmp36304
             __tmp36303)))))
    (define gerbil-ascent/program/scheme-checked#relational-lattice-join
      (lambda (_%mode11822%_)
        (gerbil-ascent/program/scheme-checked#relational-stable
         (let ((_%$e11824%_ _%mode11822%_))
           (if (eq? 'max _%$e11824%_)
               (lambda (_%left11827%_ _%right11828%_)
                 (if (and (exact-integer? _%left11827%_)
                          (exact-integer? _%right11828%_))
                     '#!void
                     (let ()
                       (declare (not safe))
                       (error '"max lattice needs exact integer values")))
                 (max _%left11827%_ _%right11828%_))
               (if (eq? 'min _%$e11824%_)
                   (lambda (_%left11830%_ _%right11831%_)
                     (if (and (exact-integer? _%left11830%_)
                              (exact-integer? _%right11831%_))
                         '#!void
                         (let ()
                           (declare (not safe))
                           (error '"min lattice needs exact integer values")))
                     (min _%left11830%_ _%right11831%_))
                   (let ()
                     (declare (not safe))
                     (error '"unknown checked lattice join"
                            _%mode11822%_))))))))
    (define gerbil-ascent/program/scheme-checked#relational-checked-lattice
      (lambda (_%name11813%_ _%arity11814%_ _%rows11815%_ _%mode11816%_)
        (if (and (exact-integer? _%arity11814%_)
                 (> _%arity11814%_ '0)
                 (list? _%rows11815%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid checked lattice signature"
                     _%name11813%_
                     _%arity11814%_)))
        (let ((_%copied11818%_
               (gerbil-ascent/program/scheme-checked#relational-copy-rows
                _%rows11815%_
                _%arity11814%_)))
          (let ((__tmp36308
                 (lambda (_%row11820%_)
                   (if (exact-integer? (last _%row11820%_))
                       '#!void
                       (let ()
                         (declare (not safe))
                         (error '"checked lattice needs exact integer value"
                                _%row11820%_))))))
            (declare (not safe))
            (##for-each __tmp36308 _%copied11818%_))
          (let ((__tmp36313
                 (gerbil-ascent/program/scheme-checked#relational-lattice-join
                  _%mode11816%_))
                (__tmp36310
                 (let ((__tmp36312
                        (make-list
                         (- _%arity11814%_ '1)
                         gerbil-ascent/program/scheme-checked#relational-scalar?))
                       (__tmp36311 (list exact-integer?)))
                   (declare (not safe))
                   (##append __tmp36312 __tmp36311)))
                (__tmp36309 (vector 'lattice _%mode11816%_)))
            (declare (not safe))
            (gerbil-ascent/program/objects#gerbil-ascent-lattice__3
             _%name11813%_
             _%arity11814%_
             _%copied11818%_
             __tmp36313
             gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider
             __tmp36310
             __tmp36309)))))
    (define gerbil-ascent/program/scheme-checked#relational-lattice-fragment
      (lambda (_%label11806%_ _%arity11807%_ _%rows11808%_ _%mode11809%_)
        (if (symbol? _%label11806%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"lattice fragment label must be a symbol"
                     _%label11806%_)))
        (let ((_%handle11811%_
               (let () (declare (not safe)) (##gensym 'lattice))))
          (let ((__tmp36316
                 (list (gerbil-ascent/program/scheme-checked#relational-checked-lattice
                        _%handle11811%_
                        _%arity11807%_
                        _%rows11808%_
                        _%mode11809%_)))
                (__tmp36315 (list (cons _%label11806%_ _%handle11811%_)))
                (__tmp36314 (list _%handle11811%_)))
            (declare (not safe))
            (gerbil-ascent/program/objects#gerbil-ascent-fragment__%
             __tmp36316
             '()
             __tmp36315
             __tmp36314)))))
    (define gerbil-ascent/program/scheme-checked#relational-finite-view
      (lambda (_%label11799%_
               _%input-arity11800%_
               _%output-arity11801%_
               _%entries11802%_)
        (if (symbol? _%label11799%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"finite view label must be a symbol" _%label11799%_)))
        (let ((_%handle11804%_ (let () (declare (not safe)) (##gensym 'view))))
          (let ((__tmp36319
                 (list (gerbil-ascent/program/scheme-checked#relational-owned-source
                        _%handle11804%_
                        (+ _%input-arity11800%_ _%output-arity11801%_)
                        (gerbil-ascent/program/scheme-checked#relational-finite-rows
                         _%input-arity11800%_
                         _%output-arity11801%_
                         _%entries11802%_))))
                (__tmp36318 (list (cons _%label11799%_ _%handle11804%_)))
                (__tmp36317 (list _%handle11804%_)))
            (declare (not safe))
            (gerbil-ascent/program/objects#gerbil-ascent-fragment__%
             __tmp36319
             '()
             __tmp36318
             __tmp36317)))))
    (define gerbil-ascent/program/scheme-checked#relational-captured-value
      (lambda (_%value11797%_)
        (if (gerbil-ascent/program/scheme-checked#relational-scalar?
             _%value11797%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational value capture requires an immutable scalar"
                     _%value11797%_)))
        (let ()
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-literal
           _%value11797%_))))
    (define gerbil-ascent/program/scheme-checked#relational-operator-literal
      (lambda (_%value11795%_)
        (if (gerbil-ascent/program/scheme-checked#relational-scalar?
             _%value11795%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational operator literal requires a scalar"
                     _%value11795%_)))
        (vector 'literal _%value11795%_)))
    (define gerbil-ascent/program/scheme-checked#relational-copy-operand
      (lambda (_%operand11787%_)
        (if (symbol? _%operand11787%_)
            (vector 'variable _%operand11787%_)
            (if (and (vector? _%operand11787%_)
                     (= (let ()
                          (declare (not safe))
                          (##vector-length _%operand11787%_))
                        '2))
                (let ((_%$e11791%_ (vector-ref _%operand11787%_ '0)))
                  (if (eq? 'variable _%$e11791%_)
                      (begin
                        (if (symbol? (vector-ref _%operand11787%_ '1))
                            '#!void
                            (let ()
                              (declare (not safe))
                              (error '"invalid relational operator variable"
                                     _%operand11787%_)))
                        (vector 'variable (vector-ref _%operand11787%_ '1)))
                      (if (eq? 'literal _%$e11791%_)
                          (gerbil-ascent/program/scheme-checked#relational-operator-literal
                           (vector-ref _%operand11787%_ '1))
                          (let ()
                            (declare (not safe))
                            (error '"invalid relational operator operand"
                                   _%operand11787%_)))))
                (let ()
                  (declare (not safe))
                  (error '"invalid relational operator operand"
                         _%operand11787%_))))))
    (define gerbil-ascent/program/scheme-checked#relational-operand-variables
      (lambda (_%operands11783%_)
        (if (list? _%operands11783%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational operator operands must be a list"
                     _%operands11783%_)))
        (let ((__tmp36320
               (lambda (_%operand11785%_)
                 (if (vector? _%operand11785%_)
                     (if (= (let ()
                              (declare (not safe))
                              (##vector-length _%operand11785%_))
                            '2)
                         (if (eq? (vector-ref _%operand11785%_ '0) 'variable)
                             (vector-ref _%operand11785%_ '1)
                             '#f)
                         '#f)
                     '#f))))
          (declare (not safe))
          (filter-map__0 __tmp36320 _%operands11783%_))))
    (define gerbil-ascent/program/scheme-checked#relational-operator-call
      (lambda (_%operation-procedure11489%_ _%operands11490%_)
        (gerbil-ascent/program/scheme-checked#relational-stable
         (let* ((_%$%operands1149111506%_ _%operands11490%_)
                (_%$%E1149511510%_
                 (lambda ()
                   (let ()
                     (declare (not safe))
                     (error '"No clause matching"
                            _%$%operands1149111506%_
                            '([operand])
                            '([left right])
                            '(_)))
                   '#!void)))
           (let ((_%$%K1150211773%_
                  (lambda (_%operand11703%_)
                    (if (eq? (vector-ref _%operand11703%_ '0) 'variable)
                        (lambda _%values11705%_
                          (let* ((_%$%values1170711716%_ _%values11705%_)
                                 (_%$%E1171011720%_
                                  (lambda ()
                                    (let ()
                                      (declare (not safe))
                                      (error '"No clause matching"
                                             _%$%values1170711716%_
                                             '([value])
                                             '(_)))
                                    '#!void)))
                            (let ((_%$%K1171211733%_
                                   (lambda (_%value11731%_)
                                     (_%operation-procedure11489%_
                                      _%value11731%_)))
                                  (_%$%K1171111725%_
                                   (lambda ()
                                     (let ()
                                       (declare (not safe))
                                       (error '"relational operator argument mismatch")))))
                              (if (pair? _%$%values1170711716%_)
                                  (let ((_%$%tl1171411738%_
                                         (let ()
                                           (declare (not safe))
                                           (##cdr _%$%values1170711716%_)))
                                        (_%$%hd1171311736%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%values1170711716%_))))
                                    (if (null? _%$%tl1171411738%_)
                                        (let ((_%value11741%_
                                               _%$%hd1171311736%_))
                                          (declare (not safe))
                                          (_%operation-procedure11489%_
                                           _%value11741%_))
                                        (_%$%K1171111725%_)))
                                  (_%$%K1171111725%_)))))
                        (let ((_%value11743%_
                               (vector-ref _%operand11703%_ '1)))
                          (lambda _%values11745%_
                            (let* ((_%$%values1174711754%_ _%values11745%_)
                                   (_%$%E1175011758%_
                                    (lambda ()
                                      (let ()
                                        (declare (not safe))
                                        (error '"No clause matching"
                                               _%$%values1174711754%_
                                               '([])
                                               '(_)))
                                      '#!void)))
                              (let ((_%$%K1175211770%_
                                     (lambda ()
                                       (_%operation-procedure11489%_
                                        _%value11743%_)))
                                    (_%$%K1175111763%_
                                     (lambda ()
                                       (let ()
                                         (declare (not safe))
                                         (error '"relational operator argument mismatch")))))
                                (if (null? _%$%values1174711754%_)
                                    (_%$%K1175211770%_)
                                    (_%$%K1175111763%_)))))))))
                 (_%$%K1149711683%_
                  (lambda (_%right11522%_ _%left11523%_)
                    (if (eq? (vector-ref _%left11523%_ '0) 'variable)
                        (if (eq? (vector-ref _%right11522%_ '0) 'variable)
                            (lambda _%values11525%_
                              (let* ((_%$%values1152711538%_ _%values11525%_)
                                     (_%$%E1153011542%_
                                      (lambda ()
                                        (let ()
                                          (declare (not safe))
                                          (error '"No clause matching"
                                                 _%$%values1152711538%_
                                                 '([a b])
                                                 '(_)))
                                        '#!void)))
                                (let ((_%$%K1153211556%_
                                       (lambda (_%b11553%_ _%a11554%_)
                                         (_%operation-procedure11489%_
                                          _%a11554%_
                                          _%b11553%_)))
                                      (_%$%K1153111547%_
                                       (lambda ()
                                         (let ()
                                           (declare (not safe))
                                           (error '"relational operator argument mismatch")))))
                                  (if (pair? _%$%values1152711538%_)
                                      (let ((_%$%tl1153411561%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%values1152711538%_)))
                                            (_%$%hd1153311559%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%values1152711538%_))))
                                        (if (pair? _%$%tl1153411561%_)
                                            (let ((_%$%tl1153611568%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%tl1153411561%_)))
                                                  (_%$%hd1153511566%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%tl1153411561%_))))
                                              (if (null? _%$%tl1153611568%_)
                                                  (let ((_%a11564%_
                                                         _%$%hd1153311559%_)
                                                        (_%b11571%_
                                                         _%$%hd1153511566%_))
                                                    (_%$%K1153211556%_
                                                     _%b11571%_
                                                     _%a11564%_))
                                                  (_%$%K1153111547%_)))
                                            (_%$%K1153111547%_)))
                                      (_%$%K1153111547%_)))))
                            (let ((_%b11573%_ (vector-ref _%right11522%_ '1)))
                              (lambda _%values11575%_
                                (let* ((_%$%values1157711586%_ _%values11575%_)
                                       (_%$%E1158011590%_
                                        (lambda ()
                                          (let ()
                                            (declare (not safe))
                                            (error '"No clause matching"
                                                   _%$%values1157711586%_
                                                   '([a])
                                                   '(_)))
                                          '#!void)))
                                  (let ((_%$%K1158211603%_
                                         (lambda (_%a11601%_)
                                           (_%operation-procedure11489%_
                                            _%a11601%_
                                            _%b11573%_)))
                                        (_%$%K1158111595%_
                                         (lambda ()
                                           (let ()
                                             (declare (not safe))
                                             (error '"relational operator argument mismatch")))))
                                    (if (pair? _%$%values1157711586%_)
                                        (let ((_%$%tl1158411608%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%values1157711586%_)))
                                              (_%$%hd1158311606%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%values1157711586%_))))
                                          (if (null? _%$%tl1158411608%_)
                                              (let ((_%a11611%_
                                                     _%$%hd1158311606%_))
                                                (_%$%K1158211603%_ _%a11611%_))
                                              (_%$%K1158111595%_)))
                                        (_%$%K1158111595%_)))))))
                        (let ((_%a11613%_ (vector-ref _%left11523%_ '1)))
                          (if (eq? (vector-ref _%right11522%_ '0) 'variable)
                              (lambda _%values11615%_
                                (let* ((_%$%values1161711626%_ _%values11615%_)
                                       (_%$%E1162011630%_
                                        (lambda ()
                                          (let ()
                                            (declare (not safe))
                                            (error '"No clause matching"
                                                   _%$%values1161711626%_
                                                   '([b])
                                                   '(_)))
                                          '#!void)))
                                  (let ((_%$%K1162211643%_
                                         (lambda (_%b11641%_)
                                           (_%operation-procedure11489%_
                                            _%a11613%_
                                            _%b11641%_)))
                                        (_%$%K1162111635%_
                                         (lambda ()
                                           (let ()
                                             (declare (not safe))
                                             (error '"relational operator argument mismatch")))))
                                    (if (pair? _%$%values1161711626%_)
                                        (let ((_%$%tl1162411648%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%values1161711626%_)))
                                              (_%$%hd1162311646%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%values1161711626%_))))
                                          (if (null? _%$%tl1162411648%_)
                                              (let ((_%b11651%_
                                                     _%$%hd1162311646%_))
                                                (_%$%K1162211643%_ _%b11651%_))
                                              (_%$%K1162111635%_)))
                                        (_%$%K1162111635%_)))))
                              (let ((_%b11653%_
                                     (vector-ref _%right11522%_ '1)))
                                (lambda _%values11655%_
                                  (let* ((_%$%values1165711664%_
                                          _%values11655%_)
                                         (_%$%E1166011668%_
                                          (lambda ()
                                            (let ()
                                              (declare (not safe))
                                              (error '"No clause matching"
                                                     _%$%values1165711664%_
                                                     '([])
                                                     '(_)))
                                            '#!void)))
                                    (let ((_%$%K1166211680%_
                                           (lambda ()
                                             (_%operation-procedure11489%_
                                              _%a11613%_
                                              _%b11653%_)))
                                          (_%$%K1166111673%_
                                           (lambda ()
                                             (let ()
                                               (declare (not safe))
                                               (error '"relational operator argument mismatch")))))
                                      (if (null? _%$%values1165711664%_)
                                          (_%$%K1166211680%_)
                                          (_%$%K1166111673%_)))))))))))
                 (_%$%K1149611515%_
                  (lambda ()
                    (let ()
                      (declare (not safe))
                      (error '"unsupported relational operator arity")))))
             (if (pair? _%$%operands1149111506%_)
                 (let ((_%$%tl1150411778%_
                        (let ()
                          (declare (not safe))
                          (##cdr _%$%operands1149111506%_)))
                       (_%$%hd1150311776%_
                        (let ()
                          (declare (not safe))
                          (##car _%$%operands1149111506%_))))
                   (if (null? _%$%tl1150411778%_)
                       (let ((_%operand11781%_ _%$%hd1150311776%_))
                         (_%$%K1150211773%_ _%operand11781%_))
                       (if (pair? _%$%tl1150411778%_)
                           (let ((_%$%tl1150111695%_
                                  (let ()
                                    (declare (not safe))
                                    (##cdr _%$%tl1150411778%_)))
                                 (_%$%hd1150011693%_
                                  (let ()
                                    (declare (not safe))
                                    (##car _%$%tl1150411778%_))))
                             (if (null? _%$%tl1150111695%_)
                                 (let ((_%left11691%_ _%$%hd1150311776%_)
                                       (_%right11698%_ _%$%hd1150011693%_))
                                   (_%$%K1149711683%_
                                    _%right11698%_
                                    _%left11691%_))
                                 (_%$%K1149611515%_)))
                           (_%$%K1149611515%_))))
                 (_%$%K1149611515%_)))))))
    (define gerbil-ascent/program/scheme-checked#relational-term-fingerprint
      (lambda (_%terms11485%_)
        (map (lambda (_%term11487%_)
               (cons (let ()
                       (declare (not safe))
                       (clan/poo/object#.ref _%term11487%_ 'kind))
                     (let ()
                       (declare (not safe))
                       (clan/poo/object#.ref _%term11487%_ 'value))))
             _%terms11485%_)))
    (define gerbil-ascent/program/scheme-checked#relational-reducer-procedure
      (lambda (_%mode11464%_ _%inputs11465%_)
        (gerbil-ascent/program/scheme-checked#relational-stable
         (let ((_%$e11467%_ _%mode11464%_))
           (if (eq? 'count _%$e11467%_)
               (begin
                 (if (null? _%inputs11465%_)
                     '#!void
                     (let ()
                       (declare (not safe))
                       (error '"checked count takes no value variable")))
                 gerbil-ascent/program/aggregators#gerbil-ascent-count)
               (if (or (eq? 'sum _%$e11467%_)
                       (eq? 'min _%$e11467%_)
                       (eq? 'max _%$e11467%_))
                   (begin
                     (if (= (length _%inputs11465%_) '1)
                         '#!void
                         (let ()
                           (declare (not safe))
                           (error '"checked numeric reduction needs one value variable")))
                     (let ((_%reducer11479%_
                            (let ((_%$e11476%_ _%mode11464%_))
                              (if (eq? 'sum _%$e11476%_)
                                  gerbil-ascent/program/aggregators#gerbil-ascent-sum
                                  (if (eq? 'min _%$e11476%_)
                                      gerbil-ascent/program/aggregators#gerbil-ascent-min
                                      (if (eq? 'max _%$e11476%_)
                                          gerbil-ascent/program/aggregators#gerbil-ascent-max
                                          '#!void))))))
                       (lambda (_%tuples11481%_)
                         (for-each
                          (lambda (_%tuple11483%_)
                            (if (and (list? _%tuple11483%_)
                                     (= (let ()
                                          (declare (not safe))
                                          (##length _%tuple11483%_))
                                        '1)
                                     (exact-integer? (car _%tuple11483%_)))
                                '#!void
                                (let ()
                                  (declare (not safe))
                                  (error '"numeric reduction needs exact integer rows"))))
                          _%tuples11481%_)
                         (_%reducer11479%_ _%tuples11481%_))))
                   (let ()
                     (declare (not safe))
                     (error '"unknown checked reducer" _%mode11464%_))))))))
    (define gerbil-ascent/program/scheme-checked#relational-reducer
      (lambda (_%output11458%_
               _%mode11459%_
               _%inputs11460%_
               _%relation11461%_
               _%terms11462%_)
        (let ((__tmp36322
               (gerbil-ascent/program/scheme-checked#relational-reducer-procedure
                _%mode11459%_
                _%inputs11460%_))
              (__tmp36321
               (vector 'reduce
                       _%mode11459%_
                       _%output11458%_
                       _%relation11461%_
                       (map identity _%inputs11460%_)
                       (gerbil-ascent/program/scheme-checked#relational-term-fingerprint
                        _%terms11462%_))))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-aggregate__%
           _%output11458%_
           _%relation11461%_
           _%terms11462%_
           _%inputs11460%_
           __tmp36322
           '#f
           __tmp36321))))
    (define gerbil-ascent/program/scheme-checked#relational-operator-procedure
      (lambda (_%mode11435%_ _%operation11436%_ _%arity11437%_)
        (let ((_%$e11439%_ _%mode11435%_))
          (if (eq? 'where _%$e11439%_)
              (let ((_%$e11442%_ _%operation11436%_))
                (if (eq? 'even? _%$e11442%_)
                    (begin
                      (if (= _%arity11437%_ '1)
                          '#!void
                          (let ()
                            (declare (not safe))
                            (error '"even? expects one relational input")))
                      (lambda (_%value11445%_)
                        (if (exact-integer? _%value11445%_)
                            '#!void
                            (let ()
                              (declare (not safe))
                              (error '"even? expects an exact integer"
                                     _%value11445%_)))
                        (even? _%value11445%_)))
                    (if (eq? '< _%$e11442%_)
                        (begin
                          (if (= _%arity11437%_ '2)
                              '#!void
                              (let ()
                                (declare (not safe))
                                (error '"< expects two relational inputs")))
                          (lambda (_%left11447%_ _%right11448%_)
                            (if (and (exact-integer? _%left11447%_)
                                     (exact-integer? _%right11448%_))
                                '#!void
                                (let ()
                                  (declare (not safe))
                                  (error '"< expects exact integers"
                                         _%left11447%_
                                         _%right11448%_)))
                            (< _%left11447%_ _%right11448%_)))
                        (let ()
                          (declare (not safe))
                          (error '"unknown relational filter operator"
                                 _%operation11436%_)))))
              (if (eq? 'compute _%$e11439%_)
                  (let ((_%$e11450%_ _%operation11436%_))
                    (if (eq? '+ _%$e11450%_)
                        (begin
                          (if (= _%arity11437%_ '2)
                              '#!void
                              (let ()
                                (declare (not safe))
                                (error '"+ expects two relational inputs")))
                          (lambda (_%left11453%_ _%right11454%_)
                            (if (and (exact-integer? _%left11453%_)
                                     (exact-integer? _%right11454%_))
                                '#!void
                                (let ()
                                  (declare (not safe))
                                  (error '"+ expects exact integers"
                                         _%left11453%_
                                         _%right11454%_)))
                            (+ _%left11453%_ _%right11454%_)))
                        (if (eq? 'identity _%$e11450%_)
                            (begin
                              (if (= _%arity11437%_ '1)
                                  '#!void
                                  (let ()
                                    (declare (not safe))
                                    (error '"identity expects one relational input")))
                              (lambda (_%value11456%_) _%value11456%_))
                            (let ()
                              (declare (not safe))
                              (error '"unknown relational projection operator"
                                     _%operation11436%_)))))
                  (let ()
                    (declare (not safe))
                    (error '"unknown relational operator mode"
                           _%mode11435%_)))))))
    (define gerbil-ascent/program/scheme-checked#relational-where
      (lambda (_%operation11427%_ _%variables11428%_)
        (let* ((_%operands11430%_
                (map gerbil-ascent/program/scheme-checked#relational-copy-operand
                     _%variables11428%_))
               (_%inputs11432%_
                (gerbil-ascent/program/scheme-checked#relational-operand-variables
                 _%operands11430%_)))
          (let ((__tmp36324
                 (gerbil-ascent/program/scheme-checked#relational-operator-call
                  (gerbil-ascent/program/scheme-checked#relational-operator-procedure
                   'where
                   _%operation11427%_
                   (let () (declare (not safe)) (##length _%operands11430%_)))
                  _%operands11430%_))
                (__tmp36323
                 (vector 'where _%operation11427%_ _%operands11430%_)))
            (declare (not safe))
            (gerbil-ascent/program/objects#gerbil-ascent-guard__%
             _%inputs11432%_
             __tmp36324
             __tmp36323)))))
    (define gerbil-ascent/program/scheme-checked#relational-compute
      (lambda (_%output11418%_ _%operation11419%_ _%variables11420%_)
        (let* ((_%operands11422%_
                (map gerbil-ascent/program/scheme-checked#relational-copy-operand
                     _%variables11420%_))
               (_%inputs11424%_
                (gerbil-ascent/program/scheme-checked#relational-operand-variables
                 _%operands11422%_)))
          (let ((__tmp36326
                 (gerbil-ascent/program/scheme-checked#relational-operator-call
                  (gerbil-ascent/program/scheme-checked#relational-operator-procedure
                   'compute
                   _%operation11419%_
                   (let () (declare (not safe)) (##length _%operands11422%_)))
                  _%operands11422%_))
                (__tmp36325
                 (vector 'compute
                         _%operation11419%_
                         _%operands11422%_
                         _%output11418%_)))
            (declare (not safe))
            (gerbil-ascent/program/objects#gerbil-ascent-binding__%
             _%output11418%_
             _%inputs11424%_
             __tmp36326
             __tmp36325)))))))
