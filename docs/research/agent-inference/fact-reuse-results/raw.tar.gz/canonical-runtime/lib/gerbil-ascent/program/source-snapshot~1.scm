(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/source-snapshot[1]#_g37079_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37081_|
    (##structure
     gx#syntax-quote::t
     'make-source-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37083_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37085_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-template
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37086_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-program
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37087_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-declarations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37088_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37089_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-materializations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37091_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-template-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37092_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-program-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37093_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-declarations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37094_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37095_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-materializations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37097_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-template
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37098_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-program
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37099_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-declarations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37100_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37101_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-materializations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37103_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-template-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37104_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-program-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37105_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-declarations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37106_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37107_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-materializations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37109_|
    (##structure
     gx#syntax-quote::t
     'source-materialization::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37111_|
    (##structure
     gx#syntax-quote::t
     'make-source-materialization
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37113_|
    (##structure
     gx#syntax-quote::t
     'source-materialization?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37115_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-base
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37116_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-additions
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37117_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37118_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-scalar?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37120_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-base-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37121_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-additions-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37122_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37123_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-scalar?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37125_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-base
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37126_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-additions
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37127_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37128_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-scalar?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37130_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-base-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37131_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-additions-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37132_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37133_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-scalar?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37135_|
    (gx#core-deserialize-mark
     '(0
       ($%arg11945 . _%$%arg1194512003%_)
       (id . _%id11970%_)
       (arg . _%arg12033%_)
       ($%arg11946 . _%$%arg1194612017%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37136_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g37135_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37139_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37140_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g37139_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37142_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g37139_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37144_|
    (gx#core-deserialize-mark
     '(0
       ($%arg12067 . _%$%arg1206712137%_)
       (id . _%id12090%_)
       ($%arg12066 . _%$%arg1206612123%_)
       (arg . _%arg12153%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37145_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g37144_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37148_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37149_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g37148_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37151_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g37148_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37153_|
    (gx#core-deserialize-mark
     '(0
       (id . _%id12210%_)
       ($%arg12186 . _%$%arg1218612243%_)
       (arg . _%arg12273%_)
       ($%arg12187 . _%$%arg1218712257%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37154_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g37153_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37157_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37158_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g37157_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37160_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g37157_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37162_|
    (gx#core-deserialize-mark
     '(0
       (id . _%id12330%_)
       ($%arg12307 . _%$%arg1230712377%_)
       (arg . _%arg12393%_)
       ($%arg12306 . _%$%arg1230612363%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37163_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g37162_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37166_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37167_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g37166_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g37169_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g37166_|)))
  (begin
    (define |gerbil-ascent/program/source-snapshot[:0:]#source-snapshot|
      (let ((__obj36958
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36958
           'gerbil-ascent/program/source-snapshot#source-snapshot::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36958 'source-snapshot '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36958
           '(template program declarations rows materializations)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36958
           '(template program declarations rows materializations)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36958 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36958 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36958 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36958 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36958 '#f '13 '#f '#f))
        (let ((__tmp37078 |gerbil-ascent/program/source-snapshot[1]#_g37079_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36958 __tmp37078 '4 '#f '#f))
        (let ((__tmp37080 |gerbil-ascent/program/source-snapshot[1]#_g37081_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36958 __tmp37080 '14 '#f '#f))
        (let ((__tmp37082 |gerbil-ascent/program/source-snapshot[1]#_g37083_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36958 __tmp37082 '15 '#f '#f))
        (let ((__tmp37084
               (cons (cons 'template
                           |gerbil-ascent/program/source-snapshot[1]#_g37085_|)
                     (cons (cons 'program
                                 |gerbil-ascent/program/source-snapshot[1]#_g37086_|)
                           (cons (cons 'declarations
                                       |gerbil-ascent/program/source-snapshot[1]#_g37087_|)
                                 (cons (cons 'rows
                                             |gerbil-ascent/program/source-snapshot[1]#_g37088_|)
                                       (cons (cons 'materializations
                                                   |gerbil-ascent/program/source-snapshot[1]#_g37089_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36958 __tmp37084 '16 '#f '#f))
        (let ((__tmp37090
               (cons (cons 'template
                           |gerbil-ascent/program/source-snapshot[1]#_g37091_|)
                     (cons (cons 'program
                                 |gerbil-ascent/program/source-snapshot[1]#_g37092_|)
                           (cons (cons 'declarations
                                       |gerbil-ascent/program/source-snapshot[1]#_g37093_|)
                                 (cons (cons 'rows
                                             |gerbil-ascent/program/source-snapshot[1]#_g37094_|)
                                       (cons (cons 'materializations
                                                   |gerbil-ascent/program/source-snapshot[1]#_g37095_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36958 __tmp37090 '17 '#f '#f))
        (let ((__tmp37096
               (cons (cons 'template
                           |gerbil-ascent/program/source-snapshot[1]#_g37097_|)
                     (cons (cons 'program
                                 |gerbil-ascent/program/source-snapshot[1]#_g37098_|)
                           (cons (cons 'declarations
                                       |gerbil-ascent/program/source-snapshot[1]#_g37099_|)
                                 (cons (cons 'rows
                                             |gerbil-ascent/program/source-snapshot[1]#_g37100_|)
                                       (cons (cons 'materializations
                                                   |gerbil-ascent/program/source-snapshot[1]#_g37101_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36958 __tmp37096 '18 '#f '#f))
        (let ((__tmp37102
               (cons (cons 'template
                           |gerbil-ascent/program/source-snapshot[1]#_g37103_|)
                     (cons (cons 'program
                                 |gerbil-ascent/program/source-snapshot[1]#_g37104_|)
                           (cons (cons 'declarations
                                       |gerbil-ascent/program/source-snapshot[1]#_g37105_|)
                                 (cons (cons 'rows
                                             |gerbil-ascent/program/source-snapshot[1]#_g37106_|)
                                       (cons (cons 'materializations
                                                   |gerbil-ascent/program/source-snapshot[1]#_g37107_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36958 __tmp37102 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36958 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36958 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36958 '() '21 '#f '#f))
        __obj36958))
    (define |gerbil-ascent/program/source-snapshot[:0:]#source-materialization|
      (let ((__obj36959
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36959
           'gerbil-ascent/program/source-snapshot#source-materialization::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36959
           'source-materialization
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36959
           '(base additions rows scalar?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36959
           '(base additions rows scalar?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36959 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36959 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36959 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36959 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36959 '#f '13 '#f '#f))
        (let ((__tmp37108 |gerbil-ascent/program/source-snapshot[1]#_g37109_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36959 __tmp37108 '4 '#f '#f))
        (let ((__tmp37110 |gerbil-ascent/program/source-snapshot[1]#_g37111_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36959 __tmp37110 '14 '#f '#f))
        (let ((__tmp37112 |gerbil-ascent/program/source-snapshot[1]#_g37113_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36959 __tmp37112 '15 '#f '#f))
        (let ((__tmp37114
               (cons (cons 'base
                           |gerbil-ascent/program/source-snapshot[1]#_g37115_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-snapshot[1]#_g37116_|)
                           (cons (cons 'rows
                                       |gerbil-ascent/program/source-snapshot[1]#_g37117_|)
                                 (cons (cons 'scalar?
                                             |gerbil-ascent/program/source-snapshot[1]#_g37118_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36959 __tmp37114 '16 '#f '#f))
        (let ((__tmp37119
               (cons (cons 'base
                           |gerbil-ascent/program/source-snapshot[1]#_g37120_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-snapshot[1]#_g37121_|)
                           (cons (cons 'rows
                                       |gerbil-ascent/program/source-snapshot[1]#_g37122_|)
                                 (cons (cons 'scalar?
                                             |gerbil-ascent/program/source-snapshot[1]#_g37123_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36959 __tmp37119 '17 '#f '#f))
        (let ((__tmp37124
               (cons (cons 'base
                           |gerbil-ascent/program/source-snapshot[1]#_g37125_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-snapshot[1]#_g37126_|)
                           (cons (cons 'rows
                                       |gerbil-ascent/program/source-snapshot[1]#_g37127_|)
                                 (cons (cons 'scalar?
                                             |gerbil-ascent/program/source-snapshot[1]#_g37128_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36959 __tmp37124 '18 '#f '#f))
        (let ((__tmp37129
               (cons (cons 'base
                           |gerbil-ascent/program/source-snapshot[1]#_g37130_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-snapshot[1]#_g37131_|)
                           (cons (cons 'rows
                                       |gerbil-ascent/program/source-snapshot[1]#_g37132_|)
                                 (cons (cons 'scalar?
                                             |gerbil-ascent/program/source-snapshot[1]#_g37133_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36959 __tmp37129 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36959 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36959 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36959 '() '21 '#f '#f))
        __obj36959))
    (define |gerbil-ascent/program/source-snapshot[:0:]#@materialize-source-log|
      (lambda (_%$stx11927%_)
        (let* ((_%__stx3685536856%_ _%$stx11927%_)
               (_%$%g1193211953%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3685536856%_)))))
          (let ((_%__kont3685836859%_
                 (lambda (_%$%g1193412019%_)
                   (cons (let ((__tmp37134
                                |gerbil-ascent/program/source-snapshot[1]#_g37136_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp37134
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'base))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'additions))
                                                 (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'previous))
                                                       '())))
                                     (cons (let ((__tmp37137
                                                  (lambda (_%$%g1203412037%_
                                                           _%$%g1203512040%_)
                                                    (cons _%$%g1203412037%_
                                                          _%$%g1203512040%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp37137
                                              '()
                                              _%$%g1193412019%_))
                                           '()))
                               (cons (cons (let ((__tmp37138
                                                  |gerbil-ascent/program/source-snapshot[1]#_g37140_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp37138
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'previous))
                     (cons (let ((__tmp37141
                                  |gerbil-ascent/program/source-snapshot[1]#_g37142_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp37141 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0
                                    '#f
                                    'source-materialization))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f '__materialize-source-log))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'base))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'additions))
                                 (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'previous))
                                       '()))))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3686236863%_
                 (lambda (_%$%g1194711960%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0 '#f 'materialize-source-log)))))
            (let* ((_%$%g1193111972%_
                    (lambda ()
                      (let ((_%$%g1194711960%_ _%__stx3685536856%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1194711960%_))
                            (_%__kont3686236863%_ _%$%g1194711960%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1193211953%_))))))
                   (_%__match3687836879%_
                    (lambda (_%$%e1193511979%_
                             _%$%hd1193611983%_
                             _%$%tl1193711986%_
                             _%__splice3686036861%_
                             _%$%target1193811989%_
                             _%$%tl1194011992%_)
                      (letrec ((_%$%loop1194111995%_
                                (lambda (_%$%hd1193911999%_
                                         _%$%arg1194512002%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1193911999%_))
                                      (let ((_%$%e1194212005%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1193911999%_))))
                                        (let ((_%$%lp-tl1194412012%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1194212005%_)))
                                              (_%$%lp-hd1194312009%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1194212005%_))))
                                          (_%$%loop1194111995%_
                                           _%$%lp-tl1194412012%_
                                           (cons _%$%lp-hd1194312009%_
                                                 _%$%arg1194512002%_))))
                                      (let ((_%$%arg1194612015%_
                                             (reverse _%$%arg1194512002%_)))
                                        (_%__kont3685836859%_
                                         _%$%arg1194612015%_))))))
                        (_%$%loop1194111995%_ _%$%target1193811989%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3685536856%_))
                  (let ((_%$%e1193511979%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3685536856%_))))
                    (let ((_%$%tl1193711986%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1193511979%_)))
                          (_%$%hd1193611983%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1193511979%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1193711986%_))
                          (let ((_%__splice3686036861%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1193711986%_
                                    '0))))
                            (let ((_%$%tl1194011992%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3686036861%_ '1)))
                                  (_%$%target1193811989%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3686036861%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1194011992%_))
                                  (_%__match3687836879%_
                                   _%$%e1193511979%_
                                   _%$%hd1193611983%_
                                   _%$%tl1193711986%_
                                   _%__splice3686036861%_
                                   _%$%target1193811989%_
                                   _%$%tl1194011992%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1193111972%_)))))
                          (let () (declare (not safe)) (_%$%g1193111972%_)))))
                  (let () (declare (not safe)) (_%$%g1193111972%_))))))))
    (define |gerbil-ascent/program/source-snapshot[:0:]#@gerbil-ascent-source-log-snapshot-equal?|
      (lambda (_%$stx12048%_)
        (let* ((_%__stx3688136882%_ _%$stx12048%_)
               (_%$%g1205312074%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3688136882%_)))))
          (let ((_%__kont3688436885%_
                 (lambda (_%$%g1205512139%_)
                   (cons (let ((__tmp37143
                                |gerbil-ascent/program/source-snapshot[1]#_g37145_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp37143
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'snapshot))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'candidate))
                                                 (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'index))
                                                       (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'log))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'rows))
                           '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     (cons (let ((__tmp37146
                                                  (lambda (_%$%g1215412157%_
                                                           _%$%g1215512160%_)
                                                    (cons _%$%g1215412157%_
                                                          _%$%g1215512160%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp37146
                                              '()
                                              _%$%g1205512139%_))
                                           '()))
                               (cons (cons (let ((__tmp37147
                                                  |gerbil-ascent/program/source-snapshot[1]#_g37149_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp37147
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'snapshot))
                     (cons (let ((__tmp37150
                                  |gerbil-ascent/program/source-snapshot[1]#_g37151_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp37150 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'source-snapshot))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0
                        '#f
                        '__gerbil-ascent-source-log-snapshot-equal?))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'snapshot))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'candidate))
                                 (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'index))
                                       (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f 'log))
                                             (cons (let ()
                                                     (declare (not safe))
                                                     (gx#datum->syntax__0
                                                      '#f
                                                      'rows))
                                                   '()))))))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3688836889%_
                 (lambda (_%$%g1206812081%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0
                      '#f
                      'gerbil-ascent-source-log-snapshot-equal?)))))
            (let* ((_%$%g1205212092%_
                    (lambda ()
                      (let ((_%$%g1206812081%_ _%__stx3688136882%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1206812081%_))
                            (_%__kont3688836889%_ _%$%g1206812081%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1205312074%_))))))
                   (_%__match3690436905%_
                    (lambda (_%$%e1205612099%_
                             _%$%hd1205712103%_
                             _%$%tl1205812106%_
                             _%__splice3688636887%_
                             _%$%target1205912109%_
                             _%$%tl1206112112%_)
                      (letrec ((_%$%loop1206212115%_
                                (lambda (_%$%hd1206012119%_
                                         _%$%arg1206612122%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1206012119%_))
                                      (let ((_%$%e1206312125%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1206012119%_))))
                                        (let ((_%$%lp-tl1206512132%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1206312125%_)))
                                              (_%$%lp-hd1206412129%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1206312125%_))))
                                          (_%$%loop1206212115%_
                                           _%$%lp-tl1206512132%_
                                           (cons _%$%lp-hd1206412129%_
                                                 _%$%arg1206612122%_))))
                                      (let ((_%$%arg1206712135%_
                                             (reverse _%$%arg1206612122%_)))
                                        (_%__kont3688436885%_
                                         _%$%arg1206712135%_))))))
                        (_%$%loop1206212115%_ _%$%target1205912109%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3688136882%_))
                  (let ((_%$%e1205612099%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3688136882%_))))
                    (let ((_%$%tl1205812106%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1205612099%_)))
                          (_%$%hd1205712103%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1205612099%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1205812106%_))
                          (let ((_%__splice3688636887%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1205812106%_
                                    '0))))
                            (let ((_%$%tl1206112112%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3688636887%_ '1)))
                                  (_%$%target1205912109%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3688636887%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1206112112%_))
                                  (_%__match3690436905%_
                                   _%$%e1205612099%_
                                   _%$%hd1205712103%_
                                   _%$%tl1205812106%_
                                   _%__splice3688636887%_
                                   _%$%target1205912109%_
                                   _%$%tl1206112112%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1205212092%_)))))
                          (let () (declare (not safe)) (_%$%g1205212092%_)))))
                  (let () (declare (not safe)) (_%$%g1205212092%_))))))))
    (define |gerbil-ascent/program/source-snapshot[:0:]#@gerbil-ascent-source-snapshot-scalar?|
      (lambda (_%$stx12168%_)
        (let* ((_%__stx3690736908%_ _%$stx12168%_)
               (_%$%g1217312194%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3690736908%_)))))
          (let ((_%__kont3691036911%_
                 (lambda (_%$%g1217512259%_)
                   (cons (let ((__tmp37152
                                |gerbil-ascent/program/source-snapshot[1]#_g37154_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp37152
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'snapshot))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'candidate))
                                                 (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'index))
                                                       (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'rows))
                     '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     (cons (let ((__tmp37155
                                                  (lambda (_%$%g1227412277%_
                                                           _%$%g1227512280%_)
                                                    (cons _%$%g1227412277%_
                                                          _%$%g1227512280%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp37155
                                              '()
                                              _%$%g1217512259%_))
                                           '()))
                               (cons (cons (let ((__tmp37156
                                                  |gerbil-ascent/program/source-snapshot[1]#_g37158_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp37156
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'snapshot))
                     (cons (let ((__tmp37159
                                  |gerbil-ascent/program/source-snapshot[1]#_g37160_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp37159 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'source-snapshot))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0
                        '#f
                        '__gerbil-ascent-source-snapshot-scalar?))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'snapshot))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'candidate))
                                 (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'index))
                                       (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f 'rows))
                                             '())))))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3691436915%_
                 (lambda (_%$%g1218812201%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0
                      '#f
                      'gerbil-ascent-source-snapshot-scalar?)))))
            (let* ((_%$%g1217212212%_
                    (lambda ()
                      (let ((_%$%g1218812201%_ _%__stx3690736908%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1218812201%_))
                            (_%__kont3691436915%_ _%$%g1218812201%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1217312194%_))))))
                   (_%__match3693036931%_
                    (lambda (_%$%e1217612219%_
                             _%$%hd1217712223%_
                             _%$%tl1217812226%_
                             _%__splice3691236913%_
                             _%$%target1217912229%_
                             _%$%tl1218112232%_)
                      (letrec ((_%$%loop1218212235%_
                                (lambda (_%$%hd1218012239%_
                                         _%$%arg1218612242%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1218012239%_))
                                      (let ((_%$%e1218312245%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1218012239%_))))
                                        (let ((_%$%lp-tl1218512252%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1218312245%_)))
                                              (_%$%lp-hd1218412249%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1218312245%_))))
                                          (_%$%loop1218212235%_
                                           _%$%lp-tl1218512252%_
                                           (cons _%$%lp-hd1218412249%_
                                                 _%$%arg1218612242%_))))
                                      (let ((_%$%arg1218712255%_
                                             (reverse _%$%arg1218612242%_)))
                                        (_%__kont3691036911%_
                                         _%$%arg1218712255%_))))))
                        (_%$%loop1218212235%_ _%$%target1217912229%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3690736908%_))
                  (let ((_%$%e1217612219%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3690736908%_))))
                    (let ((_%$%tl1217812226%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1217612219%_)))
                          (_%$%hd1217712223%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1217612219%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1217812226%_))
                          (let ((_%__splice3691236913%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1217812226%_
                                    '0))))
                            (let ((_%$%tl1218112232%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3691236913%_ '1)))
                                  (_%$%target1217912229%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3691236913%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1218112232%_))
                                  (_%__match3693036931%_
                                   _%$%e1217612219%_
                                   _%$%hd1217712223%_
                                   _%$%tl1217812226%_
                                   _%__splice3691236913%_
                                   _%$%target1217912229%_
                                   _%$%tl1218112232%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1217212212%_)))))
                          (let () (declare (not safe)) (_%$%g1217212212%_)))))
                  (let () (declare (not safe)) (_%$%g1217212212%_))))))))
    (define |gerbil-ascent/program/source-snapshot[:0:]#@gerbil-ascent-prepare-source-log-snapshot|
      (lambda (_%$stx12288%_)
        (let* ((_%__stx3693336934%_ _%$stx12288%_)
               (_%$%g1229312314%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3693336934%_)))))
          (let ((_%__kont3693636937%_
                 (lambda (_%$%g1229512379%_)
                   (cons (let ((__tmp37161
                                |gerbil-ascent/program/source-snapshot[1]#_g37163_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp37161
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'snapshot))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'logs))
                                                 '()))
                                     (cons (let ((__tmp37164
                                                  (lambda (_%$%g1239412397%_
                                                           _%$%g1239512400%_)
                                                    (cons _%$%g1239412397%_
                                                          _%$%g1239512400%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp37164
                                              '()
                                              _%$%g1229512379%_))
                                           '()))
                               (cons (cons (let ((__tmp37165
                                                  |gerbil-ascent/program/source-snapshot[1]#_g37167_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp37165
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'snapshot))
                     (cons (let ((__tmp37168
                                  |gerbil-ascent/program/source-snapshot[1]#_g37169_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp37168 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'source-snapshot))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0
                        '#f
                        '__gerbil-ascent-prepare-source-log-snapshot))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'snapshot))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'logs))
                                 '())))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3694036941%_
                 (lambda (_%$%g1230812321%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0
                      '#f
                      'gerbil-ascent-prepare-source-log-snapshot)))))
            (let* ((_%$%g1229212332%_
                    (lambda ()
                      (let ((_%$%g1230812321%_ _%__stx3693336934%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1230812321%_))
                            (_%__kont3694036941%_ _%$%g1230812321%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1229312314%_))))))
                   (_%__match3695636957%_
                    (lambda (_%$%e1229612339%_
                             _%$%hd1229712343%_
                             _%$%tl1229812346%_
                             _%__splice3693836939%_
                             _%$%target1229912349%_
                             _%$%tl1230112352%_)
                      (letrec ((_%$%loop1230212355%_
                                (lambda (_%$%hd1230012359%_
                                         _%$%arg1230612362%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1230012359%_))
                                      (let ((_%$%e1230312365%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1230012359%_))))
                                        (let ((_%$%lp-tl1230512372%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1230312365%_)))
                                              (_%$%lp-hd1230412369%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1230312365%_))))
                                          (_%$%loop1230212355%_
                                           _%$%lp-tl1230512372%_
                                           (cons _%$%lp-hd1230412369%_
                                                 _%$%arg1230612362%_))))
                                      (let ((_%$%arg1230712375%_
                                             (reverse _%$%arg1230612362%_)))
                                        (_%__kont3693636937%_
                                         _%$%arg1230712375%_))))))
                        (_%$%loop1230212355%_ _%$%target1229912349%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3693336934%_))
                  (let ((_%$%e1229612339%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3693336934%_))))
                    (let ((_%$%tl1229812346%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1229612339%_)))
                          (_%$%hd1229712343%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1229612339%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1229812346%_))
                          (let ((_%__splice3693836939%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1229812346%_
                                    '0))))
                            (let ((_%$%tl1230112352%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3693836939%_ '1)))
                                  (_%$%target1229912349%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3693836939%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1230112352%_))
                                  (_%__match3695636957%_
                                   _%$%e1229612339%_
                                   _%$%hd1229712343%_
                                   _%$%tl1229812346%_
                                   _%__splice3693836939%_
                                   _%$%target1229912349%_
                                   _%$%tl1230112352%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1229212332%_)))))
                          (let () (declare (not safe)) (_%$%g1229212332%_)))))
                  (let () (declare (not safe)) (_%$%g1229212332%_))))))))))
