(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37087_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37089_|
    (##structure
     gx#syntax-quote::t
     'make-grounding-rule
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37091_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37093_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-name
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37094_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-head
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37095_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-body
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37096_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-label
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37098_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-name-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37099_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-head-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37100_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-body-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37101_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-label-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37103_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-name
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37104_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-head
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37105_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-body
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37106_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-label
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37108_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-name-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37109_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-head-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37110_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-body-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37111_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-label-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37113_|
    (##structure
     gx#syntax-quote::t
     'grounding-clause::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37115_|
    (##structure
     gx#syntax-quote::t
     'make-grounding-clause
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37117_|
    (##structure
     gx#syntax-quote::t
     'grounding-clause?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37119_|
    (##structure
     gx#syntax-quote::t
     'grounding-clause-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37120_|
    (##structure
     gx#syntax-quote::t
     'grounding-clause-apply
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37122_|
    (##structure
     gx#syntax-quote::t
     'grounding-clause-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37123_|
    (##structure
     gx#syntax-quote::t
     'grounding-clause-apply-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37125_|
    (##structure
     gx#syntax-quote::t
     '&grounding-clause-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37126_|
    (##structure
     gx#syntax-quote::t
     '&grounding-clause-apply
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37128_|
    (##structure
     gx#syntax-quote::t
     '&grounding-clause-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37129_|
    (##structure
     gx#syntax-quote::t
     '&grounding-clause-apply-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/grounding-plan[:0:]#grounding-rule|
      (let ((__obj37049
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37049
           'gerbil-ascent/candidate/grounding-plan#grounding-rule::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37049 'grounding-rule '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37049
           '(name head body label)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37049
           '(name head body label)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37049 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37049 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37049 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37049 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37049 '#f '13 '#f '#f))
        (let ((__tmp37086
               |gerbil-ascent/candidate/grounding-plan[1]#_g37087_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37049 __tmp37086 '4 '#f '#f))
        (let ((__tmp37088
               |gerbil-ascent/candidate/grounding-plan[1]#_g37089_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37049 __tmp37088 '14 '#f '#f))
        (let ((__tmp37090
               |gerbil-ascent/candidate/grounding-plan[1]#_g37091_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37049 __tmp37090 '15 '#f '#f))
        (let ((__tmp37092
               (cons (cons 'name
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37093_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37094_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/grounding-plan[1]#_g37095_|)
                                 (cons (cons 'label
                                             |gerbil-ascent/candidate/grounding-plan[1]#_g37096_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37049 __tmp37092 '16 '#f '#f))
        (let ((__tmp37097
               (cons (cons 'name
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37098_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37099_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/grounding-plan[1]#_g37100_|)
                                 (cons (cons 'label
                                             |gerbil-ascent/candidate/grounding-plan[1]#_g37101_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37049 __tmp37097 '17 '#f '#f))
        (let ((__tmp37102
               (cons (cons 'name
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37103_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37104_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/grounding-plan[1]#_g37105_|)
                                 (cons (cons 'label
                                             |gerbil-ascent/candidate/grounding-plan[1]#_g37106_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37049 __tmp37102 '18 '#f '#f))
        (let ((__tmp37107
               (cons (cons 'name
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37108_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37109_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/grounding-plan[1]#_g37110_|)
                                 (cons (cons 'label
                                             |gerbil-ascent/candidate/grounding-plan[1]#_g37111_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37049 __tmp37107 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37049 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37049 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37049 '() '21 '#f '#f))
        __obj37049))
    (define |gerbil-ascent/candidate/grounding-plan[:0:]#grounding-clause|
      (let ((__obj37050
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37050
           'gerbil-ascent/candidate/grounding-plan#grounding-clause::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37050 'grounding-clause '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37050 '(relation apply) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37050 '(relation apply) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37050 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37050 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37050 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37050 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37050 '#f '13 '#f '#f))
        (let ((__tmp37112
               |gerbil-ascent/candidate/grounding-plan[1]#_g37113_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37050 __tmp37112 '4 '#f '#f))
        (let ((__tmp37114
               |gerbil-ascent/candidate/grounding-plan[1]#_g37115_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37050 __tmp37114 '14 '#f '#f))
        (let ((__tmp37116
               |gerbil-ascent/candidate/grounding-plan[1]#_g37117_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37050 __tmp37116 '15 '#f '#f))
        (let ((__tmp37118
               (cons (cons 'relation
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37119_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37120_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37050 __tmp37118 '16 '#f '#f))
        (let ((__tmp37121
               (cons (cons 'relation
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37122_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37123_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37050 __tmp37121 '17 '#f '#f))
        (let ((__tmp37124
               (cons (cons 'relation
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37125_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37126_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37050 __tmp37124 '18 '#f '#f))
        (let ((__tmp37127
               (cons (cons 'relation
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37128_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37129_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37050 __tmp37127 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37050 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37050 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37050 '() '21 '#f '#f))
        __obj37050))))
