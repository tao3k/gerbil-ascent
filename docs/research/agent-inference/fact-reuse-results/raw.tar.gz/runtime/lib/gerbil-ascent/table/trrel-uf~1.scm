(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/trrel-uf[1]#_g5246_|
    (##structure
     gx#syntax-quote::t
     'uf-node::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5248_|
    (##structure
     gx#syntax-quote::t
     'make-uf-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5250_|
    (##structure
     gx#syntax-quote::t
     'uf-node?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5252_|
    (##structure
     gx#syntax-quote::t
     'uf-node-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5253_|
    (##structure
     gx#syntax-quote::t
     'uf-node-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5254_|
    (##structure
     gx#syntax-quote::t
     'uf-node-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5255_|
    (##structure
     gx#syntax-quote::t
     'uf-node-reach
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5256_|
    (##structure
     gx#syntax-quote::t
     'uf-node-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5257_|
    (##structure
     gx#syntax-quote::t
     'uf-node-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5259_|
    (##structure
     gx#syntax-quote::t
     'uf-node-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5260_|
    (##structure
     gx#syntax-quote::t
     'uf-node-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5261_|
    (##structure
     gx#syntax-quote::t
     'uf-node-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5262_|
    (##structure
     gx#syntax-quote::t
     'uf-node-reach-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5263_|
    (##structure
     gx#syntax-quote::t
     'uf-node-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5264_|
    (##structure
     gx#syntax-quote::t
     'uf-node-order-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5266_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5267_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5268_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5269_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-reach
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5270_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5271_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5273_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5274_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5275_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5276_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-reach-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5277_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5278_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-order-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5280_|
    (##structure
     gx#syntax-quote::t
     'uf-group::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5282_|
    (##structure
     gx#syntax-quote::t
     'make-uf-group
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5284_|
    (##structure
     gx#syntax-quote::t
     'uf-group?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5286_|
    (##structure
     gx#syntax-quote::t
     'uf-group-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5287_|
    (##structure
     gx#syntax-quote::t
     'uf-group-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5288_|
    (##structure
     gx#syntax-quote::t
     'uf-group-next-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5289_|
    (##structure
     gx#syntax-quote::t
     'uf-group-indexed?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5291_|
    (##structure
     gx#syntax-quote::t
     'uf-group-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5292_|
    (##structure
     gx#syntax-quote::t
     'uf-group-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5293_|
    (##structure
     gx#syntax-quote::t
     'uf-group-next-order-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5294_|
    (##structure
     gx#syntax-quote::t
     'uf-group-indexed?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5296_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5297_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5298_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-next-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5299_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-indexed?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5301_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5302_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5303_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-next-order-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5304_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-indexed?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5306_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5308_|
    (##structure
     gx#syntax-quote::t
     'make-uf-insertion
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5310_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5312_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-group-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5313_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-group
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5314_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5315_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-left-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5316_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-right-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5317_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-a
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5318_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-b
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5320_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-group-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5321_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-group-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5322_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5323_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-left-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5324_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-right-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5325_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-a-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5326_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-b-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5328_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-group-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5329_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-group
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5330_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5331_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-left-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5332_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-right-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5333_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-a
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5334_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-b
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5336_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-group-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5337_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-group-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5338_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5339_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-left-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5340_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-right-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5341_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-a-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5342_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-b-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5344_|
    (##structure
     gx#syntax-quote::t
     'frozen-members::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5346_|
    (##structure
     gx#syntax-quote::t
     'make-frozen-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5348_|
    (##structure
     gx#syntax-quote::t
     'frozen-members?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5350_|
    (##structure
     gx#syntax-quote::t
     'frozen-members-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5351_|
    (##structure
     gx#syntax-quote::t
     'frozen-members-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5353_|
    (##structure
     gx#syntax-quote::t
     'frozen-members-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5354_|
    (##structure
     gx#syntax-quote::t
     'frozen-members-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5356_|
    (##structure
     gx#syntax-quote::t
     '&frozen-members-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5357_|
    (##structure
     gx#syntax-quote::t
     '&frozen-members-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5359_|
    (##structure
     gx#syntax-quote::t
     '&frozen-members-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g5360_|
    (##structure
     gx#syntax-quote::t
     '&frozen-members-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/table/trrel-uf[:0:]#uf-node|
      (let ((__obj5197
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj5197
           'gerbil-ascent/table/trrel-uf#uf-node::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5197 'uf-node '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj5197
           '(parent members size reach predecessors order)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj5197
           '(parent members size reach predecessors order)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5197 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5197 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5197 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5197 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5197 '#f '13 '#f '#f))
        (let ((__tmp5245 |gerbil-ascent/table/trrel-uf[1]#_g5246_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj5197 __tmp5245 '4 '#f '#f))
        (let ((__tmp5247 |gerbil-ascent/table/trrel-uf[1]#_g5248_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj5197 __tmp5247 '14 '#f '#f))
        (let ((__tmp5249 |gerbil-ascent/table/trrel-uf[1]#_g5250_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj5197 __tmp5249 '15 '#f '#f))
        (let ((__tmp5251
               (cons (cons 'parent |gerbil-ascent/table/trrel-uf[1]#_g5252_|)
                     (cons (cons 'members
                                 |gerbil-ascent/table/trrel-uf[1]#_g5253_|)
                           (cons (cons 'size
                                       |gerbil-ascent/table/trrel-uf[1]#_g5254_|)
                                 (cons (cons 'reach
                                             |gerbil-ascent/table/trrel-uf[1]#_g5255_|)
                                       (cons (cons 'predecessors
                                                   |gerbil-ascent/table/trrel-uf[1]#_g5256_|)
                                             (cons (cons 'order
                                                         |gerbil-ascent/table/trrel-uf[1]#_g5257_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj5197 __tmp5251 '16 '#f '#f))
        (let ((__tmp5258
               (cons (cons 'parent |gerbil-ascent/table/trrel-uf[1]#_g5259_|)
                     (cons (cons 'members
                                 |gerbil-ascent/table/trrel-uf[1]#_g5260_|)
                           (cons (cons 'size
                                       |gerbil-ascent/table/trrel-uf[1]#_g5261_|)
                                 (cons (cons 'reach
                                             |gerbil-ascent/table/trrel-uf[1]#_g5262_|)
                                       (cons (cons 'predecessors
                                                   |gerbil-ascent/table/trrel-uf[1]#_g5263_|)
                                             (cons (cons 'order
                                                         |gerbil-ascent/table/trrel-uf[1]#_g5264_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj5197 __tmp5258 '17 '#f '#f))
        (let ((__tmp5265
               (cons (cons 'parent |gerbil-ascent/table/trrel-uf[1]#_g5266_|)
                     (cons (cons 'members
                                 |gerbil-ascent/table/trrel-uf[1]#_g5267_|)
                           (cons (cons 'size
                                       |gerbil-ascent/table/trrel-uf[1]#_g5268_|)
                                 (cons (cons 'reach
                                             |gerbil-ascent/table/trrel-uf[1]#_g5269_|)
                                       (cons (cons 'predecessors
                                                   |gerbil-ascent/table/trrel-uf[1]#_g5270_|)
                                             (cons (cons 'order
                                                         |gerbil-ascent/table/trrel-uf[1]#_g5271_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj5197 __tmp5265 '18 '#f '#f))
        (let ((__tmp5272
               (cons (cons 'parent |gerbil-ascent/table/trrel-uf[1]#_g5273_|)
                     (cons (cons 'members
                                 |gerbil-ascent/table/trrel-uf[1]#_g5274_|)
                           (cons (cons 'size
                                       |gerbil-ascent/table/trrel-uf[1]#_g5275_|)
                                 (cons (cons 'reach
                                             |gerbil-ascent/table/trrel-uf[1]#_g5276_|)
                                       (cons (cons 'predecessors
                                                   |gerbil-ascent/table/trrel-uf[1]#_g5277_|)
                                             (cons (cons 'order
                                                         |gerbil-ascent/table/trrel-uf[1]#_g5278_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj5197 __tmp5272 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5197 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5197 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5197 '() '21 '#f '#f))
        __obj5197))
    (define |gerbil-ascent/table/trrel-uf[:0:]#uf-group|
      (let ((__obj5198
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj5198
           'gerbil-ascent/table/trrel-uf#uf-group::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5198 'uf-group '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj5198
           '(nodes roots next-order indexed?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj5198
           '(nodes roots next-order indexed?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5198 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5198 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5198 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5198 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5198 '#f '13 '#f '#f))
        (let ((__tmp5279 |gerbil-ascent/table/trrel-uf[1]#_g5280_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj5198 __tmp5279 '4 '#f '#f))
        (let ((__tmp5281 |gerbil-ascent/table/trrel-uf[1]#_g5282_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj5198 __tmp5281 '14 '#f '#f))
        (let ((__tmp5283 |gerbil-ascent/table/trrel-uf[1]#_g5284_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj5198 __tmp5283 '15 '#f '#f))
        (let ((__tmp5285
               (cons (cons 'nodes |gerbil-ascent/table/trrel-uf[1]#_g5286_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/table/trrel-uf[1]#_g5287_|)
                           (cons (cons 'next-order
                                       |gerbil-ascent/table/trrel-uf[1]#_g5288_|)
                                 (cons (cons 'indexed?
                                             |gerbil-ascent/table/trrel-uf[1]#_g5289_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj5198 __tmp5285 '16 '#f '#f))
        (let ((__tmp5290
               (cons (cons 'nodes |gerbil-ascent/table/trrel-uf[1]#_g5291_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/table/trrel-uf[1]#_g5292_|)
                           (cons (cons 'next-order
                                       |gerbil-ascent/table/trrel-uf[1]#_g5293_|)
                                 (cons (cons 'indexed?
                                             |gerbil-ascent/table/trrel-uf[1]#_g5294_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj5198 __tmp5290 '17 '#f '#f))
        (let ((__tmp5295
               (cons (cons 'nodes |gerbil-ascent/table/trrel-uf[1]#_g5296_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/table/trrel-uf[1]#_g5297_|)
                           (cons (cons 'next-order
                                       |gerbil-ascent/table/trrel-uf[1]#_g5298_|)
                                 (cons (cons 'indexed?
                                             |gerbil-ascent/table/trrel-uf[1]#_g5299_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj5198 __tmp5295 '18 '#f '#f))
        (let ((__tmp5300
               (cons (cons 'nodes |gerbil-ascent/table/trrel-uf[1]#_g5301_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/table/trrel-uf[1]#_g5302_|)
                           (cons (cons 'next-order
                                       |gerbil-ascent/table/trrel-uf[1]#_g5303_|)
                                 (cons (cons 'indexed?
                                             |gerbil-ascent/table/trrel-uf[1]#_g5304_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj5198 __tmp5300 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5198 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5198 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5198 '() '21 '#f '#f))
        __obj5198))
    (define |gerbil-ascent/table/trrel-uf[:0:]#uf-insertion|
      (let ((__obj5199
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj5199
           'gerbil-ascent/table/trrel-uf#uf-insertion::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5199 'uf-insertion '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj5199
           '(group-key group row left-node right-node a b)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj5199
           '(group-key group row left-node right-node a b)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5199 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5199 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5199 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5199 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5199 '#f '13 '#f '#f))
        (let ((__tmp5305 |gerbil-ascent/table/trrel-uf[1]#_g5306_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj5199 __tmp5305 '4 '#f '#f))
        (let ((__tmp5307 |gerbil-ascent/table/trrel-uf[1]#_g5308_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj5199 __tmp5307 '14 '#f '#f))
        (let ((__tmp5309 |gerbil-ascent/table/trrel-uf[1]#_g5310_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj5199 __tmp5309 '15 '#f '#f))
        (let ((__tmp5311
               (cons (cons 'group-key
                           |gerbil-ascent/table/trrel-uf[1]#_g5312_|)
                     (cons (cons 'group
                                 |gerbil-ascent/table/trrel-uf[1]#_g5313_|)
                           (cons (cons 'row
                                       |gerbil-ascent/table/trrel-uf[1]#_g5314_|)
                                 (cons (cons 'left-node
                                             |gerbil-ascent/table/trrel-uf[1]#_g5315_|)
                                       (cons (cons 'right-node
                                                   |gerbil-ascent/table/trrel-uf[1]#_g5316_|)
                                             (cons (cons 'a
                                                         |gerbil-ascent/table/trrel-uf[1]#_g5317_|)
                                                   (cons (cons 'b
                                                               |gerbil-ascent/table/trrel-uf[1]#_g5318_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj5199 __tmp5311 '16 '#f '#f))
        (let ((__tmp5319
               (cons (cons 'group-key
                           |gerbil-ascent/table/trrel-uf[1]#_g5320_|)
                     (cons (cons 'group
                                 |gerbil-ascent/table/trrel-uf[1]#_g5321_|)
                           (cons (cons 'row
                                       |gerbil-ascent/table/trrel-uf[1]#_g5322_|)
                                 (cons (cons 'left-node
                                             |gerbil-ascent/table/trrel-uf[1]#_g5323_|)
                                       (cons (cons 'right-node
                                                   |gerbil-ascent/table/trrel-uf[1]#_g5324_|)
                                             (cons (cons 'a
                                                         |gerbil-ascent/table/trrel-uf[1]#_g5325_|)
                                                   (cons (cons 'b
                                                               |gerbil-ascent/table/trrel-uf[1]#_g5326_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj5199 __tmp5319 '17 '#f '#f))
        (let ((__tmp5327
               (cons (cons 'group-key
                           |gerbil-ascent/table/trrel-uf[1]#_g5328_|)
                     (cons (cons 'group
                                 |gerbil-ascent/table/trrel-uf[1]#_g5329_|)
                           (cons (cons 'row
                                       |gerbil-ascent/table/trrel-uf[1]#_g5330_|)
                                 (cons (cons 'left-node
                                             |gerbil-ascent/table/trrel-uf[1]#_g5331_|)
                                       (cons (cons 'right-node
                                                   |gerbil-ascent/table/trrel-uf[1]#_g5332_|)
                                             (cons (cons 'a
                                                         |gerbil-ascent/table/trrel-uf[1]#_g5333_|)
                                                   (cons (cons 'b
                                                               |gerbil-ascent/table/trrel-uf[1]#_g5334_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj5199 __tmp5327 '18 '#f '#f))
        (let ((__tmp5335
               (cons (cons 'group-key
                           |gerbil-ascent/table/trrel-uf[1]#_g5336_|)
                     (cons (cons 'group
                                 |gerbil-ascent/table/trrel-uf[1]#_g5337_|)
                           (cons (cons 'row
                                       |gerbil-ascent/table/trrel-uf[1]#_g5338_|)
                                 (cons (cons 'left-node
                                             |gerbil-ascent/table/trrel-uf[1]#_g5339_|)
                                       (cons (cons 'right-node
                                                   |gerbil-ascent/table/trrel-uf[1]#_g5340_|)
                                             (cons (cons 'a
                                                         |gerbil-ascent/table/trrel-uf[1]#_g5341_|)
                                                   (cons (cons 'b
                                                               |gerbil-ascent/table/trrel-uf[1]#_g5342_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj5199 __tmp5335 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5199 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5199 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5199 '() '21 '#f '#f))
        __obj5199))
    (define |gerbil-ascent/table/trrel-uf[:0:]#frozen-members|
      (let ((__obj5200
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj5200
           'gerbil-ascent/table/trrel-uf#frozen-members::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5200 'frozen-members '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5200 '(rows count) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5200 '(rows count) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5200 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5200 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5200 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5200 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5200 '#f '13 '#f '#f))
        (let ((__tmp5343 |gerbil-ascent/table/trrel-uf[1]#_g5344_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj5200 __tmp5343 '4 '#f '#f))
        (let ((__tmp5345 |gerbil-ascent/table/trrel-uf[1]#_g5346_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj5200 __tmp5345 '14 '#f '#f))
        (let ((__tmp5347 |gerbil-ascent/table/trrel-uf[1]#_g5348_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj5200 __tmp5347 '15 '#f '#f))
        (let ((__tmp5349
               (cons (cons 'rows |gerbil-ascent/table/trrel-uf[1]#_g5350_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/trrel-uf[1]#_g5351_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj5200 __tmp5349 '16 '#f '#f))
        (let ((__tmp5352
               (cons (cons 'rows |gerbil-ascent/table/trrel-uf[1]#_g5353_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/trrel-uf[1]#_g5354_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj5200 __tmp5352 '17 '#f '#f))
        (let ((__tmp5355
               (cons (cons 'rows |gerbil-ascent/table/trrel-uf[1]#_g5356_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/trrel-uf[1]#_g5357_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj5200 __tmp5355 '18 '#f '#f))
        (let ((__tmp5358
               (cons (cons 'rows |gerbil-ascent/table/trrel-uf[1]#_g5359_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/trrel-uf[1]#_g5360_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj5200 __tmp5358 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5200 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5200 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj5200 '() '21 '#f '#f))
        __obj5200))))
