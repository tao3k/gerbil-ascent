(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/stratified-proof::timestamp 1791689711)
  (begin
    (define gerbil-ascent/candidate/stratified-proof#+max-proof-nodes+ '4096)
    (define gerbil-ascent/candidate/stratified-proof#+max-proof-datum-nodes+
      '65536)
    (define gerbil-ascent/candidate/stratified-proof#ground-row?
      (lambda (_%row28795%_ _%arity28796%_)
        (if (list? _%row28795%_)
            (if (= (let () (declare (not safe)) (##length _%row28795%_))
                   _%arity28796%_)
                (let ((__tmp37891
                       (lambda (_%term28798%_)
                         (if (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program#scalar?
                                _%term28798%_))
                             (if (let ()
                                   (declare (not safe))
                                   (gerbil-ascent/candidate/program#candidate-variable?
                                    _%term28798%_))
                                 '#f
                                 (not (eq? _%term28798%_ '?_)))
                             '#f))))
                  (declare (not safe))
                  (andmap__0 __tmp37891 _%row28795%_))
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/stratified-proof#same-distinct-rows?
      (lambda (_%supplied28785%_ _%actual28786%_ _%step!28787%_)
        (if (= (length _%supplied28785%_) (length _%actual28786%_))
            (let ((_%index28789%_
                   (let ()
                     (declare (not safe))
                     (make-hash-table__%
                      '#f
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value))))
              (if (let ((__tmp37892
                         (lambda (_%row28791%_)
                           (and (_%step!28787%_)
                                (begin
                                  (let ()
                                    (declare (not safe))
                                    (__hash-put!
                                     _%index28789%_
                                     _%row28791%_
                                     '#t))
                                  '#t)))))
                    (declare (not safe))
                    (andmap__0 __tmp37892 _%actual28786%_))
                  (let ((__tmp37893
                         (lambda (_%row28793%_)
                           (if (_%step!28787%_)
                               (if (let ()
                                     (declare (not safe))
                                     (__hash-get _%index28789%_ _%row28793%_))
                                   (begin
                                     (let ()
                                       (declare (not safe))
                                       (__hash-put!
                                        _%index28789%_
                                        _%row28793%_
                                        '#f))
                                     '#t)
                                   '#f)
                               '#f))))
                    (declare (not safe))
                    (andmap__0 __tmp37893 _%supplied28785%_))
                  '#f))
            '#f)))
    (define gerbil-ascent/candidate/stratified-proof#candidate-verify-stratified-proof
      (lambda (_%snapshot28617%_
               _%spec28618%_
               _%candidate-digest28619%_
               _%native-status28620%_
               _%native-rows28621%_
               _%finite-certificate28622%_
               _%finite-work-budget28623%_
               _%proof28624%_
               _%proof-work-budget28625%_)
        (if (and (exact-integer? _%proof-work-budget28625%_)
                 (> _%proof-work-budget28625%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"stratified proof needs positive work budget"
                     _%proof-work-budget28625%_)))
        (if (and (let ()
                   (declare (not safe))
                   (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                    _%proof28624%_
                    gerbil-ascent/candidate/stratified-proof#+max-proof-datum-nodes+
                    '128))
                 (list? _%proof28624%_)
                 (= (let () (declare (not safe)) (##length _%proof28624%_)) '3)
                 (eq? (car _%proof28624%_) 'stratified-proof-v1)
                 (list? (cadr _%proof28624%_))
                 (<= (length (cadr _%proof28624%_))
                     gerbil-ascent/candidate/stratified-proof#+max-proof-nodes+)
                 (list? (caddr _%proof28624%_))
                 (<= (length (caddr _%proof28624%_))
                     gerbil-ascent/candidate/stratified-proof#+max-proof-nodes+))
            (let ((_g37894_
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/finite-evidence#candidate-verified-finite-closure
                      _%snapshot28617%_
                      _%spec28618%_
                      _%candidate-digest28619%_
                      _%native-status28620%_
                      _%native-rows28621%_
                      _%finite-certificate28622%_
                      _%finite-work-budget28623%_))))
              (begin
                (let ((_g37895_
                       (let ()
                         (declare (not safe))
                         (if (##values? _g37894_)
                             (##values-length _g37894_)
                             1))))
                  (if (not (let () (declare (not safe)) (##fx= _g37895_ 2)))
                      (error "Context expects 2 values" _g37895_)))
                (let ((_%finite-verdict28627%_
                       (let () (declare (not safe)) (##values-ref _g37894_ 0)))
                      (_%closure28628%_
                       (let ()
                         (declare (not safe))
                         (##values-ref _g37894_ 1))))
                  (if (eq? _%finite-verdict28627%_ 'valid)
                      (if (null? _%native-rows28621%_)
                          'unsupported
                          (let* ((_%schema28630%_
                                  (let ()
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/funs#candidate-schema-of
                                     _%snapshot28617%_
                                     _%spec28618%_)))
                                 (_%rules28632%_
                                  (##structure-ref
                                   _%spec28618%_
                                   '3
                                   gerbil-ascent/candidate/types#reasoning-candidate::t
                                   '#f))
                                 (_%levels28634%_
                                  (let ()
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/funs#candidate-strata-of
                                     _%schema28630%_
                                     _%rules28632%_)))
                                 (_%model28636%_
                                  (let ((__tmp37896
                                         (##structure-ref
                                          _%snapshot28617%_
                                          '4
                                          gerbil-ascent/candidate/types#reasoning-snapshot::t
                                          '#f)))
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/closure-index#make-closure-index__%
                                     _%closure28628%_
                                     __tmp37896)))
                                 (_%nodes28638%_ (cadr _%proof28624%_))
                                 (_%roots28640%_ (caddr _%proof28624%_))
                                 (_%by-id28642%_ (list->vector _%nodes28638%_))
                                 (_%query28644%_
                                  (vector-ref
                                   (##structure-ref
                                    _%spec28618%_
                                    '4
                                    gerbil-ascent/candidate/types#reasoning-candidate::t
                                    '#f)
                                   '0))
                                 (_%steps28646%_ '0)
                                 (_%bounded?28648%_ '#f))
                            (letrec ((_%step!28651%_
                                      (lambda ()
                                        (set! _%steps28646%_
                                              (+ _%steps28646%_ '1))
                                        (if (> _%steps28646%_
                                               _%proof-work-budget28625%_)
                                            (set! _%bounded?28648%_ '#t)
                                            '#!void)
                                        (not _%bounded?28648%_)))
                                     (_%rows28652%_
                                      (lambda (_%name28782%_)
                                        (let ()
                                          (declare (not safe))
                                          (gerbil-ascent/candidate/closure-index#closure-index-rows
                                           _%model28636%_
                                           _%name28782%_))))
                                     (_%node-ref28653%_
                                      (lambda (_%id28776%_
                                               _%before28777%_
                                               _%relation28778%_)
                                        (if (exact-integer? _%id28776%_)
                                            (if (<= '0 _%id28776%_)
                                                (if (< _%id28776%_
                                                       _%before28777%_)
                                                    (let ((_%node28780%_
                                                           (vector-ref
                                                            _%by-id28642%_
                                                            _%id28776%_)))
                                                      (if (eq? (cadr _%node28780%_)
                                                               _%relation28778%_)
                                                          _%node28780%_
                                                          '#f))
                                                    '#f)
                                                '#f)
                                            '#f)))
                                     (_%strict-lower?28654%_
                                      (lambda (_%head28773%_
                                               _%dependency28774%_)
                                        (> (cdr (let ()
                                                  (declare (not safe))
                                                  (gerbil-ascent/candidate/funs#candidate-required-entry
                                                   _%head28773%_
                                                   _%levels28634%_)))
                                           (cdr (let ()
                                                  (declare (not safe))
                                                  (gerbil-ascent/candidate/funs#candidate-required-entry
                                                   _%dependency28774%_
                                                   _%levels28634%_))))))
                                     (_%no-match?28655%_
                                      (lambda (_%atom28768%_ _%bindings28769%_)
                                        (let ((__tmp37898
                                               (lambda (_%row28771%_)
                                                 (if (_%step!28651%_)
                                                     (not (let ()
                                                            (declare
                                                              (not safe))
                                                            (gerbil-ascent/candidate/funs#candidate-bind-atom
                                                             _%atom28768%_
                                                             _%row28771%_
                                                             _%bindings28769%_)))
                                                     '#f)))
                                              (__tmp37897
                                               (_%rows28652%_
                                                (car _%atom28768%_))))
                                          (declare (not safe))
                                          (andmap__0 __tmp37898 __tmp37897))))
                                     (_%reduction-bindings28656%_
                                      (lambda (_%clause28738%_
                                               _%witness28739%_
                                               _%bindings28740%_
                                               _%before28741%_
                                               _%head28742%_)
                                        (let ((_%atom28744%_
                                               (cadddr _%clause28738%_))
                                              (_%operator28745%_
                                               (caddr _%clause28738%_)))
                                          (if (list? _%witness28739%_)
                                              (if (= (let ()
                                                       (declare (not safe))
                                                       (##length
                                                        _%witness28739%_))
                                                     '2)
                                                  (if (eq? (car _%witness28739%_)
                                                           'reduce)
                                                      (if (list? (cadr _%witness28739%_))
                                                          (if (_%strict-lower?28654%_
                                                               _%head28742%_
                                                               (car _%atom28744%_))
                                                              (let ((_%matched28749%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (filter (lambda (_%row28747%_)
                                       (if (_%step!28651%_)
                                           (let ()
                                             (declare (not safe))
                                             (gerbil-ascent/candidate/funs#candidate-bind-atom
                                              _%atom28744%_
                                              _%row28747%_
                                              _%bindings28740%_))
                                           '#f))
                                     (_%rows28652%_ (car _%atom28744%_))))
                            (_%supplied28750%_ '()))
                        (if _%bounded?28648%_
                            '#f
                            (if (let ((__tmp37900
                                       (lambda (_%id28752%_)
                                         (let ((_%node28754%_
                                                (_%node-ref28653%_
                                                 _%id28752%_
                                                 _%before28741%_
                                                 (car _%atom28744%_))))
                                           (and (_%step!28651%_)
                                                _%node28754%_
                                                (let ((__tmp37901
                                                       (caddr _%node28754%_)))
                                                  (declare (not safe))
                                                  (gerbil-ascent/candidate/funs#candidate-bind-atom
                                                   _%atom28744%_
                                                   __tmp37901
                                                   _%bindings28740%_))
                                                (begin
                                                  (set! _%supplied28750%_
                                                        (cons (caddr _%node28754%_)
                                                              _%supplied28750%_))
                                                  '#t)))))
                                      (__tmp37899 (cadr _%witness28739%_)))
                                  (declare (not safe))
                                  (andmap__0 __tmp37900 __tmp37899))
                                (if (gerbil-ascent/candidate/stratified-proof#same-distinct-rows?
                                     _%supplied28750%_
                                     _%matched28749%_
                                     _%step!28651%_)
                                    (let* ((_%values28760%_
                                            (if (eq? (car _%operator28745%_)
                                                     'count)
                                                '()
                                                (let ((__tmp37902
                                                       (lambda (_%row28756%_)
                                                         (let ((_%next28758%_
                                                                (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gerbil-ascent/candidate/funs#candidate-bind-atom
                           _%atom28744%_
                           _%row28756%_
                           _%bindings28740%_))))
                   (if _%next28758%_
                       (cdr (let ((__tmp37903 (cadr _%operator28745%_)))
                              (declare (not safe))
                              (gerbil-ascent/candidate/funs#candidate-required-entry
                               __tmp37903
                               _%next28758%_)))
                       '#f)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (declare (not safe))
                                                  (##map __tmp37902
                                                         _%supplied28750%_))))
                                           (_%value28765%_
                                            (let ((_%$e28762%_
                                                   (car _%operator28745%_)))
                                              (if (eq? 'count _%$e28762%_)
                                                  (let ()
                                                    (declare (not safe))
                                                    (##length
                                                     _%supplied28750%_))
                                                  (if (eq? 'sum _%$e28762%_)
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (andmap__0
                                                             exact-integer?
                                                             _%values28760%_))
                                                          (apply +
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '0
                         _%values28760%_)
                  '#f)
              (if (eq? 'min _%$e28762%_)
                  (if (pair? _%values28760%_)
                      (if (let ()
                            (declare (not safe))
                            (andmap__0 exact-integer? _%values28760%_))
                          (let ()
                            (declare (not safe))
                            (##apply min _%values28760%_))
                          '#f)
                      '#f)
                  (if (eq? 'max _%$e28762%_)
                      (if (pair? _%values28760%_)
                          (if (let ()
                                (declare (not safe))
                                (andmap__0 exact-integer? _%values28760%_))
                              (let ()
                                (declare (not safe))
                                (##apply max _%values28760%_))
                              '#f)
                          '#f)
                      '#f)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                      (if _%value28765%_
                                          (cons (cons (cadr _%clause28738%_)
                                                      _%value28765%_)
                                                _%bindings28740%_)
                                          '#f))
                                    '#f)
                                '#f)))
                      '#f)
                  '#f)
              '#f)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  '#f)
                                              '#f))))
                                     (_%rule-node-valid?28657%_
                                      (lambda (_%node28694%_ _%index28695%_)
                                        (let* ((_%rule28699%_
                                                (let ((__tmp37904
                                                       (lambda (_%candidate28697%_)
                                                         (equal? (cadddr _%node28694%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (vector-ref _%candidate28697%_ '2)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (declare (not safe))
                                                  (__find __tmp37904
                                                          _%rules28632%_)))
                                               (_%head28701%_
                                                (if _%rule28699%_
                                                    (vector-ref
                                                     _%rule28699%_
                                                     '0)
                                                    '#f))
                                               (_%body28703%_
                                                (if _%rule28699%_
                                                    (vector-ref
                                                     _%rule28699%_
                                                     '1)
                                                    '#f))
                                               (_%witnesses28705%_
                                                (list-ref _%node28694%_ '4)))
                                          (if _%rule28699%_
                                              (if (eq? (cadr _%node28694%_)
                                                       (car _%head28701%_))
                                                  (if (list? _%witnesses28705%_)
                                                      (if (= (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##length _%witnesses28705%_))
                     (length _%body28703%_))
                  (let _%loop28708%_ ((_%clauses28710%_ _%body28703%_)
                                      (_%evidence28711%_ _%witnesses28705%_)
                                      (_%bindings28712%_ '()))
                    (if (null? _%clauses28710%_)
                        (if (null? _%evidence28711%_)
                            (if (let ((__tmp37906
                                       (lambda (_%term28714%_)
                                         (or (not (let ()
                                                    (declare (not safe))
                                                    (gerbil-ascent/candidate/program#candidate-variable?
                                                     _%term28714%_)))
                                             (assq _%term28714%_
                                                   _%bindings28712%_))))
                                      (__tmp37905 (cdr _%head28701%_)))
                                  (declare (not safe))
                                  (andmap__0 __tmp37906 __tmp37905))
                                (equal? (caddr _%node28694%_)
                                        (map (lambda (_%term28719%_)
                                               (if (let ()
                                                     (declare (not safe))
                                                     (gerbil-ascent/candidate/program#candidate-variable?
                                                      _%term28719%_))
                                                   (cdr (let ()
                                                          (declare (not safe))
                                                          (gerbil-ascent/candidate/funs#candidate-required-entry
                                                           _%term28719%_
                                                           _%bindings28712%_)))
                                                   _%term28719%_))
                                             (cdr _%head28701%_)))
                                '#f)
                            '#f)
                        (let ((_%clause28721%_ (car _%clauses28710%_))
                              (_%witness28722%_ (car _%evidence28711%_)))
                          (let ((_%$e28724%_ (car _%clause28721%_)))
                            (if (or (eq? 'where _%$e28724%_)
                                    (eq? 'compute _%$e28724%_))
                                (if (equal? _%witness28722%_ '(fixed))
                                    (if (_%step!28651%_)
                                        (let ((_%next28730%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gerbil-ascent/candidate/funs#candidate-fixed-clause
                                                  _%clause28721%_
                                                  _%bindings28712%_))))
                                          (if _%next28730%_
                                              (_%loop28708%_
                                               (cdr _%clauses28710%_)
                                               (cdr _%evidence28711%_)
                                               _%next28730%_)
                                              '#f))
                                        '#f)
                                    '#f)
                                (if (eq? 'not _%$e28724%_)
                                    (if (equal? _%witness28722%_ '(not))
                                        (if (_%strict-lower?28654%_
                                             (car _%head28701%_)
                                             (caadr _%clause28721%_))
                                            (if (_%no-match?28655%_
                                                 (cadr _%clause28721%_)
                                                 _%bindings28712%_)
                                                (_%loop28708%_
                                                 (cdr _%clauses28710%_)
                                                 (cdr _%evidence28711%_)
                                                 _%bindings28712%_)
                                                '#f)
                                            '#f)
                                        '#f)
                                    (if (eq? 'reduce _%$e28724%_)
                                        (let ((_%next28732%_
                                               (_%reduction-bindings28656%_
                                                _%clause28721%_
                                                _%witness28722%_
                                                _%bindings28712%_
                                                _%index28695%_
                                                (car _%head28701%_))))
                                          (if _%next28732%_
                                              (_%loop28708%_
                                               (cdr _%clauses28710%_)
                                               (cdr _%evidence28711%_)
                                               _%next28732%_)
                                              '#f))
                                        (if (list? _%witness28722%_)
                                            (if (= (let ()
                                                     (declare (not safe))
                                                     (##length
                                                      _%witness28722%_))
                                                   '2)
                                                (if (eq? (car _%witness28722%_)
                                                         'atom)
                                                    (let ((_%input28734%_
                                                           (_%node-ref28653%_
                                                            (cadr _%witness28722%_)
                                                            _%index28695%_
                                                            (car _%clause28721%_))))
                                                      (if (_%step!28651%_)
                                                          (if _%input28734%_
                                                              (let ((_%next28736%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (let ((__tmp37907 (caddr _%input28734%_)))
                               (declare (not safe))
                               (gerbil-ascent/candidate/funs#candidate-bind-atom
                                _%clause28721%_
                                __tmp37907
                                _%bindings28712%_))))
                        (if _%next28736%_
                            (_%loop28708%_
                             (cdr _%clauses28710%_)
                             (cdr _%evidence28711%_)
                             _%next28736%_)
                            '#f))
                      '#f)
                  '#f))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '#f)
                                                '#f)
                                            '#f))))))))
                  '#f)
              '#f)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  '#f)
                                              '#f))))
                                     (_%node-valid?28658%_
                                      (lambda (_%node28682%_ _%index28683%_)
                                        (if (_%step!28651%_)
                                            (if (list? _%node28682%_)
                                                (if (= (let ()
                                                         (declare (not safe))
                                                         (##length
                                                          _%node28682%_))
                                                       '5)
                                                    (if (let ((__tmp37908
                                                               (car _%node28682%_)))
                                                          (declare (not safe))
                                                          (##memq __tmp37908
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          '(source candidate rule)))
                (if (symbol? (cadr _%node28682%_))
                    (if (let ((_%declaration28685%_
                               (assq (cadr _%node28682%_) _%schema28630%_)))
                          (and _%declaration28685%_
                               (gerbil-ascent/candidate/stratified-proof#ground-row?
                                (caddr _%node28682%_)
                                (cdr _%declaration28685%_))
                               (let ((__tmp37910 (cadr _%node28682%_))
                                     (__tmp37909 (caddr _%node28682%_)))
                                 (declare (not safe))
                                 (gerbil-ascent/candidate/closure-index#closure-index-member?
                                  _%model28636%_
                                  __tmp37910
                                  __tmp37909))))
                        (if (list? (list-ref _%node28682%_ '4))
                            (let ((_%$e28687%_ (car _%node28682%_)))
                              (if (eq? 'source _%$e28687%_)
                                  (if (null? (list-ref _%node28682%_ '4))
                                      (let ((_%source28690%_
                                             (let ((__tmp37911
                                                    (cadr _%node28682%_)))
                                               (declare (not safe))
                                               (gerbil-ascent/candidate/closure-index#closure-index-source
                                                _%model28636%_
                                                __tmp37911))))
                                        (if _%source28690%_
                                            (if (exact-integer?
                                                 (cadddr _%node28682%_))
                                                (if (<= '1
                                                        (cadddr _%node28682%_))
                                                    (if (<= (cadddr _%node28682%_)
                                                            (vector-length
                                                             _%source28690%_))
                                                        (equal? (caddr _%node28682%_)
                                                                (vector-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%source28690%_
                         (- (cadddr _%node28682%_) '1)))
                '#f)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '#f)
                                                '#f)
                                            '#f))
                                      '#f)
                                  (if (eq? 'candidate _%$e28687%_)
                                      (if (null? (list-ref _%node28682%_ '4))
                                          (let ((__tmp37913
                                                 (lambda (_%fact28692%_)
                                                   (if (equal? (cadddr _%node28682%_)
                                                               (vector-ref
                                                                _%fact28692%_
                                                                '2))
                                                       (if (eq? (cadr _%node28682%_)
                                                                (vector-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%fact28692%_
                         '0))
                   (equal? (caddr _%node28682%_) (vector-ref _%fact28692%_ '1))
                   '#f)
               '#f)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (__tmp37912
                                                 (##structure-ref
                                                  _%spec28618%_
                                                  '2
                                                  gerbil-ascent/candidate/types#reasoning-candidate::t
                                                  '#f)))
                                            (declare (not safe))
                                            (__find __tmp37913 __tmp37912))
                                          '#f)
                                      (if (eq? 'rule _%$e28687%_)
                                          (_%rule-node-valid?28657%_
                                           _%node28682%_
                                           _%index28683%_)
                                          '#f))))
                            '#f)
                        '#f)
                    '#f)
                '#f)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '#f)
                                                '#f)
                                            '#f))))
                              (if _%levels28634%_
                                  (let ((_%valid-nodes?28668%_
                                         (let _%loop28660%_ ((_%remaining28662%_
                                                              _%nodes28638%_)
                                                             (_%index28663%_
                                                              '0))
                                           (let ((_%$e28665%_
                                                  (null? _%remaining28662%_)))
                                             (if _%$e28665%_
                                                 _%$e28665%_
                                                 (if (_%node-valid?28658%_
                                                      (car _%remaining28662%_)
                                                      _%index28663%_)
                                                     (_%loop28660%_
                                                      (cdr _%remaining28662%_)
                                                      (+ _%index28663%_ '1))
                                                     '#f))))))
                                    (if _%bounded?28648%_
                                        'bounded
                                        (if _%valid-nodes?28668%_
                                            (if (and (pair? _%roots28640%_)
                                                     (let ((__tmp37914
                                                            (lambda (_%id28672%_)
                                                              (let ((_%node28674%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (_%node-ref28653%_
                              _%id28672%_
                              (length _%nodes28638%_)
                              (car _%query28644%_))))
                        (and (_%step!28651%_)
                             _%node28674%_
                             (let ((__tmp37915 (caddr _%node28674%_)))
                               (declare (not safe))
                               (gerbil-ascent/candidate/funs#candidate-bind-atom
                                _%query28644%_
                                __tmp37915
                                '())))))))
               (declare (not safe))
               (andmap__0 __tmp37914 _%roots28640%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (if (gerbil-ascent/candidate/stratified-proof#same-distinct-rows?
                                                     (map (lambda (_%id28677%_)
                                                            (caddr (vector-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%by-id28642%_
                            _%id28677%_)))
                  _%roots28640%_)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     _%native-rows28621%_
                                                     _%step!28651%_)
                                                    (if _%bounded?28648%_
                                                        'bounded
                                                        'valid)
                                                    (if _%bounded?28648%_
                                                        'bounded
                                                        'invalid))
                                                (if _%bounded?28648%_
                                                    'bounded
                                                    'invalid))
                                            'invalid)))
                                  'invalid))))
                      _%finite-verdict28627%_))))
            'invalid)))))
