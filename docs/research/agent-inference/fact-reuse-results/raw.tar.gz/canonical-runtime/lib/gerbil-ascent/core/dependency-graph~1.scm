(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/core/dependency-graph[1]#_g33959_|
    (##structure
     gx#syntax-quote::t
     'graph-frame::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33961_|
    (##structure
     gx#syntax-quote::t
     'make-graph-frame
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33963_|
    (##structure
     gx#syntax-quote::t
     'graph-frame?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33965_|
    (##structure
     gx#syntax-quote::t
     'graph-frame-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33966_|
    (##structure
     gx#syntax-quote::t
     'graph-frame-remaining
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33967_|
    (##structure
     gx#syntax-quote::t
     'graph-frame-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33969_|
    (##structure
     gx#syntax-quote::t
     'graph-frame-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33970_|
    (##structure
     gx#syntax-quote::t
     'graph-frame-remaining-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33971_|
    (##structure
     gx#syntax-quote::t
     'graph-frame-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33973_|
    (##structure
     gx#syntax-quote::t
     '&graph-frame-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33974_|
    (##structure
     gx#syntax-quote::t
     '&graph-frame-remaining
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33975_|
    (##structure
     gx#syntax-quote::t
     '&graph-frame-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33977_|
    (##structure
     gx#syntax-quote::t
     '&graph-frame-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33978_|
    (##structure
     gx#syntax-quote::t
     '&graph-frame-remaining-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[1]#_g33979_|
    (##structure
     gx#syntax-quote::t
     '&graph-frame-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/dependency-graph[:0:]#graph-frame|
    (let ((__obj33798
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj33798
         'gerbil-ascent/core/dependency-graph#graph-frame::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33798 'graph-frame '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj33798
         '(node remaining parent)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj33798
         '(node remaining parent)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33798 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33798 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33798 '#t '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33798 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33798 '#f '13 '#f '#f))
      (let ((__tmp33958 |gerbil-ascent/core/dependency-graph[1]#_g33959_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj33798 __tmp33958 '4 '#f '#f))
      (let ((__tmp33960 |gerbil-ascent/core/dependency-graph[1]#_g33961_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj33798 __tmp33960 '14 '#f '#f))
      (let ((__tmp33962 |gerbil-ascent/core/dependency-graph[1]#_g33963_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj33798 __tmp33962 '15 '#f '#f))
      (let ((__tmp33964
             (cons (cons 'node
                         |gerbil-ascent/core/dependency-graph[1]#_g33965_|)
                   (cons (cons 'remaining
                               |gerbil-ascent/core/dependency-graph[1]#_g33966_|)
                         (cons (cons 'parent
                                     |gerbil-ascent/core/dependency-graph[1]#_g33967_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33798 __tmp33964 '16 '#f '#f))
      (let ((__tmp33968
             (cons (cons 'node
                         |gerbil-ascent/core/dependency-graph[1]#_g33969_|)
                   (cons (cons 'remaining
                               |gerbil-ascent/core/dependency-graph[1]#_g33970_|)
                         (cons (cons 'parent
                                     |gerbil-ascent/core/dependency-graph[1]#_g33971_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33798 __tmp33968 '17 '#f '#f))
      (let ((__tmp33972
             (cons (cons 'node
                         |gerbil-ascent/core/dependency-graph[1]#_g33973_|)
                   (cons (cons 'remaining
                               |gerbil-ascent/core/dependency-graph[1]#_g33974_|)
                         (cons (cons 'parent
                                     |gerbil-ascent/core/dependency-graph[1]#_g33975_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33798 __tmp33972 '18 '#f '#f))
      (let ((__tmp33976
             (cons (cons 'node
                         |gerbil-ascent/core/dependency-graph[1]#_g33977_|)
                   (cons (cons 'remaining
                               |gerbil-ascent/core/dependency-graph[1]#_g33978_|)
                         (cons (cons 'parent
                                     |gerbil-ascent/core/dependency-graph[1]#_g33979_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33798 __tmp33976 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33798 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33798 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33798 '() '21 '#f '#f))
      __obj33798)))
