(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/component-plan::timestamp 1791689691)
  (begin
    (define gerbil-ascent/program/component-plan#positive-component::t
      (let ((__tmp35471 (list)) (__tmp35470 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/component-plan#positive-component::t
         'positive-component
         __tmp35471
         '(id members rules predecessors)
         __tmp35470
         '#f)))
    (define gerbil-ascent/program/component-plan#positive-component?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/component-plan#positive-component::t)))
    (define gerbil-ascent/program/component-plan#make-positive-component
      (lambda _%$args17956%_
        (apply make-instance
               gerbil-ascent/program/component-plan#positive-component::t
               _%$args17956%_)))
    (define gerbil-ascent/program/component-plan#positive-component-id
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/component-plan#positive-component::t
         'id)))
    (define gerbil-ascent/program/component-plan#positive-component-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/component-plan#positive-component::t
         'members)))
    (define gerbil-ascent/program/component-plan#positive-component-rules
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/component-plan#positive-component::t
         'rules)))
    (define gerbil-ascent/program/component-plan#positive-component-predecessors
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/component-plan#positive-component::t
         'predecessors)))
    (define gerbil-ascent/program/component-plan#positive-component-id-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/component-plan#positive-component::t
         'id)))
    (define gerbil-ascent/program/component-plan#positive-component-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/component-plan#positive-component::t
         'members)))
    (define gerbil-ascent/program/component-plan#positive-component-rules-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/component-plan#positive-component::t
         'rules)))
    (define gerbil-ascent/program/component-plan#positive-component-predecessors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/component-plan#positive-component::t
         'predecessors)))
    (define gerbil-ascent/program/component-plan#&positive-component-id
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/component-plan#positive-component::t
         'id)))
    (define gerbil-ascent/program/component-plan#&positive-component-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/component-plan#positive-component::t
         'members)))
    (define gerbil-ascent/program/component-plan#&positive-component-rules
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/component-plan#positive-component::t
         'rules)))
    (define gerbil-ascent/program/component-plan#&positive-component-predecessors
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/component-plan#positive-component::t
         'predecessors)))
    (define gerbil-ascent/program/component-plan#&positive-component-id-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/component-plan#positive-component::t
         'id)))
    (define gerbil-ascent/program/component-plan#&positive-component-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/component-plan#positive-component::t
         'members)))
    (define gerbil-ascent/program/component-plan#&positive-component-rules-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/component-plan#positive-component::t
         'rules)))
    (define gerbil-ascent/program/component-plan#&positive-component-predecessors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/component-plan#positive-component::t
         'predecessors)))
    (define gerbil-ascent/program/component-plan#publish-component-rule!
      (lambda (_%component17952%_ _%plan17953%_ _%pivots17954%_)
        (##structure-set!
         _%component17952%_
         (cons (vector _%plan17953%_ _%pivots17954%_)
               (##structure-ref
                _%component17952%_
                '3
                gerbil-ascent/program/component-plan#positive-component::t
                '#f))
         '3
         gerbil-ascent/program/component-plan#positive-component::t
         '#f)))
    (define gerbil-ascent/program/component-plan#project-component-rule!
      (lambda (_%rule17889%_ _%membership17890%_)
        (let ((_%full17892%_ (vector-ref _%rule17889%_ '5))
              (_%pivots17893%_ (vector-ref _%rule17889%_ '2)))
          (if (let ()
                (declare (not safe))
                (gerbil-ascent/core/positive-plan#gerbil-ascent-pure-positive-plan?
                 _%full17892%_))
              '#!void
              (let ()
                (declare (not safe))
                (error '"unsupported ASCENT positive SCC rule")))
          (letrec ((_%owner17895%_
                    (lambda (_%output17950%_)
                      (vector-ref
                       _%membership17890%_
                       (vector-ref (vector-ref _%output17950%_ '0) '0)))))
            (let* ((_%$%g1789617905%_ (vector-ref _%full17892%_ '0))
                   (_%$%E1789917909%_
                    (lambda ()
                      (let ()
                        (declare (not safe))
                        (error '"No clause matching"
                               _%$%g1789617905%_
                               '([])
                               '([first . rest])))
                      '#!void)))
              (let ((_%$%K1790317947%_ (lambda () '#!void))
                    (_%$%K1790017931%_
                     (lambda (_%rest17913%_ _%first17914%_)
                       (let ((_%component17916%_
                              (_%owner17895%_ _%first17914%_)))
                         (if (let ((__tmp35472
                                    (lambda (_%output17918%_)
                                      (eq? _%component17916%_
                                           (_%owner17895%_ _%output17918%_)))))
                               (declare (not safe))
                               (andmap__0 __tmp35472 _%rest17913%_))
                             (gerbil-ascent/program/component-plan#publish-component-rule!
                              _%component17916%_
                              _%full17892%_
                              _%pivots17893%_)
                             (let ((_%grouped17920%_
                                    (let ()
                                      (declare (not safe))
                                      (make-hash-table-eq))))
                               (for-each
                                (lambda (_%output17922%_)
                                  (let ((__tmp35474
                                         (_%owner17895%_ _%output17922%_))
                                        (__tmp35473
                                         (lambda (_%$%g1792317925%_)
                                           (cons _%output17922%_
                                                 _%$%g1792317925%_))))
                                    (declare (not safe))
                                    (__hash-update!__%
                                     _%grouped17920%_
                                     __tmp35474
                                     __tmp35473
                                     '())))
                                (vector-ref _%full17892%_ '0))
                               (let ((__tmp35475
                                      (lambda (_%component17928%_
                                               _%outputs17929%_)
                                        (gerbil-ascent/program/component-plan#publish-component-rule!
                                         _%component17928%_
                                         (let ((__tmp35476
                                                (reverse! _%outputs17929%_)))
                                           (declare (not safe))
                                           (gerbil-ascent/core/positive-plan#gerbil-ascent-positive-plan-with-outputs
                                            _%full17892%_
                                            __tmp35476))
                                         _%pivots17893%_))))
                                 (declare (not safe))
                                 (__hash-for-each
                                  __tmp35475
                                  _%grouped17920%_))))))))
                (let ((_%$%try-match1789817943%_
                       (lambda ()
                         (if (pair? _%$%g1789617905%_)
                             (let ((_%$%tl1790217936%_
                                    (let ()
                                      (declare (not safe))
                                      (##cdr _%$%g1789617905%_)))
                                   (_%$%hd1790117934%_
                                    (let ()
                                      (declare (not safe))
                                      (##car _%$%g1789617905%_))))
                               (let ((_%first17939%_ _%$%hd1790117934%_)
                                     (_%rest17941%_ _%$%tl1790217936%_))
                                 (_%$%K1790017931%_
                                  _%rest17941%_
                                  _%first17939%_)))
                             (_%$%E1789917909%_)))))
                  (if (null? _%$%g1789617905%_)
                      '#!void
                      (_%$%try-match1789817943%_)))))))))
    (define gerbil-ascent/program/component-plan#bitmap-first-visit!
      (lambda (_%bitmap17879%_ _%id17880%_)
        (let* ((_%byte17882%_ (quotient _%id17880%_ '8))
               (_%mask17884%_ (arithmetic-shift '1 (modulo _%id17880%_ '8)))
               (_%previous17886%_
                (u8vector-ref _%bitmap17879%_ _%byte17882%_)))
          (if (zero? (bitwise-and _%previous17886%_ _%mask17884%_))
              (begin
                (u8vector-set!
                 _%bitmap17879%_
                 _%byte17882%_
                 (bitwise-ior _%previous17886%_ _%mask17884%_))
                '#t)
              '#f))))
    (define gerbil-ascent/program/component-plan#predecessor-first-visit!
      (lambda (_%seen17864%_ _%target17865%_ _%id17866%_ _%first17867%_)
        (let ((_%members17869%_ (vector-ref _%seen17864%_ _%target17865%_)))
          (if _%members17869%_
              '#!void
              (begin
                (set! _%members17869%_
                      (let () (declare (not safe)) (make-hash-table-eqv)))
                (let ()
                  (declare (not safe))
                  (hash-put! _%members17869%_ _%first17867%_ '#t))
                (vector-set! _%seen17864%_ _%target17865%_ _%members17869%_)))
          (if (u8vector? _%members17869%_)
              (gerbil-ascent/program/component-plan#bitmap-first-visit!
               _%members17869%_
               _%id17866%_)
              (if (let ()
                    (declare (not safe))
                    (hash-get _%members17869%_ _%id17866%_))
                  '#f
                  (let ()
                    (let ()
                      (declare (not safe))
                      (hash-put! _%members17869%_ _%id17866%_ '#t))
                    (if (>= (let ()
                              (declare (not safe))
                              (hash-length _%members17869%_))
                            (max '32
                                 (quotient
                                  (vector-length _%seen17864%_)
                                  '128)))
                        (let ((_%bitmap17874%_
                               (make-u8vector
                                (quotient
                                 (+ (vector-length _%seen17864%_) '7)
                                 '8)
                                '0)))
                          (let ((__tmp35477
                                 (lambda (_%key17876%_ _%_17877%_)
                                   (gerbil-ascent/program/component-plan#bitmap-first-visit!
                                    _%bitmap17874%_
                                    _%key17876%_))))
                            (declare (not safe))
                            (hash-for-each __tmp35477 _%members17869%_))
                          (vector-set!
                           _%seen17864%_
                           _%target17865%_
                           _%bitmap17874%_))
                        '#!void)
                    '#t))))))
    (define gerbil-ascent/program/component-plan#register-component-predecessor!
      (lambda (_%from17854%_ _%to17855%_ _%seen17856%_)
        (if (eq? _%from17854%_ _%to17855%_)
            '#!void
            (let ((_%id17858%_
                   (##structure-ref
                    _%from17854%_
                    '1
                    gerbil-ascent/program/component-plan#positive-component::t
                    '#f))
                  (_%previous17859%_
                   (##structure-ref
                    _%to17855%_
                    '4
                    gerbil-ascent/program/component-plan#positive-component::t
                    '#f)))
              (if (and (pair? _%previous17859%_)
                       (eqv? _%id17858%_
                             (let ()
                               (declare (not safe))
                               (##car _%previous17859%_))))
                  '#!void
                  (if (or (null? _%previous17859%_)
                          (gerbil-ascent/program/component-plan#predecessor-first-visit!
                           _%seen17856%_
                           (##structure-ref
                            _%to17855%_
                            '1
                            gerbil-ascent/program/component-plan#positive-component::t
                            '#f)
                           _%id17858%_
                           (car _%previous17859%_)))
                      (##structure-set!
                       _%to17855%_
                       (cons _%id17858%_ _%previous17859%_)
                       '4
                       gerbil-ascent/program/component-plan#positive-component::t
                       '#f)
                      '#!void))))))
    (define gerbil-ascent/program/component-plan#+positive-components-cache+
      (let ((__tmp35478 (make-mutex 'ascent-positive-components)))
        (declare (not safe))
        (make-hash-table-eq 'weak-keys: '#t 'lock: __tmp35478)))
    (define gerbil-ascent/program/component-plan#gerbil-ascent-positive-components
      (lambda (_%analysis17847%_)
        (let ((_%$e17849%_
               (let ()
                 (declare (not safe))
                 (__hash-get
                  gerbil-ascent/program/component-plan#+positive-components-cache+
                  _%analysis17847%_))))
          (if _%$e17849%_
              _%$e17849%_
              (let ((_%fresh17852%_
                     (gerbil-ascent/program/component-plan#gerbil-ascent-compile-positive-components
                      _%analysis17847%_)))
                (let ()
                  (declare (not safe))
                  (__hash-put!
                   gerbil-ascent/program/component-plan#+positive-components-cache+
                   _%analysis17847%_
                   _%fresh17852%_))
                _%fresh17852%_)))))
    (define gerbil-ascent/program/component-plan#gerbil-ascent-component-mode?
      (lambda (_%session?17834%_
               _%workers17835%_
               _%canceled?17836%_
               _%analysis17837%_
               _%schema17838%_)
        (if _%session?17834%_
            '#f
            (if (or (> _%workers17835%_ '1) _%canceled?17836%_)
                (if (let ((__tmp35480
                           (lambda (_%rules17843%_)
                             (let ((__tmp35481
                                    (lambda (_%rule17845%_)
                                      (let ((__tmp35482
                                             (vector-ref _%rule17845%_ '5)))
                                        (declare (not safe))
                                        (gerbil-ascent/core/positive-plan#gerbil-ascent-pure-positive-plan?
                                         __tmp35482)))))
                               (declare (not safe))
                               (andmap__0 __tmp35481 _%rules17843%_))))
                          (__tmp35479
                           (vector->list (vector-ref _%analysis17837%_ '5))))
                      (declare (not safe))
                      (andmap__0 __tmp35480 __tmp35479))
                    (if (let ((__tmp35483
                               (vector->list (vector-ref _%schema17838%_ '9))))
                          (declare (not safe))
                          (andmap__0
                           gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                           __tmp35483))
                        (if (let ((__tmp35484
                                   (vector->list
                                    (vector-ref _%schema17838%_ '5))))
                              (declare (not safe))
                              (andmap__0
                               gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                               __tmp35484))
                            (if (let ((__tmp35485
                                       (vector->list
                                        (vector-ref _%schema17838%_ '7))))
                                  (declare (not safe))
                                  (andmap__0 not __tmp35485))
                                (let ((__tmp35486
                                       (vector->list
                                        (vector-ref _%schema17838%_ '3))))
                                  (declare (not safe))
                                  (andmap__0 not __tmp35486))
                                '#f)
                            '#f)
                        '#f)
                    '#f)
                '#f))))
    (define gerbil-ascent/program/component-plan#gerbil-ascent-compile-positive-components
      (lambda (_%analysis17802%_)
        (let* ((_%successors17804%_ (vector-ref _%analysis17802%_ '6))
               (_%count17806%_ (vector-length _%successors17804%_))
               (_%groups17808%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/core/dependency-graph#gerbil-ascent-graph-components
                   _%successors17804%_)))
               (_%membership17810%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count17806%_ '#f)))
               (_%components17815%_
                (let ((__tmp35489
                       (lambda (_%id17812%_ _%members17813%_)
                         (let ()
                           (declare (not safe))
                           (##structure
                            gerbil-ascent/program/component-plan#positive-component::t
                            _%id17812%_
                            _%members17813%_
                            '()
                            '()))))
                      (__tmp35487
                       (let ((__tmp35488
                              (let ()
                                (declare (not safe))
                                (##length _%groups17808%_))))
                         (declare (not safe))
                         (##iota __tmp35488))))
                  (declare (not safe))
                  (##map __tmp35489 __tmp35487 _%groups17808%_)))
               (_%predecessors-seen17817%_
                (let ((__tmp35490
                       (let ()
                         (declare (not safe))
                         (##length _%groups17808%_))))
                  (declare (not safe))
                  (##make-vector __tmp35490 '#f))))
          (let ((__tmp35491
                 (lambda (_%component17820%_)
                   (for-each
                    (lambda (_%relation17822%_)
                      (vector-set!
                       _%membership17810%_
                       _%relation17822%_
                       _%component17820%_))
                    (##structure-ref
                     _%component17820%_
                     '2
                     gerbil-ascent/program/component-plan#positive-component::t
                     '#f)))))
            (declare (not safe))
            (##for-each __tmp35491 _%components17815%_))
          (let ((__tmp35493
                 (lambda (_%rules17824%_)
                   (for-each
                    (lambda (_%$%g1782517827%_)
                      (gerbil-ascent/program/component-plan#project-component-rule!
                       _%$%g1782517827%_
                       _%membership17810%_))
                    _%rules17824%_)))
                (__tmp35492 (vector->list (vector-ref _%analysis17802%_ '5))))
            (declare (not safe))
            (##for-each __tmp35493 __tmp35492))
          (let ((__tmp35495
                 (lambda (_%source17830%_)
                   (for-each
                    (lambda (_%target17832%_)
                      (gerbil-ascent/program/component-plan#register-component-predecessor!
                       (vector-ref _%membership17810%_ _%source17830%_)
                       (vector-ref _%membership17810%_ _%target17832%_)
                       _%predecessors-seen17817%_))
                    (vector-ref _%successors17804%_ _%source17830%_))))
                (__tmp35494
                 (let () (declare (not safe)) (##iota _%count17806%_))))
            (declare (not safe))
            (##for-each __tmp35495 __tmp35494))
          _%components17815%_)))))
