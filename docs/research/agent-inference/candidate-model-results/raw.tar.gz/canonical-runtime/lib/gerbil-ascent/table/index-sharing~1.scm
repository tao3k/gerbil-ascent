(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/index-sharing[1]#_g33612_|
    (##structure
     gx#syntax-quote::t
     'column-order::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33614_|
    (##structure
     gx#syntax-quote::t
     'make-column-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33616_|
    (##structure
     gx#syntax-quote::t
     'column-order?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33618_|
    (##structure
     gx#syntax-quote::t
     'column-order-sets
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33619_|
    (##structure
     gx#syntax-quote::t
     'column-order-successors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33621_|
    (##structure
     gx#syntax-quote::t
     'column-order-sets-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33622_|
    (##structure
     gx#syntax-quote::t
     'column-order-successors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33624_|
    (##structure
     gx#syntax-quote::t
     '&column-order-sets
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33625_|
    (##structure
     gx#syntax-quote::t
     '&column-order-successors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33627_|
    (##structure
     gx#syntax-quote::t
     '&column-order-sets-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33628_|
    (##structure
     gx#syntax-quote::t
     '&column-order-successors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33630_|
    (##structure
     gx#syntax-quote::t
     'shared-index::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33632_|
    (##structure
     gx#syntax-quote::t
     'make-shared-index
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33634_|
    (##structure
     gx#syntax-quote::t
     'shared-index?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33636_|
    (##structure
     gx#syntax-quote::t
     'shared-index-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33637_|
    (##structure
     gx#syntax-quote::t
     'shared-index-root
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33638_|
    (##structure
     gx#syntax-quote::t
     'shared-index-ordinal
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33639_|
    (##structure
     gx#syntax-quote::t
     'shared-index-views
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33640_|
    (##structure
     gx#syntax-quote::t
     'shared-index-projection
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33641_|
    (##structure
     gx#syntax-quote::t
     'shared-index-key-plans
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33643_|
    (##structure
     gx#syntax-quote::t
     'shared-index-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33644_|
    (##structure
     gx#syntax-quote::t
     'shared-index-root-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33645_|
    (##structure
     gx#syntax-quote::t
     'shared-index-ordinal-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33646_|
    (##structure
     gx#syntax-quote::t
     'shared-index-views-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33647_|
    (##structure
     gx#syntax-quote::t
     'shared-index-projection-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33648_|
    (##structure
     gx#syntax-quote::t
     'shared-index-key-plans-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33650_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33651_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-root
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33652_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-ordinal
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33653_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-views
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33654_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-projection
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33655_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-key-plans
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33657_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33658_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-root-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33659_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-ordinal-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33660_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-views-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33661_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-projection-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33662_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-key-plans-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33664_|
    (##structure
     gx#syntax-quote::t
     'column-projection::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33666_|
    (##structure
     gx#syntax-quote::t
     'make-column-projection
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33668_|
    (##structure
     gx#syntax-quote::t
     'column-projection?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33670_|
    (##structure
     gx#syntax-quote::t
     'column-projection-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33671_|
    (##structure
     gx#syntax-quote::t
     'column-projection-writes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33672_|
    (##structure
     gx#syntax-quote::t
     'column-projection-frame
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33674_|
    (##structure
     gx#syntax-quote::t
     'column-projection-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33675_|
    (##structure
     gx#syntax-quote::t
     'column-projection-writes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33676_|
    (##structure
     gx#syntax-quote::t
     'column-projection-frame-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33678_|
    (##structure
     gx#syntax-quote::t
     '&column-projection-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33679_|
    (##structure
     gx#syntax-quote::t
     '&column-projection-writes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33680_|
    (##structure
     gx#syntax-quote::t
     '&column-projection-frame
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33682_|
    (##structure
     gx#syntax-quote::t
     '&column-projection-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33683_|
    (##structure
     gx#syntax-quote::t
     '&column-projection-writes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33684_|
    (##structure
     gx#syntax-quote::t
     '&column-projection-frame-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33686_|
    (##structure
     gx#syntax-quote::t
     'key-projection::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33688_|
    (##structure
     gx#syntax-quote::t
     'make-key-projection
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33690_|
    (##structure
     gx#syntax-quote::t
     'key-projection?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33692_|
    (##structure
     gx#syntax-quote::t
     'key-projection-physical
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33693_|
    (##structure
     gx#syntax-quote::t
     'key-projection-writes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33694_|
    (##structure
     gx#syntax-quote::t
     'key-projection-frame
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33696_|
    (##structure
     gx#syntax-quote::t
     'key-projection-physical-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33697_|
    (##structure
     gx#syntax-quote::t
     'key-projection-writes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33698_|
    (##structure
     gx#syntax-quote::t
     'key-projection-frame-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33700_|
    (##structure
     gx#syntax-quote::t
     '&key-projection-physical
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33701_|
    (##structure
     gx#syntax-quote::t
     '&key-projection-writes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33702_|
    (##structure
     gx#syntax-quote::t
     '&key-projection-frame
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33704_|
    (##structure
     gx#syntax-quote::t
     '&key-projection-physical-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33705_|
    (##structure
     gx#syntax-quote::t
     '&key-projection-writes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33706_|
    (##structure
     gx#syntax-quote::t
     '&key-projection-frame-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/table/index-sharing[:0:]#column-order|
      (let ((__obj33548
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33548
           'gerbil-ascent/table/index-sharing#column-order::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33548 'column-order '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33548
           '(sets successors)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33548
           '(sets successors)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33548 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33548 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33548 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33548 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33548 '#f '13 '#f '#f))
        (let ((__tmp33611 |gerbil-ascent/table/index-sharing[1]#_g33612_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33548 __tmp33611 '4 '#f '#f))
        (let ((__tmp33613 |gerbil-ascent/table/index-sharing[1]#_g33614_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33548 __tmp33613 '14 '#f '#f))
        (let ((__tmp33615 |gerbil-ascent/table/index-sharing[1]#_g33616_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33548 __tmp33615 '15 '#f '#f))
        (let ((__tmp33617
               (cons (cons 'sets
                           |gerbil-ascent/table/index-sharing[1]#_g33618_|)
                     (cons (cons 'successors
                                 |gerbil-ascent/table/index-sharing[1]#_g33619_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33548 __tmp33617 '16 '#f '#f))
        (let ((__tmp33620
               (cons (cons 'sets
                           |gerbil-ascent/table/index-sharing[1]#_g33621_|)
                     (cons (cons 'successors
                                 |gerbil-ascent/table/index-sharing[1]#_g33622_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33548 __tmp33620 '17 '#f '#f))
        (let ((__tmp33623
               (cons (cons 'sets
                           |gerbil-ascent/table/index-sharing[1]#_g33624_|)
                     (cons (cons 'successors
                                 |gerbil-ascent/table/index-sharing[1]#_g33625_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33548 __tmp33623 '18 '#f '#f))
        (let ((__tmp33626
               (cons (cons 'sets
                           |gerbil-ascent/table/index-sharing[1]#_g33627_|)
                     (cons (cons 'successors
                                 |gerbil-ascent/table/index-sharing[1]#_g33628_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33548 __tmp33626 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33548 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33548 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33548 '() '21 '#f '#f))
        __obj33548))
    (define |gerbil-ascent/table/index-sharing[:0:]#shared-index|
      (let ((__obj33549
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33549
           'gerbil-ascent/table/index-sharing#shared-index::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33549 'shared-index '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33549
           '(columns root ordinal views projection key-plans)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33549
           '(columns root ordinal views projection key-plans)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33549 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33549 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33549 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33549 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33549 '#f '13 '#f '#f))
        (let ((__tmp33629 |gerbil-ascent/table/index-sharing[1]#_g33630_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33549 __tmp33629 '4 '#f '#f))
        (let ((__tmp33631 |gerbil-ascent/table/index-sharing[1]#_g33632_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33549 __tmp33631 '14 '#f '#f))
        (let ((__tmp33633 |gerbil-ascent/table/index-sharing[1]#_g33634_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33549 __tmp33633 '15 '#f '#f))
        (let ((__tmp33635
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g33636_|)
                     (cons (cons 'root
                                 |gerbil-ascent/table/index-sharing[1]#_g33637_|)
                           (cons (cons 'ordinal
                                       |gerbil-ascent/table/index-sharing[1]#_g33638_|)
                                 (cons (cons 'views
                                             |gerbil-ascent/table/index-sharing[1]#_g33639_|)
                                       (cons (cons 'projection
                                                   |gerbil-ascent/table/index-sharing[1]#_g33640_|)
                                             (cons (cons 'key-plans
                                                         |gerbil-ascent/table/index-sharing[1]#_g33641_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33549 __tmp33635 '16 '#f '#f))
        (let ((__tmp33642
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g33643_|)
                     (cons (cons 'root
                                 |gerbil-ascent/table/index-sharing[1]#_g33644_|)
                           (cons (cons 'ordinal
                                       |gerbil-ascent/table/index-sharing[1]#_g33645_|)
                                 (cons (cons 'views
                                             |gerbil-ascent/table/index-sharing[1]#_g33646_|)
                                       (cons (cons 'projection
                                                   |gerbil-ascent/table/index-sharing[1]#_g33647_|)
                                             (cons (cons 'key-plans
                                                         |gerbil-ascent/table/index-sharing[1]#_g33648_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33549 __tmp33642 '17 '#f '#f))
        (let ((__tmp33649
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g33650_|)
                     (cons (cons 'root
                                 |gerbil-ascent/table/index-sharing[1]#_g33651_|)
                           (cons (cons 'ordinal
                                       |gerbil-ascent/table/index-sharing[1]#_g33652_|)
                                 (cons (cons 'views
                                             |gerbil-ascent/table/index-sharing[1]#_g33653_|)
                                       (cons (cons 'projection
                                                   |gerbil-ascent/table/index-sharing[1]#_g33654_|)
                                             (cons (cons 'key-plans
                                                         |gerbil-ascent/table/index-sharing[1]#_g33655_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33549 __tmp33649 '18 '#f '#f))
        (let ((__tmp33656
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g33657_|)
                     (cons (cons 'root
                                 |gerbil-ascent/table/index-sharing[1]#_g33658_|)
                           (cons (cons 'ordinal
                                       |gerbil-ascent/table/index-sharing[1]#_g33659_|)
                                 (cons (cons 'views
                                             |gerbil-ascent/table/index-sharing[1]#_g33660_|)
                                       (cons (cons 'projection
                                                   |gerbil-ascent/table/index-sharing[1]#_g33661_|)
                                             (cons (cons 'key-plans
                                                         |gerbil-ascent/table/index-sharing[1]#_g33662_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33549 __tmp33656 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33549 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33549 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33549 '() '21 '#f '#f))
        __obj33549))
    (define |gerbil-ascent/table/index-sharing[:0:]#column-projection|
      (let ((__obj33550
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33550
           'gerbil-ascent/table/index-sharing#column-projection::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33550
           'column-projection
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33550
           '(columns writes frame)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33550
           '(columns writes frame)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33550 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33550 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33550 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33550 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33550 '#f '13 '#f '#f))
        (let ((__tmp33663 |gerbil-ascent/table/index-sharing[1]#_g33664_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33550 __tmp33663 '4 '#f '#f))
        (let ((__tmp33665 |gerbil-ascent/table/index-sharing[1]#_g33666_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33550 __tmp33665 '14 '#f '#f))
        (let ((__tmp33667 |gerbil-ascent/table/index-sharing[1]#_g33668_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33550 __tmp33667 '15 '#f '#f))
        (let ((__tmp33669
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g33670_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g33671_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g33672_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33550 __tmp33669 '16 '#f '#f))
        (let ((__tmp33673
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g33674_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g33675_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g33676_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33550 __tmp33673 '17 '#f '#f))
        (let ((__tmp33677
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g33678_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g33679_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g33680_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33550 __tmp33677 '18 '#f '#f))
        (let ((__tmp33681
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g33682_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g33683_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g33684_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33550 __tmp33681 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33550 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33550 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33550 '() '21 '#f '#f))
        __obj33550))
    (define |gerbil-ascent/table/index-sharing[:0:]#key-projection|
      (let ((__obj33551
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33551
           'gerbil-ascent/table/index-sharing#key-projection::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 'key-projection '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33551
           '(physical writes frame)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33551
           '(physical writes frame)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 '#f '13 '#f '#f))
        (let ((__tmp33685 |gerbil-ascent/table/index-sharing[1]#_g33686_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 __tmp33685 '4 '#f '#f))
        (let ((__tmp33687 |gerbil-ascent/table/index-sharing[1]#_g33688_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 __tmp33687 '14 '#f '#f))
        (let ((__tmp33689 |gerbil-ascent/table/index-sharing[1]#_g33690_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 __tmp33689 '15 '#f '#f))
        (let ((__tmp33691
               (cons (cons 'physical
                           |gerbil-ascent/table/index-sharing[1]#_g33692_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g33693_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g33694_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 __tmp33691 '16 '#f '#f))
        (let ((__tmp33695
               (cons (cons 'physical
                           |gerbil-ascent/table/index-sharing[1]#_g33696_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g33697_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g33698_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 __tmp33695 '17 '#f '#f))
        (let ((__tmp33699
               (cons (cons 'physical
                           |gerbil-ascent/table/index-sharing[1]#_g33700_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g33701_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g33702_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 __tmp33699 '18 '#f '#f))
        (let ((__tmp33703
               (cons (cons 'physical
                           |gerbil-ascent/table/index-sharing[1]#_g33704_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g33705_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g33706_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 __tmp33703 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 '() '21 '#f '#f))
        __obj33551))))
