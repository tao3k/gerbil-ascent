(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/source-state[1]#_g36863_|
    (##structure
     gx#syntax-quote::t
     'source-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36865_|
    (##structure
     gx#syntax-quote::t
     'make-source-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36867_|
    (##structure
     gx#syntax-quote::t
     'source-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36869_|
    (##structure
     gx#syntax-quote::t
     'source-state-originals
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36870_|
    (##structure
     gx#syntax-quote::t
     'source-state-additions
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36871_|
    (##structure
     gx#syntax-quote::t
     'source-state-overrides
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36872_|
    (##structure
     gx#syntax-quote::t
     'source-state-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36874_|
    (##structure
     gx#syntax-quote::t
     'source-state-originals-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36875_|
    (##structure
     gx#syntax-quote::t
     'source-state-additions-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36876_|
    (##structure
     gx#syntax-quote::t
     'source-state-overrides-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36877_|
    (##structure
     gx#syntax-quote::t
     'source-state-snapshot-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36879_|
    (##structure
     gx#syntax-quote::t
     '&source-state-originals
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36880_|
    (##structure
     gx#syntax-quote::t
     '&source-state-additions
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36881_|
    (##structure
     gx#syntax-quote::t
     '&source-state-overrides
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36882_|
    (##structure
     gx#syntax-quote::t
     '&source-state-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36884_|
    (##structure
     gx#syntax-quote::t
     '&source-state-originals-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36885_|
    (##structure
     gx#syntax-quote::t
     '&source-state-additions-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36886_|
    (##structure
     gx#syntax-quote::t
     '&source-state-overrides-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36887_|
    (##structure
     gx#syntax-quote::t
     '&source-state-snapshot-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g36889_|
    (gx#core-deserialize-mark
     '(0
       ($%arg16911 . _%$%arg1691116969%_)
       (id . _%id16936%_)
       (arg . _%arg16999%_)
       ($%arg16912 . _%$%arg1691216983%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-state[1]#_g36890_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g36889_|)))
  (define |gerbil-ascent/program/source-state[1]#_g36893_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-state[1]#_g36894_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g36893_|)))
  (define |gerbil-ascent/program/source-state[1]#_g36896_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g36893_|)))
  (define |gerbil-ascent/program/source-state[1]#_g36898_|
    (gx#core-deserialize-mark
     '(0
       (id . _%id17056%_)
       (arg . _%arg17119%_)
       ($%arg17032 . _%$%arg1703217089%_)
       ($%arg17033 . _%$%arg1703317103%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-state[1]#_g36899_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g36898_|)))
  (define |gerbil-ascent/program/source-state[1]#_g36902_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-state[1]#_g36903_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g36902_|)))
  (define |gerbil-ascent/program/source-state[1]#_g36905_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g36902_|)))
  (define |gerbil-ascent/program/source-state[1]#_g36907_|
    (gx#core-deserialize-mark
     '(0
       ($%arg17152 . _%$%arg1715217209%_)
       (id . _%id17176%_)
       (arg . _%arg17239%_)
       ($%arg17153 . _%$%arg1715317223%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-state[1]#_g36908_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g36907_|)))
  (define |gerbil-ascent/program/source-state[1]#_g36911_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-state[1]#_g36912_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g36911_|)))
  (define |gerbil-ascent/program/source-state[1]#_g36914_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g36911_|)))
  (begin
    (define |gerbil-ascent/program/source-state[:0:]#source-state|
      (let ((__obj36802
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36802
           'gerbil-ascent/program/source-state#source-state::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36802 'source-state '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36802
           '(originals additions overrides snapshot)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36802
           '(originals additions overrides snapshot)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36802 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36802 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36802 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36802 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36802 '#f '13 '#f '#f))
        (let ((__tmp36862 |gerbil-ascent/program/source-state[1]#_g36863_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36802 __tmp36862 '4 '#f '#f))
        (let ((__tmp36864 |gerbil-ascent/program/source-state[1]#_g36865_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36802 __tmp36864 '14 '#f '#f))
        (let ((__tmp36866 |gerbil-ascent/program/source-state[1]#_g36867_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36802 __tmp36866 '15 '#f '#f))
        (let ((__tmp36868
               (cons (cons 'originals
                           |gerbil-ascent/program/source-state[1]#_g36869_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-state[1]#_g36870_|)
                           (cons (cons 'overrides
                                       |gerbil-ascent/program/source-state[1]#_g36871_|)
                                 (cons (cons 'snapshot
                                             |gerbil-ascent/program/source-state[1]#_g36872_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36802 __tmp36868 '16 '#f '#f))
        (let ((__tmp36873
               (cons (cons 'originals
                           |gerbil-ascent/program/source-state[1]#_g36874_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-state[1]#_g36875_|)
                           (cons (cons 'overrides
                                       |gerbil-ascent/program/source-state[1]#_g36876_|)
                                 (cons (cons 'snapshot
                                             |gerbil-ascent/program/source-state[1]#_g36877_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36802 __tmp36873 '17 '#f '#f))
        (let ((__tmp36878
               (cons (cons 'originals
                           |gerbil-ascent/program/source-state[1]#_g36879_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-state[1]#_g36880_|)
                           (cons (cons 'overrides
                                       |gerbil-ascent/program/source-state[1]#_g36881_|)
                                 (cons (cons 'snapshot
                                             |gerbil-ascent/program/source-state[1]#_g36882_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36802 __tmp36878 '18 '#f '#f))
        (let ((__tmp36883
               (cons (cons 'originals
                           |gerbil-ascent/program/source-state[1]#_g36884_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-state[1]#_g36885_|)
                           (cons (cons 'overrides
                                       |gerbil-ascent/program/source-state[1]#_g36886_|)
                                 (cons (cons 'snapshot
                                             |gerbil-ascent/program/source-state[1]#_g36887_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36802 __tmp36883 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36802 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36802 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36802 '() '21 '#f '#f))
        __obj36802))
    (define |gerbil-ascent/program/source-state[:0:]#@gerbil-ascent-source-state-rows|
      (lambda (_%$stx16893%_)
        (let* ((_%__stx3672536726%_ _%$stx16893%_)
               (_%$%g1689816919%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3672536726%_)))))
          (let ((_%__kont3672836729%_
                 (lambda (_%$%g1690016985%_)
                   (cons (let ((__tmp36888
                                |gerbil-ascent/program/source-state[1]#_g36890_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp36888
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'state))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'index))
                                                 '()))
                                     (cons (let ((__tmp36891
                                                  (lambda (_%$%g1700017003%_
                                                           _%$%g1700117006%_)
                                                    (cons _%$%g1700017003%_
                                                          _%$%g1700117006%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp36891
                                              '()
                                              _%$%g1690016985%_))
                                           '()))
                               (cons (cons (let ((__tmp36892
                                                  |gerbil-ascent/program/source-state[1]#_g36894_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp36892
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'state))
                     (cons (let ((__tmp36895
                                  |gerbil-ascent/program/source-state[1]#_g36896_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp36895 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'source-state))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0
                        '#f
                        '__gerbil-ascent-source-state-rows))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'state))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'index))
                                 '())))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3673236733%_
                 (lambda (_%$%g1691316926%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0
                      '#f
                      'gerbil-ascent-source-state-rows)))))
            (let* ((_%$%g1689716938%_
                    (lambda ()
                      (let ((_%$%g1691316926%_ _%__stx3672536726%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1691316926%_))
                            (_%__kont3673236733%_ _%$%g1691316926%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1689816919%_))))))
                   (_%__match3674836749%_
                    (lambda (_%$%e1690116945%_
                             _%$%hd1690216949%_
                             _%$%tl1690316952%_
                             _%__splice3673036731%_
                             _%$%target1690416955%_
                             _%$%tl1690616958%_)
                      (letrec ((_%$%loop1690716961%_
                                (lambda (_%$%hd1690516965%_
                                         _%$%arg1691116968%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1690516965%_))
                                      (let ((_%$%e1690816971%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1690516965%_))))
                                        (let ((_%$%lp-tl1691016978%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1690816971%_)))
                                              (_%$%lp-hd1690916975%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1690816971%_))))
                                          (_%$%loop1690716961%_
                                           _%$%lp-tl1691016978%_
                                           (cons _%$%lp-hd1690916975%_
                                                 _%$%arg1691116968%_))))
                                      (let ((_%$%arg1691216981%_
                                             (reverse _%$%arg1691116968%_)))
                                        (_%__kont3672836729%_
                                         _%$%arg1691216981%_))))))
                        (_%$%loop1690716961%_ _%$%target1690416955%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3672536726%_))
                  (let ((_%$%e1690116945%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3672536726%_))))
                    (let ((_%$%tl1690316952%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1690116945%_)))
                          (_%$%hd1690216949%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1690116945%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1690316952%_))
                          (let ((_%__splice3673036731%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1690316952%_
                                    '0))))
                            (let ((_%$%tl1690616958%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3673036731%_ '1)))
                                  (_%$%target1690416955%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3673036731%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1690616958%_))
                                  (_%__match3674836749%_
                                   _%$%e1690116945%_
                                   _%$%hd1690216949%_
                                   _%$%tl1690316952%_
                                   _%__splice3673036731%_
                                   _%$%target1690416955%_
                                   _%$%tl1690616958%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1689716938%_)))))
                          (let () (declare (not safe)) (_%$%g1689716938%_)))))
                  (let () (declare (not safe)) (_%$%g1689716938%_))))))))
    (define |gerbil-ascent/program/source-state[:0:]#@gerbil-ascent-prepare-source-replacement|
      (lambda (_%$stx17014%_)
        (let* ((_%__stx3675136752%_ _%$stx17014%_)
               (_%$%g1701917040%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3675136752%_)))))
          (let ((_%__kont3675436755%_
                 (lambda (_%$%g1702117105%_)
                   (cons (let ((__tmp36897
                                |gerbil-ascent/program/source-state[1]#_g36899_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp36897
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'state))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'index))
                                                 (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'rows))
                                                       '())))
                                     (cons (let ((__tmp36900
                                                  (lambda (_%$%g1712017123%_
                                                           _%$%g1712117126%_)
                                                    (cons _%$%g1712017123%_
                                                          _%$%g1712117126%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp36900
                                              '()
                                              _%$%g1702117105%_))
                                           '()))
                               (cons (cons (let ((__tmp36901
                                                  |gerbil-ascent/program/source-state[1]#_g36903_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp36901
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'state))
                     (cons (let ((__tmp36904
                                  |gerbil-ascent/program/source-state[1]#_g36905_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp36904 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'source-state))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0
                        '#f
                        '__gerbil-ascent-prepare-source-replacement))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'state))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'index))
                                 (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'rows))
                                       '()))))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3675836759%_
                 (lambda (_%$%g1703417047%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0
                      '#f
                      'gerbil-ascent-prepare-source-replacement)))))
            (let* ((_%$%g1701817058%_
                    (lambda ()
                      (let ((_%$%g1703417047%_ _%__stx3675136752%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1703417047%_))
                            (_%__kont3675836759%_ _%$%g1703417047%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1701917040%_))))))
                   (_%__match3677436775%_
                    (lambda (_%$%e1702217065%_
                             _%$%hd1702317069%_
                             _%$%tl1702417072%_
                             _%__splice3675636757%_
                             _%$%target1702517075%_
                             _%$%tl1702717078%_)
                      (letrec ((_%$%loop1702817081%_
                                (lambda (_%$%hd1702617085%_
                                         _%$%arg1703217088%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1702617085%_))
                                      (let ((_%$%e1702917091%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1702617085%_))))
                                        (let ((_%$%lp-tl1703117098%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1702917091%_)))
                                              (_%$%lp-hd1703017095%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1702917091%_))))
                                          (_%$%loop1702817081%_
                                           _%$%lp-tl1703117098%_
                                           (cons _%$%lp-hd1703017095%_
                                                 _%$%arg1703217088%_))))
                                      (let ((_%$%arg1703317101%_
                                             (reverse _%$%arg1703217088%_)))
                                        (_%__kont3675436755%_
                                         _%$%arg1703317101%_))))))
                        (_%$%loop1702817081%_ _%$%target1702517075%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3675136752%_))
                  (let ((_%$%e1702217065%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3675136752%_))))
                    (let ((_%$%tl1702417072%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1702217065%_)))
                          (_%$%hd1702317069%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1702217065%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1702417072%_))
                          (let ((_%__splice3675636757%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1702417072%_
                                    '0))))
                            (let ((_%$%tl1702717078%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3675636757%_ '1)))
                                  (_%$%target1702517075%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3675636757%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1702717078%_))
                                  (_%__match3677436775%_
                                   _%$%e1702217065%_
                                   _%$%hd1702317069%_
                                   _%$%tl1702417072%_
                                   _%__splice3675636757%_
                                   _%$%target1702517075%_
                                   _%$%tl1702717078%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1701817058%_)))))
                          (let () (declare (not safe)) (_%$%g1701817058%_)))))
                  (let () (declare (not safe)) (_%$%g1701817058%_))))))))
    (define |gerbil-ascent/program/source-state[:0:]#@gerbil-ascent-commit-source-replacement!|
      (lambda (_%$stx17134%_)
        (let* ((_%__stx3677736778%_ _%$stx17134%_)
               (_%$%g1713917160%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3677736778%_)))))
          (let ((_%__kont3678036781%_
                 (lambda (_%$%g1714117225%_)
                   (cons (let ((__tmp36906
                                |gerbil-ascent/program/source-state[1]#_g36908_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp36906
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'state))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'index))
                                                 (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'rows))
                                                       (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'cut))
                     '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     (cons (let ((__tmp36909
                                                  (lambda (_%$%g1724017243%_
                                                           _%$%g1724117246%_)
                                                    (cons _%$%g1724017243%_
                                                          _%$%g1724117246%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp36909
                                              '()
                                              _%$%g1714117225%_))
                                           '()))
                               (cons (cons (let ((__tmp36910
                                                  |gerbil-ascent/program/source-state[1]#_g36912_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp36910
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'state))
                     (cons (let ((__tmp36913
                                  |gerbil-ascent/program/source-state[1]#_g36914_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp36913 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'source-state))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0
                        '#f
                        '__gerbil-ascent-commit-source-replacement!))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'state))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'index))
                                 (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'rows))
                                       (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f 'cut))
                                             '())))))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3678436785%_
                 (lambda (_%$%g1715417167%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0
                      '#f
                      'gerbil-ascent-commit-source-replacement!)))))
            (let* ((_%$%g1713817178%_
                    (lambda ()
                      (let ((_%$%g1715417167%_ _%__stx3677736778%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1715417167%_))
                            (_%__kont3678436785%_ _%$%g1715417167%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1713917160%_))))))
                   (_%__match3680036801%_
                    (lambda (_%$%e1714217185%_
                             _%$%hd1714317189%_
                             _%$%tl1714417192%_
                             _%__splice3678236783%_
                             _%$%target1714517195%_
                             _%$%tl1714717198%_)
                      (letrec ((_%$%loop1714817201%_
                                (lambda (_%$%hd1714617205%_
                                         _%$%arg1715217208%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1714617205%_))
                                      (let ((_%$%e1714917211%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1714617205%_))))
                                        (let ((_%$%lp-tl1715117218%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1714917211%_)))
                                              (_%$%lp-hd1715017215%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1714917211%_))))
                                          (_%$%loop1714817201%_
                                           _%$%lp-tl1715117218%_
                                           (cons _%$%lp-hd1715017215%_
                                                 _%$%arg1715217208%_))))
                                      (let ((_%$%arg1715317221%_
                                             (reverse _%$%arg1715217208%_)))
                                        (_%__kont3678036781%_
                                         _%$%arg1715317221%_))))))
                        (_%$%loop1714817201%_ _%$%target1714517195%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3677736778%_))
                  (let ((_%$%e1714217185%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3677736778%_))))
                    (let ((_%$%tl1714417192%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1714217185%_)))
                          (_%$%hd1714317189%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1714217185%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1714417192%_))
                          (let ((_%__splice3678236783%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1714417192%_
                                    '0))))
                            (let ((_%$%tl1714717198%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3678236783%_ '1)))
                                  (_%$%target1714517195%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3678236783%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1714717198%_))
                                  (_%__match3680036801%_
                                   _%$%e1714217185%_
                                   _%$%hd1714317189%_
                                   _%$%tl1714417192%_
                                   _%__splice3678236783%_
                                   _%$%target1714517195%_
                                   _%$%tl1714717198%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1713817178%_)))))
                          (let () (declare (not safe)) (_%$%g1713817178%_)))))
                  (let () (declare (not safe)) (_%$%g1713817178%_))))))))))
