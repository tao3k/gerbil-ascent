(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/index[1]#_g36018_|
    (##structure
     gx#syntax-quote::t
     'row-indexes::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36020_|
    (##structure
     gx#syntax-quote::t
     'make-row-indexes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36022_|
    (##structure
     gx#syntax-quote::t
     'row-indexes?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36024_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36025_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-advance!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36026_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-plan!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36027_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-visit-parts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36029_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36030_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-advance!-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36031_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-plan!-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36032_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-visit-parts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36034_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36035_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-advance!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36036_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-plan!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36037_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-visit-parts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36039_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36040_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-advance!-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36041_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-plan!-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36042_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-visit-parts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36044_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36046_|
    (##structure
     gx#syntax-quote::t
     'make-provider-row-member
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36048_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36050_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member-ordinal
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36051_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36052_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member-occurrences
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36054_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member-ordinal-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36055_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36056_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member-occurrences-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36058_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-member-ordinal
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36059_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-member-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36060_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-member-occurrences
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36062_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-member-ordinal-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36063_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-member-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36064_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-member-occurrences-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36066_|
    (##structure
     gx#syntax-quote::t
     'provider-row-witness::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36068_|
    (##structure
     gx#syntax-quote::t
     'make-provider-row-witness
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36070_|
    (##structure
     gx#syntax-quote::t
     'provider-row-witness?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36072_|
    (##structure
     gx#syntax-quote::t
     'provider-row-witness-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36073_|
    (##structure
     gx#syntax-quote::t
     'provider-row-witness-counts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36075_|
    (##structure
     gx#syntax-quote::t
     'provider-row-witness-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36076_|
    (##structure
     gx#syntax-quote::t
     'provider-row-witness-counts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36078_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-witness-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36079_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-witness-counts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36081_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-witness-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36082_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-witness-counts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36084_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36086_|
    (##structure
     gx#syntax-quote::t
     'make-physical-index-entry
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36088_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36090_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-version
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36091_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-lookup
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36092_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-shared?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36093_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-witness
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36095_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-version-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36096_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-lookup-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36097_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-shared?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36098_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-witness-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36100_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-version
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36101_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-lookup
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36102_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-shared?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36103_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-witness
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36105_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-version-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36106_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-lookup-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36107_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-shared?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36108_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-witness-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36110_|
    (##structure
     gx#syntax-quote::t
     'atom-index-view::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36112_|
    (##structure
     gx#syntax-quote::t
     'make-atom-index-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36114_|
    (##structure
     gx#syntax-quote::t
     'atom-index-view?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36116_|
    (##structure
     gx#syntax-quote::t
     'atom-index-view-entry
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36117_|
    (##structure
     gx#syntax-quote::t
     'atom-index-view-permutation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36119_|
    (##structure
     gx#syntax-quote::t
     'atom-index-view-entry-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36120_|
    (##structure
     gx#syntax-quote::t
     'atom-index-view-permutation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36122_|
    (##structure
     gx#syntax-quote::t
     '&atom-index-view-entry
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36123_|
    (##structure
     gx#syntax-quote::t
     '&atom-index-view-permutation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36125_|
    (##structure
     gx#syntax-quote::t
     '&atom-index-view-entry-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36126_|
    (##structure
     gx#syntax-quote::t
     '&atom-index-view-permutation-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/index[:0:]#row-indexes|
      (let ((__obj35632
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35632
           'gerbil-ascent/program/index#row-indexes::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35632 'row-indexes '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35632
           '(rows advance! plan! visit-parts)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35632
           '(rows advance! plan! visit-parts)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35632 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35632 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35632 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35632 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35632 '#f '13 '#f '#f))
        (let ((__tmp36017 |gerbil-ascent/program/index[1]#_g36018_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35632 __tmp36017 '4 '#f '#f))
        (let ((__tmp36019 |gerbil-ascent/program/index[1]#_g36020_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35632 __tmp36019 '14 '#f '#f))
        (let ((__tmp36021 |gerbil-ascent/program/index[1]#_g36022_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35632 __tmp36021 '15 '#f '#f))
        (let ((__tmp36023
               (cons (cons 'rows |gerbil-ascent/program/index[1]#_g36024_|)
                     (cons (cons 'advance!
                                 |gerbil-ascent/program/index[1]#_g36025_|)
                           (cons (cons 'plan!
                                       |gerbil-ascent/program/index[1]#_g36026_|)
                                 (cons (cons 'visit-parts
                                             |gerbil-ascent/program/index[1]#_g36027_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35632 __tmp36023 '16 '#f '#f))
        (let ((__tmp36028
               (cons (cons 'rows |gerbil-ascent/program/index[1]#_g36029_|)
                     (cons (cons 'advance!
                                 |gerbil-ascent/program/index[1]#_g36030_|)
                           (cons (cons 'plan!
                                       |gerbil-ascent/program/index[1]#_g36031_|)
                                 (cons (cons 'visit-parts
                                             |gerbil-ascent/program/index[1]#_g36032_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35632 __tmp36028 '17 '#f '#f))
        (let ((__tmp36033
               (cons (cons 'rows |gerbil-ascent/program/index[1]#_g36034_|)
                     (cons (cons 'advance!
                                 |gerbil-ascent/program/index[1]#_g36035_|)
                           (cons (cons 'plan!
                                       |gerbil-ascent/program/index[1]#_g36036_|)
                                 (cons (cons 'visit-parts
                                             |gerbil-ascent/program/index[1]#_g36037_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35632 __tmp36033 '18 '#f '#f))
        (let ((__tmp36038
               (cons (cons 'rows |gerbil-ascent/program/index[1]#_g36039_|)
                     (cons (cons 'advance!
                                 |gerbil-ascent/program/index[1]#_g36040_|)
                           (cons (cons 'plan!
                                       |gerbil-ascent/program/index[1]#_g36041_|)
                                 (cons (cons 'visit-parts
                                             |gerbil-ascent/program/index[1]#_g36042_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35632 __tmp36038 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35632 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35632 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35632 '() '21 '#f '#f))
        __obj35632))
    (define |gerbil-ascent/program/index[:0:]#provider-row-member|
      (let ((__obj35633
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35633
           'gerbil-ascent/program/index#provider-row-member::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35633
           'provider-row-member
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35633
           '(ordinal key occurrences)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35633
           '(ordinal key occurrences)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35633 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35633 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35633 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35633 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35633 '#f '13 '#f '#f))
        (let ((__tmp36043 |gerbil-ascent/program/index[1]#_g36044_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35633 __tmp36043 '4 '#f '#f))
        (let ((__tmp36045 |gerbil-ascent/program/index[1]#_g36046_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35633 __tmp36045 '14 '#f '#f))
        (let ((__tmp36047 |gerbil-ascent/program/index[1]#_g36048_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35633 __tmp36047 '15 '#f '#f))
        (let ((__tmp36049
               (cons (cons 'ordinal |gerbil-ascent/program/index[1]#_g36050_|)
                     (cons (cons 'key
                                 |gerbil-ascent/program/index[1]#_g36051_|)
                           (cons (cons 'occurrences
                                       |gerbil-ascent/program/index[1]#_g36052_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35633 __tmp36049 '16 '#f '#f))
        (let ((__tmp36053
               (cons (cons 'ordinal |gerbil-ascent/program/index[1]#_g36054_|)
                     (cons (cons 'key
                                 |gerbil-ascent/program/index[1]#_g36055_|)
                           (cons (cons 'occurrences
                                       |gerbil-ascent/program/index[1]#_g36056_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35633 __tmp36053 '17 '#f '#f))
        (let ((__tmp36057
               (cons (cons 'ordinal |gerbil-ascent/program/index[1]#_g36058_|)
                     (cons (cons 'key
                                 |gerbil-ascent/program/index[1]#_g36059_|)
                           (cons (cons 'occurrences
                                       |gerbil-ascent/program/index[1]#_g36060_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35633 __tmp36057 '18 '#f '#f))
        (let ((__tmp36061
               (cons (cons 'ordinal |gerbil-ascent/program/index[1]#_g36062_|)
                     (cons (cons 'key
                                 |gerbil-ascent/program/index[1]#_g36063_|)
                           (cons (cons 'occurrences
                                       |gerbil-ascent/program/index[1]#_g36064_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35633 __tmp36061 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35633 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35633 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35633 '() '21 '#f '#f))
        __obj35633))
    (define |gerbil-ascent/program/index[:0:]#provider-row-witness|
      (let ((__obj35634
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35634
           'gerbil-ascent/program/index#provider-row-witness::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35634
           'provider-row-witness
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 '(members counts) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 '(members counts) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 '#f '13 '#f '#f))
        (let ((__tmp36065 |gerbil-ascent/program/index[1]#_g36066_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 __tmp36065 '4 '#f '#f))
        (let ((__tmp36067 |gerbil-ascent/program/index[1]#_g36068_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 __tmp36067 '14 '#f '#f))
        (let ((__tmp36069 |gerbil-ascent/program/index[1]#_g36070_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 __tmp36069 '15 '#f '#f))
        (let ((__tmp36071
               (cons (cons 'members |gerbil-ascent/program/index[1]#_g36072_|)
                     (cons (cons 'counts
                                 |gerbil-ascent/program/index[1]#_g36073_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 __tmp36071 '16 '#f '#f))
        (let ((__tmp36074
               (cons (cons 'members |gerbil-ascent/program/index[1]#_g36075_|)
                     (cons (cons 'counts
                                 |gerbil-ascent/program/index[1]#_g36076_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 __tmp36074 '17 '#f '#f))
        (let ((__tmp36077
               (cons (cons 'members |gerbil-ascent/program/index[1]#_g36078_|)
                     (cons (cons 'counts
                                 |gerbil-ascent/program/index[1]#_g36079_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 __tmp36077 '18 '#f '#f))
        (let ((__tmp36080
               (cons (cons 'members |gerbil-ascent/program/index[1]#_g36081_|)
                     (cons (cons 'counts
                                 |gerbil-ascent/program/index[1]#_g36082_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 __tmp36080 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35634 '() '21 '#f '#f))
        __obj35634))
    (define |gerbil-ascent/program/index[:0:]#physical-index-entry|
      (let ((__obj35635
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35635
           'gerbil-ascent/program/index#physical-index-entry::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35635
           'physical-index-entry
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35635
           '(version lookup shared? witness)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35635
           '(version lookup shared? witness)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35635 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35635 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35635 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35635 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35635 '#f '13 '#f '#f))
        (let ((__tmp36083 |gerbil-ascent/program/index[1]#_g36084_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35635 __tmp36083 '4 '#f '#f))
        (let ((__tmp36085 |gerbil-ascent/program/index[1]#_g36086_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35635 __tmp36085 '14 '#f '#f))
        (let ((__tmp36087 |gerbil-ascent/program/index[1]#_g36088_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35635 __tmp36087 '15 '#f '#f))
        (let ((__tmp36089
               (cons (cons 'version |gerbil-ascent/program/index[1]#_g36090_|)
                     (cons (cons 'lookup
                                 |gerbil-ascent/program/index[1]#_g36091_|)
                           (cons (cons 'shared?
                                       |gerbil-ascent/program/index[1]#_g36092_|)
                                 (cons (cons 'witness
                                             |gerbil-ascent/program/index[1]#_g36093_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35635 __tmp36089 '16 '#f '#f))
        (let ((__tmp36094
               (cons (cons 'version |gerbil-ascent/program/index[1]#_g36095_|)
                     (cons (cons 'lookup
                                 |gerbil-ascent/program/index[1]#_g36096_|)
                           (cons (cons 'shared?
                                       |gerbil-ascent/program/index[1]#_g36097_|)
                                 (cons (cons 'witness
                                             |gerbil-ascent/program/index[1]#_g36098_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35635 __tmp36094 '17 '#f '#f))
        (let ((__tmp36099
               (cons (cons 'version |gerbil-ascent/program/index[1]#_g36100_|)
                     (cons (cons 'lookup
                                 |gerbil-ascent/program/index[1]#_g36101_|)
                           (cons (cons 'shared?
                                       |gerbil-ascent/program/index[1]#_g36102_|)
                                 (cons (cons 'witness
                                             |gerbil-ascent/program/index[1]#_g36103_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35635 __tmp36099 '18 '#f '#f))
        (let ((__tmp36104
               (cons (cons 'version |gerbil-ascent/program/index[1]#_g36105_|)
                     (cons (cons 'lookup
                                 |gerbil-ascent/program/index[1]#_g36106_|)
                           (cons (cons 'shared?
                                       |gerbil-ascent/program/index[1]#_g36107_|)
                                 (cons (cons 'witness
                                             |gerbil-ascent/program/index[1]#_g36108_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35635 __tmp36104 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35635 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35635 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35635 '() '21 '#f '#f))
        __obj35635))
    (define |gerbil-ascent/program/index[:0:]#atom-index-view|
      (let ((__obj35636
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35636
           'gerbil-ascent/program/index#atom-index-view::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35636 'atom-index-view '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35636
           '(entry permutation)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35636
           '(entry permutation)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35636 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35636 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35636 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35636 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35636 '#f '13 '#f '#f))
        (let ((__tmp36109 |gerbil-ascent/program/index[1]#_g36110_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35636 __tmp36109 '4 '#f '#f))
        (let ((__tmp36111 |gerbil-ascent/program/index[1]#_g36112_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35636 __tmp36111 '14 '#f '#f))
        (let ((__tmp36113 |gerbil-ascent/program/index[1]#_g36114_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35636 __tmp36113 '15 '#f '#f))
        (let ((__tmp36115
               (cons (cons 'entry |gerbil-ascent/program/index[1]#_g36116_|)
                     (cons (cons 'permutation
                                 |gerbil-ascent/program/index[1]#_g36117_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35636 __tmp36115 '16 '#f '#f))
        (let ((__tmp36118
               (cons (cons 'entry |gerbil-ascent/program/index[1]#_g36119_|)
                     (cons (cons 'permutation
                                 |gerbil-ascent/program/index[1]#_g36120_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35636 __tmp36118 '17 '#f '#f))
        (let ((__tmp36121
               (cons (cons 'entry |gerbil-ascent/program/index[1]#_g36122_|)
                     (cons (cons 'permutation
                                 |gerbil-ascent/program/index[1]#_g36123_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35636 __tmp36121 '18 '#f '#f))
        (let ((__tmp36124
               (cons (cons 'entry |gerbil-ascent/program/index[1]#_g36125_|)
                     (cons (cons 'permutation
                                 |gerbil-ascent/program/index[1]#_g36126_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35636 __tmp36124 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35636 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35636 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35636 '() '21 '#f '#f))
        __obj35636))))
