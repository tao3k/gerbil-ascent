(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/trrel[1]#_g34815_|
    (##structure
     gx#syntax-quote::t
     'trrel-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34817_|
    (##structure
     gx#syntax-quote::t
     'make-trrel-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34819_|
    (##structure
     gx#syntax-quote::t
     'trrel-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34821_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-known
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34822_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34823_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-successors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34825_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-known-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34826_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34827_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-successors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34829_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-known
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34830_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34831_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-successors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34833_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-known-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34834_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34835_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-successors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[:0:]#trrel-state|
    (let ((__obj34711
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34711
         'gerbil-ascent/table/trrel#trrel-state::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34711 'trrel-state '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34711
         '(known predecessors successors)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34711
         '(known predecessors successors)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34711 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34711 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34711 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34711 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34711 '#f '13 '#f '#f))
      (let ((__tmp34814 |gerbil-ascent/table/trrel[1]#_g34815_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34711 __tmp34814 '4 '#f '#f))
      (let ((__tmp34816 |gerbil-ascent/table/trrel[1]#_g34817_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34711 __tmp34816 '14 '#f '#f))
      (let ((__tmp34818 |gerbil-ascent/table/trrel[1]#_g34819_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34711 __tmp34818 '15 '#f '#f))
      (let ((__tmp34820
             (cons (cons 'known |gerbil-ascent/table/trrel[1]#_g34821_|)
                   (cons (cons 'predecessors
                               |gerbil-ascent/table/trrel[1]#_g34822_|)
                         (cons (cons 'successors
                                     |gerbil-ascent/table/trrel[1]#_g34823_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34711 __tmp34820 '16 '#f '#f))
      (let ((__tmp34824
             (cons (cons 'known |gerbil-ascent/table/trrel[1]#_g34825_|)
                   (cons (cons 'predecessors
                               |gerbil-ascent/table/trrel[1]#_g34826_|)
                         (cons (cons 'successors
                                     |gerbil-ascent/table/trrel[1]#_g34827_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34711 __tmp34824 '17 '#f '#f))
      (let ((__tmp34828
             (cons (cons 'known |gerbil-ascent/table/trrel[1]#_g34829_|)
                   (cons (cons 'predecessors
                               |gerbil-ascent/table/trrel[1]#_g34830_|)
                         (cons (cons 'successors
                                     |gerbil-ascent/table/trrel[1]#_g34831_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34711 __tmp34828 '18 '#f '#f))
      (let ((__tmp34832
             (cons (cons 'known |gerbil-ascent/table/trrel[1]#_g34833_|)
                   (cons (cons 'predecessors
                               |gerbil-ascent/table/trrel[1]#_g34834_|)
                         (cons (cons 'successors
                                     |gerbil-ascent/table/trrel[1]#_g34835_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34711 __tmp34832 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34711 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34711 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34711 '() '21 '#f '#f))
      __obj34711)))
