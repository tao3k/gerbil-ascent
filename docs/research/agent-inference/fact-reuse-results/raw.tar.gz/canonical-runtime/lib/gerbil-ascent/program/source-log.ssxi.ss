prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/program

(begin
  (declare-type
   gerbil-ascent/program/source-log#gerbil-ascent-source-log-rows
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/source-log)))
  (declare-type
   gerbil-ascent/program/source-log#gerbil-ascent-source-log-equal?
   (@lambda 3
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/source-log))))
