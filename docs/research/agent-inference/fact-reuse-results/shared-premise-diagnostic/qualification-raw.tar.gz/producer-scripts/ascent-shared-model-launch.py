import os,sys,subprocess
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'python/src'))
from ascent_test_support.movie_study import provider_key
env=os.environ.copy();env['DEEPSEEK_API_KEY']=provider_key()
source=root/'.cache/ascent/shared-premise/source-snapshot'
env['PYTHONPATH']=str(source/'python/src')+':'+str(root/'.cache/ascent/shared-premise/snapshot-api')
env['UV_CACHE_DIR']=str(root/'.cache/ascent/shared-premise/uv-cache')
mode=sys.argv[1];assert mode in ('shared-live','shared-label','shared-report','shared-check','shared-committed-check')
cmd=['uv','run','--project',str(source/'python'),'--locked','--offline','python','-m','ascent_test_support.evidence_chain_study',mode,str(root/'.cache/ascent/shared-premise/final-frozen'),str(root/'.cache/ascent/shared-premise/model-run')]
raise SystemExit(subprocess.call(cmd,env=env))
