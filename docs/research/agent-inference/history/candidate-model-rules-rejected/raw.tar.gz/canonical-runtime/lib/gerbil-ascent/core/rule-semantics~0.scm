(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/core/rule-semantics::timestamp 1791687876)
  (begin
    (define gerbil-ascent/core/rule-semantics#rule-read::t
      (let ((__tmp34844 (list))
            (__tmp34843
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/core/rule-semantics#rule-read::t
         'rule-read
         __tmp34844
         '(kind source)
         __tmp34843
         '#f)))
    (define gerbil-ascent/core/rule-semantics#rule-read?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/core/rule-semantics#rule-read::t)))
    (define gerbil-ascent/core/rule-semantics#make-rule-read
      (lambda _%$args8028%_
        (apply make-instance
               gerbil-ascent/core/rule-semantics#rule-read::t
               _%$args8028%_)))
    (define gerbil-ascent/core/rule-semantics#rule-read-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/rule-semantics#rule-read::t
         'kind)))
    (define gerbil-ascent/core/rule-semantics#rule-read-source
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/rule-semantics#rule-read::t
         'source)))
    (define gerbil-ascent/core/rule-semantics#rule-read-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/rule-semantics#rule-read::t
         'kind)))
    (define gerbil-ascent/core/rule-semantics#rule-read-source-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/rule-semantics#rule-read::t
         'source)))
    (define gerbil-ascent/core/rule-semantics#&rule-read-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/rule-semantics#rule-read::t
         'kind)))
    (define gerbil-ascent/core/rule-semantics#&rule-read-source
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/rule-semantics#rule-read::t
         'source)))
    (define gerbil-ascent/core/rule-semantics#&rule-read-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/rule-semantics#rule-read::t
         'kind)))
    (define gerbil-ascent/core/rule-semantics#&rule-read-source-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/rule-semantics#rule-read::t
         'source)))
    (define gerbil-ascent/core/rule-semantics#prepare-rule-reads
      (lambda (_%body7854%_)
        (let* ((_%head7856%_ (cons '#f '())) (_%tail7859%_ _%head7856%_))
          (for-each
           (lambda (_%clause8018%_)
             (let ((_%kind8021%_ (vector-ref _%clause8018%_ '0)))
               (if (let ()
                     (declare (not safe))
                     (##memq _%kind8021%_ '(atom negation aggregate)))
                   (let* ((_%source8023%_
                           (vector-ref (vector-ref _%clause8018%_ '1) '0))
                          (_%new-tail8025%_
                           (cons (let ()
                                   (declare (not safe))
                                   (##structure
                                    gerbil-ascent/core/rule-semantics#rule-read::t
                                    _%kind8021%_
                                    _%source8023%_))
                                 '())))
                     (let ()
                       (declare (not safe))
                       (##set-cdr! _%tail7859%_ _%new-tail8025%_))
                     (set! _%tail7859%_ _%new-tail8025%_))
                   '#!void)))
           _%body7854%_)
          (let () (declare (not safe)) (##cdr _%head7856%_)))))
    (define gerbil-ascent/core/rule-semantics#gerbil-ascent-rule-successors
      (lambda (_%plans7836%_ _%count7837%_)
        (let ((_%successors7839%_ (make-vector _%count7837%_ '())))
          (for-each
           (lambda (_%rule7841%_)
             (let ((_%heads7843%_ (vector-ref _%rule7841%_ '0)))
               (for-each
                (lambda (_%clause7845%_)
                  (let ((_%kind7848%_ (vector-ref _%clause7845%_ '0)))
                    (if (let ()
                          (declare (not safe))
                          (##memq _%kind7848%_ '(atom negation aggregate)))
                        (let ((_%source7850%_
                               (vector-ref (vector-ref _%clause7845%_ '1) '0)))
                          (for-each
                           (lambda (_%head7852%_)
                             (vector-set!
                              _%successors7839%_
                              _%source7850%_
                              (cons (vector-ref _%head7852%_ '0)
                                    (vector-ref
                                     _%successors7839%_
                                     _%source7850%_))))
                           _%heads7843%_))
                        '#!void)))
                (vector-ref _%rule7841%_ '1))))
           _%plans7836%_)
          _%successors7839%_)))
    (define gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-key
      (lambda (_%row7834%_)
        (if (pair? _%row7834%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT lattice row" _%row7834%_)))
        (let () (declare (not safe)) (std/list/list#butlast _%row7834%_))))
    (define gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-value
      (lambda (_%row7832%_) (last _%row7832%_)))
    (define gerbil-ascent/core/rule-semantics#gerbil-ascent-joined-row
      (lambda (_%key7829%_ _%value7830%_)
        (let ((__tmp34845 (list _%value7830%_)))
          (declare (not safe))
          (##append _%key7829%_ __tmp34845))))
    (define gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-feeds-relation?
      (lambda (_%rule-plans7820%_ _%kinds7821%_)
        (let ((__tmp34846
               (lambda (_%rule7823%_)
                 (if (let ((__tmp34848
                            (lambda (_%head7825%_)
                              (eq? (vector-ref
                                    _%kinds7821%_
                                    (vector-ref _%head7825%_ '0))
                                   'relation)))
                           (__tmp34847 (vector-ref _%rule7823%_ '0)))
                       (declare (not safe))
                       (ormap__0 __tmp34848 __tmp34847))
                     (let ((__tmp34850
                            (lambda (_%clause7827%_)
                              (if (eq? (vector-ref _%clause7827%_ '0) 'atom)
                                  (eq? (vector-ref
                                        _%kinds7821%_
                                        (vector-ref
                                         (vector-ref _%clause7827%_ '1)
                                         '0))
                                       'lattice)
                                  '#f)))
                           (__tmp34849 (vector-ref _%rule7823%_ '1)))
                       (declare (not safe))
                       (ormap__0 __tmp34850 __tmp34849))
                     '#f))))
          (declare (not safe))
          (ormap__0 __tmp34846 _%rule-plans7820%_))))
    (define gerbil-ascent/core/rule-semantics#gerbil-ascent-rule-strata
      (lambda (_%rule-plans7736%_ _%relation-count7737%_ _%kinds7738%_)
        (let ((_%strata7740%_ (make-vector _%relation-count7737%_ '0))
              (_%dependencies7741%_ '()))
          (if (or (let ((__tmp34851
                         (lambda (_%rule7743%_)
                           (let ((__tmp34853
                                  (lambda (_%clause7745%_)
                                    (let ((__tmp34854
                                           (vector-ref _%clause7745%_ '0)))
                                      (declare (not safe))
                                      (##memq __tmp34854
                                              '(negation aggregate)))))
                                 (__tmp34852 (vector-ref _%rule7743%_ '1)))
                             (declare (not safe))
                             (ormap__0 __tmp34853 __tmp34852)))))
                    (declare (not safe))
                    (ormap__0 __tmp34851 _%rule-plans7736%_))
                  (gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-feeds-relation?
                   _%rule-plans7736%_
                   _%kinds7738%_))
              (begin
                (for-each
                 (lambda (_%rule7750%_)
                   (let ((_%heads7752%_ (vector-ref _%rule7750%_ '0))
                         (_%reads7753%_
                          (gerbil-ascent/core/rule-semantics#prepare-rule-reads
                           (vector-ref _%rule7750%_ '1))))
                     (for-each
                      (lambda (_%head7755%_)
                        (letrec* ((_%head-index7757%_
                                   (vector-ref _%head7755%_ '0)))
                          (for-each
                           (lambda (_%read7759%_)
                             (let* ((_%read7761%_ _%read7759%_)
                                    (_%lattice-projection?7774%_
                                     (if (eq? (let ()
                                                (declare (not safe))
                                                (##unchecked-structure-ref
                                                 _%read7761%_
                                                 '1
                                                 '#f
                                                 '#f))
                                              'atom)
                                         (if (eq? (vector-ref
                                                   _%kinds7738%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%read7761%_
                                                      '2
                                                      '#f
                                                      '#f)))
                                                  'lattice)
                                             (eq? (vector-ref
                                                   _%kinds7738%_
                                                   _%head-index7757%_)
                                                  'relation)
                                             '#f)
                                         '#f))
                                    (_%strict?7779%_
                                     (let ((_%$e7776%_
                                            (not (eq? (let ()
                                                        (declare (not safe))
                                                        (##unchecked-structure-ref
                                                         _%read7761%_
                                                         '1
                                                         '#f
                                                         '#f))
                                                      'atom))))
                                       (if _%$e7776%_
                                           _%$e7776%_
                                           _%lattice-projection?7774%_))))
                               (set! _%dependencies7741%_
                                     (cons (vector _%head-index7757%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%read7761%_
                                                      '2
                                                      '#f
                                                      '#f))
                                                   (if _%strict?7779%_ '1 '0)
                                                   (if _%lattice-projection?7774%_
                                                       'lattice-projection
                                                       (let ()
                                                         (declare (not safe))
                                                         (##unchecked-structure-ref
                                                          _%read7761%_
                                                          '1
                                                          '#f
                                                          '#f))))
                                           _%dependencies7741%_))))
                           _%reads7753%_)))
                      _%heads7752%_)))
                 _%rule-plans7736%_)
                (let ((_%successors7782%_
                       (make-vector _%relation-count7737%_ '()))
                      (_%outgoing7783%_
                       (make-vector _%relation-count7737%_ '()))
                      (_%component-of7784%_
                       (make-vector _%relation-count7737%_ '#f)))
                  (let ((__tmp34855
                         (lambda (_%dependency7786%_)
                           (let ((_%head7788%_
                                  (vector-ref _%dependency7786%_ '0))
                                 (_%body7789%_
                                  (vector-ref _%dependency7786%_ '1)))
                             (vector-set!
                              _%successors7782%_
                              _%body7789%_
                              (cons _%head7788%_
                                    (vector-ref
                                     _%successors7782%_
                                     _%body7789%_)))
                             (vector-set!
                              _%outgoing7783%_
                              _%body7789%_
                              (cons _%dependency7786%_
                                    (vector-ref
                                     _%outgoing7783%_
                                     _%body7789%_)))))))
                    (declare (not safe))
                    (##for-each __tmp34855 _%dependencies7741%_))
                  (let ((_%components7791%_
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/core/dependency-graph#gerbil-ascent-graph-components
                            _%successors7782%_))))
                    (let ((__tmp34856
                           (lambda (_%members7793%_)
                             (for-each
                              (lambda (_%node7795%_)
                                (vector-set!
                                 _%component-of7784%_
                                 _%node7795%_
                                 _%members7793%_))
                              _%members7793%_))))
                      (declare (not safe))
                      (##for-each __tmp34856 _%components7791%_))
                    (let ((__tmp34857
                           (lambda (_%dependency7797%_)
                             (if (and (= (vector-ref _%dependency7797%_ '2) '1)
                                      (eq? (vector-ref
                                            _%component-of7784%_
                                            (vector-ref _%dependency7797%_ '0))
                                           (vector-ref
                                            _%component-of7784%_
                                            (vector-ref
                                             _%dependency7797%_
                                             '1))))
                                 (let ((_%$e7799%_
                                        (vector-ref _%dependency7797%_ '3)))
                                   (if (eq? 'aggregate _%$e7799%_)
                                       (let ()
                                         (declare (not safe))
                                         (error '"unstratifiable ASCENT aggregate cycle"))
                                       (if (eq? 'negation _%$e7799%_)
                                           (let ()
                                             (declare (not safe))
                                             (error '"unstratifiable ASCENT negation cycle"))
                                           (if (eq? 'lattice-projection
                                                    _%$e7799%_)
                                               (let ()
                                                 (declare (not safe))
                                                 (error '"unstratifiable ASCENT lattice projection cycle"))
                                               (let ()
                                                 (declare (not safe))
                                                 (error '"unstratifiable ASCENT dependency cycle"))))))
                                 '#!void))))
                      (declare (not safe))
                      (##for-each __tmp34857 _%dependencies7741%_))
                    (let ((__tmp34858
                           (lambda (_%members7802%_)
                             (let ((_%stratum7807%_
                                    (let ((__tmp34859
                                           (lambda (_%node7804%_ _%prior7805%_)
                                             (max _%prior7805%_
                                                  (vector-ref
                                                   _%strata7740%_
                                                   _%node7804%_)))))
                                      (declare (not safe))
                                      (foldl__0
                                       __tmp34859
                                       '0
                                       _%members7802%_))))
                               (for-each
                                (lambda (_%node7809%_)
                                  (vector-set!
                                   _%strata7740%_
                                   _%node7809%_
                                   _%stratum7807%_))
                                _%members7802%_)
                               (for-each
                                (lambda (_%node7811%_)
                                  (for-each
                                   (lambda (_%dependency7813%_)
                                     (let* ((_%head7815%_
                                             (vector-ref
                                              _%dependency7813%_
                                              '0))
                                            (_%required7817%_
                                             (+ _%stratum7807%_
                                                (vector-ref
                                                 _%dependency7813%_
                                                 '2))))
                                       (vector-set!
                                        _%strata7740%_
                                        _%head7815%_
                                        (max (vector-ref
                                              _%strata7740%_
                                              _%head7815%_)
                                             _%required7817%_))))
                                   (vector-ref _%outgoing7783%_ _%node7811%_)))
                                _%members7802%_)))))
                      (declare (not safe))
                      (##for-each __tmp34858 _%components7791%_)))))
              '#!void)
          _%strata7740%_)))
    (define gerbil-ascent/core/rule-semantics#gerbil-ascent-delta-positions
      (lambda (_%body7724%_ _%strata7725%_ _%stratum7726%_)
        (let _%loop7728%_ ((_%remaining7730%_ _%body7724%_)
                           (_%depth7731%_ '0)
                           (_%selected7732%_ '()))
          (if (null? _%remaining7730%_)
              (reverse _%selected7732%_)
              (let ((_%clause7734%_ (car _%remaining7730%_)))
                (if (eq? (vector-ref _%clause7734%_ '0) 'atom)
                    (_%loop7728%_
                     (cdr _%remaining7730%_)
                     (+ _%depth7731%_ '1)
                     (if (= (vector-ref
                             _%strata7725%_
                             (vector-ref (vector-ref _%clause7734%_ '1) '0))
                            _%stratum7726%_)
                         (cons _%depth7731%_ _%selected7732%_)
                         _%selected7732%_))
                    (_%loop7728%_
                     (cdr _%remaining7730%_)
                     _%depth7731%_
                     _%selected7732%_)))))))))
