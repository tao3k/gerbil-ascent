(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(define |gerbil-ascent/program/aggregators[:0:]#with-single-column|
  (lambda (_%$stx9897%_)
    (let* ((_%$%g99019929%_
            (lambda (_%$%g99029925%_)
              (let ()
                (declare (not safe))
                (gx#raise-syntax-error
                 '#f
                 '"Bad syntax; invalid match target"
                 _%$%g99029925%_))))
           (_%$%g990010027%_
            (lambda (_%$%g99029933%_)
              (if (let () (declare (not safe)) (gx#stx-pair? _%$%g99029933%_))
                  (let ((_%$%e99069936%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%$%g99029933%_))))
                    (let ((_%$%hd99079940%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e99069936%_)))
                          (_%$%tl99089943%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e99069936%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl99089943%_))
                          (let ((_%$%e99099946%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl99089943%_))))
                            (let ((_%$%hd99109950%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e99099946%_)))
                                  (_%$%tl99119953%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e99099946%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%tl99119953%_))
                                  (let ((_%$%e99129956%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%tl99119953%_))))
                                    (let ((_%$%hd99139960%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e99129956%_)))
                                          (_%$%tl99149963%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e99129956%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair/null?
                                             _%$%tl99149963%_))
                                          (let ((_g33590_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-split-splice
                                                    _%$%tl99149963%_
                                                    '0))))
                                            (begin
                                              (let ((_g33591_
                                                     (let ()
                                                       (declare (not safe))
                                                       (if (##values? _g33590_)
                                                           (##values-length
                                                            _g33590_)
                                                           1))))
                                                (if (not (let ()
                                                           (declare (not safe))
                                                           (##fx= _g33591_ 2)))
                                                    (error "Context expects 2 values"
                                                           _g33591_)))
                                              (let ((_%$%target99159966%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##values-ref
                                                        _g33590_
                                                        0)))
                                                    (_%$%tl99179969%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##values-ref
                                                        _g33590_
                                                        1))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl99179969%_))
                                                    (letrec ((_%$%loop99189972%_
                                                              (lambda (_%$%hd99169976%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               _%$%body99229979%_)
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair? _%$%hd99169976%_))
                            (let ((_%$%e99199981%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-e _%$%hd99169976%_))))
                              (let ((_%$%lp-hd99209985%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e99199981%_)))
                                    (_%$%lp-tl99219988%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e99199981%_))))
                                (_%$%loop99189972%_
                                 _%$%lp-tl99219988%_
                                 (cons _%$%lp-hd99209985%_
                                       _%$%body99229979%_))))
                            (let ((_%$%body99239991%_
                                   (reverse _%$%body99229979%_)))
                              (cons (let ()
                                      (declare (not safe))
                                      (gx#datum->syntax__0 '#f 'let))
                                    (cons (cons _%$%hd99139960%_
                                                (cons _%$%hd99109950%_ '()))
                                          (cons (cons (let ()
                                                        (declare (not safe))
                                                        (gx#datum->syntax__0
                                                         '#f
                                                         'for-each))
                                                      (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'single-column-value))
                                                            (cons _%$%hd99139960%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (let ((__tmp33592
                                                       (lambda (_%$%g1001810021%_
                                                                _%$%g1001910024%_)
                                                         (cons _%$%g1001810021%_
                                                               _%$%g1001910024%_))))
                                                  (declare (not safe))
                                                  (foldr__0
                                                   __tmp33592
                                                   '()
                                                   _%$%body99239991%_))))))))))
              (_%$%loop99189972%_ _%$%target99159966%_ '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%g99019929%_
                                                     _%$%g99029933%_)))))
                                          (_%$%g99019929%_ _%$%g99029933%_))))
                                  (_%$%g99019929%_ _%$%g99029933%_))))
                          (_%$%g99019929%_ _%$%g99029933%_))))
                  (_%$%g99019929%_ _%$%g99029933%_)))))
      (_%$%g990010027%_ _%$stx9897%_))))
