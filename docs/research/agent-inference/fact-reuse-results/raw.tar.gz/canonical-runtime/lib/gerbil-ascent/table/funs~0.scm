(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/funs::timestamp 1791690983)
  (begin
    (define gerbil-ascent/table/funs#gerbil-ascent-index-row-snapshot
      (lambda (_%rows4120%_)
        (map (lambda (_%row4122%_) (map values _%row4122%_)) _%rows4120%_)))
    (define gerbil-ascent/table/funs#gerbil-ascent-index-row-snapshot/arity
      (lambda (_%rows4073%_ _%width4074%_)
        (letrec ((_%wrong-arity4076%_
                  (lambda ()
                    (let ()
                      (declare (not safe))
                      (error '"ASCENT index provider returned wrong row arity"
                             _%width4074%_))))
                 (_%copy4077%_
                  (lambda (_%row4083%_ _%left4084%_)
                    (if (zero? _%left4084%_)
                        (if (null? _%row4083%_) '() (_%wrong-arity4076%_))
                        (let* ((_%$%row40854093%_ _%row4083%_)
                               (_%$%else40874101%_
                                (lambda () (_%wrong-arity4076%_)))
                               (_%$%K40894107%_
                                (lambda (_%rest4104%_ _%value4105%_)
                                  (cons _%value4105%_
                                        (_%copy4077%_
                                         _%rest4104%_
                                         (- _%left4084%_ '1))))))
                          (if (pair? _%$%row40854093%_)
                              (let ((_%$%hd40904110%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%row40854093%_)))
                                    (_%$%tl40914112%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%row40854093%_))))
                                (let* ((_%value4115%_ _%$%hd40904110%_)
                                       (_%rest4117%_ _%$%tl40914112%_))
                                  (_%$%K40894107%_
                                   _%rest4117%_
                                   _%value4115%_)))
                              (_%wrong-arity4076%_)))))))
          (map (lambda (_%$%g40784080%_)
                 (_%copy4077%_ _%$%g40784080%_ _%width4074%_))
               _%rows4073%_))))
    (define gerbil-ascent/table/funs#gerbil-ascent-index-build
      (lambda (_%rows4068%_ _%columns4069%_)
        (let ((_%index4071%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (gerbil-ascent/table/funs#gerbil-ascent-index-extend!
           _%index4071%_
           _%rows4068%_
           _%columns4069%_)
          (gerbil-ascent/table/funs#gerbil-ascent-index-order!
           _%index4071%_))))
    (define gerbil-ascent/table/funs#gerbil-ascent-index-order!
      (lambda (_%index4063%_)
        (let ((__tmp33679
               (lambda (_%key4065%_ _%rows4066%_)
                 (if (pair? (cdr _%rows4066%_))
                     (let ((__tmp33680 (reverse! _%rows4066%_)))
                       (declare (not safe))
                       (hash-put! _%index4063%_ _%key4065%_ __tmp33680))
                     '#!void))))
          (declare (not safe))
          (hash-for-each __tmp33679 _%index4063%_))
        _%index4063%_))
    (define gerbil-ascent/table/funs#forward-column-steps
      (lambda (_%columns4013%_)
        (let _%step4015%_ ((_%remaining4017%_ _%columns4013%_)
                           (_%position4018%_ '0))
          (let* ((_%$%remaining40194028%_ _%remaining4017%_)
                 (_%$%E40224032%_
                  (lambda ()
                    (let ()
                      (declare (not safe))
                      (error '"No clause matching"
                             _%$%remaining40194028%_
                             '([])
                             '([column . rest])))
                    '#!void)))
            (let ((_%$%K40264060%_ (lambda () '()))
                  (_%$%K40234044%_
                   (lambda (_%rest4036%_ _%column4037%_)
                     (if (>= _%column4037%_ _%position4018%_)
                         (let ((_%$%steps40384040%_
                                (_%step4015%_ _%rest4036%_ _%column4037%_)))
                           (if _%$%steps40384040%_
                               (let ((_%steps4042%_ _%$%steps40384040%_))
                                 (cons (inexact->exact
                                        (- _%column4037%_ _%position4018%_))
                                       _%steps4042%_))
                               '#f))
                         '#f))))
              (let ((_%$%try-match40214056%_
                     (lambda ()
                       (if (pair? _%$%remaining40194028%_)
                           (let ((_%$%tl40254049%_
                                  (let ()
                                    (declare (not safe))
                                    (##cdr _%$%remaining40194028%_)))
                                 (_%$%hd40244047%_
                                  (let ()
                                    (declare (not safe))
                                    (##car _%$%remaining40194028%_))))
                             (let ((_%column4052%_ _%$%hd40244047%_)
                                   (_%rest4054%_ _%$%tl40254049%_))
                               (_%$%K40234044%_ _%rest4054%_ _%column4052%_)))
                           (_%$%E40224032%_)))))
                (if (null? _%$%remaining40194028%_)
                    (_%$%K40264060%_)
                    (_%$%try-match40214056%_))))))))
    (define gerbil-ascent/table/funs#nondecreasing-columns?
      (lambda (_%columns3968%_)
        (let _%ordered3970%_ ((_%remaining3972%_ _%columns3968%_)
                              (_%position3973%_ '0))
          (let* ((_%$%remaining39743983%_ _%remaining3972%_)
                 (_%$%E39773987%_
                  (lambda ()
                    (let ()
                      (declare (not safe))
                      (error '"No clause matching"
                             _%$%remaining39743983%_
                             '([])
                             '([column . rest])))
                    '#!void)))
            (let ((_%$%K39814010%_ (lambda () '#t))
                  (_%$%K39783994%_
                   (lambda (_%rest3991%_ _%column3992%_)
                     (if (>= _%column3992%_ _%position3973%_)
                         (_%ordered3970%_ _%rest3991%_ _%column3992%_)
                         '#f))))
              (let ((_%$%try-match39764006%_
                     (lambda ()
                       (if (pair? _%$%remaining39743983%_)
                           (let ((_%$%tl39803999%_
                                  (let ()
                                    (declare (not safe))
                                    (##cdr _%$%remaining39743983%_)))
                                 (_%$%hd39793997%_
                                  (let ()
                                    (declare (not safe))
                                    (##car _%$%remaining39743983%_))))
                             (let ((_%column4002%_ _%$%hd39793997%_)
                                   (_%rest4004%_ _%$%tl39803999%_))
                               (_%$%K39783994%_ _%rest4004%_ _%column4002%_)))
                           (_%$%E39773987%_)))))
                (if (null? _%$%remaining39743983%_)
                    (_%$%K39814010%_)
                    (_%$%try-match39764006%_))))))))
    (define gerbil-ascent/table/funs#stepped-key
      (lambda (_%row3925%_ _%steps3926%_)
        (let* ((_%$%steps39273936%_ _%steps3926%_)
               (_%$%E39303940%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%steps39273936%_
                           '([])
                           '([distance . rest])))
                  '#!void)))
          (let ((_%$%K39343965%_ (lambda () '()))
                (_%$%K39313949%_
                 (lambda (_%rest3944%_ _%distance3945%_)
                   (let ((_%selected3947%_
                          (list-tail _%row3925%_ _%distance3945%_)))
                     (cons (car _%selected3947%_)
                           (gerbil-ascent/table/funs#stepped-key
                            _%selected3947%_
                            _%rest3944%_))))))
            (let ((_%$%try-match39293961%_
                   (lambda ()
                     (if (pair? _%$%steps39273936%_)
                         (let ((_%$%tl39333954%_
                                (let ()
                                  (declare (not safe))
                                  (##cdr _%$%steps39273936%_)))
                               (_%$%hd39323952%_
                                (let ()
                                  (declare (not safe))
                                  (##car _%$%steps39273936%_))))
                           (let ((_%distance3957%_ _%$%hd39323952%_)
                                 (_%rest3959%_ _%$%tl39333954%_))
                             (_%$%K39313949%_ _%rest3959%_ _%distance3957%_)))
                         (_%$%E39303940%_)))))
              (if (null? _%$%steps39273936%_)
                  (_%$%K39343965%_)
                  (_%$%try-match39293961%_)))))))
    (define gerbil-ascent/table/funs#column-key
      (lambda (_%row3881%_ _%columns3882%_ _%position3883%_)
        (let* ((_%$%columns38843893%_ _%columns3882%_)
               (_%$%E38873897%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%columns38843893%_
                           '([])
                           '([column . rest])))
                  '#!void)))
          (let ((_%$%K38913922%_ (lambda () '()))
                (_%$%K38883906%_
                 (lambda (_%rest3901%_ _%column3902%_)
                   (let ((_%selected3904%_
                          (list-tail
                           _%row3881%_
                           (inexact->exact
                            (- _%column3902%_ _%position3883%_)))))
                     (cons (car _%selected3904%_)
                           (gerbil-ascent/table/funs#column-key
                            _%selected3904%_
                            _%rest3901%_
                            _%column3902%_))))))
            (let ((_%$%try-match38863918%_
                   (lambda ()
                     (if (pair? _%$%columns38843893%_)
                         (let ((_%$%tl38903911%_
                                (let ()
                                  (declare (not safe))
                                  (##cdr _%$%columns38843893%_)))
                               (_%$%hd38893909%_
                                (let ()
                                  (declare (not safe))
                                  (##car _%$%columns38843893%_))))
                           (let ((_%column3914%_ _%$%hd38893909%_)
                                 (_%rest3916%_ _%$%tl38903911%_))
                             (_%$%K38883906%_ _%rest3916%_ _%column3914%_)))
                         (_%$%E38873897%_)))))
              (if (null? _%$%columns38843893%_)
                  (_%$%K38913922%_)
                  (_%$%try-match38863918%_)))))))
    (define gerbil-ascent/table/funs#gerbil-ascent-index-key
      (lambda (_%row3876%_ _%columns3877%_)
        (if (gerbil-ascent/table/funs#nondecreasing-columns? _%columns3877%_)
            (gerbil-ascent/table/funs#column-key
             _%row3876%_
             _%columns3877%_
             '0)
            (map (lambda (_%column3879%_)
                   (list-ref _%row3876%_ _%column3879%_))
                 _%columns3877%_))))
    (define gerbil-ascent/table/funs#gerbil-ascent-index-extend!
      (lambda (_%index3822%_ _%new-rows3823%_ _%columns3824%_)
        (let ((_%$e3826%_
               (gerbil-ascent/table/funs#forward-column-steps
                _%columns3824%_)))
          (if _%$e3826%_
              (let* ((_%target3831%_ _%index3822%_)
                     (_%row-slot3834%_ (vector '#f))
                     (_%prepend-row3843%_
                      (lambda (_%bucket3837%_)
                        (cons (vector-ref _%row-slot3834%_ '0)
                              (let ((_%$e3840%_ _%bucket3837%_))
                                (if _%$e3840%_ _%$e3840%_ '()))))))
                (for-each
                 (lambda (_%row3847%_)
                   (let ((_%selected3849%_
                          (gerbil-ascent/table/funs#stepped-key
                           _%row3847%_
                           _%$e3826%_)))
                     (vector-set! _%row-slot3834%_ '0 _%row3847%_)
                     (let ()
                       (declare (not safe))
                       (hash-update!__%
                        _%target3831%_
                        _%selected3849%_
                        _%prepend-row3843%_
                        '#f))))
                 _%new-rows3823%_)
                _%target3831%_)
              (let* ((_%target3853%_ _%index3822%_)
                     (_%row-slot3856%_ (vector '#f))
                     (_%prepend-row3865%_
                      (lambda (_%bucket3859%_)
                        (cons (vector-ref _%row-slot3856%_ '0)
                              (let ((_%$e3862%_ _%bucket3859%_))
                                (if _%$e3862%_ _%$e3862%_ '()))))))
                (for-each
                 (lambda (_%row3869%_)
                   (let ((_%selected3873%_
                          (map (lambda (_%column3871%_)
                                 (list-ref _%row3869%_ _%column3871%_))
                               _%columns3824%_)))
                     (vector-set! _%row-slot3856%_ '0 _%row3869%_)
                     (let ()
                       (declare (not safe))
                       (hash-update!__%
                        _%target3853%_
                        _%selected3873%_
                        _%prepend-row3865%_
                        '#f))))
                 _%new-rows3823%_)
                _%target3853%_)))))))
