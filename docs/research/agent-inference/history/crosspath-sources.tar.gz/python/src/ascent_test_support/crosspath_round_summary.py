# SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
"""Post-outcome descriptive audit; never modifies frozen trials or labels."""
import json,re
from pathlib import Path
from .crosspath_search_v4 import ROOT,BASE,sha,save,canonical
DOC=ROOT/'docs/research/agent-inference'

def produce():
    reports={v:json.loads((DOC/f'crosspath-search-v{v}-report.json').read_text()) for v in (3,4)}
    bounded=json.loads((DOC/'crosspath-search-v4-bounded-report.json').read_text())
    solver=json.loads((BASE/'ledger.json').read_text())['phases'];labels=json.loads((BASE/'annotation-bounded-ledger.json').read_text())['annotations']
    lookup={x['phaseKey']:x for x in labels};rows=[];mismatches=[];examples=[]
    for r in solver:
        lab=lookup[f"paid/{r['case']}-{r['arm']}-{r['phase']}"]
        end_cost={c['turn']:c['cumulativeGrossTokens'] for c in r['calls']};selected=[]
        for e in lab['accepted']:
            seg=next((s for s in lab['segments'] if s['start']<=e['span'][0] and e['span'][1]<=s['end']),None)
            if seg and end_cost[seg['turn']]<=32768:selected.append(e)
            ids={int(a or b) for a,b in re.findall(r'\bF\s*(\d+)\b|\bfragment\s*(?:F\s*)?(\d+)\b',e['quote'],re.I)}
            if e['fragment'] is not None and ids and e['fragment'] not in ids:
                mismatches.append({'phaseKey':lab['phaseKey'],'episode':e['index'],'annotatedFragment':e['fragment'],'literalFragmentIds':sorted(ids),'span':e['span'],'quote':e['quote'],'admittedRepeat':e['definiteRepeatedDerivation'],'scope':'Retrospective literal-ID/boundary diagnostic, not a replacement preregistered count. Some quotes include the next fragment heading; all original labels retained.'})
        outcome=next(x for x in bounded['table'] if x['arm']==r['arm'] and x['goal']==r['phase']);checkpoint=outcome['checkpoints'][1]
        methods={k:sum(e['definiteRepeatedDerivation'] and e.get('repeatLinkMethod')==k for e in selected) for k in ('within_chunk','deterministic_cross_chunk_identical_key')}
        rows.append({'arm':r['arm'],'goal':r['phase'],**checkpoint,'labeledEpisodes':len(selected),'labeledDerivations':sum(e['kind']=='derive' for e in selected),'labeledPositiveRepeats':sum(e['definiteRepeatedDerivation'] for e in selected),'labeledReuses':sum(e['kind']=='reuse' for e in selected),'repeatLinkMethods':methods,'nativePacketReused':r['packet']['reused'] if r['packet'] else None,'nativeProofBuilds':int(bool(r['packet']) and not r['packet']['reused']),'nativeProofSeconds':r['packet']['nativeSeconds'] if r['packet'] else 0})
        if r['arm']=='baseline':
            for e in selected:
                if not e['definiteRepeatedDerivation'] or not e['premiseEdges']:continue
                a=next(x for x in lab['accepted'] if x['index']==e['prior'])
                def tags(x):return {int(v or w) for v,w in re.findall(r'\bF\s*(\d+)\b|\bfragment\s*(?:F\s*)?(\d+)\b',x['quote'],re.I)}
                if e['fragment'] is not None and tags(a)==tags(e)=={e['fragment']}:
                    examples.append({'phaseKey':lab['phaseKey'],'sourceTextSha256':lab['textSha256'],'first':a,'later':e,'scope':'Post-outcome illustrative source-span pair; semantic completeness and all alternative-witness edges have not been independently certified.'});break
    native={a:{'builds':sum(r['nativeProofBuilds'] for r in rows if r['arm']==a),'seconds':sum(r['nativeProofSeconds'] for r in rows if r['arm']==a)} for a in ('baseline','fresh','retained')}
    original_annotations=sum(x['measurementGrossTokens'] for x in reports.values());solver_cost=sum(x['solverGrossTokens'] for x in reports.values());cal_cost=sum(x['calibrationGrossTokens'] for x in reports.values())
    failed_annotations=sum(bool(x['failure']) for v in (3,4) for x in json.loads((ROOT/f'.cache/ascent/crosspath-search-v{v}/annotation-ledger.json').read_text())['annotations'])
    result={'schema':'ascent.crosspath.round-summary.v1','scope':'Descriptive post-outcome audit of separately frozen v3 and v4; no pooled treatment estimate. Fixed common 32768 checkpoint chosen in solver plans. Bounded label extraction frozen separately after whole-phase failures.','mainProtocol':'v4','v4SolverCalls':sum(r['calls'] for r in bounded['table']),'v4SolverTruncations':sum(r['truncatedCalls'] for r in bounded['table']),'v3FailedSolverCalls':sum(r['failedCalls'] for r in reports[3]['table']),'originalAnnotationFailures':failed_annotations,'boundedChunks':sum(len(l['chunks']) for l in labels),'boundedFailedChunks':sum(bool(c['failure']) for l in labels for c in l['chunks']),'boundedAcceptedLabels':sum(len(l['accepted']) for l in labels),'boundedRejectedLabels':sum(len(l['rejected']) for l in labels),'matchedCheckpointRows':rows,'literalIdentityDiagnostics':mismatches,'illustrativePairs':examples,'nativeProofOnly':native,'cost':{'solverGrossTokens':solver_cost,'calibrationGrossTokens':cal_cost,'originalAnnotationGrossTokens':original_annotations,'boundedAnnotationGrossTokens':bounded['measurementGrossTokens'],'allStudyGrossTokens':solver_cost+cal_cost+original_annotations+bounded['measurementGrossTokens']},'conclusion':'Output/control-flow repair passed this real-model pilot. Accepted-label counts show fewer positive repeats in evidence arms at common spend, but evidence arms execute fewer expansions; quality is mixed and admitted depth is not consistently greater. Semantic label identity/completeness remains unvalidated, with literal-ID/boundary ambiguity observed. No reliable causal claim of reduced repeated thinking or increased depth/quality is established. Fresh/retained differ only in private native state: only fewer native proof builds is directly demonstrated.'}
    save(DOC/'crosspath-branch-round-summary.json',result)
    md=['# Branch reuse experiment: output repair passed; cognitive benefit remains unproved','',
        'The v4 local-branch protocol completed **77 real solver calls without output truncation or malformed actions**, after three deep-branch calibration calls also completed. The common feasible seed was independently verified and strictly non-optimal. Every phase retained a valid controller incumbent; none reached the hidden exhaustive optimum. The v3 failed-control experiment remains separately preserved with **15 truncated solver calls**.','',
        'All arms have the same 65,536 input + all-output ceiling, including thinking, cached/repeated inputs and failures. Unused budget is **unused**, never token savings. The main comparison below uses the same **32,768 gross-token checkpoint**, only completed expansions and labels from calls ending before that boundary. A seeded full candidate is not an explored seven-layer path.','',
        '| Arm / goal | Best value (gain over seed) | Expanded branches | Admitted depth | Labeled positive repeats | Within-chunk / cross-chunk links |',
        '|---|---:|---:|---:|---:|---:|']
    for r in rows:md.append(f"| {r['arm']} / {r['goal']} | {r['bestValue']} (+{r['gainFromSeed']}) | {r['prefixes']} | {r['maxAdmittedDepth']} | {r['labeledPositiveRepeats']} | {r['repeatLinkMethods']['within_chunk']} / {r['repeatLinkMethods']['deterministic_cross_chunk_identical_key']} |")
    md +=['',
        'The evidence arms have lower extracted positive-repeat counts at common spend, but also execute fewer branch expansions. Their quality improves on one goal and declines on the other relative to baseline. Depth is equal or lower at the matched checkpoint. The experiment **does not establish a reliable improvement in repeated thinking, exploration depth or quality**. Whole-phase thinking totals cannot be called savings because actual spend/call counts and unused budget differ.','',
        f"Whole-phase annotation encountered {failed_annotations} failed measurements across the two versions. These remain archived. A separate operational measurement froze two-consecutive-call chunks and matching rules before any bounded extraction. All {result['boundedChunks']} chunks completed; {result['boundedAcceptedLabels']} labels passed byte/schema/span checks, {result['boundedRejectedLabels']} were rejected. The original pre-solver semantic rubric was unchanged. Exact spans/native conclusion truth do **not** establish exhaustive extraction, correct semantic classification or independent-rater agreement. The annotator uses the same provider with partial blinding.",'',
        f"A retrospective literal-ID/boundary audit flagged {len(mismatches)} accepted entries where the annotated Fact ID did not appear among explicit Fact IDs in the quoted span. Some span boundaries include the following Fact heading; one clear case labels the paths 4→11 and 5→9 as F2 while the source text calls them fragment 4. Such corrections/ambiguities prevent interpreting the raw counts as validated cognitive ground truth. Original labels and both snippets are kept. See the JSON diagnostics; this audit does not silently replace the frozen count.",'',
        'Fresh and retained receive identical model-visible proof packets and policy. Their thinking/quality differences are stochastic descriptions, not a native-cache cognitive effect. Across two goals, fresh builds the native packet twice; retained once and reuses it once. This establishes native proof-work reuse only. The baseline shares the feasible seed, which itself implies some eligibility; it has no initial ASCENT packet rather than no evidence of any kind.','',
        f"Cost ledger: solver {solver_cost:,}; disjoint calibration {cal_cost:,}; original annotation {original_annotations:,}; bounded annotation {bounded['measurementGrossTokens']:,}; total {result['cost']['allStudyGrossTokens']:,} gross tokens. Measurement tokens are separate overhead and never credited to solver savings. Native timings cover packet proofs only, not an end-to-end speed claim.",'',
        'All raw failed responses, incomplete reasoning, invalid prefixes/completions, malformed annotation JSON, rejected quotes, proof-store receipts and native scores remain in portable archives. Current candidate source bytes match the inherited frozen kernel; source/artifact hashes and initial arm-input parity were verified. This does not certify the entire concurrent working tree or remote CI. Twelve focused tests passed.','',
        '- [Frozen v4 protocol](crosspath-branch-v4-protocol.md)',
        '- [V4 native outcomes and original failed measurements](crosspath-search-v4-report.md)',
        '- [Bounded extraction report and ledger](crosspath-search-v4-bounded-report.md)',
        '- [Exact thinking spans and prior links](crosspath-v4-bounded-thinking-annotations.md)',
        '- [V3 failed-control trial](crosspath-search-v3-report.md)',
        '- [Machine-readable summary and retrospective diagnostics](crosspath-branch-round-summary.json)','',
        'The next useful system hypothesis is source-bound, branch-specific Fact/proof lookup with a small typed reference, rather than replaying the full proof packet at every expansion. It needs a new frozen experiment; this round provides no positive claim for that untested design.']
    (DOC/'crosspath-branch-round-summary.md').write_text('\n'.join(md)+'\n')
    for v in (3,4):
        path=DOC/f'crosspath-search-v{v}-report.md';text=path.read_text();note='\n**Measurement warning:** zero accepted labels in a failed annotation row means missing measurement, not zero repetition. Whole-phase annotation failures are retained; use the bounded supplemental report and round summary for explicit measurement limitations.\n'
        if 'Measurement warning:' not in text:path.write_text(text+note)
    print(json.dumps({'v4Calls':result['v4SolverCalls'],'chunks':result['boundedChunks'],'matchedRows':rows,'cost':result['cost']},indent=2))

if __name__=='__main__':produce()
