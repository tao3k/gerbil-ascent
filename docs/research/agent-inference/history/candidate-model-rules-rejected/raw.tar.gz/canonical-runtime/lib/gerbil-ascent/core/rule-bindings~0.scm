(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/core/rule-bindings::timestamp 1791687872)
  (begin
    (define gerbil-ascent/core/rule-bindings#binding-value
      (lambda (_%name7005%_ _%environment7006%_ _%diagnostic7007%_)
        (let ((_%binding7009%_ (assq _%name7005%_ _%environment7006%_)))
          (if _%binding7009%_
              '#!void
              (let ()
                (declare (not safe))
                (error _%diagnostic7007%_ _%name7005%_)))
          (cdr _%binding7009%_))))
    (define gerbil-ascent/core/rule-bindings#gerbil-ascent-binding-values
      (lambda (_%names6999%_ _%environment7000%_ _%diagnostic7001%_)
        (map (lambda (_%name7003%_)
               (gerbil-ascent/core/rule-bindings#binding-value
                _%name7003%_
                _%environment7000%_
                _%diagnostic7001%_))
             _%names6999%_)))
    (define gerbil-ascent/core/rule-bindings#gerbil-ascent-call-with-bindings
      (lambda (_%procedure6768%_
               _%names6769%_
               _%environment6770%_
               _%diagnostic6771%_)
        (let* ((_%$%names67726806%_ _%names6769%_)
               (_%$%else67786816%_
                (lambda ()
                  (apply _%procedure6768%_
                         (map (lambda (_%name6814%_)
                                (gerbil-ascent/core/rule-bindings#binding-value
                                 _%name6814%_
                                 _%environment6770%_
                                 _%diagnostic6771%_))
                              _%names6769%_)))))
          (let ((_%$%K68046996%_ (lambda () (_%procedure6768%_)))
                (_%$%K68016982%_
                 (lambda (_%one6974%_)
                   (let* ((_%name6976%_ _%one6974%_)
                          (_%next6978%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6976%_
                            _%environment6770%_
                            _%diagnostic6771%_)))
                     (_%procedure6768%_ _%next6978%_))))
                (_%$%K67966953%_
                 (lambda (_%two6938%_ _%one6939%_)
                   (let* ((_%name6941%_ _%one6939%_)
                          (_%next6943%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6941%_
                            _%environment6770%_
                            _%diagnostic6771%_))
                          (_%name6947%_ _%two6938%_)
                          (_%next6949%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6947%_
                            _%environment6770%_
                            _%diagnostic6771%_)))
                     (_%procedure6768%_ _%next6943%_ _%next6949%_))))
                (_%$%K67896910%_
                 (lambda (_%three6888%_ _%two6889%_ _%one6890%_)
                   (let* ((_%name6892%_ _%one6890%_)
                          (_%next6894%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6892%_
                            _%environment6770%_
                            _%diagnostic6771%_))
                          (_%name6898%_ _%two6889%_)
                          (_%next6900%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6898%_
                            _%environment6770%_
                            _%diagnostic6771%_))
                          (_%name6904%_ _%three6888%_)
                          (_%next6906%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6904%_
                            _%environment6770%_
                            _%diagnostic6771%_)))
                     (_%procedure6768%_
                      _%next6894%_
                      _%next6900%_
                      _%next6906%_))))
                (_%$%K67806853%_
                 (lambda (_%four6820%_ _%three6822%_ _%two6824%_ _%one6826%_)
                   (let* ((_%name6829%_ _%one6826%_)
                          (_%next6831%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6829%_
                            _%environment6770%_
                            _%diagnostic6771%_))
                          (_%name6835%_ _%two6824%_)
                          (_%next6837%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6835%_
                            _%environment6770%_
                            _%diagnostic6771%_))
                          (_%name6841%_ _%three6822%_)
                          (_%next6843%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6841%_
                            _%environment6770%_
                            _%diagnostic6771%_))
                          (_%name6847%_ _%four6820%_)
                          (_%next6849%_
                           (gerbil-ascent/core/rule-bindings#binding-value
                            _%name6847%_
                            _%environment6770%_
                            _%diagnostic6771%_)))
                     (_%procedure6768%_
                      _%next6831%_
                      _%next6837%_
                      _%next6843%_
                      _%next6849%_)))))
            (let ((_%$%try-match67746992%_
                   (lambda ()
                     (if (pair? _%$%names67726806%_)
                         (let ((_%$%tl68036987%_
                                (let ()
                                  (declare (not safe))
                                  (##cdr _%$%names67726806%_)))
                               (_%$%hd68026985%_
                                (let ()
                                  (declare (not safe))
                                  (##car _%$%names67726806%_))))
                           (if (null? _%$%tl68036987%_)
                               (let ((_%one6990%_ _%$%hd68026985%_))
                                 (_%$%K68016982%_ _%one6990%_))
                               (if (pair? _%$%tl68036987%_)
                                   (let ((_%$%tl68006965%_
                                          (let ()
                                            (declare (not safe))
                                            (##cdr _%$%tl68036987%_)))
                                         (_%$%hd67996963%_
                                          (let ()
                                            (declare (not safe))
                                            (##car _%$%tl68036987%_))))
                                     (if (null? _%$%tl68006965%_)
                                         (let ((_%one6961%_ _%$%hd68026985%_)
                                               (_%two6968%_ _%$%hd67996963%_))
                                           (_%$%K67966953%_
                                            _%two6968%_
                                            _%one6961%_))
                                         (if (pair? _%$%tl68006965%_)
                                             (let ((_%$%tl67956929%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##cdr _%$%tl68006965%_)))
                                                   (_%$%hd67946927%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##car _%$%tl68006965%_))))
                                               (if (null? _%$%tl67956929%_)
                                                   (let ((_%one6918%_
                                                          _%$%hd68026985%_)
                                                         (_%two6925%_
                                                          _%$%hd67996963%_)
                                                         (_%three6932%_
                                                          _%$%hd67946927%_))
                                                     (_%$%K67896910%_
                                                      _%three6932%_
                                                      _%two6925%_
                                                      _%one6918%_))
                                                   (if (pair? _%$%tl67956929%_)
                                                       (let ((_%$%tl67886879%_
                                                              (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (##cdr _%$%tl67956929%_)))
                     (_%$%hd67876877%_
                      (let () (declare (not safe)) (##car _%$%tl67956929%_))))
                 (if (null? _%$%tl67886879%_)
                     (let ((_%one6861%_ _%$%hd68026985%_)
                           (_%two6868%_ _%$%hd67996963%_)
                           (_%three6875%_ _%$%hd67946927%_)
                           (_%four6882%_ _%$%hd67876877%_))
                       (_%$%K67806853%_
                        _%four6882%_
                        _%three6875%_
                        _%two6868%_
                        _%one6861%_))
                     (_%$%else67786816%_)))
               (_%$%else67786816%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%$%else67786816%_))))
                                   (_%$%else67786816%_))))
                         (_%$%else67786816%_)))))
              (if (null? _%$%names67726806%_)
                  (let () (declare (not safe)) (_%procedure6768%_))
                  (_%$%try-match67746992%_)))))))
    (define gerbil-ascent/core/rule-bindings#gerbil-ascent-expression-value
      (lambda (_%payload6765%_ _%environment6766%_)
        (gerbil-ascent/core/rule-bindings#gerbil-ascent-call-with-bindings
         (vector-ref _%payload6765%_ '1)
         (vector-ref _%payload6765%_ '0)
         _%environment6766%_
         '"unbound ASCENT expression variable")))
    (define gerbil-ascent/core/rule-bindings#gerbil-ascent-extend-pattern
      (lambda (_%outputs6698%_
               _%matched6699%_
               _%environment6700%_
               _%diagnostic6701%_)
        (let _%extend6703%_ ((_%names6705%_ _%outputs6698%_)
                             (_%values6706%_ _%matched6699%_))
          (let ((_%$%names67076720%_ _%names6705%_)
                (_%$%values67086721%_ _%values6706%_))
            (let ((_%$%else67116728%_
                   (lambda ()
                     (let ()
                       (declare (not safe))
                       (error _%diagnostic6701%_
                              _%matched6699%_
                              _%outputs6698%_)))))
              (let ((_%$%K67186762%_ (lambda () _%environment6700%_))
                    (_%$%K67136737%_
                     (lambda (_%remaining6732%_
                              _%name6733%_
                              _%rest6734%_
                              _%value6735%_)
                       (cons (cons _%name6733%_ _%value6735%_)
                             (_%extend6703%_
                              _%remaining6732%_
                              _%rest6734%_)))))
                (let ((_%$%try-match67106758%_
                       (lambda ()
                         (if (pair? _%$%names67076720%_)
                             (let ((_%$%tl67176742%_
                                    (let ()
                                      (declare (not safe))
                                      (##cdr _%$%names67076720%_)))
                                   (_%$%hd67166740%_
                                    (let ()
                                      (declare (not safe))
                                      (##car _%$%names67076720%_))))
                               (if (pair? _%$%values67086721%_)
                                   (let ((_%$%tl67156751%_
                                          (let ()
                                            (declare (not safe))
                                            (##cdr _%$%values67086721%_)))
                                         (_%$%hd67146749%_
                                          (let ()
                                            (declare (not safe))
                                            (##car _%$%values67086721%_))))
                                     (let ((_%name6745%_ _%$%hd67166740%_)
                                           (_%remaining6747%_ _%$%tl67176742%_)
                                           (_%value6754%_ _%$%hd67146749%_)
                                           (_%rest6756%_ _%$%tl67156751%_))
                                       (_%$%K67136737%_
                                        _%remaining6747%_
                                        _%name6745%_
                                        _%rest6756%_
                                        _%value6754%_)))
                                   (_%$%else67116728%_)))
                             (_%$%else67116728%_)))))
                  (if (null? _%$%names67076720%_)
                      (if (null? _%$%values67086721%_)
                          (_%$%K67186762%_)
                          (_%$%else67116728%_))
                      (_%$%try-match67106758%_)))))))))
    (define gerbil-ascent/core/rule-bindings#gerbil-ascent-bind-row
      (lambda (_%terms6444%_ _%row6445%_ _%environment6446%_)
        (let _%loop6448%_ ((_%patterns6450%_ _%terms6444%_)
                           (_%values6451%_ _%row6445%_)
                           (_%bindings6452%_ _%environment6446%_))
          (let* ((_%$%patterns64536462%_ _%patterns6450%_)
                 (_%$%E64566466%_
                  (lambda ()
                    (let ()
                      (declare (not safe))
                      (error '"No clause matching"
                             _%$%patterns64536462%_
                             '([])
                             '([term . _])))
                    '#!void)))
            (let ((_%$%K64606695%_ (lambda () _%bindings6452%_))
                  (_%$%K64576683%_
                   (lambda (_%term6470%_)
                     (letrec* ((_%value6472%_ (car _%values6451%_)))
                       (let* ((_%$%term65556582%_ _%term6470%_)
                              (_%$%E65626586%_
                               (lambda ()
                                 (let ()
                                   (declare (not safe))
                                   (error '"No clause matching"
                                          _%$%term65556582%_
                                          '(['wildcard . _])
                                          '(['fresh-variable . name])
                                          '(['pattern . payload])
                                          '(['literal . expected])
                                          '(['expression . payload])
                                          '([_ . name])))
                                 '#!void)))
                         (let ((_%$%K65786677%_
                                (lambda ()
                                  (_%loop6448%_
                                   (cdr _%patterns6450%_)
                                   (cdr _%values6451%_)
                                   _%bindings6452%_)))
                               (_%$%K65756663%_
                                (lambda (_%name6661%_)
                                  (_%loop6448%_
                                   (cdr _%patterns6450%_)
                                   (cdr _%values6451%_)
                                   (cons (cons _%name6661%_ _%value6472%_)
                                         _%bindings6452%_))))
                               (_%$%K65726647%_
                                (lambda (_%payload6642%_)
                                  (letrec* ((_%matched6644%_
                                             ((vector-ref _%payload6642%_ '1)
                                              _%value6472%_))
                                            (_%outputs6645%_
                                             (vector-ref _%payload6642%_ '0)))
                                    (if _%matched6644%_
                                        (_%loop6448%_
                                         (cdr _%patterns6450%_)
                                         (cdr _%values6451%_)
                                         (gerbil-ascent/core/rule-bindings#gerbil-ascent-extend-pattern
                                          _%outputs6645%_
                                          _%matched6644%_
                                          _%bindings6452%_
                                          '"ASCENT pattern returned invalid bindings"))
                                        '#f))))
                               (_%$%K65696628%_
                                (lambda (_%expected6626%_)
                                  (if (equal? _%expected6626%_ _%value6472%_)
                                      (_%loop6448%_
                                       (cdr _%patterns6450%_)
                                       (cdr _%values6451%_)
                                       _%bindings6452%_)
                                      '#f)))
                               (_%$%K65666612%_
                                (lambda (_%payload6610%_)
                                  (if (equal? (gerbil-ascent/core/rule-bindings#gerbil-ascent-expression-value
                                               _%payload6610%_
                                               _%bindings6452%_)
                                              _%value6472%_)
                                      (_%loop6448%_
                                       (cdr _%patterns6450%_)
                                       (cdr _%values6451%_)
                                       _%bindings6452%_)
                                      '#f)))
                               (_%$%K65636598%_
                                (lambda (_%name6590%_)
                                  (let ((_%$e6592%_
                                         (assq _%name6590%_ _%bindings6452%_)))
                                    (if _%$e6592%_
                                        (if (equal? (cdr _%$e6592%_)
                                                    _%value6472%_)
                                            (_%loop6448%_
                                             (cdr _%patterns6450%_)
                                             (cdr _%values6451%_)
                                             _%bindings6452%_)
                                            '#f)
                                        (_%loop6448%_
                                         (cdr _%patterns6450%_)
                                         (cdr _%values6451%_)
                                         (cons (cons _%name6590%_
                                                     _%value6472%_)
                                               _%bindings6452%_)))))))
                           (if (pair? _%$%term65556582%_)
                               (let ((_%$%hd65796680%_
                                      (let ()
                                        (declare (not safe))
                                        (##car _%$%term65556582%_))))
                                 (if (let ()
                                       (declare (not safe))
                                       (##eq? _%$%hd65796680%_ 'wildcard))
                                     (_%$%K65786677%_)
                                     (let ((_%$%tl65776668%_
                                            (let ()
                                              (declare (not safe))
                                              (##cdr _%$%term65556582%_))))
                                       (if (let ()
                                             (declare (not safe))
                                             (##eq? _%$%hd65796680%_
                                                    'fresh-variable))
                                           (let ((_%name6671%_
                                                  _%$%tl65776668%_))
                                             (_%$%K65756663%_ _%name6671%_))
                                           (if (let ()
                                                 (declare (not safe))
                                                 (##eq? _%$%hd65796680%_
                                                        'pattern))
                                               (let ((_%payload6655%_
                                                      _%$%tl65776668%_))
                                                 (_%$%K65726647%_
                                                  _%payload6655%_))
                                               (if (let ()
                                                     (declare (not safe))
                                                     (##eq? _%$%hd65796680%_
                                                            'literal))
                                                   (let ((_%expected6636%_
                                                          _%$%tl65776668%_))
                                                     (_%$%K65696628%_
                                                      _%expected6636%_))
                                                   (if (let ()
                                                         (declare (not safe))
                                                         (##eq? _%$%hd65796680%_
                                                                'expression))
                                                       (let ((_%payload6620%_
                                                              _%$%tl65776668%_))
                                                         (_%$%K65666612%_
                                                          _%payload6620%_))
                                                       (let ((_%name6604%_
                                                              _%$%tl65776668%_))
                                                         (_%$%K65636598%_
                                                          _%name6604%_)))))))))
                               (_%$%E65626586%_))))))))
              (let ((_%$%try-match64556691%_
                     (lambda ()
                       (if (pair? _%$%patterns64536462%_)
                           (let* ((_%$%hd64586686%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%patterns64536462%_)))
                                  (_%term6689%_ _%$%hd64586686%_))
                             (_%$%K64576683%_ _%term6689%_))
                           (_%$%E64566466%_)))))
                (if (null? _%$%patterns64536462%_)
                    (_%$%K64606695%_)
                    (_%$%try-match64556691%_))))))))
    (define gerbil-ascent/core/rule-bindings#gerbil-ascent-head-row
      (lambda (_%terms6344%_ _%environment6345%_)
        (map (lambda (_%$%e63466348%_)
               (let* ((_%$%$%e634663506373%_ _%$%e63466348%_)
                      (_%$%E63566377%_
                       (lambda ()
                         (let ()
                           (declare (not safe))
                           (error '"No clause matching"
                                  _%$%$%e634663506373%_
                                  '(['literal . value])
                                  '(['expression . payload])
                                  '(['pattern . _])
                                  '(['wildcard . _])
                                  '([_ . name])))
                         '#!void)))
                 (let ((_%$%K63696434%_ (lambda (_%value6432%_) _%value6432%_))
                       (_%$%K63666419%_
                        (lambda (_%payload6417%_)
                          (gerbil-ascent/core/rule-bindings#gerbil-ascent-expression-value
                           _%payload6417%_
                           _%environment6345%_)))
                       (_%$%K63636407%_
                        (lambda ()
                          (let ()
                            (declare (not safe))
                            (error '"ASCENT pattern is invalid in a rule head"))))
                       (_%$%K63606396%_
                        (lambda ()
                          (let ()
                            (declare (not safe))
                            (error '"ASCENT wildcard is invalid in a rule head"))))
                       (_%$%K63576383%_
                        (lambda (_%name6381%_)
                          (gerbil-ascent/core/rule-bindings#binding-value
                           _%name6381%_
                           _%environment6345%_
                           '"unbound ASCENT head variable"))))
                   (if (pair? _%$%$%e634663506373%_)
                       (let ((_%$%tl63716439%_
                              (let ()
                                (declare (not safe))
                                (##cdr _%$%$%e634663506373%_)))
                             (_%$%hd63706437%_
                              (let ()
                                (declare (not safe))
                                (##car _%$%$%e634663506373%_))))
                         (if (let ()
                               (declare (not safe))
                               (##eq? _%$%hd63706437%_ 'literal))
                             (let ((_%value6442%_ _%$%tl63716439%_))
                               (_%$%K63696434%_ _%value6442%_))
                             (if (let ()
                                   (declare (not safe))
                                   (##eq? _%$%hd63706437%_ 'expression))
                                 (let ((_%payload6427%_ _%$%tl63716439%_))
                                   (_%$%K63666419%_ _%payload6427%_))
                                 (if (let ()
                                       (declare (not safe))
                                       (##eq? _%$%hd63706437%_ 'pattern))
                                     (_%$%K63636407%_)
                                     (if (let ()
                                           (declare (not safe))
                                           (##eq? _%$%hd63706437%_ 'wildcard))
                                         (_%$%K63606396%_)
                                         (let ((_%name6389%_ _%$%tl63716439%_))
                                           (_%$%K63576383%_ _%name6389%_)))))))
                       (_%$%E63566377%_)))))
             _%terms6344%_)))))
