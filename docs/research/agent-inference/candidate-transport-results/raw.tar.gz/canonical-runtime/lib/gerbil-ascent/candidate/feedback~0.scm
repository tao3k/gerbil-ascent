(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/feedback::timestamp 1791692692)
  (begin
    (define gerbil-ascent/candidate/feedback#reasoning-feedback::t
      (let ((__tmp34419 (list))
            (__tmp34418
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reasoning-feedback
         __tmp34419
         '(status reason missing extra)
         __tmp34418
         '#f)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/feedback#reasoning-feedback::t)))
    (define gerbil-ascent/candidate/feedback#make-reasoning-feedback
      (lambda _%$args30568%_
        (apply make-instance
               gerbil-ascent/candidate/feedback#reasoning-feedback::t
               _%$args30568%_)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'status)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-reason
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reason)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-missing
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'missing)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-extra
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'extra)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'status)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-reason-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reason)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-missing-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'missing)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-extra-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'extra)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'status)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-reason
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reason)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-missing
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'missing)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-extra
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'extra)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'status)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-reason-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reason)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-missing-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'missing)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-extra-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'extra)))
    (define gerbil-ascent/candidate/feedback#refuse-feedback
      (lambda (_%reason30566%_)
        (let ()
          (declare (not safe))
          (##structure
           gerbil-ascent/candidate/feedback#reasoning-feedback::t
           'inconclusive
           _%reason30566%_
           '()
           '()))))
    (define gerbil-ascent/candidate/feedback#receipt-feedback-reason
      (lambda (_%snapshot30559%_ _%candidate30560%_ _%receipt30561%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
               _%receipt30561%_
               _%snapshot30559%_
               _%candidate30560%_))
            (if (eq? (##structure-ref
                      _%receipt30561%_
                      '1
                      gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                      '#f)
                     'complete)
                '#f
                (##structure-ref
                 _%receipt30561%_
                 '1
                 gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                 '#f))
            'unbound)))
    (define gerbil-ascent/candidate/feedback#reasoning-compare-rows
      (lambda (_%snapshot30552%_
               _%candidate30553%_
               _%receipt30554%_
               _%expected30555%_)
        (let ((_%reason30557%_
               (gerbil-ascent/candidate/feedback#receipt-feedback-reason
                _%snapshot30552%_
                _%candidate30553%_
                _%receipt30554%_)))
          (if _%reason30557%_
              (gerbil-ascent/candidate/feedback#refuse-feedback
               _%reason30557%_)
              (gerbil-ascent/candidate/feedback#compare-qualified-rows
               _%receipt30554%_
               _%expected30555%_)))))
    (define gerbil-ascent/candidate/feedback#reasoning-compare-attempts
      (lambda (_%snapshot30539%_
               _%candidate30540%_
               _%receipt30541%_
               _%reference-candidate30542%_
               _%reference-receipt30543%_)
        (let ((_%reason30545%_
               (gerbil-ascent/candidate/feedback#receipt-feedback-reason
                _%snapshot30539%_
                _%candidate30540%_
                _%receipt30541%_)))
          (if _%reason30545%_
              (gerbil-ascent/candidate/feedback#refuse-feedback
               _%reason30545%_)
              (if (let ()
                    (declare (not safe))
                    (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                     _%reference-receipt30543%_
                     _%snapshot30539%_
                     _%reference-candidate30542%_))
                  (if (eq? (##structure-ref
                            _%reference-receipt30543%_
                            '1
                            gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                            '#f)
                           'complete)
                      (if (equal? (##structure-ref
                                   _%receipt30541%_
                                   '6
                                   gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                   '#f)
                                  (##structure-ref
                                   _%reference-receipt30543%_
                                   '6
                                   gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                   '#f))
                          (gerbil-ascent/candidate/feedback#compare-qualified-rows
                           _%receipt30541%_
                           (##structure-ref
                            _%reference-receipt30543%_
                            '7
                            gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                            '#f))
                          (gerbil-ascent/candidate/feedback#refuse-feedback
                           'query-mismatch))
                      (gerbil-ascent/candidate/feedback#refuse-feedback
                       'reference-incomplete))
                  (gerbil-ascent/candidate/feedback#refuse-feedback
                   'reference-unbound))))))
    (define gerbil-ascent/candidate/feedback#compare-qualified-rows
      (lambda (_%receipt30509%_ _%expected30510%_)
        (if (and (let ()
                   (declare (not safe))
                   (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                    _%expected30510%_
                    '16384
                    '128))
                 (list? _%expected30510%_)
                 (let* ((_%arity30512%_
                         (length (cdr (##structure-ref
                                       _%receipt30509%_
                                       '6
                                       gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                       '#f))))
                        (__tmp34420
                         (lambda (_%row30514%_)
                           (and (list? _%row30514%_)
                                (= (let ()
                                     (declare (not safe))
                                     (##length _%row30514%_))
                                   _%arity30512%_)
                                (let ()
                                  (declare (not safe))
                                  (andmap__0
                                   gerbil-ascent/candidate/program#scalar?
                                   _%row30514%_))))))
                   (declare (not safe))
                   (andmap__0 __tmp34420 _%expected30510%_)))
            (let ((_%actual-set30518%_
                   (let ()
                     (declare (not safe))
                     (make-hash-table__%
                      '#f
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value)))
                  (_%expected-set30519%_
                   (let ()
                     (declare (not safe))
                     (make-hash-table__%
                      '#f
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value)))
                  (_%actual30520%_ '())
                  (_%wanted30521%_ '()))
              (letrec ((_%insert30523%_
                        (lambda (_%rows30532%_ _%table30533%_)
                          (let ((_%unique30535%_ '()))
                            (for-each
                             (lambda (_%row30537%_)
                               (if (let ()
                                     (declare (not safe))
                                     (hash-get _%table30533%_ _%row30537%_))
                                   '#!void
                                   (begin
                                     (let ()
                                       (declare (not safe))
                                       (hash-put!
                                        _%table30533%_
                                        _%row30537%_
                                        '#t))
                                     (set! _%unique30535%_
                                           (cons _%row30537%_
                                                 _%unique30535%_)))))
                             _%rows30532%_)
                            (let ()
                              (declare (not safe))
                              (##reverse _%unique30535%_))))))
                (set! _%actual30520%_
                      (_%insert30523%_
                       (##structure-ref
                        _%receipt30509%_
                        '7
                        gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                        '#f)
                       _%actual-set30518%_))
                (set! _%wanted30521%_
                      (_%insert30523%_
                       _%expected30510%_
                       _%expected-set30519%_))
                (let ((_%missing30529%_
                       (let ((__tmp34421
                              (lambda (_%row30525%_)
                                (not (let ()
                                       (declare (not safe))
                                       (__hash-get
                                        _%actual-set30518%_
                                        _%row30525%_))))))
                         (declare (not safe))
                         (##filter __tmp34421 _%wanted30521%_)))
                      (_%extra30530%_
                       (let ((__tmp34422
                              (lambda (_%row30527%_)
                                (not (let ()
                                       (declare (not safe))
                                       (__hash-get
                                        _%expected-set30519%_
                                        _%row30527%_))))))
                         (declare (not safe))
                         (##filter __tmp34422 _%actual30520%_))))
                  (let ((__tmp34425
                         (if (and (null? _%missing30529%_)
                                  (null? _%extra30530%_))
                             'match
                             'mismatch))
                        (__tmp34424
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/datum#candidate-copy-pairs
                            _%missing30529%_)))
                        (__tmp34423
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/datum#candidate-copy-pairs
                            _%extra30530%_))))
                    (declare (not safe))
                    (##structure
                     gerbil-ascent/candidate/feedback#reasoning-feedback::t
                     __tmp34425
                     '#f
                     __tmp34424
                     __tmp34423)))))
            (gerbil-ascent/candidate/feedback#refuse-feedback
             'invalid-reference))))))
