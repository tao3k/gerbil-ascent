(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/tools/research/candidate-interaction::timestamp
    1791691412)
  (begin
    (define gerbil-ascent/tools/research/candidate-interaction#edges
      '((0 1) (0 2) (1 0) (1 2) (2 0) (2 1)))
    (define gerbil-ascent/tools/research/candidate-interaction#ordinals
      (lambda (_%n2541%_)
        (let _%loop2543%_ ((_%i2545%_ '0))
          (if (= _%i2545%_ _%n2541%_)
              '()
              (cons _%i2545%_ (_%loop2543%_ (+ _%i2545%_ '1)))))))
    (define gerbil-ascent/tools/research/candidate-interaction#graph
      (lambda (_%mask2536%_)
        (let ((__tmp5369
               (lambda (_%edge2538%_ _%index2539%_)
                 (if (zero? (bitwise-and
                             _%mask2536%_
                             (arithmetic-shift '1 _%index2539%_)))
                     '#f
                     _%edge2538%_)))
              (__tmp5368
               (gerbil-ascent/tools/research/candidate-interaction#ordinals
                '6)))
          (declare (not safe))
          (filter-map__1
           __tmp5369
           gerbil-ascent/tools/research/candidate-interaction#edges
           __tmp5368))))
    (define gerbil-ascent/tools/research/candidate-interaction#walk
      (lambda (_%pairs2510%_ _%origin2511%_ _%even?2512%_)
        (let _%loop2514%_ ((_%pending2516%_
                            (let ((__tmp5377
                                   (lambda (_%e2532%_)
                                     (list (cadr _%e2532%_) '1)))
                                  (__tmp5376
                                   (filter (lambda (_%e2534%_)
                                             (= _%origin2511%_
                                                (car _%e2534%_)))
                                           _%pairs2510%_)))
                              (declare (not safe))
                              (##map __tmp5377 __tmp5376)))
                           (_%seen2517%_ '()))
          (if (null? _%pending2516%_)
              (let ((__tmp5370
                     (lambda (_%v2519%_)
                       (if (let ((__tmp5371
                                  (lambda (_%s2521%_)
                                    (and (= _%v2519%_ (car _%s2521%_))
                                         (or (not _%even?2512%_)
                                             (= '0 (cadr _%s2521%_)))))))
                             (declare (not safe))
                             (ormap__0 __tmp5371 _%seen2517%_))
                           _%v2519%_
                           '#f))))
                (declare (not safe))
                (filter-map__0 __tmp5370 '(0 1 2)))
              (let ((_%s2526%_ (car _%pending2516%_)))
                (if (member _%s2526%_ _%seen2517%_)
                    (_%loop2514%_ (cdr _%pending2516%_) _%seen2517%_)
                    (_%loop2514%_
                     (let ((__tmp5375 (cdr _%pending2516%_))
                           (__tmp5372
                            (let ((__tmp5374
                                   (lambda (_%e2528%_)
                                     (list (cadr _%e2528%_)
                                           (- '1 (cadr _%s2526%_)))))
                                  (__tmp5373
                                   (filter (lambda (_%e2530%_)
                                             (= (car _%s2526%_)
                                                (car _%e2530%_)))
                                           _%pairs2510%_)))
                              (declare (not safe))
                              (##map __tmp5374 __tmp5373))))
                       (declare (not safe))
                       (##append __tmp5375 __tmp5372))
                     (cons _%s2526%_ _%seen2517%_))))))))
    (define gerbil-ascent/tools/research/candidate-interaction#expected
      (lambda (_%case-id2501%_ _%pairs2502%_)
        (if (= _%case-id2501%_ '2)
            (let ((__tmp5378
                   (filter (lambda (_%v2504%_)
                             (member _%v2504%_
                                     (gerbil-ascent/tools/research/candidate-interaction#walk
                                      _%pairs2502%_
                                      '1
                                      '#f)))
                           (gerbil-ascent/tools/research/candidate-interaction#walk
                            _%pairs2502%_
                            '0
                            '#f))))
              (declare (not safe))
              (##map list __tmp5378))
            (let ((__tmp5379
                   (let ((__tmp5380
                          (lambda (_%u2506%_)
                            (map (lambda (_%v2508%_)
                                   (list _%u2506%_ _%v2508%_))
                                 (gerbil-ascent/tools/research/candidate-interaction#walk
                                  _%pairs2502%_
                                  _%u2506%_
                                  (= _%case-id2501%_ '1))))))
                     (declare (not safe))
                     (##map __tmp5380 '(0 1 2)))))
              (declare (not safe))
              (##apply append __tmp5379)))))
    (define gerbil-ascent/tools/research/candidate-interaction#proposal__%
      (lambda (_%case-id2483%_ _%rules2484%_ _%row-budget2485%_)
        (let ((__tmp5383 (if (= _%case-id2483%_ '2) '((relation both 1)) '()))
              (__tmp5382
               (map (lambda (_%r2487%_) (cons 'rule _%r2487%_)) _%rules2484%_))
              (__tmp5381
               (list (if (= _%case-id2483%_ '2)
                         '(query both ?z)
                         '(query path ?x ?y))
                     (list 'limits '16 _%row-budget2485%_ '128))))
          (declare (not safe))
          (##append
           '(candidate (relation path 2))
           __tmp5383
           __tmp5382
           __tmp5381))))
    (define gerbil-ascent/tools/research/candidate-interaction#proposal__0
      (lambda (_%case-id2492%_ _%rules2493%_)
        (let ((_%row-budget2495%_ '64))
          (gerbil-ascent/tools/research/candidate-interaction#proposal__%
           _%case-id2492%_
           _%rules2493%_
           _%row-budget2495%_))))
    (define gerbil-ascent/tools/research/candidate-interaction#proposal
      (lambda _g5384_
        (let ((_g5385_ (let () (declare (not safe)) (##length _g5384_))))
          (cond ((let () (declare (not safe)) (##fx= _g5385_ 2))
                 (apply gerbil-ascent/tools/research/candidate-interaction#proposal__0
                        _g5384_))
                ((let () (declare (not safe)) (##fx= _g5385_ 3))
                 (apply gerbil-ascent/tools/research/candidate-interaction#proposal__%
                        _g5384_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/tools/research/candidate-interaction#proposal
                  _g5384_))))))
    (define gerbil-ascent/tools/research/candidate-interaction#source
      (lambda (_%case-id2478%_ _%generation2479%_ _%pairs2480%_)
        (let ((__tmp5389
               (let ((__tmp5390 (number->string _%case-id2478%_)))
                 (declare (not safe))
                 (##string-append '"library-candidate-" __tmp5390)))
              (__tmp5386
               (let ((__tmp5388 (list (list 'edge '2 _%pairs2480%_)))
                     (__tmp5387
                      (if (= _%case-id2478%_ '2)
                          '((left 1 ((0))) (right 1 ((1))))
                          '())))
                 (declare (not safe))
                 (##append __tmp5388 __tmp5387))))
          (declare (not safe))
          (gerbil-ascent/candidate/reasoning#reasoning-source-snapshot
           __tmp5389
           _%generation2479%_
           __tmp5386))))
    (define gerbil-ascent/tools/research/candidate-interaction#wire
      (lambda (_%x2473%_)
        (if (symbol? _%x2473%_)
            (let () (declare (not safe)) (##symbol->string _%x2473%_))
            (if (pair? _%x2473%_)
                (let ()
                  (declare (not safe))
                  (##map gerbil-ascent/tools/research/candidate-interaction#wire
                         _%x2473%_))
                _%x2473%_))))
    (define gerbil-ascent/tools/research/candidate-interaction#symbols
      (lambda (_%x2467%_)
        (if (string? _%x2467%_)
            (let () (declare (not safe)) (##string->symbol _%x2467%_))
            (if (list? _%x2467%_)
                (let ()
                  (declare (not safe))
                  (##map gerbil-ascent/tools/research/candidate-interaction#symbols
                         _%x2467%_))
                (if (and (integer? _%x2467%_) (exact? _%x2467%_))
                    _%x2467%_
                    (let ()
                      (declare (not safe))
                      (error '"invalid rule datum")))))))
    (define gerbil-ascent/tools/research/candidate-interaction#observe
      (lambda (_%case-id2443%_ _%generation2444%_ _%pairs2445%_ _%rules2446%_)
        (let* ((_%s2448%_
                (gerbil-ascent/tools/research/candidate-interaction#source
                 _%case-id2443%_
                 _%generation2444%_
                 _%pairs2445%_))
               (_%p2450%_
                (gerbil-ascent/tools/research/candidate-interaction#proposal__0
                 _%case-id2443%_
                 _%rules2446%_))
               (_%r2452%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                   _%s2448%_
                   _%p2450%_
                   '#f)))
               (_%wanted2454%_
                (gerbil-ascent/tools/research/candidate-interaction#expected
                 _%case-id2443%_
                 _%pairs2445%_))
               (_%f2456%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                   _%s2448%_
                   _%p2450%_
                   _%r2452%_
                   _%wanted2454%_)))
               (_%ht2459%_
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   '10
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value))))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht2459%_ '"generation" _%generation2444%_))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht2459%_ '"edges" _%pairs2445%_))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht2459%_ '"expected" _%wanted2454%_))
          (let ((__tmp5391
                 (gerbil-ascent/tools/research/candidate-interaction#wire
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%r2452%_ '1 '#f '#f)))))
            (declare (not safe))
            (__hash-put! _%ht2459%_ '"nativeStatus" __tmp5391))
          (let ((__tmp5392
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%r2452%_ '7 '#f '#f))))
            (declare (not safe))
            (__hash-put! _%ht2459%_ '"actual" __tmp5392))
          (let ((__tmp5393
                 (gerbil-ascent/tools/research/candidate-interaction#wire
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%f2456%_ '1 '#f '#f)))))
            (declare (not safe))
            (__hash-put! _%ht2459%_ '"status" __tmp5393))
          (let ((__tmp5394
                 (map (lambda (_%d2462%_)
                        (let ((_%ht2464%_
                               (let ()
                                 (declare (not safe))
                                 (make-hash-table__%
                                  '#f
                                  '2
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value))))
                          (let ((__tmp5395
                                 (gerbil-ascent/tools/research/candidate-interaction#wire
                                  (##structure-ref
                                   _%d2462%_
                                   '1
                                   gerbil-ascent/candidate/types#reasoning-diagnostic::t
                                   '#f))))
                            (declare (not safe))
                            (__hash-put! _%ht2464%_ '"code" __tmp5395))
                          (let ((__tmp5396
                                 (##structure-ref
                                  _%d2462%_
                                  '3
                                  gerbil-ascent/candidate/types#reasoning-diagnostic::t
                                  '#f)))
                            (declare (not safe))
                            (__hash-put! _%ht2464%_ '"detail" __tmp5396))
                          _%ht2464%_))
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref _%r2452%_ '8 '#f '#f)))))
            (declare (not safe))
            (__hash-put! _%ht2459%_ '"diagnostics" __tmp5394))
          (let ((__tmp5397
                 (gerbil-ascent/tools/research/candidate-interaction#wire
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%f2456%_ '2 '#f '#f)))))
            (declare (not safe))
            (__hash-put! _%ht2459%_ '"reason" __tmp5397))
          (let ((__tmp5398
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%f2456%_ '3 '#f '#f))))
            (declare (not safe))
            (__hash-put! _%ht2459%_ '"missing" __tmp5398))
          (let ((__tmp5399
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%f2456%_ '4 '#f '#f))))
            (declare (not safe))
            (__hash-put! _%ht2459%_ '"extra" __tmp5399))
          _%ht2459%_)))
    (define gerbil-ascent/tools/research/candidate-interaction#correct
      '(((path ?x ?y) (edge ?x ?y)) ((path ?x ?z) (path ?x ?y) (edge ?y ?z))))
    (define gerbil-ascent/tools/research/candidate-interaction#even-rules
      '(((path ?x ?z) (edge ?x ?y) (edge ?y ?z))
        ((path ?x ?w) (path ?x ?y) (edge ?y ?z) (edge ?z ?w))))
    (define gerbil-ascent/tools/research/candidate-interaction#both-rules
      (let ()
        (declare (not safe))
        (##append
         gerbil-ascent/tools/research/candidate-interaction#correct
         '(((both ?z) (left ?x) (right ?y) (path ?x ?z) (path ?y ?z))))))
    (define gerbil-ascent/tools/research/candidate-interaction#grade
      (lambda (_%case-id2436%_ _%rules2437%_)
        (let ((__tmp5403
               (lambda (_%mask2439%_)
                 (gerbil-ascent/tools/research/candidate-interaction#observe
                  _%case-id2436%_
                  _%mask2439%_
                  (gerbil-ascent/tools/research/candidate-interaction#graph
                   _%mask2439%_)
                  _%rules2437%_)))
              (__tmp5400
               (let ((__tmp5402
                      (lambda (_%mask2441%_)
                        (not (let ()
                               (declare (not safe))
                               (##member _%mask2441%_ '(0 1 3 9))))))
                     (__tmp5401
                      (gerbil-ascent/tools/research/candidate-interaction#ordinals
                       '64)))
                 (declare (not safe))
                 (##filter __tmp5402 __tmp5401))))
          (declare (not safe))
          (##map __tmp5403 __tmp5400))))
    (define gerbil-ascent/tools/research/candidate-interaction#qualification
      (lambda (_%group2318%_)
        (let ((_%checks2320%_ '0)
              (_%mutants2321%_
               (list gerbil-ascent/tools/research/candidate-interaction#correct
                     (let ()
                       (declare (not safe))
                       (##cdr gerbil-ascent/tools/research/candidate-interaction#correct))
                     (list (let ()
                             (declare (not safe))
                             (##car gerbil-ascent/tools/research/candidate-interaction#correct)))
                     '(((path ?x ?y) (edge ?x ?y))
                       ((path ?x ?z) (path ?x ?y) (edge ?x ?z)))
                     '(((path ?x ?y) (edge ?y ?x))
                       ((path ?x ?z) (path ?x ?y) (edge ?y ?z))))))
          (let ((__tmp5405
                 (lambda (_%rules2323%_ _%index2324%_)
                   (if (= _%group2318%_ _%index2324%_)
                       (let ((_%mismatches2326%_ '0))
                         (let ((__tmp5407
                                (lambda (_%mask2328%_)
                                  (let ((_%r2330%_
                                         (gerbil-ascent/tools/research/candidate-interaction#observe
                                          '0
                                          _%mask2328%_
                                          (gerbil-ascent/tools/research/candidate-interaction#graph
                                           _%mask2328%_)
                                          _%rules2323%_)))
                                    (if (string=?
                                         (let* ((_%h2332%_ _%r2330%_)
                                                (_%key2335%_ '"nativeStatus")
                                                (_%default2338%_ absent-obj)
                                                (_%h2342%_ _%h2332%_)
                                                (_%h2344%_ _%h2342%_))
                                           (declare (not safe))
                                           (__hash-ref__%
                                            _%h2344%_
                                            _%key2335%_
                                            _%default2338%_))
                                         '"complete")
                                        '#!void
                                        (let ()
                                          (declare (not safe))
                                          (error '"incomplete control"
                                                 _%r2330%_)))
                                    (if (string=?
                                         (let* ((_%h2362%_ _%r2330%_)
                                                (_%key2365%_ '"status")
                                                (_%default2368%_ absent-obj)
                                                (_%h2372%_ _%h2362%_)
                                                (_%h2374%_ _%h2372%_))
                                           (declare (not safe))
                                           (__hash-ref__%
                                            _%h2374%_
                                            _%key2365%_
                                            _%default2368%_))
                                         '"match")
                                        '#!void
                                        (set! _%mismatches2326%_
                                              (+ _%mismatches2326%_ '1)))
                                    (set! _%checks2320%_
                                          (+ _%checks2320%_ '1)))))
                               (__tmp5406
                                (gerbil-ascent/tools/research/candidate-interaction#ordinals
                                 '64)))
                           (declare (not safe))
                           (##for-each __tmp5407 __tmp5406))
                         (if (if (= _%index2324%_ '0)
                                 (= _%mismatches2326%_ '0)
                                 (> _%mismatches2326%_ '0))
                             '#!void
                             (let ()
                               (declare (not safe))
                               (error '"mutant control failed"))))
                       '#!void)))
                (__tmp5404
                 (gerbil-ascent/tools/research/candidate-interaction#ordinals
                  '5)))
            (declare (not safe))
            (##for-each __tmp5405 _%mutants2321%_ __tmp5404))
          (let ((__tmp5409
                 (lambda (_%id2386%_ _%rules2387%_)
                   (if (= _%group2318%_ (+ _%id2386%_ '4))
                       (let ((__tmp5411
                              (lambda (_%mask2389%_)
                                (if (string=?
                                     (let* ((_%h2391%_
                                             (gerbil-ascent/tools/research/candidate-interaction#observe
                                              _%id2386%_
                                              _%mask2389%_
                                              (gerbil-ascent/tools/research/candidate-interaction#graph
                                               _%mask2389%_)
                                              _%rules2387%_))
                                            (_%key2394%_ '"status")
                                            (_%default2397%_ absent-obj)
                                            (_%h2401%_ _%h2391%_)
                                            (_%h2403%_ _%h2401%_))
                                       (declare (not safe))
                                       (__hash-ref__%
                                        _%h2403%_
                                        _%key2394%_
                                        _%default2397%_))
                                     '"match")
                                    '#!void
                                    (let ()
                                      (declare (not safe))
                                      (error '"independent walk disagrees")))
                                (set! _%checks2320%_ (+ _%checks2320%_ '1))))
                             (__tmp5410
                              (gerbil-ascent/tools/research/candidate-interaction#ordinals
                               '64)))
                         (declare (not safe))
                         (##for-each __tmp5411 __tmp5410))
                       '#!void)))
                (__tmp5408
                 (list gerbil-ascent/tools/research/candidate-interaction#even-rules
                       gerbil-ascent/tools/research/candidate-interaction#both-rules)))
            (declare (not safe))
            (##for-each __tmp5409 '(1 2) __tmp5408))
          (if (= _%group2318%_ '7)
              (begin
                (let* ((_%s2417%_
                        (gerbil-ascent/tools/research/candidate-interaction#source
                         '0
                         '0
                         (gerbil-ascent/tools/research/candidate-interaction#graph
                          '8)))
                       (_%p2419%_
                        (gerbil-ascent/tools/research/candidate-interaction#proposal__0
                         '0
                         gerbil-ascent/tools/research/candidate-interaction#correct))
                       (_%r2421%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                           _%s2417%_
                           _%p2419%_
                           '#f))))
                  (if (eq? (let ((__tmp5412
                                  (let ((__tmp5414
                                         (gerbil-ascent/tools/research/candidate-interaction#source
                                          '0
                                          '1
                                          (gerbil-ascent/tools/research/candidate-interaction#graph
                                           '8)))
                                        (__tmp5413
                                         (gerbil-ascent/tools/research/candidate-interaction#expected
                                          '0
                                          (gerbil-ascent/tools/research/candidate-interaction#graph
                                           '8))))
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                                     __tmp5414
                                     _%p2419%_
                                     _%r2421%_
                                     __tmp5413))))
                             (declare (not safe))
                             (##unchecked-structure-ref __tmp5412 '2 '#f '#f))
                           'unbound)
                      '#!void
                      (let ()
                        (declare (not safe))
                        (error '"stale receipt accepted"))))
                (let* ((_%s2424%_
                        (gerbil-ascent/tools/research/candidate-interaction#source
                         '0
                         '0
                         (gerbil-ascent/tools/research/candidate-interaction#graph
                          '9)))
                       (_%p2426%_
                        (gerbil-ascent/tools/research/candidate-interaction#proposal__%
                         '0
                         gerbil-ascent/tools/research/candidate-interaction#correct
                         '1))
                       (_%r2428%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                           _%s2424%_
                           _%p2426%_
                           '#f)))
                       (_%f2430%_
                        (let ((__tmp5415
                               (gerbil-ascent/tools/research/candidate-interaction#expected
                                '0
                                (gerbil-ascent/tools/research/candidate-interaction#graph
                                 '9))))
                          (declare (not safe))
                          (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                           _%s2424%_
                           _%p2426%_
                           _%r2428%_
                           __tmp5415))))
                  (if (eq? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref _%f2430%_ '1 '#f '#f))
                           'match)
                      (let ()
                        (declare (not safe))
                        (error '"bounded failure became match"))
                      '#!void)))
              '#!void)
          (let ((_%ht2433%_
                 (let ()
                   (declare (not safe))
                   (make-hash-table__%
                    '#f
                    '3
                    absent-value
                    absent-value
                    absent-value
                    absent-value
                    absent-value
                    absent-value
                    absent-value))))
            (let ()
              (declare (not safe))
              (__hash-put! _%ht2433%_ '"checks" _%checks2320%_))
            (let ((__tmp5416 (= _%group2318%_ '7)))
              (declare (not safe))
              (__hash-put! _%ht2433%_ '"staleRejected" __tmp5416))
            (let ((__tmp5417 (= _%group2318%_ '7)))
              (declare (not safe))
              (__hash-put! _%ht2433%_ '"boundedNotMatch" __tmp5417))
            _%ht2433%_))))
    (define gerbil-ascent/tools/research/candidate-interaction#dispatch
      (lambda (_%request2198%_)
        (let ((_%op2225%_
               (let* ((_%h2200%_ _%request2198%_)
                      (_%key2203%_ '"op")
                      (_%default2206%_ absent-obj)
                      (_%h2210%_
                       (let ()
                         (declare (not safe))
                         (cast HashTable::interface _%h2200%_)))
                      (_%h2212%_ _%h2210%_))
                 (declare (not safe))
                 (__hash-ref__% _%h2212%_ _%key2203%_ _%default2206%_))))
          (if (string=? _%op2225%_ '"reuse-init")
              (gerbil-ascent/tools/research/candidate-interaction#reuse-init
               _%request2198%_)
              (if (string=? _%op2225%_ '"reuse-packet")
                  (gerbil-ascent/tools/research/candidate-interaction#reuse-packet
                   _%request2198%_)
                  (if (string=? _%op2225%_ '"reuse-episode")
                      (gerbil-ascent/tools/research/candidate-interaction#reuse-episode
                       _%request2198%_)
                      (if (string=? _%op2225%_ '"qualify")
                          (gerbil-ascent/tools/research/candidate-interaction#qualification
                           (let* ((_%h2231%_ _%request2198%_)
                                  (_%key2234%_ '"group")
                                  (_%default2237%_ absent-obj)
                                  (_%h2241%_
                                   (let ()
                                     (declare (not safe))
                                     (cast HashTable::interface _%h2231%_)))
                                  (_%h2243%_ _%h2241%_))
                             (declare (not safe))
                             (__hash-ref__%
                              _%h2243%_
                              _%key2234%_
                              _%default2237%_)))
                          (let* ((_%id2283%_
                                  (let* ((_%h2258%_ _%request2198%_)
                                         (_%key2261%_ '"case")
                                         (_%default2264%_ absent-obj)
                                         (_%h2268%_
                                          (let ()
                                            (declare (not safe))
                                            (cast HashTable::interface
                                                  _%h2258%_)))
                                         (_%h2270%_ _%h2268%_))
                                    (declare (not safe))
                                    (__hash-ref__%
                                     _%h2270%_
                                     _%key2261%_
                                     _%default2264%_)))
                                 (_%rules2310%_
                                  (gerbil-ascent/tools/research/candidate-interaction#symbols
                                   (let* ((_%h2285%_ _%request2198%_)
                                          (_%key2288%_ '"rules")
                                          (_%default2291%_ absent-obj)
                                          (_%h2295%_
                                           (let ()
                                             (declare (not safe))
                                             (cast HashTable::interface
                                                   _%h2285%_)))
                                          (_%h2297%_ _%h2295%_))
                                     (declare (not safe))
                                     (__hash-ref__%
                                      _%h2297%_
                                      _%key2288%_
                                      _%default2291%_)))))
                            (if (let ()
                                  (declare (not safe))
                                  (##member _%id2283%_ '(0 1 2)))
                                '#!void
                                (let ()
                                  (declare (not safe))
                                  (error '"invalid case")))
                            (if (string=? _%op2225%_ '"grade")
                                (gerbil-ascent/tools/research/candidate-interaction#grade
                                 _%id2283%_
                                 _%rules2310%_)
                                (if (string=? _%op2225%_ '"feedback")
                                    (let ((__tmp5418
                                           (lambda (_%mask2315%_)
                                             (gerbil-ascent/tools/research/candidate-interaction#observe
                                              _%id2283%_
                                              _%mask2315%_
                                              (gerbil-ascent/tools/research/candidate-interaction#graph
                                               _%mask2315%_)
                                              _%rules2310%_))))
                                      (declare (not safe))
                                      (##map __tmp5418 '(0 1 3 9)))
                                    (let ()
                                      (declare (not safe))
                                      (error '"invalid operation"))))))))))))
    (define gerbil-ascent/tools/research/candidate-interaction#reuse-store '#f)
    (define gerbil-ascent/tools/research/candidate-interaction#reuse-source
      '#f)
    (define gerbil-ascent/tools/research/candidate-interaction#reuse-handle
      '#f)
    (define gerbil-ascent/tools/research/candidate-interaction#reuse-needs '())
    (define gerbil-ascent/tools/research/candidate-interaction#reuse-candidate
      '(candidate
        (relation path 2)
        (relation ready 1)
        (rule (path ?x ?y) (edge ?x ?y))
        (rule (path ?x ?z) (path ?x ?y) (edge ?y ?z))
        (rule (ready ?f) (need ?f ?u ?v ?x ?y) (path ?u ?v) (path ?x ?y))
        (query ready ?f)
        (limits 256 1024 1024)))
    (define gerbil-ascent/tools/research/candidate-interaction#field
      (lambda (_%key2195%_ _%pairs2196%_)
        (cadr (assq _%key2195%_ _%pairs2196%_))))
    (define gerbil-ascent/tools/research/candidate-interaction#reuse-init
      (lambda (_%request2115%_)
        (set! gerbil-ascent/tools/research/candidate-interaction#reuse-store
              (let ()
                (declare (not safe))
                (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__0)))
        (set! gerbil-ascent/tools/research/candidate-interaction#reuse-needs
              (let* ((_%h2117%_ _%request2115%_)
                     (_%key2120%_ '"needs")
                     (_%default2123%_ absent-obj)
                     (_%h2127%_
                      (let ()
                        (declare (not safe))
                        (cast HashTable::interface _%h2117%_)))
                     (_%h2129%_ _%h2127%_))
                (declare (not safe))
                (__hash-ref__% _%h2129%_ _%key2120%_ _%default2123%_)))
        (set! gerbil-ascent/tools/research/candidate-interaction#reuse-source
              (let ((__tmp5420
                     (let* ((_%h2142%_ _%request2115%_)
                            (_%key2145%_ '"identity")
                            (_%default2148%_ absent-obj)
                            (_%h2152%_
                             (let ()
                               (declare (not safe))
                               (cast HashTable::interface _%h2142%_)))
                            (_%h2154%_ _%h2152%_))
                       (declare (not safe))
                       (__hash-ref__% _%h2154%_ _%key2145%_ _%default2148%_)))
                    (__tmp5419
                     (list (list 'edge
                                 '2
                                 (let* ((_%h2166%_ _%request2115%_)
                                        (_%key2169%_ '"edges")
                                        (_%default2172%_ absent-obj)
                                        (_%h2176%_
                                         (let ()
                                           (declare (not safe))
                                           (cast HashTable::interface
                                                 _%h2166%_)))
                                        (_%h2178%_ _%h2176%_))
                                   (declare (not safe))
                                   (__hash-ref__%
                                    _%h2178%_
                                    _%key2169%_
                                    _%default2172%_)))
                           (list 'need
                                 '5
                                 gerbil-ascent/tools/research/candidate-interaction#reuse-needs))))
                (declare (not safe))
                (gerbil-ascent/candidate/reasoning#reasoning-source-snapshot
                 __tmp5420
                 '0
                 __tmp5419)))
        (let ((_%answer2190%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                  gerbil-ascent/tools/research/candidate-interaction#reuse-store
                  gerbil-ascent/tools/research/candidate-interaction#reuse-source
                  gerbil-ascent/tools/research/candidate-interaction#reuse-candidate))))
          (if (eq? (gerbil-ascent/tools/research/candidate-interaction#field
                    'status
                    _%answer2190%_)
                   'verified)
              '#!void
              (let ()
                (declare (not safe))
                (error '"unverified source" _%answer2190%_)))
          (set! gerbil-ascent/tools/research/candidate-interaction#reuse-handle
                (gerbil-ascent/tools/research/candidate-interaction#field
                 'handle
                 _%answer2190%_))
          (let ((_%ht2192%_
                 (let ()
                   (declare (not safe))
                   (make-hash-table__%
                    '#f
                    '2
                    absent-value
                    absent-value
                    absent-value
                    absent-value
                    absent-value
                    absent-value
                    absent-value))))
            (let ((__tmp5421
                   (gerbil-ascent/tools/research/candidate-interaction#field
                    'rows
                    _%answer2190%_)))
              (declare (not safe))
              (__hash-put! _%ht2192%_ '"rows" __tmp5421))
            (let ((__tmp5422
                   (gerbil-ascent/tools/research/candidate-interaction#wire
                    (gerbil-ascent/tools/research/candidate-interaction#field
                     'scope
                     _%answer2190%_))))
              (declare (not safe))
              (__hash-put! _%ht2192%_ '"scope" __tmp5422))
            _%ht2192%_))))
    (define gerbil-ascent/tools/research/candidate-interaction#reuse-fact
      (lambda (_%atom2113%_)
        (let ()
          (declare (not safe))
          (gerbil-ascent/candidate/evidence-store#reasoning-evidence-fact
           gerbil-ascent/tools/research/candidate-interaction#reuse-store
           gerbil-ascent/tools/research/candidate-interaction#reuse-source
           gerbil-ascent/tools/research/candidate-interaction#reuse-candidate
           gerbil-ascent/tools/research/candidate-interaction#reuse-handle
           _%atom2113%_))))
    (define gerbil-ascent/tools/research/candidate-interaction#reuse-packet
      (lambda (_%request2037%_)
        (let* ((_%ids2064%_
                (let* ((_%h2039%_ _%request2037%_)
                       (_%key2042%_ '"fragments")
                       (_%default2045%_ absent-obj)
                       (_%h2049%_
                        (let ()
                          (declare (not safe))
                          (cast HashTable::interface _%h2039%_)))
                       (_%h2051%_ _%h2049%_))
                  (declare (not safe))
                  (__hash-ref__% _%h2051%_ _%key2042%_ _%default2045%_)))
               (_%answer2066%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                   gerbil-ascent/tools/research/candidate-interaction#reuse-store
                   gerbil-ascent/tools/research/candidate-interaction#reuse-source
                   gerbil-ascent/tools/research/candidate-interaction#reuse-candidate)))
               (_%atoms2076%_
                (let ((_%seen2068%_ '()))
                  (for-each
                   (lambda (_%id2070%_)
                     (let ((_%n2072%_
                            (assoc _%id2070%_
                                   gerbil-ascent/tools/research/candidate-interaction#reuse-needs)))
                       (if _%n2072%_
                           '#!void
                           (let ()
                             (declare (not safe))
                             (error '"unknown fragment" _%id2070%_)))
                       (let ((__tmp5424
                              (lambda (_%a2074%_)
                                (if (let ()
                                      (declare (not safe))
                                      (##member _%a2074%_ _%seen2068%_))
                                    '#!void
                                    (set! _%seen2068%_
                                          (cons _%a2074%_ _%seen2068%_)))))
                             (__tmp5423
                              (list (list 'ready _%id2070%_)
                                    (list 'path
                                          (list-ref _%n2072%_ '1)
                                          (list-ref _%n2072%_ '2))
                                    (list 'path
                                          (list-ref _%n2072%_ '3)
                                          (list-ref _%n2072%_ '4)))))
                         (declare (not safe))
                         (##for-each __tmp5424 __tmp5423))))
                   _%ids2064%_)
                  (let () (declare (not safe)) (##reverse _%seen2068%_))))
               (_%facts2078%_
                (let ()
                  (declare (not safe))
                  (##map gerbil-ascent/tools/research/candidate-interaction#reuse-fact
                         _%atoms2076%_)))
               (_%alternatives2082%_
                (map (lambda (_%id2080%_)
                       (list _%id2080%_ (list (list 'ready _%id2080%_))))
                     _%ids2064%_))
               (_%partition2084%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/evidence-store#reasoning-evidence-partition
                   gerbil-ascent/tools/research/candidate-interaction#reuse-store
                   gerbil-ascent/tools/research/candidate-interaction#reuse-source
                   gerbil-ascent/tools/research/candidate-interaction#reuse-candidate
                   gerbil-ascent/tools/research/candidate-interaction#reuse-handle
                   _%alternatives2082%_)))
               (_%pieces2088%_
                (map (lambda (_%id2086%_)
                       (let ((__tmp5425 (list 'ready _%id2086%_)))
                         (declare (not safe))
                         (gerbil-ascent/candidate/evidence-store#reasoning-evidence-fragment
                          gerbil-ascent/tools/research/candidate-interaction#reuse-store
                          gerbil-ascent/tools/research/candidate-interaction#reuse-source
                          gerbil-ascent/tools/research/candidate-interaction#reuse-candidate
                          gerbil-ascent/tools/research/candidate-interaction#reuse-handle
                          __tmp5425)))
                     _%ids2064%_))
               (_%nodes2096%_
                (let ((_%seen2090%_ '()))
                  (let ((__tmp5426
                         (lambda (_%piece2092%_)
                           (if (eq? (gerbil-ascent/tools/research/candidate-interaction#field
                                     'status
                                     _%piece2092%_)
                                    'verified)
                               (for-each
                                (lambda (_%node2094%_)
                                  (if (assoc (car _%node2094%_) _%seen2090%_)
                                      '#!void
                                      (set! _%seen2090%_
                                            (cons _%node2094%_ _%seen2090%_))))
                                (gerbil-ascent/tools/research/candidate-interaction#field
                                 'nodes
                                 _%piece2092%_))
                               '#!void))))
                    (declare (not safe))
                    (##for-each __tmp5426 _%pieces2088%_))
                  (let () (declare (not safe)) (##reverse _%seen2090%_))))
               (_%ht2099%_
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   '7
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value))))
          (let ((__tmp5427
                 (let ((__tmp5428
                        (lambda (_%a2102%_)
                          (let ((_%ht2104%_
                                 (let ()
                                   (declare (not safe))
                                   (make-hash-table__%
                                    '#f
                                    '2
                                    absent-value
                                    absent-value
                                    absent-value
                                    absent-value
                                    absent-value
                                    absent-value
                                    absent-value))))
                            (let ((__tmp5429
                                   (gerbil-ascent/tools/research/candidate-interaction#wire
                                    (gerbil-ascent/tools/research/candidate-interaction#field
                                     'atom
                                     _%a2102%_))))
                              (declare (not safe))
                              (__hash-put! _%ht2104%_ '"atom" __tmp5429))
                            (let ((__tmp5430
                                   (gerbil-ascent/tools/research/candidate-interaction#field
                                    'present
                                    _%a2102%_)))
                              (declare (not safe))
                              (__hash-put! _%ht2104%_ '"present" __tmp5430))
                            _%ht2104%_))))
                   (declare (not safe))
                   (##map __tmp5428 _%facts2078%_))))
            (declare (not safe))
            (__hash-put! _%ht2099%_ '"facts" __tmp5427))
          (let ((__tmp5431
                 (map (lambda (_%id2107%_ _%piece2108%_)
                        (let ((_%ht2110%_
                               (let ()
                                 (declare (not safe))
                                 (make-hash-table__%
                                  '#f
                                  '2
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value))))
                          (let ()
                            (declare (not safe))
                            (__hash-put! _%ht2110%_ '"id" _%id2107%_))
                          (let ((__tmp5432
                                 (if (eq? (gerbil-ascent/tools/research/candidate-interaction#field
                                           'status
                                           _%piece2108%_)
                                          'verified)
                                     (gerbil-ascent/tools/research/candidate-interaction#field
                                      'roots
                                      _%piece2108%_)
                                     '())))
                            (declare (not safe))
                            (__hash-put! _%ht2110%_ '"roots" __tmp5432))
                          _%ht2110%_))
                      _%ids2064%_
                      _%pieces2088%_)))
            (declare (not safe))
            (__hash-put! _%ht2099%_ '"fragments" __tmp5431))
          (let ((__tmp5433
                 (gerbil-ascent/tools/research/candidate-interaction#wire
                  _%nodes2096%_)))
            (declare (not safe))
            (__hash-put! _%ht2099%_ '"nodes" __tmp5433))
          (let ((__tmp5434
                 (gerbil-ascent/tools/research/candidate-interaction#field
                  'allowed
                  _%partition2084%_)))
            (declare (not safe))
            (__hash-put! _%ht2099%_ '"allowed" __tmp5434))
          (let ((__tmp5435
                 (gerbil-ascent/tools/research/candidate-interaction#field
                  'pruned
                  _%partition2084%_)))
            (declare (not safe))
            (__hash-put! _%ht2099%_ '"pruned" __tmp5435))
          (let ((__tmp5436
                 (gerbil-ascent/tools/research/candidate-interaction#field
                  'reused
                  _%answer2066%_)))
            (declare (not safe))
            (__hash-put! _%ht2099%_ '"reused" __tmp5436))
          (let ((__tmp5437
                 (gerbil-ascent/tools/research/candidate-interaction#wire
                  (let ()
                    (declare (not safe))
                    (gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-stats
                     gerbil-ascent/tools/research/candidate-interaction#reuse-store)))))
            (declare (not safe))
            (__hash-put! _%ht2099%_ '"stats" __tmp5437))
          _%ht2099%_)))
    (define gerbil-ascent/tools/research/candidate-interaction#reuse-episode
      (lambda (_%request1958%_)
        (let* ((_%atom1985%_
                (gerbil-ascent/tools/research/candidate-interaction#symbols
                 (let* ((_%h1960%_ _%request1958%_)
                        (_%key1963%_ '"atom")
                        (_%default1966%_ absent-obj)
                        (_%h1970%_
                         (let ()
                           (declare (not safe))
                           (cast HashTable::interface _%h1960%_)))
                        (_%h1972%_ _%h1970%_))
                   (declare (not safe))
                   (__hash-ref__% _%h1972%_ _%key1963%_ _%default1966%_))))
               (_%premises2012%_
                (gerbil-ascent/tools/research/candidate-interaction#symbols
                 (let* ((_%h1987%_ _%request1958%_)
                        (_%key1990%_ '"premises")
                        (_%default1993%_ absent-obj)
                        (_%h1997%_
                         (let ()
                           (declare (not safe))
                           (cast HashTable::interface _%h1987%_)))
                        (_%h1999%_ _%h1997%_))
                   (declare (not safe))
                   (__hash-ref__% _%h1999%_ _%key1990%_ _%default1993%_))))
               (_%present?2016%_
                (lambda (_%a2014%_)
                  (eq? (gerbil-ascent/tools/research/candidate-interaction#field
                        'status
                        (gerbil-ascent/tools/research/candidate-interaction#reuse-fact
                         _%a2014%_))
                       'verified)))
               (_%supported2031%_
                (if (pair? _%premises2012%_)
                    (if (let ()
                          (declare (not safe))
                          (andmap__0 _%present?2016%_ _%premises2012%_))
                        (let ((_%$e2018%_ (car _%atom1985%_)))
                          (if (eq? 'ready _%$e2018%_)
                              (let ((_%n2021%_
                                     (assoc (cadr _%atom1985%_)
                                            gerbil-ascent/tools/research/candidate-interaction#reuse-needs)))
                                (if _%n2021%_
                                    (equal? _%premises2012%_
                                            (list (list 'path
                                                        (list-ref _%n2021%_ '1)
                                                        (list-ref
                                                         _%n2021%_
                                                         '2))
                                                  (list 'path
                                                        (list-ref _%n2021%_ '3)
                                                        (list-ref
                                                         _%n2021%_
                                                         '4))))
                                    '#f))
                              (if (eq? 'path _%$e2018%_)
                                  (if (or (pair? (let ()
                                                   (declare (not safe))
                                                   (##cdr _%premises2012%_)))
                                          (eq? (caar _%premises2012%_) 'edge))
                                      (let _%loop2026%_ ((_%at2028%_
                                                          (cadr _%atom1985%_))
                                                         (_%rest2029%_
                                                          _%premises2012%_))
                                        (if (null? _%rest2029%_)
                                            (= _%at2028%_ (caddr _%atom1985%_))
                                            (if (let ((__tmp5438
                                                       (caar _%rest2029%_)))
                                                  (declare (not safe))
                                                  (##memq __tmp5438
                                                          '(edge path)))
                                                (if (= _%at2028%_
                                                       (cadar _%rest2029%_))
                                                    (_%loop2026%_
                                                     (caddar _%rest2029%_)
                                                     (cdr _%rest2029%_))
                                                    '#f)
                                                '#f)))
                                      '#f)
                                  '#f)))
                        '#f)
                    '#f))
               (_%ht2034%_
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   '2
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value))))
          (let ((__tmp5439 (_%present?2016%_ _%atom1985%_)))
            (declare (not safe))
            (__hash-put! _%ht2034%_ '"present" __tmp5439))
          (let ((__tmp5440 (if _%supported2031%_ '#t '#f)))
            (declare (not safe))
            (__hash-put! _%ht2034%_ '"supportQualified" __tmp5440))
          _%ht2034%_)))
    (define gerbil-ascent/tools/research/candidate-interaction#main
      (lambda _%args1887%_
        (if (let ()
              (declare (not safe))
              (##member '"--dynamic-evidence" _%args1887%_))
            (let ((_%before1889%_
                   gerbil-ascent/candidate/evidence-store#GerbilAscentEvidenceStoreContract))
              (load (path-expand
                     '"lib/gerbil-ascent/candidate/evidence-store.o1"
                     (let () (declare (not safe)) (##getenv '"GERBIL_PATH"))))
              (if (eq? _%before1889%_
                       gerbil-ascent/candidate/evidence-store#GerbilAscentEvidenceStoreContract)
                  (let ()
                    (declare (not safe))
                    (error '"dynamic module did not initialize"))
                  '#!void))
            '#!void)
        (let () (declare (not safe)) (displayln '"{\"ready\":true}"))
        (force-output)
        (let _%loop1891%_ ()
          (let ((_%line1894%_ (read-line)))
            (if (eof-object? _%line1894%_)
                '#!void
                (begin
                  (let ((__tmp5441
                         (let ((__tmp5442
                                (let ((__tmp5446
                                       (lambda (_%$%g18951897%_)
                                         (let* ((_%e1901%_ _%$%g18951897%_)
                                                (_%ht1903%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (make-hash-table__%
                                                    '#f
                                                    '1
                                                    absent-value
                                                    absent-value
                                                    absent-value
                                                    absent-value
                                                    absent-value
                                                    absent-value
                                                    absent-value))))
                                           (let ((__tmp5447
                                                  (let ()
                                                    (declare (not safe))
                                                    (std/error#exception->string
                                                     _%e1901%_))))
                                             (declare (not safe))
                                             (__hash-put!
                                              _%ht1903%_
                                              '"error"
                                              __tmp5447))
                                           _%ht1903%_)))
                                      (__tmp5443
                                       (lambda ()
                                         (gerbil-ascent/tools/research/candidate-interaction#dispatch
                                          (let ((__tmp5445
                                                 (lambda ()
                                                   (call-with-input-string
                                                    _%line1894%_
                                                    std/encoding/json/util#read-json)))
                                                (__tmp5444
                                                 (let* ((_%object-as-hash1909%_
                                                         '#t)
                                                        (_%key-as-symbol1912%_
                                                         '#f)
                                                        (_%array-as-vector1915%_
                                                         '#f)
                                                        (_%key-as-symbol1920%_
                                                         _%key-as-symbol1912%_)
                                                        (_%array-as-vector1938%_
                                                         _%array-as-vector1915%_)
                                                        (_%object-as-hash1948%_
                                                         _%object-as-hash1909%_))
                                                   (declare (not safe))
                                                   (std/encoding/json/env#__make-JSONReadOptions__%
                                                    '#f
                                                    _%key-as-symbol1920%_
                                                    _%array-as-vector1938%_
                                                    _%object-as-hash1948%_))))
                                            (declare (not safe))
                                            (call-with-parameters__1
                                             __tmp5445
                                             std/encoding/json/env#current-json-read-options
                                             __tmp5444))))))
                                  (declare (not safe))
                                  (__with-catch __tmp5446 __tmp5443))))
                           (declare (not safe))
                           (std/encoding/json/util#json->string __tmp5442))))
                    (declare (not safe))
                    (displayln __tmp5441))
                  (force-output)
                  (_%loop1891%_)))))))))
