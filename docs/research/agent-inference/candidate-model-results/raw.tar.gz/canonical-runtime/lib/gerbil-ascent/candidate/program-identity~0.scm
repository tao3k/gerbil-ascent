(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/program-identity::timestamp 1791689689)
  (begin
    (define gerbil-ascent/candidate/program-identity#entry-datum
      (lambda (_%entry27287%_)
        (list (vector-ref _%entry27287%_ '0)
              (vector-ref _%entry27287%_ '1)
              (vector-ref _%entry27287%_ '2))))
    (define gerbil-ascent/candidate/program-identity#program-shape
      (lambda (_%spec27285%_)
        (list (##structure-ref
               _%spec27285%_
               '1
               gerbil-ascent/candidate/types#reasoning-candidate::t
               '#f)
              (map gerbil-ascent/candidate/program-identity#entry-datum
                   (##structure-ref
                    _%spec27285%_
                    '2
                    gerbil-ascent/candidate/types#reasoning-candidate::t
                    '#f))
              (map gerbil-ascent/candidate/program-identity#entry-datum
                   (##structure-ref
                    _%spec27285%_
                    '3
                    gerbil-ascent/candidate/types#reasoning-candidate::t
                    '#f))
              (vector-ref
               (##structure-ref
                _%spec27285%_
                '4
                gerbil-ascent/candidate/types#reasoning-candidate::t
                '#f)
               '0)
              (##structure-ref
               _%spec27285%_
               '5
               gerbil-ascent/candidate/types#reasoning-candidate::t
               '#f))))
    (define gerbil-ascent/candidate/program-identity#datum-fingerprint
      (lambda (_%datum27215%_)
        (let* ((_%bytes27236%_
                (let* ((_%bytes27219%_
                        (let ((__tmp35106
                               (call-with-output-string
                                '""
                                (lambda (_%port27217%_)
                                  (write _%datum27215%_ _%port27217%_)))))
                          (declare (not safe))
                          (##string->utf8 __tmp35106)))
                       (_%bytes27224%_ _%bytes27219%_))
                  (declare (not safe))
                  (std/crypto/digest#__sha256 _%bytes27224%_)))
               (_%start27239%_ '0)
               (_%end27242%_
                (let ()
                  (declare (not safe))
                  (##u8vector-length _%bytes27236%_)))
               (_%bytes27247%_ _%bytes27236%_))
          (if (and (let () (declare (not safe)) (##fx>= _%start27239%_ '0))
                   (let ((__tmp35107
                          (let ((__tmp35108
                                 (let ()
                                   (declare (not safe))
                                   (##u8vector-length _%bytes27247%_))))
                            (declare (not safe))
                            (##fxmax __tmp35108 '1))))
                     (declare (not safe))
                     (##fx< _%start27239%_ __tmp35107)))
              (let ((_%start27262%_ _%start27239%_))
                (if (let ((__tmp35109
                           (let ()
                             (declare (not safe))
                             (##u8vector-length _%bytes27247%_))))
                      (declare (not safe))
                      (##fx<= _%start27262%_ _%end27242%_ __tmp35109))
                    (let ((_%end27275%_ _%end27242%_))
                      (declare (not safe))
                      (std/encoding/hex#__hex-encode__%
                       _%bytes27247%_
                       _%start27262%_
                       _%end27275%_))
                    (begin
                      (raise-contract-violation-error
                       '"contract violation"
                       'context:
                       'gerbil-ascent/candidate/program-identity
                       'contract:
                       '(in-range-inclusive? start (u8vector-length bytes))
                       'value:
                       _%end27242%_)
                      '#!void)))
              (begin
                (raise-contract-violation-error
                 '"contract violation"
                 'context:
                 'gerbil-ascent/candidate/program-identity
                 'contract:
                 '(in-range? 0 (fxmax (u8vector-length bytes) 1))
                 'value:
                 _%start27239%_)
                '#!void)))))
    (define gerbil-ascent/candidate/program-identity#candidate-finite-program-fingerprint
      (lambda (_%spec27213%_)
        (gerbil-ascent/candidate/program-identity#datum-fingerprint
         (gerbil-ascent/candidate/program-identity#program-shape
          _%spec27213%_))))
    (define gerbil-ascent/candidate/program-identity#candidate-positive-program-fingerprint
      (lambda (_%spec27211%_)
        (gerbil-ascent/candidate/program-identity#datum-fingerprint
         (cons 'positive-program-v1
               (gerbil-ascent/candidate/program-identity#program-shape
                _%spec27211%_)))))))
