(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/stratified-proof::timestamp 1791687892)
  (begin
    (define gerbil-ascent/candidate/stratified-proof#+max-proof-nodes+ '4096)
    (define gerbil-ascent/candidate/stratified-proof#+max-proof-datum-nodes+
      '65536)
    (define gerbil-ascent/candidate/stratified-proof#ground-row?
      (lambda (_%row28777%_ _%arity28778%_)
        (if (list? _%row28777%_)
            (if (= (let () (declare (not safe)) (##length _%row28777%_))
                   _%arity28778%_)
                (let ((__tmp37862
                       (lambda (_%term28780%_)
                         (if (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program#scalar?
                                _%term28780%_))
                             (if (let ()
                                   (declare (not safe))
                                   (gerbil-ascent/candidate/program#candidate-variable?
                                    _%term28780%_))
                                 '#f
                                 (not (eq? _%term28780%_ '?_)))
                             '#f))))
                  (declare (not safe))
                  (andmap__0 __tmp37862 _%row28777%_))
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/stratified-proof#same-distinct-rows?
      (lambda (_%supplied28767%_ _%actual28768%_ _%step!28769%_)
        (if (= (length _%supplied28767%_) (length _%actual28768%_))
            (let ((_%index28771%_
                   (let ()
                     (declare (not safe))
                     (make-hash-table__%
                      '#f
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value))))
              (if (let ((__tmp37863
                         (lambda (_%row28773%_)
                           (and (_%step!28769%_)
                                (begin
                                  (let ()
                                    (declare (not safe))
                                    (__hash-put!
                                     _%index28771%_
                                     _%row28773%_
                                     '#t))
                                  '#t)))))
                    (declare (not safe))
                    (andmap__0 __tmp37863 _%actual28768%_))
                  (let ((__tmp37864
                         (lambda (_%row28775%_)
                           (if (_%step!28769%_)
                               (if (let ()
                                     (declare (not safe))
                                     (__hash-get _%index28771%_ _%row28775%_))
                                   (begin
                                     (let ()
                                       (declare (not safe))
                                       (__hash-put!
                                        _%index28771%_
                                        _%row28775%_
                                        '#f))
                                     '#t)
                                   '#f)
                               '#f))))
                    (declare (not safe))
                    (andmap__0 __tmp37864 _%supplied28767%_))
                  '#f))
            '#f)))
    (define gerbil-ascent/candidate/stratified-proof#candidate-verify-stratified-proof
      (lambda (_%snapshot28599%_
               _%spec28600%_
               _%candidate-digest28601%_
               _%native-status28602%_
               _%native-rows28603%_
               _%finite-certificate28604%_
               _%finite-work-budget28605%_
               _%proof28606%_
               _%proof-work-budget28607%_)
        (if (and (exact-integer? _%proof-work-budget28607%_)
                 (> _%proof-work-budget28607%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"stratified proof needs positive work budget"
                     _%proof-work-budget28607%_)))
        (if (and (let ()
                   (declare (not safe))
                   (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                    _%proof28606%_
                    gerbil-ascent/candidate/stratified-proof#+max-proof-datum-nodes+
                    '128))
                 (list? _%proof28606%_)
                 (= (let () (declare (not safe)) (##length _%proof28606%_)) '3)
                 (eq? (car _%proof28606%_) 'stratified-proof-v1)
                 (list? (cadr _%proof28606%_))
                 (<= (length (cadr _%proof28606%_))
                     gerbil-ascent/candidate/stratified-proof#+max-proof-nodes+)
                 (list? (caddr _%proof28606%_))
                 (<= (length (caddr _%proof28606%_))
                     gerbil-ascent/candidate/stratified-proof#+max-proof-nodes+))
            (let ((_g37865_
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/finite-evidence#candidate-verified-finite-closure
                      _%snapshot28599%_
                      _%spec28600%_
                      _%candidate-digest28601%_
                      _%native-status28602%_
                      _%native-rows28603%_
                      _%finite-certificate28604%_
                      _%finite-work-budget28605%_))))
              (begin
                (let ((_g37866_
                       (let ()
                         (declare (not safe))
                         (if (##values? _g37865_)
                             (##values-length _g37865_)
                             1))))
                  (if (not (let () (declare (not safe)) (##fx= _g37866_ 2)))
                      (error "Context expects 2 values" _g37866_)))
                (let ((_%finite-verdict28609%_
                       (let () (declare (not safe)) (##values-ref _g37865_ 0)))
                      (_%closure28610%_
                       (let ()
                         (declare (not safe))
                         (##values-ref _g37865_ 1))))
                  (if (eq? _%finite-verdict28609%_ 'valid)
                      (if (null? _%native-rows28603%_)
                          'unsupported
                          (let* ((_%schema28612%_
                                  (let ()
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/funs#candidate-schema-of
                                     _%snapshot28599%_
                                     _%spec28600%_)))
                                 (_%rules28614%_
                                  (##structure-ref
                                   _%spec28600%_
                                   '3
                                   gerbil-ascent/candidate/types#reasoning-candidate::t
                                   '#f))
                                 (_%levels28616%_
                                  (let ()
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/funs#candidate-strata-of
                                     _%schema28612%_
                                     _%rules28614%_)))
                                 (_%model28618%_
                                  (let ((__tmp37867
                                         (##structure-ref
                                          _%snapshot28599%_
                                          '4
                                          gerbil-ascent/candidate/types#reasoning-snapshot::t
                                          '#f)))
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/closure-index#make-closure-index__%
                                     _%closure28610%_
                                     __tmp37867)))
                                 (_%nodes28620%_ (cadr _%proof28606%_))
                                 (_%roots28622%_ (caddr _%proof28606%_))
                                 (_%by-id28624%_ (list->vector _%nodes28620%_))
                                 (_%query28626%_
                                  (vector-ref
                                   (##structure-ref
                                    _%spec28600%_
                                    '4
                                    gerbil-ascent/candidate/types#reasoning-candidate::t
                                    '#f)
                                   '0))
                                 (_%steps28628%_ '0)
                                 (_%bounded?28630%_ '#f))
                            (letrec ((_%step!28633%_
                                      (lambda ()
                                        (set! _%steps28628%_
                                              (+ _%steps28628%_ '1))
                                        (if (> _%steps28628%_
                                               _%proof-work-budget28607%_)
                                            (set! _%bounded?28630%_ '#t)
                                            '#!void)
                                        (not _%bounded?28630%_)))
                                     (_%rows28634%_
                                      (lambda (_%name28764%_)
                                        (let ()
                                          (declare (not safe))
                                          (gerbil-ascent/candidate/closure-index#closure-index-rows
                                           _%model28618%_
                                           _%name28764%_))))
                                     (_%node-ref28635%_
                                      (lambda (_%id28758%_
                                               _%before28759%_
                                               _%relation28760%_)
                                        (if (exact-integer? _%id28758%_)
                                            (if (<= '0 _%id28758%_)
                                                (if (< _%id28758%_
                                                       _%before28759%_)
                                                    (let ((_%node28762%_
                                                           (vector-ref
                                                            _%by-id28624%_
                                                            _%id28758%_)))
                                                      (if (eq? (cadr _%node28762%_)
                                                               _%relation28760%_)
                                                          _%node28762%_
                                                          '#f))
                                                    '#f)
                                                '#f)
                                            '#f)))
                                     (_%strict-lower?28636%_
                                      (lambda (_%head28755%_
                                               _%dependency28756%_)
                                        (> (cdr (let ()
                                                  (declare (not safe))
                                                  (gerbil-ascent/candidate/funs#candidate-required-entry
                                                   _%head28755%_
                                                   _%levels28616%_)))
                                           (cdr (let ()
                                                  (declare (not safe))
                                                  (gerbil-ascent/candidate/funs#candidate-required-entry
                                                   _%dependency28756%_
                                                   _%levels28616%_))))))
                                     (_%no-match?28637%_
                                      (lambda (_%atom28750%_ _%bindings28751%_)
                                        (let ((__tmp37869
                                               (lambda (_%row28753%_)
                                                 (if (_%step!28633%_)
                                                     (not (let ()
                                                            (declare
                                                              (not safe))
                                                            (gerbil-ascent/candidate/funs#candidate-bind-atom
                                                             _%atom28750%_
                                                             _%row28753%_
                                                             _%bindings28751%_)))
                                                     '#f)))
                                              (__tmp37868
                                               (_%rows28634%_
                                                (car _%atom28750%_))))
                                          (declare (not safe))
                                          (andmap__0 __tmp37869 __tmp37868))))
                                     (_%reduction-bindings28638%_
                                      (lambda (_%clause28720%_
                                               _%witness28721%_
                                               _%bindings28722%_
                                               _%before28723%_
                                               _%head28724%_)
                                        (let ((_%atom28726%_
                                               (cadddr _%clause28720%_))
                                              (_%operator28727%_
                                               (caddr _%clause28720%_)))
                                          (if (list? _%witness28721%_)
                                              (if (= (let ()
                                                       (declare (not safe))
                                                       (##length
                                                        _%witness28721%_))
                                                     '2)
                                                  (if (eq? (car _%witness28721%_)
                                                           'reduce)
                                                      (if (list? (cadr _%witness28721%_))
                                                          (if (_%strict-lower?28636%_
                                                               _%head28724%_
                                                               (car _%atom28726%_))
                                                              (let ((_%matched28731%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (filter (lambda (_%row28729%_)
                                       (if (_%step!28633%_)
                                           (let ()
                                             (declare (not safe))
                                             (gerbil-ascent/candidate/funs#candidate-bind-atom
                                              _%atom28726%_
                                              _%row28729%_
                                              _%bindings28722%_))
                                           '#f))
                                     (_%rows28634%_ (car _%atom28726%_))))
                            (_%supplied28732%_ '()))
                        (if _%bounded?28630%_
                            '#f
                            (if (let ((__tmp37871
                                       (lambda (_%id28734%_)
                                         (let ((_%node28736%_
                                                (_%node-ref28635%_
                                                 _%id28734%_
                                                 _%before28723%_
                                                 (car _%atom28726%_))))
                                           (and (_%step!28633%_)
                                                _%node28736%_
                                                (let ((__tmp37872
                                                       (caddr _%node28736%_)))
                                                  (declare (not safe))
                                                  (gerbil-ascent/candidate/funs#candidate-bind-atom
                                                   _%atom28726%_
                                                   __tmp37872
                                                   _%bindings28722%_))
                                                (begin
                                                  (set! _%supplied28732%_
                                                        (cons (caddr _%node28736%_)
                                                              _%supplied28732%_))
                                                  '#t)))))
                                      (__tmp37870 (cadr _%witness28721%_)))
                                  (declare (not safe))
                                  (andmap__0 __tmp37871 __tmp37870))
                                (if (gerbil-ascent/candidate/stratified-proof#same-distinct-rows?
                                     _%supplied28732%_
                                     _%matched28731%_
                                     _%step!28633%_)
                                    (let* ((_%values28742%_
                                            (if (eq? (car _%operator28727%_)
                                                     'count)
                                                '()
                                                (let ((__tmp37873
                                                       (lambda (_%row28738%_)
                                                         (let ((_%next28740%_
                                                                (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gerbil-ascent/candidate/funs#candidate-bind-atom
                           _%atom28726%_
                           _%row28738%_
                           _%bindings28722%_))))
                   (if _%next28740%_
                       (cdr (let ((__tmp37874 (cadr _%operator28727%_)))
                              (declare (not safe))
                              (gerbil-ascent/candidate/funs#candidate-required-entry
                               __tmp37874
                               _%next28740%_)))
                       '#f)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (declare (not safe))
                                                  (##map __tmp37873
                                                         _%supplied28732%_))))
                                           (_%value28747%_
                                            (let ((_%$e28744%_
                                                   (car _%operator28727%_)))
                                              (if (eq? 'count _%$e28744%_)
                                                  (let ()
                                                    (declare (not safe))
                                                    (##length
                                                     _%supplied28732%_))
                                                  (if (eq? 'sum _%$e28744%_)
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (andmap__0
                                                             exact-integer?
                                                             _%values28742%_))
                                                          (apply +
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '0
                         _%values28742%_)
                  '#f)
              (if (eq? 'min _%$e28744%_)
                  (if (pair? _%values28742%_)
                      (if (let ()
                            (declare (not safe))
                            (andmap__0 exact-integer? _%values28742%_))
                          (let ()
                            (declare (not safe))
                            (##apply min _%values28742%_))
                          '#f)
                      '#f)
                  (if (eq? 'max _%$e28744%_)
                      (if (pair? _%values28742%_)
                          (if (let ()
                                (declare (not safe))
                                (andmap__0 exact-integer? _%values28742%_))
                              (let ()
                                (declare (not safe))
                                (##apply max _%values28742%_))
                              '#f)
                          '#f)
                      '#f)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                      (if _%value28747%_
                                          (cons (cons (cadr _%clause28720%_)
                                                      _%value28747%_)
                                                _%bindings28722%_)
                                          '#f))
                                    '#f)
                                '#f)))
                      '#f)
                  '#f)
              '#f)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  '#f)
                                              '#f))))
                                     (_%rule-node-valid?28639%_
                                      (lambda (_%node28676%_ _%index28677%_)
                                        (let* ((_%rule28681%_
                                                (let ((__tmp37875
                                                       (lambda (_%candidate28679%_)
                                                         (equal? (cadddr _%node28676%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (vector-ref _%candidate28679%_ '2)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (declare (not safe))
                                                  (__find __tmp37875
                                                          _%rules28614%_)))
                                               (_%head28683%_
                                                (if _%rule28681%_
                                                    (vector-ref
                                                     _%rule28681%_
                                                     '0)
                                                    '#f))
                                               (_%body28685%_
                                                (if _%rule28681%_
                                                    (vector-ref
                                                     _%rule28681%_
                                                     '1)
                                                    '#f))
                                               (_%witnesses28687%_
                                                (list-ref _%node28676%_ '4)))
                                          (if _%rule28681%_
                                              (if (eq? (cadr _%node28676%_)
                                                       (car _%head28683%_))
                                                  (if (list? _%witnesses28687%_)
                                                      (if (= (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##length _%witnesses28687%_))
                     (length _%body28685%_))
                  (let _%loop28690%_ ((_%clauses28692%_ _%body28685%_)
                                      (_%evidence28693%_ _%witnesses28687%_)
                                      (_%bindings28694%_ '()))
                    (if (null? _%clauses28692%_)
                        (if (null? _%evidence28693%_)
                            (if (let ((__tmp37877
                                       (lambda (_%term28696%_)
                                         (or (not (let ()
                                                    (declare (not safe))
                                                    (gerbil-ascent/candidate/program#candidate-variable?
                                                     _%term28696%_)))
                                             (assq _%term28696%_
                                                   _%bindings28694%_))))
                                      (__tmp37876 (cdr _%head28683%_)))
                                  (declare (not safe))
                                  (andmap__0 __tmp37877 __tmp37876))
                                (equal? (caddr _%node28676%_)
                                        (map (lambda (_%term28701%_)
                                               (if (let ()
                                                     (declare (not safe))
                                                     (gerbil-ascent/candidate/program#candidate-variable?
                                                      _%term28701%_))
                                                   (cdr (let ()
                                                          (declare (not safe))
                                                          (gerbil-ascent/candidate/funs#candidate-required-entry
                                                           _%term28701%_
                                                           _%bindings28694%_)))
                                                   _%term28701%_))
                                             (cdr _%head28683%_)))
                                '#f)
                            '#f)
                        (let ((_%clause28703%_ (car _%clauses28692%_))
                              (_%witness28704%_ (car _%evidence28693%_)))
                          (let ((_%$e28706%_ (car _%clause28703%_)))
                            (if (or (eq? 'where _%$e28706%_)
                                    (eq? 'compute _%$e28706%_))
                                (if (equal? _%witness28704%_ '(fixed))
                                    (if (_%step!28633%_)
                                        (let ((_%next28712%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gerbil-ascent/candidate/funs#candidate-fixed-clause
                                                  _%clause28703%_
                                                  _%bindings28694%_))))
                                          (if _%next28712%_
                                              (_%loop28690%_
                                               (cdr _%clauses28692%_)
                                               (cdr _%evidence28693%_)
                                               _%next28712%_)
                                              '#f))
                                        '#f)
                                    '#f)
                                (if (eq? 'not _%$e28706%_)
                                    (if (equal? _%witness28704%_ '(not))
                                        (if (_%strict-lower?28636%_
                                             (car _%head28683%_)
                                             (caadr _%clause28703%_))
                                            (if (_%no-match?28637%_
                                                 (cadr _%clause28703%_)
                                                 _%bindings28694%_)
                                                (_%loop28690%_
                                                 (cdr _%clauses28692%_)
                                                 (cdr _%evidence28693%_)
                                                 _%bindings28694%_)
                                                '#f)
                                            '#f)
                                        '#f)
                                    (if (eq? 'reduce _%$e28706%_)
                                        (let ((_%next28714%_
                                               (_%reduction-bindings28638%_
                                                _%clause28703%_
                                                _%witness28704%_
                                                _%bindings28694%_
                                                _%index28677%_
                                                (car _%head28683%_))))
                                          (if _%next28714%_
                                              (_%loop28690%_
                                               (cdr _%clauses28692%_)
                                               (cdr _%evidence28693%_)
                                               _%next28714%_)
                                              '#f))
                                        (if (list? _%witness28704%_)
                                            (if (= (let ()
                                                     (declare (not safe))
                                                     (##length
                                                      _%witness28704%_))
                                                   '2)
                                                (if (eq? (car _%witness28704%_)
                                                         'atom)
                                                    (let ((_%input28716%_
                                                           (_%node-ref28635%_
                                                            (cadr _%witness28704%_)
                                                            _%index28677%_
                                                            (car _%clause28703%_))))
                                                      (if (_%step!28633%_)
                                                          (if _%input28716%_
                                                              (let ((_%next28718%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (let ((__tmp37878 (caddr _%input28716%_)))
                               (declare (not safe))
                               (gerbil-ascent/candidate/funs#candidate-bind-atom
                                _%clause28703%_
                                __tmp37878
                                _%bindings28694%_))))
                        (if _%next28718%_
                            (_%loop28690%_
                             (cdr _%clauses28692%_)
                             (cdr _%evidence28693%_)
                             _%next28718%_)
                            '#f))
                      '#f)
                  '#f))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '#f)
                                                '#f)
                                            '#f))))))))
                  '#f)
              '#f)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  '#f)
                                              '#f))))
                                     (_%node-valid?28640%_
                                      (lambda (_%node28664%_ _%index28665%_)
                                        (if (_%step!28633%_)
                                            (if (list? _%node28664%_)
                                                (if (= (let ()
                                                         (declare (not safe))
                                                         (##length
                                                          _%node28664%_))
                                                       '5)
                                                    (if (let ((__tmp37879
                                                               (car _%node28664%_)))
                                                          (declare (not safe))
                                                          (##memq __tmp37879
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          '(source candidate rule)))
                (if (symbol? (cadr _%node28664%_))
                    (if (let ((_%declaration28667%_
                               (assq (cadr _%node28664%_) _%schema28612%_)))
                          (and _%declaration28667%_
                               (gerbil-ascent/candidate/stratified-proof#ground-row?
                                (caddr _%node28664%_)
                                (cdr _%declaration28667%_))
                               (let ((__tmp37881 (cadr _%node28664%_))
                                     (__tmp37880 (caddr _%node28664%_)))
                                 (declare (not safe))
                                 (gerbil-ascent/candidate/closure-index#closure-index-member?
                                  _%model28618%_
                                  __tmp37881
                                  __tmp37880))))
                        (if (list? (list-ref _%node28664%_ '4))
                            (let ((_%$e28669%_ (car _%node28664%_)))
                              (if (eq? 'source _%$e28669%_)
                                  (if (null? (list-ref _%node28664%_ '4))
                                      (let ((_%source28672%_
                                             (let ((__tmp37882
                                                    (cadr _%node28664%_)))
                                               (declare (not safe))
                                               (gerbil-ascent/candidate/closure-index#closure-index-source
                                                _%model28618%_
                                                __tmp37882))))
                                        (if _%source28672%_
                                            (if (exact-integer?
                                                 (cadddr _%node28664%_))
                                                (if (<= '1
                                                        (cadddr _%node28664%_))
                                                    (if (<= (cadddr _%node28664%_)
                                                            (vector-length
                                                             _%source28672%_))
                                                        (equal? (caddr _%node28664%_)
                                                                (vector-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%source28672%_
                         (- (cadddr _%node28664%_) '1)))
                '#f)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '#f)
                                                '#f)
                                            '#f))
                                      '#f)
                                  (if (eq? 'candidate _%$e28669%_)
                                      (if (null? (list-ref _%node28664%_ '4))
                                          (let ((__tmp37884
                                                 (lambda (_%fact28674%_)
                                                   (if (equal? (cadddr _%node28664%_)
                                                               (vector-ref
                                                                _%fact28674%_
                                                                '2))
                                                       (if (eq? (cadr _%node28664%_)
                                                                (vector-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%fact28674%_
                         '0))
                   (equal? (caddr _%node28664%_) (vector-ref _%fact28674%_ '1))
                   '#f)
               '#f)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (__tmp37883
                                                 (##structure-ref
                                                  _%spec28600%_
                                                  '2
                                                  gerbil-ascent/candidate/types#reasoning-candidate::t
                                                  '#f)))
                                            (declare (not safe))
                                            (__find __tmp37884 __tmp37883))
                                          '#f)
                                      (if (eq? 'rule _%$e28669%_)
                                          (_%rule-node-valid?28639%_
                                           _%node28664%_
                                           _%index28665%_)
                                          '#f))))
                            '#f)
                        '#f)
                    '#f)
                '#f)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '#f)
                                                '#f)
                                            '#f))))
                              (if _%levels28616%_
                                  (let ((_%valid-nodes?28650%_
                                         (let _%loop28642%_ ((_%remaining28644%_
                                                              _%nodes28620%_)
                                                             (_%index28645%_
                                                              '0))
                                           (let ((_%$e28647%_
                                                  (null? _%remaining28644%_)))
                                             (if _%$e28647%_
                                                 _%$e28647%_
                                                 (if (_%node-valid?28640%_
                                                      (car _%remaining28644%_)
                                                      _%index28645%_)
                                                     (_%loop28642%_
                                                      (cdr _%remaining28644%_)
                                                      (+ _%index28645%_ '1))
                                                     '#f))))))
                                    (if _%bounded?28630%_
                                        'bounded
                                        (if _%valid-nodes?28650%_
                                            (if (and (pair? _%roots28622%_)
                                                     (let ((__tmp37885
                                                            (lambda (_%id28654%_)
                                                              (let ((_%node28656%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (_%node-ref28635%_
                              _%id28654%_
                              (length _%nodes28620%_)
                              (car _%query28626%_))))
                        (and (_%step!28633%_)
                             _%node28656%_
                             (let ((__tmp37886 (caddr _%node28656%_)))
                               (declare (not safe))
                               (gerbil-ascent/candidate/funs#candidate-bind-atom
                                _%query28626%_
                                __tmp37886
                                '())))))))
               (declare (not safe))
               (andmap__0 __tmp37885 _%roots28622%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (if (gerbil-ascent/candidate/stratified-proof#same-distinct-rows?
                                                     (map (lambda (_%id28659%_)
                                                            (caddr (vector-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%by-id28624%_
                            _%id28659%_)))
                  _%roots28622%_)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     _%native-rows28603%_
                                                     _%step!28633%_)
                                                    (if _%bounded?28630%_
                                                        'bounded
                                                        'valid)
                                                    (if _%bounded?28630%_
                                                        'bounded
                                                        'invalid))
                                                (if _%bounded?28630%_
                                                    'bounded
                                                    'invalid))
                                            'invalid)))
                                  'invalid))))
                      _%finite-verdict28609%_))))
            'invalid)))))
