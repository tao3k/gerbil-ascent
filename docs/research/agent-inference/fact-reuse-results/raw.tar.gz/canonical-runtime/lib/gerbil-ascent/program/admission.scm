(declare (block) (standard-bindings) (extended-bindings))
(begin
  (load-module "std/list/list-builder")
  (load-module "gerbil-ascent/program/admission~0"))
