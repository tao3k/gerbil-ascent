(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/provenance[1]#_g37988_|
    (##structure
     gx#syntax-quote::t
     'positive-proof::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37990_|
    (##structure
     gx#syntax-quote::t
     'make-positive-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37992_|
    (##structure
     gx#syntax-quote::t
     'positive-proof?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37994_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37995_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37996_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37997_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37998_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g37999_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38000_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38001_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38002_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38004_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38005_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38006_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38007_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38008_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38009_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38010_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38011_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38012_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38014_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38015_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38016_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38017_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38018_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38019_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38020_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38021_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38022_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38024_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38025_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38026_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38027_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38028_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38029_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38030_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38031_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38032_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38034_|
    (##structure
     gx#syntax-quote::t
     'proof-node::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38036_|
    (##structure
     gx#syntax-quote::t
     'make-proof-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38038_|
    (##structure
     gx#syntax-quote::t
     'proof-node?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38040_|
    (##structure
     gx#syntax-quote::t
     'proof-node-id
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38041_|
    (##structure
     gx#syntax-quote::t
     'proof-node-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38042_|
    (##structure
     gx#syntax-quote::t
     'proof-node-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38043_|
    (##structure
     gx#syntax-quote::t
     'proof-node-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38044_|
    (##structure
     gx#syntax-quote::t
     'proof-node-label
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38045_|
    (##structure
     gx#syntax-quote::t
     'proof-node-inputs
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38047_|
    (##structure
     gx#syntax-quote::t
     'proof-node-id-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38048_|
    (##structure
     gx#syntax-quote::t
     'proof-node-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38049_|
    (##structure
     gx#syntax-quote::t
     'proof-node-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38050_|
    (##structure
     gx#syntax-quote::t
     'proof-node-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38051_|
    (##structure
     gx#syntax-quote::t
     'proof-node-label-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38052_|
    (##structure
     gx#syntax-quote::t
     'proof-node-inputs-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38054_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-id
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38055_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38056_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38057_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38058_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-label
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38059_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-inputs
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38061_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-id-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38062_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38063_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38064_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38065_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-label-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38066_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-inputs-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38068_|
    (##structure
     gx#syntax-quote::t
     'proof-relation::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38070_|
    (##structure
     gx#syntax-quote::t
     'make-proof-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38072_|
    (##structure
     gx#syntax-quote::t
     'proof-relation?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38074_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38075_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-tail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38076_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38078_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38079_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-tail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38080_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38082_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38083_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-tail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38084_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38086_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38087_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-tail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g38088_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/provenance[:0:]#positive-proof|
      (let ((__obj37796
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37796
           'gerbil-ascent/candidate/provenance#positive-proof::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37796 'positive-proof '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37796
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    work-budget
                    nodes
                    roots)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37796
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    work-budget
                    nodes
                    roots)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37796 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37796 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37796 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37796 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37796 '#f '13 '#f '#f))
        (let ((__tmp37987 |gerbil-ascent/candidate/provenance[1]#_g37988_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37796 __tmp37987 '4 '#f '#f))
        (let ((__tmp37989 |gerbil-ascent/candidate/provenance[1]#_g37990_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37796 __tmp37989 '14 '#f '#f))
        (let ((__tmp37991 |gerbil-ascent/candidate/provenance[1]#_g37992_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37796 __tmp37991 '15 '#f '#f))
        (let ((__tmp37993
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g37994_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g37995_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g37996_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g37997_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g37998_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g37999_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g38000_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g38001_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g38002_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37796 __tmp37993 '16 '#f '#f))
        (let ((__tmp38003
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g38004_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g38005_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g38006_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g38007_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g38008_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g38009_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g38010_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g38011_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g38012_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37796 __tmp38003 '17 '#f '#f))
        (let ((__tmp38013
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g38014_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g38015_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g38016_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g38017_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g38018_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g38019_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g38020_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g38021_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g38022_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37796 __tmp38013 '18 '#f '#f))
        (let ((__tmp38023
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g38024_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g38025_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g38026_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g38027_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g38028_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g38029_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g38030_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g38031_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g38032_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj37796 __tmp38023 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37796 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37796 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37796 '() '21 '#f '#f))
        __obj37796))
    (define |gerbil-ascent/candidate/provenance[:0:]#proof-node|
      (let ((__obj37797
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37797
           'gerbil-ascent/candidate/provenance#proof-node::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37797 'proof-node '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37797
           '(id kind relation row label inputs)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37797
           '(id kind relation row label inputs)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37797 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37797 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37797 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37797 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37797 '#f '13 '#f '#f))
        (let ((__tmp38033 |gerbil-ascent/candidate/provenance[1]#_g38034_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37797 __tmp38033 '4 '#f '#f))
        (let ((__tmp38035 |gerbil-ascent/candidate/provenance[1]#_g38036_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37797 __tmp38035 '14 '#f '#f))
        (let ((__tmp38037 |gerbil-ascent/candidate/provenance[1]#_g38038_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37797 __tmp38037 '15 '#f '#f))
        (let ((__tmp38039
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g38040_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g38041_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g38042_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g38043_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g38044_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g38045_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37797 __tmp38039 '16 '#f '#f))
        (let ((__tmp38046
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g38047_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g38048_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g38049_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g38050_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g38051_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g38052_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37797 __tmp38046 '17 '#f '#f))
        (let ((__tmp38053
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g38054_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g38055_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g38056_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g38057_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g38058_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g38059_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37797 __tmp38053 '18 '#f '#f))
        (let ((__tmp38060
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g38061_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g38062_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g38063_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g38064_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g38065_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g38066_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37797 __tmp38060 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37797 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37797 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37797 '() '21 '#f '#f))
        __obj37797))
    (define |gerbil-ascent/candidate/provenance[:0:]#proof-relation|
      (let ((__obj37798
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37798
           'gerbil-ascent/candidate/provenance#proof-relation::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37798 'proof-relation '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37798
           '(nodes tail members)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37798
           '(nodes tail members)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37798 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37798 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37798 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37798 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37798 '#f '13 '#f '#f))
        (let ((__tmp38067 |gerbil-ascent/candidate/provenance[1]#_g38068_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37798 __tmp38067 '4 '#f '#f))
        (let ((__tmp38069 |gerbil-ascent/candidate/provenance[1]#_g38070_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37798 __tmp38069 '14 '#f '#f))
        (let ((__tmp38071 |gerbil-ascent/candidate/provenance[1]#_g38072_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37798 __tmp38071 '15 '#f '#f))
        (let ((__tmp38073
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g38074_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g38075_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g38076_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37798 __tmp38073 '16 '#f '#f))
        (let ((__tmp38077
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g38078_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g38079_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g38080_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37798 __tmp38077 '17 '#f '#f))
        (let ((__tmp38081
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g38082_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g38083_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g38084_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37798 __tmp38081 '18 '#f '#f))
        (let ((__tmp38085
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g38086_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g38087_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g38088_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37798 __tmp38085 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37798 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37798 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37798 '() '21 '#f '#f))
        __obj37798))))
