(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/finite-evidence::timestamp 1791689708)
  (begin
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence::t
      (let ((__tmp37468 (list)) (__tmp37467 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'finite-evidence
         __tmp37468
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  program
                  query
                  work-budget
                  closure)
         __tmp37467
         '#f)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t)))
    (define gerbil-ascent/candidate/finite-evidence#make-finite-evidence
      (lambda _%$args28565%_
        (apply make-instance
               gerbil-ascent/candidate/finite-evidence#finite-evidence::t
               _%$args28565%_)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'status)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-program
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'program)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-query
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'query)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-closure
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'closure)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'status)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-program-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'program)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'query)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/finite-evidence#finite-evidence-closure-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'closure)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'status)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-program
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'program)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-query
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'query)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-closure
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'closure)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'status)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-program-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'program)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'query)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'work-budget)))
    (define gerbil-ascent/candidate/finite-evidence#&finite-evidence-closure-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
         'closure)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation::t
      (let ((__tmp37470 (list))
            (__tmp37469
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'replay-relation
         __tmp37470
         '(arity reversed present frontier dirty?)
         __tmp37469
         '#f)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/finite-evidence#replay-relation::t)))
    (define gerbil-ascent/candidate/finite-evidence#make-replay-relation
      (lambda _%$args28562%_
        (apply make-instance
               gerbil-ascent/candidate/finite-evidence#replay-relation::t
               _%$args28562%_)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-arity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'arity)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-reversed
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'reversed)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-present
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'present)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-frontier
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'frontier)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-dirty?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'dirty?)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-arity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'arity)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-reversed-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'reversed)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-present-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'present)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-frontier-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'frontier)))
    (define gerbil-ascent/candidate/finite-evidence#replay-relation-dirty?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'dirty?)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-arity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'arity)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-reversed
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'reversed)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-present
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'present)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-frontier
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'frontier)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-dirty?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'dirty?)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-arity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'arity)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-reversed-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'reversed)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-present-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'present)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-frontier-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'frontier)))
    (define gerbil-ascent/candidate/finite-evidence#&replay-relation-dirty?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-evidence#replay-relation::t
         'dirty?)))
    (define gerbil-ascent/candidate/finite-evidence#closure-valid?
      (lambda (_%closure28547%_ _%schema28548%_)
        (if (equal? (let ()
                      (declare (not safe))
                      (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                       _%closure28547%_
                       gerbil-ascent/candidate/certificate-limits#+max-certificate-relations+))
                    (length _%schema28548%_))
            (let ((_%rows28550%_ '0) (_%cells28551%_ '0))
              (let ((__tmp37471
                     (lambda (_%entry28553%_ _%declaration28554%_)
                       (if (equal? (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                                      _%entry28553%_
                                      '3))
                                   '3)
                           (if (eq? (car _%entry28553%_)
                                    (car _%declaration28554%_))
                               (if (exact-integer? (cadr _%entry28553%_))
                                   (if (= (cadr _%entry28553%_)
                                          (cdr _%declaration28554%_))
                                       (if (let ((_%count28556%_
                                                  (let ((__tmp37473
                                                         (caddr _%entry28553%_))
                                                        (__tmp37472
                                                         (- gerbil-ascent/candidate/certificate-limits#+max-certificate-rows+
                                                            _%rows28550%_)))
                                                    (declare (not safe))
                                                    (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                                                     __tmp37473
                                                     __tmp37472))))
                                             (and _%count28556%_
                                                  (begin
                                                    (set! _%rows28550%_
                                                          (+ _%rows28550%_
                                                             _%count28556%_))
                                                    '#t)))
                                           (if (<= _%rows28550%_
                                                   gerbil-ascent/candidate/certificate-limits#+max-certificate-rows+)
                                               (if (let ((__tmp37475
                                                          (lambda (_%row28558%_)
                                                            (let ((_%width28560%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ((__tmp37476
                                  (min gerbil-ascent/candidate/certificate-limits#+max-certificate-row-arity+
                                       (- gerbil-ascent/candidate/certificate-limits#+max-certificate-cells+
                                          _%cells28551%_))))
                             (declare (not safe))
                             (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                              _%row28558%_
                              __tmp37476))))
                      (and _%width28560%_
                           (= _%width28560%_ (cadr _%entry28553%_))
                           (begin
                             (set! _%cells28551%_
                                   (+ _%cells28551%_ _%width28560%_))
                             '#t)
                           (let ()
                             (declare (not safe))
                             (andmap__0
                              gerbil-ascent/candidate/program#scalar?
                              _%row28558%_))))))
                 (__tmp37474 (caddr _%entry28553%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (declare (not safe))
                                                     (andmap__0
                                                      __tmp37475
                                                      __tmp37474))
                                                   (let ((__tmp37477
                                                          (caddr _%entry28553%_)))
                                                     (declare (not safe))
                                                     (gerbil-ascent/candidate/certificate-limits#unique-rows?
                                                      __tmp37477))
                                                   '#f)
                                               '#f)
                                           '#f)
                                       '#f)
                                   '#f)
                               '#f)
                           '#f))))
                (declare (not safe))
                (andmap__1 __tmp37471 _%closure28547%_ _%schema28548%_)))
            '#f)))
    (define gerbil-ascent/candidate/finite-evidence#finite-replay
      (lambda (_%snapshot27778%_ _%spec27779%_ _%work-budget27780%_)
        (let* ((_%schema27782%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/funs#candidate-schema-of
                   _%snapshot27778%_
                   _%spec27779%_)))
               (_%rules27784%_
                (##structure-ref
                 _%spec27779%_
                 '3
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f))
               (_%levels27786%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/funs#candidate-strata-of
                   _%schema27782%_
                   _%rules27784%_)))
               (_%tables27790%_
                (let ((__tmp37478
                       (lambda (_%entry27788%_)
                         (cons (car _%entry27788%_)
                               (let ((__tmp37480 (cdr _%entry27788%_))
                                     (__tmp37479
                                      (let ()
                                        (declare (not safe))
                                        (make-hash-table__%
                                         '#f
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value))))
                                 (declare (not safe))
                                 (##structure
                                  gerbil-ascent/candidate/finite-evidence#replay-relation::t
                                  __tmp37480
                                  '()
                                  __tmp37479
                                  '()
                                  '#f))))))
                  (declare (not safe))
                  (##map __tmp37478 _%schema27782%_)))
               (_%relations27792%_
                (let ()
                  (declare (not safe))
                  (list->hash-table-eq _%tables27790%_)))
               (_%resolve27799%_
                (lambda (_%name27794%_)
                  (let ((_%$e27796%_
                         (let ()
                           (declare (not safe))
                           (hash-get _%relations27792%_ _%name27794%_))))
                    (if _%$e27796%_
                        _%$e27796%_
                        (let ()
                          (declare (not safe))
                          (error '"candidate is missing inspected entry"
                                 _%name27794%_))))))
               (_%plans27803%_
                (if _%levels27786%_
                    (map (lambda (_%rule27801%_)
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/candidate/finite-plan#prepare-finite-rule
                              _%rule27801%_
                              _%resolve27799%_
                              _%levels27786%_)))
                         _%rules27784%_)
                    '#f))
               (_%steps27805%_ '0)
               (_%bounded?27807%_ '#f)
               (_%material27809%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/certificate-limits#make-certificate-material-budget)))
               (_%derived-count27811%_ '0)
               (_%derived-limit27813%_
                (cadr (##structure-ref
                       _%spec27779%_
                       '5
                       gerbil-ascent/candidate/types#reasoning-candidate::t
                       '#f))))
          (letrec ((_%active?27816%_ (lambda () (not _%bounded?27807%_)))
                   (_%__rows27969%_
                    (lambda (_%relation28534%_)
                      (let ((_%relation28537%_ _%relation28534%_))
                        (if (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%relation28537%_
                               '5
                               '#f
                               '#f))
                            (begin
                              (let ((__tmp37481
                                     (reverse (let ()
                                                (declare (not safe))
                                                (##unchecked-structure-ref
                                                 _%relation28537%_
                                                 '2
                                                 '#f
                                                 '#f)))))
                                (declare (not safe))
                                (##unchecked-structure-set!
                                 _%relation28537%_
                                 __tmp37481
                                 '4
                                 '#f
                                 '#f))
                              (let ()
                                (declare (not safe))
                                (##unchecked-structure-set!
                                 _%relation28537%_
                                 '#f
                                 '5
                                 '#f
                                 '#f)))
                            '#!void)
                        (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%relation28537%_
                           '4
                           '#f
                           '#f)))))
                   (_%rows27970%_
                    (lambda (_%relation28522%_)
                      (let ((_%relation28525%_ _%relation28522%_))
                        (_%__rows27969%_ _%relation28525%_))))
                   (_%__add-row!28092%_
                    (lambda (_%relation28500%_ _%row28501%_ _%derived?28502%_)
                      (let ((_%relation28505%_ _%relation28500%_))
                        (if (or _%bounded?27807%_
                                (let ((__tmp37482
                                       (let ()
                                         (declare (not safe))
                                         (##unchecked-structure-ref
                                          _%relation28505%_
                                          '3
                                          '#f
                                          '#f))))
                                  (declare (not safe))
                                  (hash-get __tmp37482 _%row28501%_)))
                            '#f
                            (begin
                              (if _%derived?28502%_
                                  (begin
                                    (set! _%derived-count27811%_
                                          (+ _%derived-count27811%_ '1))
                                    (if (> _%derived-count27811%_
                                           _%derived-limit27813%_)
                                        (set! _%bounded?27807%_ '#t)
                                        '#!void))
                                  '#!void)
                              (if (or _%bounded?27807%_
                                      (let ()
                                        (declare (not safe))
                                        (gerbil-ascent/candidate/certificate-limits#certificate-material-reserve!
                                         _%material27809%_
                                         _%row28501%_)))
                                  '#!void
                                  (set! _%bounded?27807%_ '#t))
                              (if _%bounded?27807%_
                                  '#f
                                  (let ((_%owned28520%_
                                         (let ()
                                           (declare (not safe))
                                           (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                            _%row28501%_))))
                                    (let ((__tmp37483
                                           (let ()
                                             (declare (not safe))
                                             (##unchecked-structure-ref
                                              _%relation28505%_
                                              '3
                                              '#f
                                              '#f))))
                                      (declare (not safe))
                                      (hash-put!
                                       __tmp37483
                                       _%owned28520%_
                                       '#t))
                                    (let ((__tmp37484
                                           (cons _%owned28520%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%relation28505%_
                                                    '2
                                                    '#f
                                                    '#f)))))
                                      (declare (not safe))
                                      (##unchecked-structure-set!
                                       _%relation28505%_
                                       __tmp37484
                                       '2
                                       '#f
                                       '#f))
                                    (let ()
                                      (declare (not safe))
                                      (##unchecked-structure-set!
                                       _%relation28505%_
                                       '#t
                                       '5
                                       '#f
                                       '#f))
                                    '#t)))))))
                   (_%add-row!28093%_
                    (lambda (_%relation28486%_ _%row28487%_ _%derived?28488%_)
                      (let ((_%relation28491%_ _%relation28486%_))
                        (_%__add-row!28092%_
                         _%relation28491%_
                         _%row28487%_
                         _%derived?28488%_))))
                   (_%step!28094%_
                    (lambda ()
                      (if _%bounded?27807%_
                          '#!void
                          (begin
                            (set! _%steps27805%_ (+ _%steps27805%_ '1))
                            (if (> _%steps27805%_ _%work-budget27780%_)
                                (set! _%bounded?27807%_ '#t)
                                '#!void)))
                      (not _%bounded?27807%_)))
                   (_%__evaluate-rule28216%_
                    (lambda (_%rule28341%_)
                      (let ((_%rule28344%_ _%rule28341%_))
                        (let ((_%body28353%_
                               (let ()
                                 (declare (not safe))
                                 (##unchecked-structure-ref
                                  _%rule28344%_
                                  '3
                                  '#f
                                  '#f)))
                              (_%changed?28354%_ '#f))
                          (letrec ((_%walk28356%_
                                    (lambda (_%clauses28358%_
                                             _%bindings28359%_)
                                      (if _%bounded?27807%_
                                          '#!void
                                          (if (null? _%clauses28358%_)
                                              (if (let* ((_%relation28361%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (##unchecked-structure-ref
                                                             _%rule28344%_
                                                             '1
                                                             '#f
                                                             '#f)))
                                                         (_%row28364%_
                                                          ((let ()
                                                             (declare
                                                               (not safe))
                                                             (##unchecked-structure-ref
                                                              _%rule28344%_
                                                              '2
                                                              '#f
                                                              '#f))
                                                           _%bindings28359%_))
                                                         (_%derived?28367%_
                                                          '#t)
                                                         (_%relation28371%_
                                                          _%relation28361%_))
                                                    (_%__add-row!28092%_
                                                     _%relation28371%_
                                                     _%row28364%_
                                                     _%derived?28367%_))
                                                  (set! _%changed?28354%_ '#t)
                                                  '#!void)
                                              (let* ((_%clause28388%_
                                                      (car _%clauses28358%_))
                                                     (_%clause28390%_
                                                      _%clause28388%_)
                                                     (_%$e28397%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (##unchecked-structure-ref
                                                         _%clause28390%_
                                                         '1
                                                         '#f
                                                         '#f))))
                                                (if (eq? 'fixed _%$e28397%_)
                                                    (if (_%step!28094%_)
                                                        (let ((_%next28400%_
                                                               ((let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%clause28390%_
                           '3
                           '#f
                           '#f))
                        _%bindings28359%_)))
                  (if _%next28400%_
                      (_%walk28356%_ (cdr _%clauses28358%_) _%next28400%_)
                      '#!void))
                '#!void)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (if (eq? 'not _%$e28397%_)
                                                        (let ((_%matched?28402%_
                                                               '#f))
                                                          (let _%probe28404%_ ((_%remaining28406%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                        (let* ((_%relation28408%_
                                                (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%clause28390%_
                                                   '2
                                                   '#f
                                                   '#f)))
                                               (_%relation28412%_
                                                _%relation28408%_))
                                          (_%__rows27969%_
                                           _%relation28412%_))))
                    (if (and (pair? _%remaining28406%_) (_%step!28094%_))
                        (if ((let ()
                               (declare (not safe))
                               (##unchecked-structure-ref
                                _%clause28390%_
                                '3
                                '#f
                                '#f))
                             (car _%remaining28406%_)
                             _%bindings28359%_)
                            (set! _%matched?28402%_ '#t)
                            (_%probe28404%_ (cdr _%remaining28406%_)))
                        '#!void))
                  (if (if _%bounded?27807%_
                          '#f
                          (if _%matched?28402%_ '#f (_%step!28094%_)))
                      (_%walk28356%_ (cdr _%clauses28358%_) _%bindings28359%_)
                      '#!void))
                (if (eq? 'reduce _%$e28397%_)
                    (let* ((_%output28425%_
                            (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%clause28390%_
                               '4
                               '#f
                               '#f)))
                           (_%operator28427%_
                            (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%clause28390%_
                               '5
                               '#f
                               '#f)))
                           (_%mode28429%_ (car _%operator28427%_))
                           (_%accumulator28431%_
                            (if (let ()
                                  (declare (not safe))
                                  (##memq _%mode28429%_ '(count sum)))
                                '0
                                '#f))
                           (_%numeric?28433%_ '#t))
                      (let _%probe28436%_ ((_%remaining28438%_
                                            (let* ((_%relation28447%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%clause28390%_
                                                       '2
                                                       '#f
                                                       '#f)))
                                                   (_%relation28451%_
                                                    _%relation28447%_))
                                              (_%__rows27969%_
                                               _%relation28451%_))))
                        (if (and (pair? _%remaining28438%_) (_%step!28094%_))
                            (begin
                              (let ((_%next28440%_
                                     ((let ()
                                        (declare (not safe))
                                        (##unchecked-structure-ref
                                         _%clause28390%_
                                         '3
                                         '#f
                                         '#f))
                                      (car _%remaining28438%_)
                                      _%bindings28359%_)))
                                (if _%next28440%_
                                    (if (eq? _%mode28429%_ 'count)
                                        (set! _%accumulator28431%_
                                              (+ _%accumulator28431%_ '1))
                                        (if _%numeric?28433%_
                                            (let ((_%value28442%_
                                                   (cdr (let ((__tmp37485
                                                               (cadr _%operator28427%_)))
                                                          (declare (not safe))
                                                          (gerbil-ascent/candidate/funs#candidate-required-entry
                                                           __tmp37485
                                                           _%next28440%_)))))
                                              (if (exact-integer?
                                                   _%value28442%_)
                                                  (set! _%accumulator28431%_
                                                        (let ((_%$e28444%_
                                                               _%mode28429%_))
                                                          (if (eq? 'sum
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           _%$e28444%_)
                      (+ _%accumulator28431%_ _%value28442%_)
                      (if (eq? 'min _%$e28444%_)
                          (if _%accumulator28431%_
                              (min _%accumulator28431%_ _%value28442%_)
                              _%value28442%_)
                          (if (eq? 'max _%$e28444%_)
                              (if _%accumulator28431%_
                                  (max _%accumulator28431%_ _%value28442%_)
                                  _%value28442%_)
                              '#f)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (set! _%numeric?28433%_
                                                        '#f)))
                                            '#!void))
                                    '#!void))
                              (_%probe28436%_ (cdr _%remaining28438%_)))
                            '#!void))
                      (if _%bounded?27807%_
                          '#!void
                          (let ((_%value28466%_
                                 (if _%numeric?28433%_
                                     _%accumulator28431%_
                                     '#f)))
                            (if _%value28466%_
                                (_%walk28356%_
                                 (cdr _%clauses28358%_)
                                 (cons (cons _%output28425%_ _%value28466%_)
                                       _%bindings28359%_))
                                '#!void))))
                    (let ((__tmp37487
                           (lambda (_%row28468%_)
                             (if (_%step!28094%_)
                                 (let ((_%next28470%_
                                        ((let ()
                                           (declare (not safe))
                                           (##unchecked-structure-ref
                                            _%clause28390%_
                                            '3
                                            '#f
                                            '#f))
                                         _%row28468%_
                                         _%bindings28359%_)))
                                   (if _%next28470%_
                                       (_%walk28356%_
                                        (cdr _%clauses28358%_)
                                        _%next28470%_)
                                       '#!void))
                                 '#!void)))
                          (__tmp37486
                           (let* ((_%relation28472%_
                                   (let ()
                                     (declare (not safe))
                                     (##unchecked-structure-ref
                                      _%clause28390%_
                                      '2
                                      '#f
                                      '#f)))
                                  (_%relation28476%_ _%relation28472%_))
                             (_%__rows27969%_ _%relation28476%_))))
                      (declare (not safe))
                      (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                       _%active?27816%_
                       __tmp37487
                       __tmp37486)))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                            (_%walk28356%_ _%body28353%_ '())
                            _%changed?28354%_)))))
                   (_%evaluate-rule28217%_
                    (lambda (_%rule28329%_)
                      (let ((_%rule28332%_ _%rule28329%_))
                        (_%__evaluate-rule28216%_ _%rule28332%_)))))
            (if (> (let () (declare (not safe)) (##length _%schema27782%_))
                   gerbil-ascent/candidate/certificate-limits#+max-certificate-relations+)
                (values 'bounded '())
                (if _%levels27786%_
                    (begin
                      (let ((__tmp37489
                             (lambda (_%entry28219%_)
                               (let ((__tmp37491
                                      (lambda (_%row28221%_)
                                        (let* ((_%relation28223%_
                                                (_%resolve27799%_
                                                 (car _%entry28219%_)))
                                               (_%row28226%_ _%row28221%_)
                                               (_%derived?28229%_ '#f)
                                               (_%relation28233%_
                                                _%relation28223%_))
                                          (_%__add-row!28092%_
                                           _%relation28233%_
                                           _%row28226%_
                                           _%derived?28229%_))))
                                     (__tmp37490 (caddr _%entry28219%_)))
                                 (declare (not safe))
                                 (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                                  _%active?27816%_
                                  __tmp37491
                                  __tmp37490))))
                            (__tmp37488
                             (##structure-ref
                              _%snapshot27778%_
                              '4
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f)))
                        (declare (not safe))
                        (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                         _%active?27816%_
                         __tmp37489
                         __tmp37488))
                      (let ((__tmp37493
                             (lambda (_%fact28246%_)
                               (let* ((_%relation28248%_
                                       (_%resolve27799%_
                                        (vector-ref _%fact28246%_ '0)))
                                      (_%row28251%_
                                       (vector-ref _%fact28246%_ '1))
                                      (_%derived?28254%_ '#f)
                                      (_%relation28258%_ _%relation28248%_))
                                 (_%__add-row!28092%_
                                  _%relation28258%_
                                  _%row28251%_
                                  _%derived?28254%_))))
                            (__tmp37492
                             (##structure-ref
                              _%spec27779%_
                              '2
                              gerbil-ascent/candidate/types#reasoning-candidate::t
                              '#f)))
                        (declare (not safe))
                        (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                         _%active?27816%_
                         __tmp37493
                         __tmp37492))
                      (let _%stratum28270%_ ((_%level28272%_ '0)
                                             (_%maximum28273%_
                                              (let ((__tmp37495
                                                     (map cdr
                                                          _%levels27786%_)))
                                                (declare (not safe))
                                                (##apply max __tmp37495))))
                        (if (and (<= _%level28272%_ _%maximum28273%_)
                                 (not _%bounded?27807%_))
                            (begin
                              (let _%repeat28275%_ ()
                                (let ((_%changed?28278%_ '#f))
                                  (let ((__tmp37494
                                         (lambda (_%rule28280%_)
                                           (let ((_%rule28283%_ _%rule28280%_))
                                             (if (if _%bounded?27807%_
                                                     '#f
                                                     (= (let ()
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           _%rule28283%_
                                                           '4
                                                           '#f
                                                           '#f))
                                                        _%level28272%_))
                                                 (if (let* ((_%rule28297%_
                                                             _%rule28283%_)
                                                            (_%rule28301%_
                                                             _%rule28297%_))
                                                       (_%__evaluate-rule28216%_
                                                        _%rule28301%_))
                                                     (set! _%changed?28278%_
                                                           '#t)
                                                     '#!void)
                                                 '#!void)))))
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                                     _%active?27816%_
                                     __tmp37494
                                     _%plans27803%_))
                                  (if (and _%changed?28278%_
                                           (not _%bounded?27807%_))
                                      (_%repeat28275%_)
                                      '#!void)))
                              (_%stratum28270%_
                               (+ _%level28272%_ '1)
                               _%maximum28273%_))
                            '#!void))
                      (values (if _%bounded?27807%_ 'bounded 'complete)
                              (if _%bounded?27807%_
                                  '()
                                  (let ((__tmp37496
                                         (lambda (_%entry28313%_)
                                           (list (car _%entry28313%_)
                                                 (##direct-structure-ref
                                                  (cdr _%entry28313%_)
                                                  '1
                                                  gerbil-ascent/candidate/finite-evidence#replay-relation::t
                                                  '#f)
                                                 (let* ((_%relation28315%_
                                                         (cdr _%entry28313%_))
                                                        (_%relation28319%_
                                                         _%relation28315%_))
                                                   (_%__rows27969%_
                                                    _%relation28319%_))))))
                                    (declare (not safe))
                                    (##map __tmp37496 _%tables27790%_)))))
                    (values 'unsupported '())))))))
    (define gerbil-ascent/candidate/finite-evidence#query-rows
      (lambda (_%spec27766%_ _%closure27767%_)
        (let* ((_%query27769%_
                (vector-ref
                 (##structure-ref
                  _%spec27766%_
                  '4
                  gerbil-ascent/candidate/types#reasoning-candidate::t
                  '#f)
                 '0))
               (_%entry27771%_
                (let ((__tmp37497 (car _%query27769%_)))
                  (declare (not safe))
                  (gerbil-ascent/candidate/funs#candidate-required-entry
                   __tmp37497
                   _%closure27767%_)))
               (_%match-row27773%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
                   _%query27769%_))))
          (filter (lambda (_%row27776%_)
                    (if (_%match-row27773%_ _%row27776%_ '()) '#t '#f))
                  (caddr _%entry27771%_)))))
    (define gerbil-ascent/candidate/finite-evidence#candidate-finite-evidence
      (lambda (_%snapshot27742%_
               _%spec27743%_
               _%candidate-digest27744%_
               _%native-status27745%_
               _%native-rows27746%_
               _%work-budget27747%_)
        (if (and (exact-integer? _%work-budget27747%_)
                 (> _%work-budget27747%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"finite evidence requires positive work budget"
                     _%work-budget27747%_)))
        (letrec ((_%result27749%_
                  (lambda (_%status27763%_ _%closure27764%_)
                    (let ((__tmp37503
                           (##structure-ref
                            _%snapshot27742%_
                            '1
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                          (__tmp37502
                           (##structure-ref
                            _%snapshot27742%_
                            '2
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                          (__tmp37501
                           (##structure-ref
                            _%snapshot27742%_
                            '3
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                          (__tmp37500
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/candidate/program-identity#candidate-finite-program-fingerprint
                              _%spec27743%_)))
                          (__tmp37498
                           (let ((__tmp37499
                                  (vector-ref
                                   (##structure-ref
                                    _%spec27743%_
                                    '4
                                    gerbil-ascent/candidate/types#reasoning-candidate::t
                                    '#f)
                                   '0)))
                             (declare (not safe))
                             (gerbil-ascent/candidate/datum#candidate-copy-pairs
                              __tmp37499))))
                      (declare (not safe))
                      (##structure
                       gerbil-ascent/candidate/finite-evidence#finite-evidence::t
                       _%status27763%_
                       __tmp37503
                       __tmp37502
                       __tmp37501
                       _%candidate-digest27744%_
                       __tmp37500
                       __tmp37498
                       _%work-budget27747%_
                       _%closure27764%_)))))
          (if (or (not (let ()
                         (declare (not safe))
                         (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                          _%snapshot27742%_)))
                  (not (eq? _%native-status27745%_ 'complete)))
              (_%result27749%_ 'unsupported '())
              (let ((_g37504_
                     (gerbil-ascent/candidate/finite-evidence#finite-replay
                      _%snapshot27742%_
                      _%spec27743%_
                      _%work-budget27747%_)))
                (begin
                  (let ((_g37505_
                         (let ()
                           (declare (not safe))
                           (if (##values? _g37504_)
                               (##values-length _g37504_)
                               1))))
                    (if (not (let () (declare (not safe)) (##fx= _g37505_ 2)))
                        (error "Context expects 2 values" _g37505_)))
                  (let ((_%status27754%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g37504_ 0)))
                        (_%closure27755%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g37504_ 1))))
                    (let ((_%$e27757%_ _%status27754%_))
                      (if (eq? 'complete _%$e27757%_)
                          (if (gerbil-ascent/candidate/finite-evidence#closure-valid?
                               _%closure27755%_
                               (let ()
                                 (declare (not safe))
                                 (gerbil-ascent/candidate/funs#candidate-schema-of
                                  _%snapshot27742%_
                                  _%spec27743%_)))
                              (if (let ((__tmp37506
                                         (gerbil-ascent/candidate/finite-evidence#query-rows
                                          _%spec27743%_
                                          _%closure27755%_)))
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/funs#candidate-same-row-set?
                                     __tmp37506
                                     _%native-rows27746%_))
                                  (_%result27749%_ 'complete _%closure27755%_)
                                  (_%result27749%_ 'mismatch '()))
                              (_%result27749%_ 'bounded '()))
                          (if (eq? 'bounded _%$e27757%_)
                              (_%result27749%_ 'bounded '())
                              (_%result27749%_ 'unsupported '())))))))))))
    (define gerbil-ascent/candidate/finite-evidence#candidate-verified-finite-closure
      (lambda (_%snapshot27725%_
               _%spec27726%_
               _%candidate-digest27727%_
               _%native-status27728%_
               _%native-rows27729%_
               _%certificate27730%_
               _%work-budget27731%_)
        (if (and (exact-integer? _%work-budget27731%_)
                 (> _%work-budget27731%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"finite evidence verification needs positive budget"
                     _%work-budget27731%_)))
        (if (and (let ()
                   (declare (not safe))
                   (##structure-instance-of?
                    _%certificate27730%_
                    'gerbil-ascent/candidate/finite-evidence#finite-evidence::t))
                 (let ()
                   (declare (not safe))
                   (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                    _%snapshot27725%_))
                 (eq? _%native-status27728%_ 'complete)
                 (eq? (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%certificate27730%_
                         '1
                         '#f
                         '#f))
                      'complete)
                 (equal? (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%certificate27730%_
                            '2
                            '#f
                            '#f))
                         (##structure-ref
                          _%snapshot27725%_
                          '1
                          gerbil-ascent/candidate/types#reasoning-snapshot::t
                          '#f))
                 (equal? (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%certificate27730%_
                            '3
                            '#f
                            '#f))
                         (##structure-ref
                          _%snapshot27725%_
                          '2
                          gerbil-ascent/candidate/types#reasoning-snapshot::t
                          '#f))
                 (equal? (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%certificate27730%_
                            '4
                            '#f
                            '#f))
                         (##structure-ref
                          _%snapshot27725%_
                          '3
                          gerbil-ascent/candidate/types#reasoning-snapshot::t
                          '#f))
                 (equal? (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%certificate27730%_
                            '5
                            '#f
                            '#f))
                         _%candidate-digest27727%_)
                 (equal? (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%certificate27730%_
                            '6
                            '#f
                            '#f))
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/program-identity#candidate-finite-program-fingerprint
                            _%spec27726%_)))
                 (equal? (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%certificate27730%_
                            '7
                            '#f
                            '#f))
                         (vector-ref
                          (##structure-ref
                           _%spec27726%_
                           '4
                           gerbil-ascent/candidate/types#reasoning-candidate::t
                           '#f)
                          '0))
                 (gerbil-ascent/candidate/finite-evidence#closure-valid?
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref
                     _%certificate27730%_
                     '9
                     '#f
                     '#f))
                  (let ()
                    (declare (not safe))
                    (gerbil-ascent/candidate/funs#candidate-schema-of
                     _%snapshot27725%_
                     _%spec27726%_))))
            (let ((_g37507_
                   (gerbil-ascent/candidate/finite-evidence#finite-replay
                    _%snapshot27725%_
                    _%spec27726%_
                    _%work-budget27731%_)))
              (begin
                (let ((_g37508_
                       (let ()
                         (declare (not safe))
                         (if (##values? _g37507_)
                             (##values-length _g37507_)
                             1))))
                  (if (not (let () (declare (not safe)) (##fx= _g37508_ 2)))
                      (error "Context expects 2 values" _g37508_)))
                (let ((_%status27733%_
                       (let () (declare (not safe)) (##values-ref _g37507_ 0)))
                      (_%closure27734%_
                       (let ()
                         (declare (not safe))
                         (##values-ref _g37507_ 1))))
                  (let ((_%$e27736%_ _%status27733%_))
                    (if (eq? 'bounded _%$e27736%_)
                        (values 'bounded '())
                        (if (eq? 'complete _%$e27736%_)
                            (if (and (let ((__tmp37510
                                            (lambda (_%actual27739%_
                                                     _%supplied27740%_)
                                              (let ((__tmp37512
                                                     (caddr _%actual27739%_))
                                                    (__tmp37511
                                                     (caddr _%supplied27740%_)))
                                                (declare (not safe))
                                                (gerbil-ascent/candidate/funs#candidate-same-row-set?
                                                 __tmp37512
                                                 __tmp37511))))
                                           (__tmp37509
                                            (##structure-ref
                                             _%certificate27730%_
                                             '9
                                             gerbil-ascent/candidate/finite-evidence#finite-evidence::t
                                             '#f)))
                                       (declare (not safe))
                                       (andmap__1
                                        __tmp37510
                                        _%closure27734%_
                                        __tmp37509))
                                     (let ((__tmp37513
                                            (gerbil-ascent/candidate/finite-evidence#query-rows
                                             _%spec27726%_
                                             _%closure27734%_)))
                                       (declare (not safe))
                                       (gerbil-ascent/candidate/funs#candidate-same-row-set?
                                        __tmp37513
                                        _%native-rows27729%_)))
                                (values 'valid _%closure27734%_)
                                (values 'invalid '()))
                            (values 'invalid '())))))))
            (values 'invalid '()))))
    (define gerbil-ascent/candidate/finite-evidence#candidate-verify-finite-evidence
      (lambda (_%snapshot27714%_
               _%spec27715%_
               _%candidate-digest27716%_
               _%native-status27717%_
               _%native-rows27718%_
               _%certificate27719%_
               _%work-budget27720%_)
        (let ((_g37514_
               (gerbil-ascent/candidate/finite-evidence#candidate-verified-finite-closure
                _%snapshot27714%_
                _%spec27715%_
                _%candidate-digest27716%_
                _%native-status27717%_
                _%native-rows27718%_
                _%certificate27719%_
                _%work-budget27720%_)))
          (begin
            (let ((_g37515_
                   (let ()
                     (declare (not safe))
                     (if (##values? _g37514_) (##values-length _g37514_) 1))))
              (if (not (let () (declare (not safe)) (##fx= _g37515_ 2)))
                  (error "Context expects 2 values" _g37515_)))
            (let ((_%verdict27722%_
                   (let () (declare (not safe)) (##values-ref _g37514_ 0)))
                  (_%closure27723%_
                   (let () (declare (not safe)) (##values-ref _g37514_ 1))))
              _%verdict27722%_)))))))
