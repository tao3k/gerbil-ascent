(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/scheme-query[1]#_g36328_|
    (##structure
     gx#syntax-quote::t
     'relational-solution::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36330_|
    (##structure
     gx#syntax-quote::t
     'make-relational-solution
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36332_|
    (##structure
     gx#syntax-quote::t
     'relational-solution?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36334_|
    (##structure
     gx#syntax-quote::t
     'relational-solution-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36336_|
    (##structure
     gx#syntax-quote::t
     'relational-solution-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36338_|
    (##structure
     gx#syntax-quote::t
     '&relational-solution-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36340_|
    (##structure
     gx#syntax-quote::t
     '&relational-solution-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36342_|
    (##structure
     gx#syntax-quote::t
     'relational-program-solution::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36344_|
    (##structure
     gx#syntax-quote::t
     'make-relational-program-solution
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36346_|
    (##structure
     gx#syntax-quote::t
     'relational-program-solution?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36348_|
    (##structure
     gx#syntax-quote::t
     'relational-program-solution-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36350_|
    (##structure
     gx#syntax-quote::t
     'relational-program-solution-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36352_|
    (##structure
     gx#syntax-quote::t
     '&relational-program-solution-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-query[1]#_g36354_|
    (##structure
     gx#syntax-quote::t
     '&relational-program-solution-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/scheme-query[:0:]#relational-solution|
      (let ((__obj36233
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36233
           'gerbil-ascent/program/scheme-query#relational-solution::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36233
           'relational-solution
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36233 '(result) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36233 '(result) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36233 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36233 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36233 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36233 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36233 '#f '13 '#f '#f))
        (let ((__tmp36327 |gerbil-ascent/program/scheme-query[1]#_g36328_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36233 __tmp36327 '4 '#f '#f))
        (let ((__tmp36329 |gerbil-ascent/program/scheme-query[1]#_g36330_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36233 __tmp36329 '14 '#f '#f))
        (let ((__tmp36331 |gerbil-ascent/program/scheme-query[1]#_g36332_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36233 __tmp36331 '15 '#f '#f))
        (let ((__tmp36333
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36334_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36233 __tmp36333 '16 '#f '#f))
        (let ((__tmp36335
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36336_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36233 __tmp36335 '17 '#f '#f))
        (let ((__tmp36337
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36338_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36233 __tmp36337 '18 '#f '#f))
        (let ((__tmp36339
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36340_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36233 __tmp36339 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36233 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36233 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36233 '() '21 '#f '#f))
        __obj36233))
    (define |gerbil-ascent/program/scheme-query[:0:]#relational-program-solution|
      (let ((__obj36234
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36234
           'gerbil-ascent/program/scheme-query#relational-program-solution::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36234
           'relational-program-solution
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36234 '(result) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36234 '(result) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36234 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36234 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36234 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36234 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36234 '#f '13 '#f '#f))
        (let ((__tmp36341 |gerbil-ascent/program/scheme-query[1]#_g36342_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36234 __tmp36341 '4 '#f '#f))
        (let ((__tmp36343 |gerbil-ascent/program/scheme-query[1]#_g36344_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36234 __tmp36343 '14 '#f '#f))
        (let ((__tmp36345 |gerbil-ascent/program/scheme-query[1]#_g36346_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36234 __tmp36345 '15 '#f '#f))
        (let ((__tmp36347
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36348_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36234 __tmp36347 '16 '#f '#f))
        (let ((__tmp36349
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36350_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36234 __tmp36349 '17 '#f '#f))
        (let ((__tmp36351
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36352_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36234 __tmp36351 '18 '#f '#f))
        (let ((__tmp36353
               (cons (cons 'result
                           |gerbil-ascent/program/scheme-query[1]#_g36354_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36234 __tmp36353 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36234 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36234 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36234 '() '21 '#f '#f))
        __obj36234))))
