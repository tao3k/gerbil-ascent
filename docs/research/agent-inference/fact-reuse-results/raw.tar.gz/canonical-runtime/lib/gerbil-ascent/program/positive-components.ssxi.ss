prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/program

(declare-type
 gerbil-ascent/program/positive-components#gerbil-ascent-run-positive-components!
 (@lambda 6
          #f
          signature:
          (return:
           t::t
           effect:
           #f
           arguments:
           #f
           unchecked:
           #f
           origin:
           gerbil-ascent/program/positive-components)))
