# SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
from ascent_test_support.crosspath_annotation import anchor,validate_annotations
import pytest


def episode(quote,**kw):
    return dict(quote=quote,occurrence=0,fragment=0,ready=True,claim='F0',paths=[[0,2],[1,2]],premiseEdges=[],kind='derive',prior=None,explanation='chain',**kw)


def test_anchor_repeated_occurrence_and_hallucinated_quote():
    assert anchor('abc abc','abc',1)==[4,7]
    with pytest.raises(ValueError):anchor('abc','def',0)


def test_repeat_requires_exact_truth_prior_and_premises():
    a=episode('first');b=episode('second');b['prior']=0
    accepted,rejected=validate_annotations('first then second',[a,b],[[0,0,2,1,2]],[],[[0,2],[1,2]],[0])
    assert not rejected and accepted[1]['definiteRepeatedDerivation']
    b['premiseEdges']=[[0,2]]
    accepted,rejected=validate_annotations('first then second',[a,b],[[0,0,2,1,2]],[[0,2]],[[0,2],[1,2]],[0])
    assert len(rejected)==1 and len(accepted)==1


def test_mentions_rechecks_false_and_missing_support_are_not_repeats():
    a=episode('first');b=episode('second');b.update(prior=0,kind='mention')
    accepted,rejected=validate_annotations('first second',[a,b],[[0,0,2,1,2]],[],[],[])
    assert rejected and not accepted[0]['nativeTruthMatches']
    b.update(kind='derive',paths=[[0,2]])
    accepted,rejected=validate_annotations('first second',[a,b],[[0,0,2,1,2]],[],[[0,2],[1,2]],[0])
    assert rejected and not any(x['definiteRepeatedDerivation'] for x in accepted)


def test_overlapping_self_link_is_rejected():
    a=episode('first');b=episode('first');b['prior']=0
    accepted,rejected=validate_annotations('first',[a,b],[[0,0,2,1,2]],[],[[0,2],[1,2]],[0])
    assert len(accepted)==1 and rejected
