(declare (block) (standard-bindings) (extended-bindings))
(begin
  (load-module "gerbil-ascent/candidate/program")
  (load-module "gerbil-ascent/candidate/proof-frame~0"))
