#ifdef ___LINKER_INFO
; File: "gerbil-ascent__program__source-log.c", produced by Gambit v4.9.8
(
409008
(C)
"gerbil-ascent__program__source-log"
("gerbil-ascent__program__source-log")
()
(("gerbil-ascent__program__source-log"))
( #|*/"*/"symbols|#
"gerbil-ascent/program/source-log#gerbil-ascent-source-log-equal?"
"gerbil-ascent/program/source-log#gerbil-ascent-source-log-rows"
"gerbil-ascent__program__source-log"
"gerbil-ascent__program__source-log#"
) #|*/"*/"symbols|#
( #|*/"*/"keywords|#
) #|*/"*/"keywords|#
( #|*/"*/"globals-s-d|#
"gerbil-ascent__program__source-log#"
) #|*/"*/"globals-s-d|#
( #|*/"*/"globals-s-nd|#
"gerbil-ascent/program/source-log#gerbil-ascent-source-log-equal?"
"gerbil-ascent/program/source-log#gerbil-ascent-source-log-rows"
"gerbil-ascent/program/source-log::timestamp"
) #|*/"*/"globals-s-nd|#
( #|*/"*/"globals-ns|#
"##append"
"equal?"
"foldl__0"
"reverse"
) #|*/"*/"globals-ns|#
( #|*/"*/"meta-info|#
) #|*/"*/"meta-info|#
)
#else
#define ___VERSION 409008
#define ___MODULE_NAME "gerbil-ascent__program__source-log"
#define ___LINKER_ID ___LNK_gerbil_2d_ascent____program____source_2d_log
#define ___MH_PROC ___H_gerbil_2d_ascent____program____source_2d_log
#define ___SCRIPT_LINE 0
#define ___SYMCOUNT 4
#define ___GLOCOUNT 8
#define ___SUPCOUNT 4
#define ___SUBCOUNT 4
#define ___LBLCOUNT 15
#define ___MODDESCR ___REF_SUB(1)
#include "gambit.h"

___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows)
___NEED_SYM(___S_gerbil_2d_ascent____program____source_2d_log)
___NEED_SYM(___S_gerbil_2d_ascent____program____source_2d_log_23_)

___NEED_GLO(___G__23__23_append)
___NEED_GLO(___G_equal_3f_)
___NEED_GLO(___G_foldl____0)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_source_2d_log_3a__3a_timestamp)
___NEED_GLO(___G_gerbil_2d_ascent____program____source_2d_log_23_)
___NEED_GLO(___G_reverse)

___BEGIN_SYM
___DEF_SYM(0,___S_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_,"gerbil-ascent/program/source-log#gerbil-ascent-source-log-equal?")

___DEF_SYM(1,___S_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows,"gerbil-ascent/program/source-log#gerbil-ascent-source-log-rows")

___DEF_SYM(2,___S_gerbil_2d_ascent____program____source_2d_log,"gerbil-ascent__program__source-log")

___DEF_SYM(3,___S_gerbil_2d_ascent____program____source_2d_log_23_,"gerbil-ascent__program__source-log#")

___END_SYM

#define ___SYM_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_ ___SYM(0,___S_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows ___SYM(1,___S_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows)
#define ___SYM_gerbil_2d_ascent____program____source_2d_log ___SYM(2,___S_gerbil_2d_ascent____program____source_2d_log)
#define ___SYM_gerbil_2d_ascent____program____source_2d_log_23_ ___SYM(3,___S_gerbil_2d_ascent____program____source_2d_log_23_)

___BEGIN_GLO
___DEF_GLO(0,"gerbil-ascent/program/source-log#gerbil-ascent-source-log-equal?")

___DEF_GLO(1,"gerbil-ascent/program/source-log#gerbil-ascent-source-log-rows")

___DEF_GLO(2,"gerbil-ascent/program/source-log::timestamp")

___DEF_GLO(3,"gerbil-ascent__program__source-log#")

___DEF_GLO(4,"##append")
___DEF_GLO(5,"equal?")
___DEF_GLO(6,"foldl__0")
___DEF_GLO(7,"reverse")
___END_GLO

#define ___GLO_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_ ___GLO(0,___G_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_ ___PRM(0,___G_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows ___GLO(1,___G_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows ___PRM(1,___G_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_source_2d_log_3a__3a_timestamp ___GLO(2,___G_gerbil_2d_ascent_2f_program_2f_source_2d_log_3a__3a_timestamp)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_source_2d_log_3a__3a_timestamp ___PRM(2,___G_gerbil_2d_ascent_2f_program_2f_source_2d_log_3a__3a_timestamp)
#define ___GLO_gerbil_2d_ascent____program____source_2d_log_23_ ___GLO(3,___G_gerbil_2d_ascent____program____source_2d_log_23_)
#define ___PRM_gerbil_2d_ascent____program____source_2d_log_23_ ___PRM(3,___G_gerbil_2d_ascent____program____source_2d_log_23_)
#define ___GLO__23__23_append ___GLO(4,___G__23__23_append)
#define ___PRM__23__23_append ___PRM(4,___G__23__23_append)
#define ___GLO_equal_3f_ ___GLO(5,___G_equal_3f_)
#define ___PRM_equal_3f_ ___PRM(5,___G_equal_3f_)
#define ___GLO_foldl____0 ___GLO(6,___G_foldl____0)
#define ___PRM_foldl____0 ___PRM(6,___G_foldl____0)
#define ___GLO_reverse ___GLO(7,___G_reverse)
#define ___PRM_reverse ___PRM(7,___G_reverse)

___DEF_SUB_BIGFIX(___X0,1UL)
               ___BIGFIX1(0x6acafcb0L)
___DEF_SUB_VEC(___X1,6UL)
               ___VEC1(___REF_SUB(2))
               ___VEC1(___REF_SUB(3))
               ___VEC1(___REF_NUL)
               ___VEC1(___REF_FIX(1))
               ___VEC1(___REF_PRC(1))
               ___VEC1(___REF_FAL)
               ___VEC0
___DEF_SUB_VEC(___X2,1UL)
               ___VEC1(___REF_SYM(2,___S_gerbil_2d_ascent____program____source_2d_log))
               ___VEC0
___DEF_SUB_VEC(___X3,0UL)
               ___VEC0

___BEGIN_SUB
 ___DEF_SUB(___X0)
,___DEF_SUB(___X1)
,___DEF_SUB(___X2)
,___DEF_SUB(___X3)
___END_SUB



#undef ___MD_ALL
#define ___MD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___MR_ALL
#define ___MR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___MW_ALL
#define ___MW_ALL ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_M_COD
___BEGIN_M_HLBL
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent____program____source_2d_log_23_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___END_M_HLBL

___BEGIN_M_SW

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent____program____source_2d_log_23_
#undef ___PH_LBL0
#define ___PH_LBL0 1
#undef ___PD_ALL
#define ___PD_ALL ___D_R0 ___D_R1
#undef ___PR_ALL
#define ___PR_ALL ___R_R0 ___R_R1
#undef ___PW_ALL
#define ___PW_ALL ___W_R1
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent____program____source_2d_log_23_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent____program____source_2d_log_23_)
   ___IF_NARGS_EQ(0,___NOTHING)
   ___WRONG_NARGS(0,0,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent____program____source_2d_log_23_)
   ___SET_GLO(2,___G_gerbil_2d_ascent_2f_program_2f_source_2d_log_3a__3a_timestamp,___BIGFIX(0,1791687856LL))
   ___SET_R1(___VOID)
   ___JUMPRET(___R0)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows
#undef ___PH_LBL0
#define ___PH_LBL0 3
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R2
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R2
#undef ___PW_ALL
#define ___PW_ALL ___W_FP ___W_R0 ___W_R1 ___W_R2
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows)
   ___IF_NARGS_EQ(2,___NOTHING)
   ___WRONG_NARGS(0,2,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows)
   ___IF(___NULLP(___R2))
   ___GOTO(___L3_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows)
   ___END_IF
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R1(___R2)
   ___SET_R0(___LBL(1))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(1),___PRM_reverse)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows)
   ___SET_R2(___R1)
   ___SET_R1(___STK(-6))
   ___SET_R0(___STK(-7))
   ___POLL(2)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows)
   ___ADJFP(-8)
   ___JUMPPRM(___SET_NARGS(2),___PRM__23__23_append)
___DEF_GLBL(___L3_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows)
   ___JUMPRET(___R0)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_
#undef ___PH_LBL0
#define ___PH_LBL0 7
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___IF_NARGS_EQ(3,___NOTHING)
   ___WRONG_NARGS(0,3,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___IF(___NOT(___NULLP(___R2)))
   ___GOTO(___L13_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___END_IF
   ___IF(___EQP(___R1,___R3))
   ___GOTO(___L12_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___END_IF
   ___IF(___NOT(___POSSIBLYEQUALP(___R1,___R3)))
   ___GOTO(___L8_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___END_IF
   ___SET_R2(___R3)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___JUMPPRM(___SET_NARGS(2),___PRM_equal_3f_)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L9_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___END_IF
   ___SET_R0(___STK(-7))
   ___ADJFP(-8)
___DEF_GLBL(___L8_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___SET_R1(___FAL)
   ___JUMPRET(___R0)
___DEF_GLBL(___L9_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___SET_R2(___STK(-6))
   ___SET_R0(___STK(-7))
   ___ADJFP(-8)
   ___GOTO(___L10_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___IF_NARGS_EQ(2,___NOTHING)
   ___WRONG_NARGS(3,2,0,0)
   ___IF(___NOT(___PAIRP(___R2)))
   ___GOTO(___L8_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___END_IF
   ___SET_R3(___CAR(___R2))
   ___IF(___NOT(___EQP(___R1,___R3)))
   ___GOTO(___L11_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___END_IF
___DEF_GLBL(___L10_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___SET_R1(___CDR(___R2))
   ___JUMPRET(___R0)
___DEF_GLBL(___L11_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___IF(___NOT(___POSSIBLYEQUALP(___R1,___R3)))
   ___GOTO(___L8_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___END_IF
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R2)
   ___SET_R2(___R3)
   ___SET_R0(___LBL(2))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM_equal_3f_)
___DEF_GLBL(___L12_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___SET_R1(___TRU)
   ___JUMPRET(___R0)
___DEF_GLBL(___L13_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R2)
   ___SET_STK(3,___R3)
   ___SET_R3(___R1)
   ___SET_R2(___STK(3))
   ___SET_R1(___LBL(3))
   ___ADJFP(8)
   ___POLL(4)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___SET_R0(___LBL(5))
   ___JUMPGLONOTSAFE(___SET_NARGS(3),6,___G_foldl____0)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L14_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___END_IF
   ___SET_STK(-5,___R1)
   ___SET_R1(___STK(-6))
   ___SET_R0(___LBL(6))
   ___JUMPPRM(___SET_NARGS(1),___PRM_reverse)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___IF(___EQP(___R1,___STK(-5)))
   ___GOTO(___L15_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___END_IF
   ___IF(___NOT(___POSSIBLYEQUALP(___R1,___STK(-5))))
   ___GOTO(___L14_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___END_IF
   ___SET_R2(___STK(-5))
   ___SET_R0(___STK(-7))
   ___POLL(7)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___ADJFP(-8)
   ___JUMPPRM(___SET_NARGS(2),___PRM_equal_3f_)
___DEF_GLBL(___L14_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___SET_R1(___FAL)
   ___ADJFP(-8)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L15_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_)
   ___SET_R1(___TRU)
   ___ADJFP(-8)
   ___JUMPRET(___STK(1))
___END_P_SW
___END_P_COD

___END_M_SW
___END_M_COD

___BEGIN_LBL
 ___DEF_LBL_INTRO(___H_gerbil_2d_ascent____program____source_2d_log_23_,___REF_SYM(3,___S_gerbil_2d_ascent____program____source_2d_log_23_),___REF_FAL,1,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____program____source_2d_log_23_,0,-1)
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows,___REF_SYM(1,___S_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows),___REF_FAL,3,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows,2,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows,___IFD(___RETI,8,8,0x3f00L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_,___REF_SYM(0,___S_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_),___REF_FAL,8,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_,3,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_,2,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_,___IFD(___RETN,5,0,0x5L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_,___IFD(___RETI,8,8,0x3f00L))
___END_LBL

___BEGIN_MOD_PRM
___DEF_MOD_PRM(3,___G_gerbil_2d_ascent____program____source_2d_log_23_,1)
___DEF_MOD_PRM(1,___G_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows,3)
___DEF_MOD_PRM(0,___G_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_,7)
___END_MOD_PRM

___BEGIN_MOD_C_INIT
___END_MOD_C_INIT

___BEGIN_MOD_GLO
___DEF_MOD_GLO(3,___G_gerbil_2d_ascent____program____source_2d_log_23_,1)
___DEF_MOD_GLO(1,___G_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows,3)
___DEF_MOD_GLO(0,___G_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_,7)
___END_MOD_GLO

___BEGIN_MOD_SYM_KEY
___DEF_MOD_SYM(0,___S_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_equal_3f_,"gerbil-ascent/program/source-log#gerbil-ascent-source-log-equal?")

___DEF_MOD_SYM(1,___S_gerbil_2d_ascent_2f_program_2f_source_2d_log_23_gerbil_2d_ascent_2d_source_2d_log_2d_rows,"gerbil-ascent/program/source-log#gerbil-ascent-source-log-rows")

___DEF_MOD_SYM(2,___S_gerbil_2d_ascent____program____source_2d_log,"gerbil-ascent__program__source-log")

___DEF_MOD_SYM(3,___S_gerbil_2d_ascent____program____source_2d_log_23_,"gerbil-ascent__program__source-log#")

___END_MOD_SYM_KEY

#endif
