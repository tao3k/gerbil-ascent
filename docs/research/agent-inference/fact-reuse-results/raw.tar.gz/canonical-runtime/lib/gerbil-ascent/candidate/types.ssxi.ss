prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/candidate

(begin
  (declare-class
   gerbil-ascent/candidate/types#reasoning-snapshot::t
   (@class gerbil-ascent/candidate/types#reasoning-snapshot::t
           ()
           (object::t t::t)
           (identity generation digest relations)
           (identity generation digest relations)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-snapshot::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/types#reasoning-snapshot::t)
    'class::t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-snapshot?
   (@predicate gerbil-ascent/candidate/types#reasoning-snapshot::t))
  (declare-type
   gerbil-ascent/candidate/types#make-reasoning-snapshot
   (@constructor gerbil-ascent/candidate/types#reasoning-snapshot::t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-snapshot-identity
   (@accessor gerbil-ascent/candidate/types#reasoning-snapshot::t identity #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-snapshot-generation
   (@accessor
    gerbil-ascent/candidate/types#reasoning-snapshot::t
    generation
    #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-snapshot-digest
   (@accessor gerbil-ascent/candidate/types#reasoning-snapshot::t digest #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-snapshot-relations
   (@accessor
    gerbil-ascent/candidate/types#reasoning-snapshot::t
    relations
    #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-snapshot-identity-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-snapshot::t identity #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-snapshot-generation-set!
   (@mutator
    gerbil-ascent/candidate/types#reasoning-snapshot::t
    generation
    #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-snapshot-digest-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-snapshot::t digest #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-snapshot-relations-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-snapshot::t relations #t))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-snapshot-identity
   (@accessor gerbil-ascent/candidate/types#reasoning-snapshot::t identity #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-snapshot-generation
   (@accessor
    gerbil-ascent/candidate/types#reasoning-snapshot::t
    generation
    #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-snapshot-digest
   (@accessor gerbil-ascent/candidate/types#reasoning-snapshot::t digest #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-snapshot-relations
   (@accessor
    gerbil-ascent/candidate/types#reasoning-snapshot::t
    relations
    #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-snapshot-identity-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-snapshot::t identity #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-snapshot-generation-set!
   (@mutator
    gerbil-ascent/candidate/types#reasoning-snapshot::t
    generation
    #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-snapshot-digest-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-snapshot::t digest #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-snapshot-relations-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-snapshot::t relations #f))
  (declare-class
   gerbil-ascent/candidate/types#reasoning-diagnostic::t
   (@class gerbil-ascent/candidate/types#reasoning-diagnostic::t
           ()
           (object::t t::t)
           (code path detail)
           (code path detail)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-diagnostic::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/types#reasoning-diagnostic::t)
    'class::t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-diagnostic?
   (@predicate gerbil-ascent/candidate/types#reasoning-diagnostic::t))
  (declare-type
   gerbil-ascent/candidate/types#make-reasoning-diagnostic
   (@constructor gerbil-ascent/candidate/types#reasoning-diagnostic::t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-diagnostic-code
   (@accessor gerbil-ascent/candidate/types#reasoning-diagnostic::t code #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-diagnostic-path
   (@accessor gerbil-ascent/candidate/types#reasoning-diagnostic::t path #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-diagnostic-detail
   (@accessor gerbil-ascent/candidate/types#reasoning-diagnostic::t detail #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-diagnostic-code-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-diagnostic::t code #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-diagnostic-path-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-diagnostic::t path #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-diagnostic-detail-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-diagnostic::t detail #t))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-diagnostic-code
   (@accessor gerbil-ascent/candidate/types#reasoning-diagnostic::t code #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-diagnostic-path
   (@accessor gerbil-ascent/candidate/types#reasoning-diagnostic::t path #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-diagnostic-detail
   (@accessor gerbil-ascent/candidate/types#reasoning-diagnostic::t detail #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-diagnostic-code-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-diagnostic::t code #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-diagnostic-path-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-diagnostic::t path #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-diagnostic-detail-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-diagnostic::t detail #f))
  (declare-class
   gerbil-ascent/candidate/types#reasoning-candidate::t
   (@class gerbil-ascent/candidate/types#reasoning-candidate::t
           ()
           (object::t t::t)
           (relations facts rules query limits)
           (relations facts rules query limits)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-candidate::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/types#reasoning-candidate::t)
    'class::t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-candidate?
   (@predicate gerbil-ascent/candidate/types#reasoning-candidate::t))
  (declare-type
   gerbil-ascent/candidate/types#make-reasoning-candidate
   (@constructor gerbil-ascent/candidate/types#reasoning-candidate::t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-candidate-relations
   (@accessor
    gerbil-ascent/candidate/types#reasoning-candidate::t
    relations
    #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-candidate-facts
   (@accessor gerbil-ascent/candidate/types#reasoning-candidate::t facts #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-candidate-rules
   (@accessor gerbil-ascent/candidate/types#reasoning-candidate::t rules #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-candidate-query
   (@accessor gerbil-ascent/candidate/types#reasoning-candidate::t query #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-candidate-limits
   (@accessor gerbil-ascent/candidate/types#reasoning-candidate::t limits #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-candidate-relations-set!
   (@mutator
    gerbil-ascent/candidate/types#reasoning-candidate::t
    relations
    #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-candidate-facts-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-candidate::t facts #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-candidate-rules-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-candidate::t rules #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-candidate-query-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-candidate::t query #t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-candidate-limits-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-candidate::t limits #t))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-candidate-relations
   (@accessor
    gerbil-ascent/candidate/types#reasoning-candidate::t
    relations
    #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-candidate-facts
   (@accessor gerbil-ascent/candidate/types#reasoning-candidate::t facts #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-candidate-rules
   (@accessor gerbil-ascent/candidate/types#reasoning-candidate::t rules #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-candidate-query
   (@accessor gerbil-ascent/candidate/types#reasoning-candidate::t query #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-candidate-limits
   (@accessor gerbil-ascent/candidate/types#reasoning-candidate::t limits #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-candidate-relations-set!
   (@mutator
    gerbil-ascent/candidate/types#reasoning-candidate::t
    relations
    #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-candidate-facts-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-candidate::t facts #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-candidate-rules-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-candidate::t rules #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-candidate-query-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-candidate::t query #f))
  (declare-type
   gerbil-ascent/candidate/types#&reasoning-candidate-limits-set!
   (@mutator gerbil-ascent/candidate/types#reasoning-candidate::t limits #f))
  (declare-class
   gerbil-ascent/candidate/types#candidate-rejection::t
   (@class gerbil-ascent/candidate/types#candidate-rejection::t
           ()
           (object::t t::t)
           (diagnostic)
           (diagnostic)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/candidate/types#candidate-rejection::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/types#candidate-rejection::t)
    'class::t))
  (declare-type
   gerbil-ascent/candidate/types#candidate-rejection?
   (@predicate gerbil-ascent/candidate/types#candidate-rejection::t))
  (declare-type
   gerbil-ascent/candidate/types#make-candidate-rejection
   (@constructor gerbil-ascent/candidate/types#candidate-rejection::t))
  (declare-type
   gerbil-ascent/candidate/types#candidate-rejection-diagnostic
   (@accessor
    gerbil-ascent/candidate/types#candidate-rejection::t
    diagnostic
    #t))
  (declare-type
   gerbil-ascent/candidate/types#candidate-rejection-diagnostic-set!
   (@mutator
    gerbil-ascent/candidate/types#candidate-rejection::t
    diagnostic
    #t))
  (declare-type
   gerbil-ascent/candidate/types#&candidate-rejection-diagnostic
   (@accessor
    gerbil-ascent/candidate/types#candidate-rejection::t
    diagnostic
    #f))
  (declare-type
   gerbil-ascent/candidate/types#&candidate-rejection-diagnostic-set!
   (@mutator
    gerbil-ascent/candidate/types#candidate-rejection::t
    diagnostic
    #f))
  (declare-type
   gerbil-ascent/candidate/types#+max-relations+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/types#+max-relations+)
    'fixnum::t))
  (declare-type
   gerbil-ascent/candidate/types#+max-rules+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/types#+max-rules+)
    'fixnum::t))
  (declare-type
   gerbil-ascent/candidate/types#+max-input-facts+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/types#+max-input-facts+)
    'fixnum::t))
  (declare-type
   gerbil-ascent/candidate/types#+max-derived-facts+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/types#+max-derived-facts+)
    'fixnum::t))
  (declare-type
   gerbil-ascent/candidate/types#+max-output-facts+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/types#+max-output-facts+)
    'fixnum::t))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-snapshot-content-digest
   (@lambda 3
            #f
            signature:
            (return:
             string::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/types)))
  (declare-type
   gerbil-ascent/candidate/types#snapshot-scalar?
   (@lambda 1
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/types)))
  (declare-type
   gerbil-ascent/candidate/types#snapshot-row-valid?
   (@lambda 2
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/types)))
  (declare-type
   gerbil-ascent/candidate/types#snapshot-relation-valid?
   (@lambda 3
            #f
            signature:
            (return:
             (nullable true::t)
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/types)))
  (declare-type
   gerbil-ascent/candidate/types#reasoning-snapshot-valid?
   (@lambda 1
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/types))))
