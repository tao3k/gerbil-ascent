prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/candidate

(begin
  (declare-class
   gerbil-ascent/candidate/feedback#reasoning-feedback::t
   (@class gerbil-ascent/candidate/feedback#reasoning-feedback::t
           ()
           (object::t t::t)
           (status reason missing extra)
           (status reason missing extra)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/candidate/feedback#reasoning-feedback::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/feedback#reasoning-feedback::t)
    'class::t))
  (declare-type
   gerbil-ascent/candidate/feedback#reasoning-feedback?
   (@predicate gerbil-ascent/candidate/feedback#reasoning-feedback::t))
  (declare-type
   gerbil-ascent/candidate/feedback#make-reasoning-feedback
   (@constructor gerbil-ascent/candidate/feedback#reasoning-feedback::t))
  (declare-type
   gerbil-ascent/candidate/feedback#reasoning-feedback-status
   (@accessor
    gerbil-ascent/candidate/feedback#reasoning-feedback::t
    status
    #t))
  (declare-type
   gerbil-ascent/candidate/feedback#reasoning-feedback-reason
   (@accessor
    gerbil-ascent/candidate/feedback#reasoning-feedback::t
    reason
    #t))
  (declare-type
   gerbil-ascent/candidate/feedback#reasoning-feedback-missing
   (@accessor
    gerbil-ascent/candidate/feedback#reasoning-feedback::t
    missing
    #t))
  (declare-type
   gerbil-ascent/candidate/feedback#reasoning-feedback-extra
   (@accessor gerbil-ascent/candidate/feedback#reasoning-feedback::t extra #t))
  (declare-type
   gerbil-ascent/candidate/feedback#reasoning-feedback-status-set!
   (@mutator gerbil-ascent/candidate/feedback#reasoning-feedback::t status #t))
  (declare-type
   gerbil-ascent/candidate/feedback#reasoning-feedback-reason-set!
   (@mutator gerbil-ascent/candidate/feedback#reasoning-feedback::t reason #t))
  (declare-type
   gerbil-ascent/candidate/feedback#reasoning-feedback-missing-set!
   (@mutator
    gerbil-ascent/candidate/feedback#reasoning-feedback::t
    missing
    #t))
  (declare-type
   gerbil-ascent/candidate/feedback#reasoning-feedback-extra-set!
   (@mutator gerbil-ascent/candidate/feedback#reasoning-feedback::t extra #t))
  (declare-type
   gerbil-ascent/candidate/feedback#&reasoning-feedback-status
   (@accessor
    gerbil-ascent/candidate/feedback#reasoning-feedback::t
    status
    #f))
  (declare-type
   gerbil-ascent/candidate/feedback#&reasoning-feedback-reason
   (@accessor
    gerbil-ascent/candidate/feedback#reasoning-feedback::t
    reason
    #f))
  (declare-type
   gerbil-ascent/candidate/feedback#&reasoning-feedback-missing
   (@accessor
    gerbil-ascent/candidate/feedback#reasoning-feedback::t
    missing
    #f))
  (declare-type
   gerbil-ascent/candidate/feedback#&reasoning-feedback-extra
   (@accessor gerbil-ascent/candidate/feedback#reasoning-feedback::t extra #f))
  (declare-type
   gerbil-ascent/candidate/feedback#&reasoning-feedback-status-set!
   (@mutator gerbil-ascent/candidate/feedback#reasoning-feedback::t status #f))
  (declare-type
   gerbil-ascent/candidate/feedback#&reasoning-feedback-reason-set!
   (@mutator gerbil-ascent/candidate/feedback#reasoning-feedback::t reason #f))
  (declare-type
   gerbil-ascent/candidate/feedback#&reasoning-feedback-missing-set!
   (@mutator
    gerbil-ascent/candidate/feedback#reasoning-feedback::t
    missing
    #f))
  (declare-type
   gerbil-ascent/candidate/feedback#&reasoning-feedback-extra-set!
   (@mutator gerbil-ascent/candidate/feedback#reasoning-feedback::t extra #f))
  (declare-type
   gerbil-ascent/candidate/feedback#refuse-feedback
   (@lambda 1
            #f
            signature:
            (return:
             gerbil-ascent/candidate/feedback#reasoning-feedback::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/feedback)))
  (declare-type
   gerbil-ascent/candidate/feedback#receipt-feedback-reason
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/feedback)))
  (declare-type
   gerbil-ascent/candidate/feedback#reasoning-compare-rows
   (@lambda 4
            #f
            signature:
            (return:
             gerbil-ascent/candidate/feedback#reasoning-feedback::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/feedback)))
  (declare-type
   gerbil-ascent/candidate/feedback#reasoning-compare-attempts
   (@lambda 5
            #f
            signature:
            (return:
             gerbil-ascent/candidate/feedback#reasoning-feedback::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/feedback)))
  (declare-type
   gerbil-ascent/candidate/feedback#compare-qualified-rows
   (@lambda 2
            #f
            signature:
            (return:
             gerbil-ascent/candidate/feedback#reasoning-feedback::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/feedback))))
