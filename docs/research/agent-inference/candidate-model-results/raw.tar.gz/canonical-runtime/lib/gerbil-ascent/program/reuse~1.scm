(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/reuse[1]#_g37131_|
    (##structure
     gx#syntax-quote::t
     'native-reuse::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37133_|
    (##structure
     gx#syntax-quote::t
     'make-native-reuse
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37135_|
    (##structure
     gx#syntax-quote::t
     'native-reuse?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37137_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37138_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-affected
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37139_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-reader
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37140_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-publication
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37141_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-source-only
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37143_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37144_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-affected-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37145_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-reader-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37146_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-publication-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37147_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-source-only-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37149_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37150_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-affected
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37151_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-reader
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37152_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-publication
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37153_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-source-only
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37155_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37156_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-affected-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37157_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-reader-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37158_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-publication-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37159_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-source-only-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37161_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37163_|
    (##structure
     gx#syntax-quote::t
     'make-closure-seed-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37165_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37167_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-all
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37168_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-seen
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37169_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-delta
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37170_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-all-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37171_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-delta-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37172_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-lattice-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37174_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-all-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37175_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-seen-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37176_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-delta-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37177_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-all-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37178_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-delta-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37179_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-lattice-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37181_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-all
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37182_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-seen
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37183_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-delta
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37184_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-all-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37185_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-delta-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37186_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-lattice-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37188_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-all-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37189_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-seen-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37190_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-delta-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37191_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-all-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37192_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-delta-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37193_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-lattice-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/reuse[:0:]#native-reuse|
      (let ((__obj37067
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37067
           'gerbil-ascent/program/reuse#native-reuse::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37067 'native-reuse '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37067
           '(result affected reader publication source-only)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37067
           '(result affected reader publication source-only)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37067 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37067 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37067 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37067 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37067 '#f '13 '#f '#f))
        (let ((__tmp37130 |gerbil-ascent/program/reuse[1]#_g37131_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37067 __tmp37130 '4 '#f '#f))
        (let ((__tmp37132 |gerbil-ascent/program/reuse[1]#_g37133_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37067 __tmp37132 '14 '#f '#f))
        (let ((__tmp37134 |gerbil-ascent/program/reuse[1]#_g37135_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37067 __tmp37134 '15 '#f '#f))
        (let ((__tmp37136
               (cons (cons 'result |gerbil-ascent/program/reuse[1]#_g37137_|)
                     (cons (cons 'affected
                                 |gerbil-ascent/program/reuse[1]#_g37138_|)
                           (cons (cons 'reader
                                       |gerbil-ascent/program/reuse[1]#_g37139_|)
                                 (cons (cons 'publication
                                             |gerbil-ascent/program/reuse[1]#_g37140_|)
                                       (cons (cons 'source-only
                                                   |gerbil-ascent/program/reuse[1]#_g37141_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37067 __tmp37136 '16 '#f '#f))
        (let ((__tmp37142
               (cons (cons 'result |gerbil-ascent/program/reuse[1]#_g37143_|)
                     (cons (cons 'affected
                                 |gerbil-ascent/program/reuse[1]#_g37144_|)
                           (cons (cons 'reader
                                       |gerbil-ascent/program/reuse[1]#_g37145_|)
                                 (cons (cons 'publication
                                             |gerbil-ascent/program/reuse[1]#_g37146_|)
                                       (cons (cons 'source-only
                                                   |gerbil-ascent/program/reuse[1]#_g37147_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37067 __tmp37142 '17 '#f '#f))
        (let ((__tmp37148
               (cons (cons 'result |gerbil-ascent/program/reuse[1]#_g37149_|)
                     (cons (cons 'affected
                                 |gerbil-ascent/program/reuse[1]#_g37150_|)
                           (cons (cons 'reader
                                       |gerbil-ascent/program/reuse[1]#_g37151_|)
                                 (cons (cons 'publication
                                             |gerbil-ascent/program/reuse[1]#_g37152_|)
                                       (cons (cons 'source-only
                                                   |gerbil-ascent/program/reuse[1]#_g37153_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37067 __tmp37148 '18 '#f '#f))
        (let ((__tmp37154
               (cons (cons 'result |gerbil-ascent/program/reuse[1]#_g37155_|)
                     (cons (cons 'affected
                                 |gerbil-ascent/program/reuse[1]#_g37156_|)
                           (cons (cons 'reader
                                       |gerbil-ascent/program/reuse[1]#_g37157_|)
                                 (cons (cons 'publication
                                             |gerbil-ascent/program/reuse[1]#_g37158_|)
                                       (cons (cons 'source-only
                                                   |gerbil-ascent/program/reuse[1]#_g37159_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37067 __tmp37154 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37067 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37067 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37067 '() '21 '#f '#f))
        __obj37067))
    (define |gerbil-ascent/program/reuse[:0:]#closure-seed-state|
      (let ((__obj37068
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37068
           'gerbil-ascent/program/reuse#closure-seed-state::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37068
           'closure-seed-state
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37068
           '(all seen delta all-size delta-size lattice-rows)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37068
           '(all seen delta all-size delta-size lattice-rows)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37068 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37068 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37068 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37068 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37068 '#f '13 '#f '#f))
        (let ((__tmp37160 |gerbil-ascent/program/reuse[1]#_g37161_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37068 __tmp37160 '4 '#f '#f))
        (let ((__tmp37162 |gerbil-ascent/program/reuse[1]#_g37163_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37068 __tmp37162 '14 '#f '#f))
        (let ((__tmp37164 |gerbil-ascent/program/reuse[1]#_g37165_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37068 __tmp37164 '15 '#f '#f))
        (let ((__tmp37166
               (cons (cons 'all |gerbil-ascent/program/reuse[1]#_g37167_|)
                     (cons (cons 'seen
                                 |gerbil-ascent/program/reuse[1]#_g37168_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/reuse[1]#_g37169_|)
                                 (cons (cons 'all-size
                                             |gerbil-ascent/program/reuse[1]#_g37170_|)
                                       (cons (cons 'delta-size
                                                   |gerbil-ascent/program/reuse[1]#_g37171_|)
                                             (cons (cons 'lattice-rows
                                                         |gerbil-ascent/program/reuse[1]#_g37172_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37068 __tmp37166 '16 '#f '#f))
        (let ((__tmp37173
               (cons (cons 'all |gerbil-ascent/program/reuse[1]#_g37174_|)
                     (cons (cons 'seen
                                 |gerbil-ascent/program/reuse[1]#_g37175_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/reuse[1]#_g37176_|)
                                 (cons (cons 'all-size
                                             |gerbil-ascent/program/reuse[1]#_g37177_|)
                                       (cons (cons 'delta-size
                                                   |gerbil-ascent/program/reuse[1]#_g37178_|)
                                             (cons (cons 'lattice-rows
                                                         |gerbil-ascent/program/reuse[1]#_g37179_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37068 __tmp37173 '17 '#f '#f))
        (let ((__tmp37180
               (cons (cons 'all |gerbil-ascent/program/reuse[1]#_g37181_|)
                     (cons (cons 'seen
                                 |gerbil-ascent/program/reuse[1]#_g37182_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/reuse[1]#_g37183_|)
                                 (cons (cons 'all-size
                                             |gerbil-ascent/program/reuse[1]#_g37184_|)
                                       (cons (cons 'delta-size
                                                   |gerbil-ascent/program/reuse[1]#_g37185_|)
                                             (cons (cons 'lattice-rows
                                                         |gerbil-ascent/program/reuse[1]#_g37186_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37068 __tmp37180 '18 '#f '#f))
        (let ((__tmp37187
               (cons (cons 'all |gerbil-ascent/program/reuse[1]#_g37188_|)
                     (cons (cons 'seen
                                 |gerbil-ascent/program/reuse[1]#_g37189_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/reuse[1]#_g37190_|)
                                 (cons (cons 'all-size
                                             |gerbil-ascent/program/reuse[1]#_g37191_|)
                                       (cons (cons 'delta-size
                                                   |gerbil-ascent/program/reuse[1]#_g37192_|)
                                             (cons (cons 'lattice-rows
                                                         |gerbil-ascent/program/reuse[1]#_g37193_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37068 __tmp37187 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37068 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37068 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37068 '() '21 '#f '#f))
        __obj37068))))
