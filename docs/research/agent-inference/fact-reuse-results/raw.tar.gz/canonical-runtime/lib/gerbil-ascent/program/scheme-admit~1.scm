(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/scheme-admit[1]#_g38141_|
    (##structure
     gx#syntax-quote::t
     'relational-admission::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38143_|
    (##structure
     gx#syntax-quote::t
     'make-relational-admission
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38145_|
    (##structure
     gx#syntax-quote::t
     'relational-admission?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38147_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-run
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38149_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-run-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38151_|
    (##structure
     gx#syntax-quote::t
     '&relational-admission-run
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38153_|
    (##structure
     gx#syntax-quote::t
     '&relational-admission-run-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38155_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38157_|
    (##structure
     gx#syntax-quote::t
     'make-relational-diagnostic
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38159_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38161_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic-code
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38162_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic-path
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38163_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic-detail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38165_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic-code-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38166_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic-path-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38167_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic-detail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38169_|
    (##structure
     gx#syntax-quote::t
     '&relational-diagnostic-code
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38170_|
    (##structure
     gx#syntax-quote::t
     '&relational-diagnostic-path
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38171_|
    (##structure
     gx#syntax-quote::t
     '&relational-diagnostic-detail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38173_|
    (##structure
     gx#syntax-quote::t
     '&relational-diagnostic-code-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38174_|
    (##structure
     gx#syntax-quote::t
     '&relational-diagnostic-path-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38175_|
    (##structure
     gx#syntax-quote::t
     '&relational-diagnostic-detail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38177_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-report::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38179_|
    (##structure
     gx#syntax-quote::t
     'make-relational-admission-report
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38181_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-report?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38183_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-report-admission
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38184_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-report-diagnostic
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38186_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-report-admission-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38187_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-report-diagnostic-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38189_|
    (##structure
     gx#syntax-quote::t
     '&relational-admission-report-admission
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38190_|
    (##structure
     gx#syntax-quote::t
     '&relational-admission-report-diagnostic
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38192_|
    (##structure
     gx#syntax-quote::t
     '&relational-admission-report-admission-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g38193_|
    (##structure
     gx#syntax-quote::t
     '&relational-admission-report-diagnostic-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/scheme-admit[:0:]#relational-admission|
      (let ((__obj37908
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37908
           'gerbil-ascent/program/scheme-admit#relational-admission::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37908
           'relational-admission
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37908 '(run) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37908 '(run) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37908 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37908 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37908 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37908 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37908 '#f '13 '#f '#f))
        (let ((__tmp38140 |gerbil-ascent/program/scheme-admit[1]#_g38141_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37908 __tmp38140 '4 '#f '#f))
        (let ((__tmp38142 |gerbil-ascent/program/scheme-admit[1]#_g38143_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37908 __tmp38142 '14 '#f '#f))
        (let ((__tmp38144 |gerbil-ascent/program/scheme-admit[1]#_g38145_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37908 __tmp38144 '15 '#f '#f))
        (let ((__tmp38146
               (cons (cons 'run
                           |gerbil-ascent/program/scheme-admit[1]#_g38147_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj37908 __tmp38146 '16 '#f '#f))
        (let ((__tmp38148
               (cons (cons 'run
                           |gerbil-ascent/program/scheme-admit[1]#_g38149_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj37908 __tmp38148 '17 '#f '#f))
        (let ((__tmp38150
               (cons (cons 'run
                           |gerbil-ascent/program/scheme-admit[1]#_g38151_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj37908 __tmp38150 '18 '#f '#f))
        (let ((__tmp38152
               (cons (cons 'run
                           |gerbil-ascent/program/scheme-admit[1]#_g38153_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj37908 __tmp38152 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37908 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37908 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37908 '() '21 '#f '#f))
        __obj37908))
    (define |gerbil-ascent/program/scheme-admit[:0:]#relational-diagnostic|
      (let ((__obj37909
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37909
           'gerbil-ascent/program/scheme-admit#relational-diagnostic::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37909
           'relational-diagnostic
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37909
           '(code path detail)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37909
           '(code path detail)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37909 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37909 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37909 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37909 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37909 '#f '13 '#f '#f))
        (let ((__tmp38154 |gerbil-ascent/program/scheme-admit[1]#_g38155_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37909 __tmp38154 '4 '#f '#f))
        (let ((__tmp38156 |gerbil-ascent/program/scheme-admit[1]#_g38157_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37909 __tmp38156 '14 '#f '#f))
        (let ((__tmp38158 |gerbil-ascent/program/scheme-admit[1]#_g38159_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37909 __tmp38158 '15 '#f '#f))
        (let ((__tmp38160
               (cons (cons 'code
                           |gerbil-ascent/program/scheme-admit[1]#_g38161_|)
                     (cons (cons 'path
                                 |gerbil-ascent/program/scheme-admit[1]#_g38162_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/program/scheme-admit[1]#_g38163_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37909 __tmp38160 '16 '#f '#f))
        (let ((__tmp38164
               (cons (cons 'code
                           |gerbil-ascent/program/scheme-admit[1]#_g38165_|)
                     (cons (cons 'path
                                 |gerbil-ascent/program/scheme-admit[1]#_g38166_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/program/scheme-admit[1]#_g38167_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37909 __tmp38164 '17 '#f '#f))
        (let ((__tmp38168
               (cons (cons 'code
                           |gerbil-ascent/program/scheme-admit[1]#_g38169_|)
                     (cons (cons 'path
                                 |gerbil-ascent/program/scheme-admit[1]#_g38170_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/program/scheme-admit[1]#_g38171_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37909 __tmp38168 '18 '#f '#f))
        (let ((__tmp38172
               (cons (cons 'code
                           |gerbil-ascent/program/scheme-admit[1]#_g38173_|)
                     (cons (cons 'path
                                 |gerbil-ascent/program/scheme-admit[1]#_g38174_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/program/scheme-admit[1]#_g38175_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37909 __tmp38172 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37909 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37909 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37909 '() '21 '#f '#f))
        __obj37909))
    (define |gerbil-ascent/program/scheme-admit[:0:]#relational-admission-report|
      (let ((__obj37910
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37910
           'gerbil-ascent/program/scheme-admit#relational-admission-report::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37910
           'relational-admission-report
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37910
           '(admission diagnostic)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37910
           '(admission diagnostic)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37910 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37910 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37910 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37910 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37910 '#f '13 '#f '#f))
        (let ((__tmp38176 |gerbil-ascent/program/scheme-admit[1]#_g38177_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37910 __tmp38176 '4 '#f '#f))
        (let ((__tmp38178 |gerbil-ascent/program/scheme-admit[1]#_g38179_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37910 __tmp38178 '14 '#f '#f))
        (let ((__tmp38180 |gerbil-ascent/program/scheme-admit[1]#_g38181_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37910 __tmp38180 '15 '#f '#f))
        (let ((__tmp38182
               (cons (cons 'admission
                           |gerbil-ascent/program/scheme-admit[1]#_g38183_|)
                     (cons (cons 'diagnostic
                                 |gerbil-ascent/program/scheme-admit[1]#_g38184_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37910 __tmp38182 '16 '#f '#f))
        (let ((__tmp38185
               (cons (cons 'admission
                           |gerbil-ascent/program/scheme-admit[1]#_g38186_|)
                     (cons (cons 'diagnostic
                                 |gerbil-ascent/program/scheme-admit[1]#_g38187_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37910 __tmp38185 '17 '#f '#f))
        (let ((__tmp38188
               (cons (cons 'admission
                           |gerbil-ascent/program/scheme-admit[1]#_g38189_|)
                     (cons (cons 'diagnostic
                                 |gerbil-ascent/program/scheme-admit[1]#_g38190_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37910 __tmp38188 '18 '#f '#f))
        (let ((__tmp38191
               (cons (cons 'admission
                           |gerbil-ascent/program/scheme-admit[1]#_g38192_|)
                     (cons (cons 'diagnostic
                                 |gerbil-ascent/program/scheme-admit[1]#_g38193_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37910 __tmp38191 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37910 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37910 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37910 '() '21 '#f '#f))
        __obj37910))))
