prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/program

(begin
  (declare-class
   gerbil-ascent/program/view-replay#replay-node::t
   (@class gerbil-ascent/program/view-replay#replay-node::t
           ()
           (object::t t::t)
           (parent members size)
           (parent members size)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/program/view-replay#replay-node::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/view-replay#replay-node::t)
    'class::t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-node?
   (@predicate gerbil-ascent/program/view-replay#replay-node::t))
  (declare-type
   gerbil-ascent/program/view-replay#make-replay-node
   (@constructor gerbil-ascent/program/view-replay#replay-node::t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-node-parent
   (@accessor gerbil-ascent/program/view-replay#replay-node::t parent #t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-node-members
   (@accessor gerbil-ascent/program/view-replay#replay-node::t members #t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-node-size
   (@accessor gerbil-ascent/program/view-replay#replay-node::t size #t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-node-parent-set!
   (@mutator gerbil-ascent/program/view-replay#replay-node::t parent #t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-node-members-set!
   (@mutator gerbil-ascent/program/view-replay#replay-node::t members #t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-node-size-set!
   (@mutator gerbil-ascent/program/view-replay#replay-node::t size #t))
  (declare-type
   gerbil-ascent/program/view-replay#&replay-node-parent
   (@accessor gerbil-ascent/program/view-replay#replay-node::t parent #f))
  (declare-type
   gerbil-ascent/program/view-replay#&replay-node-members
   (@accessor gerbil-ascent/program/view-replay#replay-node::t members #f))
  (declare-type
   gerbil-ascent/program/view-replay#&replay-node-size
   (@accessor gerbil-ascent/program/view-replay#replay-node::t size #f))
  (declare-type
   gerbil-ascent/program/view-replay#&replay-node-parent-set!
   (@mutator gerbil-ascent/program/view-replay#replay-node::t parent #f))
  (declare-type
   gerbil-ascent/program/view-replay#&replay-node-members-set!
   (@mutator gerbil-ascent/program/view-replay#replay-node::t members #f))
  (declare-type
   gerbil-ascent/program/view-replay#&replay-node-size-set!
   (@mutator gerbil-ascent/program/view-replay#replay-node::t size #f))
  (declare-class
   gerbil-ascent/program/view-replay#replay-group::t
   (@class gerbil-ascent/program/view-replay#replay-group::t
           ()
           (object::t t::t)
           (nodes roots values used width bits)
           (nodes roots values used width bits)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/program/view-replay#replay-group::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/view-replay#replay-group::t)
    'class::t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-group?
   (@predicate gerbil-ascent/program/view-replay#replay-group::t))
  (declare-type
   gerbil-ascent/program/view-replay#make-replay-group
   (@constructor gerbil-ascent/program/view-replay#replay-group::t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-group-nodes
   (@accessor gerbil-ascent/program/view-replay#replay-group::t nodes #t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-group-roots
   (@accessor gerbil-ascent/program/view-replay#replay-group::t roots #t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-group-values
   (@accessor gerbil-ascent/program/view-replay#replay-group::t values #t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-group-used
   (@accessor gerbil-ascent/program/view-replay#replay-group::t used #t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-group-width
   (@accessor gerbil-ascent/program/view-replay#replay-group::t width #t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-group-bits
   (@accessor gerbil-ascent/program/view-replay#replay-group::t bits #t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-group-nodes-set!
   (@mutator gerbil-ascent/program/view-replay#replay-group::t nodes #t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-group-roots-set!
   (@mutator gerbil-ascent/program/view-replay#replay-group::t roots #t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-group-values-set!
   (@mutator gerbil-ascent/program/view-replay#replay-group::t values #t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-group-used-set!
   (@mutator gerbil-ascent/program/view-replay#replay-group::t used #t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-group-width-set!
   (@mutator gerbil-ascent/program/view-replay#replay-group::t width #t))
  (declare-type
   gerbil-ascent/program/view-replay#replay-group-bits-set!
   (@mutator gerbil-ascent/program/view-replay#replay-group::t bits #t))
  (declare-type
   gerbil-ascent/program/view-replay#&replay-group-nodes
   (@accessor gerbil-ascent/program/view-replay#replay-group::t nodes #f))
  (declare-type
   gerbil-ascent/program/view-replay#&replay-group-roots
   (@accessor gerbil-ascent/program/view-replay#replay-group::t roots #f))
  (declare-type
   gerbil-ascent/program/view-replay#&replay-group-values
   (@accessor gerbil-ascent/program/view-replay#replay-group::t values #f))
  (declare-type
   gerbil-ascent/program/view-replay#&replay-group-used
   (@accessor gerbil-ascent/program/view-replay#replay-group::t used #f))
  (declare-type
   gerbil-ascent/program/view-replay#&replay-group-width
   (@accessor gerbil-ascent/program/view-replay#replay-group::t width #f))
  (declare-type
   gerbil-ascent/program/view-replay#&replay-group-bits
   (@accessor gerbil-ascent/program/view-replay#replay-group::t bits #f))
  (declare-type
   gerbil-ascent/program/view-replay#&replay-group-nodes-set!
   (@mutator gerbil-ascent/program/view-replay#replay-group::t nodes #f))
  (declare-type
   gerbil-ascent/program/view-replay#&replay-group-roots-set!
   (@mutator gerbil-ascent/program/view-replay#replay-group::t roots #f))
  (declare-type
   gerbil-ascent/program/view-replay#&replay-group-values-set!
   (@mutator gerbil-ascent/program/view-replay#replay-group::t values #f))
  (declare-type
   gerbil-ascent/program/view-replay#&replay-group-used-set!
   (@mutator gerbil-ascent/program/view-replay#replay-group::t used #f))
  (declare-type
   gerbil-ascent/program/view-replay#&replay-group-width-set!
   (@mutator gerbil-ascent/program/view-replay#replay-group::t width #f))
  (declare-type
   gerbil-ascent/program/view-replay#&replay-group-bits-set!
   (@mutator gerbil-ascent/program/view-replay#replay-group::t bits #f))
  (declare-type
   gerbil-ascent/program/view-replay#root
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/view-replay)))
  (declare-type
   gerbil-ascent/program/view-replay#position
   (@lambda 3
            #f
            signature:
            (return:
             fixnum::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/view-replay)))
  (declare-type
   gerbil-ascent/program/view-replay#reaches?
   (@lambda 3
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/view-replay)))
  (declare-type
   gerbil-ascent/program/view-replay#mark!
   (@lambda 3
            #f
            signature:
            (return:
             void::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/view-replay)))
  (declare-type
   gerbil-ascent/program/view-replay#fresh!
   (@lambda 2
            #f
            signature:
            (return:
             gerbil-ascent/program/view-replay#replay-node::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/view-replay)))
  (declare-type
   gerbil-ascent/program/view-replay#group-key
   (@lambda 1
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/view-replay)))
  (declare-type
   gerbil-ascent/program/view-replay#prepare
   (@lambda 2
            #f
            signature:
            (return:
             (nullable HashTable::t)
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/view-replay)))
  (declare-type
   gerbil-ascent/program/view-replay#merge!
   (@lambda 3
            #f
            signature:
            (return:
             void::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/view-replay)))
  (declare-type
   gerbil-ascent/program/view-replay#write-rights!
   (@lambda 5
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/view-replay)))
  (declare-type
   gerbil-ascent/program/view-replay#write-block!
   (@lambda 5
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/view-replay)))
  (declare-type
   gerbil-ascent/program/view-replay#count-targets
   (@lambda 4
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/view-replay)))
  (declare-type
   gerbil-ascent/program/view-replay#count-sources
   (@lambda 4
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/view-replay)))
  (declare-type
   gerbil-ascent/program/view-replay#write-targets!
   (@lambda 5
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/view-replay)))
  (declare-type
   gerbil-ascent/program/view-replay#write-sources!
   (@lambda 5
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/view-replay)))
  (declare-type
   gerbil-ascent/program/view-replay#collect-roots
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/view-replay)))
  (declare-type
   gerbil-ascent/program/view-replay#insert!
   (@lambda 4
            #f
            signature:
            (return:
             void::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/view-replay)))
  (declare-type
   gerbil-ascent/program/view-replay#gerbil-ascent-small-journal-export
   (@lambda 6
            #f
            signature:
            (return:
             (nullable list::t)
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/view-replay))))
