prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/table

(begin
  (declare-type
   gerbil-ascent/table/provider#+procedure+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/provider#+procedure+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/provider#GerbilAscentIndexProviderContract)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/table/provider#IndexProvider.
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/provider#IndexProvider.)
    't::t))
  (declare-type
   gerbil-ascent/table/provider#gerbil-ascent-index-provider-build
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/provider)))
  (declare-type
   gerbil-ascent/table/provider#gerbil-ascent-index-provider-extend!
   (@lambda 4
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/provider)))
  (declare-type
   gerbil-ascent/table/provider#gerbil-ascent-index-provider-lookup
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/provider)))
  (declare-type
   gerbil-ascent/table/provider#+canonical-hash-index-provider+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/provider#+canonical-hash-index-provider+)
    't::t))
  (declare-type
   gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider)
    't::t))
  (declare-type
   gerbil-ascent/table/provider#+curried-index-provider+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/provider#+curried-index-provider+)
    't::t))
  (declare-type
   gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider
   (optimizer-resolve-class
    '(typedecl
      gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider)
    't::t))
  (declare-type
   gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider?
   (@lambda 1
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/provider)))
  (declare-type
   gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
   (@lambda 1
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/provider))))
