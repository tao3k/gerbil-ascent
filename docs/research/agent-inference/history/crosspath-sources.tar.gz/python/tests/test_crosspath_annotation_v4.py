# SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
import unittest
from ascent_test_support.crosspath_annotation_v4 import validate_annotations
class NegativeScopeTests(unittest.TestCase):
    def test_negative_fact_kept_but_not_positive_repeat(self):
        quote='F0 not ready: path 0->1 exists, path 2->3 does not.'
        a={'quote':quote,'occurrence':0,'fragment':0,'paths':[[0,1],[2,3]],'ready':False,'premiseEdges':[[0,1]],'kind':'derive','claim':'F0 false','prior':None,'explanation':'negative fact'}
        b={**a,'occurrence':1,'prior':0}
        accepted,rejected=validate_annotations(quote+'\n'+quote,[a,b],[[0,0,1,2,3]],[[0,1]],[[0,1]],[])
        self.assertFalse(rejected);self.assertTrue(accepted[1]['nativeTruthMatches']);self.assertFalse(accepted[1]['definiteRepeatedDerivation'])
