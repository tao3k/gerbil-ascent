(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/core/relation-view")
    (load-module "clan/poo/object"))
  (load-module "gerbil-ascent/program/result~0"))
