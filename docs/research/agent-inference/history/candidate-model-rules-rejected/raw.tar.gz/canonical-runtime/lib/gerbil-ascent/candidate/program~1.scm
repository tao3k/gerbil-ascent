(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/program[1]#_g36615_|
    (##structure
     gx#syntax-quote::t
     'candidate-declaration::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36617_|
    (##structure
     gx#syntax-quote::t
     'make-candidate-declaration
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36619_|
    (##structure
     gx#syntax-quote::t
     'candidate-declaration?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36621_|
    (##structure
     gx#syntax-quote::t
     'candidate-declaration-arity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36622_|
    (##structure
     gx#syntax-quote::t
     'candidate-declaration-source?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36624_|
    (##structure
     gx#syntax-quote::t
     'candidate-declaration-arity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36625_|
    (##structure
     gx#syntax-quote::t
     'candidate-declaration-source?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36627_|
    (##structure
     gx#syntax-quote::t
     '&candidate-declaration-arity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36628_|
    (##structure
     gx#syntax-quote::t
     '&candidate-declaration-source?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36630_|
    (##structure
     gx#syntax-quote::t
     '&candidate-declaration-arity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36631_|
    (##structure
     gx#syntax-quote::t
     '&candidate-declaration-source?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[:0:]#candidate-declaration|
    (let ((__obj36390
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj36390
         'gerbil-ascent/candidate/program#candidate-declaration::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj36390
         'candidate-declaration
         '3
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36390 '(arity source?) '6 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36390 '(arity source?) '8 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36390 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36390 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36390 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36390 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36390 '#f '13 '#f '#f))
      (let ((__tmp36614 |gerbil-ascent/candidate/program[1]#_g36615_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj36390 __tmp36614 '4 '#f '#f))
      (let ((__tmp36616 |gerbil-ascent/candidate/program[1]#_g36617_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj36390 __tmp36616 '14 '#f '#f))
      (let ((__tmp36618 |gerbil-ascent/candidate/program[1]#_g36619_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj36390 __tmp36618 '15 '#f '#f))
      (let ((__tmp36620
             (cons (cons 'arity |gerbil-ascent/candidate/program[1]#_g36621_|)
                   (cons (cons 'source?
                               |gerbil-ascent/candidate/program[1]#_g36622_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36390 __tmp36620 '16 '#f '#f))
      (let ((__tmp36623
             (cons (cons 'arity |gerbil-ascent/candidate/program[1]#_g36624_|)
                   (cons (cons 'source?
                               |gerbil-ascent/candidate/program[1]#_g36625_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36390 __tmp36623 '17 '#f '#f))
      (let ((__tmp36626
             (cons (cons 'arity |gerbil-ascent/candidate/program[1]#_g36627_|)
                   (cons (cons 'source?
                               |gerbil-ascent/candidate/program[1]#_g36628_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36390 __tmp36626 '18 '#f '#f))
      (let ((__tmp36629
             (cons (cons 'arity |gerbil-ascent/candidate/program[1]#_g36630_|)
                   (cons (cons 'source?
                               |gerbil-ascent/candidate/program[1]#_g36631_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36390 __tmp36629 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36390 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36390 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36390 '() '21 '#f '#f))
      __obj36390)))
