(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/finite-plan::timestamp 1791689704)
  (begin
    (define gerbil-ascent/candidate/finite-plan#finite-rule::t
      (let ((__tmp37197 (list))
            (__tmp37196
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/finite-plan#finite-rule::t
         'finite-rule
         __tmp37197
         '(relation head body level)
         __tmp37196
         '#f)))
    (define gerbil-ascent/candidate/finite-plan#finite-rule?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/finite-plan#finite-rule::t)))
    (define gerbil-ascent/candidate/finite-plan#make-finite-rule
      (lambda _%$args27710%_
        (apply make-instance
               gerbil-ascent/candidate/finite-plan#finite-rule::t
               _%$args27710%_)))
    (define gerbil-ascent/candidate/finite-plan#finite-rule-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'relation)))
    (define gerbil-ascent/candidate/finite-plan#finite-rule-head
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'head)))
    (define gerbil-ascent/candidate/finite-plan#finite-rule-body
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'body)))
    (define gerbil-ascent/candidate/finite-plan#finite-rule-level
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'level)))
    (define gerbil-ascent/candidate/finite-plan#finite-rule-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'relation)))
    (define gerbil-ascent/candidate/finite-plan#finite-rule-head-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'head)))
    (define gerbil-ascent/candidate/finite-plan#finite-rule-body-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'body)))
    (define gerbil-ascent/candidate/finite-plan#finite-rule-level-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'level)))
    (define gerbil-ascent/candidate/finite-plan#&finite-rule-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'relation)))
    (define gerbil-ascent/candidate/finite-plan#&finite-rule-head
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'head)))
    (define gerbil-ascent/candidate/finite-plan#&finite-rule-body
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'body)))
    (define gerbil-ascent/candidate/finite-plan#&finite-rule-level
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'level)))
    (define gerbil-ascent/candidate/finite-plan#&finite-rule-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'relation)))
    (define gerbil-ascent/candidate/finite-plan#&finite-rule-head-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'head)))
    (define gerbil-ascent/candidate/finite-plan#&finite-rule-body-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'body)))
    (define gerbil-ascent/candidate/finite-plan#&finite-rule-level-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'level)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause::t
      (let ((__tmp37199 (list))
            (__tmp37198
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/finite-plan#finite-clause::t
         'finite-clause
         __tmp37199
         '(kind relation apply output operator)
         __tmp37198
         '#f)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/finite-plan#finite-clause::t)))
    (define gerbil-ascent/candidate/finite-plan#make-finite-clause
      (lambda _%$args27707%_
        (apply make-instance
               gerbil-ascent/candidate/finite-plan#finite-clause::t
               _%$args27707%_)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'kind)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'relation)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-apply
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'apply)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-output
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'output)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-operator
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'operator)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'kind)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'relation)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-apply-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'apply)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-output-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'output)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-operator-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'operator)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'kind)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'relation)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-apply
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'apply)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-output
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'output)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-operator
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'operator)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'kind)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'relation)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-apply-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'apply)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-output-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'output)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-operator-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'operator)))
    (define gerbil-ascent/candidate/finite-plan#prepare-finite-rule
      (lambda (_%rule27659%_ _%resolve27660%_ _%levels27661%_)
        (let* ((_%$%rule2766227670%_ _%rule27659%_)
               (_%$%E2766427673%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%rule2766227670%_
                           '(#(head body _))))
                  '#!void))
               (_%$%K2766527691%_
                (lambda (_%body27676%_ _%head27677%_)
                  (let ((__tmp37213 (_%resolve27660%_ (car _%head27677%_)))
                        (__tmp37212
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/grounding-plan#prepare-grounding-head
                            _%head27677%_)))
                        (__tmp37202
                         (map (lambda (_%clause27679%_)
                                (let ((_%$e27681%_ (car _%clause27679%_)))
                                  (if (or (eq? 'where _%$e27681%_)
                                          (eq? 'compute _%$e27681%_))
                                      (let ((__tmp37203
                                             (let ()
                                               (declare (not safe))
                                               (gerbil-ascent/candidate/grounding-plan#prepare-grounding-fixed
                                                _%clause27679%_))))
                                        (declare (not safe))
                                        (##structure
                                         gerbil-ascent/candidate/finite-plan#finite-clause::t
                                         'fixed
                                         '#f
                                         __tmp37203
                                         '#f
                                         '#f))
                                      (if (eq? 'not _%$e27681%_)
                                          (let ((_%atom27687%_
                                                 (cadr _%clause27679%_)))
                                            (let ((__tmp37205
                                                   (_%resolve27660%_
                                                    (car _%atom27687%_)))
                                                  (__tmp37204
                                                   (let ()
                                                     (declare (not safe))
                                                     (gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
                                                      _%atom27687%_))))
                                              (declare (not safe))
                                              (##structure
                                               gerbil-ascent/candidate/finite-plan#finite-clause::t
                                               'not
                                               __tmp37205
                                               __tmp37204
                                               '#f
                                               '#f)))
                                          (if (eq? 'reduce _%$e27681%_)
                                              (let ((_%atom27689%_
                                                     (cadddr _%clause27679%_)))
                                                (let ((__tmp37209
                                                       (_%resolve27660%_
                                                        (car _%atom27689%_)))
                                                      (__tmp37208
                                                       (let ()
                                                         (declare (not safe))
                                                         (gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
                                                          _%atom27689%_)))
                                                      (__tmp37207
                                                       (cadr _%clause27679%_))
                                                      (__tmp37206
                                                       (caddr _%clause27679%_)))
                                                  (declare (not safe))
                                                  (##structure
                                                   gerbil-ascent/candidate/finite-plan#finite-clause::t
                                                   'reduce
                                                   __tmp37209
                                                   __tmp37208
                                                   __tmp37207
                                                   __tmp37206)))
                                              (let ((__tmp37211
                                                     (_%resolve27660%_
                                                      (car _%clause27679%_)))
                                                    (__tmp37210
                                                     (let ()
                                                       (declare (not safe))
                                                       (gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
                                                        _%clause27679%_))))
                                                (declare (not safe))
                                                (##structure
                                                 gerbil-ascent/candidate/finite-plan#finite-clause::t
                                                 'atom
                                                 __tmp37211
                                                 __tmp37210
                                                 '#f
                                                 '#f)))))))
                              _%body27676%_))
                        (__tmp37200
                         (cdr (let ((__tmp37201 (car _%head27677%_)))
                                (declare (not safe))
                                (gerbil-ascent/candidate/funs#candidate-required-entry
                                 __tmp37201
                                 _%levels27661%_)))))
                    (declare (not safe))
                    (##structure
                     gerbil-ascent/candidate/finite-plan#finite-rule::t
                     __tmp37213
                     __tmp37212
                     __tmp37202
                     __tmp37200)))))
          (if (vector? _%$%rule2766227670%_)
              (if (let ((__tmp37214
                         (let ()
                           (declare (not safe))
                           (##vector-length _%$%rule2766227670%_))))
                    (declare (not safe))
                    (##fx= __tmp37214 '3))
                  (let* ((_%$%e2766627694%_
                          (let ()
                            (declare (not safe))
                            (##vector-ref _%$%rule2766227670%_ '0)))
                         (_%head27697%_ _%$%e2766627694%_)
                         (_%$%e2766727699%_
                          (let ()
                            (declare (not safe))
                            (##vector-ref _%$%rule2766227670%_ '1)))
                         (_%body27702%_ _%$%e2766727699%_)
                         (_%$%e2766827704%_
                          (let ()
                            (declare (not safe))
                            (##vector-ref _%$%rule2766227670%_ '2))))
                    (_%$%K2766527691%_ _%body27702%_ _%head27697%_))
                  (_%$%E2766427673%_))
              (_%$%E2766427673%_)))))))
