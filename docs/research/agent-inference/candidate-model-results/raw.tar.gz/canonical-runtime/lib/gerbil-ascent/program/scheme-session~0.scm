(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/scheme-session::timestamp 1791689711)
  (begin
    (define gerbil-ascent/program/scheme-session#relational-session::t
      (let ((__tmp37965 (list)) (__tmp37964 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/scheme-session#relational-session::t
         'relational-session
         __tmp37965
         '(engine source-arities)
         __tmp37964
         '#f)))
    (define gerbil-ascent/program/scheme-session#relational-session?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/scheme-session#relational-session::t)))
    (define gerbil-ascent/program/scheme-session#make-relational-session
      (lambda _%$args20405%_
        (apply make-instance
               gerbil-ascent/program/scheme-session#relational-session::t
               _%$args20405%_)))
    (define gerbil-ascent/program/scheme-session#relational-session-engine
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-session#relational-session::t
         'engine)))
    (define gerbil-ascent/program/scheme-session#relational-session-source-arities
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-session#relational-session::t
         'source-arities)))
    (define gerbil-ascent/program/scheme-session#relational-session-engine-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-session#relational-session::t
         'engine)))
    (define gerbil-ascent/program/scheme-session#relational-session-source-arities-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-session#relational-session::t
         'source-arities)))
    (define gerbil-ascent/program/scheme-session#&relational-session-engine
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-session#relational-session::t
         'engine)))
    (define gerbil-ascent/program/scheme-session#&relational-session-source-arities
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-session#relational-session::t
         'source-arities)))
    (define gerbil-ascent/program/scheme-session#&relational-session-engine-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-session#relational-session::t
         'engine)))
    (define gerbil-ascent/program/scheme-session#&relational-session-source-arities-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-session#relational-session::t
         'source-arities)))
    (define gerbil-ascent/program/scheme-session#relational-program-session::t
      (let ((__tmp37967 (list)) (__tmp37966 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/scheme-session#relational-program-session::t
         'relational-program-session
         __tmp37967
         '(engine source-arities)
         __tmp37966
         '#f)))
    (define gerbil-ascent/program/scheme-session#relational-program-session?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/scheme-session#relational-program-session::t)))
    (define gerbil-ascent/program/scheme-session#make-relational-program-session
      (lambda _%$args20402%_
        (apply make-instance
               gerbil-ascent/program/scheme-session#relational-program-session::t
               _%$args20402%_)))
    (define gerbil-ascent/program/scheme-session#relational-program-session-engine
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-session#relational-program-session::t
         'engine)))
    (define gerbil-ascent/program/scheme-session#relational-program-session-source-arities
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-session#relational-program-session::t
         'source-arities)))
    (define gerbil-ascent/program/scheme-session#relational-program-session-engine-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-session#relational-program-session::t
         'engine)))
    (define gerbil-ascent/program/scheme-session#relational-program-session-source-arities-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-session#relational-program-session::t
         'source-arities)))
    (define gerbil-ascent/program/scheme-session#&relational-program-session-engine
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-session#relational-program-session::t
         'engine)))
    (define gerbil-ascent/program/scheme-session#&relational-program-session-source-arities
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-session#relational-program-session::t
         'source-arities)))
    (define gerbil-ascent/program/scheme-session#&relational-program-session-engine-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-session#relational-program-session::t
         'engine)))
    (define gerbil-ascent/program/scheme-session#&relational-program-session-source-arities-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-session#relational-program-session::t
         'source-arities)))
    (define gerbil-ascent/program/scheme-session#relational-source-arities
      (lambda (_%snapshot20392%_)
        (let ((_%sources20394%_
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%snapshot20392%_ 'source-handles))))
          (map (lambda (_%name20396%_)
                 (let ((_%relation20400%_
                        (let ((__tmp37969
                               (lambda (_%candidate20398%_)
                                 (eq? (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%candidate20398%_
                                         'name))
                                      _%name20396%_)))
                              (__tmp37968
                               (let ()
                                 (declare (not safe))
                                 (clan/poo/object#.ref
                                  _%snapshot20392%_
                                  'relations))))
                          (declare (not safe))
                          (__find __tmp37969 __tmp37968))))
                   (if _%relation20400%_
                       '#!void
                       (let ()
                         (declare (not safe))
                         (error '"relational source has no declaration"
                                _%name20396%_)))
                   (cons _%name20396%_
                         (let ()
                           (declare (not safe))
                           (clan/poo/object#.ref _%relation20400%_ 'arity)))))
               _%sources20394%_))))
    (define gerbil-ascent/program/scheme-session#relational-open-session
      (lambda (_%program20385%_)
        (let* ((_%snapshot20387%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/program/scheme-snapshot#relational-snapshot-program
                   _%program20385%_)))
               (_%arities20389%_
                (gerbil-ascent/program/scheme-session#relational-source-arities
                 _%snapshot20387%_))
               (__tmp37970
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/program/session#gerbil-ascent-open-session__%
                   '#f
                   absent-value
                   _%snapshot20387%_))))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/scheme-session#relational-session::t
           __tmp37970
           _%arities20389%_))))
    (define gerbil-ascent/program/scheme-session#relational-open-program-session
      (lambda (_%program20378%_)
        (let* ((_%snapshot20380%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/program/scheme-snapshot#relational-snapshot-program
                   _%program20378%_)))
               (_%arities20382%_
                (gerbil-ascent/program/scheme-session#relational-source-arities
                 _%snapshot20380%_))
               (__tmp37971
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/program/session#gerbil-ascent-open-session__%
                   '#f
                   absent-value
                   _%snapshot20380%_))))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/scheme-session#relational-program-session::t
           __tmp37971
           _%arities20382%_))))
    (define gerbil-ascent/program/scheme-session#relational-replace-source/checked!
      (lambda (_%engine20369%_ _%arities20370%_ _%name20371%_ _%rows20372%_)
        (let ((_%arity20374%_
               (if (symbol? _%name20371%_)
                   (assq _%name20371%_ _%arities20370%_)
                   '#f)))
          (if _%arity20374%_
              '#!void
              (let ()
                (declare (not safe))
                (error '"relation is not a source in this session"
                       _%name20371%_)))
          (let ((_%copied20376%_
                 (let ((__tmp37972 (cdr _%arity20374%_)))
                   (declare (not safe))
                   (gerbil-ascent/program/scheme-checked#relational-copy-rows
                    _%rows20372%_
                    __tmp37972))))
            (let ()
              (declare (not safe))
              (gerbil-ascent/program/session#gerbil-ascent-session-replace-source!
               _%engine20369%_
               _%name20371%_
               _%copied20376%_))
            '#!void))))
    (define gerbil-ascent/program/scheme-session#relational-append-source/checked!
      (lambda (_%engine20360%_ _%arities20361%_ _%name20362%_ _%row20363%_)
        (let ((_%arity20365%_
               (if (symbol? _%name20362%_)
                   (assq _%name20362%_ _%arities20361%_)
                   '#f)))
          (if _%arity20365%_
              '#!void
              (let ()
                (declare (not safe))
                (error '"relation is not a source in this session"
                       _%name20362%_)))
          (let ((_%copied20367%_
                 (let ((__tmp37973 (cdr _%arity20365%_)))
                   (declare (not safe))
                   (gerbil-ascent/program/scheme-checked#relational-copy-row
                    _%row20363%_
                    __tmp37973))))
            (let ()
              (declare (not safe))
              (gerbil-ascent/program/session#gerbil-ascent-session-append-source!
               _%engine20360%_
               _%name20362%_
               _%copied20367%_))
            '#!void))))
    (define gerbil-ascent/program/scheme-session#relational-session-append-source!
      (lambda (_%session20350%_ _%fragment20351%_ _%label20352%_ _%row20353%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20350%_
               'gerbil-ascent/program/scheme-session#relational-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational source append requires a session"
                     _%session20350%_)))
        (let ()
          (declare (not safe))
          (clan/poo/mop#validate
           gerbil-ascent/program/types#GerbilAscentFragmentContract
           _%fragment20351%_))
        (let* ((_%name20355%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/program/scheme-query#relational-export
                   _%fragment20351%_
                   _%label20352%_)))
               (_%arity20357%_
                (assq _%name20355%_
                      (##structure-ref
                       _%session20350%_
                       '2
                       gerbil-ascent/program/scheme-session#relational-session::t
                       '#f))))
          (if (and (memq _%name20355%_
                         (let ()
                           (declare (not safe))
                           (clan/poo/object#.ref
                            _%fragment20351%_
                            'source-handles)))
                   _%arity20357%_)
              '#!void
              (let ()
                (declare (not safe))
                (error '"relational export is not a source in this session"
                       _%label20352%_)))
          (gerbil-ascent/program/scheme-session#relational-append-source/checked!
           (##structure-ref
            _%session20350%_
            '1
            gerbil-ascent/program/scheme-session#relational-session::t
            '#f)
           (##structure-ref
            _%session20350%_
            '2
            gerbil-ascent/program/scheme-session#relational-session::t
            '#f)
           _%name20355%_
           _%row20353%_))))
    (define gerbil-ascent/program/scheme-session#relational-session-replace-source!
      (lambda (_%session20340%_ _%fragment20341%_ _%label20342%_ _%rows20343%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20340%_
               'gerbil-ascent/program/scheme-session#relational-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational source replacement requires a session"
                     _%session20340%_)))
        (let ()
          (declare (not safe))
          (clan/poo/mop#validate
           gerbil-ascent/program/types#GerbilAscentFragmentContract
           _%fragment20341%_))
        (let* ((_%name20345%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/program/scheme-query#relational-export
                   _%fragment20341%_
                   _%label20342%_)))
               (_%arity20347%_
                (assq _%name20345%_
                      (##structure-ref
                       _%session20340%_
                       '2
                       gerbil-ascent/program/scheme-session#relational-session::t
                       '#f))))
          (if (and (memq _%name20345%_
                         (let ()
                           (declare (not safe))
                           (clan/poo/object#.ref
                            _%fragment20341%_
                            'source-handles)))
                   _%arity20347%_)
              '#!void
              (let ()
                (declare (not safe))
                (error '"relational export is not a source in this session"
                       _%label20342%_)))
          (gerbil-ascent/program/scheme-session#relational-replace-source/checked!
           (##structure-ref
            _%session20340%_
            '1
            gerbil-ascent/program/scheme-session#relational-session::t
            '#f)
           (##structure-ref
            _%session20340%_
            '2
            gerbil-ascent/program/scheme-session#relational-session::t
            '#f)
           _%name20345%_
           _%rows20343%_))))
    (define gerbil-ascent/program/scheme-session#relational-checked-replacements
      (lambda (_%arities20326%_ _%entries20327%_)
        (if (and (list? _%entries20327%_) (pair? _%entries20327%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational transaction requires source updates"
                     _%entries20327%_)))
        (let ((_%seen20329%_
               (let () (declare (not safe)) (make-hash-table-eq))))
          (map (lambda (_%entry20331%_)
                 (if (and (pair? _%entry20331%_)
                          (symbol? (let ()
                                     (declare (not safe))
                                     (##car _%entry20331%_))))
                     '#!void
                     (let ()
                       (declare (not safe))
                       (error '"invalid relational source update"
                              _%entry20331%_)))
                 (let* ((_%name20333%_ (car _%entry20331%_))
                        (_%arity20335%_ (assq _%name20333%_ _%arities20326%_)))
                   (if _%arity20335%_
                       '#!void
                       (let ()
                         (declare (not safe))
                         (error '"relation is not a source in this session"
                                _%name20333%_)))
                   (if (let ()
                         (declare (not safe))
                         (__hash-get _%seen20329%_ _%name20333%_))
                       (let ()
                         (declare (not safe))
                         (error '"duplicate relational transaction source"
                                _%name20333%_))
                       '#!void)
                   (let ()
                     (declare (not safe))
                     (__hash-put! _%seen20329%_ _%name20333%_ '#t))
                   (let ((_%rows20338%_
                          (let ((__tmp37975 (cdr _%entry20331%_))
                                (__tmp37974 (cdr _%arity20335%_)))
                            (declare (not safe))
                            (gerbil-ascent/program/scheme-checked#relational-copy-rows
                             __tmp37975
                             __tmp37974))))
                     (cons _%name20333%_ _%rows20338%_))))
               _%entries20327%_))))
    (define gerbil-ascent/program/scheme-session#relational-session-source-name
      (lambda (_%session20320%_ _%fragment20321%_ _%label20322%_)
        (let ((_%name20324%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/program/scheme-query#relational-export
                  _%fragment20321%_
                  _%label20322%_))))
          (if (and (memq _%name20324%_
                         (let ()
                           (declare (not safe))
                           (clan/poo/object#.ref
                            _%fragment20321%_
                            'source-handles)))
                   (assq _%name20324%_
                         (##structure-ref
                          _%session20320%_
                          '2
                          gerbil-ascent/program/scheme-session#relational-session::t
                          '#f)))
              '#!void
              (let ()
                (declare (not safe))
                (error '"relational export is not a source in this session"
                       _%label20322%_)))
          _%name20324%_)))
    (define gerbil-ascent/program/scheme-session#relational-session-transaction!
      (lambda (_%session20313%_ _%updates20314%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20313%_
               'gerbil-ascent/program/scheme-session#relational-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational transaction requires a session"
                     _%session20313%_)))
        (if (and (list? _%updates20314%_) (pair? _%updates20314%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational transaction requires source updates"
                     _%updates20314%_)))
        (let ((_%entries20318%_
               (map (lambda (_%update20316%_)
                      (if (and (list? _%update20316%_)
                               (= (let ()
                                    (declare (not safe))
                                    (##length _%update20316%_))
                                  '3)
                               (symbol? (cadr _%update20316%_)))
                          '#!void
                          (let ()
                            (declare (not safe))
                            (error '"invalid relational transaction update"
                                   _%update20316%_)))
                      (cons (gerbil-ascent/program/scheme-session#relational-session-source-name
                             _%session20313%_
                             (car _%update20316%_)
                             (cadr _%update20316%_))
                            (caddr _%update20316%_)))
                    _%updates20314%_)))
          (gerbil-ascent/program/scheme-session#relational-session-commit-entries!
           _%session20313%_
           _%entries20318%_))))
    (define gerbil-ascent/program/scheme-session#relational-session-commit-entries!
      (lambda (_%session20310%_ _%entries20311%_)
        (let ((__tmp37976
               (let ((__tmp37978
                      (##structure-ref
                       _%session20310%_
                       '1
                       gerbil-ascent/program/scheme-session#relational-session::t
                       '#f))
                     (__tmp37977
                      (gerbil-ascent/program/scheme-session#relational-checked-replacements
                       (##structure-ref
                        _%session20310%_
                        '2
                        gerbil-ascent/program/scheme-session#relational-session::t
                        '#f)
                       _%entries20311%_)))
                 (declare (not safe))
                 (gerbil-ascent/program/session#gerbil-ascent-session-replace-sources!__0
                  __tmp37978
                  __tmp37977))))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/scheme-query#relational-solution::t
           __tmp37976))))
    (define gerbil-ascent/program/scheme-session#relational-session-prepare-transaction
      (lambda (_%session20294%_ _%sources20295%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20294%_
               'gerbil-ascent/program/scheme-session#relational-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational transaction requires a session"
                     _%session20294%_)))
        (if (and (list? _%sources20295%_) (pair? _%sources20295%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"prepared transaction requires source selections"
                     _%sources20295%_)))
        (let* ((_%seen20297%_
                (let () (declare (not safe)) (make-hash-table-eq)))
               (_%names20303%_
                (map (lambda (_%source20299%_)
                       (if (and (list? _%source20299%_)
                                (= (let ()
                                     (declare (not safe))
                                     (##length _%source20299%_))
                                   '2)
                                (symbol? (cadr _%source20299%_)))
                           '#!void
                           (let ()
                             (declare (not safe))
                             (error '"invalid prepared transaction source"
                                    _%source20299%_)))
                       (let ((_%name20301%_
                              (gerbil-ascent/program/scheme-session#relational-session-source-name
                               _%session20294%_
                               (car _%source20299%_)
                               (cadr _%source20299%_))))
                         (if (let ()
                               (declare (not safe))
                               (__hash-get _%seen20297%_ _%name20301%_))
                             (let ()
                               (declare (not safe))
                               (error '"duplicate relational transaction source"
                                      _%name20301%_))
                             '#!void)
                         (let ()
                           (declare (not safe))
                           (__hash-put! _%seen20297%_ _%name20301%_ '#t))
                         _%name20301%_))
                     _%sources20295%_))
               (_%count20305%_
                (let () (declare (not safe)) (##length _%names20303%_))))
          (lambda (_%batches20308%_)
            (if (and (list? _%batches20308%_)
                     (= (let ()
                          (declare (not safe))
                          (##length _%batches20308%_))
                        _%count20305%_))
                '#!void
                (let ()
                  (declare (not safe))
                  (error '"prepared transaction requires one row batch per source"
                         _%batches20308%_)))
            (gerbil-ascent/program/scheme-session#relational-session-commit-entries!
             _%session20294%_
             (let ()
               (declare (not safe))
               (##map cons _%names20303%_ _%batches20308%_)))))))
    (define gerbil-ascent/program/scheme-session#relational-session-prepare-replacements
      (lambda (_%session20274%_ _%fragment20275%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20274%_
               'gerbil-ascent/program/scheme-session#relational-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational transaction requires a session"
                     _%session20274%_)))
        (let ()
          (declare (not safe))
          (clan/poo/mop#validate
           gerbil-ascent/program/types#GerbilAscentFragmentContract
           _%fragment20275%_))
        (let ((_%last-preparation20277%_ '#f))
          (lambda (_%replacements20279%_)
            (if (and (list? _%replacements20279%_)
                     (pair? _%replacements20279%_))
                '#!void
                (let ()
                  (declare (not safe))
                  (error '"relational transaction requires source updates"
                         _%replacements20279%_)))
            (let* ((_%labels20283%_
                    (map (lambda (_%replacement20281%_)
                           (if (and (pair? _%replacement20281%_)
                                    (symbol? (let ()
                                               (declare (not safe))
                                               (##car _%replacement20281%_))))
                               '#!void
                               (let ()
                                 (declare (not safe))
                                 (error '"invalid relational source replacement"
                                        _%replacement20281%_)))
                           (car _%replacement20281%_))
                         _%replacements20279%_))
                   (_%previous20285%_ _%last-preparation20277%_)
                   (_%transaction20291%_
                    (if (and _%previous20285%_
                             (equal? _%labels20283%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%previous20285%_))))
                        (cdr _%previous20285%_)
                        (let ((_%prepared20289%_
                               (gerbil-ascent/program/scheme-session#relational-session-prepare-transaction
                                _%session20274%_
                                (let ((__tmp37979
                                       (lambda (_%label20287%_)
                                         (list _%fragment20275%_
                                               _%label20287%_))))
                                  (declare (not safe))
                                  (##map __tmp37979 _%labels20283%_)))))
                          (set! _%last-preparation20277%_
                                (cons _%labels20283%_ _%prepared20289%_))
                          _%prepared20289%_))))
              (_%transaction20291%_ (map cdr _%replacements20279%_)))))))
    (define gerbil-ascent/program/scheme-session#relational-session-replace-sources!
      (lambda (_%session20268%_ _%fragment20269%_ _%replacements20270%_)
        (if (list? _%replacements20270%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational batch replacements must be a list"
                     _%replacements20270%_)))
        (gerbil-ascent/program/scheme-session#relational-session-transaction!
         _%session20268%_
         (map (lambda (_%replacement20272%_)
                (if (and (pair? _%replacement20272%_)
                         (symbol? (let ()
                                    (declare (not safe))
                                    (##car _%replacement20272%_))))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"invalid relational source replacement"
                             _%replacement20272%_)))
                (list _%fragment20269%_
                      (car _%replacement20272%_)
                      (cdr _%replacement20272%_)))
              _%replacements20270%_))))
    (define gerbil-ascent/program/scheme-session#relational-program-replace-source!
      (lambda (_%session20264%_ _%name20265%_ _%rows20266%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20264%_
               'gerbil-ascent/program/scheme-session#relational-program-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"named source replacement requires a program session"
                     _%session20264%_)))
        (gerbil-ascent/program/scheme-session#relational-replace-source/checked!
         (##structure-ref
          _%session20264%_
          '1
          gerbil-ascent/program/scheme-session#relational-program-session::t
          '#f)
         (##structure-ref
          _%session20264%_
          '2
          gerbil-ascent/program/scheme-session#relational-program-session::t
          '#f)
         _%name20265%_
         _%rows20266%_)))
    (define gerbil-ascent/program/scheme-session#relational-program-append-source!
      (lambda (_%session20260%_ _%name20261%_ _%row20262%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20260%_
               'gerbil-ascent/program/scheme-session#relational-program-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"named source append requires a program session"
                     _%session20260%_)))
        (gerbil-ascent/program/scheme-session#relational-append-source/checked!
         (##structure-ref
          _%session20260%_
          '1
          gerbil-ascent/program/scheme-session#relational-program-session::t
          '#f)
         (##structure-ref
          _%session20260%_
          '2
          gerbil-ascent/program/scheme-session#relational-program-session::t
          '#f)
         _%name20261%_
         _%row20262%_)))
    (define gerbil-ascent/program/scheme-session#relational-program-transaction!
      (lambda (_%session20257%_ _%replacements20258%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20257%_
               'gerbil-ascent/program/scheme-session#relational-program-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"named transaction requires a program session"
                     _%session20257%_)))
        (let ((__tmp37980
               (let ((__tmp37982
                      (##structure-ref
                       _%session20257%_
                       '1
                       gerbil-ascent/program/scheme-session#relational-program-session::t
                       '#f))
                     (__tmp37981
                      (gerbil-ascent/program/scheme-session#relational-checked-replacements
                       (##structure-ref
                        _%session20257%_
                        '2
                        gerbil-ascent/program/scheme-session#relational-program-session::t
                        '#f)
                       _%replacements20258%_)))
                 (declare (not safe))
                 (gerbil-ascent/program/session#gerbil-ascent-session-replace-sources!__0
                  __tmp37982
                  __tmp37981))))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/scheme-query#relational-program-solution::t
           __tmp37980))))
    (define gerbil-ascent/program/scheme-session#relational-session-result
      (lambda (_%engine20253%_)
        (let ((_%result20255%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/program/session#gerbil-ascent-session-run
                  _%engine20253%_))))
          (if (let ()
                (declare (not safe))
                (clan/poo/object#.ref _%result20255%_ 'finished))
              '#!void
              (let ()
                (declare (not safe))
                (error '"relational session did not complete")))
          _%result20255%_)))
    (define gerbil-ascent/program/scheme-session#relational-session-run
      (lambda (_%session20251%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20251%_
               'gerbil-ascent/program/scheme-session#relational-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational run requires a session" _%session20251%_)))
        (let ((__tmp37983
               (gerbil-ascent/program/scheme-session#relational-session-result
                (##structure-ref
                 _%session20251%_
                 '1
                 gerbil-ascent/program/scheme-session#relational-session::t
                 '#f))))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/scheme-query#relational-solution::t
           __tmp37983))))
    (define gerbil-ascent/program/scheme-session#relational-program-session-run
      (lambda (_%session20249%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20249%_
               'gerbil-ascent/program/scheme-session#relational-program-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"named run requires a program session"
                     _%session20249%_)))
        (let ((__tmp37984
               (gerbil-ascent/program/scheme-session#relational-session-result
                (##structure-ref
                 _%session20249%_
                 '1
                 gerbil-ascent/program/scheme-session#relational-program-session::t
                 '#f))))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/scheme-query#relational-program-solution::t
           __tmp37984))))))
