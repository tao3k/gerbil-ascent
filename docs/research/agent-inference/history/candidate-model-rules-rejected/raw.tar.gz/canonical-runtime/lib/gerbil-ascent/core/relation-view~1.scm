(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/core/relation-view[1]#_g33342_|
    (##structure
     gx#syntax-quote::t
     'relation-view::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33344_|
    (##structure
     gx#syntax-quote::t
     'make-relation-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33346_|
    (##structure
     gx#syntax-quote::t
     'relation-view?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33348_|
    (##structure
     gx#syntax-quote::t
     'relation-view-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33349_|
    (##structure
     gx#syntax-quote::t
     'relation-view-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33350_|
    (##structure
     gx#syntax-quote::t
     'relation-view-revision
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33351_|
    (##structure
     gx#syntax-quote::t
     'relation-view-lane
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33352_|
    (##structure
     gx#syntax-quote::t
     'relation-view-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33353_|
    (##structure
     gx#syntax-quote::t
     'relation-view-units
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33354_|
    (##structure
     gx#syntax-quote::t
     'relation-view-visit
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33355_|
    (##structure
     gx#syntax-quote::t
     'relation-view-contains
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33356_|
    (##structure
     gx#syntax-quote::t
     'relation-view-export
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33357_|
    (##structure
     gx#syntax-quote::t
     'relation-view-parts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33359_|
    (##structure
     gx#syntax-quote::t
     'relation-view-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33360_|
    (##structure
     gx#syntax-quote::t
     'relation-view-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33361_|
    (##structure
     gx#syntax-quote::t
     'relation-view-revision-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33362_|
    (##structure
     gx#syntax-quote::t
     'relation-view-lane-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33363_|
    (##structure
     gx#syntax-quote::t
     'relation-view-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33364_|
    (##structure
     gx#syntax-quote::t
     'relation-view-units-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33365_|
    (##structure
     gx#syntax-quote::t
     'relation-view-visit-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33366_|
    (##structure
     gx#syntax-quote::t
     'relation-view-contains-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33367_|
    (##structure
     gx#syntax-quote::t
     'relation-view-export-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33368_|
    (##structure
     gx#syntax-quote::t
     'relation-view-parts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33370_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33371_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33372_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-revision
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33373_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-lane
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33374_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33375_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-units
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33376_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-visit
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33377_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-contains
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33378_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-export
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33379_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-parts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33381_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33382_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33383_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-revision-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33384_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-lane-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33385_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33386_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-units-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33387_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-visit-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33388_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-contains-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33389_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-export-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33390_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-parts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33392_|
    (##structure
     gx#syntax-quote::t
     'part-visitors::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33394_|
    (##structure
     gx#syntax-quote::t
     'make-part-visitors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33396_|
    (##structure
     gx#syntax-quote::t
     'part-visitors?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33398_|
    (##structure
     gx#syntax-quote::t
     'part-visitors-checked
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33399_|
    (##structure
     gx#syntax-quote::t
     'part-visitors-admitted
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33401_|
    (##structure
     gx#syntax-quote::t
     'part-visitors-checked-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33402_|
    (##structure
     gx#syntax-quote::t
     'part-visitors-admitted-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33404_|
    (##structure
     gx#syntax-quote::t
     '&part-visitors-checked
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33405_|
    (##structure
     gx#syntax-quote::t
     '&part-visitors-admitted
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33407_|
    (##structure
     gx#syntax-quote::t
     '&part-visitors-checked-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33408_|
    (##structure
     gx#syntax-quote::t
     '&part-visitors-admitted-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33410_|
    (##structure
     gx#syntax-quote::t
     'row-stream::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33412_|
    (##structure
     gx#syntax-quote::t
     'make-row-stream
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33414_|
    (##structure
     gx#syntax-quote::t
     'row-stream?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33416_|
    (##structure
     gx#syntax-quote::t
     'row-stream-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33417_|
    (##structure
     gx#syntax-quote::t
     'row-stream-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33418_|
    (##structure
     gx#syntax-quote::t
     'row-stream-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33420_|
    (##structure
     gx#syntax-quote::t
     'row-stream-view-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33421_|
    (##structure
     gx#syntax-quote::t
     'row-stream-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33422_|
    (##structure
     gx#syntax-quote::t
     'row-stream-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33424_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33425_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33426_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33428_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-view-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33429_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33430_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33432_|
    (##structure
     gx#syntax-quote::t
     'rectangle::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33434_|
    (##structure
     gx#syntax-quote::t
     'make-rectangle
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33436_|
    (##structure
     gx#syntax-quote::t
     'rectangle?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33438_|
    (##structure
     gx#syntax-quote::t
     'rectangle-prefix
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33439_|
    (##structure
     gx#syntax-quote::t
     'rectangle-left
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33440_|
    (##structure
     gx#syntax-quote::t
     'rectangle-right
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33442_|
    (##structure
     gx#syntax-quote::t
     'rectangle-prefix-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33443_|
    (##structure
     gx#syntax-quote::t
     'rectangle-left-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33444_|
    (##structure
     gx#syntax-quote::t
     'rectangle-right-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33446_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-prefix
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33447_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-left
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33448_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-right
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33450_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-prefix-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33451_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-left-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33452_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-right-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33454_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33456_|
    (##structure
     gx#syntax-quote::t
     'make-rectangle-bucket
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33458_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33460_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33461_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-blocks
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33462_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33463_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-plain
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33465_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33466_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-blocks-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33467_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33468_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-plain-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33470_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33471_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-blocks
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33472_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33473_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-plain
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33475_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33476_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-blocks-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33477_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33478_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-plain-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/core/relation-view[:0:]#relation-view|
      (let ((__obj33090
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33090
           'gerbil-ascent/core/relation-view#relation-view::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33090 'relation-view '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33090
           '(identity
             generation
             revision
             lane
             count
             units
             visit
             contains
             export
             parts)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33090
           '(identity
             generation
             revision
             lane
             count
             units
             visit
             contains
             export
             parts)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33090 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33090 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33090 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33090 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33090 '#f '13 '#f '#f))
        (let ((__tmp33341 |gerbil-ascent/core/relation-view[1]#_g33342_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33090 __tmp33341 '4 '#f '#f))
        (let ((__tmp33343 |gerbil-ascent/core/relation-view[1]#_g33344_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33090 __tmp33343 '14 '#f '#f))
        (let ((__tmp33345 |gerbil-ascent/core/relation-view[1]#_g33346_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33090 __tmp33345 '15 '#f '#f))
        (let ((__tmp33347
               (cons (cons 'identity
                           |gerbil-ascent/core/relation-view[1]#_g33348_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/core/relation-view[1]#_g33349_|)
                           (cons (cons 'revision
                                       |gerbil-ascent/core/relation-view[1]#_g33350_|)
                                 (cons (cons 'lane
                                             |gerbil-ascent/core/relation-view[1]#_g33351_|)
                                       (cons (cons 'count
                                                   |gerbil-ascent/core/relation-view[1]#_g33352_|)
                                             (cons (cons 'units
                                                         |gerbil-ascent/core/relation-view[1]#_g33353_|)
                                                   (cons (cons 'visit
                                                               |gerbil-ascent/core/relation-view[1]#_g33354_|)
                                                         (cons (cons 'contains
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/core/relation-view[1]#_g33355_|)
                       (cons (cons 'export
                                   |gerbil-ascent/core/relation-view[1]#_g33356_|)
                             (cons (cons 'parts
                                         |gerbil-ascent/core/relation-view[1]#_g33357_|)
                                   '()))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33090 __tmp33347 '16 '#f '#f))
        (let ((__tmp33358
               (cons (cons 'identity
                           |gerbil-ascent/core/relation-view[1]#_g33359_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/core/relation-view[1]#_g33360_|)
                           (cons (cons 'revision
                                       |gerbil-ascent/core/relation-view[1]#_g33361_|)
                                 (cons (cons 'lane
                                             |gerbil-ascent/core/relation-view[1]#_g33362_|)
                                       (cons (cons 'count
                                                   |gerbil-ascent/core/relation-view[1]#_g33363_|)
                                             (cons (cons 'units
                                                         |gerbil-ascent/core/relation-view[1]#_g33364_|)
                                                   (cons (cons 'visit
                                                               |gerbil-ascent/core/relation-view[1]#_g33365_|)
                                                         (cons (cons 'contains
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/core/relation-view[1]#_g33366_|)
                       (cons (cons 'export
                                   |gerbil-ascent/core/relation-view[1]#_g33367_|)
                             (cons (cons 'parts
                                         |gerbil-ascent/core/relation-view[1]#_g33368_|)
                                   '()))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33090 __tmp33358 '17 '#f '#f))
        (let ((__tmp33369
               (cons (cons 'identity
                           |gerbil-ascent/core/relation-view[1]#_g33370_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/core/relation-view[1]#_g33371_|)
                           (cons (cons 'revision
                                       |gerbil-ascent/core/relation-view[1]#_g33372_|)
                                 (cons (cons 'lane
                                             |gerbil-ascent/core/relation-view[1]#_g33373_|)
                                       (cons (cons 'count
                                                   |gerbil-ascent/core/relation-view[1]#_g33374_|)
                                             (cons (cons 'units
                                                         |gerbil-ascent/core/relation-view[1]#_g33375_|)
                                                   (cons (cons 'visit
                                                               |gerbil-ascent/core/relation-view[1]#_g33376_|)
                                                         (cons (cons 'contains
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/core/relation-view[1]#_g33377_|)
                       (cons (cons 'export
                                   |gerbil-ascent/core/relation-view[1]#_g33378_|)
                             (cons (cons 'parts
                                         |gerbil-ascent/core/relation-view[1]#_g33379_|)
                                   '()))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33090 __tmp33369 '18 '#f '#f))
        (let ((__tmp33380
               (cons (cons 'identity
                           |gerbil-ascent/core/relation-view[1]#_g33381_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/core/relation-view[1]#_g33382_|)
                           (cons (cons 'revision
                                       |gerbil-ascent/core/relation-view[1]#_g33383_|)
                                 (cons (cons 'lane
                                             |gerbil-ascent/core/relation-view[1]#_g33384_|)
                                       (cons (cons 'count
                                                   |gerbil-ascent/core/relation-view[1]#_g33385_|)
                                             (cons (cons 'units
                                                         |gerbil-ascent/core/relation-view[1]#_g33386_|)
                                                   (cons (cons 'visit
                                                               |gerbil-ascent/core/relation-view[1]#_g33387_|)
                                                         (cons (cons 'contains
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/core/relation-view[1]#_g33388_|)
                       (cons (cons 'export
                                   |gerbil-ascent/core/relation-view[1]#_g33389_|)
                             (cons (cons 'parts
                                         |gerbil-ascent/core/relation-view[1]#_g33390_|)
                                   '()))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33090 __tmp33380 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33090 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33090 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33090 '() '21 '#f '#f))
        __obj33090))
    (define |gerbil-ascent/core/relation-view[:0:]#part-visitors|
      (let ((__obj33091
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33091
           'gerbil-ascent/core/relation-view#part-visitors::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33091 'part-visitors '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33091
           '(checked admitted)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33091
           '(checked admitted)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33091 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33091 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33091 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33091 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33091 '#f '13 '#f '#f))
        (let ((__tmp33391 |gerbil-ascent/core/relation-view[1]#_g33392_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33091 __tmp33391 '4 '#f '#f))
        (let ((__tmp33393 |gerbil-ascent/core/relation-view[1]#_g33394_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33091 __tmp33393 '14 '#f '#f))
        (let ((__tmp33395 |gerbil-ascent/core/relation-view[1]#_g33396_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33091 __tmp33395 '15 '#f '#f))
        (let ((__tmp33397
               (cons (cons 'checked
                           |gerbil-ascent/core/relation-view[1]#_g33398_|)
                     (cons (cons 'admitted
                                 |gerbil-ascent/core/relation-view[1]#_g33399_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33091 __tmp33397 '16 '#f '#f))
        (let ((__tmp33400
               (cons (cons 'checked
                           |gerbil-ascent/core/relation-view[1]#_g33401_|)
                     (cons (cons 'admitted
                                 |gerbil-ascent/core/relation-view[1]#_g33402_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33091 __tmp33400 '17 '#f '#f))
        (let ((__tmp33403
               (cons (cons 'checked
                           |gerbil-ascent/core/relation-view[1]#_g33404_|)
                     (cons (cons 'admitted
                                 |gerbil-ascent/core/relation-view[1]#_g33405_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33091 __tmp33403 '18 '#f '#f))
        (let ((__tmp33406
               (cons (cons 'checked
                           |gerbil-ascent/core/relation-view[1]#_g33407_|)
                     (cons (cons 'admitted
                                 |gerbil-ascent/core/relation-view[1]#_g33408_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33091 __tmp33406 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33091 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33091 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33091 '() '21 '#f '#f))
        __obj33091))
    (define |gerbil-ascent/core/relation-view[:0:]#row-stream|
      (let ((__obj33092
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33092
           'gerbil-ascent/core/relation-view#row-stream::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33092 'row-stream '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33092
           '(view columns key)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33092
           '(view columns key)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33092 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33092 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33092 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33092 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33092 '#f '13 '#f '#f))
        (let ((__tmp33409 |gerbil-ascent/core/relation-view[1]#_g33410_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33092 __tmp33409 '4 '#f '#f))
        (let ((__tmp33411 |gerbil-ascent/core/relation-view[1]#_g33412_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33092 __tmp33411 '14 '#f '#f))
        (let ((__tmp33413 |gerbil-ascent/core/relation-view[1]#_g33414_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33092 __tmp33413 '15 '#f '#f))
        (let ((__tmp33415
               (cons (cons 'view
                           |gerbil-ascent/core/relation-view[1]#_g33416_|)
                     (cons (cons 'columns
                                 |gerbil-ascent/core/relation-view[1]#_g33417_|)
                           (cons (cons 'key
                                       |gerbil-ascent/core/relation-view[1]#_g33418_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33092 __tmp33415 '16 '#f '#f))
        (let ((__tmp33419
               (cons (cons 'view
                           |gerbil-ascent/core/relation-view[1]#_g33420_|)
                     (cons (cons 'columns
                                 |gerbil-ascent/core/relation-view[1]#_g33421_|)
                           (cons (cons 'key
                                       |gerbil-ascent/core/relation-view[1]#_g33422_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33092 __tmp33419 '17 '#f '#f))
        (let ((__tmp33423
               (cons (cons 'view
                           |gerbil-ascent/core/relation-view[1]#_g33424_|)
                     (cons (cons 'columns
                                 |gerbil-ascent/core/relation-view[1]#_g33425_|)
                           (cons (cons 'key
                                       |gerbil-ascent/core/relation-view[1]#_g33426_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33092 __tmp33423 '18 '#f '#f))
        (let ((__tmp33427
               (cons (cons 'view
                           |gerbil-ascent/core/relation-view[1]#_g33428_|)
                     (cons (cons 'columns
                                 |gerbil-ascent/core/relation-view[1]#_g33429_|)
                           (cons (cons 'key
                                       |gerbil-ascent/core/relation-view[1]#_g33430_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33092 __tmp33427 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33092 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33092 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33092 '() '21 '#f '#f))
        __obj33092))
    (define |gerbil-ascent/core/relation-view[:0:]#rectangle|
      (let ((__obj33093
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33093
           'gerbil-ascent/core/relation-view#rectangle::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33093 'rectangle '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33093
           '(prefix left right)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33093
           '(prefix left right)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33093 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33093 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33093 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33093 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33093 '#f '13 '#f '#f))
        (let ((__tmp33431 |gerbil-ascent/core/relation-view[1]#_g33432_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33093 __tmp33431 '4 '#f '#f))
        (let ((__tmp33433 |gerbil-ascent/core/relation-view[1]#_g33434_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33093 __tmp33433 '14 '#f '#f))
        (let ((__tmp33435 |gerbil-ascent/core/relation-view[1]#_g33436_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33093 __tmp33435 '15 '#f '#f))
        (let ((__tmp33437
               (cons (cons 'prefix
                           |gerbil-ascent/core/relation-view[1]#_g33438_|)
                     (cons (cons 'left
                                 |gerbil-ascent/core/relation-view[1]#_g33439_|)
                           (cons (cons 'right
                                       |gerbil-ascent/core/relation-view[1]#_g33440_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33093 __tmp33437 '16 '#f '#f))
        (let ((__tmp33441
               (cons (cons 'prefix
                           |gerbil-ascent/core/relation-view[1]#_g33442_|)
                     (cons (cons 'left
                                 |gerbil-ascent/core/relation-view[1]#_g33443_|)
                           (cons (cons 'right
                                       |gerbil-ascent/core/relation-view[1]#_g33444_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33093 __tmp33441 '17 '#f '#f))
        (let ((__tmp33445
               (cons (cons 'prefix
                           |gerbil-ascent/core/relation-view[1]#_g33446_|)
                     (cons (cons 'left
                                 |gerbil-ascent/core/relation-view[1]#_g33447_|)
                           (cons (cons 'right
                                       |gerbil-ascent/core/relation-view[1]#_g33448_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33093 __tmp33445 '18 '#f '#f))
        (let ((__tmp33449
               (cons (cons 'prefix
                           |gerbil-ascent/core/relation-view[1]#_g33450_|)
                     (cons (cons 'left
                                 |gerbil-ascent/core/relation-view[1]#_g33451_|)
                           (cons (cons 'right
                                       |gerbil-ascent/core/relation-view[1]#_g33452_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33093 __tmp33449 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33093 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33093 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33093 '() '21 '#f '#f))
        __obj33093))
    (define |gerbil-ascent/core/relation-view[:0:]#rectangle-bucket|
      (let ((__obj33094
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33094
           'gerbil-ascent/core/relation-view#rectangle-bucket::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33094 'rectangle-bucket '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33094
           '(members blocks count plain)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33094
           '(members blocks count plain)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33094 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33094 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33094 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33094 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33094 '#f '13 '#f '#f))
        (let ((__tmp33453 |gerbil-ascent/core/relation-view[1]#_g33454_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33094 __tmp33453 '4 '#f '#f))
        (let ((__tmp33455 |gerbil-ascent/core/relation-view[1]#_g33456_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33094 __tmp33455 '14 '#f '#f))
        (let ((__tmp33457 |gerbil-ascent/core/relation-view[1]#_g33458_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33094 __tmp33457 '15 '#f '#f))
        (let ((__tmp33459
               (cons (cons 'members
                           |gerbil-ascent/core/relation-view[1]#_g33460_|)
                     (cons (cons 'blocks
                                 |gerbil-ascent/core/relation-view[1]#_g33461_|)
                           (cons (cons 'count
                                       |gerbil-ascent/core/relation-view[1]#_g33462_|)
                                 (cons (cons 'plain
                                             |gerbil-ascent/core/relation-view[1]#_g33463_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33094 __tmp33459 '16 '#f '#f))
        (let ((__tmp33464
               (cons (cons 'members
                           |gerbil-ascent/core/relation-view[1]#_g33465_|)
                     (cons (cons 'blocks
                                 |gerbil-ascent/core/relation-view[1]#_g33466_|)
                           (cons (cons 'count
                                       |gerbil-ascent/core/relation-view[1]#_g33467_|)
                                 (cons (cons 'plain
                                             |gerbil-ascent/core/relation-view[1]#_g33468_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33094 __tmp33464 '17 '#f '#f))
        (let ((__tmp33469
               (cons (cons 'members
                           |gerbil-ascent/core/relation-view[1]#_g33470_|)
                     (cons (cons 'blocks
                                 |gerbil-ascent/core/relation-view[1]#_g33471_|)
                           (cons (cons 'count
                                       |gerbil-ascent/core/relation-view[1]#_g33472_|)
                                 (cons (cons 'plain
                                             |gerbil-ascent/core/relation-view[1]#_g33473_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33094 __tmp33469 '18 '#f '#f))
        (let ((__tmp33474
               (cons (cons 'members
                           |gerbil-ascent/core/relation-view[1]#_g33475_|)
                     (cons (cons 'blocks
                                 |gerbil-ascent/core/relation-view[1]#_g33476_|)
                           (cons (cons 'count
                                       |gerbil-ascent/core/relation-view[1]#_g33477_|)
                                 (cons (cons 'plain
                                             |gerbil-ascent/core/relation-view[1]#_g33478_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33094 __tmp33474 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33094 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33094 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33094 '() '21 '#f '#f))
        __obj33094))))
