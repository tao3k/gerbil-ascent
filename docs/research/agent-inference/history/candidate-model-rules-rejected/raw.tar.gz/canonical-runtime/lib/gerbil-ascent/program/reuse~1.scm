(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/reuse[1]#_g37110_|
    (##structure
     gx#syntax-quote::t
     'native-reuse::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37112_|
    (##structure
     gx#syntax-quote::t
     'make-native-reuse
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37114_|
    (##structure
     gx#syntax-quote::t
     'native-reuse?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37116_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37117_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-affected
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37118_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-reader
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37119_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-publication
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37120_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-source-only
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37122_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37123_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-affected-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37124_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-reader-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37125_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-publication-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37126_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-source-only-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37128_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37129_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-affected
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37130_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-reader
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37131_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-publication
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37132_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-source-only
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37134_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37135_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-affected-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37136_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-reader-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37137_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-publication-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37138_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-source-only-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37140_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37142_|
    (##structure
     gx#syntax-quote::t
     'make-closure-seed-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37144_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37146_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-all
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37147_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-seen
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37148_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-delta
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37149_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-all-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37150_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-delta-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37151_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-lattice-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37153_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-all-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37154_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-seen-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37155_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-delta-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37156_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-all-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37157_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-delta-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37158_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-lattice-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37160_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-all
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37161_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-seen
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37162_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-delta
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37163_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-all-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37164_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-delta-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37165_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-lattice-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37167_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-all-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37168_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-seen-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37169_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-delta-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37170_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-all-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37171_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-delta-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37172_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-lattice-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/reuse[:0:]#native-reuse|
      (let ((__obj37046
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37046
           'gerbil-ascent/program/reuse#native-reuse::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37046 'native-reuse '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37046
           '(result affected reader publication source-only)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37046
           '(result affected reader publication source-only)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37046 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37046 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37046 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37046 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37046 '#f '13 '#f '#f))
        (let ((__tmp37109 |gerbil-ascent/program/reuse[1]#_g37110_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37046 __tmp37109 '4 '#f '#f))
        (let ((__tmp37111 |gerbil-ascent/program/reuse[1]#_g37112_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37046 __tmp37111 '14 '#f '#f))
        (let ((__tmp37113 |gerbil-ascent/program/reuse[1]#_g37114_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37046 __tmp37113 '15 '#f '#f))
        (let ((__tmp37115
               (cons (cons 'result |gerbil-ascent/program/reuse[1]#_g37116_|)
                     (cons (cons 'affected
                                 |gerbil-ascent/program/reuse[1]#_g37117_|)
                           (cons (cons 'reader
                                       |gerbil-ascent/program/reuse[1]#_g37118_|)
                                 (cons (cons 'publication
                                             |gerbil-ascent/program/reuse[1]#_g37119_|)
                                       (cons (cons 'source-only
                                                   |gerbil-ascent/program/reuse[1]#_g37120_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37046 __tmp37115 '16 '#f '#f))
        (let ((__tmp37121
               (cons (cons 'result |gerbil-ascent/program/reuse[1]#_g37122_|)
                     (cons (cons 'affected
                                 |gerbil-ascent/program/reuse[1]#_g37123_|)
                           (cons (cons 'reader
                                       |gerbil-ascent/program/reuse[1]#_g37124_|)
                                 (cons (cons 'publication
                                             |gerbil-ascent/program/reuse[1]#_g37125_|)
                                       (cons (cons 'source-only
                                                   |gerbil-ascent/program/reuse[1]#_g37126_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37046 __tmp37121 '17 '#f '#f))
        (let ((__tmp37127
               (cons (cons 'result |gerbil-ascent/program/reuse[1]#_g37128_|)
                     (cons (cons 'affected
                                 |gerbil-ascent/program/reuse[1]#_g37129_|)
                           (cons (cons 'reader
                                       |gerbil-ascent/program/reuse[1]#_g37130_|)
                                 (cons (cons 'publication
                                             |gerbil-ascent/program/reuse[1]#_g37131_|)
                                       (cons (cons 'source-only
                                                   |gerbil-ascent/program/reuse[1]#_g37132_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37046 __tmp37127 '18 '#f '#f))
        (let ((__tmp37133
               (cons (cons 'result |gerbil-ascent/program/reuse[1]#_g37134_|)
                     (cons (cons 'affected
                                 |gerbil-ascent/program/reuse[1]#_g37135_|)
                           (cons (cons 'reader
                                       |gerbil-ascent/program/reuse[1]#_g37136_|)
                                 (cons (cons 'publication
                                             |gerbil-ascent/program/reuse[1]#_g37137_|)
                                       (cons (cons 'source-only
                                                   |gerbil-ascent/program/reuse[1]#_g37138_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37046 __tmp37133 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37046 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37046 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37046 '() '21 '#f '#f))
        __obj37046))
    (define |gerbil-ascent/program/reuse[:0:]#closure-seed-state|
      (let ((__obj37047
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37047
           'gerbil-ascent/program/reuse#closure-seed-state::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37047
           'closure-seed-state
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37047
           '(all seen delta all-size delta-size lattice-rows)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37047
           '(all seen delta all-size delta-size lattice-rows)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37047 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37047 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37047 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37047 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37047 '#f '13 '#f '#f))
        (let ((__tmp37139 |gerbil-ascent/program/reuse[1]#_g37140_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37047 __tmp37139 '4 '#f '#f))
        (let ((__tmp37141 |gerbil-ascent/program/reuse[1]#_g37142_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37047 __tmp37141 '14 '#f '#f))
        (let ((__tmp37143 |gerbil-ascent/program/reuse[1]#_g37144_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37047 __tmp37143 '15 '#f '#f))
        (let ((__tmp37145
               (cons (cons 'all |gerbil-ascent/program/reuse[1]#_g37146_|)
                     (cons (cons 'seen
                                 |gerbil-ascent/program/reuse[1]#_g37147_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/reuse[1]#_g37148_|)
                                 (cons (cons 'all-size
                                             |gerbil-ascent/program/reuse[1]#_g37149_|)
                                       (cons (cons 'delta-size
                                                   |gerbil-ascent/program/reuse[1]#_g37150_|)
                                             (cons (cons 'lattice-rows
                                                         |gerbil-ascent/program/reuse[1]#_g37151_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37047 __tmp37145 '16 '#f '#f))
        (let ((__tmp37152
               (cons (cons 'all |gerbil-ascent/program/reuse[1]#_g37153_|)
                     (cons (cons 'seen
                                 |gerbil-ascent/program/reuse[1]#_g37154_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/reuse[1]#_g37155_|)
                                 (cons (cons 'all-size
                                             |gerbil-ascent/program/reuse[1]#_g37156_|)
                                       (cons (cons 'delta-size
                                                   |gerbil-ascent/program/reuse[1]#_g37157_|)
                                             (cons (cons 'lattice-rows
                                                         |gerbil-ascent/program/reuse[1]#_g37158_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37047 __tmp37152 '17 '#f '#f))
        (let ((__tmp37159
               (cons (cons 'all |gerbil-ascent/program/reuse[1]#_g37160_|)
                     (cons (cons 'seen
                                 |gerbil-ascent/program/reuse[1]#_g37161_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/reuse[1]#_g37162_|)
                                 (cons (cons 'all-size
                                             |gerbil-ascent/program/reuse[1]#_g37163_|)
                                       (cons (cons 'delta-size
                                                   |gerbil-ascent/program/reuse[1]#_g37164_|)
                                             (cons (cons 'lattice-rows
                                                         |gerbil-ascent/program/reuse[1]#_g37165_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37047 __tmp37159 '18 '#f '#f))
        (let ((__tmp37166
               (cons (cons 'all |gerbil-ascent/program/reuse[1]#_g37167_|)
                     (cons (cons 'seen
                                 |gerbil-ascent/program/reuse[1]#_g37168_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/reuse[1]#_g37169_|)
                                 (cons (cons 'all-size
                                             |gerbil-ascent/program/reuse[1]#_g37170_|)
                                       (cons (cons 'delta-size
                                                   |gerbil-ascent/program/reuse[1]#_g37171_|)
                                             (cons (cons 'lattice-rows
                                                         |gerbil-ascent/program/reuse[1]#_g37172_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37047 __tmp37166 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37047 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37047 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37047 '() '21 '#f '#f))
        __obj37047))))
