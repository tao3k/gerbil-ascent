(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/initialization[1]#_g35932_|
    (##structure
     gx#syntax-quote::t
     'pure
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35934_|
    (##structure
     gx#syntax-quote::t
     'callbacks
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35936_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35938_|
    (##structure
     gx#syntax-quote::t
     'make-initial-source-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35940_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35942_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-all
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35943_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-delta
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35944_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-all-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35945_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-delta-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35946_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-storage-states
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35947_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-seen
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35948_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-lattice-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35950_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-all-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35951_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-delta-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35952_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-all-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35953_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-delta-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35954_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-storage-states-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35955_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-seen-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35956_|
    (##structure
     gx#syntax-quote::t
     'initial-source-state-lattice-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35958_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-all
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35959_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-delta
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35960_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-all-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35961_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-delta-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35962_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-storage-states
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35963_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-seen
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35964_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-lattice-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35966_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-all-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35967_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-delta-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35968_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-all-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35969_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-delta-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35970_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-storage-states-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35971_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-seen-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/initialization[1]#_g35972_|
    (##structure
     gx#syntax-quote::t
     '&initial-source-state-lattice-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/initialization[:0:]#source-admission-loop|
      (lambda (_%$stx16306%_)
        (let* ((_%__stx3569035691%_ _%$stx16306%_)
               (_%$%g1631116396%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3569035691%_)))))
          (let ((_%__kont3569335694%_
                 (lambda (_%$%g1631316667%_
                          _%$%g1631416669%_
                          _%$%g1631516670%_
                          _%$%g1631616671%_
                          _%$%g1631716672%_
                          _%$%g1631816673%_
                          _%$%g1631916674%_
                          _%$%g1632016675%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'foldl))
                         (cons (cons (let ()
                                       (declare (not safe))
                                       (gx#datum->syntax__0 '#f 'lambda))
                                     (cons (cons _%$%g1631916674%_
                                                 (cons _%$%g1631616671%_ '()))
                                           (cons (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'unless))
                                                       (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'and))
                           (cons (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'list?))
                                       (cons _%$%g1631916674%_ '()))
                                 (cons (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f '=))
                                             (cons (cons (let ()
                                                           (declare (not safe))
                                                           (gx#datum->syntax__0
                                                            '#f
                                                            'length))
                                                         (cons _%$%g1631916674%_
                                                               '()))
                                                   (cons _%$%g1631716672%_
                                                         '())))
                                       '())))
                     (cons (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'error))
                                 (cons '"invalid ASCENT relation row"
                                       (cons _%$%g1631816673%_
                                             (cons _%$%g1631916674%_ '()))))
                           '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'let))
                     (cons (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'next-count))
                                 (cons (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f '+))
                                             (cons _%$%g1631616671%_
                                                   (cons '1 '())))
                                       '()))
                           (cons (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'when))
                                       (cons (cons (let ()
                                                     (declare (not safe))
                                                     (gx#datum->syntax__0
                                                      '#f
                                                      'or))
                                                   (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#datum->syntax__0 '#f '>))
                       (cons (let ()
                               (declare (not safe))
                               (gx#datum->syntax__0 '#f 'next-count))
                             (cons _%$%g1631516670%_ '())))
                 (cons (cons (let ()
                               (declare (not safe))
                               (gx#datum->syntax__0 '#f '>))
                             (cons (let ()
                                     (declare (not safe))
                                     (gx#datum->syntax__0 '#f 'next-count))
                                   (cons _%$%g1631416669%_ '())))
                       '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (cons (cons (let ()
                                                           (declare (not safe))
                                                           (gx#datum->syntax__0
                                                            '#f
                                                            'error))
                                                         (cons '"ASCENT source fact budget exceeded"
                                                               '()))
                                                   '())))
                                 (let ((__tmp35929
                                        (lambda (_%$%g1671316716%_
                                                 _%$%g1671416719%_)
                                          (cons _%$%g1671316716%_
                                                _%$%g1671416719%_)))
                                       (__tmp35928
                                        (cons (let ()
                                                (declare (not safe))
                                                (gx#datum->syntax__0
                                                 '#f
                                                 'next-count))
                                              '())))
                                   (declare (not safe))
                                   (foldr__0
                                    __tmp35929
                                    __tmp35928
                                    _%$%g1631316667%_)))))
               '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                               (cons _%$%g1631616671%_
                                     (cons _%$%g1632016675%_ '()))))))
                (_%__kont3569735698%_
                 (lambda (_%$%g1636016491%_
                          _%$%g1636116493%_
                          _%$%g1636216494%_
                          _%$%g1636316495%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'for-each))
                         (cons (cons (let ()
                                       (declare (not safe))
                                       (gx#datum->syntax__0 '#f 'lambda))
                                     (cons (cons _%$%g1636216494%_ '())
                                           (cons (cons _%$%g1636116493%_
                                                       (cons _%$%g1636216494%_
                                                             '()))
                                                 (let ((__tmp35930
                                                        (lambda (_%$%g1652316526%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%$%g1652416529%_)
                  (cons _%$%g1652316526%_ _%$%g1652416529%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (declare (not safe))
                                                   (foldr__0
                                                    __tmp35930
                                                    '()
                                                    _%$%g1636016491%_)))))
                               (cons _%$%g1636316495%_ '()))))))
            (let* ((_%__match3582535826%_
                    (lambda (_%$%e1636416403%_
                             _%$%hd1636516407%_
                             _%$%tl1636616410%_
                             _%$%e1636716413%_
                             _%$%hd1636816417%_
                             _%$%tl1636916420%_
                             _%$%e1637016423%_
                             _%$%hd1637116427%_
                             _%$%tl1637216430%_
                             _%$%e1637316433%_
                             _%$%hd1637416437%_
                             _%$%tl1637516440%_
                             _%$%e1637616443%_
                             _%$%hd1637716447%_
                             _%$%tl1637816450%_
                             _%$%e1637916453%_
                             _%$%hd1638016457%_
                             _%$%tl1638116460%_
                             _%__splice3569935700%_
                             _%$%target1638216463%_
                             _%$%tl1638416466%_)
                      (letrec ((_%$%loop1638516469%_
                                (lambda (_%$%hd1638316473%_
                                         _%$%body1638916476%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1638316473%_))
                                      (let ((_%$%e1638616478%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1638316473%_))))
                                        (let ((_%$%lp-tl1638816485%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1638616478%_)))
                                              (_%$%lp-hd1638716482%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1638616478%_))))
                                          (_%$%loop1638516469%_
                                           _%$%lp-tl1638816485%_
                                           (cons _%$%lp-hd1638716482%_
                                                 _%$%body1638916476%_))))
                                      (let ((_%$%body1639016488%_
                                             (reverse _%$%body1638916476%_)))
                                        (_%__kont3569735698%_
                                         _%$%body1639016488%_
                                         _%$%hd1638016457%_
                                         _%$%hd1637716447%_
                                         _%$%hd1637116427%_))))))
                        (_%$%loop1638516469%_ _%$%target1638216463%_ '()))))
                   (_%__match3577535776%_
                    (lambda (_%$%e1632116539%_
                             _%$%hd1632216543%_
                             _%$%tl1632316546%_
                             _%$%e1632416549%_
                             _%$%hd1632516553%_
                             _%$%tl1632616556%_
                             _%$%e1632716559%_
                             _%$%hd1632816563%_
                             _%$%tl1632916566%_
                             _%$%e1633016569%_
                             _%$%hd1633116573%_
                             _%$%tl1633216576%_
                             _%$%e1633316579%_
                             _%$%hd1633416583%_
                             _%$%tl1633516586%_
                             _%$%e1633616589%_
                             _%$%hd1633716593%_
                             _%$%tl1633816596%_
                             _%$%e1633916599%_
                             _%$%hd1634016603%_
                             _%$%tl1634116606%_
                             _%$%e1634216609%_
                             _%$%hd1634316613%_
                             _%$%tl1634416616%_
                             _%$%e1634516619%_
                             _%$%hd1634616623%_
                             _%$%tl1634716626%_
                             _%$%e1634816629%_
                             _%$%hd1634916633%_
                             _%$%tl1635016636%_
                             _%__splice3569535696%_
                             _%$%target1635116639%_
                             _%$%tl1635316642%_)
                      (letrec ((_%$%loop1635416645%_
                                (lambda (_%$%hd1635216649%_
                                         _%$%body1635816652%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1635216649%_))
                                      (let ((_%$%e1635516654%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1635216649%_))))
                                        (let ((_%$%lp-tl1635716661%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1635516654%_)))
                                              (_%$%lp-hd1635616658%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1635516654%_))))
                                          (_%$%loop1635416645%_
                                           _%$%lp-tl1635716661%_
                                           (cons _%$%lp-hd1635616658%_
                                                 _%$%body1635816652%_))))
                                      (let ((_%$%body1635916664%_
                                             (reverse _%$%body1635816652%_)))
                                        (_%__kont3569335694%_
                                         _%$%body1635916664%_
                                         _%$%hd1634916633%_
                                         _%$%hd1634616623%_
                                         _%$%hd1634316613%_
                                         _%$%hd1634016603%_
                                         _%$%hd1633716593%_
                                         _%$%hd1633416583%_
                                         _%$%hd1632816563%_))))))
                        (_%$%loop1635416645%_ _%$%target1635116639%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3569035691%_))
                  (let ((_%$%e1632116539%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3569035691%_))))
                    (let ((_%$%tl1632316546%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1632116539%_)))
                          (_%$%hd1632216543%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1632116539%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl1632316546%_))
                          (let ((_%$%e1632416549%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl1632316546%_))))
                            (let ((_%$%tl1632616556%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e1632416549%_)))
                                  (_%$%hd1632516553%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e1632416549%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#identifier? _%$%hd1632516553%_))
                                  (if (let ((__tmp35931
                                             |gerbil-ascent/program/initialization[1]#_g35932_|))
                                        (declare (not safe))
                                        (gx#free-identifier=?
                                         __tmp35931
                                         _%$%hd1632516553%_))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl1632616556%_))
                                          (let ((_%$%e1632716559%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl1632616556%_))))
                                            (let ((_%$%tl1632916566%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e1632716559%_)))
                                                  (_%$%hd1632816563%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e1632716559%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%tl1632916566%_))
                                                  (let ((_%$%e1633016569%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%tl1632916566%_))))
                                                    (let ((_%$%tl1633216576%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e1633016569%_)))
                                                          (_%$%hd1633116573%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e1633016569%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-pair?
                                                             _%$%hd1633116573%_))
                                                          (let ((_%$%e1633316579%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%$%hd1633116573%_))))
                    (let ((_%$%tl1633516586%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1633316579%_)))
                          (_%$%hd1633416583%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1633316579%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl1633516586%_))
                          (let ((_%$%e1633616589%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl1633516586%_))))
                            (let ((_%$%tl1633816596%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e1633616589%_)))
                                  (_%$%hd1633716593%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e1633616589%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%tl1633816596%_))
                                  (let ((_%$%e1633916599%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%tl1633816596%_))))
                                    (let ((_%$%tl1634116606%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e1633916599%_)))
                                          (_%$%hd1634016603%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e1633916599%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl1634116606%_))
                                          (let ((_%$%e1634216609%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl1634116606%_))))
                                            (let ((_%$%tl1634416616%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e1634216609%_)))
                                                  (_%$%hd1634316613%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e1634216609%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%tl1634416616%_))
                                                  (let ((_%$%e1634516619%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%tl1634416616%_))))
                                                    (let ((_%$%tl1634716626%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e1634516619%_)))
                                                          (_%$%hd1634616623%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e1634516619%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-pair?
                                                             _%$%tl1634716626%_))
                                                          (let ((_%$%e1634816629%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%$%tl1634716626%_))))
                    (let ((_%$%tl1635016636%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1634816629%_)))
                          (_%$%hd1634916633%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1634816629%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-null? _%$%tl1635016636%_))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair/null? _%$%tl1633216576%_))
                              (let ((_%__splice3569535696%_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-split-splice->vector
                                        _%$%tl1633216576%_
                                        '0))))
                                (let ((_%$%tl1635316642%_
                                       (let ()
                                         (declare (not safe))
                                         (##vector-ref
                                          _%__splice3569535696%_
                                          '1)))
                                      (_%$%target1635116639%_
                                       (let ()
                                         (declare (not safe))
                                         (##vector-ref
                                          _%__splice3569535696%_
                                          '0))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl1635316642%_))
                                      (_%__match3577535776%_
                                       _%$%e1632116539%_
                                       _%$%hd1632216543%_
                                       _%$%tl1632316546%_
                                       _%$%e1632416549%_
                                       _%$%hd1632516553%_
                                       _%$%tl1632616556%_
                                       _%$%e1632716559%_
                                       _%$%hd1632816563%_
                                       _%$%tl1632916566%_
                                       _%$%e1633016569%_
                                       _%$%hd1633116573%_
                                       _%$%tl1633216576%_
                                       _%$%e1633316579%_
                                       _%$%hd1633416583%_
                                       _%$%tl1633516586%_
                                       _%$%e1633616589%_
                                       _%$%hd1633716593%_
                                       _%$%tl1633816596%_
                                       _%$%e1633916599%_
                                       _%$%hd1634016603%_
                                       _%$%tl1634116606%_
                                       _%$%e1634216609%_
                                       _%$%hd1634316613%_
                                       _%$%tl1634416616%_
                                       _%$%e1634516619%_
                                       _%$%hd1634616623%_
                                       _%$%tl1634716626%_
                                       _%$%e1634816629%_
                                       _%$%hd1634916633%_
                                       _%$%tl1635016636%_
                                       _%__splice3569535696%_
                                       _%$%target1635116639%_
                                       _%$%tl1635316642%_)
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g1631116396%_)))))
                              (let ()
                                (declare (not safe))
                                (_%$%g1631116396%_)))
                          (let () (declare (not safe)) (_%$%g1631116396%_)))))
                  (let () (declare (not safe)) (_%$%g1631116396%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (let ()
                                                    (declare (not safe))
                                                    (_%$%g1631116396%_)))))
                                          (let ()
                                            (declare (not safe))
                                            (_%$%g1631116396%_)))))
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1631116396%_)))))
                          (let () (declare (not safe)) (_%$%g1631116396%_)))))
                  (let () (declare (not safe)) (_%$%g1631116396%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (let ()
                                                    (declare (not safe))
                                                    (_%$%g1631116396%_)))))
                                          (let ()
                                            (declare (not safe))
                                            (_%$%g1631116396%_)))
                                      (if (let ((__tmp35933
                                                 |gerbil-ascent/program/initialization[1]#_g35934_|))
                                            (declare (not safe))
                                            (gx#free-identifier=?
                                             __tmp35933
                                             _%$%hd1632516553%_))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair?
                                                 _%$%tl1632616556%_))
                                              (let ((_%$%e1637016423%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-e
                                                        _%$%tl1632616556%_))))
                                                (let ((_%$%tl1637216430%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##cdr _%$%e1637016423%_)))
                                                      (_%$%hd1637116427%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##car _%$%e1637016423%_))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair?
                                                         _%$%tl1637216430%_))
                                                      (let ((_%$%e1637316433%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-e _%$%tl1637216430%_))))
                (let ((_%$%tl1637516440%_
                       (let () (declare (not safe)) (##cdr _%$%e1637316433%_)))
                      (_%$%hd1637416437%_
                       (let ()
                         (declare (not safe))
                         (##car _%$%e1637316433%_))))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-pair? _%$%hd1637416437%_))
                      (let ((_%$%e1637616443%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-e _%$%hd1637416437%_))))
                        (let ((_%$%tl1637816450%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%$%e1637616443%_)))
                              (_%$%hd1637716447%_
                               (let ()
                                 (declare (not safe))
                                 (##car _%$%e1637616443%_))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair? _%$%tl1637816450%_))
                              (let ((_%$%e1637916453%_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-e _%$%tl1637816450%_))))
                                (let ((_%$%tl1638116460%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%e1637916453%_)))
                                      (_%$%hd1638016457%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%$%e1637916453%_))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl1638116460%_))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair/null?
                                             _%$%tl1637516440%_))
                                          (let ((_%__splice3569935700%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-split-splice->vector
                                                    _%$%tl1637516440%_
                                                    '0))))
                                            (let ((_%$%tl1638416466%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3569935700%_
                                                      '1)))
                                                  (_%$%target1638216463%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3569935700%_
                                                      '0))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl1638416466%_))
                                                  (_%__match3582535826%_
                                                   _%$%e1632116539%_
                                                   _%$%hd1632216543%_
                                                   _%$%tl1632316546%_
                                                   _%$%e1632416549%_
                                                   _%$%hd1632516553%_
                                                   _%$%tl1632616556%_
                                                   _%$%e1637016423%_
                                                   _%$%hd1637116427%_
                                                   _%$%tl1637216430%_
                                                   _%$%e1637316433%_
                                                   _%$%hd1637416437%_
                                                   _%$%tl1637516440%_
                                                   _%$%e1637616443%_
                                                   _%$%hd1637716447%_
                                                   _%$%tl1637816450%_
                                                   _%$%e1637916453%_
                                                   _%$%hd1638016457%_
                                                   _%$%tl1638116460%_
                                                   _%__splice3569935700%_
                                                   _%$%target1638216463%_
                                                   _%$%tl1638416466%_)
                                                  (let ()
                                                    (declare (not safe))
                                                    (_%$%g1631116396%_)))))
                                          (let ()
                                            (declare (not safe))
                                            (_%$%g1631116396%_)))
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g1631116396%_)))))
                              (let ()
                                (declare (not safe))
                                (_%$%g1631116396%_)))))
                      (let () (declare (not safe)) (_%$%g1631116396%_)))))
              (let () (declare (not safe)) (_%$%g1631116396%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g1631116396%_)))
                                          (let ()
                                            (declare (not safe))
                                            (_%$%g1631116396%_))))
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1631116396%_)))))
                          (let () (declare (not safe)) (_%$%g1631116396%_)))))
                  (let () (declare (not safe)) (_%$%g1631116396%_))))))))
    (define |gerbil-ascent/program/initialization[:0:]#initial-source-state|
      (let ((__obj35827
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35827
           'gerbil-ascent/program/initialization#initial-source-state::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35827
           'initial-source-state
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35827
           '(all delta all-size delta-size storage-states seen lattice-rows)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35827
           '(all delta all-size delta-size storage-states seen lattice-rows)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35827 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35827 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35827 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35827 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35827 '#f '13 '#f '#f))
        (let ((__tmp35935 |gerbil-ascent/program/initialization[1]#_g35936_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35827 __tmp35935 '4 '#f '#f))
        (let ((__tmp35937 |gerbil-ascent/program/initialization[1]#_g35938_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35827 __tmp35937 '14 '#f '#f))
        (let ((__tmp35939 |gerbil-ascent/program/initialization[1]#_g35940_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35827 __tmp35939 '15 '#f '#f))
        (let ((__tmp35941
               (cons (cons 'all
                           |gerbil-ascent/program/initialization[1]#_g35942_|)
                     (cons (cons 'delta
                                 |gerbil-ascent/program/initialization[1]#_g35943_|)
                           (cons (cons 'all-size
                                       |gerbil-ascent/program/initialization[1]#_g35944_|)
                                 (cons (cons 'delta-size
                                             |gerbil-ascent/program/initialization[1]#_g35945_|)
                                       (cons (cons 'storage-states
                                                   |gerbil-ascent/program/initialization[1]#_g35946_|)
                                             (cons (cons 'seen
                                                         |gerbil-ascent/program/initialization[1]#_g35947_|)
                                                   (cons (cons 'lattice-rows
                                                               |gerbil-ascent/program/initialization[1]#_g35948_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35827 __tmp35941 '16 '#f '#f))
        (let ((__tmp35949
               (cons (cons 'all
                           |gerbil-ascent/program/initialization[1]#_g35950_|)
                     (cons (cons 'delta
                                 |gerbil-ascent/program/initialization[1]#_g35951_|)
                           (cons (cons 'all-size
                                       |gerbil-ascent/program/initialization[1]#_g35952_|)
                                 (cons (cons 'delta-size
                                             |gerbil-ascent/program/initialization[1]#_g35953_|)
                                       (cons (cons 'storage-states
                                                   |gerbil-ascent/program/initialization[1]#_g35954_|)
                                             (cons (cons 'seen
                                                         |gerbil-ascent/program/initialization[1]#_g35955_|)
                                                   (cons (cons 'lattice-rows
                                                               |gerbil-ascent/program/initialization[1]#_g35956_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35827 __tmp35949 '17 '#f '#f))
        (let ((__tmp35957
               (cons (cons 'all
                           |gerbil-ascent/program/initialization[1]#_g35958_|)
                     (cons (cons 'delta
                                 |gerbil-ascent/program/initialization[1]#_g35959_|)
                           (cons (cons 'all-size
                                       |gerbil-ascent/program/initialization[1]#_g35960_|)
                                 (cons (cons 'delta-size
                                             |gerbil-ascent/program/initialization[1]#_g35961_|)
                                       (cons (cons 'storage-states
                                                   |gerbil-ascent/program/initialization[1]#_g35962_|)
                                             (cons (cons 'seen
                                                         |gerbil-ascent/program/initialization[1]#_g35963_|)
                                                   (cons (cons 'lattice-rows
                                                               |gerbil-ascent/program/initialization[1]#_g35964_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35827 __tmp35957 '18 '#f '#f))
        (let ((__tmp35965
               (cons (cons 'all
                           |gerbil-ascent/program/initialization[1]#_g35966_|)
                     (cons (cons 'delta
                                 |gerbil-ascent/program/initialization[1]#_g35967_|)
                           (cons (cons 'all-size
                                       |gerbil-ascent/program/initialization[1]#_g35968_|)
                                 (cons (cons 'delta-size
                                             |gerbil-ascent/program/initialization[1]#_g35969_|)
                                       (cons (cons 'storage-states
                                                   |gerbil-ascent/program/initialization[1]#_g35970_|)
                                             (cons (cons 'seen
                                                         |gerbil-ascent/program/initialization[1]#_g35971_|)
                                                   (cons (cons 'lattice-rows
                                                               |gerbil-ascent/program/initialization[1]#_g35972_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35827 __tmp35965 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35827 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35827 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35827 '() '21 '#f '#f))
        __obj35827))))
