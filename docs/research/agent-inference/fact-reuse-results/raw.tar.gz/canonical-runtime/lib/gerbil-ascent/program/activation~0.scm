(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/activation::timestamp 1791690984)
  (begin
    (define gerbil-ascent/program/activation#gerbil-ascent-activate-rule
      (lambda (_%rule11910%_)
        (let ((_%plan11912%_ (vector-ref _%rule11910%_ '5)))
          (vector (vector-ref _%rule11910%_ '0)
                  (vector-ref _%rule11910%_ '1)
                  (vector-ref _%rule11910%_ '2)
                  (vector-ref _%rule11910%_ '3)
                  (vector-ref _%rule11910%_ '4)
                  _%plan11912%_
                  (if _%plan11912%_
                      (make-vector (vector-ref _%plan11912%_ '2) '#f)
                      '#f)))))
    (define gerbil-ascent/program/activation#gerbil-ascent-activate-plans
      (lambda (_%plans11906%_)
        (vector-map
         (lambda (_%rules11908%_)
           (map gerbil-ascent/program/activation#gerbil-ascent-activate-rule
                _%rules11908%_))
         _%plans11906%_)))))
