(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/reuse::timestamp 1791691020)
  (begin
    (define gerbil-ascent/program/reuse#native-reuse::t
      (let ((__tmp37382 (list)) (__tmp37381 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/reuse#native-reuse::t
         'native-reuse
         __tmp37382
         '(result affected reader publication source-only)
         __tmp37381
         '#f)))
    (define gerbil-ascent/program/reuse#native-reuse?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/program/reuse#native-reuse::t)))
    (define gerbil-ascent/program/reuse#make-native-reuse
      (lambda _%$args14190%_
        (apply make-instance
               gerbil-ascent/program/reuse#native-reuse::t
               _%$args14190%_)))
    (define gerbil-ascent/program/reuse#native-reuse-result
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'result)))
    (define gerbil-ascent/program/reuse#native-reuse-affected
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'affected)))
    (define gerbil-ascent/program/reuse#native-reuse-reader
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'reader)))
    (define gerbil-ascent/program/reuse#native-reuse-publication
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'publication)))
    (define gerbil-ascent/program/reuse#native-reuse-source-only
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'source-only)))
    (define gerbil-ascent/program/reuse#native-reuse-result-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'result)))
    (define gerbil-ascent/program/reuse#native-reuse-affected-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'affected)))
    (define gerbil-ascent/program/reuse#native-reuse-reader-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'reader)))
    (define gerbil-ascent/program/reuse#native-reuse-publication-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'publication)))
    (define gerbil-ascent/program/reuse#native-reuse-source-only-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'source-only)))
    (define gerbil-ascent/program/reuse#&native-reuse-result
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'result)))
    (define gerbil-ascent/program/reuse#&native-reuse-affected
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'affected)))
    (define gerbil-ascent/program/reuse#&native-reuse-reader
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'reader)))
    (define gerbil-ascent/program/reuse#&native-reuse-publication
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'publication)))
    (define gerbil-ascent/program/reuse#&native-reuse-source-only
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#native-reuse::t
         'source-only)))
    (define gerbil-ascent/program/reuse#&native-reuse-result-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'result)))
    (define gerbil-ascent/program/reuse#&native-reuse-affected-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'affected)))
    (define gerbil-ascent/program/reuse#&native-reuse-reader-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'reader)))
    (define gerbil-ascent/program/reuse#&native-reuse-publication-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'publication)))
    (define gerbil-ascent/program/reuse#&native-reuse-source-only-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#native-reuse::t
         'source-only)))
    (define gerbil-ascent/program/reuse#source-only-relations
      (lambda (_%analysis14181%_ _%count14182%_)
        (let ((_%source-only14184%_ (make-vector _%count14182%_ '#t)))
          (for-each
           (lambda (_%rule14186%_)
             (for-each
              (lambda (_%head14188%_)
                (vector-set!
                 _%source-only14184%_
                 (vector-ref _%head14188%_ '0)
                 '#f))
              (vector-ref _%rule14186%_ '0)))
           (vector-ref _%analysis14181%_ '2))
          _%source-only14184%_)))
    (define gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__%
      (lambda (_%previous14142%_
               _%candidate14143%_
               _%completed14144%_
               _%analysis14145%_
               _%source-cut14146%_
               _%publication14147%_)
        (if (let ()
              (declare (not safe))
              (clan/poo/object#.ref _%completed14144%_ 'finished))
            '#!void
            (let ()
              (declare (not safe))
              (error '"cannot reuse a partial closure")))
        (let ((_%$%affected1414814150%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/program/update-selection#gerbil-ascent-update-selection__%
                  _%previous14142%_
                  _%candidate14143%_
                  _%analysis14145%_
                  _%source-cut14146%_))))
          (if _%$%affected1414814150%_
              (let ((_%affected14152%_ _%$%affected1414814150%_))
                (let ((__tmp37384
                       (let ()
                         (declare (not safe))
                         (gerbil-ascent/program/result#gerbil-ascent-publication-reader
                          _%publication14147%_
                          _%completed14144%_)))
                      (__tmp37383
                       (gerbil-ascent/program/reuse#source-only-relations
                        _%analysis14145%_
                        (vector-length _%previous14142%_))))
                  (declare (not safe))
                  (##structure
                   gerbil-ascent/program/reuse#native-reuse::t
                   _%completed14144%_
                   _%affected14152%_
                   __tmp37384
                   _%publication14147%_
                   __tmp37383)))
              '#f))))
    (define gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__0
      (lambda (_%previous14157%_
               _%candidate14158%_
               _%completed14159%_
               _%analysis14160%_)
        (let* ((_%source-cut14162%_ '#f) (_%publication14164%_ '#f))
          (gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__%
           _%previous14157%_
           _%candidate14158%_
           _%completed14159%_
           _%analysis14160%_
           _%source-cut14162%_
           _%publication14164%_))))
    (define gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__1
      (lambda (_%previous14166%_
               _%candidate14167%_
               _%completed14168%_
               _%analysis14169%_
               _%source-cut14170%_)
        (let ((_%publication14172%_ '#f))
          (gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__%
           _%previous14166%_
           _%candidate14167%_
           _%completed14168%_
           _%analysis14169%_
           _%source-cut14170%_
           _%publication14172%_))))
    (define gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse
      (lambda _g37385_
        (let ((_g37386_ (let () (declare (not safe)) (##length _g37385_))))
          (cond ((let () (declare (not safe)) (##fx= _g37386_ 4))
                 (apply gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__0
                        _g37385_))
                ((let () (declare (not safe)) (##fx= _g37386_ 5))
                 (apply gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__1
                        _g37385_))
                ((let () (declare (not safe)) (##fx= _g37386_ 6))
                 (apply gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__%
                        _g37385_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse
                  _g37385_))))))
    (define gerbil-ascent/program/reuse#gerbil-ascent-activate-rules
      (lambda (_%x14134%_)
        (let ((__tmp37387 (vector-ref _%x14134%_ '5)))
          (declare (not safe))
          (gerbil-ascent/program/activation#gerbil-ascent-activate-plans
           __tmp37387))))
    (define gerbil-ascent/program/reuse#gerbil-ascent-activate-selected-rules
      (lambda (_%analysis14131%_ _%affected14132%_)
        (let ((__tmp37388
               (let ((__tmp37389 (vector-ref _%analysis14131%_ '5)))
                 (declare (not safe))
                 (gerbil-ascent/program/update-selection#gerbil-ascent-select-rule-plans
                  __tmp37389
                  _%affected14132%_))))
          (declare (not safe))
          (gerbil-ascent/program/activation#gerbil-ascent-activate-plans
           __tmp37388))))
    (define gerbil-ascent/program/reuse#gerbil-ascent-reuse-active-rules
      (lambda (_%full-active-by-stratum14121%_ _%reuse14122%_)
        (if _%reuse14122%_
            (let* ((_%reuse14124%_ _%reuse14122%_)
                   (__tmp37390
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-ref _%reuse14124%_ '2 '#f '#f))))
              (declare (not safe))
              (gerbil-ascent/program/update-selection#gerbil-ascent-update-active-plans
               _%full-active-by-stratum14121%_
               __tmp37390))
            _%full-active-by-stratum14121%_)))
    (define gerbil-ascent/program/reuse#closure-seed-state::t
      (let ((__tmp37392 (list)) (__tmp37391 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/reuse#closure-seed-state::t
         'closure-seed-state
         __tmp37392
         '(all seen delta all-size delta-size lattice-rows)
         __tmp37391
         '#f)))
    (define gerbil-ascent/program/reuse#closure-seed-state?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/reuse#closure-seed-state::t)))
    (define gerbil-ascent/program/reuse#make-closure-seed-state
      (lambda _%$args14118%_
        (apply make-instance
               gerbil-ascent/program/reuse#closure-seed-state::t
               _%$args14118%_)))
    (define gerbil-ascent/program/reuse#closure-seed-state-all
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'all)))
    (define gerbil-ascent/program/reuse#closure-seed-state-seen
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'seen)))
    (define gerbil-ascent/program/reuse#closure-seed-state-delta
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'delta)))
    (define gerbil-ascent/program/reuse#closure-seed-state-all-size
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'all-size)))
    (define gerbil-ascent/program/reuse#closure-seed-state-delta-size
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'delta-size)))
    (define gerbil-ascent/program/reuse#closure-seed-state-lattice-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'lattice-rows)))
    (define gerbil-ascent/program/reuse#closure-seed-state-all-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'all)))
    (define gerbil-ascent/program/reuse#closure-seed-state-seen-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'seen)))
    (define gerbil-ascent/program/reuse#closure-seed-state-delta-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'delta)))
    (define gerbil-ascent/program/reuse#closure-seed-state-all-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'all-size)))
    (define gerbil-ascent/program/reuse#closure-seed-state-delta-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'delta-size)))
    (define gerbil-ascent/program/reuse#closure-seed-state-lattice-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'lattice-rows)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-all
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'all)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-seen
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'seen)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-delta
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'delta)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-all-size
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'all-size)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-delta-size
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'delta-size)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-lattice-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/reuse#closure-seed-state::t
         'lattice-rows)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-all-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'all)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-seen-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'seen)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-delta-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'delta)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-all-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'all-size)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-delta-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'delta-size)))
    (define gerbil-ascent/program/reuse#&closure-seed-state-lattice-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/reuse#closure-seed-state::t
         'lattice-rows)))
    (define gerbil-ascent/program/reuse#gerbil-ascent-seed-native-reuse!
      (lambda (_%reuse14067%_
               _%schema14068%_
               _%buffers14069%_
               _%source-materialized-count14070%_
               _%derived-limit14071%_
               _%output-limit14072%_)
        (let ((_%names14074%_ (vector-ref _%schema14068%_ '1))
              (_%arity14075%_ (vector-ref _%schema14068%_ '2))
              (_%field-checkers14076%_ (vector-ref _%schema14068%_ '3))
              (_%lattice-joins14077%_ (vector-ref _%schema14068%_ '7))
              (_%all14078%_
               (##structure-ref
                _%buffers14069%_
                '1
                gerbil-ascent/program/reuse#closure-seed-state::t
                '#f))
              (_%seen14079%_
               (##structure-ref
                _%buffers14069%_
                '2
                gerbil-ascent/program/reuse#closure-seed-state::t
                '#f))
              (_%delta14080%_
               (##structure-ref
                _%buffers14069%_
                '3
                gerbil-ascent/program/reuse#closure-seed-state::t
                '#f))
              (_%all-size14081%_
               (##structure-ref
                _%buffers14069%_
                '4
                gerbil-ascent/program/reuse#closure-seed-state::t
                '#f))
              (_%delta-size14082%_
               (##structure-ref
                _%buffers14069%_
                '5
                gerbil-ascent/program/reuse#closure-seed-state::t
                '#f))
              (_%lattice-rows14083%_
               (##structure-ref
                _%buffers14069%_
                '6
                gerbil-ascent/program/reuse#closure-seed-state::t
                '#f))
              (_%count14084%_ (vector-length (vector-ref _%schema14068%_ '1)))
              (_%derived-count14085%_ '0))
          (if _%reuse14067%_
              (begin
                (if (let ()
                      (declare (not safe))
                      (##structure-instance-of?
                       _%reuse14067%_
                       'gerbil-ascent/program/reuse#native-reuse::t))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"invalid native reuse capsule")))
                (let _%seed14087%_ ((_%index14089%_ '0))
                  (if (< _%index14089%_ _%count14084%_)
                      (begin
                        (if (vector-ref
                             (##structure-ref
                              _%reuse14067%_
                              '2
                              gerbil-ascent/program/reuse#native-reuse::t
                              '#f)
                             _%index14089%_)
                            '#!void
                            (if (if (vector-ref
                                     _%lattice-joins14077%_
                                     _%index14089%_)
                                    '#f
                                    (and (vector-ref
                                          (##structure-ref
                                           _%reuse14067%_
                                           '5
                                           gerbil-ascent/program/reuse#native-reuse::t
                                           '#f)
                                          _%index14089%_)
                                         (eqv? (vector-ref
                                                _%all-size14081%_
                                                _%index14089%_)
                                               (let ((__tmp37395
                                                      (##structure-ref
                                                       _%reuse14067%_
                                                       '4
                                                       gerbil-ascent/program/reuse#native-reuse::t
                                                       '#f))
                                                     (__tmp37394
                                                      (##structure-ref
                                                       _%reuse14067%_
                                                       '1
                                                       gerbil-ascent/program/reuse#native-reuse::t
                                                       '#f))
                                                     (__tmp37393
                                                      (vector-ref
                                                       _%names14074%_
                                                       _%index14089%_)))
                                                 (declare (not safe))
                                                 (gerbil-ascent/program/result#gerbil-ascent-publication-size
                                                  __tmp37395
                                                  __tmp37394
                                                  __tmp37393)))))
                                '#!void
                                (let* ((_%rows14094%_
                                        ((let ((_%$e14091%_
                                                (##structure-ref
                                                 _%reuse14067%_
                                                 '3
                                                 gerbil-ascent/program/reuse#native-reuse::t
                                                 '#f)))
                                           (if _%$e14091%_
                                               _%$e14091%_
                                               (let ((__tmp37396
                                                      (##structure-ref
                                                       _%reuse14067%_
                                                       '1
                                                       gerbil-ascent/program/reuse#native-reuse::t
                                                       '#f)))
                                                 (declare (not safe))
                                                 (clan/poo/object#.ref
                                                  __tmp37396
                                                  'rows-of))))
                                         (vector-ref
                                          _%names14074%_
                                          _%index14089%_)))
                                       (_%base14096%_
                                        (vector-ref
                                         _%all14078%_
                                         _%index14089%_))
                                       (_%check14098%_
                                        (vector-ref
                                         _%field-checkers14076%_
                                         _%index14089%_))
                                       (_%base-present14104%_
                                        (if _%check14098%_
                                            '#f
                                            (if (vector-ref
                                                 _%lattice-joins14077%_
                                                 _%index14089%_)
                                                (let ((_%membership14100%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (make-hash-table__%
                                                          '#f
                                                          absent-value
                                                          absent-value
                                                          absent-value
                                                          absent-value
                                                          absent-value
                                                          absent-value
                                                          absent-value
                                                          absent-value))))
                                                  (for-each
                                                   (lambda (_%row14102%_)
                                                     (let ()
                                                       (declare (not safe))
                                                       (__hash-put!
                                                        _%membership14100%_
                                                        _%row14102%_
                                                        '#t)))
                                                   _%base14096%_)
                                                  _%membership14100%_)
                                                (vector-ref
                                                 _%seen14079%_
                                                 _%index14089%_))))
                                       (_%present14106%_
                                        (let ()
                                          (declare (not safe))
                                          (make-hash-table__%
                                           '#f
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value
                                           absent-value))))
                                  (for-each
                                   (lambda (_%row14109%_)
                                     (if (and (list? _%row14109%_)
                                              (= (let ()
                                                   (declare (not safe))
                                                   (##length _%row14109%_))
                                                 (vector-ref
                                                  _%arity14075%_
                                                  _%index14089%_)))
                                         '#!void
                                         (let ()
                                           (declare (not safe))
                                           (error '"invalid completed reuse row")))
                                     (if _%check14098%_
                                         (_%check14098%_ _%row14109%_)
                                         '#!void)
                                     (if (let ()
                                           (declare (not safe))
                                           (__hash-get
                                            _%present14106%_
                                            _%row14109%_))
                                         '#!void
                                         (begin
                                           (let ()
                                             (declare (not safe))
                                             (__hash-put!
                                              _%present14106%_
                                              _%row14109%_
                                              '#t))
                                           (if (if _%base-present14104%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (hash-get
                                                      _%base-present14104%_
                                                      _%row14109%_))
                                                   (member _%row14109%_
                                                           _%base14096%_))
                                               '#!void
                                               (set! _%derived-count14085%_
                                                     (+ _%derived-count14085%_
                                                        '1))))))
                                   _%rows14094%_)
                                  (if (or (> _%derived-count14085%_
                                             _%derived-limit14071%_)
                                          (> (+ _%source-materialized-count14070%_
                                                _%derived-count14085%_)
                                             _%output-limit14072%_))
                                      (let ()
                                        (declare (not safe))
                                        (error '"ASCENT reused closure fact budget exceeded"))
                                      '#!void)
                                  (if (vector-ref
                                       _%lattice-joins14077%_
                                       _%index14089%_)
                                      (let ((_%keyed14114%_
                                             (let ()
                                               (declare (not safe))
                                               (make-hash-table__%
                                                '#f
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value))))
                                        (for-each
                                         (lambda (_%row14116%_)
                                           (let ((__tmp37397
                                                  (let ()
                                                    (declare (not safe))
                                                    (gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-key
                                                     _%row14116%_))))
                                             (declare (not safe))
                                             (__hash-put!
                                              _%keyed14114%_
                                              __tmp37397
                                              _%row14116%_)))
                                         _%rows14094%_)
                                        (vector-set!
                                         _%lattice-rows14083%_
                                         _%index14089%_
                                         _%keyed14114%_))
                                      '#!void)
                                  (vector-set!
                                   _%all14078%_
                                   _%index14089%_
                                   (reverse _%rows14094%_))
                                  (vector-set!
                                   _%seen14079%_
                                   _%index14089%_
                                   _%present14106%_)
                                  (vector-set!
                                   _%delta14080%_
                                   _%index14089%_
                                   (vector-ref _%all14078%_ _%index14089%_))
                                  (vector-set!
                                   _%all-size14081%_
                                   _%index14089%_
                                   (length _%rows14094%_))
                                  (vector-set!
                                   _%delta-size14082%_
                                   _%index14089%_
                                   (length _%rows14094%_)))))
                        (_%seed14087%_ (+ _%index14089%_ '1)))
                      '#!void)))
              '#!void)
          _%derived-count14085%_)))))
