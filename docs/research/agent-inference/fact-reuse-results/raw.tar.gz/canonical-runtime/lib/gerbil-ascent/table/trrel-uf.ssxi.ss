prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/table

(begin
  (declare-class
   gerbil-ascent/table/trrel-uf#uf-node::t
   (@class gerbil-ascent/table/trrel-uf#uf-node::t
           ()
           (object::t t::t)
           (parent members size reach predecessors order)
           (parent members size reach predecessors order)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-node::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/trrel-uf#uf-node::t)
    'class::t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-node?
   (@predicate gerbil-ascent/table/trrel-uf#uf-node::t))
  (declare-type
   gerbil-ascent/table/trrel-uf#make-uf-node
   (@constructor gerbil-ascent/table/trrel-uf#uf-node::t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-node-parent
   (@accessor gerbil-ascent/table/trrel-uf#uf-node::t parent #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-node-members
   (@accessor gerbil-ascent/table/trrel-uf#uf-node::t members #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-node-size
   (@accessor gerbil-ascent/table/trrel-uf#uf-node::t size #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-node-reach
   (@accessor gerbil-ascent/table/trrel-uf#uf-node::t reach #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-node-predecessors
   (@accessor gerbil-ascent/table/trrel-uf#uf-node::t predecessors #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-node-order
   (@accessor gerbil-ascent/table/trrel-uf#uf-node::t order #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-node-parent-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-node::t parent #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-node-members-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-node::t members #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-node-size-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-node::t size #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-node-reach-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-node::t reach #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-node-predecessors-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-node::t predecessors #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-node-order-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-node::t order #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-node-parent
   (@accessor gerbil-ascent/table/trrel-uf#uf-node::t parent #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-node-members
   (@accessor gerbil-ascent/table/trrel-uf#uf-node::t members #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-node-size
   (@accessor gerbil-ascent/table/trrel-uf#uf-node::t size #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-node-reach
   (@accessor gerbil-ascent/table/trrel-uf#uf-node::t reach #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-node-predecessors
   (@accessor gerbil-ascent/table/trrel-uf#uf-node::t predecessors #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-node-order
   (@accessor gerbil-ascent/table/trrel-uf#uf-node::t order #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-node-parent-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-node::t parent #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-node-members-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-node::t members #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-node-size-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-node::t size #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-node-reach-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-node::t reach #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-node-predecessors-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-node::t predecessors #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-node-order-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-node::t order #f))
  (declare-class
   gerbil-ascent/table/trrel-uf#uf-group::t
   (@class gerbil-ascent/table/trrel-uf#uf-group::t
           ()
           (object::t t::t)
           (nodes roots next-order indexed?)
           (nodes roots next-order indexed?)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-group::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/trrel-uf#uf-group::t)
    'class::t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-group?
   (@predicate gerbil-ascent/table/trrel-uf#uf-group::t))
  (declare-type
   gerbil-ascent/table/trrel-uf#make-uf-group
   (@constructor gerbil-ascent/table/trrel-uf#uf-group::t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-group-nodes
   (@accessor gerbil-ascent/table/trrel-uf#uf-group::t nodes #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-group-roots
   (@accessor gerbil-ascent/table/trrel-uf#uf-group::t roots #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-group-next-order
   (@accessor gerbil-ascent/table/trrel-uf#uf-group::t next-order #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-group-indexed?
   (@accessor gerbil-ascent/table/trrel-uf#uf-group::t indexed? #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-group-nodes-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-group::t nodes #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-group-roots-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-group::t roots #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-group-next-order-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-group::t next-order #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-group-indexed?-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-group::t indexed? #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-group-nodes
   (@accessor gerbil-ascent/table/trrel-uf#uf-group::t nodes #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-group-roots
   (@accessor gerbil-ascent/table/trrel-uf#uf-group::t roots #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-group-next-order
   (@accessor gerbil-ascent/table/trrel-uf#uf-group::t next-order #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-group-indexed?
   (@accessor gerbil-ascent/table/trrel-uf#uf-group::t indexed? #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-group-nodes-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-group::t nodes #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-group-roots-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-group::t roots #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-group-next-order-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-group::t next-order #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-group-indexed?-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-group::t indexed? #f))
  (declare-class
   gerbil-ascent/table/trrel-uf#uf-insertion::t
   (@class gerbil-ascent/table/trrel-uf#uf-insertion::t
           ()
           (object::t t::t)
           (group-key group row left-node right-node a b)
           (group-key group row left-node right-node a b)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-insertion::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/trrel-uf#uf-insertion::t)
    'class::t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-insertion?
   (@predicate gerbil-ascent/table/trrel-uf#uf-insertion::t))
  (declare-type
   gerbil-ascent/table/trrel-uf#make-uf-insertion
   (@constructor gerbil-ascent/table/trrel-uf#uf-insertion::t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-insertion-group-key
   (@accessor gerbil-ascent/table/trrel-uf#uf-insertion::t group-key #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-insertion-group
   (@accessor gerbil-ascent/table/trrel-uf#uf-insertion::t group #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-insertion-row
   (@accessor gerbil-ascent/table/trrel-uf#uf-insertion::t row #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-insertion-left-node
   (@accessor gerbil-ascent/table/trrel-uf#uf-insertion::t left-node #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-insertion-right-node
   (@accessor gerbil-ascent/table/trrel-uf#uf-insertion::t right-node #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-insertion-a
   (@accessor gerbil-ascent/table/trrel-uf#uf-insertion::t a #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-insertion-b
   (@accessor gerbil-ascent/table/trrel-uf#uf-insertion::t b #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-insertion-group-key-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-insertion::t group-key #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-insertion-group-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-insertion::t group #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-insertion-row-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-insertion::t row #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-insertion-left-node-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-insertion::t left-node #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-insertion-right-node-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-insertion::t right-node #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-insertion-a-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-insertion::t a #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#uf-insertion-b-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-insertion::t b #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-insertion-group-key
   (@accessor gerbil-ascent/table/trrel-uf#uf-insertion::t group-key #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-insertion-group
   (@accessor gerbil-ascent/table/trrel-uf#uf-insertion::t group #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-insertion-row
   (@accessor gerbil-ascent/table/trrel-uf#uf-insertion::t row #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-insertion-left-node
   (@accessor gerbil-ascent/table/trrel-uf#uf-insertion::t left-node #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-insertion-right-node
   (@accessor gerbil-ascent/table/trrel-uf#uf-insertion::t right-node #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-insertion-a
   (@accessor gerbil-ascent/table/trrel-uf#uf-insertion::t a #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-insertion-b
   (@accessor gerbil-ascent/table/trrel-uf#uf-insertion::t b #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-insertion-group-key-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-insertion::t group-key #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-insertion-group-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-insertion::t group #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-insertion-row-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-insertion::t row #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-insertion-left-node-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-insertion::t left-node #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-insertion-right-node-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-insertion::t right-node #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-insertion-a-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-insertion::t a #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&uf-insertion-b-set!
   (@mutator gerbil-ascent/table/trrel-uf#uf-insertion::t b #f))
  (declare-class
   gerbil-ascent/table/trrel-uf#frozen-members::t
   (@class gerbil-ascent/table/trrel-uf#frozen-members::t
           ()
           (object::t t::t)
           (rows count)
           (rows count)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#frozen-members::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/trrel-uf#frozen-members::t)
    'class::t))
  (declare-type
   gerbil-ascent/table/trrel-uf#frozen-members?
   (@predicate gerbil-ascent/table/trrel-uf#frozen-members::t))
  (declare-type
   gerbil-ascent/table/trrel-uf#make-frozen-members
   (@constructor gerbil-ascent/table/trrel-uf#frozen-members::t))
  (declare-type
   gerbil-ascent/table/trrel-uf#frozen-members-rows
   (@accessor gerbil-ascent/table/trrel-uf#frozen-members::t rows #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#frozen-members-count
   (@accessor gerbil-ascent/table/trrel-uf#frozen-members::t count #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#frozen-members-rows-set!
   (@mutator gerbil-ascent/table/trrel-uf#frozen-members::t rows #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#frozen-members-count-set!
   (@mutator gerbil-ascent/table/trrel-uf#frozen-members::t count #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#&frozen-members-rows
   (@accessor gerbil-ascent/table/trrel-uf#frozen-members::t rows #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&frozen-members-count
   (@accessor gerbil-ascent/table/trrel-uf#frozen-members::t count #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&frozen-members-rows-set!
   (@mutator gerbil-ascent/table/trrel-uf#frozen-members::t rows #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#&frozen-members-count-set!
   (@mutator gerbil-ascent/table/trrel-uf#frozen-members::t count #f))
  (declare-type
   gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-state
   (@lambda 0 make-hash-table))
  (declare-type
   gerbil-ascent/table/trrel-uf#root
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel-uf)))
  (declare-type
   gerbil-ascent/table/trrel-uf#reachable?
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel-uf)))
  (declare-type
   gerbil-ascent/table/trrel-uf#fresh
   (@lambda 3
            #f
            signature:
            (return:
             gerbil-ascent/table/trrel-uf#uf-node::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel-uf)))
  (declare-type
   gerbil-ascent/table/trrel-uf#ordered-neighbors
   (@lambda 2
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel-uf)))
  (declare-type
   gerbil-ascent/table/trrel-uf#rebuild-predecessors!
   (@lambda 1
            #f
            signature:
            (return:
             void::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel-uf)))
  (declare-type
   gerbil-ascent/table/trrel-uf#retire-cycle-predecessors!
   (@lambda 2
            #f
            signature:
            (return:
             void::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel-uf)))
  (declare-type
   gerbil-ascent/table/trrel-uf#merge-cycle!
   (@lambda 3
            #f
            signature:
            (return:
             void::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel-uf)))
  (declare-type
   gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-insert!
   (@lambda 3
            #f
            signature:
            (return:
             gerbil-ascent/core/relation-view#relation-view::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel-uf)))
  (declare-type
   gerbil-ascent/table/trrel-uf#insert-components!
   (@lambda 3
            #f
            signature:
            (return:
             gerbil-ascent/core/relation-view#relation-view::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel-uf)))
  (declare-type
   gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-observation
   (@lambda 1
            #f
            signature:
            (return:
             vector::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel-uf)))
  (declare-type
   gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-validate
   (@lambda 1
            #f
            signature:
            (return:
             true::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel-uf)))
  (declare-type
   gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-extension
   (@lambda 5
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel-uf)))
  (declare-type
   gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__%
   (@lambda 2
            #f
            signature:
            (return:
             gerbil-ascent/core/relation-view#relation-view::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel-uf)))
  (declare-type
   gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__0
   (@lambda 1
            #f
            signature:
            (return:
             gerbil-ascent/core/relation-view#relation-view::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel-uf)))
  (declare-type
   gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze
   (@case-lambda
    (1
     gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__0
     signature:
     (return:
      gerbil-ascent/core/relation-view#relation-view::t
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/table/trrel-uf))
    (2
     gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__%
     signature:
     (return:
      gerbil-ascent/core/relation-view#relation-view::t
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/table/trrel-uf))))
  (declare-type
   gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-frontier-extension
   (@lambda 3
            #f
            signature:
            (return:
             gerbil-ascent/core/relation-view#relation-view::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel-uf)))
  (declare-type
   gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-snapshot
   (@case-lambda
    (1
     gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__0
     signature:
     (return:
      gerbil-ascent/core/relation-view#relation-view::t
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/table/trrel-uf))
    (2
     gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__%
     signature:
     (return:
      gerbil-ascent/core/relation-view#relation-view::t
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/table/trrel-uf))))
  (declare-type
   gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-view-count
   (@accessor gerbil-ascent/core/relation-view#relation-view::t count #t))
  (declare-type
   gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-view-for-each
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel-uf)))
  (declare-type
   gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-view-lookup
   (@lambda 3
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/trrel-uf))))
