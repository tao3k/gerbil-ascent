(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/scheme-session[1]#_g37986_|
    (##structure
     gx#syntax-quote::t
     'relational-session::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37988_|
    (##structure
     gx#syntax-quote::t
     'make-relational-session
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37990_|
    (##structure
     gx#syntax-quote::t
     'relational-session?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37992_|
    (##structure
     gx#syntax-quote::t
     'relational-session-engine
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37993_|
    (##structure
     gx#syntax-quote::t
     'relational-session-source-arities
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37995_|
    (##structure
     gx#syntax-quote::t
     'relational-session-engine-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37996_|
    (##structure
     gx#syntax-quote::t
     'relational-session-source-arities-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37998_|
    (##structure
     gx#syntax-quote::t
     '&relational-session-engine
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37999_|
    (##structure
     gx#syntax-quote::t
     '&relational-session-source-arities
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38001_|
    (##structure
     gx#syntax-quote::t
     '&relational-session-engine-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38002_|
    (##structure
     gx#syntax-quote::t
     '&relational-session-source-arities-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38004_|
    (##structure
     gx#syntax-quote::t
     'relational-program-session::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38006_|
    (##structure
     gx#syntax-quote::t
     'make-relational-program-session
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38008_|
    (##structure
     gx#syntax-quote::t
     'relational-program-session?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38010_|
    (##structure
     gx#syntax-quote::t
     'relational-program-session-engine
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38011_|
    (##structure
     gx#syntax-quote::t
     'relational-program-session-source-arities
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38013_|
    (##structure
     gx#syntax-quote::t
     'relational-program-session-engine-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38014_|
    (##structure
     gx#syntax-quote::t
     'relational-program-session-source-arities-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38016_|
    (##structure
     gx#syntax-quote::t
     '&relational-program-session-engine
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38017_|
    (##structure
     gx#syntax-quote::t
     '&relational-program-session-source-arities
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38019_|
    (##structure
     gx#syntax-quote::t
     '&relational-program-session-engine-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38020_|
    (##structure
     gx#syntax-quote::t
     '&relational-program-session-source-arities-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/scheme-session[:0:]#relational-session|
      (let ((__obj37962
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37962
           'gerbil-ascent/program/scheme-session#relational-session::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37962
           'relational-session
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37962
           '(engine source-arities)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37962
           '(engine source-arities)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37962 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37962 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37962 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37962 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37962 '#f '13 '#f '#f))
        (let ((__tmp37985 |gerbil-ascent/program/scheme-session[1]#_g37986_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37962 __tmp37985 '4 '#f '#f))
        (let ((__tmp37987 |gerbil-ascent/program/scheme-session[1]#_g37988_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37962 __tmp37987 '14 '#f '#f))
        (let ((__tmp37989 |gerbil-ascent/program/scheme-session[1]#_g37990_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37962 __tmp37989 '15 '#f '#f))
        (let ((__tmp37991
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g37992_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g37993_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37962 __tmp37991 '16 '#f '#f))
        (let ((__tmp37994
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g37995_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g37996_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37962 __tmp37994 '17 '#f '#f))
        (let ((__tmp37997
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g37998_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g37999_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37962 __tmp37997 '18 '#f '#f))
        (let ((__tmp38000
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g38001_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g38002_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37962 __tmp38000 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37962 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37962 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37962 '() '21 '#f '#f))
        __obj37962))
    (define |gerbil-ascent/program/scheme-session[:0:]#relational-program-session|
      (let ((__obj37963
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37963
           'gerbil-ascent/program/scheme-session#relational-program-session::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37963
           'relational-program-session
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37963
           '(engine source-arities)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37963
           '(engine source-arities)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37963 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37963 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37963 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37963 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37963 '#f '13 '#f '#f))
        (let ((__tmp38003 |gerbil-ascent/program/scheme-session[1]#_g38004_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37963 __tmp38003 '4 '#f '#f))
        (let ((__tmp38005 |gerbil-ascent/program/scheme-session[1]#_g38006_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37963 __tmp38005 '14 '#f '#f))
        (let ((__tmp38007 |gerbil-ascent/program/scheme-session[1]#_g38008_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37963 __tmp38007 '15 '#f '#f))
        (let ((__tmp38009
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g38010_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g38011_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37963 __tmp38009 '16 '#f '#f))
        (let ((__tmp38012
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g38013_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g38014_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37963 __tmp38012 '17 '#f '#f))
        (let ((__tmp38015
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g38016_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g38017_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37963 __tmp38015 '18 '#f '#f))
        (let ((__tmp38018
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g38019_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g38020_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37963 __tmp38018 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37963 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37963 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37963 '() '21 '#f '#f))
        __obj37963))))
