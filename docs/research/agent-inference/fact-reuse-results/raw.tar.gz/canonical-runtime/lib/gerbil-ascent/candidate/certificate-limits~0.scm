(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/certificate-limits::timestamp 1791690988)
  (begin
    (define gerbil-ascent/candidate/certificate-limits#+max-certificate-relations+
      '64)
    (define gerbil-ascent/candidate/certificate-limits#+max-certificate-rows+
      '4096)
    (define gerbil-ascent/candidate/certificate-limits#+max-certificate-cells+
      '32768)
    (define gerbil-ascent/candidate/certificate-limits#+max-certificate-row-arity+
      '1024)
    (define gerbil-ascent/candidate/certificate-limits#certificate-material::t
      (let ((__tmp34451 (list)) (__tmp34450 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/certificate-limits#certificate-material::t
         'certificate-material
         __tmp34451
         '(rows cells)
         __tmp34450
         '#f)))
    (define gerbil-ascent/candidate/certificate-limits#certificate-material?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/certificate-limits#certificate-material::t)))
    (define gerbil-ascent/candidate/certificate-limits#make-certificate-material
      (lambda _%$args27329%_
        (apply make-instance
               gerbil-ascent/candidate/certificate-limits#certificate-material::t
               _%$args27329%_)))
    (define gerbil-ascent/candidate/certificate-limits#certificate-material-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/certificate-limits#certificate-material::t
         'rows)))
    (define gerbil-ascent/candidate/certificate-limits#certificate-material-cells
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/certificate-limits#certificate-material::t
         'cells)))
    (define gerbil-ascent/candidate/certificate-limits#certificate-material-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/certificate-limits#certificate-material::t
         'rows)))
    (define gerbil-ascent/candidate/certificate-limits#certificate-material-cells-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/certificate-limits#certificate-material::t
         'cells)))
    (define gerbil-ascent/candidate/certificate-limits#&certificate-material-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/certificate-limits#certificate-material::t
         'rows)))
    (define gerbil-ascent/candidate/certificate-limits#&certificate-material-cells
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/certificate-limits#certificate-material::t
         'cells)))
    (define gerbil-ascent/candidate/certificate-limits#&certificate-material-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/certificate-limits#certificate-material::t
         'rows)))
    (define gerbil-ascent/candidate/certificate-limits#&certificate-material-cells-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/certificate-limits#certificate-material::t
         'cells)))
    (define gerbil-ascent/candidate/certificate-limits#make-certificate-material-budget
      (lambda ()
        (let ()
          (declare (not safe))
          (##structure
           gerbil-ascent/candidate/certificate-limits#certificate-material::t
           '0
           '0))))
    (define gerbil-ascent/candidate/certificate-limits#certificate-material-reserve!
      (lambda (_%budget27323%_ _%row27324%_)
        (let ((_%width27326%_
               (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                _%row27324%_
                gerbil-ascent/candidate/certificate-limits#+max-certificate-row-arity+)))
          (if _%width27326%_
              (if (< (##structure-ref
                      _%budget27323%_
                      '1
                      gerbil-ascent/candidate/certificate-limits#certificate-material::t
                      '#f)
                     gerbil-ascent/candidate/certificate-limits#+max-certificate-rows+)
                  (if (<= (+ (##structure-ref
                              _%budget27323%_
                              '2
                              gerbil-ascent/candidate/certificate-limits#certificate-material::t
                              '#f)
                             _%width27326%_)
                          gerbil-ascent/candidate/certificate-limits#+max-certificate-cells+)
                      (begin
                        (##structure-set!
                         _%budget27323%_
                         (+ (##structure-ref
                             _%budget27323%_
                             '1
                             gerbil-ascent/candidate/certificate-limits#certificate-material::t
                             '#f)
                            '1)
                         '1
                         gerbil-ascent/candidate/certificate-limits#certificate-material::t
                         '#f)
                        (##structure-set!
                         _%budget27323%_
                         (+ (##structure-ref
                             _%budget27323%_
                             '2
                             gerbil-ascent/candidate/certificate-limits#certificate-material::t
                             '#f)
                            _%width27326%_)
                         '2
                         gerbil-ascent/candidate/certificate-limits#certificate-material::t
                         '#f)
                        '#t)
                      '#f)
                  '#f)
              '#f))))
    (define gerbil-ascent/candidate/certificate-limits#bounded-list-length
      (lambda (_%items27307%_ _%maximum27308%_)
        (let _%$loop27310%_ ((_%rest27313%_ _%items27307%_)
                             (_%count27314%_ '0))
          (if (or (null? _%rest27313%_)
                  (not (pair? _%rest27313%_))
                  (>= _%count27314%_ _%maximum27308%_))
              (if (null? _%rest27313%_) _%count27314%_ '#f)
              (_%$loop27310%_ (cdr _%rest27313%_) (+ _%count27314%_ '1))))))
    (define gerbil-ascent/candidate/certificate-limits#unique-rows?
      (lambda (_%rows27301%_)
        (let* ((_%seen27303%_
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value)))
               (__tmp34452
                (lambda (_%row27305%_)
                  (if (let ()
                        (declare (not safe))
                        (__hash-get _%seen27303%_ _%row27305%_))
                      '#f
                      (begin
                        (let ()
                          (declare (not safe))
                          (__hash-put! _%seen27303%_ _%row27305%_ '#t))
                        '#t)))))
          (declare (not safe))
          (andmap__0 __tmp34452 _%rows27301%_))))
    (define gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
      (lambda (_%proceed?27290%_ _%visit27291%_ _%items27292%_)
        (let _%walk27294%_ ((_%remaining27296%_ _%items27292%_))
          (if (_%proceed?27290%_)
              (if (null? _%remaining27296%_)
                  '#t
                  (let ()
                    (_%visit27291%_ (car _%remaining27296%_))
                    (_%walk27294%_ (cdr _%remaining27296%_))))
              '#f))))))
