(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/core/dependency-graph::timestamp 1791690983)
  (begin
    (define gerbil-ascent/core/dependency-graph#graph-frame::t
      (let ((__tmp33800 (list))
            (__tmp33799
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/core/dependency-graph#graph-frame::t
         'graph-frame
         __tmp33800
         '(node remaining parent)
         __tmp33799
         '#f)))
    (define gerbil-ascent/core/dependency-graph#graph-frame?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/core/dependency-graph#graph-frame::t)))
    (define gerbil-ascent/core/dependency-graph#make-graph-frame
      (lambda _%$args7403%_
        (apply make-instance
               gerbil-ascent/core/dependency-graph#graph-frame::t
               _%$args7403%_)))
    (define gerbil-ascent/core/dependency-graph#graph-frame-node
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'node)))
    (define gerbil-ascent/core/dependency-graph#graph-frame-remaining
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'remaining)))
    (define gerbil-ascent/core/dependency-graph#graph-frame-parent
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'parent)))
    (define gerbil-ascent/core/dependency-graph#graph-frame-node-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'node)))
    (define gerbil-ascent/core/dependency-graph#graph-frame-remaining-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'remaining)))
    (define gerbil-ascent/core/dependency-graph#graph-frame-parent-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'parent)))
    (define gerbil-ascent/core/dependency-graph#&graph-frame-node
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'node)))
    (define gerbil-ascent/core/dependency-graph#&graph-frame-remaining
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'remaining)))
    (define gerbil-ascent/core/dependency-graph#&graph-frame-parent
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'parent)))
    (define gerbil-ascent/core/dependency-graph#&graph-frame-node-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'node)))
    (define gerbil-ascent/core/dependency-graph#&graph-frame-remaining-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'remaining)))
    (define gerbil-ascent/core/dependency-graph#&graph-frame-parent-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/dependency-graph#graph-frame::t
         'parent)))
    (define gerbil-ascent/core/dependency-graph#gerbil-ascent-graph-close!
      (lambda (_%successors7348%_ _%selected7349%_)
        (let ((_%count7351%_ (vector-length _%selected7349%_))
              (_%pending7352%_ '()))
          (let _%seed7354%_ ((_%index7356%_ '0))
            (if (< _%index7356%_ _%count7351%_)
                (begin
                  (if (vector-ref _%selected7349%_ _%index7356%_)
                      (set! _%pending7352%_
                            (cons _%index7356%_ _%pending7352%_))
                      '#!void)
                  (_%seed7354%_ (+ _%index7356%_ '1)))
                '#!void))
          (letrec ((_%enqueue7358%_
                    (lambda (_%target7401%_)
                      (if (vector-ref _%selected7349%_ _%target7401%_)
                          '#!void
                          (begin
                            (vector-set! _%selected7349%_ _%target7401%_ '#t)
                            (set! _%pending7352%_
                                  (cons _%target7401%_ _%pending7352%_)))))))
            (let _%visit7360%_ ()
              (let* ((_%$%pending73627371%_ _%pending7352%_)
                     (_%$%E73657375%_
                      (lambda ()
                        (let ()
                          (declare (not safe))
                          (error '"No clause matching"
                                 _%$%pending73627371%_
                                 '([])
                                 '([source . rest])))
                        '#!void)))
                (let ((_%$%K73697398%_ (lambda () '#!void))
                      (_%$%K73667382%_
                       (lambda (_%rest7379%_ _%source7380%_)
                         (set! _%pending7352%_ _%rest7379%_)
                         (for-each
                          _%enqueue7358%_
                          (vector-ref _%successors7348%_ _%source7380%_))
                         (_%visit7360%_))))
                  (let ((_%$%try-match73647394%_
                         (lambda ()
                           (if (pair? _%$%pending73627371%_)
                               (let ((_%$%tl73687387%_
                                      (let ()
                                        (declare (not safe))
                                        (##cdr _%$%pending73627371%_)))
                                     (_%$%hd73677385%_
                                      (let ()
                                        (declare (not safe))
                                        (##car _%$%pending73627371%_))))
                                 (let ((_%source7390%_ _%$%hd73677385%_)
                                       (_%rest7392%_ _%$%tl73687387%_))
                                   (_%$%K73667382%_
                                    _%rest7392%_
                                    _%source7390%_)))
                               (_%$%E73657375%_)))))
                    (if (null? _%$%pending73627371%_)
                        '#!void
                        (_%$%try-match73647394%_))))))))))
    (define gerbil-ascent/core/dependency-graph#gerbil-ascent-graph-components
      (lambda (_%successors7030%_)
        (let* ((_%count7032%_ (vector-length _%successors7030%_))
               (_%next-index7034%_ '0)
               (_%indices7036%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count7032%_ '#f)))
               (_%lowlinks7038%_
                (let () (declare (not safe)) (##make-vector _%count7032%_ '0)))
               (_%stack7040%_ '())
               (_%components7042%_ '()))
          (letrec ((_%enter7045%_
                    (lambda (_%node7343%_ _%frames7344%_)
                      (let ((_%index7346%_ _%next-index7034%_))
                        (set! _%next-index7034%_
                              (let ()
                                (declare (not safe))
                                (##fx+ _%next-index7034%_ '1)))
                        (vector-set!
                         _%indices7036%_
                         _%node7343%_
                         _%index7346%_)
                        (vector-set!
                         _%lowlinks7038%_
                         _%node7343%_
                         _%index7346%_)
                        (set! _%stack7040%_ (cons _%node7343%_ _%stack7040%_)))
                      (let ((__tmp33801
                             (vector-ref _%successors7030%_ _%node7343%_)))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/core/dependency-graph#graph-frame::t
                         _%node7343%_
                         __tmp33801
                         _%frames7344%_))))
                   (_%lower!7046%_
                    (lambda (_%node7340%_ _%index7341%_)
                      (vector-set!
                       _%lowlinks7038%_
                       _%node7340%_
                       (fxmin (vector-ref _%lowlinks7038%_ _%node7340%_)
                              _%index7341%_))))
                   (_%finish7047%_
                    (lambda (_%node7305%_)
                      (if (fx= (vector-ref _%lowlinks7038%_ _%node7305%_)
                               (vector-ref _%indices7036%_ _%node7305%_))
                          (let _%pop7307%_ ((_%members7309%_ '()))
                            (let* ((_%$%stack73107317%_ _%stack7040%_)
                                   (_%$%E73127320%_
                                    (lambda ()
                                      (let ()
                                        (declare (not safe))
                                        (error '"No clause matching"
                                               _%$%stack73107317%_
                                               '([member . rest])))
                                      '#!void))
                                   (_%$%K73137328%_
                                    (lambda (_%rest7323%_ _%member7324%_)
                                      (set! _%stack7040%_ _%rest7323%_)
                                      (vector-set!
                                       _%indices7036%_
                                       _%member7324%_
                                       '#t)
                                      (let ((_%collected7326%_
                                             (cons _%member7324%_
                                                   _%members7309%_)))
                                        (if (fx= _%member7324%_ _%node7305%_)
                                            (set! _%components7042%_
                                                  (cons _%collected7326%_
                                                        _%components7042%_))
                                            (_%pop7307%_
                                             _%collected7326%_))))))
                              (if (pair? _%$%stack73107317%_)
                                  (let ((_%$%hd73147331%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%stack73107317%_)))
                                        (_%$%tl73157333%_
                                         (let ()
                                           (declare (not safe))
                                           (##cdr _%$%stack73107317%_))))
                                    (let* ((_%member7336%_ _%$%hd73147331%_)
                                           (_%rest7338%_ _%$%tl73157333%_))
                                      (_%$%K73137328%_
                                       _%rest7338%_
                                       _%member7336%_)))
                                  (_%$%E73127320%_))))
                          '#!void)))
                   (_%__advance7188%_
                    (lambda (_%node7259%_ _%remaining7260%_ _%frame7261%_)
                      (let* ((_%frame7264%_ _%frame7261%_)
                             (_%$%remaining72727279%_ _%remaining7260%_)
                             (_%$%E72747282%_
                              (lambda ()
                                (let ()
                                  (declare (not safe))
                                  (error '"No clause matching"
                                         _%$%remaining72727279%_
                                         '([neighbor . rest])))
                                '#!void))
                             (_%$%K72757293%_
                              (lambda (_%rest7285%_ _%neighbor7286%_)
                                (let ()
                                  (declare (not safe))
                                  (##unchecked-structure-set!
                                   _%frame7264%_
                                   _%rest7285%_
                                   '2
                                   '#f
                                   '#f))
                                (let ((_%index7288%_
                                       (vector-ref
                                        _%indices7036%_
                                        _%neighbor7286%_)))
                                  (if _%index7288%_
                                      (if (eq? _%index7288%_ '#t)
                                          _%frame7264%_
                                          (let ()
                                            (_%lower!7046%_
                                             _%node7259%_
                                             _%index7288%_)
                                            _%frame7264%_))
                                      (_%enter7045%_
                                       _%neighbor7286%_
                                       _%frame7264%_))))))
                        (if (pair? _%$%remaining72727279%_)
                            (let ((_%$%hd72767296%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%remaining72727279%_)))
                                  (_%$%tl72777298%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%remaining72727279%_))))
                              (let* ((_%neighbor7301%_ _%$%hd72767296%_)
                                     (_%rest7303%_ _%$%tl72777298%_))
                                (_%$%K72757293%_
                                 _%rest7303%_
                                 _%neighbor7301%_)))
                            (_%$%E72747282%_)))))
                   (_%advance7189%_
                    (lambda (_%node7245%_ _%remaining7246%_ _%frame7247%_)
                      (let ((_%frame7250%_ _%frame7247%_))
                        (_%__advance7188%_
                         _%node7245%_
                         _%remaining7246%_
                         _%frame7250%_))))
                   (_%leave7190%_
                    (lambda (_%node7235%_ _%parent7236%_)
                      (_%finish7047%_ _%node7235%_)
                      (if _%parent7236%_
                          (let ((_%parent7238%_ _%parent7236%_))
                            (_%lower!7046%_
                             (let ()
                               (declare (not safe))
                               (##unchecked-structure-ref
                                _%parent7238%_
                                '1
                                '#f
                                '#f))
                             (vector-ref _%lowlinks7038%_ _%node7235%_)))
                          '#!void)
                      _%parent7236%_))
                   (_%traverse7191%_
                    (lambda (_%root7197%_)
                      (let _%walk7199%_ ((_%frame7201%_
                                          (_%enter7045%_ _%root7197%_ '#f)))
                        (if _%frame7201%_
                            (let ((_%frame7203%_ _%frame7201%_))
                              (_%walk7199%_
                               (if (pair? (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%frame7203%_
                                             '2
                                             '#f
                                             '#f)))
                                   (let* ((_%node7212%_
                                           (let ()
                                             (declare (not safe))
                                             (##unchecked-structure-ref
                                              _%frame7203%_
                                              '1
                                              '#f
                                              '#f)))
                                          (_%remaining7215%_
                                           (let ()
                                             (declare (not safe))
                                             (##unchecked-structure-ref
                                              _%frame7203%_
                                              '2
                                              '#f
                                              '#f)))
                                          (_%frame7218%_ _%frame7203%_)
                                          (_%frame7222%_ _%frame7218%_))
                                     (_%__advance7188%_
                                      _%node7212%_
                                      _%remaining7215%_
                                      _%frame7222%_))
                                   (_%leave7190%_
                                    (let ()
                                      (declare (not safe))
                                      (##unchecked-structure-ref
                                       _%frame7203%_
                                       '1
                                       '#f
                                       '#f))
                                    (let ()
                                      (declare (not safe))
                                      (##unchecked-structure-ref
                                       _%frame7203%_
                                       '3
                                       '#f
                                       '#f))))))
                            '#!void)))))
            (let _%roots7193%_ ((_%root7195%_ '0))
              (if (let ()
                    (declare (not safe))
                    (##fx< _%root7195%_ _%count7032%_))
                  (begin
                    (if (vector-ref _%indices7036%_ _%root7195%_)
                        '#!void
                        (_%traverse7191%_ _%root7195%_))
                    (_%roots7193%_
                     (let () (declare (not safe)) (##fx+ _%root7195%_ '1))))
                  '#!void))
            _%components7042%_))))))
