(declare (block) (standard-bindings) (extended-bindings))
(begin
  (load-module "clan/poo/support/base")
  (load-module "gerbil-ascent/program/aggregators~0"))
