(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/provider::timestamp 1791687557)
  (begin
    (define gerbil-ascent/table/provider#+procedure+
      (let ((__tmp9606 (lambda (_%_value9599%_ _%_context9600%_) '())))
        (declare (not safe))
        (core/types#poo-flow-predicate-contract
         'ascent/index-provider-procedure
         procedure?
         __tmp9606)))
    (define gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
      (let ((__obj9603
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp9608
               (list (cons 'sexp
                           (let ((__tmp9609
                                  (lambda (_%@9539%_)
                                    'GerbilAscentIndexProviderContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp9609)))
                     (cons 'identity
                           (let ((__tmp9610
                                  (lambda (_%@9545%_) 'ascent/index-provider)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp9610)))
                     (cons 'proto
                           (let ((__tmp9611
                                  (lambda (_%@9550%_)
                                    (let ((__obj9601
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp9613 (list))
                                            (__tmp9612 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp9613
                                         __tmp9612
                                         __obj9601))
                                      __obj9601))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp9611)))
                     (cons 'responsibilities
                           (let ((__tmp9614
                                  (lambda (_%@9564%_)
                                    (let ((__obj9602
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp9616
                                             (list (cons '.build-index
                                                         (let ((__tmp9617
                                                                (lambda (_%self9582%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/table/provider#+procedure+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp9617)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.extend-index!
                                                         (let ((__tmp9618
                                                                (lambda (_%self9589%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/table/provider#+procedure+)))
                   (declare (not safe))
                   (##structure clan/poo/object#$self-slot-spec::t __tmp9618)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.lookup-index
                                                         (let ((__tmp9619
                                                                (lambda (_%self9594%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/table/provider#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp9619)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp9615 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp9616
                                         __tmp9615
                                         __obj9602))
                                      __obj9602))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp9614)))))
              (__tmp9607 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp9608
           __tmp9607
           __obj9603))
        __obj9603))
    (define gerbil-ascent/table/provider#IndexProvider.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
         'proto)))
    (define gerbil-ascent/table/provider#gerbil-ascent-index-provider-build
      (lambda (_%provider9522%_ _%rows9523%_ _%columns9524%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%provider9522%_ '.build-index))
         _%rows9523%_
         _%columns9524%_)))
    (define gerbil-ascent/table/provider#gerbil-ascent-index-provider-extend!
      (lambda (_%provider9517%_ _%index9518%_ _%rows9519%_ _%columns9520%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%provider9517%_ '.extend-index!))
         _%index9518%_
         _%rows9519%_
         _%columns9520%_)))
    (define gerbil-ascent/table/provider#gerbil-ascent-index-provider-lookup
      (lambda (_%provider9513%_ _%index9514%_ _%key9515%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%provider9513%_ '.lookup-index))
         _%index9514%_
         _%key9515%_)))
    (define gerbil-ascent/table/provider#+canonical-hash-index-provider+
      (let ((__tmp9620
             (let ((__obj9604
                    (let ()
                      (declare (not safe))
                      (##structure
                       clan/poo/object#object::t
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f))))
               (let ((__tmp9622
                      (list (cons '.build-index
                                  (let ((__tmp9623
                                         (lambda (_%@9469%_)
                                           gerbil-ascent/table/funs#gerbil-ascent-index-build)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp9623)))
                            (cons '.extend-index!
                                  (let ((__tmp9624
                                         (lambda (_%@9475%_)
                                           gerbil-ascent/table/funs#gerbil-ascent-index-extend!)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp9624)))
                            (cons '.lookup-index
                                  (let ((__tmp9625
                                         (lambda (_%@9480%_)
                                           (lambda (_%index9485%_ _%key9486%_)
                                             (let ((_%$e9510%_
                                                    (let* ((_%h9488%_
                                                            _%index9485%_)
                                                           (_%key9491%_
                                                            _%key9486%_)
                                                           (_%h9495%_
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (cast HashTable::interface
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%h9488%_)))
                   (_%h9497%_ _%h9495%_))
              (declare (not safe))
              (__hash-get _%h9497%_ _%key9491%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (if _%$e9510%_
                                                   _%$e9510%_
                                                   '()))))))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp9625)))))
                     (__tmp9621 (list)))
                 (declare (not safe))
                 (clan/poo/object#object:::init!__%
                  '#f
                  gerbil-ascent/table/provider#IndexProvider.
                  __tmp9622
                  __tmp9621
                  __obj9604))
               __obj9604)))
        (declare (not safe))
        (clan/poo/mop#validate
         gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
         __tmp9620)))
    (define gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider
      gerbil-ascent/table/provider#+canonical-hash-index-provider+)
    (define gerbil-ascent/table/provider#+curried-index-provider+
      (let ((__tmp9626
             (let ((__obj9605
                    (let ()
                      (declare (not safe))
                      (##structure
                       clan/poo/object#object::t
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f))))
               (let ((__tmp9628
                      (list (cons '.build-index
                                  (let ((__tmp9629
                                         (lambda (_%@9413%_)
                                           gerbil-ascent/table/funs#gerbil-ascent-index-build)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp9629)))
                            (cons '.extend-index!
                                  (let ((__tmp9630
                                         (lambda (_%@9419%_)
                                           gerbil-ascent/table/funs#gerbil-ascent-index-extend!)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp9630)))
                            (cons '.lookup-index
                                  (let ((__tmp9631
                                         (lambda (_%@9424%_)
                                           (lambda (_%index9429%_ _%key9430%_)
                                             (let ((_%$e9454%_
                                                    (let* ((_%h9432%_
                                                            _%index9429%_)
                                                           (_%key9435%_
                                                            _%key9430%_)
                                                           (_%h9439%_
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (cast HashTable::interface
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%h9432%_)))
                   (_%h9441%_ _%h9439%_))
              (declare (not safe))
              (__hash-get _%h9441%_ _%key9435%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (if _%$e9454%_
                                                   _%$e9454%_
                                                   '()))))))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp9631)))))
                     (__tmp9627 (list)))
                 (declare (not safe))
                 (clan/poo/object#object:::init!__%
                  '#f
                  gerbil-ascent/table/provider#IndexProvider.
                  __tmp9628
                  __tmp9627
                  __obj9605))
               __obj9605)))
        (declare (not safe))
        (clan/poo/mop#validate
         gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
         __tmp9626)))
    (define gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider
      gerbil-ascent/table/provider#+curried-index-provider+)
    (define gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider?
      (lambda (_%value9398%_)
        (eq? _%value9398%_
             gerbil-ascent/table/provider#+curried-index-provider+)))
    (define gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
      (lambda (_%value9393%_)
        (let ((_%$e9395%_
               (eq? _%value9393%_
                    gerbil-ascent/table/provider#+canonical-hash-index-provider+)))
          (if _%$e9395%_
              _%$e9395%_
              (eq? _%value9393%_
                   gerbil-ascent/table/provider#+curried-index-provider+)))))))
