(declare (block) (standard-bindings) (extended-bindings))
(begin
  (load-module "gerbil-ascent/table/trrel-uf")
  (load-module "gerbil-ascent/table/trrel~0"))
