(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/tools/research/evidence-search::timestamp 1791680664)
  (begin
    (define gerbil-ascent/tools/research/evidence-search#field
      (lambda (_%key3869%_ _%rows3870%_)
        (cadr (assq _%key3869%_ _%rows3870%_))))
    (define gerbil-ascent/tools/research/evidence-search#flat-map
      (lambda (_%f3866%_ _%rows3867%_)
        (apply append (map _%f3866%_ _%rows3867%_))))
    (define gerbil-ascent/tools/research/evidence-search#ordinals
      (let ((_%$%opt-lambda38513856%_
             (lambda (_%n3853%_ _%start3854%_)
               (if (= _%n3853%_ '0)
                   '()
                   (cons _%start3854%_
                         (gerbil-ascent/tools/research/evidence-search#ordinals
                          (- _%n3853%_ '1)
                          (+ _%start3854%_ '1)))))))
        (lambda _g3871_
          (let ((_g3872_ (let () (declare (not safe)) (##length _g3871_))))
            (cond ((let () (declare (not safe)) (##fx= _g3872_ 1))
                   (apply (lambda (_%n3859%_)
                            (let ((_%start3861%_ '0))
                              (_%$%opt-lambda38513856%_
                               _%n3859%_
                               _%start3861%_)))
                          _g3871_))
                  ((let () (declare (not safe)) (##fx= _g3872_ 2))
                   (apply _%$%opt-lambda38513856%_ _g3871_))
                  (else
                   (##raise-wrong-number-of-arguments-exception
                    gerbil-ascent/tools/research/evidence-search#ordinals
                    _g3871_)))))))
    (define gerbil-ascent/tools/research/evidence-search#wire
      (lambda (_%value3847%_)
        (if (symbol? _%value3847%_)
            (symbol->string _%value3847%_)
            (if (pair? _%value3847%_)
                (map gerbil-ascent/tools/research/evidence-search#wire
                     _%value3847%_)
                _%value3847%_))))
    (define gerbil-ascent/tools/research/evidence-search#base-edges
      '((0 2)
        (1 2)
        (2 4)
        (2 5)
        (4 7)
        (5 7)
        (3 6)
        (6 8)
        (7 9)
        (8 9)
        (9 11)
        (10 11)))
    (define gerbil-ascent/tools/research/evidence-search#needs
      '((0 0 7 1 9)
        (1 2 9 3 11)
        (2 4 11 5 9)
        (3 0 11 3 9)
        (4 1 7 6 11)
        (5 2 7 8 11)
        (6 3 8 9 11)
        (7 0 9 10 11)
        (8 0 8 1 7)
        (9 3 7 2 9)
        (10 4 8 5 11)
        (11 10 9 0 7)))
    (define gerbil-ascent/tools/research/evidence-search#proposal
      '(candidate
        (relation path 2)
        (relation ready 1)
        (rule (path ?x ?y) (edge ?x ?y))
        (rule (path ?x ?z) (path ?x ?y) (edge ?y ?z))
        (rule (ready ?f) (need ?f ?u ?v ?x ?y) (path ?u ?v) (path ?x ?y))
        (query ready ?f)
        (limits 128 4096 2048)))
    (define gerbil-ascent/tools/research/evidence-search#make-task
      (lambda (_%number3810%_)
        (if (member _%number3810%_ '(0 1 2))
            '#!void
            (error '"unknown frozen task"))
        (let* ((_%stages3812%_ '7)
               (_%index3814%_ (modulo _%number3810%_ '2))
               (_%edges3819%_
                (let ((_%$e3816%_ _%number3810%_))
                  (if (eq? '1 _%$e3816%_)
                      (append gerbil-ascent/tools/research/evidence-search#base-edges
                              '((4 8)))
                      (if (eq? '2 _%$e3816%_)
                          (append gerbil-ascent/tools/research/evidence-search#base-edges
                                  '((5 8)))
                          gerbil-ascent/tools/research/evidence-search#base-edges))))
               (_%options3828%_
                (gerbil-ascent/tools/research/evidence-search#flat-map
                 (lambda (_%s3821%_)
                   (map (lambda (_%j3823%_)
                          (let ((_%ht3825%_ (make-hash-table 'size: '6)))
                            (hash-put!
                             _%ht3825%_
                             '"id"
                             (+ (* _%s3821%_ '5) _%j3823%_))
                            (hash-put! _%ht3825%_ '"stage" _%s3821%_)
                            (hash-put!
                             _%ht3825%_
                             '"fragment"
                             (if (= _%j3823%_ '3)
                                 (+ '8 (modulo _%s3821%_ '4))
                                 (modulo (+ _%s3821%_ (* '2 _%j3823%_)) '8)))
                            (hash-put!
                             _%ht3825%_
                             '"cost"
                             (if (= _%j3823%_ '0)
                                 '2
                                 (+ '3
                                    (modulo (+ (* _%s3821%_ '3)
                                               (* _%j3823%_ '5)
                                               _%number3810%_)
                                            '10))))
                            (hash-put!
                             _%ht3825%_
                             '"risk"
                             (if (= _%j3823%_ '0)
                                 '1
                                 (+ '1
                                    (modulo (+ (* _%s3821%_ '2)
                                               (* _%j3823%_ '3)
                                               _%number3810%_)
                                            '7))))
                            (hash-put!
                             _%ht3825%_
                             '"values"
                             (if (= _%j3823%_ '0)
                                 (list '10 '11)
                                 (list (+ '13
                                          (modulo (+ (* _%s3821%_ '7)
                                                     (* _%j3823%_ '11)
                                                     (* _%number3810%_ '5))
                                                  '35))
                                       (+ '14
                                          (modulo (+ (* _%s3821%_ '11)
                                                     (* _%j3823%_ '7)
                                                     (* _%number3810%_ '3))
                                                  '35)))))
                            _%ht3825%_))
                        (gerbil-ascent/tools/research/evidence-search#ordinals
                         '5)))
                 (gerbil-ascent/tools/research/evidence-search#ordinals
                  _%stages3812%_)))
               (_%bonuses3834%_
                (gerbil-ascent/tools/research/evidence-search#flat-map
                 (lambda (_%s3830%_)
                   (map (lambda (_%t3832%_)
                          (list (+ (* _%s3830%_ '5)
                                   (modulo (+ _%s3830%_
                                              _%t3832%_
                                              _%number3810%_)
                                           '3))
                                (+ (* _%t3832%_ '5)
                                   (modulo (+ (* '2 _%s3830%_)
                                              _%t3832%_
                                              _%number3810%_
                                              '1)
                                           '3))
                                (+ '8
                                   (modulo (+ (* _%s3830%_ '3)
                                              (* _%t3832%_ '7)
                                              _%number3810%_)
                                           '17))))
                        (gerbil-ascent/tools/research/evidence-search#ordinals
                         (- _%stages3812%_ _%s3830%_ '1)
                         (+ _%s3830%_ '1))))
                 (gerbil-ascent/tools/research/evidence-search#ordinals
                  _%stages3812%_)))
               (_%goal3839%_
                (let ((_%ht3836%_ (make-hash-table 'size: '5)))
                  (hash-put! _%ht3836%_ '"index" _%index3814%_)
                  (hash-put! _%ht3836%_ '"stages" _%stages3812%_)
                  (hash-put! _%ht3836%_ '"costLimit" '45)
                  (hash-put! _%ht3836%_ '"riskLimit" '26)
                  (hash-put! _%ht3836%_ '"bonuses" _%bonuses3834%_)
                  _%ht3836%_))
               (_%ht3842%_ (make-hash-table 'size: '6)))
          (hash-put!
           _%ht3842%_
           '"id"
           (string-append '"evidence-search-" (number->string _%number3810%_)))
          (hash-put! _%ht3842%_ '"edges" _%edges3819%_)
          (hash-put!
           _%ht3842%_
           '"needs"
           gerbil-ascent/tools/research/evidence-search#needs)
          (hash-put! _%ht3842%_ '"options" _%options3828%_)
          (hash-put! _%ht3842%_ '"goal" _%goal3839%_)
          (hash-put!
           _%ht3842%_
           '"seed"
           (map (lambda (_%s3845%_) (* _%s3845%_ '5))
                (gerbil-ascent/tools/research/evidence-search#ordinals
                 _%stages3812%_)))
          _%ht3842%_)))
    (define gerbil-ascent/tools/research/evidence-search#task '#f)
    (define gerbil-ascent/tools/research/evidence-search#source '#f)
    (define gerbil-ascent/tools/research/evidence-search#store '#f)
    (define gerbil-ascent/tools/research/evidence-search#resolved '#f)
    (define gerbil-ascent/tools/research/evidence-search#certificate '#f)
    (define gerbil-ascent/tools/research/evidence-search#arm '#f)
    (define gerbil-ascent/tools/research/evidence-search#frontier '())
    (define gerbil-ascent/tools/research/evidence-search#tried '#f)
    (define gerbil-ascent/tools/research/evidence-search#pending '#f)
    (define gerbil-ascent/tools/research/evidence-search#incumbent '#f)
    (define gerbil-ascent/tools/research/evidence-search#prunings '())
    (define gerbil-ascent/tools/research/evidence-search#expansions '())
    (define gerbil-ascent/tools/research/evidence-search#lifecycle '#f)
    (define gerbil-ascent/tools/research/evidence-search#instant
      (let ((_%$%opt-lambda37953800%_
             (lambda (_%at3797%_ _%domain3798%_)
               (poo-flow/modules/temporal-causality/time/objects#poo-flow-temporal-instant
                (string-append _%domain3798%_ '"/" (number->string _%at3797%_))
                _%domain3798%_
                _%at3797%_
                '"fixture-owner"
                'observed))))
        (lambda _g3873_
          (let ((_g3874_ (let () (declare (not safe)) (##length _g3873_))))
            (cond ((let () (declare (not safe)) (##fx= _g3874_ 1))
                   (apply (lambda (_%at3803%_)
                            (let ((_%domain3805%_ '"txn"))
                              (_%$%opt-lambda37953800%_
                               _%at3803%_
                               _%domain3805%_)))
                          _g3873_))
                  ((let () (declare (not safe)) (##fx= _g3874_ 2))
                   (apply _%$%opt-lambda37953800%_ _g3873_))
                  (else
                   (##raise-wrong-number-of-arguments-exception
                    gerbil-ascent/tools/research/evidence-search#instant
                    _g3873_)))))))
    (define gerbil-ascent/tools/research/evidence-search#edge-id
      (lambda (_%row3794%_)
        (string-append
         '"edge/"
         (number->string (car _%row3794%_))
         '"/"
         (number->string (cadr _%row3794%_)))))
    (define gerbil-ascent/tools/research/evidence-search#atom-id
      (lambda (_%relation3791%_ _%row3792%_)
        (object->string (cons _%relation3791%_ _%row3792%_))))
    (define gerbil-ascent/tools/research/evidence-search#fixture-journal
      (lambda ()
        (let* ((_%valid3778%_
                (poo-flow/modules/temporal-causality/time/objects#poo-flow-temporal-interval
                 '"valid"
                 (gerbil-ascent/tools/research/evidence-search#instant
                  '0
                  '"valid")
                 (gerbil-ascent/tools/research/evidence-search#instant
                  '100
                  '"valid")
                 '#t
                 '#f))
               (_%initial3782%_
                (map (lambda (_%row3780%_)
                       (poo-flow/modules/temporal-causality/revisions/objects#poo-flow-temporal-evidence-revision
                        (string-append
                         (gerbil-ascent/tools/research/evidence-search#edge-id
                          _%row3780%_)
                         '"/assert")
                        (gerbil-ascent/tools/research/evidence-search#edge-id
                         _%row3780%_)
                        'assert
                        '#f
                        (gerbil-ascent/tools/research/evidence-search#instant
                         '10)
                        _%valid3778%_
                        (gerbil-ascent/tools/research/evidence-search#edge-id
                         _%row3780%_)))
                     gerbil-ascent/tools/research/evidence-search#base-edges))
               (_%bridge3784%_
                (poo-flow/modules/temporal-causality/revisions/objects#poo-flow-temporal-evidence-revision
                 '"bridge/assert"
                 '"bridge"
                 'assert
                 '#f
                 (gerbil-ascent/tools/research/evidence-search#instant '10)
                 _%valid3778%_
                 '"edge/4/8"))
               (_%fixed3786%_
                (poo-flow/modules/temporal-causality/revisions/objects#poo-flow-temporal-evidence-revision
                 '"bridge/correct"
                 '"bridge"
                 'correct
                 '"bridge/assert"
                 (gerbil-ascent/tools/research/evidence-search#instant '20)
                 _%valid3778%_
                 '"edge/5/8"))
               (_%withdrawn3788%_
                (poo-flow/modules/temporal-causality/revisions/objects#poo-flow-temporal-evidence-revision
                 '"bridge/retract"
                 '"bridge"
                 'retract
                 '"bridge/correct"
                 (gerbil-ascent/tools/research/evidence-search#instant '30)
                 '#f
                 '#f)))
          (poo-flow/modules/temporal-causality/revisions/funs#poo-flow-temporal-evidence-journal
           '"fixture-history"
           '"txn"
           (append _%initial3782%_
                   (list _%bridge3784%_ _%fixed3786%_ _%withdrawn3788%_))))))
    (define gerbil-ascent/tools/research/evidence-search#project-edges
      (lambda (_%journal3764%_ _%at3765%_)
        (let* ((_%cut3767%_
                (poo-flow/modules/temporal-causality/revisions/funs#poo-flow-temporal-evidence-as-of
                 _%journal3764%_
                 (gerbil-ascent/tools/research/evidence-search#instant
                  _%at3765%_)
                 '#f))
               (_%ids3769%_
                (clan/poo/object#.ref
                 _%cut3767%_
                 'active-revision-identities)))
          (values _%cut3767%_
                  (append (filter (lambda (_%row3772%_)
                                    (member (string-append
                                             (gerbil-ascent/tools/research/evidence-search#edge-id
                                              _%row3772%_)
                                             '"/assert")
                                            _%ids3769%_))
                                  gerbil-ascent/tools/research/evidence-search#base-edges)
                          (if (member '"bridge/assert" _%ids3769%_)
                              '((4 8))
                              (if (member '"bridge/correct" _%ids3769%_)
                                  '((5 8))
                                  '())))))))
    (define gerbil-ascent/tools/research/evidence-search#library-program
      (lambda (_%edges3756%_)
        (let ((_%relations3758%_
               (list (gerbil-ascent/program/scheme-checked#relational-source
                      'edge
                      (length '(from to))
                      _%edges3756%_)
                     (gerbil-ascent/program/scheme-checked#relational-source
                      'need
                      (length '(f u v x y))
                      gerbil-ascent/tools/research/evidence-search#needs)
                     (gerbil-ascent/program/scheme-checked#relational-source
                      'path
                      (length '(from to))
                      '())
                     (gerbil-ascent/program/scheme-checked#relational-source
                      'ready
                      (length '(f))
                      '()))))
          (gerbil-ascent/program/objects#gerbil-ascent-program
           _%relations3758%_
           (list (gerbil-ascent/program/objects#gerbil-ascent-rule
                  (list (gerbil-ascent/program/objects#gerbil-ascent-atom
                         'path
                         (list (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?x)
                               (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?y))))
                  (list (gerbil-ascent/program/objects#gerbil-ascent-atom
                         'edge
                         (list (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?x)
                               (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?y)))))
                 (gerbil-ascent/program/objects#gerbil-ascent-rule
                  (list (gerbil-ascent/program/objects#gerbil-ascent-atom
                         'path
                         (list (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?x)
                               (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?z))))
                  (list (gerbil-ascent/program/objects#gerbil-ascent-atom
                         'path
                         (list (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?x)
                               (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?y)))
                        (gerbil-ascent/program/objects#gerbil-ascent-atom
                         'edge
                         (list (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?y)
                               (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?z)))))
                 (gerbil-ascent/program/objects#gerbil-ascent-rule
                  (list (gerbil-ascent/program/objects#gerbil-ascent-atom
                         'ready
                         (list (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?f))))
                  (list (gerbil-ascent/program/objects#gerbil-ascent-atom
                         'need
                         (list (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?f)
                               (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?u)
                               (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?v)
                               (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?x)
                               (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?y)))
                        (gerbil-ascent/program/objects#gerbil-ascent-atom
                         'path
                         (list (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?u)
                               (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?v)))
                        (gerbil-ascent/program/objects#gerbil-ascent-atom
                         'path
                         (list (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?x)
                               (gerbil-ascent/program/objects#gerbil-ascent-variable
                                '?y))))))
           '128
           '4096
           '2048
           (map (lambda (_%relation3761%_)
                  (clan/poo/object#.ref _%relation3761%_ 'name))
                _%relations3758%_)))))
    (define gerbil-ascent/tools/research/evidence-search#same-rows!
      (lambda (_%a3751%_ _%b3752%_)
        (if (and (= (length _%a3751%_) (length _%b3752%_))
                 (andmap (lambda (_%row3754%_) (member _%row3754%_ _%b3752%_))
                         _%a3751%_))
            '#!void
            (error '"retained Session and independently verified closure disagree"))))
    (define gerbil-ascent/tools/research/evidence-search#dependency-index
      (lambda (_%cut3733%_ _%cert3734%_)
        (let ((_%nodes3736%_
               (gerbil-ascent/tools/research/evidence-search#field
                'nodes
                _%cert3734%_)))
          (poo-flow/modules/temporal-causality/truth-maintenance/funs#poo-flow-temporal-dependency-index
           '"consumer-index"
           (clan/poo/object#.ref _%cut3733%_ 'cut-digest)
           (clan/poo/object#.ref _%cut3733%_ 'projection-digest)
           '#t
           (map (lambda (_%node3738%_)
                  (let* ((_%relation3740%_ (list-ref _%node3738%_ '2))
                         (_%row3742%_ (list-ref _%node3738%_ '3))
                         (_%parents3746%_
                          (map (lambda (_%id3744%_)
                                 (assoc _%id3744%_ _%nodes3736%_))
                               (list-ref _%node3738%_ '5))))
                    (poo-flow/modules/temporal-causality/truth-maintenance/objects#poo-flow-temporal-derivation
                     (gerbil-ascent/tools/research/evidence-search#atom-id
                      _%relation3740%_
                      _%row3742%_)
                     (clan/poo/object#.ref _%cut3733%_ 'cut-digest)
                     (clan/poo/object#.ref _%cut3733%_ 'projection-digest)
                     '"fixture-positive-support"
                     (if (eq? (list-ref _%node3738%_ '1) 'source)
                         (list (if (and (eq? _%relation3740%_ 'edge)
                                        (member _%row3742%_ '((4 8) (5 8))))
                                   '"bridge"
                                   (if (eq? _%relation3740%_ 'edge)
                                       (gerbil-ascent/tools/research/evidence-search#edge-id
                                        _%row3742%_)
                                       (gerbil-ascent/tools/research/evidence-search#atom-id
                                        _%relation3740%_
                                        _%row3742%_))))
                         '())
                     (map (lambda (_%n3749%_)
                            (gerbil-ascent/tools/research/evidence-search#atom-id
                             (list-ref _%n3749%_ '2)
                             (list-ref _%n3749%_ '3)))
                          _%parents3746%_))))
                _%nodes3736%_)))))
    (define gerbil-ascent/tools/research/evidence-search#prepare-library!
      (lambda (_%number3652%_)
        (let* ((_%journal3654%_
                (gerbil-ascent/tools/research/evidence-search#fixture-journal))
               (_%at3659%_
                (let ((_%$e3656%_ _%number3652%_))
                  (if (eq? '0 _%$e3656%_)
                      '35
                      (if (eq? '1 _%$e3656%_) '15 '25))))
               (_%session3661%_ '#f)
               (_%previous-cut3663%_ '#f)
               (_%previous-cert3665%_ '#f)
               (_%records3667%_ '())
               (_%old-source3669%_ '#f)
               (_%old-handle3671%_ '#f))
          (set! gerbil-ascent/tools/research/evidence-search#store
                (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store))
          (for-each
           (lambda (_%position3674%_)
             (let ((_g3875_ (gerbil-ascent/tools/research/evidence-search#project-edges
                             _%journal3654%_
                             _%position3674%_)))
               (begin
                 (let ((_g3876_ (let ()
                                  (declare (not safe))
                                  (if (##values? _g3875_)
                                      (##values-length _g3875_)
                                      1))))
                   (if (not (let () (declare (not safe)) (##fx= _g3876_ 2)))
                       (error "Context expects 2 values" _g3876_)))
                 (let ((_%cut3676%_
                        (let () (declare (not safe)) (##values-ref _g3875_ 0)))
                       (_%edges3677%_
                        (let ()
                          (declare (not safe))
                          (##values-ref _g3875_ 1))))
                   (let* ((_%result3679%_
                           (if _%session3661%_
                               (begin
                                 (gerbil-ascent/program/session#gerbil-ascent-session-replace-source!
                                  _%session3661%_
                                  'edge
                                  _%edges3677%_)
                                 (gerbil-ascent/program/session#gerbil-ascent-session-run
                                  _%session3661%_))
                               (begin
                                 (set! _%session3661%_
                                       (gerbil-ascent/program/session#gerbil-ascent-open-session
                                        (gerbil-ascent/tools/research/evidence-search#library-program
                                         _%edges3677%_)))
                                 (gerbil-ascent/program/session#gerbil-ascent-session-run
                                  _%session3661%_))))
                          (_%plan3681%_
                           (if _%previous-cut3663%_
                               (poo-flow/modules/temporal-causality/truth-maintenance/funs#poo-flow-temporal-reverse-dependency-plan-from-cuts
                                (gerbil-ascent/tools/research/evidence-search#dependency-index
                                 _%previous-cut3663%_
                                 _%previous-cert3665%_)
                                _%journal3654%_
                                (gerbil-ascent/tools/research/evidence-search#instant
                                 (- _%position3674%_ '10))
                                (gerbil-ascent/tools/research/evidence-search#instant
                                 _%position3674%_)
                                '#f)
                               '#f)))
                     (if (clan/poo/object#.ref _%result3679%_ 'finished)
                         '#!void
                         (error '"incomplete retained Session"))
                     (set! gerbil-ascent/tools/research/evidence-search#source
                           (gerbil-ascent/candidate/reasoning#reasoning-source-snapshot
                            (string-append
                             (let* ((_%h3684%_
                                     gerbil-ascent/tools/research/evidence-search#task)
                                    (_%key3687%_ '"id")
                                    (_%default3690%_ absent-obj)
                                    (_%h3694%_
                                     (cast HashTable::interface _%h3684%_))
                                    (_%h3696%_ _%h3694%_))
                               (__hash-ref
                                _%h3696%_
                                _%key3687%_
                                _%default3690%_))
                             '"/"
                             (clan/poo/object#.ref
                              _%cut3676%_
                              'projection-digest))
                            _%position3674%_
                            (list (list 'edge '2 _%edges3677%_)
                                  (list 'need
                                        '5
                                        gerbil-ascent/tools/research/evidence-search#needs))))
                     (set! gerbil-ascent/tools/research/evidence-search#resolved
                           (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
                            gerbil-ascent/tools/research/evidence-search#store
                            gerbil-ascent/tools/research/evidence-search#source
                            gerbil-ascent/tools/research/evidence-search#proposal))
                     (if (eq? (gerbil-ascent/tools/research/evidence-search#field
                               'status
                               gerbil-ascent/tools/research/evidence-search#resolved)
                              'verified)
                         '#!void
                         (error '"proof not admitted"))
                     (set! gerbil-ascent/tools/research/evidence-search#certificate
                           (gerbil-ascent/candidate/evidence-store#reasoning-evidence-certificate
                            gerbil-ascent/tools/research/evidence-search#store
                            gerbil-ascent/tools/research/evidence-search#source
                            gerbil-ascent/tools/research/evidence-search#proposal
                            (gerbil-ascent/tools/research/evidence-search#field
                             'handle
                             gerbil-ascent/tools/research/evidence-search#resolved)))
                     (gerbil-ascent/tools/research/evidence-search#same-rows!
                      ((clan/poo/object#.ref _%result3679%_ 'rows-of) 'ready)
                      (gerbil-ascent/tools/research/evidence-search#field
                       'rows
                       gerbil-ascent/tools/research/evidence-search#resolved))
                     (for-each
                      (lambda (_%row3723%_)
                        (if (eq? (gerbil-ascent/tools/research/evidence-search#field
                                  'status
                                  (gerbil-ascent/candidate/evidence-store#reasoning-evidence-fact
                                   gerbil-ascent/tools/research/evidence-search#store
                                   gerbil-ascent/tools/research/evidence-search#source
                                   gerbil-ascent/tools/research/evidence-search#proposal
                                   (gerbil-ascent/tools/research/evidence-search#field
                                    'handle
                                    gerbil-ascent/tools/research/evidence-search#resolved)
                                   (cons 'path _%row3723%_)))
                                 'verified)
                            '#!void
                            (error '"Session path lacks finite verification")))
                      ((clan/poo/object#.ref _%result3679%_ 'rows-of) 'path))
                     (if _%old-source3669%_
                         (begin
                           (if (eq? (gerbil-ascent/tools/research/evidence-search#field
                                     'status
                                     (gerbil-ascent/candidate/evidence-store#reasoning-evidence-fact
                                      gerbil-ascent/tools/research/evidence-search#store
                                      gerbil-ascent/tools/research/evidence-search#source
                                      gerbil-ascent/tools/research/evidence-search#proposal
                                      _%old-handle3671%_
                                      '(path 0 8)))
                                    'unknown)
                               '#!void
                               (error '"old proof handle accepted for revised scope"))
                           (if (eq? (gerbil-ascent/tools/research/evidence-search#field
                                     'status
                                     (gerbil-ascent/candidate/evidence-store#reasoning-evidence-fact
                                      gerbil-ascent/tools/research/evidence-search#store
                                      _%old-source3669%_
                                      gerbil-ascent/tools/research/evidence-search#proposal
                                      _%old-handle3671%_
                                      '(path 0 8)))
                                    'verified)
                               '#!void
                               (error '"historical evidence lost")))
                         '#!void)
                     (if _%plan3681%_
                         (begin
                           (if (member (gerbil-ascent/tools/research/evidence-search#atom-id
                                        'path
                                        '(0 8))
                                       (clan/poo/object#.ref
                                        _%plan3681%_
                                        'affected-conclusion-identities))
                               '#!void
                               (error '"POO plan omitted revised derivation"))
                           (if (member (gerbil-ascent/tools/research/evidence-search#atom-id
                                        'path
                                        '(3 11))
                                       (clan/poo/object#.ref
                                        _%plan3681%_
                                        'affected-conclusion-identities))
                               (error '"unrelated derivation incorrectly affected")
                               '#!void))
                         '#!void)
                     (set! _%records3667%_
                           (cons (let ((_%ht3725%_
                                        (make-hash-table 'size: '11)))
                                   (hash-put!
                                    _%ht3725%_
                                    '"knowledgeAt"
                                    _%position3674%_)
                                   (hash-put!
                                    _%ht3725%_
                                    '"cutDigest"
                                    (clan/poo/object#.ref
                                     _%cut3676%_
                                     'cut-digest))
                                   (hash-put!
                                    _%ht3725%_
                                    '"projectionDigest"
                                    (clan/poo/object#.ref
                                     _%cut3676%_
                                     'projection-digest))
                                   (hash-put!
                                    _%ht3725%_
                                    '"edges"
                                    _%edges3677%_)
                                   (hash-put!
                                    _%ht3725%_
                                    '"sessionReady"
                                    ((clan/poo/object#.ref
                                      _%result3679%_
                                      'rows-of)
                                     'ready))
                                   (hash-put!
                                    _%ht3725%_
                                    '"sessionPaths"
                                    ((clan/poo/object#.ref
                                      _%result3679%_
                                      'rows-of)
                                     'path))
                                   (hash-put!
                                    _%ht3725%_
                                    '"activeRules"
                                    (clan/poo/object#.ref
                                     _%result3679%_
                                     'active-rule-count))
                                   (hash-put!
                                    _%ht3725%_
                                    '"changedSubjects"
                                    (if _%plan3681%_
                                        (clan/poo/object#.ref
                                         _%plan3681%_
                                         'changed-subject-identities)
                                        '()))
                                   (hash-put!
                                    _%ht3725%_
                                    '"affectedDerivations"
                                    (if _%plan3681%_
                                        (clan/poo/object#.ref
                                         _%plan3681%_
                                         'affected-conclusion-identities)
                                        '()))
                                   (hash-put!
                                    _%ht3725%_
                                    '"certificate"
                                    (gerbil-ascent/tools/research/evidence-search#wire
                                     gerbil-ascent/tools/research/evidence-search#certificate))
                                   (hash-put!
                                    _%ht3725%_
                                    '"staleHandleRejected"
                                    (if _%old-source3669%_ '#t '#f))
                                   _%ht3725%_)
                                 _%records3667%_))
                     (set! _%previous-cut3663%_ _%cut3676%_)
                     (set! _%previous-cert3665%_
                           gerbil-ascent/tools/research/evidence-search#certificate)
                     (set! _%old-source3669%_
                           gerbil-ascent/tools/research/evidence-search#source)
                     (set! _%old-handle3671%_
                           (gerbil-ascent/tools/research/evidence-search#field
                            'handle
                            gerbil-ascent/tools/research/evidence-search#resolved)))))))
           (filter (lambda (_%p3728%_) (<= _%p3728%_ _%at3659%_)) '(15 25 35)))
          (set! gerbil-ascent/tools/research/evidence-search#lifecycle
                (let ((_%ht3730%_ (make-hash-table 'size: '3)))
                  (hash-put! _%ht3730%_ '"records" (reverse _%records3667%_))
                  (hash-put! _%ht3730%_ '"currentKnowledgeAt" _%at3659%_)
                  (hash-put!
                   _%ht3730%_
                   '"ownership"
                   '"Synthetic consumer fixture. POO Flow selects revisions and schedules reevaluation; ASCENT retained Session computes relations; proof store independently verifies current finite results.")
                  _%ht3730%_)))))
    (define gerbil-ascent/tools/research/evidence-search#fact
      (lambda (_%atom3650%_)
        (gerbil-ascent/candidate/evidence-store#reasoning-evidence-fact
         gerbil-ascent/tools/research/evidence-search#store
         gerbil-ascent/tools/research/evidence-search#source
         gerbil-ascent/tools/research/evidence-search#proposal
         (gerbil-ascent/tools/research/evidence-search#field
          'handle
          gerbil-ascent/tools/research/evidence-search#resolved)
         _%atom3650%_)))
    (define gerbil-ascent/tools/research/evidence-search#check
      (lambda (_%selection3315%_ _%full?3316%_)
        (let* ((_%options3343%_
                (let* ((_%h3318%_
                        gerbil-ascent/tools/research/evidence-search#task)
                       (_%key3321%_ '"options")
                       (_%default3324%_ absent-obj)
                       (_%h3328%_ (cast HashTable::interface _%h3318%_))
                       (_%h3330%_ _%h3328%_))
                  (__hash-ref _%h3330%_ _%key3321%_ _%default3324%_)))
               (_%goal3370%_
                (let* ((_%h3345%_
                        gerbil-ascent/tools/research/evidence-search#task)
                       (_%key3348%_ '"goal")
                       (_%default3351%_ absent-obj)
                       (_%h3355%_ (cast HashTable::interface _%h3345%_))
                       (_%h3357%_ _%h3355%_))
                  (__hash-ref _%h3357%_ _%key3348%_ _%default3351%_)))
               (_%stages3397%_
                (let* ((_%h3372%_ _%goal3370%_)
                       (_%key3375%_ '"stages")
                       (_%default3378%_ absent-obj)
                       (_%h3382%_ (cast HashTable::interface _%h3372%_))
                       (_%h3384%_ _%h3382%_))
                  (__hash-ref _%h3384%_ _%key3375%_ _%default3378%_)))
               (_%cost3399%_ '0)
               (_%risk3401%_ '0)
               (_%value3403%_ '0)
               (_%valid3405%_ '#t)
               (_%stage3407%_ '0))
          (if (and (list? _%selection3315%_)
                   (<= (length _%selection3315%_) _%stages3397%_)
                   (or (not _%full?3316%_)
                       (= (length _%selection3315%_) _%stages3397%_))
                   (andmap (lambda (_%id3413%_)
                             (and (exact-integer? _%id3413%_)
                                  (<= '0 _%id3413%_)
                                  (< _%id3413%_ (length _%options3343%_))))
                           _%selection3315%_))
              '#!void
              (error '"invalid selection shape"))
          (for-each
           (lambda (_%id3415%_)
             (let ((_%o3417%_ (list-ref _%options3343%_ _%id3415%_)))
               (if (and (= _%stage3407%_
                           (let* ((_%h3419%_ _%o3417%_)
                                  (_%key3422%_ '"stage")
                                  (_%default3425%_ absent-obj)
                                  (_%h3429%_
                                   (cast HashTable::interface _%h3419%_))
                                  (_%h3431%_ _%h3429%_))
                             (__hash-ref
                              _%h3431%_
                              _%key3422%_
                              _%default3425%_)))
                        (eq? (gerbil-ascent/tools/research/evidence-search#field
                              'status
                              (gerbil-ascent/tools/research/evidence-search#fact
                               (list 'ready
                                     (let* ((_%h3452%_ _%o3417%_)
                                            (_%key3455%_ '"fragment")
                                            (_%default3458%_ absent-obj)
                                            (_%h3462%_
                                             (cast HashTable::interface
                                                   _%h3452%_))
                                            (_%h3464%_ _%h3462%_))
                                       (__hash-ref
                                        _%h3464%_
                                        _%key3455%_
                                        _%default3458%_)))))
                             'verified))
                   '#!void
                   (set! _%valid3405%_ '#f))
               (set! _%cost3399%_
                     (+ _%cost3399%_
                        (let* ((_%h3476%_ _%o3417%_)
                               (_%key3479%_ '"cost")
                               (_%default3482%_ absent-obj)
                               (_%h3486%_
                                (cast HashTable::interface _%h3476%_))
                               (_%h3488%_ _%h3486%_))
                          (__hash-ref _%h3488%_ _%key3479%_ _%default3482%_))))
               (set! _%risk3401%_
                     (+ _%risk3401%_
                        (let* ((_%h3500%_ _%o3417%_)
                               (_%key3503%_ '"risk")
                               (_%default3506%_ absent-obj)
                               (_%h3510%_
                                (cast HashTable::interface _%h3500%_))
                               (_%h3512%_ _%h3510%_))
                          (__hash-ref _%h3512%_ _%key3503%_ _%default3506%_))))
               (set! _%value3403%_
                     (+ _%value3403%_
                        (list-ref
                         (let* ((_%h3524%_ _%o3417%_)
                                (_%key3527%_ '"values")
                                (_%default3530%_ absent-obj)
                                (_%h3534%_
                                 (cast HashTable::interface _%h3524%_))
                                (_%h3536%_ _%h3534%_))
                           (__hash-ref _%h3536%_ _%key3527%_ _%default3530%_))
                         (let* ((_%h3548%_ _%goal3370%_)
                                (_%key3551%_ '"index")
                                (_%default3554%_ absent-obj)
                                (_%h3558%_
                                 (cast HashTable::interface _%h3548%_))
                                (_%h3560%_ _%h3558%_))
                           (__hash-ref
                            _%h3560%_
                            _%key3551%_
                            _%default3554%_)))))
               (set! _%stage3407%_ (+ _%stage3407%_ '1))))
           _%selection3315%_)
          (for-each
           (lambda (_%b3572%_)
             (if (and (member (car _%b3572%_) _%selection3315%_)
                      (member (cadr _%b3572%_) _%selection3315%_))
                 (set! _%value3403%_ (+ _%value3403%_ (caddr _%b3572%_)))
                 '#!void))
           (let* ((_%h3574%_ _%goal3370%_)
                  (_%key3577%_ '"bonuses")
                  (_%default3580%_ absent-obj)
                  (_%h3584%_ (cast HashTable::interface _%h3574%_))
                  (_%h3586%_ _%h3584%_))
             (__hash-ref _%h3586%_ _%key3577%_ _%default3580%_)))
          (let ((_%ht3598%_ (make-hash-table 'size: '5)))
            (hash-put!
             _%ht3598%_
             '"valid"
             (if _%valid3405%_
                 (if (<= _%cost3399%_
                         (let* ((_%h3601%_ _%goal3370%_)
                                (_%key3604%_ '"costLimit")
                                (_%default3607%_ absent-obj)
                                (_%h3611%_
                                 (cast HashTable::interface _%h3601%_))
                                (_%h3613%_ _%h3611%_))
                           (__hash-ref _%h3613%_ _%key3604%_ _%default3607%_)))
                     (<= _%risk3401%_
                         (let* ((_%h3626%_ _%goal3370%_)
                                (_%key3629%_ '"riskLimit")
                                (_%default3632%_ absent-obj)
                                (_%h3636%_
                                 (cast HashTable::interface _%h3626%_))
                                (_%h3638%_ _%h3636%_))
                           (__hash-ref _%h3638%_ _%key3629%_ _%default3632%_)))
                     '#f)
                 '#f))
            (hash-put! _%ht3598%_ '"depth" (length _%selection3315%_))
            (hash-put! _%ht3598%_ '"cost" _%cost3399%_)
            (hash-put! _%ht3598%_ '"risk" _%risk3401%_)
            (hash-put! _%ht3598%_ '"value" _%value3403%_)
            _%ht3598%_))))
    (define gerbil-ascent/tools/research/evidence-search#totals
      (lambda (_%checked3212%_)
        (let ((_%ht3214%_ (make-hash-table 'size: '4)))
          (hash-put!
           _%ht3214%_
           '"depth"
           (let* ((_%h3217%_ _%checked3212%_)
                  (_%key3220%_ '"depth")
                  (_%default3223%_ absent-obj)
                  (_%h3227%_ (cast HashTable::interface _%h3217%_))
                  (_%h3229%_ _%h3227%_))
             (__hash-ref _%h3229%_ _%key3220%_ _%default3223%_)))
          (hash-put!
           _%ht3214%_
           '"cost"
           (let* ((_%h3243%_ _%checked3212%_)
                  (_%key3246%_ '"cost")
                  (_%default3249%_ absent-obj)
                  (_%h3253%_ (cast HashTable::interface _%h3243%_))
                  (_%h3255%_ _%h3253%_))
             (__hash-ref _%h3255%_ _%key3246%_ _%default3249%_)))
          (hash-put!
           _%ht3214%_
           '"risk"
           (let* ((_%h3267%_ _%checked3212%_)
                  (_%key3270%_ '"risk")
                  (_%default3273%_ absent-obj)
                  (_%h3277%_ (cast HashTable::interface _%h3267%_))
                  (_%h3279%_ _%h3277%_))
             (__hash-ref _%h3279%_ _%key3270%_ _%default3273%_)))
          (hash-put!
           _%ht3214%_
           '"value"
           (let* ((_%h3291%_ _%checked3212%_)
                  (_%key3294%_ '"value")
                  (_%default3297%_ absent-obj)
                  (_%h3301%_ (cast HashTable::interface _%h3291%_))
                  (_%h3303%_ _%h3301%_))
             (__hash-ref _%h3303%_ _%key3294%_ _%default3297%_)))
          _%ht3214%_)))
    (define gerbil-ascent/tools/research/evidence-search#complete
      (lambda (_%prefix3185%_)
        (append _%prefix3185%_
                (list-tail
                 (let* ((_%h3187%_
                         gerbil-ascent/tools/research/evidence-search#task)
                        (_%key3190%_ '"seed")
                        (_%default3193%_ absent-obj)
                        (_%h3197%_ (cast HashTable::interface _%h3187%_))
                        (_%h3199%_ _%h3197%_))
                   (__hash-ref _%h3199%_ _%key3190%_ _%default3193%_))
                 (length _%prefix3185%_)))))
    (define gerbil-ascent/tools/research/evidence-search#mark!
      (lambda (_%parent3133%_ _%ids3134%_)
        (let* ((_%h3136%_ gerbil-ascent/tools/research/evidence-search#tried)
               (_%key3139%_ _%parent3133%_)
               (_%value3169%_
                (append (let* ((_%h3142%_
                                gerbil-ascent/tools/research/evidence-search#tried)
                               (_%key3145%_ _%parent3133%_)
                               (_%default3148%_ '())
                               (_%h3152%_
                                (cast HashTable::interface _%h3142%_))
                               (_%h3154%_ _%h3152%_))
                          (__hash-ref _%h3154%_ _%key3145%_ _%default3148%_))
                        _%ids3134%_))
               (_%h3173%_ (cast HashTable::interface _%h3136%_))
               (_%h3175%_ _%h3173%_))
          (__hash-put! _%h3175%_ _%key3139%_ _%value3169%_))))
    (define gerbil-ascent/tools/research/evidence-search#fact-packet
      (lambda (_%ids3042%_)
        (let ((_%seen3044%_ '())
              (_%facts3045%_ '())
              (_%roots3046%_ '())
              (_%nodes3047%_
               (gerbil-ascent/tools/research/evidence-search#field
                'nodes
                gerbil-ascent/tools/research/evidence-search#certificate)))
          (letrec ((_%add-node!3049%_
                    (lambda (_%id3129%_)
                      (if (member _%id3129%_ _%roots3046%_)
                          '#!void
                          (let ((_%node3131%_
                                 (assoc _%id3129%_ _%nodes3047%_)))
                            (if _%node3131%_
                                '#!void
                                (error '"missing admitted support node"
                                       _%id3129%_))
                            (set! _%roots3046%_
                                  (cons _%id3129%_ _%roots3046%_))
                            (for-each
                             _%add-node!3049%_
                             (list-ref _%node3131%_ '5)))))))
            (for-each
             (lambda (_%id3051%_)
               (let ((_%f3105%_
                      (let* ((_%h3081%_
                              (list-ref
                               (let* ((_%h3053%_
                                       gerbil-ascent/tools/research/evidence-search#task)
                                      (_%key3056%_ '"options")
                                      (_%default3059%_ absent-obj)
                                      (_%h3063%_
                                       (cast HashTable::interface _%h3053%_))
                                      (_%h3065%_ _%h3063%_))
                                 (__hash-ref
                                  _%h3065%_
                                  _%key3056%_
                                  _%default3059%_))
                               _%id3051%_))
                             (_%key3084%_ '"fragment")
                             (_%default3087%_ absent-obj)
                             (_%h3091%_ (cast HashTable::interface _%h3081%_))
                             (_%h3093%_ _%h3091%_))
                        (__hash-ref _%h3093%_ _%key3084%_ _%default3087%_))))
                 (if (member _%f3105%_ _%seen3044%_)
                     '#!void
                     (begin
                       (set! _%seen3044%_ (cons _%f3105%_ _%seen3044%_))
                       (let* ((_%ready3107%_
                               (gerbil-ascent/tools/research/evidence-search#fact
                                (list 'ready _%f3105%_)))
                              (_%n3109%_
                               (assoc _%f3105%_
                                      gerbil-ascent/tools/research/evidence-search#needs))
                              (_%requirements3118%_
                               (map (lambda (_%atom3111%_)
                                      (let ((_%answer3113%_
                                             (gerbil-ascent/tools/research/evidence-search#fact
                                              _%atom3111%_)))
                                        (for-each
                                         _%add-node!3049%_
                                         (gerbil-ascent/tools/research/evidence-search#field
                                          'support-nodes
                                          _%answer3113%_))
                                        (let ((_%ht3115%_
                                               (make-hash-table 'size: '3)))
                                          (hash-put!
                                           _%ht3115%_
                                           '"atom"
                                           (gerbil-ascent/tools/research/evidence-search#wire
                                            _%atom3111%_))
                                          (hash-put!
                                           _%ht3115%_
                                           '"status"
                                           (gerbil-ascent/tools/research/evidence-search#wire
                                            (gerbil-ascent/tools/research/evidence-search#field
                                             'status
                                             _%answer3113%_)))
                                          (hash-put!
                                           _%ht3115%_
                                           '"supportNodes"
                                           (gerbil-ascent/tools/research/evidence-search#field
                                            'support-nodes
                                            _%answer3113%_))
                                          _%ht3115%_)))
                                    (list (list 'path
                                                (list-ref _%n3109%_ '1)
                                                (list-ref _%n3109%_ '2))
                                          (list 'path
                                                (list-ref _%n3109%_ '3)
                                                (list-ref _%n3109%_ '4))))))
                         (for-each
                          _%add-node!3049%_
                          (gerbil-ascent/tools/research/evidence-search#field
                           'support-nodes
                           _%ready3107%_))
                         (set! _%facts3045%_
                               (cons (let ((_%ht3121%_
                                            (make-hash-table 'size: '4)))
                                       (hash-put!
                                        _%ht3121%_
                                        '"fragmentId"
                                        _%f3105%_)
                                       (hash-put!
                                        _%ht3121%_
                                        '"status"
                                        (gerbil-ascent/tools/research/evidence-search#wire
                                         (gerbil-ascent/tools/research/evidence-search#field
                                          'status
                                          _%ready3107%_)))
                                       (hash-put!
                                        _%ht3121%_
                                        '"requirements"
                                        _%requirements3118%_)
                                       (hash-put!
                                        _%ht3121%_
                                        '"supportNodes"
                                        (gerbil-ascent/tools/research/evidence-search#field
                                         'support-nodes
                                         _%ready3107%_))
                                       _%ht3121%_)
                                     _%facts3045%_)))))))
             _%ids3042%_)
            (let ((_%ht3124%_ (make-hash-table 'size: '4)))
              (hash-put!
               _%ht3124%_
               '"handle"
               (gerbil-ascent/tools/research/evidence-search#field
                'handle
                gerbil-ascent/tools/research/evidence-search#resolved))
              (hash-put!
               _%ht3124%_
               '"scope"
               (gerbil-ascent/tools/research/evidence-search#wire
                (gerbil-ascent/tools/research/evidence-search#field
                 'scope
                 gerbil-ascent/tools/research/evidence-search#resolved)))
              (hash-put! _%ht3124%_ '"facts" (reverse _%facts3045%_))
              (hash-put!
               _%ht3124%_
               '"proofNodes"
               (gerbil-ascent/tools/research/evidence-search#wire
                (filter (lambda (_%n3127%_)
                          (member (car _%n3127%_) _%roots3046%_))
                        _%nodes3047%_)))
              _%ht3124%_)))))
    (define gerbil-ascent/tools/research/evidence-search#next-context
      (lambda ()
        (set! gerbil-ascent/tools/research/evidence-search#resolved
              (gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
               gerbil-ascent/tools/research/evidence-search#store
               gerbil-ascent/tools/research/evidence-search#source
               gerbil-ascent/tools/research/evidence-search#proposal))
        (if (eq? (gerbil-ascent/tools/research/evidence-search#field
                  'status
                  gerbil-ascent/tools/research/evidence-search#resolved)
                 'verified)
            '#!void
            (error '"unverified scenario source"))
        (let _%loop2610%_ ()
          (if (null? gerbil-ascent/tools/research/evidence-search#frontier)
              (let ((_%ht2613%_ (make-hash-table 'size: '1)))
                (hash-put! _%ht2613%_ '"done" '#t)
                _%ht2613%_)
              (let* ((_%parent2616%_
                      (car gerbil-ascent/tools/research/evidence-search#frontier))
                     (_%ids2748%_
                      (map (lambda (_%o2618%_)
                             (let* ((_%h2620%_ _%o2618%_)
                                    (_%key2623%_ '"id")
                                    (_%default2626%_ absent-obj)
                                    (_%h2630%_
                                     (cast HashTable::interface _%h2620%_))
                                    (_%h2632%_ _%h2630%_))
                               (__hash-ref
                                _%h2632%_
                                _%key2623%_
                                _%default2626%_)))
                           (filter (lambda (_%o2649%_)
                                     (if (= (let* ((_%h2651%_ _%o2649%_)
                                                   (_%key2654%_ '"stage")
                                                   (_%default2657%_ absent-obj)
                                                   (_%h2661%_
                                                    (cast HashTable::interface
                                                          _%h2651%_))
                                                   (_%h2663%_ _%h2661%_))
                                              (__hash-ref
                                               _%h2663%_
                                               _%key2654%_
                                               _%default2657%_))
                                            (length _%parent2616%_))
                                         (not (member (let* ((_%h2676%_
                                                              _%o2649%_)
                                                             (_%key2679%_
                                                              '"id")
                                                             (_%default2682%_
                                                              absent-obj)
                                                             (_%h2686%_
                                                              (cast HashTable::interface
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%h2676%_))
                     (_%h2688%_ _%h2686%_))
                (__hash-ref _%h2688%_ _%key2679%_ _%default2682%_))
              (let* ((_%h2700%_
                      gerbil-ascent/tools/research/evidence-search#tried)
                     (_%key2703%_ _%parent2616%_)
                     (_%default2706%_ '())
                     (_%h2710%_ (cast HashTable::interface _%h2700%_))
                     (_%h2712%_ _%h2710%_))
                (__hash-ref _%h2712%_ _%key2703%_ _%default2706%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                         '#f))
                                   (let* ((_%h2724%_
                                           gerbil-ascent/tools/research/evidence-search#task)
                                          (_%key2727%_ '"options")
                                          (_%default2730%_ absent-obj)
                                          (_%h2734%_
                                           (cast HashTable::interface
                                                 _%h2724%_))
                                          (_%h2736%_ _%h2734%_))
                                     (__hash-ref
                                      _%h2736%_
                                      _%key2727%_
                                      _%default2730%_)))))
                     (_%partition2802%_
                      (if (string=?
                           gerbil-ascent/tools/research/evidence-search#arm
                           '"prune")
                          (gerbil-ascent/candidate/evidence-store#reasoning-evidence-partition
                           gerbil-ascent/tools/research/evidence-search#store
                           gerbil-ascent/tools/research/evidence-search#source
                           gerbil-ascent/tools/research/evidence-search#proposal
                           (gerbil-ascent/tools/research/evidence-search#field
                            'handle
                            gerbil-ascent/tools/research/evidence-search#resolved)
                           (map (lambda (_%id2750%_)
                                  (list _%id2750%_
                                        (list (list 'ready
                                                    (let* ((_%h2778%_
                                                            (list-ref
                                                             (let* ((_%h2752%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             gerbil-ascent/tools/research/evidence-search#task)
                            (_%key2755%_ '"options")
                            (_%default2758%_ absent-obj)
                            (_%h2762%_ (cast HashTable::interface _%h2752%_))
                            (_%h2764%_ _%h2762%_))
                       (__hash-ref _%h2764%_ _%key2755%_ _%default2758%_))
                     _%id2750%_))
                   (_%key2781%_ '"fragment")
                   (_%default2784%_ absent-obj)
                   (_%h2788%_ (cast HashTable::interface _%h2778%_))
                   (_%h2790%_ _%h2788%_))
              (__hash-ref _%h2790%_ _%key2781%_ _%default2784%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                _%ids2748%_))
                          '#f))
                     (_%allowed2804%_
                      (if _%partition2802%_
                          (gerbil-ascent/tools/research/evidence-search#field
                           'allowed
                           _%partition2802%_)
                          _%ids2748%_))
                     (_%removed2806%_
                      (if _%partition2802%_
                          (gerbil-ascent/tools/research/evidence-search#field
                           'pruned
                           _%partition2802%_)
                          '())))
                (if (pair? _%removed2806%_)
                    (begin
                      (gerbil-ascent/tools/research/evidence-search#mark!
                       _%parent2616%_
                       _%removed2806%_)
                      (set! gerbil-ascent/tools/research/evidence-search#prunings
                            (cons (list _%parent2616%_
                                        (gerbil-ascent/tools/research/evidence-search#wire
                                         _%partition2802%_))
                                  gerbil-ascent/tools/research/evidence-search#prunings)))
                    '#!void)
                (if (null? _%allowed2804%_)
                    (begin
                      (set! gerbil-ascent/tools/research/evidence-search#frontier
                            (cdr gerbil-ascent/tools/research/evidence-search#frontier))
                      (_%loop2610%_))
                    (let* ((_%children2847%_
                            (map (lambda (_%id2809%_)
                                   (let* ((_%prefix2811%_
                                           (append _%parent2616%_
                                                   (list _%id2809%_)))
                                          (_%ht2813%_
                                           (make-hash-table 'size: '3)))
                                     (hash-put!
                                      _%ht2813%_
                                      '"option"
                                      (list-ref
                                       (let* ((_%h2816%_
                                               gerbil-ascent/tools/research/evidence-search#task)
                                              (_%key2819%_ '"options")
                                              (_%default2822%_ absent-obj)
                                              (_%h2826%_
                                               (cast HashTable::interface
                                                     _%h2816%_))
                                              (_%h2828%_ _%h2826%_))
                                         (__hash-ref
                                          _%h2828%_
                                          _%key2819%_
                                          _%default2822%_))
                                       _%id2809%_))
                                     (hash-put!
                                      _%ht2813%_
                                      '"prefixTotals"
                                      (gerbil-ascent/tools/research/evidence-search#totals
                                       (gerbil-ascent/tools/research/evidence-search#check
                                        _%prefix2811%_
                                        '#f)))
                                     (hash-put!
                                      _%ht2813%_
                                      '"seedSuffixTotals"
                                      (gerbil-ascent/tools/research/evidence-search#totals
                                       (gerbil-ascent/tools/research/evidence-search#check
                                        (gerbil-ascent/tools/research/evidence-search#complete
                                         _%prefix2811%_)
                                        '#t)))
                                     _%ht2813%_))
                                 _%allowed2804%_))
                           (_%context3010%_
                            (let ((_%ht2849%_ (make-hash-table 'size: '5)))
                              (hash-put!
                               _%ht2849%_
                               '"task"
                               (let ((_%ht2852%_ (make-hash-table 'size: '5)))
                                 (hash-put!
                                  _%ht2852%_
                                  '"objective"
                                  '"Maximize the value of a feasible complete selection.")
                                 (hash-put!
                                  _%ht2852%_
                                  '"selectionContract"
                                  '"One option per stage, in stage order. Each option requires both directed paths in its fragment; paths have at least one edge. Costs and risks add. Value is the current goal's option values plus bonuses for selected pairs.")
                                 (hash-put!
                                  _%ht2852%_
                                  '"source"
                                  (let ((_%ht2855%_
                                         (make-hash-table 'size: '3)))
                                    (hash-put!
                                     _%ht2855%_
                                     '"edges"
                                     (let* ((_%h2858%_
                                             gerbil-ascent/tools/research/evidence-search#task)
                                            (_%key2861%_ '"edges")
                                            (_%default2864%_ absent-obj)
                                            (_%h2868%_
                                             (cast HashTable::interface
                                                   _%h2858%_))
                                            (_%h2870%_ _%h2868%_))
                                       (__hash-ref
                                        _%h2870%_
                                        _%key2861%_
                                        _%default2864%_)))
                                    (hash-put!
                                     _%ht2855%_
                                     '"needs"
                                     gerbil-ascent/tools/research/evidence-search#needs)
                                    (hash-put!
                                     _%ht2855%_
                                     '"needsColumns"
                                     '("fragmentId"
                                       "firstFrom"
                                       "firstTo"
                                       "secondFrom"
                                       "secondTo"))
                                    _%ht2855%_))
                                 (hash-put!
                                  _%ht2852%_
                                  '"goal"
                                  (let* ((_%h2886%_
                                          gerbil-ascent/tools/research/evidence-search#task)
                                         (_%key2889%_ '"goal")
                                         (_%default2892%_ absent-obj)
                                         (_%h2896%_
                                          (cast HashTable::interface
                                                _%h2886%_))
                                         (_%h2898%_ _%h2896%_))
                                    (__hash-ref
                                     _%h2898%_
                                     _%key2889%_
                                     _%default2892%_)))
                                 (hash-put!
                                  _%ht2852%_
                                  '"options"
                                  (let* ((_%h2910%_
                                          gerbil-ascent/tools/research/evidence-search#task)
                                         (_%key2913%_ '"options")
                                         (_%default2916%_ absent-obj)
                                         (_%h2920%_
                                          (cast HashTable::interface
                                                _%h2910%_))
                                         (_%h2922%_ _%h2920%_))
                                    (__hash-ref
                                     _%h2922%_
                                     _%key2913%_
                                     _%default2916%_)))
                                 _%ht2852%_))
                              (hash-put! _%ht2849%_ '"parent" _%parent2616%_)
                              (hash-put!
                               _%ht2849%_
                               '"unvisitedChildren"
                               _%children2847%_)
                              (hash-put!
                               _%ht2849%_
                               '"commonSeed"
                               (let* ((_%h2934%_
                                       gerbil-ascent/tools/research/evidence-search#task)
                                      (_%key2937%_ '"seed")
                                      (_%default2940%_ absent-obj)
                                      (_%h2944%_
                                       (cast HashTable::interface _%h2934%_))
                                      (_%h2946%_ _%h2944%_))
                                 (__hash-ref
                                  _%h2946%_
                                  _%key2937%_
                                  _%default2940%_)))
                              (hash-put!
                               _%ht2849%_
                               '"incumbent"
                               (let ((_%ht2958%_ (make-hash-table 'size: '2)))
                                 (hash-put!
                                  _%ht2958%_
                                  '"selection"
                                  (let* ((_%h2961%_
                                          gerbil-ascent/tools/research/evidence-search#incumbent)
                                         (_%key2964%_ '"selection")
                                         (_%default2967%_ absent-obj)
                                         (_%h2971%_
                                          (cast HashTable::interface
                                                _%h2961%_))
                                         (_%h2973%_ _%h2971%_))
                                    (__hash-ref
                                     _%h2973%_
                                     _%key2964%_
                                     _%default2967%_)))
                                 (hash-put!
                                  _%ht2958%_
                                  '"totals"
                                  (gerbil-ascent/tools/research/evidence-search#totals
                                   (let* ((_%h2986%_
                                           gerbil-ascent/tools/research/evidence-search#incumbent)
                                          (_%key2989%_ '"evaluation")
                                          (_%default2992%_ absent-obj)
                                          (_%h2996%_
                                           (cast HashTable::interface
                                                 _%h2986%_))
                                          (_%h2998%_ _%h2996%_))
                                     (__hash-ref
                                      _%h2998%_
                                      _%key2989%_
                                      _%default2992%_))))
                                 _%ht2958%_))
                              _%ht2849%_)))
                      (if (string=?
                           gerbil-ascent/tools/research/evidence-search#arm
                           '"baseline")
                          '#!void
                          (let* ((_%h3013%_ _%context3010%_)
                                 (_%key3016%_ '"evidence")
                                 (_%value3019%_
                                  (gerbil-ascent/tools/research/evidence-search#fact-packet
                                   _%ids2748%_))
                                 (_%h3023%_
                                  (cast HashTable::interface _%h3013%_))
                                 (_%h3025%_ _%h3023%_))
                            (__hash-put! _%h3025%_ _%key3016%_ _%value3019%_)))
                      (set! gerbil-ascent/tools/research/evidence-search#pending
                            (list _%parent2616%_ _%allowed2804%_))
                      (let ((_%ht3039%_ (make-hash-table 'size: '2)))
                        (hash-put! _%ht3039%_ '"done" '#f)
                        (hash-put! _%ht3039%_ '"context" _%context3010%_)
                        _%ht3039%_))))))))
    (define gerbil-ascent/tools/research/evidence-search#read-atom
      (lambda (_%row2607%_)
        (if (and (list? _%row2607%_)
                 (pair? _%row2607%_)
                 (member (car _%row2607%_) '("edge" "path" "ready"))
                 (= (length _%row2607%_)
                    (if (string=? (car _%row2607%_) '"ready") '2 '3))
                 (andmap exact-integer? (cdr _%row2607%_)))
            '#!void
            (error '"invalid ground annotation atom"))
        (cons (string->symbol (car _%row2607%_)) (cdr _%row2607%_))))
    (define gerbil-ascent/tools/research/evidence-search#episode-check
      (lambda (_%request2529%_)
        (let* ((_%atom2556%_
                (gerbil-ascent/tools/research/evidence-search#read-atom
                 (let* ((_%h2531%_ _%request2529%_)
                        (_%key2534%_ '"atom")
                        (_%default2537%_ absent-obj)
                        (_%h2541%_ (cast HashTable::interface _%h2531%_))
                        (_%h2543%_ _%h2541%_))
                   (__hash-ref _%h2543%_ _%key2534%_ _%default2537%_))))
               (_%premises2583%_
                (map gerbil-ascent/tools/research/evidence-search#read-atom
                     (let* ((_%h2558%_ _%request2529%_)
                            (_%key2561%_ '"premises")
                            (_%default2564%_ absent-obj)
                            (_%h2568%_ (cast HashTable::interface _%h2558%_))
                            (_%h2570%_ _%h2568%_))
                       (__hash-ref _%h2570%_ _%key2561%_ _%default2564%_))))
               (_%answer2585%_
                (gerbil-ascent/tools/research/evidence-search#fact
                 _%atom2556%_))
               (_%grounded2589%_
                (andmap (lambda (_%p2587%_)
                          (eq? (gerbil-ascent/tools/research/evidence-search#field
                                'status
                                (gerbil-ascent/tools/research/evidence-search#fact
                                 _%p2587%_))
                               'verified))
                        _%premises2583%_))
               (_%support2601%_
                (if _%grounded2589%_
                    (if (pair? _%premises2583%_)
                        (let ((_%$e2591%_ (car _%atom2556%_)))
                          (if (eq? 'ready _%$e2591%_)
                              (let ((_%n2594%_
                                     (assoc (cadr _%atom2556%_)
                                            gerbil-ascent/tools/research/evidence-search#needs)))
                                (if _%n2594%_
                                    (equal? _%premises2583%_
                                            (list (list 'path
                                                        (list-ref _%n2594%_ '1)
                                                        (list-ref
                                                         _%n2594%_
                                                         '2))
                                                  (list 'path
                                                        (list-ref _%n2594%_ '3)
                                                        (list-ref
                                                         _%n2594%_
                                                         '4))))
                                    '#f))
                              (if (eq? 'path _%$e2591%_)
                                  (let _%loop2596%_ ((_%at2598%_
                                                      (cadr _%atom2556%_))
                                                     (_%rest2599%_
                                                      _%premises2583%_))
                                    (if (null? _%rest2599%_)
                                        (= _%at2598%_ (caddr _%atom2556%_))
                                        (if (eq? (caar _%rest2599%_) 'edge)
                                            (if (= _%at2598%_
                                                   (cadar _%rest2599%_))
                                                (_%loop2596%_
                                                 (caddar _%rest2599%_)
                                                 (cdr _%rest2599%_))
                                                '#f)
                                            '#f)))
                                  '#f)))
                        '#f)
                    '#f))
               (_%ht2604%_ (make-hash-table 'size: '3)))
          (hash-put!
           _%ht2604%_
           '"truthStatus"
           (gerbil-ascent/tools/research/evidence-search#wire
            (gerbil-ascent/tools/research/evidence-search#field
             'status
             _%answer2585%_)))
          (hash-put!
           _%ht2604%_
           '"present"
           (if (eq? (gerbil-ascent/tools/research/evidence-search#field
                     'status
                     _%answer2585%_)
                    'verified)
               '#t
               '#f))
          (hash-put!
           _%ht2604%_
           '"supportQualified"
           (if _%support2601%_ '#t '#f))
          _%ht2604%_)))
    (define gerbil-ascent/tools/research/evidence-search#dispatch
      (lambda (_%request2116%_)
        (let ((_%$e2143%_
               (string->symbol
                (let* ((_%h2118%_ _%request2116%_)
                       (_%key2121%_ '"op")
                       (_%default2124%_ absent-obj)
                       (_%h2128%_ (cast HashTable::interface _%h2118%_))
                       (_%h2130%_ _%h2128%_))
                  (__hash-ref _%h2130%_ _%key2121%_ _%default2124%_)))))
          (if (eq? 'task _%$e2143%_)
              (gerbil-ascent/tools/research/evidence-search#make-task
               (let* ((_%h2146%_ _%request2116%_)
                      (_%key2149%_ '"case")
                      (_%default2152%_ absent-obj)
                      (_%h2156%_ (cast HashTable::interface _%h2146%_))
                      (_%h2158%_ _%h2156%_))
                 (__hash-ref _%h2158%_ _%key2149%_ _%default2152%_)))
              (if (eq? 'init _%$e2143%_)
                  (begin
                    (set! gerbil-ascent/tools/research/evidence-search#task
                          (gerbil-ascent/tools/research/evidence-search#make-task
                           (let* ((_%h2171%_ _%request2116%_)
                                  (_%key2174%_ '"case")
                                  (_%default2177%_ absent-obj)
                                  (_%h2181%_
                                   (cast HashTable::interface _%h2171%_))
                                  (_%h2183%_ _%h2181%_))
                             (__hash-ref
                              _%h2183%_
                              _%key2174%_
                              _%default2177%_))))
                    (set! gerbil-ascent/tools/research/evidence-search#arm
                          (let* ((_%h2195%_ _%request2116%_)
                                 (_%key2198%_ '"arm")
                                 (_%default2201%_ absent-obj)
                                 (_%h2205%_
                                  (cast HashTable::interface _%h2195%_))
                                 (_%h2207%_ _%h2205%_))
                            (__hash-ref
                             _%h2207%_
                             _%key2198%_
                             _%default2201%_)))
                    (if (member gerbil-ascent/tools/research/evidence-search#arm
                                '("baseline" "facts" "prune"))
                        '#!void
                        (error '"invalid treatment"))
                    (gerbil-ascent/tools/research/evidence-search#prepare-library!
                     (let* ((_%h2219%_ _%request2116%_)
                            (_%key2222%_ '"case")
                            (_%default2225%_ absent-obj)
                            (_%h2229%_ (cast HashTable::interface _%h2219%_))
                            (_%h2231%_ _%h2229%_))
                       (__hash-ref _%h2231%_ _%key2222%_ _%default2225%_)))
                    (set! gerbil-ascent/tools/research/evidence-search#frontier
                          (list '()))
                    (set! gerbil-ascent/tools/research/evidence-search#tried
                          (make-hash-table))
                    (set! gerbil-ascent/tools/research/evidence-search#pending
                          '#f)
                    (set! gerbil-ascent/tools/research/evidence-search#prunings
                          '())
                    (set! gerbil-ascent/tools/research/evidence-search#expansions
                          '())
                    (let* ((_%seed2267%_
                            (let* ((_%h2243%_
                                    gerbil-ascent/tools/research/evidence-search#task)
                                   (_%key2246%_ '"seed")
                                   (_%default2249%_ absent-obj)
                                   (_%h2253%_
                                    (cast HashTable::interface _%h2243%_))
                                   (_%h2255%_ _%h2253%_))
                              (__hash-ref
                               _%h2255%_
                               _%key2246%_
                               _%default2249%_)))
                           (_%checked2269%_
                            (gerbil-ascent/tools/research/evidence-search#check
                             _%seed2267%_
                             '#t)))
                      (if (let* ((_%h2272%_ _%checked2269%_)
                                 (_%key2275%_ '"valid")
                                 (_%default2278%_ absent-obj)
                                 (_%h2282%_
                                  (cast HashTable::interface _%h2272%_))
                                 (_%h2284%_ _%h2282%_))
                            (__hash-ref _%h2284%_ _%key2275%_ _%default2278%_))
                          '#!void
                          (error '"infeasible common seed"))
                      (set! gerbil-ascent/tools/research/evidence-search#incumbent
                            (let ((_%ht2299%_ (make-hash-table 'size: '2)))
                              (hash-put! _%ht2299%_ '"selection" _%seed2267%_)
                              (hash-put!
                               _%ht2299%_
                               '"evaluation"
                               _%checked2269%_)
                              _%ht2299%_)))
                    (let ((_%ht2302%_ (make-hash-table 'size: '3)))
                      (hash-put!
                       _%ht2302%_
                       '"task"
                       gerbil-ascent/tools/research/evidence-search#task)
                      (hash-put!
                       _%ht2302%_
                       '"certificate"
                       (gerbil-ascent/tools/research/evidence-search#wire
                        gerbil-ascent/tools/research/evidence-search#certificate))
                      (hash-put!
                       _%ht2302%_
                       '"libraryLifecycle"
                       gerbil-ascent/tools/research/evidence-search#lifecycle)
                      _%ht2302%_))
                  (if (eq? 'next _%$e2143%_)
                      (gerbil-ascent/tools/research/evidence-search#next-context)
                      (if (eq? 'episode _%$e2143%_)
                          (gerbil-ascent/tools/research/evidence-search#episode-check
                           _%request2116%_)
                          (if (eq? 'expand _%$e2143%_)
                              (let ((_%id2329%_
                                     (let* ((_%h2305%_ _%request2116%_)
                                            (_%key2308%_ '"optionId")
                                            (_%default2311%_ absent-obj)
                                            (_%h2315%_
                                             (cast HashTable::interface
                                                   _%h2305%_))
                                            (_%h2317%_ _%h2315%_))
                                       (__hash-ref
                                        _%h2317%_
                                        _%key2308%_
                                        _%default2311%_))))
                                (if (and gerbil-ascent/tools/research/evidence-search#pending
                                         (exact-integer? _%id2329%_)
                                         (member _%id2329%_
                                                 (cadr gerbil-ascent/tools/research/evidence-search#pending)))
                                    '#!void
                                    (error '"invalid scheduled child"))
                                (let* ((_%parent2331%_
                                        (car gerbil-ascent/tools/research/evidence-search#pending))
                                       (_%child2333%_
                                        (append _%parent2331%_
                                                (list _%id2329%_)))
                                       (_%prefix2335%_
                                        (gerbil-ascent/tools/research/evidence-search#check
                                         _%child2333%_
                                         '#f))
                                       (_%selection2337%_
                                        (gerbil-ascent/tools/research/evidence-search#complete
                                         _%child2333%_))
                                       (_%evaluation2339%_
                                        (gerbil-ascent/tools/research/evidence-search#check
                                         _%selection2337%_
                                         '#t))
                                       (_%event2344%_
                                        (let ((_%ht2341%_
                                               (make-hash-table 'size: '5)))
                                          (hash-put!
                                           _%ht2341%_
                                           '"parent"
                                           _%parent2331%_)
                                          (hash-put!
                                           _%ht2341%_
                                           '"child"
                                           _%child2333%_)
                                          (hash-put!
                                           _%ht2341%_
                                           '"prefix"
                                           _%prefix2335%_)
                                          (hash-put!
                                           _%ht2341%_
                                           '"completion"
                                           _%selection2337%_)
                                          (hash-put!
                                           _%ht2341%_
                                           '"evaluation"
                                           _%evaluation2339%_)
                                          _%ht2341%_)))
                                  (gerbil-ascent/tools/research/evidence-search#mark!
                                   _%parent2331%_
                                   (list _%id2329%_))
                                  (if (and (let* ((_%h2347%_ _%prefix2335%_)
                                                  (_%key2350%_ '"valid")
                                                  (_%default2353%_ absent-obj)
                                                  (_%h2357%_
                                                   (cast HashTable::interface
                                                         _%h2347%_))
                                                  (_%h2359%_ _%h2357%_))
                                             (__hash-ref
                                              _%h2359%_
                                              _%key2350%_
                                              _%default2353%_))
                                           (< (length _%child2333%_)
                                              (let* ((_%h2403%_
                                                      (let* ((_%h2379%_
                                                              gerbil-ascent/tools/research/evidence-search#task)
                                                             (_%key2382%_
                                                              '"goal")
                                                             (_%default2385%_
                                                              absent-obj)
                                                             (_%h2389%_
                                                              (cast HashTable::interface
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%h2379%_))
                     (_%h2391%_ _%h2389%_))
                (__hash-ref _%h2391%_ _%key2382%_ _%default2385%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (_%key2406%_ '"stages")
                                                     (_%default2409%_
                                                      absent-obj)
                                                     (_%h2413%_
                                                      (cast HashTable::interface
                                                            _%h2403%_))
                                                     (_%h2415%_ _%h2413%_))
                                                (__hash-ref
                                                 _%h2415%_
                                                 _%key2406%_
                                                 _%default2409%_))))
                                      (set! gerbil-ascent/tools/research/evidence-search#frontier
                                            (cons _%child2333%_
                                                  gerbil-ascent/tools/research/evidence-search#frontier))
                                      '#!void)
                                  (if (and (let* ((_%h2427%_
                                                   _%evaluation2339%_)
                                                  (_%key2430%_ '"valid")
                                                  (_%default2433%_ absent-obj)
                                                  (_%h2437%_
                                                   (cast HashTable::interface
                                                         _%h2427%_))
                                                  (_%h2439%_ _%h2437%_))
                                             (__hash-ref
                                              _%h2439%_
                                              _%key2430%_
                                              _%default2433%_))
                                           (> (let* ((_%h2451%_
                                                      _%evaluation2339%_)
                                                     (_%key2454%_ '"value")
                                                     (_%default2457%_
                                                      absent-obj)
                                                     (_%h2461%_
                                                      (cast HashTable::interface
                                                            _%h2451%_))
                                                     (_%h2463%_ _%h2461%_))
                                                (__hash-ref
                                                 _%h2463%_
                                                 _%key2454%_
                                                 _%default2457%_))
                                              (let* ((_%h2499%_
                                                      (let* ((_%h2475%_
                                                              gerbil-ascent/tools/research/evidence-search#incumbent)
                                                             (_%key2478%_
                                                              '"evaluation")
                                                             (_%default2481%_
                                                              absent-obj)
                                                             (_%h2485%_
                                                              (cast HashTable::interface
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%h2475%_))
                     (_%h2487%_ _%h2485%_))
                (__hash-ref _%h2487%_ _%key2478%_ _%default2481%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (_%key2502%_ '"value")
                                                     (_%default2505%_
                                                      absent-obj)
                                                     (_%h2509%_
                                                      (cast HashTable::interface
                                                            _%h2499%_))
                                                     (_%h2511%_ _%h2509%_))
                                                (__hash-ref
                                                 _%h2511%_
                                                 _%key2502%_
                                                 _%default2505%_))))
                                      (set! gerbil-ascent/tools/research/evidence-search#incumbent
                                            (let ((_%ht2523%_
                                                   (make-hash-table
                                                    'size:
                                                    '2)))
                                              (hash-put!
                                               _%ht2523%_
                                               '"selection"
                                               _%selection2337%_)
                                              (hash-put!
                                               _%ht2523%_
                                               '"evaluation"
                                               _%evaluation2339%_)
                                              _%ht2523%_))
                                      '#!void)
                                  (set! gerbil-ascent/tools/research/evidence-search#expansions
                                        (cons _%event2344%_
                                              gerbil-ascent/tools/research/evidence-search#expansions))
                                  (set! gerbil-ascent/tools/research/evidence-search#pending
                                        '#f)
                                  _%event2344%_))
                              (if (eq? 'summary _%$e2143%_)
                                  (let ((_%ht2526%_
                                         (make-hash-table 'size: '4)))
                                    (hash-put!
                                     _%ht2526%_
                                     '"incumbent"
                                     gerbil-ascent/tools/research/evidence-search#incumbent)
                                    (hash-put!
                                     _%ht2526%_
                                     '"expansions"
                                     (reverse gerbil-ascent/tools/research/evidence-search#expansions))
                                    (hash-put!
                                     _%ht2526%_
                                     '"prunings"
                                     (reverse gerbil-ascent/tools/research/evidence-search#prunings))
                                    (hash-put!
                                     _%ht2526%_
                                     '"nativeStats"
                                     (gerbil-ascent/tools/research/evidence-search#wire
                                      (gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-stats
                                       gerbil-ascent/tools/research/evidence-search#store)))
                                    _%ht2526%_)
                                  (error '"unsupported scenario operation"))))))))))
    (define gerbil-ascent/tools/research/evidence-search#main
      (lambda _%args2045%_
        (let _%loop2047%_ ()
          (let ((_%line2050%_ (read-line)))
            (if (eof-object? _%line2050%_)
                '#!void
                (begin
                  (let ((_%answer2114%_
                         (with-catch
                          (lambda (_%$%g20512053%_)
                            (if '#t
                                (let* ((_%e2057%_ _%$%g20512053%_)
                                       (_%ht2059%_
                                        (make-hash-table 'size: '1)))
                                  (hash-put!
                                   _%ht2059%_
                                   '"error"
                                   (std/error#exception->string _%e2057%_))
                                  _%ht2059%_)
                                (raise _%$%g20512053%_)))
                          (lambda ()
                            (gerbil-ascent/tools/research/evidence-search#dispatch
                             (call-with-parameters
                              (lambda ()
                                (call-with-input-string
                                 _%line2050%_
                                 std/encoding/json/util#read-json))
                              std/encoding/json/env#current-json-read-options
                              (let* ((_%object-as-hash2065%_ '#t)
                                     (_%key-as-symbol2068%_ '#f)
                                     (_%array-as-vector2071%_ '#f))
                                (if (boolean? _%key-as-symbol2068%_)
                                    (let ((_%key-as-symbol2076%_
                                           _%key-as-symbol2068%_))
                                      (if (boolean? _%array-as-vector2071%_)
                                          (let ((_%array-as-vector2094%_
                                                 _%array-as-vector2071%_))
                                            (if (boolean?
                                                 _%object-as-hash2065%_)
                                                (let ((_%object-as-hash2104%_
                                                       _%object-as-hash2065%_))
                                                  (std/encoding/json/env#__make-JSONReadOptions
                                                   'key-as-symbol:
                                                   _%key-as-symbol2076%_
                                                   'array-as-vector:
                                                   _%array-as-vector2094%_
                                                   'object-as-hash:
                                                   _%object-as-hash2104%_))
                                                (begin
                                                  (raise-contract-violation-error
                                                   '"contract violation"
                                                   'context:
                                                   'gerbil-ascent/tools/research/evidence-search
                                                   'contract:
                                                   'boolean?
                                                   'value:
                                                   _%object-as-hash2065%_)
                                                  (void))))
                                          (begin
                                            (raise-contract-violation-error
                                             '"contract violation"
                                             'context:
                                             'gerbil-ascent/tools/research/evidence-search
                                             'contract:
                                             'boolean?
                                             'value:
                                             _%array-as-vector2071%_)
                                            (void))))
                                    (begin
                                      (raise-contract-violation-error
                                       '"contract violation"
                                       'context:
                                       'gerbil-ascent/tools/research/evidence-search
                                       'contract:
                                       'boolean?
                                       'value:
                                       _%key-as-symbol2068%_)
                                      (void))))))))))
                    (display (std/encoding/json/util#json->string
                              _%answer2114%_))
                    (newline)
                    (force-output))
                  (_%loop2047%_)))))))))
