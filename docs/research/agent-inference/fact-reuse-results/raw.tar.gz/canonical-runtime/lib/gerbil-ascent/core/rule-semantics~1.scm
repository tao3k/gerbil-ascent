(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/core/rule-semantics[1]#_g35322_|
    (##structure
     gx#syntax-quote::t
     'rule-read::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35324_|
    (##structure
     gx#syntax-quote::t
     'make-rule-read
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35326_|
    (##structure
     gx#syntax-quote::t
     'rule-read?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35328_|
    (##structure
     gx#syntax-quote::t
     'rule-read-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35329_|
    (##structure
     gx#syntax-quote::t
     'rule-read-source
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35331_|
    (##structure
     gx#syntax-quote::t
     'rule-read-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35332_|
    (##structure
     gx#syntax-quote::t
     'rule-read-source-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35334_|
    (##structure
     gx#syntax-quote::t
     '&rule-read-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35335_|
    (##structure
     gx#syntax-quote::t
     '&rule-read-source
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35337_|
    (##structure
     gx#syntax-quote::t
     '&rule-read-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g35338_|
    (##structure
     gx#syntax-quote::t
     '&rule-read-source-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/core/rule-semantics[:0:]#rule-read|
      (let ((__obj35281
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35281
           'gerbil-ascent/core/rule-semantics#rule-read::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35281 'rule-read '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35281 '(kind source) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35281 '(kind source) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35281 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35281 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35281 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35281 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35281 '#f '13 '#f '#f))
        (let ((__tmp35321 |gerbil-ascent/core/rule-semantics[1]#_g35322_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35281 __tmp35321 '4 '#f '#f))
        (let ((__tmp35323 |gerbil-ascent/core/rule-semantics[1]#_g35324_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35281 __tmp35323 '14 '#f '#f))
        (let ((__tmp35325 |gerbil-ascent/core/rule-semantics[1]#_g35326_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35281 __tmp35325 '15 '#f '#f))
        (let ((__tmp35327
               (cons (cons 'kind
                           |gerbil-ascent/core/rule-semantics[1]#_g35328_|)
                     (cons (cons 'source
                                 |gerbil-ascent/core/rule-semantics[1]#_g35329_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35281 __tmp35327 '16 '#f '#f))
        (let ((__tmp35330
               (cons (cons 'kind
                           |gerbil-ascent/core/rule-semantics[1]#_g35331_|)
                     (cons (cons 'source
                                 |gerbil-ascent/core/rule-semantics[1]#_g35332_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35281 __tmp35330 '17 '#f '#f))
        (let ((__tmp35333
               (cons (cons 'kind
                           |gerbil-ascent/core/rule-semantics[1]#_g35334_|)
                     (cons (cons 'source
                                 |gerbil-ascent/core/rule-semantics[1]#_g35335_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35281 __tmp35333 '18 '#f '#f))
        (let ((__tmp35336
               (cons (cons 'kind
                           |gerbil-ascent/core/rule-semantics[1]#_g35337_|)
                     (cons (cons 'source
                                 |gerbil-ascent/core/rule-semantics[1]#_g35338_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35281 __tmp35336 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35281 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35281 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35281 '() '21 '#f '#f))
        __obj35281))
    (define |gerbil-ascent/core/rule-semantics[:0:]#for-rule-reads|
      (lambda (_%$stx7407%_)
        (let* ((_%$%g74117446%_
                (lambda (_%$%g74127442%_)
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%$%g74127442%_))))
               (_%$%g74107570%_
                (lambda (_%$%g74127450%_)
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-pair? _%$%g74127450%_))
                      (let ((_%$%e74177453%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-e _%$%g74127450%_))))
                        (let ((_%$%hd74187457%_
                               (let ()
                                 (declare (not safe))
                                 (##car _%$%e74177453%_)))
                              (_%$%tl74197460%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%$%e74177453%_))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair? _%$%tl74197460%_))
                              (let ((_%$%e74207463%_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-e _%$%tl74197460%_))))
                                (let ((_%$%hd74217467%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%$%e74207463%_)))
                                      (_%$%tl74227470%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%e74207463%_))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%tl74227470%_))
                                      (let ((_%$%e74237473%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%tl74227470%_))))
                                        (let ((_%$%hd74247477%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e74237473%_)))
                                              (_%$%tl74257480%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e74237473%_))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair?
                                                 _%$%hd74247477%_))
                                              (let ((_%$%e74267483%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-e
                                                        _%$%hd74247477%_))))
                                                (let ((_%$%hd74277487%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##car _%$%e74267483%_)))
                                                      (_%$%tl74287490%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##cdr _%$%e74267483%_))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair?
                                                         _%$%tl74287490%_))
                                                      (let ((_%$%e74297493%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-e _%$%tl74287490%_))))
                (let ((_%$%hd74307497%_
                       (let () (declare (not safe)) (##car _%$%e74297493%_)))
                      (_%$%tl74317500%_
                       (let () (declare (not safe)) (##cdr _%$%e74297493%_))))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-null? _%$%tl74317500%_))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl74257480%_))
                          (let ((_g35339_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice
                                    _%$%tl74257480%_
                                    '0))))
                            (begin
                              (let ((_g35340_
                                     (let ()
                                       (declare (not safe))
                                       (if (##values? _g35339_)
                                           (##values-length _g35339_)
                                           1))))
                                (if (not (let ()
                                           (declare (not safe))
                                           (##fx= _g35340_ 2)))
                                    (error "Context expects 2 values"
                                           _g35340_)))
                              (let ((_%$%target74327503%_
                                     (let ()
                                       (declare (not safe))
                                       (##values-ref _g35339_ 0)))
                                    (_%$%tl74347506%_
                                     (let ()
                                       (declare (not safe))
                                       (##values-ref _g35339_ 1))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl74347506%_))
                                    (letrec ((_%$%loop74357509%_
                                              (lambda (_%$%hd74337513%_
                                                       _%$%body74397516%_)
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair?
                                                       _%$%hd74337513%_))
                                                    (let ((_%$%e74367518%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-e
                                                              _%$%hd74337513%_))))
                                                      (let ((_%$%lp-hd74377522%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##car _%$%e74367518%_)))
                    (_%$%lp-tl74387525%_
                     (let () (declare (not safe)) (##cdr _%$%e74367518%_))))
                (_%$%loop74357509%_
                 _%$%lp-tl74387525%_
                 (cons _%$%lp-hd74377522%_ _%$%body74397516%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (let ((_%$%body74407528%_
                                                           (reverse _%$%body74397516%_)))
                                                      (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'for-each))
                                                            (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                  (declare (not safe))
                                  (gx#datum->syntax__0 '#f 'lambda))
                                (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'clause))
                                            '())
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'let))
                                                  (cons (cons _%$%hd74277487%_
                                                              (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                    (declare (not safe))
                                    (gx#datum->syntax__0 '#f 'vector-ref))
                                  (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'clause))
                                        (cons '0 '())))
                            '()))
                (cons (cons (let ()
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'when))
                            (cons (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'memq))
                                        (cons _%$%hd74277487%_
                                              (cons (cons (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#datum->syntax__0
                                                             '#f
                                                             'quote))
                                                          (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                (declare (not safe))
                                (gx#datum->syntax__0 '#f 'atom))
                              (cons (let ()
                                      (declare (not safe))
                                      (gx#datum->syntax__0 '#f 'negation))
                                    (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0
                                             '#f
                                             'aggregate))
                                          '())))
                        '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '())))
                                  (cons (cons (let ()
                                                (declare (not safe))
                                                (gx#datum->syntax__0 '#f 'let))
                                              (cons (cons _%$%hd74307497%_
                                                          (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                (declare (not safe))
                                (gx#datum->syntax__0 '#f 'vector-ref))
                              (cons (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0
                                             '#f
                                             'vector-ref))
                                          (cons (let ()
                                                  (declare (not safe))
                                                  (gx#datum->syntax__0
                                                   '#f
                                                   'clause))
                                                (cons '1 '())))
                                    (cons '0 '())))
                        '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (let ((__tmp35341
                                                           (lambda (_%$%g75617564%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%$%g75627567%_)
                     (cons _%$%g75617564%_ _%$%g75627567%_))))
              (declare (not safe))
              (foldr__0 __tmp35341 '() _%$%body74407528%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        '())))
                      '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            '())))
                          (cons _%$%hd74217467%_ '()))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                      (_%$%loop74357509%_
                                       _%$%target74327503%_
                                       '()))
                                    (_%$%g74117446%_ _%$%g74127450%_)))))
                          (_%$%g74117446%_ _%$%g74127450%_))
                      (_%$%g74117446%_ _%$%g74127450%_))))
              (_%$%g74117446%_ _%$%g74127450%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%$%g74117446%_
                                               _%$%g74127450%_))))
                                      (_%$%g74117446%_ _%$%g74127450%_))))
                              (_%$%g74117446%_ _%$%g74127450%_))))
                      (_%$%g74117446%_ _%$%g74127450%_)))))
          (_%$%g74107570%_ _%$stx7407%_))))
    (define |gerbil-ascent/core/rule-semantics[:0:]#with-rule-reads|
      (lambda (_%$stx7575%_)
        (let* ((_%$%g75797614%_
                (lambda (_%$%g75807610%_)
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%$%g75807610%_))))
               (_%$%g75787737%_
                (lambda (_%$%g75807618%_)
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-pair? _%$%g75807618%_))
                      (let ((_%$%e75857621%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-e _%$%g75807618%_))))
                        (let ((_%$%hd75867625%_
                               (let ()
                                 (declare (not safe))
                                 (##car _%$%e75857621%_)))
                              (_%$%tl75877628%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%$%e75857621%_))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair? _%$%tl75877628%_))
                              (let ((_%$%e75887631%_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-e _%$%tl75877628%_))))
                                (let ((_%$%hd75897635%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%$%e75887631%_)))
                                      (_%$%tl75907638%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%e75887631%_))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%tl75907638%_))
                                      (let ((_%$%e75917641%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%tl75907638%_))))
                                        (let ((_%$%hd75927645%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e75917641%_)))
                                              (_%$%tl75937648%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e75917641%_))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair?
                                                 _%$%hd75927645%_))
                                              (let ((_%$%e75947651%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-e
                                                        _%$%hd75927645%_))))
                                                (let ((_%$%hd75957655%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##car _%$%e75947651%_)))
                                                      (_%$%tl75967658%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##cdr _%$%e75947651%_))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair?
                                                         _%$%tl75967658%_))
                                                      (let ((_%$%e75977661%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-e _%$%tl75967658%_))))
                (let ((_%$%hd75987665%_
                       (let () (declare (not safe)) (##car _%$%e75977661%_)))
                      (_%$%tl75997668%_
                       (let () (declare (not safe)) (##cdr _%$%e75977661%_))))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-null? _%$%tl75997668%_))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl75937648%_))
                          (let ((_g35342_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice
                                    _%$%tl75937648%_
                                    '0))))
                            (begin
                              (let ((_g35343_
                                     (let ()
                                       (declare (not safe))
                                       (if (##values? _g35342_)
                                           (##values-length _g35342_)
                                           1))))
                                (if (not (let ()
                                           (declare (not safe))
                                           (##fx= _g35343_ 2)))
                                    (error "Context expects 2 values"
                                           _g35343_)))
                              (let ((_%$%target76007671%_
                                     (let ()
                                       (declare (not safe))
                                       (##values-ref _g35342_ 0)))
                                    (_%$%tl76027674%_
                                     (let ()
                                       (declare (not safe))
                                       (##values-ref _g35342_ 1))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl76027674%_))
                                    (letrec ((_%$%loop76037677%_
                                              (lambda (_%$%hd76017681%_
                                                       _%$%body76077684%_)
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair?
                                                       _%$%hd76017681%_))
                                                    (let ((_%$%e76047686%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-e
                                                              _%$%hd76017681%_))))
                                                      (let ((_%$%lp-hd76057690%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##car _%$%e76047686%_)))
                    (_%$%lp-tl76067693%_
                     (let () (declare (not safe)) (##cdr _%$%e76047686%_))))
                (_%$%loop76037677%_
                 _%$%lp-tl76067693%_
                 (cons _%$%lp-hd76057690%_ _%$%body76077684%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (let ((_%$%body76087696%_
                                                           (reverse _%$%body76077684%_)))
                                                      (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'let))
                                                            (cons (cons (cons _%$%hd75957655%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'vector-ref))
                                                  (cons _%$%hd75897635%_
                                                        (cons '0 '())))
                                            '()))
                                (cons (cons _%$%hd75987665%_
                                            (cons (cons (let ()
                                                          (declare (not safe))
                                                          (gx#datum->syntax__0
                                                           '#f
                                                           'prepare-rule-reads))
                                                        (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'vector-ref))
                            (cons _%$%hd75897635%_ (cons '1 '())))
                      '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  '()))
                                      '()))
                          (let ((__tmp35344
                                 (lambda (_%$%g77287731%_ _%$%g77297734%_)
                                   (cons _%$%g77287731%_ _%$%g77297734%_))))
                            (declare (not safe))
                            (foldr__0
                             __tmp35344
                             '()
                             _%$%body76087696%_)))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                      (_%$%loop76037677%_
                                       _%$%target76007671%_
                                       '()))
                                    (_%$%g75797614%_ _%$%g75807618%_)))))
                          (_%$%g75797614%_ _%$%g75807618%_))
                      (_%$%g75797614%_ _%$%g75807618%_))))
              (_%$%g75797614%_ _%$%g75807618%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%$%g75797614%_
                                               _%$%g75807618%_))))
                                      (_%$%g75797614%_ _%$%g75807618%_))))
                              (_%$%g75797614%_ _%$%g75807618%_))))
                      (_%$%g75797614%_ _%$%g75807618%_)))))
          (_%$%g75787737%_ _%$stx7575%_))))))
