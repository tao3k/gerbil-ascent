(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/program/source-snapshot")
    (load-module "clan/poo/object")
    (load-module "clan/poo/mop")
    (load-module "gerbil-ascent/program/types")
    (load-module "gerbil-ascent/program/admission")
    (load-module "gerbil-ascent/program/update-selection")
    (load-module "gerbil-ascent/program/evaluate")
    (load-module "gerbil-ascent/table/provider")
    (load-module "gerbil-ascent/table/storage"))
  (load-module "gerbil-ascent/program/session~0"))
