;;; -*- Gerbil -*-
;;; SPDX-FileCopyrightText: 2026 tao3k team and Contributors
;;; SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later

;;; One engine's physical indexes over live all/delta vectors. Metadata plans
;;; stay immutable; source admission and row/version publication stay in evaluate.
(import (only-in :std/iter for for/fold in-vector in-range)
        (only-in :std/list/list-builder with-list-builder)
        :gerbil-ascent/core/relation-view
        (only-in :gerbil-ascent/table/index-sharing gerbil-ascent-index-sharing-layout
                 gerbil-ascent-shared-index-build gerbil-ascent-shared-index-extend!
                 gerbil-ascent-shared-index-rows)
        (only-in :gerbil-ascent/core/positive-plan gerbil-ascent-index-key
                 gerbil-ascent-index-key/terms gerbil-ascent-index-value)
        (only-in :gerbil-ascent/table/access gerbil-ascent-physical-index-build
                 gerbil-ascent-physical-index-extend! gerbil-ascent-physical-index-rows
                 gerbil-ascent-physical-index-single-rows)
        (only-in :gerbil-ascent/table/provider gerbil-ascent-canonical-hash-index-provider?
                 gerbil-ascent-curried-index-provider?)
        (rename-in (only-in :gerbil-ascent/table/funs gerbil-ascent-index-key
                           gerbil-ascent-index-row-snapshot/arity)
                   (gerbil-ascent-index-key row-key)))
(export gerbil-ascent-make-row-indexes row-indexes-rows row-indexes-visit-parts row-indexes-advance! row-indexes-plan-atoms! row-indexes-plan-rules! row-indexes-plan-actions! row-indexes-plan-positive-rules!)

(defstruct row-indexes (rows advance! plan! visit-parts))

;;; Public metadata adapters feed one synchronous, owner-controlled collector.
;;; Physical state admission precedes traversal; unused metadata stays borrowed.
;; row-indexes-plan-atoms!
;; : (-> RowIndexes (-> AdmittedAtoms Void))
;; | doc m%
;;     Return the owner-bound atom registration procedure. Borrow immutable atom
;;     descriptors; detach retained requirement spines before publication.
;;
;;     # Examples
;;
;;     ```scheme
;;     ((row-indexes-plan-atoms! indexes) atoms)
;;     ```
;;   %
(def (row-indexes-plan-atoms! indexes)
  (lambda (atoms)
    ((row-indexes-plan! indexes) (lambda (accept!) (for-each accept! atoms)))))

(def (visit-action-atoms! actions accept!)
  (for-each (lambda (action)
              (let (atom (vector-ref action 0))
                (when (vector? atom) (accept! atom)))) actions))

;;; Sharing consumes relation/column requirements, not expression identities.
;;; Keep the first representative in source order; terms remain unevaluated.
(def (collect-sharing-atoms visit! providers)
  (let (seen (make-vector (vector-length providers) #f))
    (with-list-builder (collect!)
      (def (accept! atom)
        (let ((index (vector-ref atom 0)) (columns (vector-ref atom 2)))
          (when (and (gerbil-ascent-curried-index-provider? (vector-ref providers index))
                     (pair? columns))
            (let (table (or (vector-ref seen index)
                           (let (fresh (make-hash-table))
                             (vector-set! seen index fresh) fresh)))
              (unless (hash-get table columns)
                (hash-put! table columns #t)
                (collect! atom))))))
      (visit! accept!))))

;;; Custom indexes may overselect candidates, but each must still represent
;;; a complete relation tuple. Check the whole batch before term callbacks.
;;; Traversal is bounded by admitted arity, including improper/cyclic rows.
;;; One value-keyed admission per equal row class; transient packet counts
;;; use this version-owned member identity instead of rehashing wide rows.
(defstruct provider-row-member (ordinal key occurrences))
(defstruct provider-row-witness (members counts))

(def (checked-provider-rows rows terms witness key)
  ;; Shape admission and spine detachment share one bounded traversal. The
  ;; entire packet still precedes membership, coverage and term callbacks.
  ;; The witness belongs to this physical entry's all/delta version.
  (let ((snapshot (gerbil-ascent-index-row-snapshot/arity rows (length terms)))
        ;; Dense ordinals belong to this witness version, never to provider rows.
        (seen (make-hash-table)) (matched 0))
    (for-each
     (lambda (row)
       (let (member (hash-get (provider-row-witness-members witness) row))
         (unless member
           (error "ASCENT index provider returned foreign row"))
         ;; Initial source snapshots can contain equal row occurrences.
         ;; Reject only enumeration beyond this lane/version's admitted count.
         (let (enumerated (or (hash-get seen (provider-row-member-ordinal member)) 0))
          (when (>= enumerated (provider-row-member-occurrences member))
           (error "ASCENT index provider returned duplicate row"))
          (hash-put! seen (provider-row-member-ordinal member) (+ enumerated 1)))
         (when (equal? (provider-row-member-key member) key) (set! matched (+ matched 1)))))
     snapshot)
    ;; Represented occurrences cover this key iff their count equals the
    ;; snapshot's key count. No second key-expression evaluation.
    (unless (= matched (or (hash-get (provider-row-witness-counts witness) key) 0))
      (error "ASCENT index provider omitted matching rows"))
    snapshot))

;;; Extend the same value classes only after source admission. Their identity
;;; stays stable for the physical version; packet-local counters never escape.
;; : (-> ProviderRowWitness Rows Columns ProviderRowWitness)
(def (extend-provider-row-witness! witness rows columns)
  (let ((members (provider-row-witness-members witness))
        (counts (provider-row-witness-counts witness)))
    (for-each
     (lambda (row)
       (let* ((member (or (hash-get members row)
                         (let (fresh (make-provider-row-member (hash-length members) (row-key row columns) 0))
                           (hash-put! members row fresh) fresh)))
              (key (provider-row-member-key member)))
         (provider-row-member-occurrences-set! member
           (+ 1 (provider-row-member-occurrences member)))
         (hash-put! counts key (+ 1 (or (hash-get counts key) 0))))) rows))
  witness)

;; : (-> Rows Columns ProviderRowWitness)
(def (build-provider-row-witness rows columns)
  (extend-provider-row-witness!
   (make-provider-row-witness (make-hash-table) (make-hash-table)) rows columns))

;;; Index ownership includes discovery of the logical lookup requirements.
;;; The three execution owners supply admitted metadata, never row snapshots
;;; or evaluated key expressions, and retain their own independent roots.
;; row-indexes-plan-rules!
;; : (forall (i r) (-> (RowIndexes i) [(RulePlan r)] Void))
;; : (-> RowIndexes AdmittedRulePlans Void)
;; | doc m%
;;     Register logical atoms in original rule and clause order. Negative and
;;     aggregate lookup requirements retain their admitted atom metadata.
;;
;;     # Examples
;;
;;     ```scheme
;;     (row-indexes-plan-rules! indexes rule-plans)
;;     ;; => registers engine-owned logical lookup requirements
;;     ```
;;   %
(def (row-indexes-plan-rules! indexes rules)
  ((row-indexes-plan! indexes)
   (lambda (accept!)
     (for-each (lambda (rule)
                 (for-each (lambda (clause)
                             (when (memq (vector-ref clause 0) '(atom negation aggregate))
                               (accept! (vector-ref clause 1))))
                           (vector-ref rule 1))) rules))))

;; row-indexes-plan-actions!
;; : (forall (i a) (-> (RowIndexes i) [(CompiledAction a)] Void))
;; : (-> RowIndexes AdmittedPositiveActions Void)
;; | doc m%
;;     Register immutable compiled lookup atoms for a private worker. Do not
;;     evaluate callbacks, reorder actions or share the worker's physical roots.
;;
;;     # Examples
;;
;;     ```scheme
;;     (row-indexes-plan-actions! indexes actions)
;;     ;; => registers worker-owned compiled lookup requirements
;;     ```
;;   %
(def (row-indexes-plan-actions! indexes actions)
  ((row-indexes-plan! indexes) (cut visit-action-atoms! actions <>)))

;;; SCC rule wrappers share admitted bodies; never flatten their action lists.
;; row-indexes-plan-positive-rules!
;; : (-> RowIndexes [PositiveRule] Void)
;; | doc m%
;;     Register lookup requirements from admitted SCC rule wrappers in rule and
;;     action order. The index owner decides whether collection is needed.
;;
;;     # Examples
;;
;;     ```scheme
;;     (row-indexes-plan-positive-rules! indexes component-rules)
;;     ```
;;   %
(def (row-indexes-plan-positive-rules! indexes rules)
  ((row-indexes-plan! indexes)
   (lambda (accept!)
     (for-each (lambda (rule)
                 (visit-action-atoms! (vector-ref (vector-ref rule 0) 1) accept!)) rules))))

;;; Stable entries belong to one engine. Column tables share them across
;;; equivalent atoms; identity tables only shortcut that structural resolution.
(def empty-row-indexes
  ;; No rule can read this immutable owner; source transactions need no cache
  ;; advancement. Reject accidental consumers instead of silently scanning.
  (make-row-indexes
   (lambda (atom environment use-delta? slot-terms)
     (error "ASCENT empty index owner has no lookup consumer"))
   (lambda (index rows (reverse-order? #f)) (void))
   (lambda (visit!)
     (visit! (lambda (_) (error "ASCENT empty index owner has lookup requirements")))) #f))

(defstruct physical-index-entry (version lookup shared? witness))
(defstruct atom-index-view (entry permutation))

;; gerbil-ascent-make-row-indexes
;;   : (-> Rows Rows Sizes Sizes Versions Versions Providers RowIndexes)
;;   | doc m%
;;       Own all/delta physical caches for one engine. The engine updates the
;;       supplied row, size and version vectors; indexes extend only admitted rows.
;;
;;       # Examples
;;
;;       ```scheme
;;       (gerbil-ascent-make-row-indexes all delta all-size delta-size all-version delta-version providers)
;;       ;; => engine-local lookup and incremental extension procedures
;;       ```
;;     %
(def (gerbil-ascent-make-row-indexes all delta all-size delta-size all-version delta-version index-providers (required? #t))
  (if required?
    (make-required-row-indexes all delta all-size delta-size all-version delta-version index-providers)
    empty-row-indexes))

(def (make-required-row-indexes all delta all-size delta-size all-version delta-version index-providers)
  ;; Scans and small relations own no physical cache vectors. Allocate each
  ;; lane only when its first indexed lookup crosses the size threshold.
  (let ((all-indexes #f) (delta-indexes #f)
        (all-atoms #f) (delta-atoms #f)
        (layouts (make-vector (vector-length all) #f)) (planned-atoms #f)
        (sharing? (for/fold (found? #f) (provider (in-vector index-providers))
                    (or found? (gerbil-ascent-curried-index-provider? provider))))
        (ordered-all #f) (ordered-delta #f))
      (def (ordered-cut captured index use-delta?)
        (let* ((cache (if use-delta?
                        (or ordered-delta (let (v (make-vector (vector-length all) #f))
                                            (set! ordered-delta v) v))
                        (or ordered-all (let (v (make-vector (vector-length all) #f))
                                          (set! ordered-all v) v))))
               (prior (vector-ref cache index)))
          (if (and prior (eq? (car prior) captured)) (cdr prior)
            ;; Public export is chronological; legacy evaluator roots are
            ;; prepended lists, so internal callback traversal is its reverse.
            ;; Bound delta exports already carry legacy pending-list order;
            ;; total exports carry public chronological order.
            (let (rows (if (eq? (relation-view-lane captured) 'delta)
                         (gerbil-ascent-view-rows captured)
                         (reverse (gerbil-ascent-view-rows captured))))
              (vector-set! cache index (cons captured rows)) rows))))
      (def (plan! visit!)
        (when (or all-indexes delta-indexes) (error "cannot replan a live physical index"))
        ;; Small snapshots need no physical plan. An explicit curried receiver
        ;; triggers planning only when an actual lookup first needs an index.
        ;; Complete a fresh owned spine before replacing earlier requirements.
        ;; Providers that do not share chains need no metadata traversal.
        (let (fresh (and sharing? (collect-sharing-atoms visit! index-providers)))
          (set! planned-atoms (and (pair? fresh) fresh))))
      (def (ensure-layouts!)
        (when planned-atoms
          (let ((requirements (make-vector (vector-length all) []))
                (fresh (make-vector (vector-length all) #f)))
            (for-each
             (lambda (atom)
               (let ((i (vector-ref atom 0)) (columns (vector-ref atom 2)))
                 (when (and (gerbil-ascent-curried-index-provider? (vector-ref index-providers i))
                            (= (length columns) (hash-length (let (seen (make-hash-table-eq))
                              (for-each (lambda (c) (hash-put! seen c #t)) columns) seen))))
                   (vector-set! requirements i (cons columns (vector-ref requirements i)))))) planned-atoms)
            (for (i (in-range (vector-length all)))
              (let (columns (vector-ref requirements i))
                (when (pair? columns)
                  (let (layout (gerbil-ascent-index-sharing-layout columns))
                    (vector-set! fresh i (and (> (hash-length layout) 0) layout))))))
            ;; Metadata publication follows successful complete planning.
            (set! layouts fresh) (set! planned-atoms #f))))
      (def (visit-parts atom environment use-delta? slot-terms consume)
        (let (captured (vector-ref (if use-delta? delta all) (vector-ref atom 0)))
          (and (gerbil-ascent-admitted-row-parts? captured)
            (gerbil-ascent-canonical-hash-index-provider? (vector-ref index-providers (vector-ref atom 0)))
            (begin
              ((if slot-terms gerbil-ascent-visit-admitted-view-parts! gerbil-ascent-visit-view-parts!) captured (vector-ref atom 2)
                (if slot-terms
                  (gerbil-ascent-index-key (vector-ref atom 1) (vector-ref atom 2) environment slot-terms)
                  (gerbil-ascent-index-key/terms (vector-ref atom 4) environment)) consume)
              #t))))
      (def (indexed-rows atom environment use-delta? slot-terms (ordered? #f))
        (let* ((index (vector-ref atom 0))
               (columns (vector-ref atom 2))
               (captured (vector-ref (if use-delta? delta all) index))
               ;; Observable callbacks and aggregators use the legacy list/index
               ;; ordering. Pure plans retain the descriptor access path.
               (rows (if (and ordered? (relation-view? captured))
                       (ordered-cut captured index use-delta?) captured)))
          (if (relation-view? rows)
            (gerbil-ascent-view-select rows columns
              (if slot-terms
                (gerbil-ascent-index-key (vector-ref atom 1) columns environment slot-terms)
                (gerbil-ascent-index-key/terms (vector-ref atom 4) environment)))
          (if (or (null? columns)
                  (< (vector-ref (if use-delta? delta-size all-size)
                                 index)
                     32))
            rows
            (begin
              (ensure-layouts!)
            (let* ((identities
                    (if use-delta?
                      (or delta-atoms
                          (let (fresh (make-hash-table-eq))
                            (set! delta-atoms fresh) fresh))
                      (or all-atoms
                          (let (fresh (make-hash-table-eq))
                            (set! all-atoms fresh) fresh))))
                   (version (vector-ref
                             (if use-delta? delta-version all-version) index))
                   (view
                    (or (hash-get identities atom)
                        (let* ((layout (vector-ref layouts index))
                               (permutation (and layout (hash-get layout (list-sort < columns))))
                               (physical-columns (or permutation columns))
                               (caches
                                (if use-delta?
                                  (or delta-indexes
                                      (let (fresh (make-vector (vector-length delta) #f))
                                        (set! delta-indexes fresh) fresh))
                                  (or all-indexes
                                      (let (fresh (make-vector (vector-length all) #f))
                                        (set! all-indexes fresh) fresh))))
                               (cache
                                (or (vector-ref caches index)
                                    (let (fresh (make-hash-table))
                                      (vector-set! caches index fresh) fresh)))
                               (shared (hash-get cache physical-columns))
                               (resolved
                                (or shared
                                    (let (fresh (make-physical-index-entry #f #f (and permutation #t) #f))
                                      (hash-put! cache physical-columns fresh) fresh))))
                          (let (view (make-atom-index-view resolved permutation))
                            (hash-put! identities atom view)
                            view))))
                   (entry (atom-index-view-entry view))
                   (permutation (atom-index-view-permutation view))
                   (provider (vector-ref index-providers index))
                   (lookup
                    (if (and (physical-index-entry-version entry)
                             (= (physical-index-entry-version entry) version))
                      (physical-index-entry-lookup entry)
                      (let* ((members (and (not permutation)
                                          (not (gerbil-ascent-canonical-hash-index-provider? provider))
                                          (build-provider-row-witness rows columns)))
                             (built (if permutation
                                   (gerbil-ascent-shared-index-build rows permutation)
                                   (gerbil-ascent-physical-index-build provider rows columns))))
                        ;; Failed builds keep the old version and lookup. Publish
                        ;; both only after the provider has returned successfully.
                        (physical-index-entry-lookup-set! entry built)
                        (physical-index-entry-witness-set! entry members)
                        (physical-index-entry-version-set! entry version)
                        built))))
              ;; Only this trusted representation consumes a scalar. Custom
              ;; receivers retain list keys, callbacks and their lookup order.
              (if (and (not permutation) (gerbil-ascent-canonical-hash-index-provider? provider)
                       (null? (cdr columns)))
                (gerbil-ascent-physical-index-single-rows
                 lookup (gerbil-ascent-index-value
                         (car (vector-ref atom 4)) environment
                         (and slot-terms (car slot-terms))))
                (let (key (if slot-terms
                            (gerbil-ascent-index-key
                             (vector-ref atom 1) columns environment slot-terms)
                            (gerbil-ascent-index-key/terms
                             (vector-ref atom 4) environment)))
                  (if permutation
                    (gerbil-ascent-shared-index-rows lookup columns key)
                    (if (gerbil-ascent-canonical-hash-index-provider? provider)
                      (gerbil-ascent-physical-index-rows provider lookup key)
                      ;; Open reads may mutate private state before raising or
                      ;; returning a rejected packet. Revoke the shared entry
                      ;; so every alias rebuilds from committed rows on retry.
                      (with-catch
                       (lambda (failure)
                         (physical-index-entry-version-set! entry #f)
                         (raise failure))
                       (lambda ()
                         (checked-provider-rows
                          (gerbil-ascent-physical-index-rows provider lookup key)
                          (vector-ref atom 1)
                          (physical-index-entry-witness entry) key)))))))))))))
      (def (advance-all-indexes! index new-rows (reverse-order? #f))
        (let (cache (and all-indexes (vector-ref all-indexes index)))
          (when (and cache (pair? new-rows))
            (let ((rows (if reverse-order? (reverse new-rows) new-rows))
                  (version (vector-ref all-version index))
                  (provider (vector-ref index-providers index)))
              (hash-for-each
               (lambda (columns entry)
                 (when (and (physical-index-entry-version entry)
                            (= (physical-index-entry-version entry) version))
                   ;; A provider may mutate its lookup before raising. Revoke
                   ;; the old version before dispatch so failure forces rebuild
                   ;; from still-committed rows on the next read.
                   (physical-index-entry-version-set! entry #f)
                   (let (extended (if (physical-index-entry-shared? entry)
                                   (gerbil-ascent-shared-index-extend! (physical-index-entry-lookup entry) rows)
                                   (gerbil-ascent-physical-index-extend!
                                    provider (physical-index-entry-lookup entry) rows columns)))
                     (physical-index-entry-lookup-set! entry extended)
                     (when (physical-index-entry-witness entry)
                       (extend-provider-row-witness!
                        (physical-index-entry-witness entry) rows columns))
                     (physical-index-entry-version-set! entry (+ version 1)))))
               cache)))))
    (make-row-indexes indexed-rows advance-all-indexes! plan! visit-parts)))
