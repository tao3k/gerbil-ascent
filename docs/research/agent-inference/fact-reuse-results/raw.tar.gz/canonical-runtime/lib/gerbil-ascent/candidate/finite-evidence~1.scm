(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38251_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38253_|
    (##structure
     gx#syntax-quote::t
     'make-finite-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38255_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38257_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38258_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38259_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38260_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38261_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38262_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-program
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38263_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38264_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38265_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-closure
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38267_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38268_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38269_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38270_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38271_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38272_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-program-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38273_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38274_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38275_|
    (##structure
     gx#syntax-quote::t
     'finite-evidence-closure-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38277_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38278_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38279_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38280_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38281_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38282_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-program
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38283_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38284_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38285_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-closure
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38287_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38288_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38289_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38290_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38291_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38292_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-program-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38293_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38294_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38295_|
    (##structure
     gx#syntax-quote::t
     '&finite-evidence-closure-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38297_|
    (##structure
     gx#syntax-quote::t
     'replay-relation::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38299_|
    (##structure
     gx#syntax-quote::t
     'make-replay-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38301_|
    (##structure
     gx#syntax-quote::t
     'replay-relation?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38303_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-arity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38304_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-reversed
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38305_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-present
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38306_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-frontier
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38307_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-dirty?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38309_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-arity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38310_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-reversed-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38311_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-present-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38312_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-frontier-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38313_|
    (##structure
     gx#syntax-quote::t
     'replay-relation-dirty?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38315_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-arity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38316_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-reversed
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38317_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-present
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38318_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-frontier
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38319_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-dirty?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38321_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-arity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38322_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-reversed-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38323_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-present-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38324_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-frontier-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-evidence[1]#_g38325_|
    (##structure
     gx#syntax-quote::t
     '&replay-relation-dirty?-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/finite-evidence[:0:]#finite-evidence|
      (let ((__obj38089
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj38089
           'gerbil-ascent/candidate/finite-evidence#finite-evidence::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38089 'finite-evidence '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj38089
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    program
                    query
                    work-budget
                    closure)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj38089
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    program
                    query
                    work-budget
                    closure)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38089 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38089 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38089 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38089 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38089 '#f '13 '#f '#f))
        (let ((__tmp38250
               |gerbil-ascent/candidate/finite-evidence[1]#_g38251_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj38089 __tmp38250 '4 '#f '#f))
        (let ((__tmp38252
               |gerbil-ascent/candidate/finite-evidence[1]#_g38253_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj38089 __tmp38252 '14 '#f '#f))
        (let ((__tmp38254
               |gerbil-ascent/candidate/finite-evidence[1]#_g38255_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj38089 __tmp38254 '15 '#f '#f))
        (let ((__tmp38256
               (cons (cons 'status
                           |gerbil-ascent/candidate/finite-evidence[1]#_g38257_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g38258_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g38259_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g38260_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g38261_|)
                                             (cons (cons 'program
                                                         |gerbil-ascent/candidate/finite-evidence[1]#_g38262_|)
                                                   (cons (cons 'query
                                                               |gerbil-ascent/candidate/finite-evidence[1]#_g38263_|)
                                                         (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/finite-evidence[1]#_g38264_|)
                       (cons (cons 'closure
                                   |gerbil-ascent/candidate/finite-evidence[1]#_g38265_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj38089 __tmp38256 '16 '#f '#f))
        (let ((__tmp38266
               (cons (cons 'status
                           |gerbil-ascent/candidate/finite-evidence[1]#_g38267_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g38268_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g38269_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g38270_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g38271_|)
                                             (cons (cons 'program
                                                         |gerbil-ascent/candidate/finite-evidence[1]#_g38272_|)
                                                   (cons (cons 'query
                                                               |gerbil-ascent/candidate/finite-evidence[1]#_g38273_|)
                                                         (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/finite-evidence[1]#_g38274_|)
                       (cons (cons 'closure
                                   |gerbil-ascent/candidate/finite-evidence[1]#_g38275_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj38089 __tmp38266 '17 '#f '#f))
        (let ((__tmp38276
               (cons (cons 'status
                           |gerbil-ascent/candidate/finite-evidence[1]#_g38277_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g38278_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g38279_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g38280_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g38281_|)
                                             (cons (cons 'program
                                                         |gerbil-ascent/candidate/finite-evidence[1]#_g38282_|)
                                                   (cons (cons 'query
                                                               |gerbil-ascent/candidate/finite-evidence[1]#_g38283_|)
                                                         (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/finite-evidence[1]#_g38284_|)
                       (cons (cons 'closure
                                   |gerbil-ascent/candidate/finite-evidence[1]#_g38285_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj38089 __tmp38276 '18 '#f '#f))
        (let ((__tmp38286
               (cons (cons 'status
                           |gerbil-ascent/candidate/finite-evidence[1]#_g38287_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g38288_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g38289_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g38290_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g38291_|)
                                             (cons (cons 'program
                                                         |gerbil-ascent/candidate/finite-evidence[1]#_g38292_|)
                                                   (cons (cons 'query
                                                               |gerbil-ascent/candidate/finite-evidence[1]#_g38293_|)
                                                         (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/finite-evidence[1]#_g38294_|)
                       (cons (cons 'closure
                                   |gerbil-ascent/candidate/finite-evidence[1]#_g38295_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj38089 __tmp38286 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38089 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38089 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38089 '() '21 '#f '#f))
        __obj38089))
    (define |gerbil-ascent/candidate/finite-evidence[:0:]#replay-relation|
      (let ((__obj38090
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj38090
           'gerbil-ascent/candidate/finite-evidence#replay-relation::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38090 'replay-relation '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj38090
           '(arity reversed present frontier dirty?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj38090
           '(arity reversed present frontier dirty?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38090 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38090 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38090 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38090 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38090 '#f '13 '#f '#f))
        (let ((__tmp38296
               |gerbil-ascent/candidate/finite-evidence[1]#_g38297_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj38090 __tmp38296 '4 '#f '#f))
        (let ((__tmp38298
               |gerbil-ascent/candidate/finite-evidence[1]#_g38299_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj38090 __tmp38298 '14 '#f '#f))
        (let ((__tmp38300
               |gerbil-ascent/candidate/finite-evidence[1]#_g38301_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj38090 __tmp38300 '15 '#f '#f))
        (let ((__tmp38302
               (cons (cons 'arity
                           |gerbil-ascent/candidate/finite-evidence[1]#_g38303_|)
                     (cons (cons 'reversed
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g38304_|)
                           (cons (cons 'present
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g38305_|)
                                 (cons (cons 'frontier
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g38306_|)
                                       (cons (cons 'dirty?
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g38307_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj38090 __tmp38302 '16 '#f '#f))
        (let ((__tmp38308
               (cons (cons 'arity
                           |gerbil-ascent/candidate/finite-evidence[1]#_g38309_|)
                     (cons (cons 'reversed
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g38310_|)
                           (cons (cons 'present
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g38311_|)
                                 (cons (cons 'frontier
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g38312_|)
                                       (cons (cons 'dirty?
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g38313_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj38090 __tmp38308 '17 '#f '#f))
        (let ((__tmp38314
               (cons (cons 'arity
                           |gerbil-ascent/candidate/finite-evidence[1]#_g38315_|)
                     (cons (cons 'reversed
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g38316_|)
                           (cons (cons 'present
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g38317_|)
                                 (cons (cons 'frontier
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g38318_|)
                                       (cons (cons 'dirty?
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g38319_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj38090 __tmp38314 '18 '#f '#f))
        (let ((__tmp38320
               (cons (cons 'arity
                           |gerbil-ascent/candidate/finite-evidence[1]#_g38321_|)
                     (cons (cons 'reversed
                                 |gerbil-ascent/candidate/finite-evidence[1]#_g38322_|)
                           (cons (cons 'present
                                       |gerbil-ascent/candidate/finite-evidence[1]#_g38323_|)
                                 (cons (cons 'frontier
                                             |gerbil-ascent/candidate/finite-evidence[1]#_g38324_|)
                                       (cons (cons 'dirty?
                                                   |gerbil-ascent/candidate/finite-evidence[1]#_g38325_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj38090 __tmp38320 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38090 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38090 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38090 '() '21 '#f '#f))
        __obj38090))))
