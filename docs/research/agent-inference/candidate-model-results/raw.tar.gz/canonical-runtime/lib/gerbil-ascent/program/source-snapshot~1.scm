(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/source-snapshot[1]#_g36623_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36625_|
    (##structure
     gx#syntax-quote::t
     'make-source-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36627_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36629_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-template
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36630_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-program
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36631_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-declarations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36632_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36633_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-materializations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36635_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-template-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36636_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-program-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36637_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-declarations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36638_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36639_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-materializations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36641_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-template
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36642_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-program
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36643_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-declarations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36644_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36645_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-materializations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36647_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-template-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36648_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-program-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36649_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-declarations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36650_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36651_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-materializations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36653_|
    (##structure
     gx#syntax-quote::t
     'source-materialization::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36655_|
    (##structure
     gx#syntax-quote::t
     'make-source-materialization
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36657_|
    (##structure
     gx#syntax-quote::t
     'source-materialization?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36659_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-base
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36660_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-additions
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36661_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36662_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-scalar?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36664_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-base-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36665_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-additions-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36666_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36667_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-scalar?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36669_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-base
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36670_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-additions
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36671_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36672_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-scalar?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36674_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-base-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36675_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-additions-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36676_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36677_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-scalar?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36679_|
    (gx#core-deserialize-mark
     '(0
       ($%arg11946 . _%$%arg1194612017%_)
       (id . _%id11970%_)
       (arg . _%arg12033%_)
       ($%arg11945 . _%$%arg1194512003%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36680_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36679_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36683_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36684_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36683_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36686_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36683_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36688_|
    (gx#core-deserialize-mark
     '(0
       ($%arg12066 . _%$%arg1206612123%_)
       (id . _%id12090%_)
       (arg . _%arg12153%_)
       ($%arg12067 . _%$%arg1206712137%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36689_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36688_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36692_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36693_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36692_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36695_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36692_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36697_|
    (gx#core-deserialize-mark
     '(0
       ($%arg12187 . _%$%arg1218712257%_)
       ($%arg12186 . _%$%arg1218612243%_)
       (id . _%id12210%_)
       (arg . _%arg12273%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36698_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36697_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36701_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36702_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36701_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36704_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36701_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36706_|
    (gx#core-deserialize-mark
     '(0
       ($%arg12306 . _%$%arg1230612363%_)
       ($%arg12307 . _%$%arg1230712377%_)
       (id . _%id12330%_)
       (arg . _%arg12393%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36707_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36706_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36710_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36711_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36710_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36713_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36710_|)))
  (begin
    (define |gerbil-ascent/program/source-snapshot[:0:]#source-snapshot|
      (let ((__obj36502
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36502
           'gerbil-ascent/program/source-snapshot#source-snapshot::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36502 'source-snapshot '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36502
           '(template program declarations rows materializations)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36502
           '(template program declarations rows materializations)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36502 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36502 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36502 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36502 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36502 '#f '13 '#f '#f))
        (let ((__tmp36622 |gerbil-ascent/program/source-snapshot[1]#_g36623_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36502 __tmp36622 '4 '#f '#f))
        (let ((__tmp36624 |gerbil-ascent/program/source-snapshot[1]#_g36625_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36502 __tmp36624 '14 '#f '#f))
        (let ((__tmp36626 |gerbil-ascent/program/source-snapshot[1]#_g36627_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36502 __tmp36626 '15 '#f '#f))
        (let ((__tmp36628
               (cons (cons 'template
                           |gerbil-ascent/program/source-snapshot[1]#_g36629_|)
                     (cons (cons 'program
                                 |gerbil-ascent/program/source-snapshot[1]#_g36630_|)
                           (cons (cons 'declarations
                                       |gerbil-ascent/program/source-snapshot[1]#_g36631_|)
                                 (cons (cons 'rows
                                             |gerbil-ascent/program/source-snapshot[1]#_g36632_|)
                                       (cons (cons 'materializations
                                                   |gerbil-ascent/program/source-snapshot[1]#_g36633_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36502 __tmp36628 '16 '#f '#f))
        (let ((__tmp36634
               (cons (cons 'template
                           |gerbil-ascent/program/source-snapshot[1]#_g36635_|)
                     (cons (cons 'program
                                 |gerbil-ascent/program/source-snapshot[1]#_g36636_|)
                           (cons (cons 'declarations
                                       |gerbil-ascent/program/source-snapshot[1]#_g36637_|)
                                 (cons (cons 'rows
                                             |gerbil-ascent/program/source-snapshot[1]#_g36638_|)
                                       (cons (cons 'materializations
                                                   |gerbil-ascent/program/source-snapshot[1]#_g36639_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36502 __tmp36634 '17 '#f '#f))
        (let ((__tmp36640
               (cons (cons 'template
                           |gerbil-ascent/program/source-snapshot[1]#_g36641_|)
                     (cons (cons 'program
                                 |gerbil-ascent/program/source-snapshot[1]#_g36642_|)
                           (cons (cons 'declarations
                                       |gerbil-ascent/program/source-snapshot[1]#_g36643_|)
                                 (cons (cons 'rows
                                             |gerbil-ascent/program/source-snapshot[1]#_g36644_|)
                                       (cons (cons 'materializations
                                                   |gerbil-ascent/program/source-snapshot[1]#_g36645_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36502 __tmp36640 '18 '#f '#f))
        (let ((__tmp36646
               (cons (cons 'template
                           |gerbil-ascent/program/source-snapshot[1]#_g36647_|)
                     (cons (cons 'program
                                 |gerbil-ascent/program/source-snapshot[1]#_g36648_|)
                           (cons (cons 'declarations
                                       |gerbil-ascent/program/source-snapshot[1]#_g36649_|)
                                 (cons (cons 'rows
                                             |gerbil-ascent/program/source-snapshot[1]#_g36650_|)
                                       (cons (cons 'materializations
                                                   |gerbil-ascent/program/source-snapshot[1]#_g36651_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36502 __tmp36646 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36502 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36502 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36502 '() '21 '#f '#f))
        __obj36502))
    (define |gerbil-ascent/program/source-snapshot[:0:]#source-materialization|
      (let ((__obj36503
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36503
           'gerbil-ascent/program/source-snapshot#source-materialization::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36503
           'source-materialization
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36503
           '(base additions rows scalar?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36503
           '(base additions rows scalar?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36503 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36503 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36503 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36503 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36503 '#f '13 '#f '#f))
        (let ((__tmp36652 |gerbil-ascent/program/source-snapshot[1]#_g36653_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36503 __tmp36652 '4 '#f '#f))
        (let ((__tmp36654 |gerbil-ascent/program/source-snapshot[1]#_g36655_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36503 __tmp36654 '14 '#f '#f))
        (let ((__tmp36656 |gerbil-ascent/program/source-snapshot[1]#_g36657_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36503 __tmp36656 '15 '#f '#f))
        (let ((__tmp36658
               (cons (cons 'base
                           |gerbil-ascent/program/source-snapshot[1]#_g36659_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-snapshot[1]#_g36660_|)
                           (cons (cons 'rows
                                       |gerbil-ascent/program/source-snapshot[1]#_g36661_|)
                                 (cons (cons 'scalar?
                                             |gerbil-ascent/program/source-snapshot[1]#_g36662_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36503 __tmp36658 '16 '#f '#f))
        (let ((__tmp36663
               (cons (cons 'base
                           |gerbil-ascent/program/source-snapshot[1]#_g36664_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-snapshot[1]#_g36665_|)
                           (cons (cons 'rows
                                       |gerbil-ascent/program/source-snapshot[1]#_g36666_|)
                                 (cons (cons 'scalar?
                                             |gerbil-ascent/program/source-snapshot[1]#_g36667_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36503 __tmp36663 '17 '#f '#f))
        (let ((__tmp36668
               (cons (cons 'base
                           |gerbil-ascent/program/source-snapshot[1]#_g36669_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-snapshot[1]#_g36670_|)
                           (cons (cons 'rows
                                       |gerbil-ascent/program/source-snapshot[1]#_g36671_|)
                                 (cons (cons 'scalar?
                                             |gerbil-ascent/program/source-snapshot[1]#_g36672_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36503 __tmp36668 '18 '#f '#f))
        (let ((__tmp36673
               (cons (cons 'base
                           |gerbil-ascent/program/source-snapshot[1]#_g36674_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-snapshot[1]#_g36675_|)
                           (cons (cons 'rows
                                       |gerbil-ascent/program/source-snapshot[1]#_g36676_|)
                                 (cons (cons 'scalar?
                                             |gerbil-ascent/program/source-snapshot[1]#_g36677_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36503 __tmp36673 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36503 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36503 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36503 '() '21 '#f '#f))
        __obj36503))
    (define |gerbil-ascent/program/source-snapshot[:0:]#@materialize-source-log|
      (lambda (_%$stx11927%_)
        (let* ((_%__stx3639936400%_ _%$stx11927%_)
               (_%$%g1193211953%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3639936400%_)))))
          (let ((_%__kont3640236403%_
                 (lambda (_%$%g1193412019%_)
                   (cons (let ((__tmp36678
                                |gerbil-ascent/program/source-snapshot[1]#_g36680_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp36678
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'base))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'additions))
                                                 (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'previous))
                                                       '())))
                                     (cons (let ((__tmp36681
                                                  (lambda (_%$%g1203412037%_
                                                           _%$%g1203512040%_)
                                                    (cons _%$%g1203412037%_
                                                          _%$%g1203512040%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp36681
                                              '()
                                              _%$%g1193412019%_))
                                           '()))
                               (cons (cons (let ((__tmp36682
                                                  |gerbil-ascent/program/source-snapshot[1]#_g36684_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp36682
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'previous))
                     (cons (let ((__tmp36685
                                  |gerbil-ascent/program/source-snapshot[1]#_g36686_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp36685 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0
                                    '#f
                                    'source-materialization))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f '__materialize-source-log))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'base))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'additions))
                                 (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'previous))
                                       '()))))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3640636407%_
                 (lambda (_%$%g1194711960%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0 '#f 'materialize-source-log)))))
            (let* ((_%$%g1193111972%_
                    (lambda ()
                      (let ((_%$%g1194711960%_ _%__stx3639936400%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1194711960%_))
                            (_%__kont3640636407%_ _%$%g1194711960%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1193211953%_))))))
                   (_%__match3642236423%_
                    (lambda (_%$%e1193511979%_
                             _%$%hd1193611983%_
                             _%$%tl1193711986%_
                             _%__splice3640436405%_
                             _%$%target1193811989%_
                             _%$%tl1194011992%_)
                      (letrec ((_%$%loop1194111995%_
                                (lambda (_%$%hd1193911999%_
                                         _%$%arg1194512002%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1193911999%_))
                                      (let ((_%$%e1194212005%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1193911999%_))))
                                        (let ((_%$%lp-tl1194412012%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1194212005%_)))
                                              (_%$%lp-hd1194312009%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1194212005%_))))
                                          (_%$%loop1194111995%_
                                           _%$%lp-tl1194412012%_
                                           (cons _%$%lp-hd1194312009%_
                                                 _%$%arg1194512002%_))))
                                      (let ((_%$%arg1194612015%_
                                             (reverse _%$%arg1194512002%_)))
                                        (_%__kont3640236403%_
                                         _%$%arg1194612015%_))))))
                        (_%$%loop1194111995%_ _%$%target1193811989%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3639936400%_))
                  (let ((_%$%e1193511979%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3639936400%_))))
                    (let ((_%$%tl1193711986%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1193511979%_)))
                          (_%$%hd1193611983%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1193511979%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1193711986%_))
                          (let ((_%__splice3640436405%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1193711986%_
                                    '0))))
                            (let ((_%$%tl1194011992%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3640436405%_ '1)))
                                  (_%$%target1193811989%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3640436405%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1194011992%_))
                                  (_%__match3642236423%_
                                   _%$%e1193511979%_
                                   _%$%hd1193611983%_
                                   _%$%tl1193711986%_
                                   _%__splice3640436405%_
                                   _%$%target1193811989%_
                                   _%$%tl1194011992%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1193111972%_)))))
                          (let () (declare (not safe)) (_%$%g1193111972%_)))))
                  (let () (declare (not safe)) (_%$%g1193111972%_))))))))
    (define |gerbil-ascent/program/source-snapshot[:0:]#@gerbil-ascent-source-log-snapshot-equal?|
      (lambda (_%$stx12048%_)
        (let* ((_%__stx3642536426%_ _%$stx12048%_)
               (_%$%g1205312074%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3642536426%_)))))
          (let ((_%__kont3642836429%_
                 (lambda (_%$%g1205512139%_)
                   (cons (let ((__tmp36687
                                |gerbil-ascent/program/source-snapshot[1]#_g36689_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp36687
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'snapshot))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'candidate))
                                                 (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'index))
                                                       (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'log))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'rows))
                           '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     (cons (let ((__tmp36690
                                                  (lambda (_%$%g1215412157%_
                                                           _%$%g1215512160%_)
                                                    (cons _%$%g1215412157%_
                                                          _%$%g1215512160%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp36690
                                              '()
                                              _%$%g1205512139%_))
                                           '()))
                               (cons (cons (let ((__tmp36691
                                                  |gerbil-ascent/program/source-snapshot[1]#_g36693_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp36691
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'snapshot))
                     (cons (let ((__tmp36694
                                  |gerbil-ascent/program/source-snapshot[1]#_g36695_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp36694 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'source-snapshot))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0
                        '#f
                        '__gerbil-ascent-source-log-snapshot-equal?))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'snapshot))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'candidate))
                                 (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'index))
                                       (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f 'log))
                                             (cons (let ()
                                                     (declare (not safe))
                                                     (gx#datum->syntax__0
                                                      '#f
                                                      'rows))
                                                   '()))))))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3643236433%_
                 (lambda (_%$%g1206812081%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0
                      '#f
                      'gerbil-ascent-source-log-snapshot-equal?)))))
            (let* ((_%$%g1205212092%_
                    (lambda ()
                      (let ((_%$%g1206812081%_ _%__stx3642536426%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1206812081%_))
                            (_%__kont3643236433%_ _%$%g1206812081%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1205312074%_))))))
                   (_%__match3644836449%_
                    (lambda (_%$%e1205612099%_
                             _%$%hd1205712103%_
                             _%$%tl1205812106%_
                             _%__splice3643036431%_
                             _%$%target1205912109%_
                             _%$%tl1206112112%_)
                      (letrec ((_%$%loop1206212115%_
                                (lambda (_%$%hd1206012119%_
                                         _%$%arg1206612122%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1206012119%_))
                                      (let ((_%$%e1206312125%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1206012119%_))))
                                        (let ((_%$%lp-tl1206512132%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1206312125%_)))
                                              (_%$%lp-hd1206412129%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1206312125%_))))
                                          (_%$%loop1206212115%_
                                           _%$%lp-tl1206512132%_
                                           (cons _%$%lp-hd1206412129%_
                                                 _%$%arg1206612122%_))))
                                      (let ((_%$%arg1206712135%_
                                             (reverse _%$%arg1206612122%_)))
                                        (_%__kont3642836429%_
                                         _%$%arg1206712135%_))))))
                        (_%$%loop1206212115%_ _%$%target1205912109%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3642536426%_))
                  (let ((_%$%e1205612099%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3642536426%_))))
                    (let ((_%$%tl1205812106%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1205612099%_)))
                          (_%$%hd1205712103%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1205612099%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1205812106%_))
                          (let ((_%__splice3643036431%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1205812106%_
                                    '0))))
                            (let ((_%$%tl1206112112%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3643036431%_ '1)))
                                  (_%$%target1205912109%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3643036431%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1206112112%_))
                                  (_%__match3644836449%_
                                   _%$%e1205612099%_
                                   _%$%hd1205712103%_
                                   _%$%tl1205812106%_
                                   _%__splice3643036431%_
                                   _%$%target1205912109%_
                                   _%$%tl1206112112%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1205212092%_)))))
                          (let () (declare (not safe)) (_%$%g1205212092%_)))))
                  (let () (declare (not safe)) (_%$%g1205212092%_))))))))
    (define |gerbil-ascent/program/source-snapshot[:0:]#@gerbil-ascent-source-snapshot-scalar?|
      (lambda (_%$stx12168%_)
        (let* ((_%__stx3645136452%_ _%$stx12168%_)
               (_%$%g1217312194%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3645136452%_)))))
          (let ((_%__kont3645436455%_
                 (lambda (_%$%g1217512259%_)
                   (cons (let ((__tmp36696
                                |gerbil-ascent/program/source-snapshot[1]#_g36698_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp36696
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'snapshot))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'candidate))
                                                 (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'index))
                                                       (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'rows))
                     '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     (cons (let ((__tmp36699
                                                  (lambda (_%$%g1227412277%_
                                                           _%$%g1227512280%_)
                                                    (cons _%$%g1227412277%_
                                                          _%$%g1227512280%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp36699
                                              '()
                                              _%$%g1217512259%_))
                                           '()))
                               (cons (cons (let ((__tmp36700
                                                  |gerbil-ascent/program/source-snapshot[1]#_g36702_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp36700
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'snapshot))
                     (cons (let ((__tmp36703
                                  |gerbil-ascent/program/source-snapshot[1]#_g36704_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp36703 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'source-snapshot))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0
                        '#f
                        '__gerbil-ascent-source-snapshot-scalar?))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'snapshot))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'candidate))
                                 (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'index))
                                       (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f 'rows))
                                             '())))))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3645836459%_
                 (lambda (_%$%g1218812201%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0
                      '#f
                      'gerbil-ascent-source-snapshot-scalar?)))))
            (let* ((_%$%g1217212212%_
                    (lambda ()
                      (let ((_%$%g1218812201%_ _%__stx3645136452%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1218812201%_))
                            (_%__kont3645836459%_ _%$%g1218812201%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1217312194%_))))))
                   (_%__match3647436475%_
                    (lambda (_%$%e1217612219%_
                             _%$%hd1217712223%_
                             _%$%tl1217812226%_
                             _%__splice3645636457%_
                             _%$%target1217912229%_
                             _%$%tl1218112232%_)
                      (letrec ((_%$%loop1218212235%_
                                (lambda (_%$%hd1218012239%_
                                         _%$%arg1218612242%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1218012239%_))
                                      (let ((_%$%e1218312245%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1218012239%_))))
                                        (let ((_%$%lp-tl1218512252%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1218312245%_)))
                                              (_%$%lp-hd1218412249%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1218312245%_))))
                                          (_%$%loop1218212235%_
                                           _%$%lp-tl1218512252%_
                                           (cons _%$%lp-hd1218412249%_
                                                 _%$%arg1218612242%_))))
                                      (let ((_%$%arg1218712255%_
                                             (reverse _%$%arg1218612242%_)))
                                        (_%__kont3645436455%_
                                         _%$%arg1218712255%_))))))
                        (_%$%loop1218212235%_ _%$%target1217912229%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3645136452%_))
                  (let ((_%$%e1217612219%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3645136452%_))))
                    (let ((_%$%tl1217812226%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1217612219%_)))
                          (_%$%hd1217712223%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1217612219%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1217812226%_))
                          (let ((_%__splice3645636457%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1217812226%_
                                    '0))))
                            (let ((_%$%tl1218112232%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3645636457%_ '1)))
                                  (_%$%target1217912229%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3645636457%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1218112232%_))
                                  (_%__match3647436475%_
                                   _%$%e1217612219%_
                                   _%$%hd1217712223%_
                                   _%$%tl1217812226%_
                                   _%__splice3645636457%_
                                   _%$%target1217912229%_
                                   _%$%tl1218112232%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1217212212%_)))))
                          (let () (declare (not safe)) (_%$%g1217212212%_)))))
                  (let () (declare (not safe)) (_%$%g1217212212%_))))))))
    (define |gerbil-ascent/program/source-snapshot[:0:]#@gerbil-ascent-prepare-source-log-snapshot|
      (lambda (_%$stx12288%_)
        (let* ((_%__stx3647736478%_ _%$stx12288%_)
               (_%$%g1229312314%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3647736478%_)))))
          (let ((_%__kont3648036481%_
                 (lambda (_%$%g1229512379%_)
                   (cons (let ((__tmp36705
                                |gerbil-ascent/program/source-snapshot[1]#_g36707_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp36705
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'snapshot))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'logs))
                                                 '()))
                                     (cons (let ((__tmp36708
                                                  (lambda (_%$%g1239412397%_
                                                           _%$%g1239512400%_)
                                                    (cons _%$%g1239412397%_
                                                          _%$%g1239512400%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp36708
                                              '()
                                              _%$%g1229512379%_))
                                           '()))
                               (cons (cons (let ((__tmp36709
                                                  |gerbil-ascent/program/source-snapshot[1]#_g36711_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp36709
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'snapshot))
                     (cons (let ((__tmp36712
                                  |gerbil-ascent/program/source-snapshot[1]#_g36713_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp36712 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'source-snapshot))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0
                        '#f
                        '__gerbil-ascent-prepare-source-log-snapshot))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'snapshot))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'logs))
                                 '())))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3648436485%_
                 (lambda (_%$%g1230812321%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0
                      '#f
                      'gerbil-ascent-prepare-source-log-snapshot)))))
            (let* ((_%$%g1229212332%_
                    (lambda ()
                      (let ((_%$%g1230812321%_ _%__stx3647736478%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1230812321%_))
                            (_%__kont3648436485%_ _%$%g1230812321%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1229312314%_))))))
                   (_%__match3650036501%_
                    (lambda (_%$%e1229612339%_
                             _%$%hd1229712343%_
                             _%$%tl1229812346%_
                             _%__splice3648236483%_
                             _%$%target1229912349%_
                             _%$%tl1230112352%_)
                      (letrec ((_%$%loop1230212355%_
                                (lambda (_%$%hd1230012359%_
                                         _%$%arg1230612362%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1230012359%_))
                                      (let ((_%$%e1230312365%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1230012359%_))))
                                        (let ((_%$%lp-tl1230512372%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1230312365%_)))
                                              (_%$%lp-hd1230412369%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1230312365%_))))
                                          (_%$%loop1230212355%_
                                           _%$%lp-tl1230512372%_
                                           (cons _%$%lp-hd1230412369%_
                                                 _%$%arg1230612362%_))))
                                      (let ((_%$%arg1230712375%_
                                             (reverse _%$%arg1230612362%_)))
                                        (_%__kont3648036481%_
                                         _%$%arg1230712375%_))))))
                        (_%$%loop1230212355%_ _%$%target1229912349%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3647736478%_))
                  (let ((_%$%e1229612339%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3647736478%_))))
                    (let ((_%$%tl1229812346%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1229612339%_)))
                          (_%$%hd1229712343%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1229612339%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1229812346%_))
                          (let ((_%__splice3648236483%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1229812346%_
                                    '0))))
                            (let ((_%$%tl1230112352%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3648236483%_ '1)))
                                  (_%$%target1229912349%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3648236483%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1230112352%_))
                                  (_%__match3650036501%_
                                   _%$%e1229612339%_
                                   _%$%hd1229712343%_
                                   _%$%tl1229812346%_
                                   _%__splice3648236483%_
                                   _%$%target1229912349%_
                                   _%$%tl1230112352%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1229212332%_)))))
                          (let () (declare (not safe)) (_%$%g1229212332%_)))))
                  (let () (declare (not safe)) (_%$%g1229212332%_))))))))))
