(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/trrel[1]#_g34857_|
    (##structure
     gx#syntax-quote::t
     'trrel-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34859_|
    (##structure
     gx#syntax-quote::t
     'make-trrel-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34861_|
    (##structure
     gx#syntax-quote::t
     'trrel-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34863_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-known
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34864_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34865_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-successors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34867_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-known-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34868_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34869_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-successors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34871_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-known
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34872_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34873_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-successors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34875_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-known-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34876_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g34877_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-successors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[:0:]#trrel-state|
    (let ((__obj34729
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34729
         'gerbil-ascent/table/trrel#trrel-state::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34729 'trrel-state '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34729
         '(known predecessors successors)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34729
         '(known predecessors successors)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34729 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34729 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34729 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34729 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34729 '#f '13 '#f '#f))
      (let ((__tmp34856 |gerbil-ascent/table/trrel[1]#_g34857_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34729 __tmp34856 '4 '#f '#f))
      (let ((__tmp34858 |gerbil-ascent/table/trrel[1]#_g34859_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34729 __tmp34858 '14 '#f '#f))
      (let ((__tmp34860 |gerbil-ascent/table/trrel[1]#_g34861_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34729 __tmp34860 '15 '#f '#f))
      (let ((__tmp34862
             (cons (cons 'known |gerbil-ascent/table/trrel[1]#_g34863_|)
                   (cons (cons 'predecessors
                               |gerbil-ascent/table/trrel[1]#_g34864_|)
                         (cons (cons 'successors
                                     |gerbil-ascent/table/trrel[1]#_g34865_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34729 __tmp34862 '16 '#f '#f))
      (let ((__tmp34866
             (cons (cons 'known |gerbil-ascent/table/trrel[1]#_g34867_|)
                   (cons (cons 'predecessors
                               |gerbil-ascent/table/trrel[1]#_g34868_|)
                         (cons (cons 'successors
                                     |gerbil-ascent/table/trrel[1]#_g34869_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34729 __tmp34866 '17 '#f '#f))
      (let ((__tmp34870
             (cons (cons 'known |gerbil-ascent/table/trrel[1]#_g34871_|)
                   (cons (cons 'predecessors
                               |gerbil-ascent/table/trrel[1]#_g34872_|)
                         (cons (cons 'successors
                                     |gerbil-ascent/table/trrel[1]#_g34873_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34729 __tmp34870 '18 '#f '#f))
      (let ((__tmp34874
             (cons (cons 'known |gerbil-ascent/table/trrel[1]#_g34875_|)
                   (cons (cons 'predecessors
                               |gerbil-ascent/table/trrel[1]#_g34876_|)
                         (cons (cons 'successors
                                     |gerbil-ascent/table/trrel[1]#_g34877_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34729 __tmp34874 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34729 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34729 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34729 '() '21 '#f '#f))
      __obj34729)))
