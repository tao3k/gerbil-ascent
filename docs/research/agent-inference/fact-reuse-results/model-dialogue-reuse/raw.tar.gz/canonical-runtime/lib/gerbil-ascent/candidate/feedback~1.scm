(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/feedback[1]#_g34513_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34515_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-feedback
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34517_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34519_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34520_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-reason
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34521_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-missing
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34522_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-extra
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34524_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34525_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-reason-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34526_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-missing-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34527_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-extra-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34529_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34530_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-reason
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34531_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-missing
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34532_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-extra
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34534_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34535_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-reason-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34536_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-missing-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g34537_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-extra-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[:0:]#reasoning-feedback|
    (let ((__obj34474
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34474
         'gerbil-ascent/candidate/feedback#reasoning-feedback::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34474 'reasoning-feedback '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34474
         '(status reason missing extra)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34474
         '(status reason missing extra)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34474 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34474 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34474 '#t '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34474 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34474 '#f '13 '#f '#f))
      (let ((__tmp34512 |gerbil-ascent/candidate/feedback[1]#_g34513_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34474 __tmp34512 '4 '#f '#f))
      (let ((__tmp34514 |gerbil-ascent/candidate/feedback[1]#_g34515_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34474 __tmp34514 '14 '#f '#f))
      (let ((__tmp34516 |gerbil-ascent/candidate/feedback[1]#_g34517_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34474 __tmp34516 '15 '#f '#f))
      (let ((__tmp34518
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g34519_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g34520_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g34521_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g34522_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34474 __tmp34518 '16 '#f '#f))
      (let ((__tmp34523
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g34524_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g34525_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g34526_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g34527_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34474 __tmp34523 '17 '#f '#f))
      (let ((__tmp34528
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g34529_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g34530_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g34531_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g34532_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34474 __tmp34528 '18 '#f '#f))
      (let ((__tmp34533
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g34534_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g34535_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g34536_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g34537_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34474 __tmp34533 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34474 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34474 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34474 '() '21 '#f '#f))
      __obj34474)))
