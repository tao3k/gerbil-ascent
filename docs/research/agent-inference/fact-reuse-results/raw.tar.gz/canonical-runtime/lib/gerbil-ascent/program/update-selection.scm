(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "std/list/list-builder")
    (load-module "gerbil-ascent/program/source-log")
    (load-module "gerbil-ascent/program/source-snapshot")
    (load-module "gerbil-ascent/program/activation")
    (load-module "clan/poo/object")
    (load-module "gerbil-ascent/program/scheme-checked")
    (load-module "gerbil-ascent/core/positive-plan")
    (load-module "gerbil-ascent/core/dependency-graph")
    (load-module "gerbil-ascent/table/provider")
    (load-module "gerbil-ascent/table/storage"))
  (load-module "gerbil-ascent/program/update-selection~0"))
