(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33848_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-flow::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33850_|
    (##structure
     gx#syntax-quote::t
     'make-proof-binding-flow
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33852_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-flow?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33854_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-flow-fresh
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33855_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-flow-head
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33856_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-flow-clauses
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33858_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-flow-fresh-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33859_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-flow-head-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33860_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-flow-clauses-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33862_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-flow-fresh
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33863_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-flow-head
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33864_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-flow-clauses
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33866_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-flow-fresh-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33867_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-flow-head-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33868_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-flow-clauses-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33870_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-clause::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33872_|
    (##structure
     gx#syntax-quote::t
     'make-proof-binding-clause
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33874_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-clause?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33876_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-clause-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33877_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-clause-apply
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33879_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-clause-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33880_|
    (##structure
     gx#syntax-quote::t
     'proof-binding-clause-apply-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33882_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-clause-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33883_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-clause-apply
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33885_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-clause-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/proof-frame[1]#_g33886_|
    (##structure
     gx#syntax-quote::t
     '&proof-binding-clause-apply-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/proof-frame[:0:]#proof-binding-flow|
      (let ((__obj33831
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33831
           'gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33831
           'proof-binding-flow
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33831
           '(fresh head clauses)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33831
           '(fresh head clauses)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33831 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33831 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33831 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33831 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33831 '#f '13 '#f '#f))
        (let ((__tmp33847 |gerbil-ascent/candidate/proof-frame[1]#_g33848_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33831 __tmp33847 '4 '#f '#f))
        (let ((__tmp33849 |gerbil-ascent/candidate/proof-frame[1]#_g33850_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33831 __tmp33849 '14 '#f '#f))
        (let ((__tmp33851 |gerbil-ascent/candidate/proof-frame[1]#_g33852_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33831 __tmp33851 '15 '#f '#f))
        (let ((__tmp33853
               (cons (cons 'fresh
                           |gerbil-ascent/candidate/proof-frame[1]#_g33854_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33855_|)
                           (cons (cons 'clauses
                                       |gerbil-ascent/candidate/proof-frame[1]#_g33856_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33831 __tmp33853 '16 '#f '#f))
        (let ((__tmp33857
               (cons (cons 'fresh
                           |gerbil-ascent/candidate/proof-frame[1]#_g33858_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33859_|)
                           (cons (cons 'clauses
                                       |gerbil-ascent/candidate/proof-frame[1]#_g33860_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33831 __tmp33857 '17 '#f '#f))
        (let ((__tmp33861
               (cons (cons 'fresh
                           |gerbil-ascent/candidate/proof-frame[1]#_g33862_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33863_|)
                           (cons (cons 'clauses
                                       |gerbil-ascent/candidate/proof-frame[1]#_g33864_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33831 __tmp33861 '18 '#f '#f))
        (let ((__tmp33865
               (cons (cons 'fresh
                           |gerbil-ascent/candidate/proof-frame[1]#_g33866_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33867_|)
                           (cons (cons 'clauses
                                       |gerbil-ascent/candidate/proof-frame[1]#_g33868_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33831 __tmp33865 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33831 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33831 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33831 '() '21 '#f '#f))
        __obj33831))
    (define |gerbil-ascent/candidate/proof-frame[:0:]#proof-binding-clause|
      (let ((__obj33832
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33832
           'gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33832
           'proof-binding-clause
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33832 '(relation apply) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33832 '(relation apply) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33832 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33832 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33832 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33832 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33832 '#f '13 '#f '#f))
        (let ((__tmp33869 |gerbil-ascent/candidate/proof-frame[1]#_g33870_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33832 __tmp33869 '4 '#f '#f))
        (let ((__tmp33871 |gerbil-ascent/candidate/proof-frame[1]#_g33872_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33832 __tmp33871 '14 '#f '#f))
        (let ((__tmp33873 |gerbil-ascent/candidate/proof-frame[1]#_g33874_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33832 __tmp33873 '15 '#f '#f))
        (let ((__tmp33875
               (cons (cons 'relation
                           |gerbil-ascent/candidate/proof-frame[1]#_g33876_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33877_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33832 __tmp33875 '16 '#f '#f))
        (let ((__tmp33878
               (cons (cons 'relation
                           |gerbil-ascent/candidate/proof-frame[1]#_g33879_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33880_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33832 __tmp33878 '17 '#f '#f))
        (let ((__tmp33881
               (cons (cons 'relation
                           |gerbil-ascent/candidate/proof-frame[1]#_g33882_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33883_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33832 __tmp33881 '18 '#f '#f))
        (let ((__tmp33884
               (cons (cons 'relation
                           |gerbil-ascent/candidate/proof-frame[1]#_g33885_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/proof-frame[1]#_g33886_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33832 __tmp33884 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33832 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33832 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33832 '() '21 '#f '#f))
        __obj33832))))
