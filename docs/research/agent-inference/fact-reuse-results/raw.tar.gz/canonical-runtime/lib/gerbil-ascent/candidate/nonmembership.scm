(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/candidate/datum")
    (load-module "gerbil-ascent/core/rule-bindings")
    (load-module "gerbil-ascent/candidate/certificate-limits")
    (load-module "gerbil-ascent/candidate/program-identity")
    (load-module "gerbil-ascent/candidate/types")
    (load-module "gerbil-ascent/candidate/program")
    (load-module "gerbil-ascent/candidate/funs")
    (load-module "gerbil-ascent/candidate/provenance"))
  (load-module "gerbil-ascent/candidate/nonmembership~0"))
