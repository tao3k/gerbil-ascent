(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/stratified-producer::timestamp 1791687894)
  (begin
    (define gerbil-ascent/candidate/stratified-producer#+maximum-nodes+ '4096)
    (define gerbil-ascent/candidate/stratified-producer#candidate-produce-stratified-proof
      (lambda (_%snapshot28782%_
               _%spec28783%_
               _%candidate-digest28784%_
               _%native-status28785%_
               _%native-rows28786%_
               _%certificate28787%_
               _%finite-work-budget28788%_
               _%proof-work-budget28789%_)
        (if (and (exact-integer? _%proof-work-budget28789%_)
                 (> _%proof-work-budget28789%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"stratified producer needs positive work budget"
                     _%proof-work-budget28789%_)))
        (let ((_g38000_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/finite-evidence#candidate-verified-finite-closure
                  _%snapshot28782%_
                  _%spec28783%_
                  _%candidate-digest28784%_
                  _%native-status28785%_
                  _%native-rows28786%_
                  _%certificate28787%_
                  _%finite-work-budget28788%_))))
          (begin
            (let ((_g38001_
                   (let ()
                     (declare (not safe))
                     (if (##values? _g38000_) (##values-length _g38000_) 1))))
              (if (not (let () (declare (not safe)) (##fx= _g38001_ 2)))
                  (error "Context expects 2 values" _g38001_)))
            (let ((_%finite-verdict28791%_
                   (let () (declare (not safe)) (##values-ref _g38000_ 0)))
                  (_%closure28792%_
                   (let () (declare (not safe)) (##values-ref _g38000_ 1))))
              (if (eq? _%finite-verdict28791%_ 'valid)
                  (if (null? _%native-rows28786%_)
                      (values 'unsupported '())
                      (let* ((_%schema28794%_
                              (let ()
                                (declare (not safe))
                                (gerbil-ascent/candidate/funs#candidate-schema-of
                                 _%snapshot28782%_
                                 _%spec28783%_)))
                             (_%rules28796%_
                              (##structure-ref
                               _%spec28783%_
                               '3
                               gerbil-ascent/candidate/types#reasoning-candidate::t
                               '#f))
                             (_%levels28798%_
                              (let ()
                                (declare (not safe))
                                (gerbil-ascent/candidate/funs#candidate-strata-of
                                 _%schema28794%_
                                 _%rules28796%_)))
                             (_%model28800%_
                              (let ()
                                (declare (not safe))
                                (gerbil-ascent/candidate/closure-index#make-closure-index__0
                                 _%closure28792%_)))
                             (_%nodes28802%_
                              (let ()
                                (declare (not safe))
                                (##make-vector
                                 gerbil-ascent/candidate/stratified-producer#+maximum-nodes+
                                 '#f)))
                             (_%by-row28804%_
                              (let ()
                                (declare (not safe))
                                (make-hash-table__%
                                 '#f
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value)))
                             (_%by-relation28806%_
                              (let ()
                                (declare (not safe))
                                (make-hash-table-eq)))
                             (_%node-count28808%_ '0)
                             (_%steps28810%_ '0)
                             (_%bounded?28812%_ '#f)
                             (_%added?28814%_ '#f))
                        (letrec ((_%step!28817%_
                                  (lambda ()
                                    (set! _%steps28810%_ (+ _%steps28810%_ '1))
                                    (if (> _%steps28810%_
                                           _%proof-work-budget28789%_)
                                        (set! _%bounded?28812%_ '#t)
                                        '#!void)
                                    (not _%bounded?28812%_)))
                                 (_%rows28818%_
                                  (lambda (_%name29033%_)
                                    (let ()
                                      (declare (not safe))
                                      (gerbil-ascent/candidate/closure-index#closure-index-rows
                                       _%model28800%_
                                       _%name29033%_))))
                                 (_%level28819%_
                                  (lambda (_%name29031%_)
                                    (cdr (let ()
                                           (declare (not safe))
                                           (gerbil-ascent/candidate/funs#candidate-required-entry
                                            _%name29031%_
                                            _%levels28798%_)))))
                                 (_%node-id28820%_
                                  (lambda (_%name29028%_ _%row29029%_)
                                    (let ((__tmp38002
                                           (cons _%name29028%_ _%row29029%_)))
                                      (declare (not safe))
                                      (__hash-get
                                       _%by-row28804%_
                                       __tmp38002))))
                                 (_%add-node!28821%_
                                  (lambda (_%kind28950%_
                                           _%name28951%_
                                           _%row28952%_
                                           _%label28953%_
                                           _%witnesses28954%_)
                                    (if (if _%bounded?28812%_
                                            '#f
                                            (if (_%node-id28820%_
                                                 _%name28951%_
                                                 _%row28952%_)
                                                '#f
                                                (let ()
                                                  (declare (not safe))
                                                  (gerbil-ascent/candidate/closure-index#closure-index-member?
                                                   _%model28800%_
                                                   _%name28951%_
                                                   _%row28952%_))))
                                        (if (>= _%node-count28808%_
                                                gerbil-ascent/candidate/stratified-producer#+maximum-nodes+)
                                            (set! _%bounded?28812%_ '#t)
                                            (let ((_%id28956%_
                                                   _%node-count28808%_)
                                                  (_%copy28957%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                                      _%row28952%_))))
                                              (vector-set!
                                               _%nodes28802%_
                                               _%id28956%_
                                               (list _%kind28950%_
                                                     _%name28951%_
                                                     _%copy28957%_
                                                     _%label28953%_
                                                     _%witnesses28954%_))
                                              (let ((__tmp38003
                                                     (cons _%name28951%_
                                                           _%copy28957%_)))
                                                (declare (not safe))
                                                (__hash-put!
                                                 _%by-row28804%_
                                                 __tmp38003
                                                 _%id28956%_))
                                              (let* ((_%table28959%_
                                                      _%by-relation28806%_)
                                                     (_%key28962%_
                                                      _%name28951%_)
                                                     (_%default28966%_
                                                      (lambda () '()))
                                                     (_%function28971%_
                                                      (lambda (_%ids28969%_)
                                                        (cons _%id28956%_
                                                              _%ids28969%_)))
                                                     (_%table28975%_
                                                      _%table28959%_)
                                                     (_%table28977%_
                                                      _%table28975%_)
                                                     (_%default29008%_
                                                      _%default28966%_)
                                                     (_%function29018%_
                                                      _%function28971%_))
                                                (declare (not safe))
                                                (std/hash/misc#__hash-ensure-modify!
                                                 _%table28977%_
                                                 _%key28962%_
                                                 _%default29008%_
                                                 _%function29018%_))
                                              (set! _%node-count28808%_
                                                    (+ _%node-count28808%_ '1))
                                              (set! _%added?28814%_ '#t)))
                                        '#!void)))
                                 (_%reduction28822%_
                                  (lambda (_%clause28920%_
                                           _%bindings28921%_
                                           _%head28922%_)
                                    (let* ((_%output28924%_
                                            (cadr _%clause28920%_))
                                           (_%operator28926%_
                                            (caddr _%clause28920%_))
                                           (_%atom28928%_
                                            (cadddr _%clause28920%_))
                                           (_%name28930%_ (car _%atom28928%_))
                                           (_%ids28932%_ '())
                                           (_%values28934%_ '())
                                           (_%ready?28936%_
                                            (> (_%level28819%_ _%head28922%_)
                                               (_%level28819%_
                                                _%name28930%_))))
                                      (if _%ready?28936%_
                                          (for-each
                                           (lambda (_%row28939%_)
                                             (if (_%step!28817%_)
                                                 (let ((_%next28941%_
                                                        (let ()
                                                          (declare (not safe))
                                                          (gerbil-ascent/candidate/funs#candidate-bind-atom
                                                           _%atom28928%_
                                                           _%row28939%_
                                                           _%bindings28921%_))))
                                                   (if _%next28941%_
                                                       (let ((_%id28943%_
                                                              (_%node-id28820%_
                                                               _%name28930%_
                                                               _%row28939%_)))
                                                         (if _%id28943%_
                                                             (begin
                                                               (set! _%ids28932%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (cons _%id28943%_ _%ids28932%_))
                       (if (eq? (car _%operator28926%_) 'count)
                           '#!void
                           (set! _%values28934%_
                                 (cons (cdr (let ((__tmp38004
                                                   (cadr _%operator28926%_)))
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/funs#candidate-required-entry
                                               __tmp38004
                                               _%next28941%_)))
                                       _%values28934%_))))
                     (set! _%ready?28936%_ '#f)))
               '#!void))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 '#!void))
                                           (_%rows28818%_ _%name28930%_))
                                          '#!void)
                                      (if _%bounded?28812%_
                                          '#f
                                          (if _%ready?28936%_
                                              (let ((_%value28948%_
                                                     (let ((_%$e28945%_
                                                            (car _%operator28926%_)))
                                                       (if (eq? 'count
                                                                _%$e28945%_)
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##length
                                                              _%ids28932%_))
                                                           (if (eq? 'sum
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%$e28945%_)
                       (if (let ()
                             (declare (not safe))
                             (andmap__0 exact-integer? _%values28934%_))
                           (apply + '0 _%values28934%_)
                           '#f)
                       (if (eq? 'min _%$e28945%_)
                           (if (pair? _%values28934%_)
                               (if (let ()
                                     (declare (not safe))
                                     (andmap__0
                                      exact-integer?
                                      _%values28934%_))
                                   (let ()
                                     (declare (not safe))
                                     (##apply min _%values28934%_))
                                   '#f)
                               '#f)
                           (if (eq? 'max _%$e28945%_)
                               (if (pair? _%values28934%_)
                                   (if (let ()
                                         (declare (not safe))
                                         (andmap__0
                                          exact-integer?
                                          _%values28934%_))
                                       (let ()
                                         (declare (not safe))
                                         (##apply max _%values28934%_))
                                       '#f)
                                   '#f)
                               '#f)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (if _%value28948%_
                                                    (cons (cons (cons _%output28924%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              _%value28948%_)
                        _%bindings28921%_)
                  (list 'reduce
                        (let ()
                          (declare (not safe))
                          (##reverse _%ids28932%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '#f))
                                              '#f)))))
                                 (_%evaluate-rule28823%_
                                  (lambda (_%rule28868%_)
                                    (let* ((_%head28870%_
                                            (vector-ref _%rule28868%_ '0))
                                           (_%head-name28872%_
                                            (car _%head28870%_))
                                           (_%body28874%_
                                            (vector-ref _%rule28868%_ '1))
                                           (_%label28876%_
                                            (vector-ref _%rule28868%_ '2)))
                                      (letrec ((_%walk28879%_
                                                (lambda (_%clauses28881%_
                                                         _%bindings28882%_
                                                         _%evidence28883%_)
                                                  (if _%bounded?28812%_
                                                      '#!void
                                                      (if (null? _%clauses28881%_)
                                                          (let ((_%row28887%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (map (lambda (_%term28885%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gerbil-ascent/candidate/program#candidate-variable?
                                       _%term28885%_))
                                    (cdr (let ()
                                           (declare (not safe))
                                           (gerbil-ascent/candidate/funs#candidate-required-entry
                                            _%term28885%_
                                            _%bindings28882%_)))
                                    _%term28885%_))
                              (cdr _%head28870%_))))
                    (if (_%step!28817%_)
                        (_%add-node!28821%_
                         'rule
                         _%head-name28872%_
                         _%row28887%_
                         _%label28876%_
                         (reverse _%evidence28883%_))
                        '#!void))
                  (let* ((_%clause28889%_ (car _%clauses28881%_))
                         (_%$e28891%_ (car _%clause28889%_)))
                    (if (or (eq? 'where _%$e28891%_)
                            (eq? 'compute _%$e28891%_))
                        (if (_%step!28817%_)
                            (let ((_%next28897%_
                                   (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/funs#candidate-fixed-clause
                                      _%clause28889%_
                                      _%bindings28882%_))))
                              (if _%next28897%_
                                  (_%walk28879%_
                                   (cdr _%clauses28881%_)
                                   _%next28897%_
                                   (cons '(fixed) _%evidence28883%_))
                                  '#!void))
                            '#!void)
                        (if (eq? 'not _%$e28891%_)
                            (let* ((_%atom28899%_ (cadr _%clause28889%_))
                                   (_%name28901%_ (car _%atom28899%_))
                                   (_%absent?28903%_
                                    (> (_%level28819%_ _%head-name28872%_)
                                       (_%level28819%_ _%name28901%_))))
                              (if _%absent?28903%_
                                  (for-each
                                   (lambda (_%row28906%_)
                                     (if (_%step!28817%_)
                                         (if (let ()
                                               (declare (not safe))
                                               (gerbil-ascent/candidate/funs#candidate-bind-atom
                                                _%atom28899%_
                                                _%row28906%_
                                                _%bindings28882%_))
                                             (set! _%absent?28903%_ '#f)
                                             '#!void)
                                         '#!void))
                                   (_%rows28818%_ _%name28901%_))
                                  '#!void)
                              (if (if _%bounded?28812%_ '#f _%absent?28903%_)
                                  (_%walk28879%_
                                   (cdr _%clauses28881%_)
                                   _%bindings28882%_
                                   (cons '(not) _%evidence28883%_))
                                  '#!void))
                            (if (eq? 'reduce _%$e28891%_)
                                (let ((_%result28908%_
                                       (_%reduction28822%_
                                        _%clause28889%_
                                        _%bindings28882%_
                                        _%head-name28872%_)))
                                  (if _%result28908%_
                                      (_%walk28879%_
                                       (cdr _%clauses28881%_)
                                       (let ()
                                         (declare (not safe))
                                         (##car _%result28908%_))
                                       (cons (let ()
                                               (declare (not safe))
                                               (##cdr _%result28908%_))
                                             _%evidence28883%_))
                                      '#!void))
                                (for-each
                                 (lambda (_%id28910%_)
                                   (if (_%step!28817%_)
                                       (let* ((_%node28912%_
                                               (vector-ref
                                                _%nodes28802%_
                                                _%id28910%_))
                                              (_%next28914%_
                                               (let ((__tmp38005
                                                      (caddr _%node28912%_)))
                                                 (declare (not safe))
                                                 (gerbil-ascent/candidate/funs#candidate-bind-atom
                                                  _%clause28889%_
                                                  __tmp38005
                                                  _%bindings28882%_))))
                                         (if _%next28914%_
                                             (_%walk28879%_
                                              (cdr _%clauses28881%_)
                                              _%next28914%_
                                              (cons (list 'atom _%id28910%_)
                                                    _%evidence28883%_))
                                             '#!void))
                                       '#!void))
                                 (let ((_%$e28917%_
                                        (let ((__tmp38006
                                               (car _%clause28889%_)))
                                          (declare (not safe))
                                          (__hash-get
                                           _%by-relation28806%_
                                           __tmp38006))))
                                   (if _%$e28917%_ _%$e28917%_ '()))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        (_%walk28879%_
                                         _%body28874%_
                                         '()
                                         '()))))))
                          (if _%levels28798%_
                              (begin
                                (for-each
                                 (lambda (_%entry28825%_)
                                   (let ((_%name28827%_ (car _%entry28825%_))
                                         (_%position28828%_ '0))
                                     (for-each
                                      (lambda (_%row28830%_)
                                        (set! _%position28828%_
                                              (+ _%position28828%_ '1))
                                        (if (_%step!28817%_)
                                            (_%add-node!28821%_
                                             'source
                                             _%name28827%_
                                             _%row28830%_
                                             _%position28828%_
                                             '())
                                            '#!void))
                                      (caddr _%entry28825%_))))
                                 (##structure-ref
                                  _%snapshot28782%_
                                  '4
                                  gerbil-ascent/candidate/types#reasoning-snapshot::t
                                  '#f))
                                (for-each
                                 (lambda (_%fact28832%_)
                                   (if (_%step!28817%_)
                                       (_%add-node!28821%_
                                        'candidate
                                        (vector-ref _%fact28832%_ '0)
                                        (vector-ref _%fact28832%_ '1)
                                        (vector-ref _%fact28832%_ '2)
                                        '())
                                       '#!void))
                                 (##structure-ref
                                  _%spec28783%_
                                  '2
                                  gerbil-ascent/candidate/types#reasoning-candidate::t
                                  '#f))
                                (let _%stratum28834%_ ((_%current28836%_ '0)
                                                       (_%maximum28837%_
                                                        (let ((__tmp38007
                                                               (map cdr
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%levels28798%_)))
                  (declare (not safe))
                  (##apply max __tmp38007))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                  (if (and (<= _%current28836%_
                                               _%maximum28837%_)
                                           (not _%bounded?28812%_))
                                      (begin
                                        (let _%repeat28839%_ ()
                                          (set! _%added?28814%_ '#f)
                                          (for-each
                                           (lambda (_%rule28842%_)
                                             (if (if _%bounded?28812%_
                                                     '#f
                                                     (= (_%level28819%_
                                                         (car (vector-ref
                                                               _%rule28842%_
                                                               '0)))
                                                        _%current28836%_))
                                                 (_%evaluate-rule28823%_
                                                  _%rule28842%_)
                                                 '#!void))
                                           _%rules28796%_)
                                          (if (and _%added?28814%_
                                                   (not _%bounded?28812%_))
                                              (_%repeat28839%_)
                                              '#!void))
                                        (_%stratum28834%_
                                         (+ _%current28836%_ '1)
                                         _%maximum28837%_))
                                      '#!void))
                                (if _%bounded?28812%_
                                    (values 'bounded '())
                                    (let* ((_%query28844%_
                                            (vector-ref
                                             (##structure-ref
                                              _%spec28783%_
                                              '4
                                              gerbil-ascent/candidate/types#reasoning-candidate::t
                                              '#f)
                                             '0))
                                           (_%roots28848%_
                                            (map (lambda (_%row28846%_)
                                                   (_%node-id28820%_
                                                    (car _%query28844%_)
                                                    _%row28846%_))
                                                 _%native-rows28786%_)))
                                      (if (let ((__tmp38008
                                                 (lambda (_%id28851%_)
                                                   (and _%id28851%_ '#t))))
                                            (declare (not safe))
                                            (andmap__0
                                             __tmp38008
                                             _%roots28848%_))
                                          (let* ((_%ordered28858%_
                                                  (let _%loop28853%_ ((_%index28855%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               (- _%node-count28808%_ '1))
                              (_%result28856%_ '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (if (< _%index28855%_ '0)
                                                        _%result28856%_
                                                        (_%loop28853%_
                                                         (- _%index28855%_ '1)
                                                         (cons (vector-ref
                                                                _%nodes28802%_
                                                                _%index28855%_)
                                                               _%result28856%_)))))
                                                 (_%proof28860%_
                                                  (list 'stratified-proof-v1
                                                        _%ordered28858%_
                                                        _%roots28848%_))
                                                 (_%verdict28862%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (gerbil-ascent/candidate/stratified-proof#candidate-verify-stratified-proof
                                                     _%snapshot28782%_
                                                     _%spec28783%_
                                                     _%candidate-digest28784%_
                                                     _%native-status28785%_
                                                     _%native-rows28786%_
                                                     _%certificate28787%_
                                                     _%finite-work-budget28788%_
                                                     _%proof28860%_
                                                     _%proof-work-budget28789%_)))
                                                 (_%$e28865%_
                                                  _%verdict28862%_))
                                            (if (eq? 'valid _%$e28865%_)
                                                (values 'complete
                                                        _%proof28860%_)
                                                (if (eq? 'bounded _%$e28865%_)
                                                    (values 'bounded '())
                                                    (values 'invalid '()))))
                                          (values 'unsupported '())))))
                              (values 'invalid '())))))
                  (values _%finite-verdict28791%_ '())))))))))
