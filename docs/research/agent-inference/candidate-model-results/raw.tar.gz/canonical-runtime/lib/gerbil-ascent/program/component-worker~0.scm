(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/component-worker::timestamp 1791689698)
  (begin
    (define gerbil-ascent/program/component-worker#component-snapshot::t
      (let ((__tmp36374 (list)) (__tmp36373 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/component-worker#component-snapshot::t
         'component-snapshot
         __tmp36374
         '(rows sizes)
         __tmp36373
         '#f)))
    (define gerbil-ascent/program/component-worker#component-snapshot?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/component-worker#component-snapshot::t)))
    (define gerbil-ascent/program/component-worker#make-component-snapshot
      (lambda _%$args18034%_
        (apply make-instance
               gerbil-ascent/program/component-worker#component-snapshot::t
               _%$args18034%_)))
    (define gerbil-ascent/program/component-worker#component-snapshot-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/component-worker#component-snapshot::t
         'rows)))
    (define gerbil-ascent/program/component-worker#component-snapshot-sizes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/component-worker#component-snapshot::t
         'sizes)))
    (define gerbil-ascent/program/component-worker#component-snapshot-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/component-worker#component-snapshot::t
         'rows)))
    (define gerbil-ascent/program/component-worker#component-snapshot-sizes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/component-worker#component-snapshot::t
         'sizes)))
    (define gerbil-ascent/program/component-worker#&component-snapshot-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/component-worker#component-snapshot::t
         'rows)))
    (define gerbil-ascent/program/component-worker#&component-snapshot-sizes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/component-worker#component-snapshot::t
         'sizes)))
    (define gerbil-ascent/program/component-worker#&component-snapshot-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/component-worker#component-snapshot::t
         'rows)))
    (define gerbil-ascent/program/component-worker#&component-snapshot-sizes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/component-worker#component-snapshot::t
         'sizes)))
    (define gerbil-ascent/program/component-worker#gerbil-ascent-run-positive-component!
      (lambda (_%component17960%_
               _%schema17961%_
               _%snapshot17962%_
               _%emit!17963%_
               _%checkpoint!17964%_)
        (let* ((_%all17966%_
                (##structure-ref
                 _%snapshot17962%_
                 '1
                 gerbil-ascent/program/component-worker#component-snapshot::t
                 '#f))
               (_%all-size17968%_
                (##structure-ref
                 _%snapshot17962%_
                 '2
                 gerbil-ascent/program/component-worker#component-snapshot::t
                 '#f))
               (_%count17970%_ (vector-length _%all17966%_))
               (_%delta17972%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count17970%_ '())))
               (_%delta-size17974%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count17970%_ '0)))
               (_%all-version17976%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count17970%_ '0)))
               (_%delta-version17978%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count17970%_ '0)))
               (_%indexes17980%_
                (let ((__tmp36375 (vector-ref _%schema17961%_ '5)))
                  (declare (not safe))
                  (gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__0
                   _%all17966%_
                   _%delta17972%_
                   _%all-size17968%_
                   _%delta-size17974%_
                   _%all-version17976%_
                   _%delta-version17978%_
                   __tmp36375)))
               (_%rows-access17982%_
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-ref _%indexes17980%_ '1 '#f '#f)))
               (_%advance!17984%_
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-ref _%indexes17980%_ '2 '#f '#f)))
               (_%seen17986%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count17970%_ '#f)))
               (_%pending17988%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count17970%_ '())))
               (_%members17990%_
                (##structure-ref
                 _%component17960%_
                 '2
                 gerbil-ascent/program/component-plan#positive-component::t
                 '#f))
               (_%rules17994%_
                (map (lambda (_%rule17992%_)
                       (vector (vector-ref _%rule17992%_ '0)
                               (vector-ref _%rule17992%_ '1)
                               (make-vector
                                (vector-ref (vector-ref _%rule17992%_ '0) '2)
                                '#f)))
                     (##structure-ref
                      _%component17960%_
                      '3
                      gerbil-ascent/program/component-plan#positive-component::t
                      '#f))))
          (let ()
            (declare (not safe))
            (gerbil-ascent/program/index#row-indexes-plan-positive-rules!
             _%indexes17980%_
             _%rules17994%_))
          (for-each
           (lambda (_%index17997%_)
             (let ((_%table17999%_
                    (let ()
                      (declare (not safe))
                      (make-hash-table__%
                       '#f
                       absent-value
                       absent-value
                       absent-value
                       absent-value
                       absent-value
                       absent-value
                       absent-value
                       absent-value))))
               (for-each
                (lambda (_%row18001%_)
                  (let ()
                    (declare (not safe))
                    (__hash-put! _%table17999%_ _%row18001%_ '#t)))
                (vector-ref _%all17966%_ _%index17997%_))
               (vector-set! _%seen17986%_ _%index17997%_ _%table17999%_)))
           _%members17990%_)
          (let _%rounds18003%_ ((_%first?18005%_ '#t))
            (let ((_%new?18007%_ '#f))
              (letrec ((_%candidate!18009%_
                        (lambda (_%atom18026%_ _%row18027%_)
                          (let* ((_%index18029%_ (vector-ref _%atom18026%_ '0))
                                 (_%table18031%_
                                  (vector-ref _%seen17986%_ _%index18029%_)))
                            (if (let ()
                                  (declare (not safe))
                                  (hash-get _%table18031%_ _%row18027%_))
                                '#!void
                                (begin
                                  (let ()
                                    (declare (not safe))
                                    (hash-put!
                                     _%table18031%_
                                     _%row18027%_
                                     '#t))
                                  (vector-set!
                                   _%pending17988%_
                                   _%index18029%_
                                   (cons _%row18027%_
                                         (vector-ref
                                          _%pending17988%_
                                          _%index18029%_)))
                                  (set! _%new?18007%_ '#t)
                                  (_%emit!17963%_
                                   _%atom18026%_
                                   _%row18027%_)))))))
                (let ((__tmp36376
                       (lambda (_%rule18011%_)
                         (let ((_%plan18013%_ (vector-ref _%rule18011%_ '0))
                               (_%pivots18014%_ (vector-ref _%rule18011%_ '1))
                               (_%frame18015%_ (vector-ref _%rule18011%_ '2)))
                           (if _%first?18005%_
                               (let ()
                                 (declare (not safe))
                                 (gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__1
                                  _%plan18013%_
                                  _%frame18015%_
                                  '-1
                                  _%rows-access17982%_
                                  _%candidate!18009%_
                                  _%checkpoint!17964%_))
                               (for-each
                                (lambda (_%pivot18017%_)
                                  (let ()
                                    (declare (not safe))
                                    (gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__1
                                     _%plan18013%_
                                     _%frame18015%_
                                     _%pivot18017%_
                                     _%rows-access17982%_
                                     _%candidate!18009%_
                                     _%checkpoint!17964%_)))
                                _%pivots18014%_))))))
                  (declare (not safe))
                  (##for-each __tmp36376 _%rules17994%_))
                (for-each
                 (lambda (_%index18019%_)
                   (let* ((_%batch18021%_
                           (vector-ref _%pending17988%_ _%index18019%_))
                          (_%size18023%_ (length _%batch18021%_)))
                     (if (null? _%batch18021%_)
                         '#!void
                         (begin
                           (_%advance!17984%_
                            _%index18019%_
                            _%batch18021%_
                            '#t)
                           (vector-set!
                            _%all17966%_
                            _%index18019%_
                            (append _%batch18021%_
                                    (vector-ref _%all17966%_ _%index18019%_)))
                           (vector-set!
                            _%all-size17968%_
                            _%index18019%_
                            (+ (vector-ref _%all-size17968%_ _%index18019%_)
                               _%size18023%_))
                           (vector-set!
                            _%all-version17976%_
                            _%index18019%_
                            (+ '1
                               (vector-ref
                                _%all-version17976%_
                                _%index18019%_)))))
                     (vector-set! _%delta17972%_ _%index18019%_ _%batch18021%_)
                     (vector-set! _%pending17988%_ _%index18019%_ '())
                     (vector-set!
                      _%delta-size17974%_
                      _%index18019%_
                      _%size18023%_)
                     (vector-set!
                      _%delta-version17978%_
                      _%index18019%_
                      (+ '1
                         (vector-ref _%delta-version17978%_ _%index18019%_)))))
                 _%members17990%_)
                (if _%new?18007%_ (_%rounds18003%_ '#f) '#!void)))))))))
