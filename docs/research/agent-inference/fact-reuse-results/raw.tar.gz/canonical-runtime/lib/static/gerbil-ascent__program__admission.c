#ifdef ___LINKER_INFO
; File: "gerbil-ascent__program__admission.c", produced by Gambit v4.9.8
(
409008
(C)
"gerbil-ascent__program__admission"
("gerbil-ascent__program__admission")
()
(("gerbil-ascent__program__admission"))
( #|*/"*/"symbols|#
"gerbil-ascent/program/admission#gerbil-ascent-admit-source-row!"
"gerbil-ascent/program/admission#gerbil-ascent-check-replacement-rows!"
"gerbil-ascent/program/admission#gerbil-ascent-initialize-source-row!"
"gerbil-ascent/program/admission#gerbil-ascent-prepare-storage-batch"
"gerbil-ascent__program__admission"
"gerbil-ascent__program__admission#"
) #|*/"*/"symbols|#
( #|*/"*/"keywords|#
) #|*/"*/"keywords|#
( #|*/"*/"globals-s-d|#
"gerbil-ascent/program/admission#gerbil-ascent-admit-source-row!"
"gerbil-ascent__program__admission#"
) #|*/"*/"globals-s-d|#
( #|*/"*/"globals-s-nd|#
"gerbil-ascent/program/admission#gerbil-ascent-check-replacement-rows!"
"gerbil-ascent/program/admission#gerbil-ascent-initialize-source-row!"
"gerbil-ascent/program/admission#gerbil-ascent-prepare-storage-batch"
"gerbil-ascent/program/admission::timestamp"
) #|*/"*/"globals-s-nd|#
( #|*/"*/"globals-ns|#
"##dead-end"
"##length"
"##list?"
"+"
"="
">"
"__hash-get"
"__hash-length"
"__hash-put!"
"absent-value"
"error"
"hash-get"
"hash-put!"
"make-hash-table__%"
"vector-ref"
"vector-set!"
) #|*/"*/"globals-ns|#
( #|*/"*/"meta-info|#
) #|*/"*/"meta-info|#
)
#else
#define ___VERSION 409008
#define ___MODULE_NAME "gerbil-ascent__program__admission"
#define ___LINKER_ID ___LNK_gerbil_2d_ascent____program____admission
#define ___MH_PROC ___H_gerbil_2d_ascent____program____admission
#define ___SCRIPT_LINE 0
#define ___SYMCOUNT 6
#define ___GLOCOUNT 22
#define ___SUPCOUNT 6
#define ___SUBCOUNT 11
#define ___LBLCOUNT 81
#define ___OFDCOUNT 18
#define ___MODDESCR ___REF_SUB(8)
#include "gambit.h"

___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___NEED_SYM(___S_gerbil_2d_ascent____program____admission)
___NEED_SYM(___S_gerbil_2d_ascent____program____admission_23_)

___NEED_GLO(___G__23__23_dead_2d_end)
___NEED_GLO(___G__23__23_length)
___NEED_GLO(___G__23__23_list_3f_)
___NEED_GLO(___G__2b_)
___NEED_GLO(___G__3d_)
___NEED_GLO(___G__3e_)
___NEED_GLO(___G_____hash_2d_get)
___NEED_GLO(___G_____hash_2d_length)
___NEED_GLO(___G_____hash_2d_put_21_)
___NEED_GLO(___G_absent_2d_value)
___NEED_GLO(___G_error)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_admission_3a__3a_timestamp)
___NEED_GLO(___G_gerbil_2d_ascent____program____admission_23_)
___NEED_GLO(___G_hash_2d_get)
___NEED_GLO(___G_hash_2d_put_21_)
___NEED_GLO(___G_make_2d_hash_2d_table_____25_)
___NEED_GLO(___G_vector_2d_ref)
___NEED_GLO(___G_vector_2d_set_21_)

___BEGIN_SYM
___DEF_SYM(0,___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_,"gerbil-ascent/program/admission#gerbil-ascent-admit-source-row!")

___DEF_SYM(1,___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,"gerbil-ascent/program/admission#gerbil-ascent-check-replacement-rows!")

___DEF_SYM(2,___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_,"gerbil-ascent/program/admission#gerbil-ascent-initialize-source-row!")

___DEF_SYM(3,___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,"gerbil-ascent/program/admission#gerbil-ascent-prepare-storage-batch")

___DEF_SYM(4,___S_gerbil_2d_ascent____program____admission,"gerbil-ascent__program__admission")

___DEF_SYM(5,___S_gerbil_2d_ascent____program____admission_23_,"gerbil-ascent__program__admission#")

___END_SYM

#define ___SYM_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_ ___SYM(0,___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_ ___SYM(1,___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_ ___SYM(2,___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch ___SYM(3,___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
#define ___SYM_gerbil_2d_ascent____program____admission ___SYM(4,___S_gerbil_2d_ascent____program____admission)
#define ___SYM_gerbil_2d_ascent____program____admission_23_ ___SYM(5,___S_gerbil_2d_ascent____program____admission_23_)

___BEGIN_GLO
___DEF_GLO(0,"gerbil-ascent/program/admission#gerbil-ascent-admit-source-row!")

___DEF_GLO(1,"gerbil-ascent/program/admission#gerbil-ascent-check-replacement-rows!")

___DEF_GLO(2,"gerbil-ascent/program/admission#gerbil-ascent-initialize-source-row!")

___DEF_GLO(3,"gerbil-ascent/program/admission#gerbil-ascent-prepare-storage-batch")

___DEF_GLO(4,"gerbil-ascent/program/admission::timestamp")

___DEF_GLO(5,"gerbil-ascent__program__admission#")

___DEF_GLO(6,"##dead-end")
___DEF_GLO(7,"##length")
___DEF_GLO(8,"##list?")
___DEF_GLO(9,"+")
___DEF_GLO(10,"=")
___DEF_GLO(11,">")
___DEF_GLO(12,"__hash-get")
___DEF_GLO(13,"__hash-length")
___DEF_GLO(14,"__hash-put!")
___DEF_GLO(15,"absent-value")
___DEF_GLO(16,"error")
___DEF_GLO(17,"hash-get")
___DEF_GLO(18,"hash-put!")
___DEF_GLO(19,"make-hash-table__%")
___DEF_GLO(20,"vector-ref")
___DEF_GLO(21,"vector-set!")
___END_GLO

#define ___GLO_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_ ___GLO(0,___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_ ___PRM(0,___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_ ___GLO(1,___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_ ___PRM(1,___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_ ___GLO(2,___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_ ___PRM(2,___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch ___GLO(3,___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch ___PRM(3,___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_admission_3a__3a_timestamp ___GLO(4,___G_gerbil_2d_ascent_2f_program_2f_admission_3a__3a_timestamp)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_admission_3a__3a_timestamp ___PRM(4,___G_gerbil_2d_ascent_2f_program_2f_admission_3a__3a_timestamp)
#define ___GLO_gerbil_2d_ascent____program____admission_23_ ___GLO(5,___G_gerbil_2d_ascent____program____admission_23_)
#define ___PRM_gerbil_2d_ascent____program____admission_23_ ___PRM(5,___G_gerbil_2d_ascent____program____admission_23_)
#define ___GLO__23__23_dead_2d_end ___GLO(6,___G__23__23_dead_2d_end)
#define ___PRM__23__23_dead_2d_end ___PRM(6,___G__23__23_dead_2d_end)
#define ___GLO__23__23_length ___GLO(7,___G__23__23_length)
#define ___PRM__23__23_length ___PRM(7,___G__23__23_length)
#define ___GLO__23__23_list_3f_ ___GLO(8,___G__23__23_list_3f_)
#define ___PRM__23__23_list_3f_ ___PRM(8,___G__23__23_list_3f_)
#define ___GLO__2b_ ___GLO(9,___G__2b_)
#define ___PRM__2b_ ___PRM(9,___G__2b_)
#define ___GLO__3d_ ___GLO(10,___G__3d_)
#define ___PRM__3d_ ___PRM(10,___G__3d_)
#define ___GLO__3e_ ___GLO(11,___G__3e_)
#define ___PRM__3e_ ___PRM(11,___G__3e_)
#define ___GLO_____hash_2d_get ___GLO(12,___G_____hash_2d_get)
#define ___PRM_____hash_2d_get ___PRM(12,___G_____hash_2d_get)
#define ___GLO_____hash_2d_length ___GLO(13,___G_____hash_2d_length)
#define ___PRM_____hash_2d_length ___PRM(13,___G_____hash_2d_length)
#define ___GLO_____hash_2d_put_21_ ___GLO(14,___G_____hash_2d_put_21_)
#define ___PRM_____hash_2d_put_21_ ___PRM(14,___G_____hash_2d_put_21_)
#define ___GLO_absent_2d_value ___GLO(15,___G_absent_2d_value)
#define ___PRM_absent_2d_value ___PRM(15,___G_absent_2d_value)
#define ___GLO_error ___GLO(16,___G_error)
#define ___PRM_error ___PRM(16,___G_error)
#define ___GLO_hash_2d_get ___GLO(17,___G_hash_2d_get)
#define ___PRM_hash_2d_get ___PRM(17,___G_hash_2d_get)
#define ___GLO_hash_2d_put_21_ ___GLO(18,___G_hash_2d_put_21_)
#define ___PRM_hash_2d_put_21_ ___PRM(18,___G_hash_2d_put_21_)
#define ___GLO_make_2d_hash_2d_table_____25_ ___GLO(19,___G_make_2d_hash_2d_table_____25_)
#define ___PRM_make_2d_hash_2d_table_____25_ ___PRM(19,___G_make_2d_hash_2d_table_____25_)
#define ___GLO_vector_2d_ref ___GLO(20,___G_vector_2d_ref)
#define ___PRM_vector_2d_ref ___PRM(20,___G_vector_2d_ref)
#define ___GLO_vector_2d_set_21_ ___GLO(21,___G_vector_2d_set_21_)
#define ___PRM_vector_2d_set_21_ ___PRM(21,___G_vector_2d_set_21_)

___DEF_SUB_BIGFIX(___X0,1UL)
               ___BIGFIX1(0x6acafcb4L)
___DEF_SUB_STR(___X1,37UL)
               ___STR8(105,110,118,97,108,105,100,32)
               ___STR8(65,83,67,69,78,84,32,114)
               ___STR8(101,112,108,97,99,101,109,101)
               ___STR8(110,116,32,115,111,117,114,99)
               ___STR5(101,32,114,111,119)
___DEF_SUB_STR(___X2,38UL)
               ___STR8(105,110,118,97,108,105,100,32)
               ___STR8(65,83,67,69,78,84,32,114)
               ___STR8(101,112,108,97,99,101,109,101)
               ___STR8(110,116,32,115,111,117,114,99)
               ___STR6(101,32,114,111,119,115)
___DEF_SUB_STR(___X3,35UL)
               ___STR8(105,110,118,97,108,105,100,32)
               ___STR8(65,83,67,69,78,84,32,115)
               ___STR8(116,111,114,97,103,101,32,112)
               ___STR8(114,111,118,105,100,101,114,32)
               ___STR3(114,111,119)
___DEF_SUB_STR(___X4,34UL)
               ___STR8(65,83,67,69,78,84,32,115)
               ___STR8(111,117,114,99,101,32,102,97)
               ___STR8(99,116,32,98,117,100,103,101)
               ___STR8(116,32,101,120,99,101,101,100)
               ___STR2(101,100)
___DEF_SUB_STR(___X5,35UL)
               ___STR8(105,110,118,97,108,105,100,32)
               ___STR8(65,83,67,69,78,84,32,115)
               ___STR8(116,111,114,97,103,101,32,112)
               ___STR8(114,111,118,105,100,101,114,32)
               ___STR3(114,111,119)
___DEF_SUB_STR(___X6,42UL)
               ___STR8(65,83,67,69,78,84,32,115)
               ___STR8(101,115,115,105,111,110,32,111)
               ___STR8(117,116,112,117,116,32,102,97)
               ___STR8(99,116,32,98,117,100,103,101)
               ___STR8(116,32,101,120,99,101,101,100)
               ___STR2(101,100)
___DEF_SUB_STR(___X7,46UL)
               ___STR8(65,83,67,69,78,84,32,115)
               ___STR8(116,111,114,97,103,101,32,112)
               ___STR8(114,111,118,105,100,101,114,32)
               ___STR8(114,101,116,117,114,110,101,100)
               ___STR8(32,110,111,110,45,108,105,115)
               ___STR6(116,32,114,111,119,115)
___DEF_SUB_VEC(___X8,6UL)
               ___VEC1(___REF_SUB(9))
               ___VEC1(___REF_SUB(10))
               ___VEC1(___REF_NUL)
               ___VEC1(___REF_FIX(1))
               ___VEC1(___REF_PRC(1))
               ___VEC1(___REF_FAL)
               ___VEC0
___DEF_SUB_VEC(___X9,1UL)
               ___VEC1(___REF_SYM(4,___S_gerbil_2d_ascent____program____admission))
               ___VEC0
___DEF_SUB_VEC(___X10,0UL)
               ___VEC0

___BEGIN_SUB
 ___DEF_SUB(___X0)
,___DEF_SUB(___X1)
,___DEF_SUB(___X2)
,___DEF_SUB(___X3)
,___DEF_SUB(___X4)
,___DEF_SUB(___X5)
,___DEF_SUB(___X6)
,___DEF_SUB(___X7)
,___DEF_SUB(___X8)
,___DEF_SUB(___X9)
,___DEF_SUB(___X10)
___END_SUB



#undef ___MD_ALL
#define ___MD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4 ___D_F64(___F64V1) ___D_F64( \
___F64V2) ___D_F64(___F64V3)
#undef ___MR_ALL
#define ___MR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___MW_ALL
#define ___MW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_M_COD
___BEGIN_M_HLBL
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent____program____admission_23_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L11_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L12_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L13_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L14_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L15_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L16_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L17_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L18_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL(___L19_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L11_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L12_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L13_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L14_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L15_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L16_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L17_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L18_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L19_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L20_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L21_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L22_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L23_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L24_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L25_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L26_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L27_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L28_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L29_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L30_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L31_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L32_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L33_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L34_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L35_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_M_HLBL(___L36_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___END_M_HLBL

___BEGIN_M_SW

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent____program____admission_23_
#undef ___PH_LBL0
#define ___PH_LBL0 1
#undef ___PD_ALL
#define ___PD_ALL ___D_R0 ___D_R1
#undef ___PR_ALL
#define ___PR_ALL ___R_R0 ___R_R1
#undef ___PW_ALL
#define ___PW_ALL ___W_R1
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent____program____admission_23_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent____program____admission_23_)
   ___IF_NARGS_EQ(0,___NOTHING)
   ___WRONG_NARGS(0,0,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent____program____admission_23_)
   ___SET_GLO(4,___G_gerbil_2d_ascent_2f_program_2f_admission_3a__3a_timestamp,___BIGFIX(0,1791687860LL))
   ___SET_R1(___VOID)
   ___JUMPRET(___R0)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_
#undef ___PH_LBL0
#define ___PH_LBL0 3
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4 ___D_F64(___F64V1) ___D_F64(___F64V2) \

#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L11_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L12_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L13_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L14_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L15_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L16_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L17_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L18_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_P_HLBL(___L19_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___IF_NARGS_EQ(4,___NOTHING)
   ___WRONG_NARGS(0,4,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_STK(4,___R3)
   ___SET_R0(___LBL(1))
   ___ADJFP(7)
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_list_3f_)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L20_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
   ___GOTO(___L40_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_GLBL(___L20_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R3(___STK(-5))
   ___SET_R2(___STK(-3))
   ___SET_R1(___STK(-4))
   ___SET_R0(___STK(-6))
   ___ADJFP(-7)
   ___POLL(3)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_GLBL(___L21_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___IF(___NOT(___PAIRP(___R3)))
   ___GOTO(___L39_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
   ___SET_R4(___CAR(___R3))
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_STK(4,___R3)
   ___SET_STK(5,___R4)
   ___SET_R1(___R4)
   ___SET_R0(___LBL(4))
   ___ADJFP(11)
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_list_3f_)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L38_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
   ___GOTO(___L22_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L23_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
___DEF_GLBL(___L22_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R3(___STK(-6))
   ___SET_R2(___STK(-11))
   ___SET_R1(___SUB(1))
   ___POLL(6)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R0(___LBL(7))
   ___JUMPGLONOTSAFE(___SET_NARGS(3),16,___G_error)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___IF(___NOTFALSEP(___STK(-8)))
   ___GOTO(___L24_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
   ___GOTO(___L25_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___IF(___FIXNUMSP(___FIXNUMSP2(___FIXNUMSP1(___R1),___STK(-9))))
   ___GOTO(___L36_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
   ___IF(___NOT(___IFLONUMSP(___IFLONUMSP2(___IFLONUMSP1(___R1),___STK(-9)))))
   ___GOTO(___L37_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
   ___SET_F64(___F64V1,___F64UNBOXI(___R1))
   ___SET_F64(___F64V2,___F64UNBOXI(___STK(-9)))
   ___IF(___NOT(___F64EQ(___F64V1,___F64V2)))
   ___GOTO(___L22_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
___DEF_GLBL(___L23_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___IF(___NOT(___NOTFALSEP(___STK(-8))))
   ___GOTO(___L25_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
___DEF_GLBL(___L24_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R1(___STK(-6))
   ___POLL(9)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R0(___LBL(10))
   ___ADJFP(-4)
   ___JUMPGENSAFE(___SET_NARGS(1),___STK(-4))
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___GOTO(___L26_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_GLBL(___L25_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___ADJFP(-4)
___DEF_GLBL(___L26_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R1(___CDR(___STK(-3)))
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L35_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
   ___SET_R2(___CAR(___R1))
   ___SET_STK(-3,___R1)
   ___SET_STK(-2,___R2)
   ___SET_R1(___R2)
   ___SET_R0(___LBL(11))
   ___ADJFP(4)
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_list_3f_)
___DEF_SLBL(11,___L11_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L34_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
   ___GOTO(___L27_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_SLBL(12,___L12_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L28_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
___DEF_GLBL(___L27_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R3(___STK(-6))
   ___SET_R2(___STK(-11))
   ___SET_R1(___SUB(1))
   ___POLL(13)
___DEF_SLBL(13,___L13_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R0(___LBL(14))
   ___JUMPGLONOTSAFE(___SET_NARGS(3),16,___G_error)
___DEF_SLBL(14,___L14_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___IF(___NOTFALSEP(___STK(-8)))
   ___GOTO(___L29_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
   ___GOTO(___L30_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_SLBL(15,___L15_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___IF(___FIXNUMSP(___FIXNUMSP2(___FIXNUMSP1(___R1),___STK(-9))))
   ___GOTO(___L32_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
   ___IF(___NOT(___IFLONUMSP(___IFLONUMSP2(___IFLONUMSP1(___R1),___STK(-9)))))
   ___GOTO(___L33_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
   ___SET_F64(___F64V1,___F64UNBOXI(___R1))
   ___SET_F64(___F64V2,___F64UNBOXI(___STK(-9)))
   ___IF(___NOT(___F64EQ(___F64V1,___F64V2)))
   ___GOTO(___L27_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
___DEF_GLBL(___L28_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___IF(___NOT(___NOTFALSEP(___STK(-8))))
   ___GOTO(___L30_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
___DEF_GLBL(___L29_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R1(___STK(-6))
   ___POLL(16)
___DEF_SLBL(16,___L16_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R0(___LBL(17))
   ___ADJFP(-4)
   ___JUMPGENSAFE(___SET_NARGS(1),___STK(-4))
___DEF_SLBL(17,___L17_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___GOTO(___L31_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_GLBL(___L30_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___ADJFP(-4)
___DEF_GLBL(___L31_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R3(___CDR(___STK(-3)))
   ___SET_R2(___STK(-4))
   ___SET_R1(___STK(-5))
   ___SET_R0(___STK(-6))
   ___ADJFP(-7)
   ___POLL(18)
___DEF_SLBL(18,___L18_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___GOTO(___L21_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_GLBL(___L32_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___IF(___FIXEQ(___R1,___STK(-9)))
   ___GOTO(___L28_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
   ___GOTO(___L27_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_GLBL(___L33_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R2(___STK(-9))
   ___SET_R0(___LBL(12))
   ___JUMPPRM(___SET_NARGS(2),___PRM__3d_)
___DEF_GLBL(___L34_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R1(___STK(-6))
   ___SET_R0(___LBL(15))
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_length)
___DEF_GLBL(___L35_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R1(___VOID)
   ___ADJFP(-8)
   ___JUMPRET(___STK(2))
___DEF_GLBL(___L36_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___IF(___FIXEQ(___R1,___STK(-9)))
   ___GOTO(___L23_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___END_IF
   ___GOTO(___L22_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
___DEF_GLBL(___L37_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R2(___STK(-9))
   ___SET_R0(___LBL(5))
   ___JUMPPRM(___SET_NARGS(2),___PRM__3d_)
___DEF_GLBL(___L38_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R1(___STK(-6))
   ___SET_R0(___LBL(8))
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_length)
___DEF_GLBL(___L39_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R1(___VOID)
   ___ADJFP(-1)
   ___JUMPRET(___R0)
___DEF_GLBL(___L40_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R3(___STK(-5))
   ___SET_R2(___STK(-7))
   ___SET_R1(___SUB(2))
   ___POLL(19)
___DEF_SLBL(19,___L19_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_)
   ___SET_R0(___LBL(2))
   ___JUMPGLONOTSAFE(___SET_NARGS(3),16,___G_error)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_
#undef ___PH_LBL0
#define ___PH_LBL0 24
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4 ___D_F64(___F64V1) ___D_F64(___F64V2) \

#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___IF_NARGS_EQ(8,___NOTHING)
   ___WRONG_NARGS(0,8,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_STK(4,___R3)
   ___SET_R1(___STK(-4))
   ___SET_R0(___LBL(1))
   ___ADJFP(7)
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_list_3f_)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L15_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___END_IF
   ___GOTO(___L9_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L10_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___END_IF
___DEF_GLBL(___L9_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___SET_R2(___STK(-11))
   ___SET_R1(___SUB(3))
   ___POLL(3)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___SET_R0(___LBL(4))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),16,___G_error)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___IF(___NOTFALSEP(___STK(-9)))
   ___GOTO(___L11_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___END_IF
   ___GOTO(___L12_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___IF(___FIXNUMSP(___FIXNUMSP2(___FIXNUMSP1(___R1),___STK(-10))))
   ___GOTO(___L13_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___END_IF
   ___IF(___NOT(___IFLONUMSP(___IFLONUMSP2(___IFLONUMSP1(___R1),___STK(-10)))))
   ___GOTO(___L14_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___END_IF
   ___SET_F64(___F64V1,___F64UNBOXI(___R1))
   ___SET_F64(___F64V2,___F64UNBOXI(___STK(-10)))
   ___IF(___NOT(___F64EQ(___F64V1,___F64V2)))
   ___GOTO(___L9_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___END_IF
___DEF_GLBL(___L10_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___IF(___NOT(___NOTFALSEP(___STK(-9))))
   ___GOTO(___L12_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___END_IF
___DEF_GLBL(___L11_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___SET_R1(___STK(-11))
   ___POLL(6)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___SET_R0(___LBL(7))
   ___JUMPGENSAFE(___SET_NARGS(1),___STK(-9))
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_GLBL(___L12_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___SET_STK(-10,___STK(-8))
   ___SET_STK(-9,___STK(-7))
   ___SET_R3(___STK(-3))
   ___SET_R2(___STK(-4))
   ___SET_R1(___STK(-5))
   ___SET_R0(___STK(-6))
   ___POLL(8)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___ADJFP(-9)
   ___JUMPINT(___SET_NARGS(6),___PRC(34),___L_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_GLBL(___L13_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___IF(___FIXEQ(___R1,___STK(-10)))
   ___GOTO(___L10_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___END_IF
   ___GOTO(___L9_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
___DEF_GLBL(___L14_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___SET_R2(___STK(-10))
   ___SET_R0(___LBL(2))
   ___JUMPPRM(___SET_NARGS(2),___PRM__3d_)
___DEF_GLBL(___L15_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_)
   ___SET_R1(___STK(-11))
   ___SET_R0(___LBL(5))
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_length)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_
#undef ___PH_LBL0
#define ___PH_LBL0 34
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4 ___D_F64(___F64V1) ___D_F64( \
___F64V2)
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___IF_NARGS_EQ(6,___NOTHING)
   ___WRONG_NARGS(0,6,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_STK(4,___R3)
   ___SET_R2(___STK(-2))
   ___SET_R1(___STK(-1))
   ___SET_R3(___TRU)
   ___ADJFP(9)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___SET_R0(___LBL(2))
   ___JUMPGLONOTSAFE(___SET_NARGS(3),18,___G_hash_2d_put_21_)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___IF(___NOT(___FIXNUMP(___STK(-6))))
   ___GOTO(___L20_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___END_IF
   ___IF(___NOT(___FIXADDPCONSTY_NOTFALSEP(___R1,___STK(-6),___FIX(1L))))
   ___SET_R1(___FAL)
   ___GOTO(___L20_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___END_IF
   ___IF(___FIXNUMSP(___FIXNUMSP2(___FIXNUMSP1(___R1),___STK(-5))))
   ___GOTO(___L9_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___END_IF
   ___GOTO(___L15_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___IF(___NOT(___FIXNUMSP(___FIXNUMSP2(___FIXNUMSP1(___R1),___STK(-5)))))
   ___GOTO(___L15_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___END_IF
___DEF_GLBL(___L9_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___IF(___NOT(___FIXGT(___R1,___STK(-5))))
   ___GOTO(___L16_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___END_IF
___DEF_GLBL(___L10_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___ADJFP(-4)
___DEF_GLBL(___L11_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___SET_STK(-6,___R1)
   ___SET_R1(___SUB(4))
   ___SET_R0(___LBL(4))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),16,___G_error)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___SET_R1(___STK(-6))
   ___IF(___VECTORP(___STK(-5)))
   ___GOTO(___L12_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___END_IF
   ___GOTO(___L17_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L19_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___END_IF
   ___SET_R1(___STK(-6))
   ___IF(___NOT(___VECTORP(___STK(-5))))
   ___GOTO(___L17_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___END_IF
___DEF_GLBL(___L12_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___IF(___NOT(___VECTORINBOUNDSP(___STK(-5),___STK(-3))))
   ___GOTO(___L17_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___END_IF
   ___SET_R2(___VECTORREF(___STK(-5),___STK(-3)))
   ___SET_R2(___CONS(___STK(-7),___R2))
   ___CHECK_HEAP(6,4096)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___IF(___NOT(___VECTORP(___STK(-5))))
   ___GOTO(___L13_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___END_IF
   ___IF(___NOT(___MUTABLEP(___STK(-5))))
   ___GOTO(___L13_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___END_IF
   ___IF(___VECTORINBOUNDSP(___STK(-5),___STK(-3)))
   ___GOTO(___L14_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___END_IF
___DEF_GLBL(___L13_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___SET_STK(-7,___R1)
   ___SET_R3(___R2)
   ___SET_R2(___STK(-3))
   ___SET_R1(___STK(-5))
   ___SET_R0(___LBL(7))
   ___JUMPPRM(___SET_NARGS(3),___PRM_vector_2d_set_21_)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___SET_R0(___LBL(7))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L14_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___VECTORSET(___STK(-5),___STK(-3),___R2)
   ___ADJFP(-8)
   ___JUMPRET(___STK(4))
___DEF_GLBL(___L15_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___IF(___NOT(___IFLONUMSP(___IFLONUMSP2(___IFLONUMSP1(___R1),___STK(-5)))))
   ___GOTO(___L18_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___END_IF
   ___SET_F64(___F64V1,___F64UNBOXI(___R1))
   ___SET_F64(___F64V2,___F64UNBOXI(___STK(-5)))
   ___IF(___F64GT(___F64V1,___F64V2))
   ___GOTO(___L10_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___END_IF
___DEF_GLBL(___L16_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___ADJFP(-4)
   ___IF(___VECTORP(___STK(-5)))
   ___GOTO(___L12_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___END_IF
___DEF_GLBL(___L17_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___SET_STK(-6,___R1)
   ___SET_R2(___STK(-3))
   ___SET_R1(___STK(-5))
   ___SET_R0(___LBL(8))
   ___JUMPPRM(___SET_NARGS(2),___PRM_vector_2d_ref)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___SET_R0(___LBL(8))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L18_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___SET_STK(-10,___R1)
   ___SET_R2(___STK(-5))
   ___SET_R0(___LBL(5))
   ___ADJFP(-4)
   ___JUMPPRM(___SET_NARGS(2),___PRM__3e_)
___DEF_GLBL(___L19_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___SET_R1(___STK(-6))
   ___GOTO(___L11_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
___DEF_GLBL(___L20_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_)
   ___SET_R1(___STK(-6))
   ___SET_R2(___FIX(1L))
   ___SET_R0(___LBL(3))
   ___JUMPPRM(___SET_NARGS(2),___PRM__2b_)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch
#undef ___PH_LBL0
#define ___PH_LBL0 44
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4 ___D_F64(___F64V1) ___D_F64( \
___F64V2) ___D_F64(___F64V3)
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L11_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L12_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L13_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L14_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L15_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L16_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L17_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L18_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L19_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L20_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L21_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L22_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L23_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L24_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L25_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L26_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L27_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L28_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L29_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L30_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L31_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L32_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L33_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L34_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L35_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_P_HLBL(___L36_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF_NARGS_EQ(6,___NOTHING)
   ___WRONG_NARGS(0,6,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_STK(4,___R3)
   ___SET_R1(___STK(-2))
   ___SET_R0(___LBL(1))
   ___ADJFP(9)
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_list_3f_)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L81_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___IF(___PAIRP(___STK(-11)))
   ___GOTO(___L37_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___GOTO(___L38_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOT(___PAIRP(___STK(-11))))
   ___GOTO(___L38_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
___DEF_GLBL(___L37_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R1(___CDR(___STK(-11)))
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L38_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___SET_STK(1,___FAL)
   ___SET_STK(2,___GLO_absent_2d_value)
   ___SET_STK(3,___GLO_absent_2d_value)
   ___SET_STK(4,___GLO_absent_2d_value)
   ___SET_STK(5,___GLO_absent_2d_value)
   ___SET_STK(6,___GLO_absent_2d_value)
   ___SET_R3(___GLO_absent_2d_value)
   ___SET_R2(___GLO_absent_2d_value)
   ___SET_R1(___GLO_absent_2d_value)
   ___ADJFP(6)
   ___POLL(3)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R0(___LBL(4))
   ___JUMPGLONOTSAFE(___SET_NARGS(9),19,___G_make_2d_hash_2d_table_____25_)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___GOTO(___L39_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_GLBL(___L38_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R1(___FAL)
___DEF_GLBL(___L39_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R2(___CONS(___FAL,___NUL))
   ___SET_R3(___BOX(___R2))
   ___SET_STK(-4,___R1)
   ___SET_STK(-3,___R2)
   ___SET_STK(1,___STK(-10))
   ___SET_STK(2,___STK(-9))
   ___SET_STK(3,___STK(-7))
   ___SET_STK(-10,___R3)
   ___SET_R3(___STK(-11))
   ___SET_R2(___STK(-10))
   ___SET_R0(___LBL(29))
   ___ADJFP(3)
   ___CHECK_HEAP(5,4096)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___POLL(6)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_GLBL(___L40_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOT(___PAIRP(___R3)))
   ___GOTO(___L65_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___SET_R4(___CAR(___R3))
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_STK(4,___R3)
   ___SET_STK(5,___R4)
   ___SET_R1(___R4)
   ___SET_R0(___LBL(7))
   ___ADJFP(9)
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_list_3f_)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L64_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___GOTO(___L41_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L42_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
___DEF_GLBL(___L41_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R2(___STK(-4))
   ___SET_R1(___SUB(5))
   ___POLL(9)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R0(___LBL(10))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),16,___G_error)
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOTFALSEP(___STK(-10)))
   ___GOTO(___L43_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___GOTO(___L44_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_SLBL(11,___L11_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___FIXNUMSP(___FIXNUMSP2(___FIXNUMSP1(___R1),___STK(-11))))
   ___GOTO(___L62_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___IF(___NOT(___IFLONUMSP(___IFLONUMSP2(___IFLONUMSP1(___R1),___STK(-11)))))
   ___GOTO(___L63_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___SET_F64(___F64V1,___F64UNBOXI(___R1))
   ___SET_F64(___F64V2,___F64UNBOXI(___STK(-11)))
   ___IF(___NOT(___F64EQ(___F64V1,___F64V2)))
   ___GOTO(___L41_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
___DEF_GLBL(___L42_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOT(___NOTFALSEP(___STK(-10))))
   ___GOTO(___L44_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
___DEF_GLBL(___L43_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R1(___STK(-4))
   ___POLL(12)
___DEF_SLBL(12,___L12_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R0(___LBL(13))
   ___JUMPGENSAFE(___SET_NARGS(1),___STK(-10))
___DEF_SLBL(13,___L13_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_GLBL(___L44_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R2(___STK(-4))
   ___SET_R1(___STK(-9))
   ___POLL(14)
___DEF_SLBL(14,___L14_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R0(___LBL(15))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),17,___G_hash_2d_get)
___DEF_SLBL(15,___L15_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L46_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___GOTO(___L59_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_SLBL(16,___L16_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_GLBL(___L45_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R1(___CONS(___STK(-4),___NUL))
   ___SET_R2(___UNBOX(___STK(-6)))
   ___SETCDR(___R2,___R1)
   ___SETBOX(___STK(-6),___R1)
   ___CHECK_HEAP(17,4096)
___DEF_SLBL(17,___L17_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_GLBL(___L46_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R1(___CDR(___STK(-5)))
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L58_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___SET_R2(___CAR(___R1))
   ___SET_STK(-5,___R1)
   ___SET_STK(-4,___R2)
   ___SET_R1(___R2)
   ___SET_R0(___LBL(18))
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_list_3f_)
___DEF_SLBL(18,___L18_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L56_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___SET_R1(___STK(-4))
   ___SET_R0(___LBL(19))
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_length)
___DEF_SLBL(19,___L19_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOT(___FIXNUMSP(___FIXNUMSP2(___FIXNUMSP1(___R1),___STK(-11)))))
   ___GOTO(___L55_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___IF(___FIXEQ(___R1,___STK(-11)))
   ___GOTO(___L47_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___GOTO(___L56_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_SLBL(20,___L20_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L56_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
___DEF_GLBL(___L47_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOT(___NOTFALSEP(___STK(-10))))
   ___GOTO(___L49_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
___DEF_GLBL(___L48_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R1(___STK(-4))
   ___SET_R0(___LBL(21))
   ___JUMPGENSAFE(___SET_NARGS(1),___STK(-10))
___DEF_SLBL(21,___L21_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___GOTO(___L49_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_SLBL(22,___L22_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOTFALSEP(___STK(-10)))
   ___GOTO(___L48_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
___DEF_GLBL(___L49_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R2(___STK(-4))
   ___SET_R1(___STK(-9))
   ___SET_R0(___LBL(23))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),17,___G_hash_2d_get)
___DEF_SLBL(23,___L23_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L51_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___GOTO(___L52_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_SLBL(24,___L24_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_GLBL(___L50_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R1(___CONS(___STK(-4),___NUL))
   ___SET_R2(___UNBOX(___STK(-6)))
   ___SETCDR(___R2,___R1)
   ___SETBOX(___STK(-6),___R1)
   ___CHECK_HEAP(25,4096)
___DEF_SLBL(25,___L25_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_GLBL(___L51_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R3(___CDR(___STK(-5)))
   ___SET_R2(___STK(-6))
   ___SET_R1(___STK(-7))
   ___SET_R0(___STK(-8))
   ___ADJFP(-9)
   ___POLL(26)
___DEF_SLBL(26,___L26_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___GOTO(___L40_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_GLBL(___L52_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOTFALSEP(___STK(-7)))
   ___GOTO(___L54_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___GOTO(___L53_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_SLBL(27,___L27_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L51_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
___DEF_GLBL(___L53_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOT(___NOTFALSEP(___STK(-7))))
   ___GOTO(___L50_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___SET_R2(___STK(-4))
   ___SET_R1(___STK(-7))
   ___SET_R3(___TRU)
   ___SET_R0(___LBL(24))
   ___JUMPGLONOTSAFE(___SET_NARGS(3),14,___G_____hash_2d_put_21_)
___DEF_GLBL(___L54_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R2(___STK(-4))
   ___SET_R1(___STK(-7))
   ___SET_R0(___LBL(27))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),12,___G_____hash_2d_get)
___DEF_GLBL(___L55_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOT(___IFLONUMSP(___IFLONUMSP2(___IFLONUMSP1(___R1),___STK(-11)))))
   ___GOTO(___L57_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___SET_F64(___F64V1,___F64UNBOXI(___R1))
   ___SET_F64(___F64V2,___F64UNBOXI(___STK(-11)))
   ___IF(___F64EQ(___F64V1,___F64V2))
   ___GOTO(___L47_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
___DEF_GLBL(___L56_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R2(___STK(-4))
   ___SET_R1(___SUB(5))
   ___SET_R0(___LBL(22))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),16,___G_error)
___DEF_GLBL(___L57_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R2(___STK(-11))
   ___SET_R0(___LBL(20))
   ___JUMPPRM(___SET_NARGS(2),___PRM__3d_)
___DEF_GLBL(___L58_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R1(___VOID)
   ___ADJFP(-12)
   ___JUMPRET(___STK(4))
___DEF_GLBL(___L59_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOTFALSEP(___STK(-7)))
   ___GOTO(___L61_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___GOTO(___L60_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_SLBL(28,___L28_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L46_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
___DEF_GLBL(___L60_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOT(___NOTFALSEP(___STK(-7))))
   ___GOTO(___L45_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___SET_R2(___STK(-4))
   ___SET_R1(___STK(-7))
   ___SET_R3(___TRU)
   ___SET_R0(___LBL(16))
   ___JUMPGLONOTSAFE(___SET_NARGS(3),14,___G_____hash_2d_put_21_)
___DEF_GLBL(___L61_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R2(___STK(-4))
   ___SET_R1(___STK(-7))
   ___SET_R0(___LBL(28))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),12,___G_____hash_2d_get)
___DEF_GLBL(___L62_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___FIXEQ(___R1,___STK(-11)))
   ___GOTO(___L42_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___GOTO(___L41_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_GLBL(___L63_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R2(___STK(-11))
   ___SET_R0(___LBL(8))
   ___JUMPPRM(___SET_NARGS(2),___PRM__3d_)
___DEF_GLBL(___L64_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R1(___STK(-4))
   ___SET_R0(___LBL(11))
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_length)
___DEF_GLBL(___L65_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R1(___VOID)
   ___ADJFP(-3)
   ___JUMPRET(___R0)
___DEF_SLBL(29,___L29_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R1(___CDR(___STK(-3)))
   ___IF(___NOTFALSEP(___STK(-4)))
   ___GOTO(___L80_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L66_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___SET_R2(___FIX(1L))
   ___GOTO(___L67_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_GLBL(___L66_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R2(___FIX(0L))
___DEF_GLBL(___L67_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_STK(-11,___R1)
   ___SET_R1(___R2)
   ___IF(___NOT(___FIXNUMSP(___FIXNUMSP2(___FIXNUMSP1(___STK(-6)),___R1))))
   ___GOTO(___L77_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
___DEF_GLBL(___L68_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOT(___FIXADDP_NOTFALSEP(___R2,___STK(-6),___R1)))
   ___SET_R2(___FAL)
   ___GOTO(___L78_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___IF(___NOT(___FIXNUMSP(___FIXNUMSP2(___FIXNUMSP1(___R2),___STK(-5)))))
   ___GOTO(___L74_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
___DEF_GLBL(___L69_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOT(___FIXGT(___R2,___STK(-5))))
   ___GOTO(___L75_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
___DEF_GLBL(___L70_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___ADJFP(-4)
___DEF_GLBL(___L71_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_STK(-6,___R1)
   ___SET_R1(___SUB(6))
   ___SET_R0(___LBL(30))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),16,___G_error)
___DEF_SLBL(30,___L30_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R1(___STK(-6))
   ___GOTO(___L72_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_SLBL(31,___L31_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L73_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___SET_R1(___STK(-6))
___DEF_GLBL(___L72_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___BEGIN_ALLOC_VALUES(2UL)
   ___ADD_VALUES_ELEM(0,___STK(-7))
   ___ADD_VALUES_ELEM(1,___R1)
   ___END_ALLOC_VALUES(2)
   ___SET_R1(___GET_VALUES(2))
   ___ADJFP(-4)
   ___CHECK_HEAP(32,4096)
___DEF_SLBL(32,___L32_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___ADJFP(-4)
   ___JUMPRET(___STK(4))
___DEF_GLBL(___L73_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R1(___STK(-6))
   ___GOTO(___L71_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_SLBL(33,___L33_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R2(___R1)
   ___SET_R1(___STK(-10))
   ___IF(___FIXNUMSP(___FIXNUMSP2(___FIXNUMSP1(___R2),___STK(-5))))
   ___GOTO(___L69_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
___DEF_GLBL(___L74_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___NOT(___IFLONUMSP(___IFLONUMSP2(___IFLONUMSP1(___R2),___STK(-5)))))
   ___GOTO(___L76_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
   ___SET_F64(___F64V1,___F64UNBOXI(___R2))
   ___SET_F64(___F64V2,___F64UNBOXI(___STK(-5)))
   ___IF(___F64GT(___F64V1,___F64V2))
   ___GOTO(___L70_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
___DEF_GLBL(___L75_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___ADJFP(-4)
   ___GOTO(___L72_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_GLBL(___L76_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_STK(-10,___R1)
   ___SET_STK(-9,___R2)
   ___SET_R2(___STK(-5))
   ___SET_R1(___STK(-9))
   ___SET_R0(___LBL(31))
   ___ADJFP(-4)
   ___JUMPPRM(___SET_NARGS(2),___PRM__3e_)
___DEF_SLBL(34,___L34_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___FIXNUMSP(___FIXNUMSP2(___FIXNUMSP1(___STK(-6)),___R1)))
   ___GOTO(___L68_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
___DEF_GLBL(___L77_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___IF(___IFLONUMSP(___IFLONUMSP2(___IFLONUMSP1(___STK(-6)),___R1)))
   ___GOTO(___L79_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___END_IF
___DEF_GLBL(___L78_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_STK(-10,___R1)
   ___SET_R2(___R1)
   ___SET_R1(___STK(-6))
   ___SET_R0(___LBL(33))
   ___JUMPPRM(___SET_NARGS(2),___PRM__2b_)
___DEF_GLBL(___L79_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_F64(___F64V1,___F64UNBOXI(___STK(-6)))
   ___SET_F64(___F64V2,___F64UNBOXI(___R1))
   ___SET_F64(___F64V3,___F64ADD(___F64V1,___F64V2))
   ___SET_R2(___F64BOX(___F64V3))
   ___CHECK_HEAP_FLO(35,4096)
___DEF_SLBL(35,___L35_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___GOTO(___L74_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
___DEF_GLBL(___L80_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_STK(-11,___R1)
   ___SET_R1(___STK(-4))
   ___SET_R0(___LBL(34))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),13,___G_____hash_2d_length)
___DEF_GLBL(___L81_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R1(___SUB(7))
   ___POLL(36)
___DEF_SLBL(36,___L36_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch)
   ___SET_R0(___LBL(2))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),16,___G_error)
___END_P_SW
___END_P_COD

___END_M_SW
___END_M_COD

___BEGIN_LBL
 ___DEF_LBL_INTRO(___H_gerbil_2d_ascent____program____admission_23_,___REF_SYM(5,___S_gerbil_2d_ascent____program____admission_23_),___REF_FAL,1,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____program____admission_23_,0,-1)
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___REF_SYM(1,___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_),___REF_FAL,20,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,4,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___IFD(___RETN,5,1,0x1fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___IFD(___RETN,5,1,0x1fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___IFD(___RETI,1,4,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___IFD(___RETN,9,1,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___IFD(___RETN,9,1,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___OFD(___RETI,12,1,0x3f03fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___IFD(___RETN,9,1,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___IFD(___RETN,9,1,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___OFD(___RETI,12,1,0x3f01fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___IFD(___RETN,5,1,0x1fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___IFD(___RETN,9,1,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___IFD(___RETN,9,1,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___OFD(___RETI,12,1,0x3f03fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___IFD(___RETN,9,1,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___IFD(___RETN,9,1,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___OFD(___RETI,12,1,0x3f01fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___IFD(___RETN,5,1,0x1fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___IFD(___RETI,1,4,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,___IFD(___RETI,8,1,0x3f1fL))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_,___REF_SYM(2,___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_),___REF_FAL,9,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_,8,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_,___IFD(___RETN,9,5,0x1ffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_,___IFD(___RETN,9,5,0x1fdL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_,___OFD(___RETI,12,5,0x3f1fdL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_,___IFD(___RETN,9,5,0x1fdL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_,___IFD(___RETN,9,5,0x1ffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_,___OFD(___RETI,12,5,0x3f1fdL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_,___IFD(___RETN,9,5,0x1f9L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_,___OFD(___RETI,12,12,0x3f007L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_,___REF_SYM(0,___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_),___REF_FAL,9,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_,6,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_,___OFD(___RETI,12,3,0x3f07dL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_,___IFD(___RETN,9,3,0x7dL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_,___IFD(___RETN,9,3,0x5dL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_,___IFD(___RETN,5,3,0x1fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_,___IFD(___RETN,5,3,0x1fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_,___IFD(___RETI,8,3,0x3f1cL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_,___IFD(___RETN,5,3,0x9L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_,___IFD(___RETN,5,3,0x1fL))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___REF_SYM(3,___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch),___REF_FAL,37,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,6,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0x7fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0x7fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___OFD(___RETI,18,3,0x3f3f07fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0x7fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___OFD(___RETI,15,3,0x3f71e8L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___OFD(___RETI,15,3,0x3f71e8L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0xffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0xffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___OFD(___RETI,12,3,0x3f0ffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0xffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0xffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___OFD(___RETI,12,3,0x3f0ffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0xffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___OFD(___RETI,12,3,0x3f0ffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0xffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0xffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___OFD(___RETI,12,3,0x3f07fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0xffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0xffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0xffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0xffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0xffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0xffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0xffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___OFD(___RETI,12,3,0x3f07fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETI,3,4,0x3f7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0xffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0xffL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0x1e8L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,5,3,0xbL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,5,3,0xbL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETI,4,3,0x3f8L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0x4bL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___IFD(___RETN,9,3,0x69L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___OFD(___RETI,12,3,0x3f049L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,___OFD(___RETI,12,3,0x3f07fL))
___END_LBL

___BEGIN_OFD
 ___DEF_OFD(___RETI,12,1)
               ___GCMAP1(0x3f03fL)
,___DEF_OFD(___RETI,12,1)
               ___GCMAP1(0x3f01fL)
,___DEF_OFD(___RETI,12,1)
               ___GCMAP1(0x3f03fL)
,___DEF_OFD(___RETI,12,1)
               ___GCMAP1(0x3f01fL)
,___DEF_OFD(___RETI,12,5)
               ___GCMAP1(0x3f1fdL)
,___DEF_OFD(___RETI,12,5)
               ___GCMAP1(0x3f1fdL)
,___DEF_OFD(___RETI,12,12)
               ___GCMAP1(0x3f007L)
,___DEF_OFD(___RETI,12,3)
               ___GCMAP1(0x3f07dL)
,___DEF_OFD(___RETI,18,3)
               ___GCMAP1(0x3f3f07fL)
,___DEF_OFD(___RETI,15,3)
               ___GCMAP1(0x3f71e8L)
,___DEF_OFD(___RETI,15,3)
               ___GCMAP1(0x3f71e8L)
,___DEF_OFD(___RETI,12,3)
               ___GCMAP1(0x3f0ffL)
,___DEF_OFD(___RETI,12,3)
               ___GCMAP1(0x3f0ffL)
,___DEF_OFD(___RETI,12,3)
               ___GCMAP1(0x3f0ffL)
,___DEF_OFD(___RETI,12,3)
               ___GCMAP1(0x3f07fL)
,___DEF_OFD(___RETI,12,3)
               ___GCMAP1(0x3f07fL)
,___DEF_OFD(___RETI,12,3)
               ___GCMAP1(0x3f049L)
,___DEF_OFD(___RETI,12,3)
               ___GCMAP1(0x3f07fL)
___END_OFD

___BEGIN_MOD_PRM
___DEF_MOD_PRM(5,___G_gerbil_2d_ascent____program____admission_23_,1)
___DEF_MOD_PRM(1,___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,3)
___DEF_MOD_PRM(2,___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_,24)
___DEF_MOD_PRM(0,___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_,34)
___DEF_MOD_PRM(3,___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,44)
___END_MOD_PRM

___BEGIN_MOD_C_INIT
___END_MOD_C_INIT

___BEGIN_MOD_GLO
___DEF_MOD_GLO(5,___G_gerbil_2d_ascent____program____admission_23_,1)
___DEF_MOD_GLO(1,___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,3)
___DEF_MOD_GLO(2,___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_,24)
___DEF_MOD_GLO(0,___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_,34)
___DEF_MOD_GLO(3,___G_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,44)
___END_MOD_GLO

___BEGIN_MOD_SYM_KEY
___DEF_MOD_SYM(0,___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_admit_2d_source_2d_row_21_,"gerbil-ascent/program/admission#gerbil-ascent-admit-source-row!")

___DEF_MOD_SYM(1,___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_check_2d_replacement_2d_rows_21_,"gerbil-ascent/program/admission#gerbil-ascent-check-replacement-rows!")

___DEF_MOD_SYM(2,___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_initialize_2d_source_2d_row_21_,"gerbil-ascent/program/admission#gerbil-ascent-initialize-source-row!")

___DEF_MOD_SYM(3,___S_gerbil_2d_ascent_2f_program_2f_admission_23_gerbil_2d_ascent_2d_prepare_2d_storage_2d_batch,"gerbil-ascent/program/admission#gerbil-ascent-prepare-storage-batch")

___DEF_MOD_SYM(4,___S_gerbil_2d_ascent____program____admission,"gerbil-ascent__program__admission")

___DEF_MOD_SYM(5,___S_gerbil_2d_ascent____program____admission_23_,"gerbil-ascent__program__admission#")

___END_MOD_SYM_KEY

#endif
