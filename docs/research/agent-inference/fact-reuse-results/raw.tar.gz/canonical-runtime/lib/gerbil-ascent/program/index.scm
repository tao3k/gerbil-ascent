(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "std/iter")
    (load-module "std/list/list-builder")
    (load-module "gerbil-ascent/core/relation-view")
    (load-module "gerbil-ascent/table/index-sharing")
    (load-module "gerbil-ascent/core/positive-plan")
    (load-module "gerbil-ascent/table/access")
    (load-module "gerbil-ascent/table/provider")
    (load-module "gerbil-ascent/table/funs"))
  (load-module "gerbil-ascent/program/index~0"))
