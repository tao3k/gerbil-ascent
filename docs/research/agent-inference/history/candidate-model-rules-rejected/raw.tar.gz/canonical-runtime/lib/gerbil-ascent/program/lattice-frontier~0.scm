(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/lattice-frontier::timestamp 1791687860)
  (begin
    (define gerbil-ascent/program/lattice-frontier#lattice-round::t
      (let ((__tmp33796 (list))
            (__tmp33795
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/lattice-frontier#lattice-round::t
         'lattice-round
         __tmp33796
         '(table changes sequence ordered?)
         __tmp33795
         '#f)))
    (define gerbil-ascent/program/lattice-frontier#lattice-round?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/lattice-frontier#lattice-round::t)))
    (define gerbil-ascent/program/lattice-frontier#make-lattice-round
      (lambda _%$args16302%_
        (apply make-instance
               gerbil-ascent/program/lattice-frontier#lattice-round::t
               _%$args16302%_)))
    (define gerbil-ascent/program/lattice-frontier#lattice-round-table
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'table)))
    (define gerbil-ascent/program/lattice-frontier#lattice-round-changes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'changes)))
    (define gerbil-ascent/program/lattice-frontier#lattice-round-sequence
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'sequence)))
    (define gerbil-ascent/program/lattice-frontier#lattice-round-ordered?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'ordered?)))
    (define gerbil-ascent/program/lattice-frontier#lattice-round-table-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'table)))
    (define gerbil-ascent/program/lattice-frontier#lattice-round-changes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'changes)))
    (define gerbil-ascent/program/lattice-frontier#lattice-round-sequence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'sequence)))
    (define gerbil-ascent/program/lattice-frontier#lattice-round-ordered?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'ordered?)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-round-table
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'table)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-round-changes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'changes)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-round-sequence
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'sequence)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-round-ordered?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'ordered?)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-round-table-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'table)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-round-changes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'changes)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-round-sequence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'sequence)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-round-ordered?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'ordered?)))
    (define gerbil-ascent/program/lattice-frontier#lattice-change::t
      (let ((__tmp33798 (list))
            (__tmp33797
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/lattice-frontier#lattice-change::t
         'lattice-change
         __tmp33798
         '(row sequence)
         __tmp33797
         '#f)))
    (define gerbil-ascent/program/lattice-frontier#lattice-change?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/lattice-frontier#lattice-change::t)))
    (define gerbil-ascent/program/lattice-frontier#make-lattice-change
      (lambda _%$args16299%_
        (apply make-instance
               gerbil-ascent/program/lattice-frontier#lattice-change::t
               _%$args16299%_)))
    (define gerbil-ascent/program/lattice-frontier#lattice-change-row
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/lattice-frontier#lattice-change::t
         'row)))
    (define gerbil-ascent/program/lattice-frontier#lattice-change-sequence
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/lattice-frontier#lattice-change::t
         'sequence)))
    (define gerbil-ascent/program/lattice-frontier#lattice-change-row-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/lattice-frontier#lattice-change::t
         'row)))
    (define gerbil-ascent/program/lattice-frontier#lattice-change-sequence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/lattice-frontier#lattice-change::t
         'sequence)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-change-row
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/lattice-frontier#lattice-change::t
         'row)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-change-sequence
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/lattice-frontier#lattice-change::t
         'sequence)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-change-row-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/lattice-frontier#lattice-change::t
         'row)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-change-sequence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/lattice-frontier#lattice-change::t
         'sequence)))
    (define gerbil-ascent/program/lattice-frontier#make-lattice-frontier
      (lambda ()
        (let ((__tmp33799
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/lattice-frontier#lattice-round::t
           __tmp33799
           '()
           '0
           '#t))))
    (define gerbil-ascent/program/lattice-frontier#__lattice-frontier-ref
      (lambda (_%frontier16269%_ _%key16270%_)
        (let* ((_%frontier16273%_ _%frontier16269%_)
               (_%$%node1628116283%_
                (let ((__tmp33800
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%frontier16273%_
                          '1
                          '#f
                          '#f))))
                  (declare (not safe))
                  (hash-get __tmp33800 _%key16270%_))))
          (if _%$%node1628116283%_
              (let* ((_%node16285%_ _%$%node1628116283%_)
                     (_%node16287%_ _%node16285%_))
                (declare (not safe))
                (##unchecked-structure-ref _%node16287%_ '1 '#f '#f))
              '#f))))
    (define gerbil-ascent/program/lattice-frontier#lattice-frontier-ref
      (lambda (_%frontier16256%_ _%key16257%_)
        (let ((_%frontier16260%_ _%frontier16256%_))
          (gerbil-ascent/program/lattice-frontier#__lattice-frontier-ref
           _%frontier16260%_
           _%key16257%_))))
    (define gerbil-ascent/program/lattice-frontier#__lattice-frontier-stage!
      (lambda (_%frontier16220%_ _%key16221%_ _%row16222%_)
        (let* ((_%frontier16225%_ _%frontier16220%_)
               (_%sequence16234%_
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-ref _%frontier16225%_ '3 '#f '#f))))
          (let ((__tmp33801 (+ _%sequence16234%_ '1)))
            (declare (not safe))
            (##unchecked-structure-set!
             _%frontier16225%_
             __tmp33801
             '3
             '#f
             '#f))
          (let ((_%$e16236%_
                 (let ((__tmp33802
                        (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%frontier16225%_
                           '1
                           '#f
                           '#f))))
                   (declare (not safe))
                   (hash-get __tmp33802 _%key16221%_))))
            (if _%$e16236%_
                (let ()
                  (let ((_%node16241%_ _%$e16236%_))
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-set!
                       _%node16241%_
                       _%row16222%_
                       '1
                       '#f
                       '#f))
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-set!
                       _%node16241%_
                       _%sequence16234%_
                       '2
                       '#f
                       '#f)))
                  (if (eq? _%$e16236%_
                           (car (let ()
                                  (declare (not safe))
                                  (##unchecked-structure-ref
                                   _%frontier16225%_
                                   '2
                                   '#f
                                   '#f))))
                      '#!void
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-set!
                         _%frontier16225%_
                         '#f
                         '4
                         '#f
                         '#f)))
                  '#f)
                (let ((_%node16254%_
                       (let ()
                         (declare (not safe))
                         (##structure
                          gerbil-ascent/program/lattice-frontier#lattice-change::t
                          _%row16222%_
                          _%sequence16234%_))))
                  (let ((__tmp33803
                         (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%frontier16225%_
                            '1
                            '#f
                            '#f))))
                    (declare (not safe))
                    (hash-put! __tmp33803 _%key16221%_ _%node16254%_))
                  (let ((__tmp33804
                         (cons _%node16254%_
                               (let ()
                                 (declare (not safe))
                                 (##unchecked-structure-ref
                                  _%frontier16225%_
                                  '2
                                  '#f
                                  '#f)))))
                    (declare (not safe))
                    (##unchecked-structure-set!
                     _%frontier16225%_
                     __tmp33804
                     '2
                     '#f
                     '#f))
                  '#t))))))
    (define gerbil-ascent/program/lattice-frontier#lattice-frontier-stage!
      (lambda (_%frontier16206%_ _%key16207%_ _%row16208%_)
        (let ((_%frontier16211%_ _%frontier16206%_))
          (gerbil-ascent/program/lattice-frontier#__lattice-frontier-stage!
           _%frontier16211%_
           _%key16207%_
           _%row16208%_))))
    (define gerbil-ascent/program/lattice-frontier#__lattice-frontier-rows
      (lambda (_%frontier16163%_)
        (let ((_%frontier16166%_ _%frontier16163%_))
          (map (lambda (_%node16175%_)
                 (let ((_%node16177%_ _%node16175%_))
                   (declare (not safe))
                   (##unchecked-structure-ref _%node16177%_ '1 '#f '#f)))
               (if (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref _%frontier16166%_ '4 '#f '#f))
                   (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref _%frontier16166%_ '2 '#f '#f))
                   (list-sort
                    (lambda (_%a16187%_ _%b16188%_)
                      (let* ((_%a16190%_ _%a16187%_) (_%b16197%_ _%b16188%_))
                        (> (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref _%a16190%_ '2 '#f '#f))
                           (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%b16197%_
                              '2
                              '#f
                              '#f)))))
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-ref
                       _%frontier16166%_
                       '2
                       '#f
                       '#f))))))))
    (define gerbil-ascent/program/lattice-frontier#lattice-frontier-rows
      (lambda (_%frontier16151%_)
        (let ((_%frontier16154%_ _%frontier16151%_))
          (gerbil-ascent/program/lattice-frontier#__lattice-frontier-rows
           _%frontier16154%_))))
    (define gerbil-ascent/program/lattice-frontier#__lattice-frontier-clear!
      (lambda (_%frontier16139%_)
        (let ((_%frontier16142%_ _%frontier16139%_))
          (let ((__tmp33805
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%frontier16142%_ '1 '#f '#f))))
            (declare (not safe))
            (hash-clear! __tmp33805))
          (let ()
            (declare (not safe))
            (##unchecked-structure-set! _%frontier16142%_ '() '2 '#f '#f))
          (let ()
            (declare (not safe))
            (##unchecked-structure-set! _%frontier16142%_ '0 '3 '#f '#f))
          (let ()
            (declare (not safe))
            (##unchecked-structure-set! _%frontier16142%_ '#t '4 '#f '#f)))))
    (define gerbil-ascent/program/lattice-frontier#lattice-frontier-clear!
      (lambda (_%frontier16127%_)
        (let ((_%frontier16130%_ _%frontier16127%_))
          (gerbil-ascent/program/lattice-frontier#__lattice-frontier-clear!
           _%frontier16130%_))))))
