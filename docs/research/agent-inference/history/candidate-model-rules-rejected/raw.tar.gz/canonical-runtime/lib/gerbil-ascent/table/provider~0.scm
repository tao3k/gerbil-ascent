(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/provider::timestamp 1791687863)
  (begin
    (define gerbil-ascent/table/provider#+procedure+
      (let ((__tmp34427 (lambda (_%_value4286%_ _%_context4287%_) '())))
        (declare (not safe))
        (core/types#poo-flow-predicate-contract
         'ascent/index-provider-procedure
         procedure?
         __tmp34427)))
    (define gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
      (let ((__obj34424
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp34429
               (list (cons 'sexp
                           (let ((__tmp34430
                                  (lambda (_%@4226%_)
                                    'GerbilAscentIndexProviderContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34430)))
                     (cons 'identity
                           (let ((__tmp34431
                                  (lambda (_%@4232%_) 'ascent/index-provider)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34431)))
                     (cons 'proto
                           (let ((__tmp34432
                                  (lambda (_%@4237%_)
                                    (let ((__obj34422
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp34434 (list))
                                            (__tmp34433 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp34434
                                         __tmp34433
                                         __obj34422))
                                      __obj34422))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34432)))
                     (cons 'responsibilities
                           (let ((__tmp34435
                                  (lambda (_%@4251%_)
                                    (let ((__obj34423
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp34437
                                             (list (cons '.build-index
                                                         (let ((__tmp34438
                                                                (lambda (_%self4269%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/table/provider#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp34438)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.extend-index!
                                                         (let ((__tmp34439
                                                                (lambda (_%self4276%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/table/provider#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp34439)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons '.lookup-index
                                                         (let ((__tmp34440
                                                                (lambda (_%self4281%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          gerbil-ascent/table/provider#+procedure+)))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp34440)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp34436 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp34437
                                         __tmp34436
                                         __obj34423))
                                      __obj34423))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34435)))))
              (__tmp34428 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp34429
           __tmp34428
           __obj34424))
        __obj34424))
    (define gerbil-ascent/table/provider#IndexProvider.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
         'proto)))
    (define gerbil-ascent/table/provider#gerbil-ascent-index-provider-build
      (lambda (_%provider4209%_ _%rows4210%_ _%columns4211%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%provider4209%_ '.build-index))
         _%rows4210%_
         _%columns4211%_)))
    (define gerbil-ascent/table/provider#gerbil-ascent-index-provider-extend!
      (lambda (_%provider4204%_ _%index4205%_ _%rows4206%_ _%columns4207%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%provider4204%_ '.extend-index!))
         _%index4205%_
         _%rows4206%_
         _%columns4207%_)))
    (define gerbil-ascent/table/provider#gerbil-ascent-index-provider-lookup
      (lambda (_%provider4200%_ _%index4201%_ _%key4202%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%provider4200%_ '.lookup-index))
         _%index4201%_
         _%key4202%_)))
    (define gerbil-ascent/table/provider#+canonical-hash-index-provider+
      (let ((__tmp34441
             (let ((__obj34425
                    (let ()
                      (declare (not safe))
                      (##structure
                       clan/poo/object#object::t
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f))))
               (let ((__tmp34443
                      (list (cons '.build-index
                                  (let ((__tmp34444
                                         (lambda (_%@4178%_)
                                           gerbil-ascent/table/funs#gerbil-ascent-index-build)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp34444)))
                            (cons '.extend-index!
                                  (let ((__tmp34445
                                         (lambda (_%@4184%_)
                                           gerbil-ascent/table/funs#gerbil-ascent-index-extend!)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp34445)))
                            (cons '.lookup-index
                                  (let ((__tmp34446
                                         (lambda (_%@4189%_)
                                           (lambda (_%index4194%_ _%key4195%_)
                                             (let ((_%$e4197%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (hash-get
                                                       _%index4194%_
                                                       _%key4195%_))))
                                               (if _%$e4197%_
                                                   _%$e4197%_
                                                   '()))))))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp34446)))))
                     (__tmp34442 (list)))
                 (declare (not safe))
                 (clan/poo/object#object:::init!__%
                  '#f
                  gerbil-ascent/table/provider#IndexProvider.
                  __tmp34443
                  __tmp34442
                  __obj34425))
               __obj34425)))
        (declare (not safe))
        (clan/poo/mop#validate
         gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
         __tmp34441)))
    (define gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider
      gerbil-ascent/table/provider#+canonical-hash-index-provider+)
    (define gerbil-ascent/table/provider#+curried-index-provider+
      (let ((__tmp34447
             (let ((__obj34426
                    (let ()
                      (declare (not safe))
                      (##structure
                       clan/poo/object#object::t
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f))))
               (let ((__tmp34449
                      (list (cons '.build-index
                                  (let ((__tmp34450
                                         (lambda (_%@4144%_)
                                           gerbil-ascent/table/funs#gerbil-ascent-index-build)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp34450)))
                            (cons '.extend-index!
                                  (let ((__tmp34451
                                         (lambda (_%@4150%_)
                                           gerbil-ascent/table/funs#gerbil-ascent-index-extend!)))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp34451)))
                            (cons '.lookup-index
                                  (let ((__tmp34452
                                         (lambda (_%@4155%_)
                                           (lambda (_%index4160%_ _%key4161%_)
                                             (let ((_%$e4163%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (hash-get
                                                       _%index4160%_
                                                       _%key4161%_))))
                                               (if _%$e4163%_
                                                   _%$e4163%_
                                                   '()))))))
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#$self-slot-spec::t
                                     __tmp34452)))))
                     (__tmp34448 (list)))
                 (declare (not safe))
                 (clan/poo/object#object:::init!__%
                  '#f
                  gerbil-ascent/table/provider#IndexProvider.
                  __tmp34449
                  __tmp34448
                  __obj34426))
               __obj34426)))
        (declare (not safe))
        (clan/poo/mop#validate
         gerbil-ascent/table/provider#GerbilAscentIndexProviderContract
         __tmp34447)))
    (define gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider
      gerbil-ascent/table/provider#+curried-index-provider+)
    (define gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider?
      (lambda (_%value4129%_)
        (eq? _%value4129%_
             gerbil-ascent/table/provider#+curried-index-provider+)))
    (define gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
      (lambda (_%value4124%_)
        (let ((_%$e4126%_
               (eq? _%value4124%_
                    gerbil-ascent/table/provider#+canonical-hash-index-provider+)))
          (if _%$e4126%_
              _%$e4126%_
              (eq? _%value4124%_
                   gerbil-ascent/table/provider#+curried-index-provider+)))))))
