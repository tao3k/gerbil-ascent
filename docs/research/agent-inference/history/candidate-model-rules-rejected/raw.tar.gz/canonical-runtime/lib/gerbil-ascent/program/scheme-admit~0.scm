(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/scheme-admit::timestamp 1791687891)
  (begin
    (define gerbil-ascent/program/scheme-admit#relational-admission::t
      (let ((__tmp37787 (list)) (__tmp37786 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/scheme-admit#relational-admission::t
         'relational-admission
         __tmp37787
         '(run)
         __tmp37786
         '#f)))
    (define gerbil-ascent/program/scheme-admit#relational-admission?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/scheme-admit#relational-admission::t)))
    (define gerbil-ascent/program/scheme-admit#make-relational-admission
      (lambda _%$args20454%_
        (apply make-instance
               gerbil-ascent/program/scheme-admit#relational-admission::t
               _%$args20454%_)))
    (define gerbil-ascent/program/scheme-admit#relational-admission-run
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-admit#relational-admission::t
         'run)))
    (define gerbil-ascent/program/scheme-admit#relational-admission-run-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-admit#relational-admission::t
         'run)))
    (define gerbil-ascent/program/scheme-admit#&relational-admission-run
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-admit#relational-admission::t
         'run)))
    (define gerbil-ascent/program/scheme-admit#&relational-admission-run-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-admit#relational-admission::t
         'run)))
    (define gerbil-ascent/program/scheme-admit#relational-diagnostic::t
      (let ((__tmp37789 (list)) (__tmp37788 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'relational-diagnostic
         __tmp37789
         '(code path detail)
         __tmp37788
         '#f)))
    (define gerbil-ascent/program/scheme-admit#relational-diagnostic?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t)))
    (define gerbil-ascent/program/scheme-admit#make-relational-diagnostic
      (lambda _%$args20451%_
        (apply make-instance
               gerbil-ascent/program/scheme-admit#relational-diagnostic::t
               _%$args20451%_)))
    (define gerbil-ascent/program/scheme-admit#relational-diagnostic-code
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'code)))
    (define gerbil-ascent/program/scheme-admit#relational-diagnostic-path
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'path)))
    (define gerbil-ascent/program/scheme-admit#relational-diagnostic-detail
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'detail)))
    (define gerbil-ascent/program/scheme-admit#relational-diagnostic-code-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'code)))
    (define gerbil-ascent/program/scheme-admit#relational-diagnostic-path-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'path)))
    (define gerbil-ascent/program/scheme-admit#relational-diagnostic-detail-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'detail)))
    (define gerbil-ascent/program/scheme-admit#&relational-diagnostic-code
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'code)))
    (define gerbil-ascent/program/scheme-admit#&relational-diagnostic-path
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'path)))
    (define gerbil-ascent/program/scheme-admit#&relational-diagnostic-detail
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'detail)))
    (define gerbil-ascent/program/scheme-admit#&relational-diagnostic-code-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'code)))
    (define gerbil-ascent/program/scheme-admit#&relational-diagnostic-path-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'path)))
    (define gerbil-ascent/program/scheme-admit#&relational-diagnostic-detail-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-admit#relational-diagnostic::t
         'detail)))
    (define gerbil-ascent/program/scheme-admit#relational-admission-report::t
      (let ((__tmp37791 (list)) (__tmp37790 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/scheme-admit#relational-admission-report::t
         'relational-admission-report
         __tmp37791
         '(admission diagnostic)
         __tmp37790
         '#f)))
    (define gerbil-ascent/program/scheme-admit#relational-admission-report?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/scheme-admit#relational-admission-report::t)))
    (define gerbil-ascent/program/scheme-admit#make-relational-admission-report
      (lambda _%$args20448%_
        (apply make-instance
               gerbil-ascent/program/scheme-admit#relational-admission-report::t
               _%$args20448%_)))
    (define gerbil-ascent/program/scheme-admit#relational-admission-report-admission
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-admit#relational-admission-report::t
         'admission)))
    (define gerbil-ascent/program/scheme-admit#relational-admission-report-diagnostic
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-admit#relational-admission-report::t
         'diagnostic)))
    (define gerbil-ascent/program/scheme-admit#relational-admission-report-admission-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-admit#relational-admission-report::t
         'admission)))
    (define gerbil-ascent/program/scheme-admit#relational-admission-report-diagnostic-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-admit#relational-admission-report::t
         'diagnostic)))
    (define gerbil-ascent/program/scheme-admit#&relational-admission-report-admission
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-admit#relational-admission-report::t
         'admission)))
    (define gerbil-ascent/program/scheme-admit#&relational-admission-report-diagnostic
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-admit#relational-admission-report::t
         'diagnostic)))
    (define gerbil-ascent/program/scheme-admit#&relational-admission-report-admission-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-admit#relational-admission-report::t
         'admission)))
    (define gerbil-ascent/program/scheme-admit#&relational-admission-report-diagnostic-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-admit#relational-admission-report::t
         'diagnostic)))
    (define gerbil-ascent/program/scheme-admit#relational-compose
      (lambda (_%fragments20435%_
               _%input-limit20436%_
               _%derived-limit20437%_
               _%output-limit20438%_)
        (for-each
         (lambda (_%fragment20440%_)
           (let ()
             (declare (not safe))
             (clan/poo/mop#validate
              gerbil-ascent/program/types#GerbilAscentFragmentContract
              _%fragment20440%_)))
         _%fragments20435%_)
        (let ((__tmp37796
               (let ((__tmp37797
                      (lambda (_%fragment20442%_)
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref
                           _%fragment20442%_
                           'relations)))))
                 (declare (not safe))
                 (std/list/list#append-map __tmp37797 _%fragments20435%_)))
              (__tmp37794
               (let ((__tmp37795
                      (lambda (_%fragment20444%_)
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref _%fragment20444%_ 'rules)))))
                 (declare (not safe))
                 (std/list/list#append-map __tmp37795 _%fragments20435%_)))
              (__tmp37792
               (let ((__tmp37793
                      (lambda (_%fragment20446%_)
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref
                           _%fragment20446%_
                           'source-handles)))))
                 (declare (not safe))
                 (std/list/list#append-map __tmp37793 _%fragments20435%_))))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-program__%
           __tmp37796
           __tmp37794
           _%input-limit20436%_
           _%derived-limit20437%_
           _%output-limit20438%_
           __tmp37792))))
    (define gerbil-ascent/program/scheme-admit#relational-admit__%
      (lambda (_%program20407%_ _%on-plan-error20408%_)
        (let ((_%snapshot20410%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/program/scheme-snapshot#relational-snapshot-program
                  _%program20407%_))))
          (let ((_%run20412%_
                 (let ()
                   (declare (not safe))
                   (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__4
                    _%snapshot20410%_
                    '#f
                    '#f
                    '#f
                    '#f
                    _%on-plan-error20408%_)))
                (_%status20413%_ 'ready)
                (_%complete-result20414%_ '#f))
            (let ((__tmp37798
                   (lambda ()
                     (let ((_%$e20417%_ _%status20413%_))
                       (if (eq? 'complete _%$e20417%_)
                           _%complete-result20414%_
                           (if (eq? 'failed _%$e20417%_)
                               (let ()
                                 (declare (not safe))
                                 (error '"relational solve previously failed"))
                               (if (eq? 'running _%$e20417%_)
                                   (let ()
                                     (declare (not safe))
                                     (error '"reentrant relational solve"))
                                   (begin
                                     (set! _%status20413%_ 'running)
                                     (let ((__tmp37800
                                            (lambda (_%failure20420%_)
                                              (set! _%status20413%_ 'failed)
                                              (let ()
                                                (declare (not safe))
                                                (raise _%failure20420%_))))
                                           (__tmp37799
                                            (lambda ()
                                              (let ((_%result20423%_
                                                     (_%run20412%_)))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (clan/poo/object#.ref
                                                       _%result20423%_
                                                       'finished))
                                                    '#!void
                                                    (let ()
                                                      (declare (not safe))
                                                      (error '"relational solve did not complete")))
                                                (set! _%complete-result20414%_
                                                      _%result20423%_)
                                                (set! _%status20413%_
                                                      'complete)
                                                _%result20423%_))))
                                       (declare (not safe))
                                       (__with-catch
                                        __tmp37800
                                        __tmp37799))))))))))
              (declare (not safe))
              (##structure
               gerbil-ascent/program/scheme-admit#relational-admission::t
               __tmp37798))))))
    (define gerbil-ascent/program/scheme-admit#relational-admit__0
      (lambda (_%program20428%_)
        (let ((_%on-plan-error20430%_ '#f))
          (gerbil-ascent/program/scheme-admit#relational-admit__%
           _%program20428%_
           _%on-plan-error20430%_))))
    (define gerbil-ascent/program/scheme-admit#relational-admit
      (lambda _g37801_
        (let ((_g37802_ (let () (declare (not safe)) (##length _g37801_))))
          (cond ((let () (declare (not safe)) (##fx= _g37802_ 1))
                 (apply gerbil-ascent/program/scheme-admit#relational-admit__0
                        _g37801_))
                ((let () (declare (not safe)) (##fx= _g37802_ 2))
                 (apply gerbil-ascent/program/scheme-admit#relational-admit__%
                        _g37801_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/scheme-admit#relational-admit
                  _g37801_))))))
    (define gerbil-ascent/program/scheme-admit#relational-admit/report
      (lambda (_%program20393%_)
        (let ((_%path20395%_ '(program)))
          (let ((__tmp37805
                 (lambda (_%failure20397%_)
                   (let ((__tmp37806
                          (let ((__tmp37808
                                 (if (and (pair? _%path20395%_)
                                          (eq? (car _%path20395%_) 'rule))
                                     (if (eq? (caddr _%path20395%_) 'body)
                                         'invalid-body
                                         'invalid-head)
                                     (if (equal? _%path20395%_
                                                 '(program dependencies))
                                         'invalid-dependencies
                                         'invalid-program)))
                                (__tmp37807
                                 (let ()
                                   (declare (not safe))
                                   (std/error#exception->string
                                    _%failure20397%_))))
                            (declare (not safe))
                            (##structure
                             gerbil-ascent/program/scheme-admit#relational-diagnostic::t
                             __tmp37808
                             _%path20395%_
                             __tmp37807))))
                     (declare (not safe))
                     (##structure
                      gerbil-ascent/program/scheme-admit#relational-admission-report::t
                      '#f
                      __tmp37806))))
                (__tmp37803
                 (lambda ()
                   (let ((__tmp37804
                          (gerbil-ascent/program/scheme-admit#relational-admit__%
                           _%program20393%_
                           (lambda (_%location20403%_ _%_failure20404%_)
                             (set! _%path20395%_ _%location20403%_)))))
                     (declare (not safe))
                     (##structure
                      gerbil-ascent/program/scheme-admit#relational-admission-report::t
                      __tmp37804
                      '#f)))))
            (declare (not safe))
            (__with-catch __tmp37805 __tmp37803)))))
    (define gerbil-ascent/program/scheme-admit#relational-solve
      (lambda (_%admission20391%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%admission20391%_
               'gerbil-ascent/program/scheme-admit#relational-admission::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational solve requires admission"
                     _%admission20391%_)))
        (let ((__tmp37809
               ((##structure-ref
                 _%admission20391%_
                 '1
                 gerbil-ascent/program/scheme-admit#relational-admission::t
                 '#f))))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/scheme-query#relational-solution::t
           __tmp37809))))))
