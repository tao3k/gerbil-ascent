(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/view-state[1]#_g36135_|
    (##structure
     gx#syntax-quote::t
     'staged-frontier-count::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36137_|
    (##structure
     gx#syntax-quote::t
     'make-staged-frontier-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36139_|
    (##structure
     gx#syntax-quote::t
     'staged-frontier-count?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36141_|
    (##structure
     gx#syntax-quote::t
     'staged-frontier-count-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36143_|
    (##structure
     gx#syntax-quote::t
     'staged-frontier-count-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36145_|
    (##structure
     gx#syntax-quote::t
     '&staged-frontier-count-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36147_|
    (##structure
     gx#syntax-quote::t
     '&staged-frontier-count-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36149_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36151_|
    (##structure
     gx#syntax-quote::t
     'make-view-routing-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36153_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36155_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-storage
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36156_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-all
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36157_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-delta
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36158_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-versions
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36159_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-names
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36160_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36161_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-journals
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36162_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-routing
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36164_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-storage-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36165_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-all-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36166_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-delta-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36167_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-versions-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36168_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-names-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36169_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36170_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-journals-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36171_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-routing-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36173_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-storage
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36174_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-all
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36175_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-delta
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36176_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-versions
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36177_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-names
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36178_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36179_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-journals
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36180_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-routing
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36182_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-storage-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36183_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-all-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36184_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-delta-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36185_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-versions-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36186_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-names-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36187_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36188_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-journals-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36189_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-routing-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36191_|
    (##structure
     gx#syntax-quote::t
     'view-event::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36193_|
    (##structure
     gx#syntax-quote::t
     'make-view-event
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36195_|
    (##structure
     gx#syntax-quote::t
     'view-event?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36197_|
    (##structure
     gx#syntax-quote::t
     'view-event-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36198_|
    (##structure
     gx#syntax-quote::t
     'view-event-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36199_|
    (##structure
     gx#syntax-quote::t
     'view-event-eqrel?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36201_|
    (##structure
     gx#syntax-quote::t
     'view-event-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36202_|
    (##structure
     gx#syntax-quote::t
     'view-event-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36203_|
    (##structure
     gx#syntax-quote::t
     'view-event-eqrel?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36205_|
    (##structure
     gx#syntax-quote::t
     '&view-event-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36206_|
    (##structure
     gx#syntax-quote::t
     '&view-event-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36207_|
    (##structure
     gx#syntax-quote::t
     '&view-event-eqrel?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36209_|
    (##structure
     gx#syntax-quote::t
     '&view-event-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36210_|
    (##structure
     gx#syntax-quote::t
     '&view-event-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36211_|
    (##structure
     gx#syntax-quote::t
     '&view-event-eqrel?-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/view-state[:0:]#staged-frontier-count|
      (let ((__obj35886
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35886
           'gerbil-ascent/program/view-state#staged-frontier-count::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35886
           'staged-frontier-count
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35886 '(count) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35886 '(count) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35886 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35886 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35886 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35886 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35886 '#f '13 '#f '#f))
        (let ((__tmp36134 |gerbil-ascent/program/view-state[1]#_g36135_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35886 __tmp36134 '4 '#f '#f))
        (let ((__tmp36136 |gerbil-ascent/program/view-state[1]#_g36137_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35886 __tmp36136 '14 '#f '#f))
        (let ((__tmp36138 |gerbil-ascent/program/view-state[1]#_g36139_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35886 __tmp36138 '15 '#f '#f))
        (let ((__tmp36140
               (cons (cons 'count
                           |gerbil-ascent/program/view-state[1]#_g36141_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj35886 __tmp36140 '16 '#f '#f))
        (let ((__tmp36142
               (cons (cons 'count
                           |gerbil-ascent/program/view-state[1]#_g36143_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj35886 __tmp36142 '17 '#f '#f))
        (let ((__tmp36144
               (cons (cons 'count
                           |gerbil-ascent/program/view-state[1]#_g36145_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj35886 __tmp36144 '18 '#f '#f))
        (let ((__tmp36146
               (cons (cons 'count
                           |gerbil-ascent/program/view-state[1]#_g36147_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj35886 __tmp36146 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35886 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35886 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35886 '() '21 '#f '#f))
        __obj35886))
    (define |gerbil-ascent/program/view-state[:0:]#view-routing-state|
      (let ((__obj35887
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35887
           'gerbil-ascent/program/view-state#view-routing-state::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35887
           'view-routing-state
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35887
           '(storage all delta versions names generation journals routing)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35887
           '(storage all delta versions names generation journals routing)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35887 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35887 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35887 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35887 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35887 '#f '13 '#f '#f))
        (let ((__tmp36148 |gerbil-ascent/program/view-state[1]#_g36149_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35887 __tmp36148 '4 '#f '#f))
        (let ((__tmp36150 |gerbil-ascent/program/view-state[1]#_g36151_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35887 __tmp36150 '14 '#f '#f))
        (let ((__tmp36152 |gerbil-ascent/program/view-state[1]#_g36153_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35887 __tmp36152 '15 '#f '#f))
        (let ((__tmp36154
               (cons (cons 'storage
                           |gerbil-ascent/program/view-state[1]#_g36155_|)
                     (cons (cons 'all
                                 |gerbil-ascent/program/view-state[1]#_g36156_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/view-state[1]#_g36157_|)
                                 (cons (cons 'versions
                                             |gerbil-ascent/program/view-state[1]#_g36158_|)
                                       (cons (cons 'names
                                                   |gerbil-ascent/program/view-state[1]#_g36159_|)
                                             (cons (cons 'generation
                                                         |gerbil-ascent/program/view-state[1]#_g36160_|)
                                                   (cons (cons 'journals
                                                               |gerbil-ascent/program/view-state[1]#_g36161_|)
                                                         (cons (cons 'routing
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/view-state[1]#_g36162_|)
                       '()))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj35887 __tmp36154 '16 '#f '#f))
        (let ((__tmp36163
               (cons (cons 'storage
                           |gerbil-ascent/program/view-state[1]#_g36164_|)
                     (cons (cons 'all
                                 |gerbil-ascent/program/view-state[1]#_g36165_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/view-state[1]#_g36166_|)
                                 (cons (cons 'versions
                                             |gerbil-ascent/program/view-state[1]#_g36167_|)
                                       (cons (cons 'names
                                                   |gerbil-ascent/program/view-state[1]#_g36168_|)
                                             (cons (cons 'generation
                                                         |gerbil-ascent/program/view-state[1]#_g36169_|)
                                                   (cons (cons 'journals
                                                               |gerbil-ascent/program/view-state[1]#_g36170_|)
                                                         (cons (cons 'routing
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/view-state[1]#_g36171_|)
                       '()))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj35887 __tmp36163 '17 '#f '#f))
        (let ((__tmp36172
               (cons (cons 'storage
                           |gerbil-ascent/program/view-state[1]#_g36173_|)
                     (cons (cons 'all
                                 |gerbil-ascent/program/view-state[1]#_g36174_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/view-state[1]#_g36175_|)
                                 (cons (cons 'versions
                                             |gerbil-ascent/program/view-state[1]#_g36176_|)
                                       (cons (cons 'names
                                                   |gerbil-ascent/program/view-state[1]#_g36177_|)
                                             (cons (cons 'generation
                                                         |gerbil-ascent/program/view-state[1]#_g36178_|)
                                                   (cons (cons 'journals
                                                               |gerbil-ascent/program/view-state[1]#_g36179_|)
                                                         (cons (cons 'routing
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/view-state[1]#_g36180_|)
                       '()))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj35887 __tmp36172 '18 '#f '#f))
        (let ((__tmp36181
               (cons (cons 'storage
                           |gerbil-ascent/program/view-state[1]#_g36182_|)
                     (cons (cons 'all
                                 |gerbil-ascent/program/view-state[1]#_g36183_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/view-state[1]#_g36184_|)
                                 (cons (cons 'versions
                                             |gerbil-ascent/program/view-state[1]#_g36185_|)
                                       (cons (cons 'names
                                                   |gerbil-ascent/program/view-state[1]#_g36186_|)
                                             (cons (cons 'generation
                                                         |gerbil-ascent/program/view-state[1]#_g36187_|)
                                                   (cons (cons 'journals
                                                               |gerbil-ascent/program/view-state[1]#_g36188_|)
                                                         (cons (cons 'routing
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/view-state[1]#_g36189_|)
                       '()))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj35887 __tmp36181 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35887 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35887 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35887 '() '21 '#f '#f))
        __obj35887))
    (define |gerbil-ascent/program/view-state[:0:]#view-event|
      (let ((__obj35888
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35888
           'gerbil-ascent/program/view-state#view-event::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35888 'view-event '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35888
           '(kind rows eqrel?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35888
           '(kind rows eqrel?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35888 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35888 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35888 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35888 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35888 '#f '13 '#f '#f))
        (let ((__tmp36190 |gerbil-ascent/program/view-state[1]#_g36191_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35888 __tmp36190 '4 '#f '#f))
        (let ((__tmp36192 |gerbil-ascent/program/view-state[1]#_g36193_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35888 __tmp36192 '14 '#f '#f))
        (let ((__tmp36194 |gerbil-ascent/program/view-state[1]#_g36195_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35888 __tmp36194 '15 '#f '#f))
        (let ((__tmp36196
               (cons (cons 'kind
                           |gerbil-ascent/program/view-state[1]#_g36197_|)
                     (cons (cons 'rows
                                 |gerbil-ascent/program/view-state[1]#_g36198_|)
                           (cons (cons 'eqrel?
                                       |gerbil-ascent/program/view-state[1]#_g36199_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35888 __tmp36196 '16 '#f '#f))
        (let ((__tmp36200
               (cons (cons 'kind
                           |gerbil-ascent/program/view-state[1]#_g36201_|)
                     (cons (cons 'rows
                                 |gerbil-ascent/program/view-state[1]#_g36202_|)
                           (cons (cons 'eqrel?
                                       |gerbil-ascent/program/view-state[1]#_g36203_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35888 __tmp36200 '17 '#f '#f))
        (let ((__tmp36204
               (cons (cons 'kind
                           |gerbil-ascent/program/view-state[1]#_g36205_|)
                     (cons (cons 'rows
                                 |gerbil-ascent/program/view-state[1]#_g36206_|)
                           (cons (cons 'eqrel?
                                       |gerbil-ascent/program/view-state[1]#_g36207_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35888 __tmp36204 '18 '#f '#f))
        (let ((__tmp36208
               (cons (cons 'kind
                           |gerbil-ascent/program/view-state[1]#_g36209_|)
                     (cons (cons 'rows
                                 |gerbil-ascent/program/view-state[1]#_g36210_|)
                           (cons (cons 'eqrel?
                                       |gerbil-ascent/program/view-state[1]#_g36211_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35888 __tmp36208 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35888 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35888 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35888 '() '21 '#f '#f))
        __obj35888))))
