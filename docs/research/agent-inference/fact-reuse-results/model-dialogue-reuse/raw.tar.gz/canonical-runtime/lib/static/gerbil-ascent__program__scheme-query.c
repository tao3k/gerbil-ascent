#ifdef ___LINKER_INFO
; File: "gerbil-ascent__program__scheme-query.c", produced by Gambit v4.9.8
(
409008
(C)
"gerbil-ascent__program__scheme-query"
("gerbil-ascent__program__scheme-query")
()
(("gerbil-ascent__program__scheme-query"))
( #|*/"*/"symbols|#
"exports"
"finished"
"gerbil-ascent/program/scheme-query#checked-solution-result"
"gerbil-ascent/program/scheme-query#copy-query-rows"
"gerbil-ascent/program/scheme-query#make-relational-program-solution"
"gerbil-ascent/program/scheme-query#make-relational-solution"
"gerbil-ascent/program/scheme-query#relational-export"
"gerbil-ascent/program/scheme-query#relational-prepare-queries"
"gerbil-ascent/program/scheme-query#relational-prepare-query"
"gerbil-ascent/program/scheme-query#relational-program-query"
"gerbil-ascent/program/scheme-query#relational-program-solution::t"
"gerbil-ascent/program/scheme-query#relational-query"
"gerbil-ascent/program/scheme-query#relational-query-name"
"gerbil-ascent/program/scheme-query#relational-result-rows"
"gerbil-ascent/program/scheme-query#relational-solution::t"
"gerbil-ascent__program__scheme-query"
"gerbil-ascent__program__scheme-query#"
"relational-program-solution"
"relational-solution"
"result"
"rows-of"
) #|*/"*/"symbols|#
( #|*/"*/"keywords|#
"struct"
) #|*/"*/"keywords|#
( #|*/"*/"globals-s-d|#
"gerbil-ascent/program/scheme-query#checked-solution-result"
"gerbil-ascent/program/scheme-query#copy-query-rows"
"gerbil-ascent/program/scheme-query#relational-export"
"gerbil-ascent/program/scheme-query#relational-program-solution::t"
"gerbil-ascent/program/scheme-query#relational-result-rows"
"gerbil-ascent/program/scheme-query#relational-solution::t"
"gerbil-ascent__program__scheme-query#"
) #|*/"*/"globals-s-d|#
( #|*/"*/"globals-s-nd|#
"gerbil-ascent/program/scheme-query#&relational-program-solution-result"
"gerbil-ascent/program/scheme-query#&relational-program-solution-result-set!"
"gerbil-ascent/program/scheme-query#&relational-solution-result"
"gerbil-ascent/program/scheme-query#&relational-solution-result-set!"
"gerbil-ascent/program/scheme-query#make-relational-program-solution"
"gerbil-ascent/program/scheme-query#make-relational-solution"
"gerbil-ascent/program/scheme-query#relational-prepare-queries"
"gerbil-ascent/program/scheme-query#relational-prepare-query"
"gerbil-ascent/program/scheme-query#relational-program-query"
"gerbil-ascent/program/scheme-query#relational-program-solution-result"
"gerbil-ascent/program/scheme-query#relational-program-solution-result-set!"
"gerbil-ascent/program/scheme-query#relational-program-solution?"
"gerbil-ascent/program/scheme-query#relational-query"
"gerbil-ascent/program/scheme-query#relational-query-name"
"gerbil-ascent/program/scheme-query#relational-solution-result"
"gerbil-ascent/program/scheme-query#relational-solution-result-set!"
"gerbil-ascent/program/scheme-query#relational-solution?"
"gerbil-ascent/program/scheme-query::timestamp"
) #|*/"*/"globals-s-nd|#
( #|*/"*/"globals-ns|#
"##dead-end"
"##list?"
"##structure-instance-of?"
"##structure-ref"
"__make-class-predicate"
"__make-class-slot-accessor"
"__make-class-slot-mutator"
"__make-class-slot-unchecked-accessor"
"__make-class-slot-unchecked-mutator"
"andmap__0"
"apply"
"clan/poo/mop#validate"
"clan/poo/object#.ref"
"error"
"gerbil-ascent/program/types#GerbilAscentFragmentContract"
"make-class-type"
"make-instance"
"map"
"symbol?"
) #|*/"*/"globals-ns|#
( #|*/"*/"meta-info|#
) #|*/"*/"meta-info|#
)
#else
#define ___VERSION 409008
#define ___MODULE_NAME "gerbil-ascent__program__scheme-query"
#define ___LINKER_ID ___LNK_gerbil_2d_ascent____program____scheme_2d_query
#define ___MH_PROC ___H_gerbil_2d_ascent____program____scheme_2d_query
#define ___SCRIPT_LINE 0
#define ___SYMCOUNT 21
#define ___KEYCOUNT 1
#define ___GLOCOUNT 44
#define ___SUPCOUNT 25
#define ___CNSCOUNT 2
#define ___SUBCOUNT 11
#define ___LBLCOUNT 125
#define ___MODDESCR ___REF_SUB(8)
#include "gambit.h"

___NEED_SYM(___S_exports)
___NEED_SYM(___S_finished)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___NEED_SYM(___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t)
___NEED_SYM(___S_gerbil_2d_ascent____program____scheme_2d_query)
___NEED_SYM(___S_gerbil_2d_ascent____program____scheme_2d_query_23_)
___NEED_SYM(___S_relational_2d_program_2d_solution)
___NEED_SYM(___S_relational_2d_solution)
___NEED_SYM(___S_result)
___NEED_SYM(___S_rows_2d_of)

___NEED_KEY(___K_struct)

___NEED_GLO(___G__23__23_dead_2d_end)
___NEED_GLO(___G__23__23_list_3f_)
___NEED_GLO(___G__23__23_structure_2d_instance_2d_of_3f_)
___NEED_GLO(___G__23__23_structure_2d_ref)
___NEED_GLO(___G_____make_2d_class_2d_predicate)
___NEED_GLO(___G_____make_2d_class_2d_slot_2d_accessor)
___NEED_GLO(___G_____make_2d_class_2d_slot_2d_mutator)
___NEED_GLO(___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
___NEED_GLO(___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
___NEED_GLO(___G_andmap____0)
___NEED_GLO(___G_apply)
___NEED_GLO(___G_clan_2f_poo_2f_mop_23_validate)
___NEED_GLO(___G_clan_2f_poo_2f_object_23__2e_ref)
___NEED_GLO(___G_error)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_program_2d_solution_2d_result)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_program_2d_solution_2d_result_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_solution_2d_result)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_solution_2d_result_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_2d_result)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_2d_result_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3f_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_2d_result)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_2d_result_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3f_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_3a__3a_timestamp)
___NEED_GLO(___G_gerbil_2d_ascent_2f_program_2f_types_23_GerbilAscentFragmentContract)
___NEED_GLO(___G_gerbil_2d_ascent____program____scheme_2d_query_23_)
___NEED_GLO(___G_make_2d_class_2d_type)
___NEED_GLO(___G_make_2d_instance)
___NEED_GLO(___G_map)
___NEED_GLO(___G_symbol_3f_)

___BEGIN_SYM
___DEF_SYM(0,___S_exports,"exports")
___DEF_SYM(1,___S_finished,"finished")
___DEF_SYM(2,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result,"gerbil-ascent/program/scheme-query#checked-solution-result")

___DEF_SYM(3,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows,"gerbil-ascent/program/scheme-query#copy-query-rows")

___DEF_SYM(4,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution,"gerbil-ascent/program/scheme-query#make-relational-program-solution")

___DEF_SYM(5,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution,"gerbil-ascent/program/scheme-query#make-relational-solution")

___DEF_SYM(6,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export,"gerbil-ascent/program/scheme-query#relational-export")

___DEF_SYM(7,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,"gerbil-ascent/program/scheme-query#relational-prepare-queries")

___DEF_SYM(8,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query,"gerbil-ascent/program/scheme-query#relational-prepare-query")

___DEF_SYM(9,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query,"gerbil-ascent/program/scheme-query#relational-program-query")

___DEF_SYM(10,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t,"gerbil-ascent/program/scheme-query#relational-program-solution::t")

___DEF_SYM(11,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query,"gerbil-ascent/program/scheme-query#relational-query")

___DEF_SYM(12,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name,"gerbil-ascent/program/scheme-query#relational-query-name")

___DEF_SYM(13,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows,"gerbil-ascent/program/scheme-query#relational-result-rows")

___DEF_SYM(14,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t,"gerbil-ascent/program/scheme-query#relational-solution::t")

___DEF_SYM(15,___S_gerbil_2d_ascent____program____scheme_2d_query,"gerbil-ascent__program__scheme-query")

___DEF_SYM(16,___S_gerbil_2d_ascent____program____scheme_2d_query_23_,"gerbil-ascent__program__scheme-query#")

___DEF_SYM(17,___S_relational_2d_program_2d_solution,"relational-program-solution")
___DEF_SYM(18,___S_relational_2d_solution,"relational-solution")
___DEF_SYM(19,___S_result,"result")
___DEF_SYM(20,___S_rows_2d_of,"rows-of")
___END_SYM

#define ___SYM_exports ___SYM(0,___S_exports)
#define ___SYM_finished ___SYM(1,___S_finished)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result ___SYM(2,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows ___SYM(3,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution ___SYM(4,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution ___SYM(5,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export ___SYM(6,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries ___SYM(7,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query ___SYM(8,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query ___SYM(9,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t ___SYM(10,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query ___SYM(11,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name ___SYM(12,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows ___SYM(13,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
#define ___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t ___SYM(14,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t)
#define ___SYM_gerbil_2d_ascent____program____scheme_2d_query ___SYM(15,___S_gerbil_2d_ascent____program____scheme_2d_query)
#define ___SYM_gerbil_2d_ascent____program____scheme_2d_query_23_ ___SYM(16,___S_gerbil_2d_ascent____program____scheme_2d_query_23_)
#define ___SYM_relational_2d_program_2d_solution ___SYM(17,___S_relational_2d_program_2d_solution)
#define ___SYM_relational_2d_solution ___SYM(18,___S_relational_2d_solution)
#define ___SYM_result ___SYM(19,___S_result)
#define ___SYM_rows_2d_of ___SYM(20,___S_rows_2d_of)

___BEGIN_KEY
___DEF_KEY(0,___K_struct,"struct")
___END_KEY

#define ___KEY_struct ___KEY(0,___K_struct)

___BEGIN_GLO
___DEF_GLO(0,"gerbil-ascent/program/scheme-query#&relational-program-solution-result")

___DEF_GLO(1,"gerbil-ascent/program/scheme-query#&relational-program-solution-result-set!")

___DEF_GLO(2,"gerbil-ascent/program/scheme-query#&relational-solution-result")

___DEF_GLO(3,"gerbil-ascent/program/scheme-query#&relational-solution-result-set!")

___DEF_GLO(4,"gerbil-ascent/program/scheme-query#checked-solution-result")

___DEF_GLO(5,"gerbil-ascent/program/scheme-query#copy-query-rows")

___DEF_GLO(6,"gerbil-ascent/program/scheme-query#make-relational-program-solution")

___DEF_GLO(7,"gerbil-ascent/program/scheme-query#make-relational-solution")

___DEF_GLO(8,"gerbil-ascent/program/scheme-query#relational-export")

___DEF_GLO(9,"gerbil-ascent/program/scheme-query#relational-prepare-queries")

___DEF_GLO(10,"gerbil-ascent/program/scheme-query#relational-prepare-query")

___DEF_GLO(11,"gerbil-ascent/program/scheme-query#relational-program-query")

___DEF_GLO(12,"gerbil-ascent/program/scheme-query#relational-program-solution-result")

___DEF_GLO(13,"gerbil-ascent/program/scheme-query#relational-program-solution-result-set!")

___DEF_GLO(14,"gerbil-ascent/program/scheme-query#relational-program-solution::t")

___DEF_GLO(15,"gerbil-ascent/program/scheme-query#relational-program-solution?")

___DEF_GLO(16,"gerbil-ascent/program/scheme-query#relational-query")

___DEF_GLO(17,"gerbil-ascent/program/scheme-query#relational-query-name")

___DEF_GLO(18,"gerbil-ascent/program/scheme-query#relational-result-rows")

___DEF_GLO(19,"gerbil-ascent/program/scheme-query#relational-solution-result")

___DEF_GLO(20,"gerbil-ascent/program/scheme-query#relational-solution-result-set!")

___DEF_GLO(21,"gerbil-ascent/program/scheme-query#relational-solution::t")

___DEF_GLO(22,"gerbil-ascent/program/scheme-query#relational-solution?")

___DEF_GLO(23,"gerbil-ascent/program/scheme-query::timestamp")

___DEF_GLO(24,"gerbil-ascent__program__scheme-query#")

___DEF_GLO(25,"##dead-end")
___DEF_GLO(26,"##list?")
___DEF_GLO(27,"##structure-instance-of?")
___DEF_GLO(28,"##structure-ref")
___DEF_GLO(29,"__make-class-predicate")
___DEF_GLO(30,"__make-class-slot-accessor")
___DEF_GLO(31,"__make-class-slot-mutator")
___DEF_GLO(32,"__make-class-slot-unchecked-accessor")

___DEF_GLO(33,"__make-class-slot-unchecked-mutator")

___DEF_GLO(34,"andmap__0")
___DEF_GLO(35,"apply")
___DEF_GLO(36,"clan/poo/mop#validate")
___DEF_GLO(37,"clan/poo/object#.ref")
___DEF_GLO(38,"error")
___DEF_GLO(39,"gerbil-ascent/program/types#GerbilAscentFragmentContract")

___DEF_GLO(40,"make-class-type")
___DEF_GLO(41,"make-instance")
___DEF_GLO(42,"map")
___DEF_GLO(43,"symbol?")
___END_GLO

#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_program_2d_solution_2d_result ___GLO(0,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_program_2d_solution_2d_result)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_program_2d_solution_2d_result ___PRM(0,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_program_2d_solution_2d_result)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_program_2d_solution_2d_result_2d_set_21_ ___GLO(1,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_program_2d_solution_2d_result_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_program_2d_solution_2d_result_2d_set_21_ ___PRM(1,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_program_2d_solution_2d_result_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_solution_2d_result ___GLO(2,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_solution_2d_result)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_solution_2d_result ___PRM(2,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_solution_2d_result)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_solution_2d_result_2d_set_21_ ___GLO(3,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_solution_2d_result_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_solution_2d_result_2d_set_21_ ___PRM(3,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_solution_2d_result_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result ___GLO(4,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result ___PRM(4,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows ___GLO(5,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows ___PRM(5,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution ___GLO(6,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution ___PRM(6,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution ___GLO(7,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution ___PRM(7,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export ___GLO(8,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export ___PRM(8,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries ___GLO(9,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries ___PRM(9,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query ___GLO(10,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query ___PRM(10,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query ___GLO(11,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query ___PRM(11,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_2d_result ___GLO(12,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_2d_result)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_2d_result ___PRM(12,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_2d_result)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_2d_result_2d_set_21_ ___GLO(13,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_2d_result_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_2d_result_2d_set_21_ ___PRM(13,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_2d_result_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t ___GLO(14,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t ___PRM(14,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3f_ ___GLO(15,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3f_)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3f_ ___PRM(15,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3f_)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query ___GLO(16,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query ___PRM(16,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name ___GLO(17,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name ___PRM(17,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows ___GLO(18,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows ___PRM(18,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_2d_result ___GLO(19,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_2d_result)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_2d_result ___PRM(19,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_2d_result)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_2d_result_2d_set_21_ ___GLO(20,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_2d_result_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_2d_result_2d_set_21_ ___PRM(20,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_2d_result_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t ___GLO(21,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t ___PRM(21,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3f_ ___GLO(22,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3f_)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3f_ ___PRM(22,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3f_)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_3a__3a_timestamp ___GLO(23,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_3a__3a_timestamp)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_3a__3a_timestamp ___PRM(23,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_3a__3a_timestamp)
#define ___GLO_gerbil_2d_ascent____program____scheme_2d_query_23_ ___GLO(24,___G_gerbil_2d_ascent____program____scheme_2d_query_23_)
#define ___PRM_gerbil_2d_ascent____program____scheme_2d_query_23_ ___PRM(24,___G_gerbil_2d_ascent____program____scheme_2d_query_23_)
#define ___GLO__23__23_dead_2d_end ___GLO(25,___G__23__23_dead_2d_end)
#define ___PRM__23__23_dead_2d_end ___PRM(25,___G__23__23_dead_2d_end)
#define ___GLO__23__23_list_3f_ ___GLO(26,___G__23__23_list_3f_)
#define ___PRM__23__23_list_3f_ ___PRM(26,___G__23__23_list_3f_)
#define ___GLO__23__23_structure_2d_instance_2d_of_3f_ ___GLO(27,___G__23__23_structure_2d_instance_2d_of_3f_)
#define ___PRM__23__23_structure_2d_instance_2d_of_3f_ ___PRM(27,___G__23__23_structure_2d_instance_2d_of_3f_)
#define ___GLO__23__23_structure_2d_ref ___GLO(28,___G__23__23_structure_2d_ref)
#define ___PRM__23__23_structure_2d_ref ___PRM(28,___G__23__23_structure_2d_ref)
#define ___GLO_____make_2d_class_2d_predicate ___GLO(29,___G_____make_2d_class_2d_predicate)
#define ___PRM_____make_2d_class_2d_predicate ___PRM(29,___G_____make_2d_class_2d_predicate)
#define ___GLO_____make_2d_class_2d_slot_2d_accessor ___GLO(30,___G_____make_2d_class_2d_slot_2d_accessor)
#define ___PRM_____make_2d_class_2d_slot_2d_accessor ___PRM(30,___G_____make_2d_class_2d_slot_2d_accessor)
#define ___GLO_____make_2d_class_2d_slot_2d_mutator ___GLO(31,___G_____make_2d_class_2d_slot_2d_mutator)
#define ___PRM_____make_2d_class_2d_slot_2d_mutator ___PRM(31,___G_____make_2d_class_2d_slot_2d_mutator)
#define ___GLO_____make_2d_class_2d_slot_2d_unchecked_2d_accessor ___GLO(32,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
#define ___PRM_____make_2d_class_2d_slot_2d_unchecked_2d_accessor ___PRM(32,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
#define ___GLO_____make_2d_class_2d_slot_2d_unchecked_2d_mutator ___GLO(33,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
#define ___PRM_____make_2d_class_2d_slot_2d_unchecked_2d_mutator ___PRM(33,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
#define ___GLO_andmap____0 ___GLO(34,___G_andmap____0)
#define ___PRM_andmap____0 ___PRM(34,___G_andmap____0)
#define ___GLO_apply ___GLO(35,___G_apply)
#define ___PRM_apply ___PRM(35,___G_apply)
#define ___GLO_clan_2f_poo_2f_mop_23_validate ___GLO(36,___G_clan_2f_poo_2f_mop_23_validate)
#define ___PRM_clan_2f_poo_2f_mop_23_validate ___PRM(36,___G_clan_2f_poo_2f_mop_23_validate)
#define ___GLO_clan_2f_poo_2f_object_23__2e_ref ___GLO(37,___G_clan_2f_poo_2f_object_23__2e_ref)
#define ___PRM_clan_2f_poo_2f_object_23__2e_ref ___PRM(37,___G_clan_2f_poo_2f_object_23__2e_ref)
#define ___GLO_error ___GLO(38,___G_error)
#define ___PRM_error ___PRM(38,___G_error)
#define ___GLO_gerbil_2d_ascent_2f_program_2f_types_23_GerbilAscentFragmentContract ___GLO(39,___G_gerbil_2d_ascent_2f_program_2f_types_23_GerbilAscentFragmentContract)
#define ___PRM_gerbil_2d_ascent_2f_program_2f_types_23_GerbilAscentFragmentContract ___PRM(39,___G_gerbil_2d_ascent_2f_program_2f_types_23_GerbilAscentFragmentContract)
#define ___GLO_make_2d_class_2d_type ___GLO(40,___G_make_2d_class_2d_type)
#define ___PRM_make_2d_class_2d_type ___PRM(40,___G_make_2d_class_2d_type)
#define ___GLO_make_2d_instance ___GLO(41,___G_make_2d_instance)
#define ___PRM_make_2d_instance ___PRM(41,___G_make_2d_instance)
#define ___GLO_map ___GLO(42,___G_map)
#define ___PRM_map ___PRM(42,___G_map)
#define ___GLO_symbol_3f_ ___GLO(43,___G_symbol_3f_)
#define ___PRM_symbol_3f_ ___PRM(43,___G_symbol_3f_)

___BEGIN_CNS
 ___DEF_CNS(___REF_SYM(19,___S_result),___REF_NUL)
,___DEF_CNS(___REF_SYM(19,___S_result),___REF_NUL)
___END_CNS

___DEF_SUB_BIGFIX(___X0,1UL)
               ___BIGFIX1(0x6acb0906L)
___DEF_SUB_STR(___X1,44UL)
               ___STR8(114,101,108,97,116,105,111,110)
               ___STR8(97,108,32,113,117,101,114,121)
               ___STR8(32,114,101,113,117,105,114,101)
               ___STR8(115,32,97,32,99,111,109,112)
               ___STR8(108,101,116,101,100,32,114,101)
               ___STR4(115,117,108,116)
___DEF_SUB_STR(___X2,40UL)
               ___STR8(114,101,108,97,116,105,111,110)
               ___STR8(97,108,32,113,117,101,114,121)
               ___STR8(32,114,101,113,117,105,114,101)
               ___STR8(115,32,97,32,115,111,108,118)
               ___STR8(101,100,32,118,97,108,117,101)
               ___STR0
___DEF_SUB_STR(___X3,44UL)
               ___STR8(114,101,108,97,116,105,111,110)
               ___STR8(97,108,32,113,117,101,114,121)
               ___STR8(32,114,101,113,117,105,114,101)
               ___STR8(115,32,97,32,99,111,109,112)
               ___STR8(108,101,116,101,100,32,114,101)
               ___STR4(115,117,108,116)
___DEF_SUB_STR(___X4,46UL)
               ___STR8(114,101,108,97,116,105,111,110)
               ___STR8(97,108,32,113,117,101,114,121)
               ___STR8(32,118,105,101,119,32,114,101)
               ___STR8(113,117,105,114,101,115,32,101)
               ___STR8(120,112,111,114,116,101,100,32)
               ___STR6(108,97,98,101,108,115)
___DEF_SUB_STR(___X5,40UL)
               ___STR8(114,101,108,97,116,105,111,110)
               ___STR8(97,108,32,113,117,101,114,121)
               ___STR8(32,114,101,113,117,105,114,101)
               ___STR8(115,32,97,32,115,111,108,118)
               ___STR8(101,100,32,118,97,108,117,101)
               ___STR0
___DEF_SUB_STR(___X6,46UL)
               ___STR8(114,101,108,97,116,105,111,110)
               ___STR8(97,108,32,110,97,109,101,100)
               ___STR8(32,113,117,101,114,121,32,114)
               ___STR8(101,113,117,105,114,101,115,32)
               ___STR8(97,32,115,111,108,118,101,100)
               ___STR6(32,118,97,108,117,101)
___DEF_SUB_STR(___X7,50UL)
               ___STR8(114,101,108,97,116,105,111,110)
               ___STR8(97,108,32,112,114,111,103,114)
               ___STR8(97,109,32,113,117,101,114,121)
               ___STR8(32,114,101,113,117,105,114,101)
               ___STR8(115,32,97,32,110,97,109,101)
               ___STR8(100,32,115,111,108,117,116,105)
               ___STR2(111,110)
___DEF_SUB_VEC(___X8,6UL)
               ___VEC1(___REF_SUB(9))
               ___VEC1(___REF_SUB(10))
               ___VEC1(___REF_NUL)
               ___VEC1(___REF_FIX(1))
               ___VEC1(___REF_PRC(1))
               ___VEC1(___REF_FAL)
               ___VEC0
___DEF_SUB_VEC(___X9,1UL)
               ___VEC1(___REF_SYM(15,___S_gerbil_2d_ascent____program____scheme_2d_query))
               ___VEC0
___DEF_SUB_VEC(___X10,0UL)
               ___VEC0

___BEGIN_SUB
 ___DEF_SUB(___X0)
,___DEF_SUB(___X1)
,___DEF_SUB(___X2)
,___DEF_SUB(___X3)
,___DEF_SUB(___X4)
,___DEF_SUB(___X5)
,___DEF_SUB(___X6)
,___DEF_SUB(___X7)
,___DEF_SUB(___X8)
,___DEF_SUB(___X9)
,___DEF_SUB(___X10)
___END_SUB



#undef ___MD_ALL
#define ___MD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___MR_ALL
#define ___MR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___MW_ALL
#define ___MW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_M_COD
___BEGIN_M_HLBL
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_M_HLBL(___L1_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_M_HLBL(___L2_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_M_HLBL(___L3_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_M_HLBL(___L4_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_M_HLBL(___L5_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_M_HLBL(___L6_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_M_HLBL(___L7_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_M_HLBL(___L8_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_M_HLBL(___L9_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_M_HLBL(___L10_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_M_HLBL(___L11_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_M_HLBL(___L12_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_M_HLBL(___L13_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_M_HLBL(___L14_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_M_HLBL(___L15_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_M_HLBL(___L11_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L11_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L12_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L13_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L14_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L15_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L16_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L17_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L18_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L19_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L20_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L21_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L22_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L23_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L24_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L25_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L26_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL(___L27_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_M_HLBL(___L11_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
___END_M_HLBL

___BEGIN_M_SW

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent____program____scheme_2d_query_23_
#undef ___PH_LBL0
#define ___PH_LBL0 1
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_P_HLBL(___L1_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_P_HLBL(___L2_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_P_HLBL(___L3_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_P_HLBL(___L4_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_P_HLBL(___L5_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_P_HLBL(___L6_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_P_HLBL(___L7_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_P_HLBL(___L8_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_P_HLBL(___L9_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_P_HLBL(___L10_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_P_HLBL(___L11_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_P_HLBL(___L12_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_P_HLBL(___L13_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_P_HLBL(___L14_gerbil_2d_ascent____program____scheme_2d_query_23_)
___DEF_P_HLBL(___L15_gerbil_2d_ascent____program____scheme_2d_query_23_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent____program____scheme_2d_query_23_)
   ___IF_NARGS_EQ(0,___NOTHING)
   ___WRONG_NARGS(0,0,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent____program____scheme_2d_query_23_)
   ___SET_GLO(23,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_3a__3a_timestamp,___BIGFIX(0,1791691014LL))
   ___SET_R1(___NUL)
   ___SET_R2(___CONS(___KEY_struct,___TRU))
   ___SET_R2(___CONS(___R2,___NUL))
   ___SET_STK(1,___R0)
   ___SET_STK(5,___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t)
   ___SET_STK(6,___SYM_relational_2d_solution)
   ___SET_STK(7,___R1)
   ___SET_R3(___FAL)
   ___SET_R1(___CNS(0))
   ___ADJFP(7)
   ___CHECK_HEAP(1,4096)
___DEF_SLBL(1,___L1_gerbil_2d_ascent____program____scheme_2d_query_23_)
   ___POLL(2)
___DEF_SLBL(2,___L2_gerbil_2d_ascent____program____scheme_2d_query_23_)
   ___SET_R0(___LBL(3))
   ___JUMPGLONOTSAFE(___SET_NARGS(6),40,___G_make_2d_class_2d_type)
___DEF_SLBL(3,___L3_gerbil_2d_ascent____program____scheme_2d_query_23_)
   ___SET_GLO(21,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t,___R1)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t)
   ___SET_R0(___LBL(4))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),29,___G_____make_2d_class_2d_predicate)
___DEF_SLBL(4,___L4_gerbil_2d_ascent____program____scheme_2d_query_23_)
   ___SET_GLO(22,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3f_,___R1)
   ___SET_R2(___SYM_result)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t)
   ___SET_R0(___LBL(5))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),30,___G_____make_2d_class_2d_slot_2d_accessor)
___DEF_SLBL(5,___L5_gerbil_2d_ascent____program____scheme_2d_query_23_)
   ___SET_GLO(19,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_2d_result,___R1)
   ___SET_R2(___SYM_result)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t)
   ___SET_R0(___LBL(6))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),31,___G_____make_2d_class_2d_slot_2d_mutator)
___DEF_SLBL(6,___L6_gerbil_2d_ascent____program____scheme_2d_query_23_)
   ___SET_GLO(20,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_2d_result_2d_set_21_,___R1)
   ___SET_R2(___SYM_result)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t)
   ___SET_R0(___LBL(7))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),32,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
___DEF_SLBL(7,___L7_gerbil_2d_ascent____program____scheme_2d_query_23_)
   ___SET_GLO(2,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_solution_2d_result,___R1)
   ___SET_R2(___SYM_result)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t)
   ___SET_R0(___LBL(8))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),33,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
___DEF_SLBL(8,___L8_gerbil_2d_ascent____program____scheme_2d_query_23_)
   ___SET_GLO(3,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_solution_2d_result_2d_set_21_,___R1)
   ___SET_R1(___NUL)
   ___SET_R2(___CONS(___KEY_struct,___TRU))
   ___SET_R2(___CONS(___R2,___NUL))
   ___SET_STK(1,___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t)
   ___SET_STK(2,___SYM_relational_2d_program_2d_solution)
   ___SET_STK(3,___R1)
   ___SET_R3(___FAL)
   ___SET_R1(___CNS(1))
   ___SET_R0(___LBL(10))
   ___ADJFP(3)
   ___CHECK_HEAP(9,4096)
___DEF_SLBL(9,___L9_gerbil_2d_ascent____program____scheme_2d_query_23_)
   ___JUMPGLONOTSAFE(___SET_NARGS(6),40,___G_make_2d_class_2d_type)
___DEF_SLBL(10,___L10_gerbil_2d_ascent____program____scheme_2d_query_23_)
   ___SET_GLO(14,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t,___R1)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t)
   ___SET_R0(___LBL(11))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),29,___G_____make_2d_class_2d_predicate)
___DEF_SLBL(11,___L11_gerbil_2d_ascent____program____scheme_2d_query_23_)
   ___SET_GLO(15,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3f_,___R1)
   ___SET_R2(___SYM_result)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t)
   ___SET_R0(___LBL(12))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),30,___G_____make_2d_class_2d_slot_2d_accessor)
___DEF_SLBL(12,___L12_gerbil_2d_ascent____program____scheme_2d_query_23_)
   ___SET_GLO(12,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_2d_result,___R1)
   ___SET_R2(___SYM_result)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t)
   ___SET_R0(___LBL(13))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),31,___G_____make_2d_class_2d_slot_2d_mutator)
___DEF_SLBL(13,___L13_gerbil_2d_ascent____program____scheme_2d_query_23_)
   ___SET_GLO(13,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_2d_result_2d_set_21_,___R1)
   ___SET_R2(___SYM_result)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t)
   ___SET_R0(___LBL(14))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),32,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
___DEF_SLBL(14,___L14_gerbil_2d_ascent____program____scheme_2d_query_23_)
   ___SET_GLO(0,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_program_2d_solution_2d_result,___R1)
   ___SET_R2(___SYM_result)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t)
   ___SET_R0(___LBL(15))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),33,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
___DEF_SLBL(15,___L15_gerbil_2d_ascent____program____scheme_2d_query_23_)
   ___SET_GLO(1,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23__26_relational_2d_program_2d_solution_2d_result_2d_set_21_,___R1)
   ___SET_R1(___VOID)
   ___ADJFP(-4)
   ___JUMPRET(___STK(1))
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution
#undef ___PH_LBL0
#define ___PH_LBL0 18
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R1 ___D_R2 ___D_R3
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R1 ___R_R2 ___R_R3
#undef ___PW_ALL
#define ___PW_ALL ___W_R1 ___W_R2 ___W_R3
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution)
   ___IF_NARGS_EQ(0,___SET_R1(___NUL))
   ___GET_REST(0,0,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution)
   ___SET_R3(___R1)
   ___SET_R2(___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t)
   ___SET_R1(___GLO_make_2d_instance)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution)
   ___JUMPPRM(___SET_NARGS(3),___PRM_apply)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution
#undef ___PH_LBL0
#define ___PH_LBL0 21
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R1 ___D_R2 ___D_R3
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R1 ___R_R2 ___R_R3
#undef ___PW_ALL
#define ___PW_ALL ___W_R1 ___W_R2 ___W_R3
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution)
   ___IF_NARGS_EQ(0,___SET_R1(___NUL))
   ___GET_REST(0,0,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution)
   ___SET_R3(___R1)
   ___SET_R2(___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t)
   ___SET_R1(___GLO_make_2d_instance)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution)
   ___JUMPPRM(___SET_NARGS(3),___PRM_apply)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows
#undef ___PH_LBL0
#define ___PH_LBL0 24
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
   ___IF(___PAIRP(___R1))
   ___GOTO(___L9_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
   ___END_IF
   ___GOTO(___L11_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
   ___SET_STK(-5,___R1)
   ___SET_R1(___CDR(___STK(-6)))
   ___SET_R0(___LBL(7))
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L11_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
   ___END_IF
___DEF_GLBL(___L9_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
   ___SET_R2(___CAR(___R1))
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R1(___R2)
   ___SET_R0(___LBL(2))
   ___ADJFP(8)
   ___POLL(3)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_GLBL(___L10_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L11_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
   ___END_IF
   ___SET_R2(___CAR(___R1))
   ___SET_R2(___R2)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R2)
   ___SET_R1(___CDR(___R1))
   ___SET_R0(___LBL(5))
   ___ADJFP(8)
   ___POLL(4)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
   ___GOTO(___L10_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
   ___SET_R1(___CONS(___STK(-6),___R1))
   ___ADJFP(-7)
   ___CHECK_HEAP(6,4096)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
   ___ADJFP(-1)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L11_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
   ___SET_R1(___NUL)
   ___JUMPRET(___R0)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
   ___SET_R1(___CONS(___STK(-5),___R1))
   ___ADJFP(-7)
   ___CHECK_HEAP(8,4096)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
   ___ADJFP(-1)
   ___JUMPRET(___STK(1))
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows
#undef ___PH_LBL0
#define ___PH_LBL0 34
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
   ___IF_NARGS_EQ(2,___NOTHING)
   ___WRONG_NARGS(0,2,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_R2(___SYM_finished)
   ___ADJFP(8)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
   ___SET_R0(___LBL(2))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),37,___G_clan_2f_poo_2f_object_23__2e_ref)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
   ___END_IF
   ___GOTO(___L8_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___DEF_GLBL(___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
   ___SET_R1(___STK(-6))
   ___SET_R2(___SYM_rows_2d_of)
   ___SET_R0(___LBL(4))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),37,___G_clan_2f_poo_2f_object_23__2e_ref)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
   ___SET_STK(-6,___R1)
   ___SET_R1(___STK(-5))
   ___SET_R0(___LBL(5))
   ___ADJFP(-4)
   ___JUMPGENSAFE(___SET_NARGS(1),___STK(-2))
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
   ___SET_R0(___STK(-3))
   ___POLL(6)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
   ___ADJFP(-4)
   ___JUMPINT(___SET_NARGS(1),___PRC(24),___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_GLBL(___L8_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
   ___SET_R1(___SUB(1))
   ___SET_R0(___LBL(3))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),38,___G_error)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export
#undef ___PH_LBL0
#define ___PH_LBL0 42
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
   ___IF_NARGS_EQ(2,___NOTHING)
   ___WRONG_NARGS(0,2,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_R2(___R1)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_program_2f_types_23_GerbilAscentFragmentContract)
   ___ADJFP(8)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
   ___SET_R0(___LBL(2))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),36,___G_clan_2f_poo_2f_mop_23_validate)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
   ___SET_R1(___STK(-6))
   ___SET_R2(___SYM_exports)
   ___SET_R0(___LBL(3))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),37,___G_clan_2f_poo_2f_object_23__2e_ref)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
   ___SET_STK(-6,___R1)
   ___SET_R1(___STK(-5))
   ___SET_R0(___STK(-7))
   ___POLL(4)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
   ___ADJFP(-8)
   ___JUMPGENSAFE(___SET_NARGS(1),___STK(2))
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result
#undef ___PH_LBL0
#define ___PH_LBL0 48
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R2(___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t)
   ___SET_R0(___LBL(1))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM__23__23_structure_2d_instance_2d_of_3f_)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L8_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
   ___END_IF
   ___SET_R2(___STK(-6))
   ___SET_R1(___SUB(2))
   ___POLL(2)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
   ___SET_R0(___LBL(3))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),38,___G_error)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_GLBL(___L8_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
   ___SET_STK(-3,___STK(-6))
   ___SET_R3(___FAL)
   ___SET_R2(___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t)
   ___SET_R1(___FIX(1L))
   ___SET_R0(___LBL(4))
   ___ADJFP(-3)
   ___JUMPPRM(___SET_NARGS(4),___PRM__23__23_structure_2d_ref)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
   ___SET_STK(-2,___R1)
   ___SET_R2(___SYM_finished)
   ___ADJFP(4)
   ___POLL(5)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
   ___SET_R0(___LBL(6))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),37,___G_clan_2f_poo_2f_object_23__2e_ref)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L9_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
   ___END_IF
   ___SET_R1(___SUB(3))
   ___SET_R0(___LBL(7))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),38,___G_error)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_GLBL(___L9_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
   ___SET_R1(___STK(-6))
   ___ADJFP(-8)
   ___JUMPRET(___STK(1))
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query
#undef ___PH_LBL0
#define ___PH_LBL0 57
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___DEF_P_HLBL(___L11_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
   ___IF_NARGS_EQ(2,___NOTHING)
   ___WRONG_NARGS(0,2,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_R2(___R1)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_program_2f_types_23_GerbilAscentFragmentContract)
   ___ADJFP(8)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
   ___SET_R0(___LBL(2))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),36,___G_clan_2f_poo_2f_mop_23_validate)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
   ___SET_R1(___STK(-6))
   ___SET_R2(___SYM_exports)
   ___SET_R0(___LBL(3))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),37,___G_clan_2f_poo_2f_object_23__2e_ref)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
   ___SET_STK(-6,___R1)
   ___SET_R1(___STK(-5))
   ___SET_R0(___LBL(4))
   ___ADJFP(-4)
   ___JUMPGENSAFE(___SET_NARGS(1),___STK(-2))
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
   ___SET_STK(-2,___ALLOC_CLO(1UL))
   ___BEGIN_SETUP_CLO(1,___STK(-2),6)
   ___ADD_CLO_ELEM(0,___R1)
   ___END_SETUP_CLO(1)
   ___SET_R1(___STK(-2))
   ___ADJFP(-3)
   ___CHECK_HEAP(5,4096)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
   ___ADJFP(-1)
   ___JUMPRET(___STK(1))
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(6,1,0,0)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R4)
   ___ADJFP(8)
   ___POLL(7)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
   ___SET_R0(___LBL(8))
   ___JUMPINT(___SET_NARGS(1),___PRC(48),___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
   ___SET_R2(___SYM_rows_2d_of)
   ___SET_R0(___LBL(9))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),37,___G_clan_2f_poo_2f_object_23__2e_ref)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
   ___SET_STK(-5,___R1)
   ___SET_R1(___CLO(___STK(-6),1))
   ___SET_R0(___LBL(10))
   ___ADJFP(-4)
   ___JUMPGENSAFE(___SET_NARGS(1),___STK(-1))
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
   ___SET_R0(___STK(-3))
   ___POLL(11)
___DEF_SLBL(11,___L11_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query)
   ___ADJFP(-4)
   ___JUMPINT(___SET_NARGS(1),___PRC(24),___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries
#undef ___PH_LBL0
#define ___PH_LBL0 70
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L11_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L12_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L13_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L14_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L15_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L16_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L17_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L18_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L19_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L20_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L21_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L22_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L23_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L24_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L25_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L26_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_P_HLBL(___L27_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___IF_NARGS_EQ(2,___NOTHING)
   ___WRONG_NARGS(0,2,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_R1(___R2)
   ___SET_R0(___LBL(1))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_list_3f_)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L28_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___END_IF
   ___SET_R2(___STK(-5))
   ___SET_R1(___PRM_symbol_3f_)
   ___POLL(2)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_R0(___LBL(3))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),34,___G_andmap____0)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L29_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___END_IF
___DEF_GLBL(___L28_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_R2(___STK(-5))
   ___SET_R1(___SUB(4))
   ___POLL(4)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_R0(___LBL(5))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),38,___G_error)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_GLBL(___L29_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_R2(___STK(-6))
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_program_2f_types_23_GerbilAscentFragmentContract)
   ___SET_R0(___LBL(6))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),36,___G_clan_2f_poo_2f_mop_23_validate)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_R1(___STK(-6))
   ___SET_R2(___SYM_exports)
   ___SET_R0(___LBL(7))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),37,___G_clan_2f_poo_2f_object_23__2e_ref)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___IF(___NOT(___PROCEDUREP(___R1)))
   ___GOTO(___L37_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___END_IF
   ___SET_R2(___R1)
   ___SET_R3(___STK(-5))
   ___SET_R1(___STK(-5))
   ___SET_R0(___LBL(22))
   ___ADJFP(-4)
   ___IF(___PAIRP(___R3))
   ___GOTO(___L31_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___END_IF
   ___GOTO(___L32_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_GLBL(___L30_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___IF(___NOT(___PAIRP(___R3)))
   ___GOTO(___L32_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___END_IF
___DEF_GLBL(___L31_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_R3(___CDR(___R3))
   ___POLL(8)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___GOTO(___L30_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_GLBL(___L32_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___IF(___NOT(___NULLP(___R3)))
   ___GOTO(___L36_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___END_IF
   ___SET_STK(1,___R2)
   ___SET_R2(___R1)
   ___SET_R1(___STK(1))
   ___POLL(9)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___IF(___PAIRP(___R2))
   ___GOTO(___L33_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___END_IF
   ___GOTO(___L34_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_STK(-4,___R1)
   ___SET_R2(___CDR(___STK(-5)))
   ___SET_R1(___STK(-6))
   ___SET_R0(___LBL(12))
   ___IF(___NOT(___PAIRP(___R2)))
   ___GOTO(___L34_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___END_IF
___DEF_GLBL(___L33_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_R1(___CAR(___R2))
   ___ADJFP(8)
   ___POLL(11)
___DEF_SLBL(11,___L11_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_R0(___LBL(10))
   ___JUMPGENSAFE(___SET_NARGS(1),___STK(-6))
___DEF_SLBL(12,___L12_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_R1(___CONS(___STK(-4),___R1))
   ___ADJFP(-7)
   ___CHECK_HEAP(13,4096)
___DEF_SLBL(13,___L13_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___ADJFP(-1)
   ___JUMPRET(___STK(1))
___DEF_SLBL(14,___L14_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_R2(___CLO(___STK(-6),1))
   ___SET_R0(___STK(-7))
   ___ADJFP(-8)
   ___POLL(15)
___DEF_SLBL(15,___L15_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___IF(___PAIRP(___R2))
   ___GOTO(___L35_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___END_IF
___DEF_GLBL(___L34_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_R1(___NUL)
   ___JUMPRET(___R0)
___DEF_SLBL(16,___L16_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_STK(-4,___R1)
   ___SET_R2(___CDR(___STK(-5)))
   ___SET_R1(___STK(-6))
   ___SET_R0(___LBL(12))
   ___IF(___NOT(___PAIRP(___R2)))
   ___GOTO(___L34_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___END_IF
___DEF_GLBL(___L35_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_R2(___CAR(___R2))
   ___SET_R0(___LBL(16))
   ___ADJFP(8)
   ___POLL(17)
___DEF_SLBL(17,___L17_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R1(___R2)
   ___ADJFP(4)
   ___POLL(18)
___DEF_SLBL(18,___L18_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_R0(___LBL(19))
   ___JUMPGENSAFE(___SET_NARGS(1),___STK(-2))
___DEF_SLBL(19,___L19_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_R0(___STK(-3))
   ___POLL(20)
___DEF_SLBL(20,___L20_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___ADJFP(-4)
   ___JUMPINT(___SET_NARGS(1),___PRC(24),___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_GLBL(___L36_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_STK(1,___R2)
   ___SET_R2(___R1)
   ___SET_R1(___STK(1))
   ___ADJFP(1)
   ___POLL(21)
___DEF_SLBL(21,___L21_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___ADJFP(-1)
   ___JUMPPRM(___SET_NARGS(2),___PRM_map)
___DEF_SLBL(22,___L22_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_STK(-2,___ALLOC_CLO(1UL))
   ___BEGIN_SETUP_CLO(1,___STK(-2),24)
   ___ADD_CLO_ELEM(0,___R1)
   ___END_SETUP_CLO(1)
   ___SET_R1(___STK(-2))
   ___ADJFP(-3)
   ___CHECK_HEAP(23,4096)
___DEF_SLBL(23,___L23_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___ADJFP(-1)
   ___JUMPRET(___STK(1))
___DEF_SLBL(24,___L24_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(24,1,0,0)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R4)
   ___ADJFP(8)
   ___POLL(25)
___DEF_SLBL(25,___L25_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_R0(___LBL(26))
   ___JUMPINT(___SET_NARGS(1),___PRC(48),___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result)
___DEF_SLBL(26,___L26_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_R2(___SYM_rows_2d_of)
   ___SET_R0(___LBL(14))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),37,___G_clan_2f_poo_2f_object_23__2e_ref)
___DEF_GLBL(___L37_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_R2(___STK(-5))
   ___SET_R0(___LBL(27))
   ___ADJFP(-4)
   ___JUMPPRM(___SET_NARGS(2),___PRM_map)
___DEF_SLBL(27,___L27_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries)
   ___SET_R0(___LBL(27))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query
#undef ___PH_LBL0
#define ___PH_LBL0 99
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_P_HLBL(___L11_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
   ___IF_NARGS_EQ(3,___NOTHING)
   ___WRONG_NARGS(0,3,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_STK(4,___R3)
   ___SET_R2(___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t)
   ___SET_R0(___LBL(1))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM__23__23_structure_2d_instance_2d_of_3f_)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L12_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
   ___END_IF
   ___SET_R2(___STK(-6))
   ___SET_R1(___SUB(5))
   ___POLL(2)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
   ___SET_R0(___LBL(3))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),38,___G_error)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_GLBL(___L12_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
   ___SET_STK(1,___STK(-6))
   ___SET_R3(___FAL)
   ___SET_R2(___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t)
   ___SET_R1(___FIX(1L))
   ___SET_R0(___LBL(4))
   ___ADJFP(1)
   ___JUMPPRM(___SET_NARGS(4),___PRM__23__23_structure_2d_ref)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
   ___SET_STK(-6,___R1)
   ___SET_R2(___STK(-4))
   ___SET_R1(___STK(-5))
   ___POLL(5)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
   ___SET_R0(___LBL(6))
   ___JUMPINT(___SET_NARGS(2),___PRC(42),___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
   ___SET_STK(-5,___R1)
   ___SET_R1(___STK(-6))
   ___SET_R2(___SYM_finished)
   ___SET_R0(___LBL(7))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),37,___G_clan_2f_poo_2f_object_23__2e_ref)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L13_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
   ___END_IF
   ___GOTO(___L14_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
___DEF_GLBL(___L13_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
   ___SET_R1(___STK(-6))
   ___SET_R2(___SYM_rows_2d_of)
   ___SET_R0(___LBL(9))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),37,___G_clan_2f_poo_2f_object_23__2e_ref)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
   ___SET_STK(-6,___R1)
   ___SET_R1(___STK(-5))
   ___SET_R0(___LBL(10))
   ___ADJFP(-4)
   ___JUMPGENSAFE(___SET_NARGS(1),___STK(-2))
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
   ___SET_R0(___STK(-3))
   ___POLL(11)
___DEF_SLBL(11,___L11_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
   ___ADJFP(-4)
   ___JUMPINT(___SET_NARGS(1),___PRC(24),___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows)
___DEF_GLBL(___L14_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query)
   ___SET_R1(___SUB(1))
   ___SET_R0(___LBL(8))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),38,___G_error)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name
#undef ___PH_LBL0
#define ___PH_LBL0 112
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
   ___IF_NARGS_EQ(2,___NOTHING)
   ___WRONG_NARGS(0,2,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_R2(___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t)
   ___SET_R0(___LBL(1))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM__23__23_structure_2d_instance_2d_of_3f_)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
   ___END_IF
   ___IF(___SYMBOLP(___STK(-5)))
   ___GOTO(___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
   ___END_IF
___DEF_GLBL(___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
   ___SET_R2(___STK(-5))
   ___SET_R1(___SUB(6))
   ___POLL(2)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
   ___SET_R0(___LBL(3))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),38,___G_error)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
___DEF_GLBL(___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
   ___SET_STK(1,___STK(-6))
   ___SET_R3(___FAL)
   ___SET_R2(___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t)
   ___SET_R1(___FIX(1L))
   ___SET_R0(___LBL(4))
   ___ADJFP(1)
   ___JUMPPRM(___SET_NARGS(4),___PRM__23__23_structure_2d_ref)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
   ___SET_R2(___STK(-5))
   ___SET_R0(___STK(-7))
   ___POLL(5)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name)
   ___ADJFP(-8)
   ___JUMPINT(___SET_NARGS(2),___PRC(34),___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query
#undef ___PH_LBL0
#define ___PH_LBL0 119
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
   ___IF_NARGS_EQ(2,___NOTHING)
   ___WRONG_NARGS(0,2,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_R2(___SYM_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t)
   ___SET_R0(___LBL(1))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM__23__23_structure_2d_instance_2d_of_3f_)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
   ___END_IF
   ___IF(___SYMBOLP(___STK(-5)))
   ___GOTO(___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
   ___END_IF
___DEF_GLBL(___L6_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
   ___SET_R2(___STK(-5))
   ___SET_R1(___SUB(7))
   ___POLL(2)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
   ___SET_R0(___LBL(3))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),38,___G_error)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
___DEF_GLBL(___L7_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
   ___SET_STK(1,___STK(-6))
   ___SET_R3(___FAL)
   ___SET_R2(___GLO_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t)
   ___SET_R1(___FIX(1L))
   ___SET_R0(___LBL(4))
   ___ADJFP(1)
   ___JUMPPRM(___SET_NARGS(4),___PRM__23__23_structure_2d_ref)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
   ___SET_R2(___STK(-5))
   ___SET_R0(___STK(-7))
   ___POLL(5)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query)
   ___ADJFP(-8)
   ___JUMPINT(___SET_NARGS(2),___PRC(34),___L_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows)
___END_P_SW
___END_P_COD

___END_M_SW
___END_M_COD

___BEGIN_LBL
 ___DEF_LBL_INTRO(___H_gerbil_2d_ascent____program____scheme_2d_query_23_,___REF_SYM(16,___S_gerbil_2d_ascent____program____scheme_2d_query_23_),___REF_FAL,16,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____program____scheme_2d_query_23_,0,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent____program____scheme_2d_query_23_,___IFD(___RETI,7,0,0x3f71L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____program____scheme_2d_query_23_,___IFD(___RETI,7,0,0x3f71L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____program____scheme_2d_query_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____program____scheme_2d_query_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____program____scheme_2d_query_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____program____scheme_2d_query_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____program____scheme_2d_query_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____program____scheme_2d_query_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____program____scheme_2d_query_23_,___IFD(___RETI,7,0,0x3f71L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____program____scheme_2d_query_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____program____scheme_2d_query_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____program____scheme_2d_query_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____program____scheme_2d_query_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____program____scheme_2d_query_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____program____scheme_2d_query_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution,___REF_SYM(5,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution),___REF_FAL,2,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution,___REF_SYM(4,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution),___REF_FAL,2,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows,___REF_SYM(3,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows),___REF_FAL,9,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows,___IFD(___RETI,1,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows,___IFD(___RETN,5,0,0x5L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows,___IFD(___RETI,1,0,0x3f1L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows,___REF_SYM(13,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows),___REF_FAL,7,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows,2,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows,___IFD(___RETI,8,0,0x3f07L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows,___IFD(___RETN,5,0,0x5L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows,___IFD(___RETI,4,4,0x3f0L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export,___REF_SYM(6,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export),___REF_FAL,5,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export,2,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export,___IFD(___RETI,8,0,0x3f07L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export,___IFD(___RETN,5,0,0x5L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export,___IFD(___RETI,8,8,0x3f02L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result,___REF_SYM(2,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result),___REF_FAL,8,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query,___REF_SYM(8,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query),___REF_FAL,12,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query,2,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query,___IFD(___RETI,8,0,0x3f07L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query,___IFD(___RETN,5,0,0x5L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query,___IFD(___RETI,1,0,0x3f1L))
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query,1,1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query,___IFD(___RETI,4,4,0x3f0L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___REF_SYM(7,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries),___REF_FAL,28,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,2,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETI,8,0,0x3f07L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETI,8,0,0x3f07L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETN,5,0,0x5L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETI,8,0,0x3f07L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETN,5,0,0x9L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETI,1,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETI,8,0,0x3f07L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETI,4,0,0x3f3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETI,4,4,0x3f0L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETI,1,4,0x3f0L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETI,1,0,0x3f1L))
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,1,1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query,___REF_SYM(11,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query),___REF_FAL,12,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query,3,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query,___IFD(___RETN,5,0,0xfL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query,___IFD(___RETI,8,0,0x3f0fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query,___IFD(___RETN,5,0,0xfL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query,___IFD(___RETN,5,0,0xdL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query,___IFD(___RETN,5,0,0x5L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query,___IFD(___RETI,4,4,0x3f0L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name,___REF_SYM(12,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name),___REF_FAL,6,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name,2,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name,___IFD(___RETI,8,0,0x3f07L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name,___IFD(___RETN,5,0,0x5L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name,___IFD(___RETI,8,8,0x3f00L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query,___REF_SYM(9,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query),___REF_FAL,6,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query,2,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query,___IFD(___RETI,8,0,0x3f07L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query,___IFD(___RETN,5,0,0x5L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query,___IFD(___RETI,8,8,0x3f00L))
___END_LBL

___BEGIN_MOD_PRM
___DEF_MOD_PRM(24,___G_gerbil_2d_ascent____program____scheme_2d_query_23_,1)
___DEF_MOD_PRM(7,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution,18)
___DEF_MOD_PRM(6,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution,21)
___DEF_MOD_PRM(5,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows,24)
___DEF_MOD_PRM(18,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows,34)
___DEF_MOD_PRM(8,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export,42)
___DEF_MOD_PRM(4,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result,48)
___DEF_MOD_PRM(10,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query,57)
___DEF_MOD_PRM(9,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,70)
___DEF_MOD_PRM(16,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query,99)
___DEF_MOD_PRM(17,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name,112)
___DEF_MOD_PRM(11,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query,119)
___END_MOD_PRM

___BEGIN_MOD_C_INIT
___END_MOD_C_INIT

___BEGIN_MOD_GLO
___DEF_MOD_GLO(24,___G_gerbil_2d_ascent____program____scheme_2d_query_23_,1)
___DEF_MOD_GLO(7,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution,18)
___DEF_MOD_GLO(6,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution,21)
___DEF_MOD_GLO(5,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows,24)
___DEF_MOD_GLO(18,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows,34)
___DEF_MOD_GLO(8,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export,42)
___DEF_MOD_GLO(4,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result,48)
___DEF_MOD_GLO(10,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query,57)
___DEF_MOD_GLO(9,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,70)
___DEF_MOD_GLO(16,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query,99)
___DEF_MOD_GLO(17,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name,112)
___DEF_MOD_GLO(11,___G_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query,119)
___END_MOD_GLO

___BEGIN_MOD_SYM_KEY
___DEF_MOD_SYM(0,___S_exports,"exports")
___DEF_MOD_SYM(1,___S_finished,"finished")
___DEF_MOD_SYM(2,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_checked_2d_solution_2d_result,"gerbil-ascent/program/scheme-query#checked-solution-result")

___DEF_MOD_SYM(3,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_copy_2d_query_2d_rows,"gerbil-ascent/program/scheme-query#copy-query-rows")

___DEF_MOD_SYM(4,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_program_2d_solution,"gerbil-ascent/program/scheme-query#make-relational-program-solution")

___DEF_MOD_SYM(5,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_make_2d_relational_2d_solution,"gerbil-ascent/program/scheme-query#make-relational-solution")

___DEF_MOD_SYM(6,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_export,"gerbil-ascent/program/scheme-query#relational-export")

___DEF_MOD_SYM(7,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_queries,"gerbil-ascent/program/scheme-query#relational-prepare-queries")

___DEF_MOD_SYM(8,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_prepare_2d_query,"gerbil-ascent/program/scheme-query#relational-prepare-query")

___DEF_MOD_SYM(9,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_query,"gerbil-ascent/program/scheme-query#relational-program-query")

___DEF_MOD_SYM(10,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_program_2d_solution_3a__3a_t,"gerbil-ascent/program/scheme-query#relational-program-solution::t")

___DEF_MOD_SYM(11,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query,"gerbil-ascent/program/scheme-query#relational-query")

___DEF_MOD_SYM(12,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_query_2d_name,"gerbil-ascent/program/scheme-query#relational-query-name")

___DEF_MOD_SYM(13,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_result_2d_rows,"gerbil-ascent/program/scheme-query#relational-result-rows")

___DEF_MOD_SYM(14,___S_gerbil_2d_ascent_2f_program_2f_scheme_2d_query_23_relational_2d_solution_3a__3a_t,"gerbil-ascent/program/scheme-query#relational-solution::t")

___DEF_MOD_SYM(15,___S_gerbil_2d_ascent____program____scheme_2d_query,"gerbil-ascent__program__scheme-query")

___DEF_MOD_SYM(16,___S_gerbil_2d_ascent____program____scheme_2d_query_23_,"gerbil-ascent__program__scheme-query#")

___DEF_MOD_SYM(17,___S_relational_2d_program_2d_solution,"relational-program-solution")
___DEF_MOD_SYM(18,___S_relational_2d_solution,"relational-solution")
___DEF_MOD_SYM(19,___S_result,"result")
___DEF_MOD_SYM(20,___S_rows_2d_of,"rows-of")
___DEF_MOD_KEY(0,___K_struct,"struct")
___END_MOD_SYM_KEY

#endif
