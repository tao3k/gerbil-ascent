prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/candidate

(begin
  (declare-class
   gerbil-ascent/candidate/finite-plan#finite-rule::t
   (@class gerbil-ascent/candidate/finite-plan#finite-rule::t
           ()
           (object::t t::t)
           (relation head body level)
           (relation head body level)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-rule::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/finite-plan#finite-rule::t)
    'class::t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-rule?
   (@predicate gerbil-ascent/candidate/finite-plan#finite-rule::t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#make-finite-rule
   (@constructor gerbil-ascent/candidate/finite-plan#finite-rule::t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-rule-relation
   (@accessor gerbil-ascent/candidate/finite-plan#finite-rule::t relation #t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-rule-head
   (@accessor gerbil-ascent/candidate/finite-plan#finite-rule::t head #t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-rule-body
   (@accessor gerbil-ascent/candidate/finite-plan#finite-rule::t body #t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-rule-level
   (@accessor gerbil-ascent/candidate/finite-plan#finite-rule::t level #t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-rule-relation-set!
   (@mutator gerbil-ascent/candidate/finite-plan#finite-rule::t relation #t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-rule-head-set!
   (@mutator gerbil-ascent/candidate/finite-plan#finite-rule::t head #t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-rule-body-set!
   (@mutator gerbil-ascent/candidate/finite-plan#finite-rule::t body #t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-rule-level-set!
   (@mutator gerbil-ascent/candidate/finite-plan#finite-rule::t level #t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#&finite-rule-relation
   (@accessor gerbil-ascent/candidate/finite-plan#finite-rule::t relation #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#&finite-rule-head
   (@accessor gerbil-ascent/candidate/finite-plan#finite-rule::t head #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#&finite-rule-body
   (@accessor gerbil-ascent/candidate/finite-plan#finite-rule::t body #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#&finite-rule-level
   (@accessor gerbil-ascent/candidate/finite-plan#finite-rule::t level #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#&finite-rule-relation-set!
   (@mutator gerbil-ascent/candidate/finite-plan#finite-rule::t relation #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#&finite-rule-head-set!
   (@mutator gerbil-ascent/candidate/finite-plan#finite-rule::t head #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#&finite-rule-body-set!
   (@mutator gerbil-ascent/candidate/finite-plan#finite-rule::t body #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#&finite-rule-level-set!
   (@mutator gerbil-ascent/candidate/finite-plan#finite-rule::t level #f))
  (declare-class
   gerbil-ascent/candidate/finite-plan#finite-clause::t
   (@class gerbil-ascent/candidate/finite-plan#finite-clause::t
           ()
           (object::t t::t)
           (kind relation apply output operator)
           (kind relation apply output operator)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-clause::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/finite-plan#finite-clause::t)
    'class::t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-clause?
   (@predicate gerbil-ascent/candidate/finite-plan#finite-clause::t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#make-finite-clause
   (@constructor gerbil-ascent/candidate/finite-plan#finite-clause::t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-clause-kind
   (@accessor gerbil-ascent/candidate/finite-plan#finite-clause::t kind #t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-clause-relation
   (@accessor
    gerbil-ascent/candidate/finite-plan#finite-clause::t
    relation
    #t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-clause-apply
   (@accessor gerbil-ascent/candidate/finite-plan#finite-clause::t apply #t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-clause-output
   (@accessor gerbil-ascent/candidate/finite-plan#finite-clause::t output #t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-clause-operator
   (@accessor
    gerbil-ascent/candidate/finite-plan#finite-clause::t
    operator
    #t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-clause-kind-set!
   (@mutator gerbil-ascent/candidate/finite-plan#finite-clause::t kind #t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-clause-relation-set!
   (@mutator gerbil-ascent/candidate/finite-plan#finite-clause::t relation #t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-clause-apply-set!
   (@mutator gerbil-ascent/candidate/finite-plan#finite-clause::t apply #t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-clause-output-set!
   (@mutator gerbil-ascent/candidate/finite-plan#finite-clause::t output #t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#finite-clause-operator-set!
   (@mutator gerbil-ascent/candidate/finite-plan#finite-clause::t operator #t))
  (declare-type
   gerbil-ascent/candidate/finite-plan#&finite-clause-kind
   (@accessor gerbil-ascent/candidate/finite-plan#finite-clause::t kind #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#&finite-clause-relation
   (@accessor
    gerbil-ascent/candidate/finite-plan#finite-clause::t
    relation
    #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#&finite-clause-apply
   (@accessor gerbil-ascent/candidate/finite-plan#finite-clause::t apply #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#&finite-clause-output
   (@accessor gerbil-ascent/candidate/finite-plan#finite-clause::t output #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#&finite-clause-operator
   (@accessor
    gerbil-ascent/candidate/finite-plan#finite-clause::t
    operator
    #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#&finite-clause-kind-set!
   (@mutator gerbil-ascent/candidate/finite-plan#finite-clause::t kind #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#&finite-clause-relation-set!
   (@mutator gerbil-ascent/candidate/finite-plan#finite-clause::t relation #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#&finite-clause-apply-set!
   (@mutator gerbil-ascent/candidate/finite-plan#finite-clause::t apply #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#&finite-clause-output-set!
   (@mutator gerbil-ascent/candidate/finite-plan#finite-clause::t output #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#&finite-clause-operator-set!
   (@mutator gerbil-ascent/candidate/finite-plan#finite-clause::t operator #f))
  (declare-type
   gerbil-ascent/candidate/finite-plan#prepare-finite-rule
   (@lambda 3
            #f
            signature:
            (return:
             gerbil-ascent/candidate/finite-plan#finite-rule::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/finite-plan))))
