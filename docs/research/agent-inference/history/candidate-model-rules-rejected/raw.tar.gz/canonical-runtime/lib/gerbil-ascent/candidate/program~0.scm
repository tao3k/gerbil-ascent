(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/program::timestamp 1791687883)
  (begin
    (define gerbil-ascent/candidate/program#scalar?
      (lambda (_%value27076%_)
        (let ((_%$e27078%_ (exact-integer? _%value27076%_)))
          (if _%$e27078%_
              _%$e27078%_
              (let ((_%$e27081%_ (boolean? _%value27076%_)))
                (if _%$e27081%_
                    _%$e27081%_
                    (let ((_%$e27084%_ (symbol? _%value27076%_)))
                      (if _%$e27084%_
                          _%$e27084%_
                          (char? _%value27076%_)))))))))
    (define gerbil-ascent/candidate/program#reject
      (lambda (_%code27072%_ _%path27073%_ _%detail27074%_)
        (let ((__tmp36391
               (let ((__tmp36392
                      (let ()
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/types#reasoning-diagnostic::t
                         _%code27072%_
                         _%path27073%_
                         _%detail27074%_))))
                 (declare (not safe))
                 (##structure
                  gerbil-ascent/candidate/types#candidate-rejection::t
                  __tmp36392))))
          (declare (not safe))
          (raise __tmp36391))))
    (define gerbil-ascent/candidate/program#candidate-variable?
      (lambda (_%value27068%_)
        (if (symbol? _%value27068%_)
            (let ((_%spelling27070%_
                   (let ()
                     (declare (not safe))
                     (##symbol->string _%value27068%_))))
              (if (> (let ()
                       (declare (not safe))
                       (##string-length _%spelling27070%_))
                     '1)
                  (let ((__tmp36393 (string-ref _%spelling27070%_ '0)))
                    (declare (not safe))
                    (##char=? __tmp36393 '#\?))
                  '#f))
            '#f)))
    (define gerbil-ascent/candidate/program#candidate-term?
      (lambda (_%value27066%_)
        (if (gerbil-ascent/candidate/program#scalar? _%value27066%_)
            (not (eq? _%value27066%_ '?))
            '#f)))
    (define gerbil-ascent/candidate/program#candidate-parse
      (lambda (_%datum27044%_)
        (if (and (let ()
                   (declare (not safe))
                   (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                    _%datum27044%_
                    '16384
                    '128))
                 (list? _%datum27044%_)
                 (pair? _%datum27044%_)
                 (eq? (let () (declare (not safe)) (##car _%datum27044%_))
                      'candidate)
                 (<= (length (let ()
                               (declare (not safe))
                               (##cdr _%datum27044%_)))
                     '256))
            '#!void
            (gerbil-ascent/candidate/program#reject
             'invalid-candidate
             '(candidate)
             'expected-inert-candidate-list))
        (let _%loop27046%_ ((_%clauses27048%_ (cdr _%datum27044%_))
                            (_%index27049%_ '1)
                            (_%relations27050%_ '())
                            (_%facts27051%_ '())
                            (_%rules27052%_ '())
                            (_%query27053%_ '#f)
                            (_%limits27054%_ '#f))
          (if (null? _%clauses27048%_)
              (begin
                (if _%query27053%_
                    '#!void
                    (gerbil-ascent/candidate/program#reject
                     'missing-query
                     '(query)
                     'required))
                (if _%limits27054%_
                    '#!void
                    (gerbil-ascent/candidate/program#reject
                     'missing-limits
                     '(limits)
                     'required))
                (if (> (length _%relations27050%_)
                       gerbil-ascent/candidate/types#+max-relations+)
                    (gerbil-ascent/candidate/program#reject
                     'relation-limit
                     '(relations)
                     gerbil-ascent/candidate/types#+max-relations+)
                    '#!void)
                (if (> (length _%rules27052%_)
                       gerbil-ascent/candidate/types#+max-rules+)
                    (gerbil-ascent/candidate/program#reject
                     'rule-limit
                     '(rules)
                     gerbil-ascent/candidate/types#+max-rules+)
                    '#!void)
                (let ((__tmp36396 (reverse _%relations27050%_))
                      (__tmp36395 (reverse _%facts27051%_))
                      (__tmp36394 (reverse _%rules27052%_)))
                  (declare (not safe))
                  (##structure
                   gerbil-ascent/candidate/types#reasoning-candidate::t
                   __tmp36396
                   __tmp36395
                   __tmp36394
                   _%query27053%_
                   _%limits27054%_)))
              (let ((_%clause27056%_ (car _%clauses27048%_))
                    (_%path27057%_ (list 'clause _%index27049%_)))
                (if (and (list? _%clause27056%_)
                         (pair? _%clause27056%_)
                         (symbol? (let ()
                                    (declare (not safe))
                                    (##car _%clause27056%_))))
                    '#!void
                    (gerbil-ascent/candidate/program#reject
                     'invalid-clause
                     _%path27057%_
                     _%clause27056%_))
                (let ((_%$e27059%_ (car _%clause27056%_)))
                  (if (eq? 'relation _%$e27059%_)
                      (begin
                        (if (and (= (length _%clause27056%_) '3)
                                 (symbol? (cadr _%clause27056%_))
                                 (exact-integer? (caddr _%clause27056%_))
                                 (<= '0 (caddr _%clause27056%_)))
                            '#!void
                            (gerbil-ascent/candidate/program#reject
                             'invalid-relation
                             _%path27057%_
                             _%clause27056%_))
                        (_%loop27046%_
                         (cdr _%clauses27048%_)
                         (+ _%index27049%_ '1)
                         (cons (cons (cadr _%clause27056%_)
                                     (caddr _%clause27056%_))
                               _%relations27050%_)
                         _%facts27051%_
                         _%rules27052%_
                         _%query27053%_
                         _%limits27054%_))
                      (if (eq? 'fact _%$e27059%_)
                          (begin
                            (if (and (>= (length _%clause27056%_) '2)
                                     (symbol? (cadr _%clause27056%_))
                                     (let ((__tmp36398
                                            (lambda (_%value27062%_)
                                              (and (gerbil-ascent/candidate/program#scalar?
                                                    _%value27062%_)
                                                   (if (gerbil-ascent/candidate/program#candidate-variable?
                                                        _%value27062%_)
                                                       '#f
                                                       (not (eq? _%value27062%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '?))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           (__tmp36397 (cddr _%clause27056%_)))
                                       (declare (not safe))
                                       (andmap__0 __tmp36398 __tmp36397)))
                                '#!void
                                (gerbil-ascent/candidate/program#reject
                                 'invalid-fact
                                 _%path27057%_
                                 _%clause27056%_))
                            (_%loop27046%_
                             (cdr _%clauses27048%_)
                             (+ _%index27049%_ '1)
                             _%relations27050%_
                             (cons (vector (cadr _%clause27056%_)
                                           (cddr _%clause27056%_)
                                           _%index27049%_)
                                   _%facts27051%_)
                             _%rules27052%_
                             _%query27053%_
                             _%limits27054%_))
                          (if (eq? 'rule _%$e27059%_)
                              (begin
                                (if (>= (length _%clause27056%_) '3)
                                    '#!void
                                    (gerbil-ascent/candidate/program#reject
                                     'invalid-rule
                                     _%path27057%_
                                     _%clause27056%_))
                                (_%loop27046%_
                                 (cdr _%clauses27048%_)
                                 (+ _%index27049%_ '1)
                                 _%relations27050%_
                                 _%facts27051%_
                                 (cons (vector (cadr _%clause27056%_)
                                               (cddr _%clause27056%_)
                                               _%index27049%_)
                                       _%rules27052%_)
                                 _%query27053%_
                                 _%limits27054%_))
                              (if (eq? 'query _%$e27059%_)
                                  (begin
                                    (if _%query27053%_
                                        (gerbil-ascent/candidate/program#reject
                                         'duplicate-query
                                         _%path27057%_
                                         _%clause27056%_)
                                        '#!void)
                                    (if (>= (length _%clause27056%_) '2)
                                        '#!void
                                        (gerbil-ascent/candidate/program#reject
                                         'invalid-query
                                         _%path27057%_
                                         _%clause27056%_))
                                    (_%loop27046%_
                                     (cdr _%clauses27048%_)
                                     (+ _%index27049%_ '1)
                                     _%relations27050%_
                                     _%facts27051%_
                                     _%rules27052%_
                                     (vector (cdr _%clause27056%_)
                                             _%index27049%_)
                                     _%limits27054%_))
                                  (if (eq? 'limits _%$e27059%_)
                                      (begin
                                        (if _%limits27054%_
                                            (gerbil-ascent/candidate/program#reject
                                             'duplicate-limits
                                             _%path27057%_
                                             _%clause27056%_)
                                            '#!void)
                                        (if (and (= (length _%clause27056%_)
                                                    '4)
                                                 (let ((__tmp36400
                                                        (lambda (_%value27064%_)
                                                          (and (exact-integer?
                                                                _%value27064%_)
                                                               (> _%value27064%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          '0))))
               (__tmp36399 (cdr _%clause27056%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (declare (not safe))
                                                   (andmap__0
                                                    __tmp36400
                                                    __tmp36399))
                                                 (<= (cadr _%clause27056%_)
                                                     gerbil-ascent/candidate/types#+max-input-facts+)
                                                 (<= (caddr _%clause27056%_)
                                                     gerbil-ascent/candidate/types#+max-derived-facts+)
                                                 (<= (cadddr _%clause27056%_)
                                                     gerbil-ascent/candidate/types#+max-output-facts+))
                                            '#!void
                                            (gerbil-ascent/candidate/program#reject
                                             'invalid-limits
                                             _%path27057%_
                                             _%clause27056%_))
                                        (_%loop27046%_
                                         (cdr _%clauses27048%_)
                                         (+ _%index27049%_ '1)
                                         _%relations27050%_
                                         _%facts27051%_
                                         _%rules27052%_
                                         _%query27053%_
                                         (cdr _%clause27056%_)))
                                      (gerbil-ascent/candidate/program#reject
                                       'unsupported-construct
                                       _%path27057%_
                                       (car _%clause27056%_)))))))))))))
    (define gerbil-ascent/candidate/program#candidate-declaration::t
      (let ((__tmp36402 (list)) (__tmp36401 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/program#candidate-declaration::t
         'candidate-declaration
         __tmp36402
         '(arity source?)
         __tmp36401
         '#f)))
    (define gerbil-ascent/candidate/program#candidate-declaration?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/program#candidate-declaration::t)))
    (define gerbil-ascent/candidate/program#make-candidate-declaration
      (lambda _%$args27041%_
        (apply make-instance
               gerbil-ascent/candidate/program#candidate-declaration::t
               _%$args27041%_)))
    (define gerbil-ascent/candidate/program#candidate-declaration-arity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/program#candidate-declaration::t
         'arity)))
    (define gerbil-ascent/candidate/program#candidate-declaration-source?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/program#candidate-declaration::t
         'source?)))
    (define gerbil-ascent/candidate/program#candidate-declaration-arity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/program#candidate-declaration::t
         'arity)))
    (define gerbil-ascent/candidate/program#candidate-declaration-source?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/program#candidate-declaration::t
         'source?)))
    (define gerbil-ascent/candidate/program#&candidate-declaration-arity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/program#candidate-declaration::t
         'arity)))
    (define gerbil-ascent/candidate/program#&candidate-declaration-source?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/program#candidate-declaration::t
         'source?)))
    (define gerbil-ascent/candidate/program#&candidate-declaration-arity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/program#candidate-declaration::t
         'arity)))
    (define gerbil-ascent/candidate/program#&candidate-declaration-source?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/program#candidate-declaration::t
         'source?)))
    (define gerbil-ascent/candidate/program#candidate-schema
      (lambda (_%source27032%_ _%derived27033%_)
        (let ((_%schema27035%_
               (let () (declare (not safe)) (make-hash-table-eq))))
          (for-each
           (lambda (_%entry27037%_)
             (if (let ((__tmp36403 (car _%entry27037%_)))
                   (declare (not safe))
                   (__hash-get _%schema27035%_ __tmp36403))
                 '#!void
                 (let ((__tmp36406 (car _%entry27037%_))
                       (__tmp36404
                        (let ((__tmp36405 (cadr _%entry27037%_)))
                          (declare (not safe))
                          (##structure
                           gerbil-ascent/candidate/program#candidate-declaration::t
                           __tmp36405
                           '#t))))
                   (declare (not safe))
                   (__hash-put! _%schema27035%_ __tmp36406 __tmp36404))))
           _%source27032%_)
          (for-each
           (lambda (_%entry27039%_)
             (if (let ((__tmp36407 (car _%entry27039%_)))
                   (declare (not safe))
                   (__hash-get _%schema27035%_ __tmp36407))
                 (gerbil-ascent/candidate/program#reject
                  'duplicate-relation
                  '(relations)
                  (car _%entry27039%_))
                 '#!void)
             (let ((__tmp36410 (car _%entry27039%_))
                   (__tmp36408
                    (let ((__tmp36409 (cdr _%entry27039%_)))
                      (declare (not safe))
                      (##structure
                       gerbil-ascent/candidate/program#candidate-declaration::t
                       __tmp36409
                       '#f))))
               (declare (not safe))
               (__hash-put! _%schema27035%_ __tmp36410 __tmp36408)))
           _%derived27033%_)
          _%schema27035%_)))
    (define gerbil-ascent/candidate/program#candidate-bind!
      (lambda (_%bound27029%_ _%term27030%_)
        (if (gerbil-ascent/candidate/program#logic-variable? _%term27030%_)
            (let ()
              (declare (not safe))
              (hash-put! _%bound27029%_ _%term27030%_ '#t))
            '#!void)
        _%bound27029%_))
    (define gerbil-ascent/candidate/program#atom-check
      (lambda (_%atom27020%_ _%schema27021%_ _%path27022%_)
        (if (and (list? _%atom27020%_)
                 (pair? _%atom27020%_)
                 (symbol? (let () (declare (not safe)) (##car _%atom27020%_))))
            '#!void
            (gerbil-ascent/candidate/program#reject
             'invalid-atom
             _%path27022%_
             _%atom27020%_))
        (let ((_%declaration27024%_
               (let ((__tmp36411 (car _%atom27020%_)))
                 (declare (not safe))
                 (hash-get _%schema27021%_ __tmp36411))))
          (if _%declaration27024%_
              '#!void
              (gerbil-ascent/candidate/program#reject
               'unknown-relation
               _%path27022%_
               (car _%atom27020%_)))
          (if (= (length (cdr _%atom27020%_))
                 (##structure-ref
                  _%declaration27024%_
                  '1
                  gerbil-ascent/candidate/program#candidate-declaration::t
                  '#f))
              '#!void
              (gerbil-ascent/candidate/program#reject
               'arity-mismatch
               _%path27022%_
               (car _%atom27020%_)))
          (for-each
           (lambda (_%term27026%_ _%position27027%_)
             (if (gerbil-ascent/candidate/program#candidate-term?
                  _%term27026%_)
                 '#!void
                 (gerbil-ascent/candidate/program#reject
                  'invalid-term
                  (let ((__tmp36412 (list 'term _%position27027%_)))
                    (declare (not safe))
                    (##append _%path27022%_ __tmp36412))
                  _%term27026%_)))
           (cdr _%atom27020%_)
           (let ((__tmp36413 (length (cdr _%atom27020%_))))
             (declare (not safe))
             (##iota __tmp36413 '1))))))
    (define gerbil-ascent/candidate/program#logic-variable?
      (lambda (_%value27018%_)
        (if (gerbil-ascent/candidate/program#candidate-variable?
             _%value27018%_)
            (not (eq? _%value27018%_ '?_))
            '#f)))
    (define gerbil-ascent/candidate/program#require-bound-inputs
      (lambda (_%inputs27011%_ _%bound27012%_ _%path27013%_)
        (for-each
         (lambda (_%input27015%_ _%position27016%_)
           (if (and (gerbil-ascent/candidate/program#logic-variable?
                     _%input27015%_)
                    (let ()
                      (declare (not safe))
                      (hash-get _%bound27012%_ _%input27015%_)))
               '#!void
               (gerbil-ascent/candidate/program#reject
                'unbound-operator-input
                (let ((__tmp36414 (list 'input _%position27016%_)))
                  (declare (not safe))
                  (##append _%path27013%_ __tmp36414))
                _%input27015%_)))
         _%inputs27011%_
         (let ((__tmp36415 (length _%inputs27011%_)))
           (declare (not safe))
           (##iota __tmp36415 '1)))))
    (define gerbil-ascent/candidate/program#+candidate-reducer-specs+
      '((count 0) (sum 1) (min 1) (max 1)))
    (define gerbil-ascent/candidate/program#+candidate-operator-specs+
      '((where (even? 1) (< 2)) (compute (identity 1) (+ 2))))
    (define gerbil-ascent/candidate/program#candidate-language-description
      (lambda ()
        (let ((__tmp36416
               (list 'candidate-language
                     'v1
                     '(forms (relation NAME ARITY)
                             (fact SOURCE TERM ...)
                             (rule HEAD BODY ...)
                             (query RELATION TERM ...)
                             (limits INPUT DERIVED OUTPUT))
                     '(body (RELATION TERM ...)
                            (not (RELATION TERM ...))
                            (where (OP INPUT ...))
                            (compute OUTPUT (OP INPUT ...))
                            (reduce OUTPUT
                                    (MODE INPUT ...)
                                    (RELATION TERM ...)))
                     (cons 'operators
                           gerbil-ascent/candidate/program#+candidate-operator-specs+)
                     (cons 'reducers
                           gerbil-ascent/candidate/program#+candidate-reducer-specs+)
                     '(binding positive-atoms-bind
                               negation-and-operators-read-bound
                               compute-and-reduce-bind-fresh)
                     '(operator-inputs bound-variables-only)
                     '(diagnostic-index-base 1)
                     '(scope syntax-description-not-source-authority-or-task-intent))))
          (declare (not safe))
          (gerbil-ascent/candidate/datum#candidate-copy-pairs __tmp36416))))
    (define gerbil-ascent/candidate/program#checked-operation
      (lambda (_%form26997%_ _%mode26998%_ _%bound26999%_ _%path27000%_)
        (if (and (list? _%form26997%_)
                 (pair? _%form26997%_)
                 (symbol? (let () (declare (not safe)) (##car _%form26997%_))))
            '#!void
            (gerbil-ascent/candidate/program#reject
             'invalid-operator
             _%path27000%_
             _%form26997%_))
        (let ((_%operation27002%_ (car _%form26997%_))
              (_%inputs27003%_ (cdr _%form26997%_)))
          (let* ((_%tier27005%_
                  (assq _%mode26998%_
                        gerbil-ascent/candidate/program#+candidate-operator-specs+))
                 (_%spec27007%_
                  (if _%tier27005%_
                      (assq _%operation27002%_ (cdr _%tier27005%_))
                      '#f)))
            (if (and _%spec27007%_
                     (= (length _%inputs27003%_) (cadr _%spec27007%_)))
                '#!void
                (gerbil-ascent/candidate/program#reject
                 'unsupported-operator
                 _%path27000%_
                 _%form26997%_)))
          (gerbil-ascent/candidate/program#require-bound-inputs
           _%inputs27003%_
           _%bound26999%_
           _%path27000%_))))
    (define gerbil-ascent/candidate/program#candidate-check-body-clause
      (lambda (_%clause26969%_ _%schema26970%_ _%bound26971%_ _%path26972%_)
        (if (and (list? _%clause26969%_)
                 (pair? _%clause26969%_)
                 (symbol? (let ()
                            (declare (not safe))
                            (##car _%clause26969%_))))
            '#!void
            (gerbil-ascent/candidate/program#reject
             'invalid-body-clause
             _%path26972%_
             _%clause26969%_))
        (let ((_%$e26974%_ (car _%clause26969%_)))
          (if (eq? 'not _%$e26974%_)
              (begin
                (if (= (length _%clause26969%_) '2)
                    '#!void
                    (gerbil-ascent/candidate/program#reject
                     'invalid-negation
                     _%path26972%_
                     _%clause26969%_))
                (let ((_%atom26977%_ (cadr _%clause26969%_)))
                  (gerbil-ascent/candidate/program#atom-check
                   _%atom26977%_
                   _%schema26970%_
                   _%path26972%_)
                  (for-each
                   (lambda (_%term26979%_ _%position26980%_)
                     (if (and (gerbil-ascent/candidate/program#logic-variable?
                               _%term26979%_)
                              (not (let ()
                                     (declare (not safe))
                                     (hash-get _%bound26971%_ _%term26979%_))))
                         (gerbil-ascent/candidate/program#reject
                          'unsafe-negation
                          (let ((__tmp36417 (list 'term _%position26980%_)))
                            (declare (not safe))
                            (##append _%path26972%_ __tmp36417))
                          _%term26979%_)
                         '#!void))
                   (cdr _%atom26977%_)
                   (let ((__tmp36418 (length (cdr _%atom26977%_))))
                     (declare (not safe))
                     (##iota __tmp36418 '1))))
                _%bound26971%_)
              (if (eq? 'where _%$e26974%_)
                  (begin
                    (if (= (length _%clause26969%_) '2)
                        '#!void
                        (gerbil-ascent/candidate/program#reject
                         'invalid-filter
                         _%path26972%_
                         _%clause26969%_))
                    (gerbil-ascent/candidate/program#checked-operation
                     (cadr _%clause26969%_)
                     'where
                     _%bound26971%_
                     _%path26972%_)
                    _%bound26971%_)
                  (if (eq? 'compute _%$e26974%_)
                      (begin
                        (if (and (= (length _%clause26969%_) '3)
                                 (gerbil-ascent/candidate/program#logic-variable?
                                  (cadr _%clause26969%_)))
                            '#!void
                            (gerbil-ascent/candidate/program#reject
                             'invalid-computation
                             _%path26972%_
                             _%clause26969%_))
                        (if (let ((__tmp36419 (cadr _%clause26969%_)))
                              (declare (not safe))
                              (hash-get _%bound26971%_ __tmp36419))
                            (gerbil-ascent/candidate/program#reject
                             'duplicate-binding
                             _%path26972%_
                             (cadr _%clause26969%_))
                            '#!void)
                        (gerbil-ascent/candidate/program#checked-operation
                         (caddr _%clause26969%_)
                         'compute
                         _%bound26971%_
                         _%path26972%_)
                        (gerbil-ascent/candidate/program#candidate-bind!
                         _%bound26971%_
                         (cadr _%clause26969%_)))
                      (if (eq? 'reduce _%$e26974%_)
                          (begin
                            (if (and (= (length _%clause26969%_) '4)
                                     (gerbil-ascent/candidate/program#logic-variable?
                                      (cadr _%clause26969%_))
                                     (list? (caddr _%clause26969%_))
                                     (pair? (caddr _%clause26969%_)))
                                '#!void
                                (gerbil-ascent/candidate/program#reject
                                 'invalid-reduction
                                 _%path26972%_
                                 _%clause26969%_))
                            (if (let ((__tmp36420 (cadr _%clause26969%_)))
                                  (declare (not safe))
                                  (hash-get _%bound26971%_ __tmp36420))
                                (gerbil-ascent/candidate/program#reject
                                 'duplicate-binding
                                 _%path26972%_
                                 (cadr _%clause26969%_))
                                '#!void)
                            (let* ((_%mode26982%_ (caaddr _%clause26969%_))
                                   (_%inputs26984%_ (cdaddr _%clause26969%_))
                                   (_%atom26986%_ (cadddr _%clause26969%_)))
                              (if (and (symbol? _%mode26982%_)
                                       (let ((_%spec26989%_
                                              (assq _%mode26982%_
                                                    gerbil-ascent/candidate/program#+candidate-reducer-specs+)))
                                         (and _%spec26989%_
                                              (= (length _%inputs26984%_)
                                                 (cadr _%spec26989%_))))
                                       (let ()
                                         (declare (not safe))
                                         (andmap__0
                                          gerbil-ascent/candidate/program#logic-variable?
                                          _%inputs26984%_)))
                                  '#!void
                                  (gerbil-ascent/candidate/program#reject
                                   'unsupported-reduction
                                   _%path26972%_
                                   (caddr _%clause26969%_)))
                              (gerbil-ascent/candidate/program#atom-check
                               _%atom26986%_
                               _%schema26970%_
                               (let ()
                                 (declare (not safe))
                                 (##append _%path26972%_ '(aggregate))))
                              (for-each
                               (lambda (_%input26991%_)
                                 (if (memq _%input26991%_ (cdr _%atom26986%_))
                                     '#!void
                                     (gerbil-ascent/candidate/program#reject
                                      'reduction-input-absent
                                      _%path26972%_
                                      _%input26991%_)))
                               _%inputs26984%_))
                            (gerbil-ascent/candidate/program#candidate-bind!
                             _%bound26971%_
                             (cadr _%clause26969%_)))
                          (begin
                            (gerbil-ascent/candidate/program#atom-check
                             _%clause26969%_
                             _%schema26970%_
                             _%path26972%_)
                            (for-each
                             (lambda (_%$%g2699226994%_)
                               (gerbil-ascent/candidate/program#candidate-bind!
                                _%bound26971%_
                                _%$%g2699226994%_))
                             (cdr _%clause26969%_))
                            _%bound26971%_))))))))
    (define gerbil-ascent/candidate/program#candidate-inspect
      (lambda (_%snapshot26920%_ _%candidate26921%_)
        (let* ((_%spec26923%_
                (gerbil-ascent/candidate/program#candidate-parse
                 _%candidate26921%_))
               (_%source26925%_
                (##structure-ref
                 _%snapshot26920%_
                 '4
                 gerbil-ascent/candidate/types#reasoning-snapshot::t
                 '#f))
               (_%derived26927%_
                (##structure-ref
                 _%spec26923%_
                 '1
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f))
               (_%schema26929%_
                (gerbil-ascent/candidate/program#candidate-schema
                 _%source26925%_
                 _%derived26927%_)))
          (for-each
           (lambda (_%fact26932%_)
             (let ((_%name26934%_ (vector-ref _%fact26932%_ '0))
                   (_%row26935%_ (vector-ref _%fact26932%_ '1))
                   (_%path26936%_
                    (list 'clause (vector-ref _%fact26932%_ '2))))
               (let ((_%declaration26938%_
                      (let ()
                        (declare (not safe))
                        (__hash-get _%schema26929%_ _%name26934%_))))
                 (if (and _%declaration26938%_
                          (##structure-ref
                           _%declaration26938%_
                           '2
                           gerbil-ascent/candidate/program#candidate-declaration::t
                           '#f))
                     '#!void
                     (gerbil-ascent/candidate/program#reject
                      'fact-needs-source
                      _%path26936%_
                      _%name26934%_))
                 (if (= (length _%row26935%_)
                        (##structure-ref
                         _%declaration26938%_
                         '1
                         gerbil-ascent/candidate/program#candidate-declaration::t
                         '#f))
                     '#!void
                     (gerbil-ascent/candidate/program#reject
                      'arity-mismatch
                      _%path26936%_
                      _%name26934%_)))))
           (##structure-ref
            _%spec26923%_
            '2
            gerbil-ascent/candidate/types#reasoning-candidate::t
            '#f))
          (for-each
           (lambda (_%rule26940%_)
             (let* ((_%head26942%_ (vector-ref _%rule26940%_ '0))
                    (_%body26944%_ (vector-ref _%rule26940%_ '1))
                    (_%path26946%_
                     (list 'clause (vector-ref _%rule26940%_ '2)))
                    (_%bound26948%_
                     (let () (declare (not safe)) (make-hash-table-eq))))
               (gerbil-ascent/candidate/program#atom-check
                _%head26942%_
                _%schema26929%_
                (let () (declare (not safe)) (##append _%path26946%_ '(head))))
               (if (##structure-ref
                    (let ((__tmp36421 (car _%head26942%_)))
                      (declare (not safe))
                      (hash-ref__0 _%schema26929%_ __tmp36421))
                    '2
                    gerbil-ascent/candidate/program#candidate-declaration::t
                    '#f)
                   (gerbil-ascent/candidate/program#reject
                    'rule-writes-source
                    (let ()
                      (declare (not safe))
                      (##append _%path26946%_ '(head)))
                    (car _%head26942%_))
                   '#!void)
               (for-each
                (lambda (_%clause26951%_ _%position26952%_)
                  (set! _%bound26948%_
                        (gerbil-ascent/candidate/program#candidate-check-body-clause
                         _%clause26951%_
                         _%schema26929%_
                         _%bound26948%_
                         (let ((__tmp36422 (list 'body _%position26952%_)))
                           (declare (not safe))
                           (##append _%path26946%_ __tmp36422)))))
                _%body26944%_
                (let ((__tmp36423 (length _%body26944%_)))
                  (declare (not safe))
                  (##iota __tmp36423 '1)))
               (for-each
                (lambda (_%term26954%_ _%position26955%_)
                  (if (eq? _%term26954%_ '?_)
                      (gerbil-ascent/candidate/program#reject
                       'wildcard-head
                       (let ((__tmp36424 (list 'head 'term _%position26955%_)))
                         (declare (not safe))
                         (##append _%path26946%_ __tmp36424))
                       _%term26954%_)
                      (if (and (gerbil-ascent/candidate/program#candidate-variable?
                                _%term26954%_)
                               (not (let ()
                                      (declare (not safe))
                                      (hash-get
                                       _%bound26948%_
                                       _%term26954%_))))
                          (gerbil-ascent/candidate/program#reject
                           'unbound-head-variable
                           (let ((__tmp36425
                                  (list 'head 'term _%position26955%_)))
                             (declare (not safe))
                             (##append _%path26946%_ __tmp36425))
                           _%term26954%_)
                          '#!void)))
                (cdr _%head26942%_)
                (let ((__tmp36426 (length (cdr _%head26942%_))))
                  (declare (not safe))
                  (##iota __tmp36426 '1)))))
           (##structure-ref
            _%spec26923%_
            '3
            gerbil-ascent/candidate/types#reasoning-candidate::t
            '#f))
          (let* ((_%query26959%_
                  (vector-ref
                   (##structure-ref
                    _%spec26923%_
                    '4
                    gerbil-ascent/candidate/types#reasoning-candidate::t
                    '#f)
                   '0))
                 (_%path26961%_
                  (list 'clause
                        (vector-ref
                         (##structure-ref
                          _%spec26923%_
                          '4
                          gerbil-ascent/candidate/types#reasoning-candidate::t
                          '#f)
                         '1))))
            (gerbil-ascent/candidate/program#atom-check
             _%query26959%_
             _%schema26929%_
             _%path26961%_))
          (let ((_%source-count26966%_
                 (let ((__tmp36427
                        (map (lambda (_%entry26964%_)
                               (length (caddr _%entry26964%_)))
                             _%source26925%_)))
                   (declare (not safe))
                   (##apply + __tmp36427)))
                (_%candidate-count26967%_
                 (length (##structure-ref
                          _%spec26923%_
                          '2
                          gerbil-ascent/candidate/types#reasoning-candidate::t
                          '#f))))
            (if (> (+ _%source-count26966%_ _%candidate-count26967%_)
                   (car (##structure-ref
                         _%spec26923%_
                         '5
                         gerbil-ascent/candidate/types#reasoning-candidate::t
                         '#f)))
                (gerbil-ascent/candidate/program#reject
                 'input-budget
                 '(limits input)
                 (+ _%source-count26966%_ _%candidate-count26967%_))
                '#!void))
          _%spec26923%_)))
    (define gerbil-ascent/candidate/program#candidate-term->object
      (lambda (_%term26915%_)
        (if (eq? _%term26915%_ '?_)
            (let ()
              (declare (not safe))
              (gerbil-ascent/program/objects#gerbil-ascent-wildcard))
            (if (gerbil-ascent/candidate/program#candidate-variable?
                 _%term26915%_)
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/program/objects#gerbil-ascent-variable
                   _%term26915%_))
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/program/objects#gerbil-ascent-literal
                   _%term26915%_))))))
    (define gerbil-ascent/candidate/program#candidate-atom->object
      (lambda (_%atom26913%_)
        (let ((__tmp36429 (car _%atom26913%_))
              (__tmp36428
               (map gerbil-ascent/candidate/program#candidate-term->object
                    (cdr _%atom26913%_))))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-atom
           __tmp36429
           __tmp36428))))
    (define gerbil-ascent/candidate/program#candidate-body->object
      (lambda (_%clause26903%_)
        (let ((_%$e26905%_ (car _%clause26903%_)))
          (if (eq? 'not _%$e26905%_)
              (let ((_%atom26908%_ (cadr _%clause26903%_)))
                (let ((__tmp36431 (car _%atom26908%_))
                      (__tmp36430
                       (map gerbil-ascent/candidate/program#candidate-term->object
                            (cdr _%atom26908%_))))
                  (declare (not safe))
                  (gerbil-ascent/program/objects#gerbil-ascent-negation
                   __tmp36431
                   __tmp36430)))
              (if (eq? 'where _%$e26905%_)
                  (let ((__tmp36433 (caadr _%clause26903%_))
                        (__tmp36432 (cdadr _%clause26903%_)))
                    (declare (not safe))
                    (gerbil-ascent/program/scheme-checked#relational-where
                     __tmp36433
                     __tmp36432))
                  (if (eq? 'compute _%$e26905%_)
                      (let ((__tmp36436 (cadr _%clause26903%_))
                            (__tmp36435 (caaddr _%clause26903%_))
                            (__tmp36434 (cdaddr _%clause26903%_)))
                        (declare (not safe))
                        (gerbil-ascent/program/scheme-checked#relational-compute
                         __tmp36436
                         __tmp36435
                         __tmp36434))
                      (if (eq? 'reduce _%$e26905%_)
                          (let ((_%operator26910%_ (caddr _%clause26903%_))
                                (_%atom26911%_ (cadddr _%clause26903%_)))
                            (let ((__tmp36441 (cadr _%clause26903%_))
                                  (__tmp36440 (car _%operator26910%_))
                                  (__tmp36439 (cdr _%operator26910%_))
                                  (__tmp36438 (car _%atom26911%_))
                                  (__tmp36437
                                   (map gerbil-ascent/candidate/program#candidate-term->object
                                        (cdr _%atom26911%_))))
                              (declare (not safe))
                              (gerbil-ascent/program/scheme-checked#relational-reducer
                               __tmp36441
                               __tmp36440
                               __tmp36439
                               __tmp36438
                               __tmp36437)))
                          (gerbil-ascent/candidate/program#candidate-atom->object
                           _%clause26903%_))))))))
    (define gerbil-ascent/candidate/program#candidate-fact-partition
      (lambda (_%facts26865%_)
        (if (pair? _%facts26865%_)
            (let ((_%groups26867%_
                   (let () (declare (not safe)) (make-hash-table-eq))))
              (let ((__tmp36442
                     (lambda (_%fact26869%_)
                       (let* ((_%$%fact2687026878%_ _%fact26869%_)
                              (_%$%E2687226881%_
                               (lambda ()
                                 (let ()
                                   (declare (not safe))
                                   (error '"No clause matching"
                                          _%$%fact2687026878%_
                                          '((vector name row _))))
                                 '#!void))
                              (_%$%K2687326887%_
                               (lambda (_%row26884%_ _%name26885%_)
                                 (let ((__tmp36443
                                        (cons _%row26884%_
                                              (let ()
                                                (declare (not safe))
                                                (__hash-ref__%
                                                 _%groups26867%_
                                                 _%name26885%_
                                                 '())))))
                                   (declare (not safe))
                                   (__hash-put!
                                    _%groups26867%_
                                    _%name26885%_
                                    __tmp36443)))))
                         (if (vector? _%$%fact2687026878%_)
                             (if (let ((__tmp36444
                                        (let ()
                                          (declare (not safe))
                                          (##vector-length
                                           _%$%fact2687026878%_))))
                                   (declare (not safe))
                                   (##fx= __tmp36444 '3))
                                 (let* ((_%$%e2687426890%_
                                         (let ()
                                           (declare (not safe))
                                           (##vector-ref
                                            _%$%fact2687026878%_
                                            '0)))
                                        (_%name26893%_ _%$%e2687426890%_)
                                        (_%$%e2687526895%_
                                         (let ()
                                           (declare (not safe))
                                           (##vector-ref
                                            _%$%fact2687026878%_
                                            '1)))
                                        (_%row26898%_ _%$%e2687526895%_)
                                        (_%$%e2687626900%_
                                         (let ()
                                           (declare (not safe))
                                           (##vector-ref
                                            _%$%fact2687026878%_
                                            '2))))
                                   (_%$%K2687326887%_
                                    _%row26898%_
                                    _%name26893%_))
                                 (_%$%E2687226881%_))
                             (_%$%E2687226881%_))))))
                (declare (not safe))
                (##for-each __tmp36442 _%facts26865%_))
              _%groups26867%_)
            '#f)))
    (define gerbil-ascent/candidate/program#candidate-program
      (lambda (_%snapshot26861%_ _%spec26862%_)
        (let ((__tmp36445
               (lambda ()
                 (gerbil-ascent/candidate/program#candidate-lower-program
                  _%snapshot26861%_
                  _%spec26862%_))))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-construct-inert-program
           __tmp36445))))
    (define gerbil-ascent/candidate/program#candidate-lower-program
      (lambda (_%snapshot26833%_ _%spec26834%_)
        (let* ((_%source26836%_
                (##structure-ref
                 _%snapshot26833%_
                 '4
                 gerbil-ascent/candidate/types#reasoning-snapshot::t
                 '#f))
               (_%facts26838%_
                (gerbil-ascent/candidate/program#candidate-fact-partition
                 (##structure-ref
                  _%spec26834%_
                  '2
                  gerbil-ascent/candidate/types#reasoning-candidate::t
                  '#f)))
               (_%derived26840%_
                (##structure-ref
                 _%spec26834%_
                 '1
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f))
               (_%source-relations26846%_
                (map (lambda (_%entry26842%_)
                       (let ((_%name26844%_ (car _%entry26842%_)))
                         (let ((__tmp36449 (cadr _%entry26842%_))
                               (__tmp36446
                                (let ((__tmp36448 (caddr _%entry26842%_))
                                      (__tmp36447
                                       (if _%facts26838%_
                                           (reverse (let ()
                                                      (declare (not safe))
                                                      (__hash-ref__%
                                                       _%facts26838%_
                                                       _%name26844%_
                                                       '())))
                                           '())))
                                  (declare (not safe))
                                  (##append __tmp36448 __tmp36447))))
                           (declare (not safe))
                           (gerbil-ascent/program/objects#gerbil-ascent-relation__0
                            _%name26844%_
                            __tmp36449
                            __tmp36446))))
                     _%source26836%_))
               (_%derived-relations26850%_
                (map (lambda (_%entry26848%_)
                       (let ((__tmp36451 (car _%entry26848%_))
                             (__tmp36450 (cdr _%entry26848%_)))
                         (declare (not safe))
                         (gerbil-ascent/program/objects#gerbil-ascent-relation__0
                          __tmp36451
                          __tmp36450
                          '())))
                     _%derived26840%_))
               (_%relations26852%_
                (let ()
                  (declare (not safe))
                  (##append
                   _%source-relations26846%_
                   _%derived-relations26850%_)))
               (_%rules26856%_
                (map (lambda (_%rule26854%_)
                       (let ((__tmp36453
                              (list (gerbil-ascent/candidate/program#candidate-atom->object
                                     (vector-ref _%rule26854%_ '0))))
                             (__tmp36452
                              (map gerbil-ascent/candidate/program#candidate-body->object
                                   (vector-ref _%rule26854%_ '1))))
                         (declare (not safe))
                         (gerbil-ascent/program/objects#gerbil-ascent-rule
                          __tmp36453
                          __tmp36452)))
                     (##structure-ref
                      _%spec26834%_
                      '3
                      gerbil-ascent/candidate/types#reasoning-candidate::t
                      '#f)))
               (_%limits26858%_
                (##structure-ref
                 _%spec26834%_
                 '5
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f)))
          (let ((__tmp36457 (car _%limits26858%_))
                (__tmp36456 (cadr _%limits26858%_))
                (__tmp36455 (caddr _%limits26858%_))
                (__tmp36454 (map car _%source26836%_)))
            (declare (not safe))
            (gerbil-ascent/program/objects#gerbil-ascent-program__%
             _%relations26852%_
             _%rules26856%_
             __tmp36457
             __tmp36456
             __tmp36455
             __tmp36454)))))
    (define gerbil-ascent/candidate/program#candidate-planner-path
      (lambda (_%spec26830%_ _%path26831%_)
        (if (and (list? _%path26831%_)
                 (= (let () (declare (not safe)) (##length _%path26831%_)) '4)
                 (eq? (car _%path26831%_) 'rule)
                 (exact-integer? (cadr _%path26831%_))
                 (<= '0 (cadr _%path26831%_))
                 (< (cadr _%path26831%_)
                    (length (##structure-ref
                             _%spec26830%_
                             '3
                             gerbil-ascent/candidate/types#reasoning-candidate::t
                             '#f)))
                 (let ((__tmp36458 (caddr _%path26831%_)))
                   (declare (not safe))
                   (##memq __tmp36458 '(body head)))
                 (exact-integer? (cadddr _%path26831%_)))
            (list 'clause
                  (vector-ref
                   (list-ref
                    (##structure-ref
                     _%spec26830%_
                     '3
                     gerbil-ascent/candidate/types#reasoning-candidate::t
                     '#f)
                    (cadr _%path26831%_))
                   '2)
                  (caddr _%path26831%_)
                  (+ '1 (cadddr _%path26831%_)))
            _%path26831%_)))))
