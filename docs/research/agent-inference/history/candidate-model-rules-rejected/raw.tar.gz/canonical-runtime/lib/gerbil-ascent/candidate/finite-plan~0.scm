(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/finite-plan::timestamp 1791687887)
  (begin
    (define gerbil-ascent/candidate/finite-plan#finite-rule::t
      (let ((__tmp37176 (list))
            (__tmp37175
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/finite-plan#finite-rule::t
         'finite-rule
         __tmp37176
         '(relation head body level)
         __tmp37175
         '#f)))
    (define gerbil-ascent/candidate/finite-plan#finite-rule?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/finite-plan#finite-rule::t)))
    (define gerbil-ascent/candidate/finite-plan#make-finite-rule
      (lambda _%$args27692%_
        (apply make-instance
               gerbil-ascent/candidate/finite-plan#finite-rule::t
               _%$args27692%_)))
    (define gerbil-ascent/candidate/finite-plan#finite-rule-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'relation)))
    (define gerbil-ascent/candidate/finite-plan#finite-rule-head
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'head)))
    (define gerbil-ascent/candidate/finite-plan#finite-rule-body
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'body)))
    (define gerbil-ascent/candidate/finite-plan#finite-rule-level
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'level)))
    (define gerbil-ascent/candidate/finite-plan#finite-rule-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'relation)))
    (define gerbil-ascent/candidate/finite-plan#finite-rule-head-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'head)))
    (define gerbil-ascent/candidate/finite-plan#finite-rule-body-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'body)))
    (define gerbil-ascent/candidate/finite-plan#finite-rule-level-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'level)))
    (define gerbil-ascent/candidate/finite-plan#&finite-rule-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'relation)))
    (define gerbil-ascent/candidate/finite-plan#&finite-rule-head
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'head)))
    (define gerbil-ascent/candidate/finite-plan#&finite-rule-body
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'body)))
    (define gerbil-ascent/candidate/finite-plan#&finite-rule-level
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'level)))
    (define gerbil-ascent/candidate/finite-plan#&finite-rule-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'relation)))
    (define gerbil-ascent/candidate/finite-plan#&finite-rule-head-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'head)))
    (define gerbil-ascent/candidate/finite-plan#&finite-rule-body-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'body)))
    (define gerbil-ascent/candidate/finite-plan#&finite-rule-level-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-plan#finite-rule::t
         'level)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause::t
      (let ((__tmp37178 (list))
            (__tmp37177
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/finite-plan#finite-clause::t
         'finite-clause
         __tmp37178
         '(kind relation apply output operator)
         __tmp37177
         '#f)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/finite-plan#finite-clause::t)))
    (define gerbil-ascent/candidate/finite-plan#make-finite-clause
      (lambda _%$args27689%_
        (apply make-instance
               gerbil-ascent/candidate/finite-plan#finite-clause::t
               _%$args27689%_)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'kind)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'relation)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-apply
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'apply)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-output
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'output)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-operator
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'operator)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'kind)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'relation)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-apply-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'apply)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-output-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'output)))
    (define gerbil-ascent/candidate/finite-plan#finite-clause-operator-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'operator)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'kind)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'relation)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-apply
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'apply)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-output
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'output)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-operator
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'operator)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'kind)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'relation)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-apply-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'apply)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-output-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'output)))
    (define gerbil-ascent/candidate/finite-plan#&finite-clause-operator-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/finite-plan#finite-clause::t
         'operator)))
    (define gerbil-ascent/candidate/finite-plan#prepare-finite-rule
      (lambda (_%rule27641%_ _%resolve27642%_ _%levels27643%_)
        (let* ((_%$%rule2764427652%_ _%rule27641%_)
               (_%$%E2764627655%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%rule2764427652%_
                           '(#(head body _))))
                  '#!void))
               (_%$%K2764727673%_
                (lambda (_%body27658%_ _%head27659%_)
                  (let ((__tmp37192 (_%resolve27642%_ (car _%head27659%_)))
                        (__tmp37191
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/grounding-plan#prepare-grounding-head
                            _%head27659%_)))
                        (__tmp37181
                         (map (lambda (_%clause27661%_)
                                (let ((_%$e27663%_ (car _%clause27661%_)))
                                  (if (or (eq? 'where _%$e27663%_)
                                          (eq? 'compute _%$e27663%_))
                                      (let ((__tmp37182
                                             (let ()
                                               (declare (not safe))
                                               (gerbil-ascent/candidate/grounding-plan#prepare-grounding-fixed
                                                _%clause27661%_))))
                                        (declare (not safe))
                                        (##structure
                                         gerbil-ascent/candidate/finite-plan#finite-clause::t
                                         'fixed
                                         '#f
                                         __tmp37182
                                         '#f
                                         '#f))
                                      (if (eq? 'not _%$e27663%_)
                                          (let ((_%atom27669%_
                                                 (cadr _%clause27661%_)))
                                            (let ((__tmp37184
                                                   (_%resolve27642%_
                                                    (car _%atom27669%_)))
                                                  (__tmp37183
                                                   (let ()
                                                     (declare (not safe))
                                                     (gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
                                                      _%atom27669%_))))
                                              (declare (not safe))
                                              (##structure
                                               gerbil-ascent/candidate/finite-plan#finite-clause::t
                                               'not
                                               __tmp37184
                                               __tmp37183
                                               '#f
                                               '#f)))
                                          (if (eq? 'reduce _%$e27663%_)
                                              (let ((_%atom27671%_
                                                     (cadddr _%clause27661%_)))
                                                (let ((__tmp37188
                                                       (_%resolve27642%_
                                                        (car _%atom27671%_)))
                                                      (__tmp37187
                                                       (let ()
                                                         (declare (not safe))
                                                         (gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
                                                          _%atom27671%_)))
                                                      (__tmp37186
                                                       (cadr _%clause27661%_))
                                                      (__tmp37185
                                                       (caddr _%clause27661%_)))
                                                  (declare (not safe))
                                                  (##structure
                                                   gerbil-ascent/candidate/finite-plan#finite-clause::t
                                                   'reduce
                                                   __tmp37188
                                                   __tmp37187
                                                   __tmp37186
                                                   __tmp37185)))
                                              (let ((__tmp37190
                                                     (_%resolve27642%_
                                                      (car _%clause27661%_)))
                                                    (__tmp37189
                                                     (let ()
                                                       (declare (not safe))
                                                       (gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
                                                        _%clause27661%_))))
                                                (declare (not safe))
                                                (##structure
                                                 gerbil-ascent/candidate/finite-plan#finite-clause::t
                                                 'atom
                                                 __tmp37190
                                                 __tmp37189
                                                 '#f
                                                 '#f)))))))
                              _%body27658%_))
                        (__tmp37179
                         (cdr (let ((__tmp37180 (car _%head27659%_)))
                                (declare (not safe))
                                (gerbil-ascent/candidate/funs#candidate-required-entry
                                 __tmp37180
                                 _%levels27643%_)))))
                    (declare (not safe))
                    (##structure
                     gerbil-ascent/candidate/finite-plan#finite-rule::t
                     __tmp37192
                     __tmp37191
                     __tmp37181
                     __tmp37179)))))
          (if (vector? _%$%rule2764427652%_)
              (if (let ((__tmp37193
                         (let ()
                           (declare (not safe))
                           (##vector-length _%$%rule2764427652%_))))
                    (declare (not safe))
                    (##fx= __tmp37193 '3))
                  (let* ((_%$%e2764827676%_
                          (let ()
                            (declare (not safe))
                            (##vector-ref _%$%rule2764427652%_ '0)))
                         (_%head27679%_ _%$%e2764827676%_)
                         (_%$%e2764927681%_
                          (let ()
                            (declare (not safe))
                            (##vector-ref _%$%rule2764427652%_ '1)))
                         (_%body27684%_ _%$%e2764927681%_)
                         (_%$%e2765027686%_
                          (let ()
                            (declare (not safe))
                            (##vector-ref _%$%rule2764427652%_ '2))))
                    (_%$%K2764727673%_ _%body27684%_ _%head27679%_))
                  (_%$%E2764627655%_))
              (_%$%E2764627655%_)))))))
