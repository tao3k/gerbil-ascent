(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/index[1]#_g35530_|
    (##structure
     gx#syntax-quote::t
     'row-indexes::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35532_|
    (##structure
     gx#syntax-quote::t
     'make-row-indexes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35534_|
    (##structure
     gx#syntax-quote::t
     'row-indexes?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35536_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35537_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-advance!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35538_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-plan!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35539_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-visit-parts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35541_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35542_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-advance!-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35543_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-plan!-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35544_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-visit-parts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35546_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35547_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-advance!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35548_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-plan!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35549_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-visit-parts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35551_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35552_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-advance!-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35553_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-plan!-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35554_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-visit-parts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35556_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35558_|
    (##structure
     gx#syntax-quote::t
     'make-provider-row-member
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35560_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35562_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member-ordinal
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35563_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35564_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member-occurrences
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35566_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member-ordinal-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35567_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35568_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member-occurrences-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35570_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-member-ordinal
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35571_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-member-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35572_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-member-occurrences
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35574_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-member-ordinal-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35575_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-member-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35576_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-member-occurrences-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35578_|
    (##structure
     gx#syntax-quote::t
     'provider-row-witness::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35580_|
    (##structure
     gx#syntax-quote::t
     'make-provider-row-witness
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35582_|
    (##structure
     gx#syntax-quote::t
     'provider-row-witness?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35584_|
    (##structure
     gx#syntax-quote::t
     'provider-row-witness-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35585_|
    (##structure
     gx#syntax-quote::t
     'provider-row-witness-counts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35587_|
    (##structure
     gx#syntax-quote::t
     'provider-row-witness-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35588_|
    (##structure
     gx#syntax-quote::t
     'provider-row-witness-counts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35590_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-witness-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35591_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-witness-counts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35593_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-witness-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35594_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-witness-counts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35596_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35598_|
    (##structure
     gx#syntax-quote::t
     'make-physical-index-entry
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35600_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35602_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-version
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35603_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-lookup
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35604_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-shared?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35605_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-witness
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35607_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-version-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35608_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-lookup-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35609_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-shared?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35610_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-witness-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35612_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-version
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35613_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-lookup
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35614_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-shared?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35615_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-witness
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35617_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-version-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35618_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-lookup-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35619_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-shared?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35620_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-witness-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35622_|
    (##structure
     gx#syntax-quote::t
     'atom-index-view::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35624_|
    (##structure
     gx#syntax-quote::t
     'make-atom-index-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35626_|
    (##structure
     gx#syntax-quote::t
     'atom-index-view?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35628_|
    (##structure
     gx#syntax-quote::t
     'atom-index-view-entry
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35629_|
    (##structure
     gx#syntax-quote::t
     'atom-index-view-permutation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35631_|
    (##structure
     gx#syntax-quote::t
     'atom-index-view-entry-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35632_|
    (##structure
     gx#syntax-quote::t
     'atom-index-view-permutation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35634_|
    (##structure
     gx#syntax-quote::t
     '&atom-index-view-entry
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35635_|
    (##structure
     gx#syntax-quote::t
     '&atom-index-view-permutation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35637_|
    (##structure
     gx#syntax-quote::t
     '&atom-index-view-entry-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g35638_|
    (##structure
     gx#syntax-quote::t
     '&atom-index-view-permutation-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/index[:0:]#row-indexes|
      (let ((__obj35171
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35171
           'gerbil-ascent/program/index#row-indexes::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35171 'row-indexes '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35171
           '(rows advance! plan! visit-parts)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35171
           '(rows advance! plan! visit-parts)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35171 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35171 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35171 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35171 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35171 '#f '13 '#f '#f))
        (let ((__tmp35529 |gerbil-ascent/program/index[1]#_g35530_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35171 __tmp35529 '4 '#f '#f))
        (let ((__tmp35531 |gerbil-ascent/program/index[1]#_g35532_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35171 __tmp35531 '14 '#f '#f))
        (let ((__tmp35533 |gerbil-ascent/program/index[1]#_g35534_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35171 __tmp35533 '15 '#f '#f))
        (let ((__tmp35535
               (cons (cons 'rows |gerbil-ascent/program/index[1]#_g35536_|)
                     (cons (cons 'advance!
                                 |gerbil-ascent/program/index[1]#_g35537_|)
                           (cons (cons 'plan!
                                       |gerbil-ascent/program/index[1]#_g35538_|)
                                 (cons (cons 'visit-parts
                                             |gerbil-ascent/program/index[1]#_g35539_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35171 __tmp35535 '16 '#f '#f))
        (let ((__tmp35540
               (cons (cons 'rows |gerbil-ascent/program/index[1]#_g35541_|)
                     (cons (cons 'advance!
                                 |gerbil-ascent/program/index[1]#_g35542_|)
                           (cons (cons 'plan!
                                       |gerbil-ascent/program/index[1]#_g35543_|)
                                 (cons (cons 'visit-parts
                                             |gerbil-ascent/program/index[1]#_g35544_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35171 __tmp35540 '17 '#f '#f))
        (let ((__tmp35545
               (cons (cons 'rows |gerbil-ascent/program/index[1]#_g35546_|)
                     (cons (cons 'advance!
                                 |gerbil-ascent/program/index[1]#_g35547_|)
                           (cons (cons 'plan!
                                       |gerbil-ascent/program/index[1]#_g35548_|)
                                 (cons (cons 'visit-parts
                                             |gerbil-ascent/program/index[1]#_g35549_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35171 __tmp35545 '18 '#f '#f))
        (let ((__tmp35550
               (cons (cons 'rows |gerbil-ascent/program/index[1]#_g35551_|)
                     (cons (cons 'advance!
                                 |gerbil-ascent/program/index[1]#_g35552_|)
                           (cons (cons 'plan!
                                       |gerbil-ascent/program/index[1]#_g35553_|)
                                 (cons (cons 'visit-parts
                                             |gerbil-ascent/program/index[1]#_g35554_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35171 __tmp35550 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35171 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35171 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35171 '() '21 '#f '#f))
        __obj35171))
    (define |gerbil-ascent/program/index[:0:]#provider-row-member|
      (let ((__obj35172
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35172
           'gerbil-ascent/program/index#provider-row-member::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35172
           'provider-row-member
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35172
           '(ordinal key occurrences)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35172
           '(ordinal key occurrences)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35172 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35172 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35172 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35172 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35172 '#f '13 '#f '#f))
        (let ((__tmp35555 |gerbil-ascent/program/index[1]#_g35556_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35172 __tmp35555 '4 '#f '#f))
        (let ((__tmp35557 |gerbil-ascent/program/index[1]#_g35558_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35172 __tmp35557 '14 '#f '#f))
        (let ((__tmp35559 |gerbil-ascent/program/index[1]#_g35560_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35172 __tmp35559 '15 '#f '#f))
        (let ((__tmp35561
               (cons (cons 'ordinal |gerbil-ascent/program/index[1]#_g35562_|)
                     (cons (cons 'key
                                 |gerbil-ascent/program/index[1]#_g35563_|)
                           (cons (cons 'occurrences
                                       |gerbil-ascent/program/index[1]#_g35564_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35172 __tmp35561 '16 '#f '#f))
        (let ((__tmp35565
               (cons (cons 'ordinal |gerbil-ascent/program/index[1]#_g35566_|)
                     (cons (cons 'key
                                 |gerbil-ascent/program/index[1]#_g35567_|)
                           (cons (cons 'occurrences
                                       |gerbil-ascent/program/index[1]#_g35568_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35172 __tmp35565 '17 '#f '#f))
        (let ((__tmp35569
               (cons (cons 'ordinal |gerbil-ascent/program/index[1]#_g35570_|)
                     (cons (cons 'key
                                 |gerbil-ascent/program/index[1]#_g35571_|)
                           (cons (cons 'occurrences
                                       |gerbil-ascent/program/index[1]#_g35572_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35172 __tmp35569 '18 '#f '#f))
        (let ((__tmp35573
               (cons (cons 'ordinal |gerbil-ascent/program/index[1]#_g35574_|)
                     (cons (cons 'key
                                 |gerbil-ascent/program/index[1]#_g35575_|)
                           (cons (cons 'occurrences
                                       |gerbil-ascent/program/index[1]#_g35576_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35172 __tmp35573 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35172 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35172 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35172 '() '21 '#f '#f))
        __obj35172))
    (define |gerbil-ascent/program/index[:0:]#provider-row-witness|
      (let ((__obj35173
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35173
           'gerbil-ascent/program/index#provider-row-witness::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35173
           'provider-row-witness
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35173 '(members counts) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35173 '(members counts) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35173 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35173 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35173 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35173 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35173 '#f '13 '#f '#f))
        (let ((__tmp35577 |gerbil-ascent/program/index[1]#_g35578_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35173 __tmp35577 '4 '#f '#f))
        (let ((__tmp35579 |gerbil-ascent/program/index[1]#_g35580_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35173 __tmp35579 '14 '#f '#f))
        (let ((__tmp35581 |gerbil-ascent/program/index[1]#_g35582_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35173 __tmp35581 '15 '#f '#f))
        (let ((__tmp35583
               (cons (cons 'members |gerbil-ascent/program/index[1]#_g35584_|)
                     (cons (cons 'counts
                                 |gerbil-ascent/program/index[1]#_g35585_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35173 __tmp35583 '16 '#f '#f))
        (let ((__tmp35586
               (cons (cons 'members |gerbil-ascent/program/index[1]#_g35587_|)
                     (cons (cons 'counts
                                 |gerbil-ascent/program/index[1]#_g35588_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35173 __tmp35586 '17 '#f '#f))
        (let ((__tmp35589
               (cons (cons 'members |gerbil-ascent/program/index[1]#_g35590_|)
                     (cons (cons 'counts
                                 |gerbil-ascent/program/index[1]#_g35591_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35173 __tmp35589 '18 '#f '#f))
        (let ((__tmp35592
               (cons (cons 'members |gerbil-ascent/program/index[1]#_g35593_|)
                     (cons (cons 'counts
                                 |gerbil-ascent/program/index[1]#_g35594_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35173 __tmp35592 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35173 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35173 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35173 '() '21 '#f '#f))
        __obj35173))
    (define |gerbil-ascent/program/index[:0:]#physical-index-entry|
      (let ((__obj35174
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35174
           'gerbil-ascent/program/index#physical-index-entry::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35174
           'physical-index-entry
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35174
           '(version lookup shared? witness)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35174
           '(version lookup shared? witness)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35174 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35174 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35174 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35174 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35174 '#f '13 '#f '#f))
        (let ((__tmp35595 |gerbil-ascent/program/index[1]#_g35596_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35174 __tmp35595 '4 '#f '#f))
        (let ((__tmp35597 |gerbil-ascent/program/index[1]#_g35598_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35174 __tmp35597 '14 '#f '#f))
        (let ((__tmp35599 |gerbil-ascent/program/index[1]#_g35600_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35174 __tmp35599 '15 '#f '#f))
        (let ((__tmp35601
               (cons (cons 'version |gerbil-ascent/program/index[1]#_g35602_|)
                     (cons (cons 'lookup
                                 |gerbil-ascent/program/index[1]#_g35603_|)
                           (cons (cons 'shared?
                                       |gerbil-ascent/program/index[1]#_g35604_|)
                                 (cons (cons 'witness
                                             |gerbil-ascent/program/index[1]#_g35605_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35174 __tmp35601 '16 '#f '#f))
        (let ((__tmp35606
               (cons (cons 'version |gerbil-ascent/program/index[1]#_g35607_|)
                     (cons (cons 'lookup
                                 |gerbil-ascent/program/index[1]#_g35608_|)
                           (cons (cons 'shared?
                                       |gerbil-ascent/program/index[1]#_g35609_|)
                                 (cons (cons 'witness
                                             |gerbil-ascent/program/index[1]#_g35610_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35174 __tmp35606 '17 '#f '#f))
        (let ((__tmp35611
               (cons (cons 'version |gerbil-ascent/program/index[1]#_g35612_|)
                     (cons (cons 'lookup
                                 |gerbil-ascent/program/index[1]#_g35613_|)
                           (cons (cons 'shared?
                                       |gerbil-ascent/program/index[1]#_g35614_|)
                                 (cons (cons 'witness
                                             |gerbil-ascent/program/index[1]#_g35615_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35174 __tmp35611 '18 '#f '#f))
        (let ((__tmp35616
               (cons (cons 'version |gerbil-ascent/program/index[1]#_g35617_|)
                     (cons (cons 'lookup
                                 |gerbil-ascent/program/index[1]#_g35618_|)
                           (cons (cons 'shared?
                                       |gerbil-ascent/program/index[1]#_g35619_|)
                                 (cons (cons 'witness
                                             |gerbil-ascent/program/index[1]#_g35620_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35174 __tmp35616 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35174 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35174 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35174 '() '21 '#f '#f))
        __obj35174))
    (define |gerbil-ascent/program/index[:0:]#atom-index-view|
      (let ((__obj35175
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35175
           'gerbil-ascent/program/index#atom-index-view::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35175 'atom-index-view '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35175
           '(entry permutation)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35175
           '(entry permutation)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35175 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35175 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35175 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35175 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35175 '#f '13 '#f '#f))
        (let ((__tmp35621 |gerbil-ascent/program/index[1]#_g35622_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35175 __tmp35621 '4 '#f '#f))
        (let ((__tmp35623 |gerbil-ascent/program/index[1]#_g35624_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35175 __tmp35623 '14 '#f '#f))
        (let ((__tmp35625 |gerbil-ascent/program/index[1]#_g35626_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35175 __tmp35625 '15 '#f '#f))
        (let ((__tmp35627
               (cons (cons 'entry |gerbil-ascent/program/index[1]#_g35628_|)
                     (cons (cons 'permutation
                                 |gerbil-ascent/program/index[1]#_g35629_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35175 __tmp35627 '16 '#f '#f))
        (let ((__tmp35630
               (cons (cons 'entry |gerbil-ascent/program/index[1]#_g35631_|)
                     (cons (cons 'permutation
                                 |gerbil-ascent/program/index[1]#_g35632_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35175 __tmp35630 '17 '#f '#f))
        (let ((__tmp35633
               (cons (cons 'entry |gerbil-ascent/program/index[1]#_g35634_|)
                     (cons (cons 'permutation
                                 |gerbil-ascent/program/index[1]#_g35635_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35175 __tmp35633 '18 '#f '#f))
        (let ((__tmp35636
               (cons (cons 'entry |gerbil-ascent/program/index[1]#_g35637_|)
                     (cons (cons 'permutation
                                 |gerbil-ascent/program/index[1]#_g35638_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35175 __tmp35636 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35175 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35175 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35175 '() '21 '#f '#f))
        __obj35175))))
