(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/view-state[1]#_g36599_|
    (##structure
     gx#syntax-quote::t
     'staged-frontier-count::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36601_|
    (##structure
     gx#syntax-quote::t
     'make-staged-frontier-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36603_|
    (##structure
     gx#syntax-quote::t
     'staged-frontier-count?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36605_|
    (##structure
     gx#syntax-quote::t
     'staged-frontier-count-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36607_|
    (##structure
     gx#syntax-quote::t
     'staged-frontier-count-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36609_|
    (##structure
     gx#syntax-quote::t
     '&staged-frontier-count-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36611_|
    (##structure
     gx#syntax-quote::t
     '&staged-frontier-count-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36613_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36615_|
    (##structure
     gx#syntax-quote::t
     'make-view-routing-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36617_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36619_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-storage
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36620_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-all
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36621_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-delta
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36622_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-versions
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36623_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-names
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36624_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36625_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-journals
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36626_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-routing
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36628_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-storage-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36629_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-all-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36630_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-delta-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36631_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-versions-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36632_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-names-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36633_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36634_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-journals-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36635_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-routing-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36637_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-storage
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36638_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-all
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36639_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-delta
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36640_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-versions
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36641_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-names
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36642_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36643_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-journals
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36644_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-routing
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36646_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-storage-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36647_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-all-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36648_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-delta-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36649_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-versions-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36650_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-names-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36651_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36652_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-journals-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36653_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-routing-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36655_|
    (##structure
     gx#syntax-quote::t
     'view-event::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36657_|
    (##structure
     gx#syntax-quote::t
     'make-view-event
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36659_|
    (##structure
     gx#syntax-quote::t
     'view-event?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36661_|
    (##structure
     gx#syntax-quote::t
     'view-event-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36662_|
    (##structure
     gx#syntax-quote::t
     'view-event-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36663_|
    (##structure
     gx#syntax-quote::t
     'view-event-eqrel?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36665_|
    (##structure
     gx#syntax-quote::t
     'view-event-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36666_|
    (##structure
     gx#syntax-quote::t
     'view-event-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36667_|
    (##structure
     gx#syntax-quote::t
     'view-event-eqrel?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36669_|
    (##structure
     gx#syntax-quote::t
     '&view-event-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36670_|
    (##structure
     gx#syntax-quote::t
     '&view-event-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36671_|
    (##structure
     gx#syntax-quote::t
     '&view-event-eqrel?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36673_|
    (##structure
     gx#syntax-quote::t
     '&view-event-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36674_|
    (##structure
     gx#syntax-quote::t
     '&view-event-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36675_|
    (##structure
     gx#syntax-quote::t
     '&view-event-eqrel?-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/view-state[:0:]#staged-frontier-count|
      (let ((__obj36350
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36350
           'gerbil-ascent/program/view-state#staged-frontier-count::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36350
           'staged-frontier-count
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36350 '(count) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36350 '(count) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36350 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36350 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36350 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36350 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36350 '#f '13 '#f '#f))
        (let ((__tmp36598 |gerbil-ascent/program/view-state[1]#_g36599_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36350 __tmp36598 '4 '#f '#f))
        (let ((__tmp36600 |gerbil-ascent/program/view-state[1]#_g36601_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36350 __tmp36600 '14 '#f '#f))
        (let ((__tmp36602 |gerbil-ascent/program/view-state[1]#_g36603_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36350 __tmp36602 '15 '#f '#f))
        (let ((__tmp36604
               (cons (cons 'count
                           |gerbil-ascent/program/view-state[1]#_g36605_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36350 __tmp36604 '16 '#f '#f))
        (let ((__tmp36606
               (cons (cons 'count
                           |gerbil-ascent/program/view-state[1]#_g36607_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36350 __tmp36606 '17 '#f '#f))
        (let ((__tmp36608
               (cons (cons 'count
                           |gerbil-ascent/program/view-state[1]#_g36609_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36350 __tmp36608 '18 '#f '#f))
        (let ((__tmp36610
               (cons (cons 'count
                           |gerbil-ascent/program/view-state[1]#_g36611_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj36350 __tmp36610 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36350 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36350 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36350 '() '21 '#f '#f))
        __obj36350))
    (define |gerbil-ascent/program/view-state[:0:]#view-routing-state|
      (let ((__obj36351
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36351
           'gerbil-ascent/program/view-state#view-routing-state::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36351
           'view-routing-state
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36351
           '(storage all delta versions names generation journals routing)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36351
           '(storage all delta versions names generation journals routing)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36351 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36351 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36351 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36351 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36351 '#f '13 '#f '#f))
        (let ((__tmp36612 |gerbil-ascent/program/view-state[1]#_g36613_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36351 __tmp36612 '4 '#f '#f))
        (let ((__tmp36614 |gerbil-ascent/program/view-state[1]#_g36615_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36351 __tmp36614 '14 '#f '#f))
        (let ((__tmp36616 |gerbil-ascent/program/view-state[1]#_g36617_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36351 __tmp36616 '15 '#f '#f))
        (let ((__tmp36618
               (cons (cons 'storage
                           |gerbil-ascent/program/view-state[1]#_g36619_|)
                     (cons (cons 'all
                                 |gerbil-ascent/program/view-state[1]#_g36620_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/view-state[1]#_g36621_|)
                                 (cons (cons 'versions
                                             |gerbil-ascent/program/view-state[1]#_g36622_|)
                                       (cons (cons 'names
                                                   |gerbil-ascent/program/view-state[1]#_g36623_|)
                                             (cons (cons 'generation
                                                         |gerbil-ascent/program/view-state[1]#_g36624_|)
                                                   (cons (cons 'journals
                                                               |gerbil-ascent/program/view-state[1]#_g36625_|)
                                                         (cons (cons 'routing
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/view-state[1]#_g36626_|)
                       '()))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj36351 __tmp36618 '16 '#f '#f))
        (let ((__tmp36627
               (cons (cons 'storage
                           |gerbil-ascent/program/view-state[1]#_g36628_|)
                     (cons (cons 'all
                                 |gerbil-ascent/program/view-state[1]#_g36629_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/view-state[1]#_g36630_|)
                                 (cons (cons 'versions
                                             |gerbil-ascent/program/view-state[1]#_g36631_|)
                                       (cons (cons 'names
                                                   |gerbil-ascent/program/view-state[1]#_g36632_|)
                                             (cons (cons 'generation
                                                         |gerbil-ascent/program/view-state[1]#_g36633_|)
                                                   (cons (cons 'journals
                                                               |gerbil-ascent/program/view-state[1]#_g36634_|)
                                                         (cons (cons 'routing
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/view-state[1]#_g36635_|)
                       '()))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj36351 __tmp36627 '17 '#f '#f))
        (let ((__tmp36636
               (cons (cons 'storage
                           |gerbil-ascent/program/view-state[1]#_g36637_|)
                     (cons (cons 'all
                                 |gerbil-ascent/program/view-state[1]#_g36638_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/view-state[1]#_g36639_|)
                                 (cons (cons 'versions
                                             |gerbil-ascent/program/view-state[1]#_g36640_|)
                                       (cons (cons 'names
                                                   |gerbil-ascent/program/view-state[1]#_g36641_|)
                                             (cons (cons 'generation
                                                         |gerbil-ascent/program/view-state[1]#_g36642_|)
                                                   (cons (cons 'journals
                                                               |gerbil-ascent/program/view-state[1]#_g36643_|)
                                                         (cons (cons 'routing
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/view-state[1]#_g36644_|)
                       '()))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj36351 __tmp36636 '18 '#f '#f))
        (let ((__tmp36645
               (cons (cons 'storage
                           |gerbil-ascent/program/view-state[1]#_g36646_|)
                     (cons (cons 'all
                                 |gerbil-ascent/program/view-state[1]#_g36647_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/view-state[1]#_g36648_|)
                                 (cons (cons 'versions
                                             |gerbil-ascent/program/view-state[1]#_g36649_|)
                                       (cons (cons 'names
                                                   |gerbil-ascent/program/view-state[1]#_g36650_|)
                                             (cons (cons 'generation
                                                         |gerbil-ascent/program/view-state[1]#_g36651_|)
                                                   (cons (cons 'journals
                                                               |gerbil-ascent/program/view-state[1]#_g36652_|)
                                                         (cons (cons 'routing
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/view-state[1]#_g36653_|)
                       '()))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj36351 __tmp36645 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36351 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36351 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36351 '() '21 '#f '#f))
        __obj36351))
    (define |gerbil-ascent/program/view-state[:0:]#view-event|
      (let ((__obj36352
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36352
           'gerbil-ascent/program/view-state#view-event::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36352 'view-event '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36352
           '(kind rows eqrel?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36352
           '(kind rows eqrel?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36352 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36352 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36352 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36352 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36352 '#f '13 '#f '#f))
        (let ((__tmp36654 |gerbil-ascent/program/view-state[1]#_g36655_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36352 __tmp36654 '4 '#f '#f))
        (let ((__tmp36656 |gerbil-ascent/program/view-state[1]#_g36657_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36352 __tmp36656 '14 '#f '#f))
        (let ((__tmp36658 |gerbil-ascent/program/view-state[1]#_g36659_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36352 __tmp36658 '15 '#f '#f))
        (let ((__tmp36660
               (cons (cons 'kind
                           |gerbil-ascent/program/view-state[1]#_g36661_|)
                     (cons (cons 'rows
                                 |gerbil-ascent/program/view-state[1]#_g36662_|)
                           (cons (cons 'eqrel?
                                       |gerbil-ascent/program/view-state[1]#_g36663_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36352 __tmp36660 '16 '#f '#f))
        (let ((__tmp36664
               (cons (cons 'kind
                           |gerbil-ascent/program/view-state[1]#_g36665_|)
                     (cons (cons 'rows
                                 |gerbil-ascent/program/view-state[1]#_g36666_|)
                           (cons (cons 'eqrel?
                                       |gerbil-ascent/program/view-state[1]#_g36667_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36352 __tmp36664 '17 '#f '#f))
        (let ((__tmp36668
               (cons (cons 'kind
                           |gerbil-ascent/program/view-state[1]#_g36669_|)
                     (cons (cons 'rows
                                 |gerbil-ascent/program/view-state[1]#_g36670_|)
                           (cons (cons 'eqrel?
                                       |gerbil-ascent/program/view-state[1]#_g36671_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36352 __tmp36668 '18 '#f '#f))
        (let ((__tmp36672
               (cons (cons 'kind
                           |gerbil-ascent/program/view-state[1]#_g36673_|)
                     (cons (cons 'rows
                                 |gerbil-ascent/program/view-state[1]#_g36674_|)
                           (cons (cons 'eqrel?
                                       |gerbil-ascent/program/view-state[1]#_g36675_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36352 __tmp36672 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36352 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36352 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36352 '() '21 '#f '#f))
        __obj36352))))
