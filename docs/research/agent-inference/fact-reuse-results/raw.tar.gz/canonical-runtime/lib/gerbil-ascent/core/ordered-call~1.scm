(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/core/ordered-call[:0:]#ordered-call-values|
    (lambda (_%$stx5671%_)
      (let* ((_%__stx3368233683%_ _%$stx5671%_)
             (_%$%g56765765%_
              (lambda ()
                (gx#raise-syntax-error
                 '#f
                 '"Bad syntax; invalid match target"
                 _%__stx3368233683%_))))
        (let ((_%__kont3368533686%_
               (lambda (_%$%g56786074%_
                        _%$%g56796076%_
                        _%$%g56806077%_
                        _%$%g56816078%_)
                 (cons _%$%g56816078%_
                       (let ((__tmp33940
                              (lambda (_%$%g61066109%_ _%$%g61076112%_)
                                (cons _%$%g61066109%_ _%$%g61076112%_))))
                         (declare (not safe))
                         (foldr__0 __tmp33940 '() _%$%g56786074%_)))))
              (_%__kont3368933690%_
               (lambda (_%$%g57125908%_
                        _%$%g57135910%_
                        _%$%g57145911%_
                        _%$%g57155912%_
                        _%$%g57165913%_
                        _%$%g57175914%_)
                 (cons (gx#datum->syntax '#f 'let*)
                       (cons (cons (cons _%$%g57165913%_
                                         (cons _%$%g57135910%_ '()))
                                   (cons (cons (gx#datum->syntax '#f 'next)
                                               (cons _%$%g57155912%_ '()))
                                         '()))
                             (cons (cons (gx#datum->syntax
                                          '#f
                                          'ordered-call-values)
                                         (cons _%$%g57175914%_
                                               (cons (cons _%$%g57165913%_
                                                           (cons _%$%g57155912%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (cons (let ((__tmp33942
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (lambda (_%$%g59525957%_ _%$%g59535960%_)
                            (cons _%$%g59525957%_ _%$%g59535960%_)))
                         (__tmp33941 (cons (gx#datum->syntax '#f 'next) '())))
                     (declare (not safe))
                     (foldr__0 __tmp33942 __tmp33941 _%$%g57145911%_))
                   (cons (let ((__tmp33943
                                (lambda (_%$%g59545963%_ _%$%g59555966%_)
                                  (cons _%$%g59545963%_ _%$%g59555966%_))))
                           (declare (not safe))
                           (foldr__0 __tmp33943 '() _%$%g57125908%_))
                         '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                   '()))))))
          (let* ((_%__match3378733788%_
                  (lambda (_%$%e57185772%_
                           _%$%hd57195776%_
                           _%$%tl57205779%_
                           _%$%e57215782%_
                           _%$%hd57225786%_
                           _%$%tl57235789%_
                           _%$%e57245792%_
                           _%$%hd57255796%_
                           _%$%tl57265799%_
                           _%$%e57275802%_
                           _%$%hd57285806%_
                           _%$%tl57295809%_
                           _%$%e57305812%_
                           _%$%hd57315816%_
                           _%$%tl57325819%_
                           _%$%e57335822%_
                           _%$%hd57345826%_
                           _%$%tl57355829%_
                           _%__splice3369133692%_
                           _%$%target57365832%_
                           _%$%tl57385835%_)
                    (letrec ((_%$%loop57395838%_
                              (lambda (_%$%hd57375842%_ _%$%value57435845%_)
                                (if (gx#stx-pair? _%$%hd57375842%_)
                                    (let ((_%$%e57405847%_
                                           (gx#syntax-e _%$%hd57375842%_)))
                                      (let ((_%$%lp-tl57425854%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e57405847%_)))
                                            (_%$%lp-hd57415851%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e57405847%_))))
                                        (_%$%loop57395838%_
                                         _%$%lp-tl57425854%_
                                         (cons _%$%lp-hd57415851%_
                                               _%$%value57435845%_))))
                                    (let ((_%$%value57445857%_
                                           (reverse _%$%value57435845%_)))
                                      (if (gx#stx-pair? _%$%tl57355829%_)
                                          (let ((_%$%e57455860%_
                                                 (gx#syntax-e
                                                  _%$%tl57355829%_)))
                                            (let ((_%$%tl57475867%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e57455860%_)))
                                                  (_%$%hd57465864%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e57455860%_))))
                                              (if (gx#stx-pair?
                                                   _%$%hd57465864%_)
                                                  (let ((_%$%e57485870%_
                                                         (gx#syntax-e
                                                          _%$%hd57465864%_)))
                                                    (let ((_%$%tl57505877%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e57485870%_)))
                                                          (_%$%hd57495874%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e57485870%_))))
                                                      (if (gx#stx-pair/null?
                                                           _%$%tl57505877%_)
                                                          (let ((_%__splice3369333694%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (gx#syntax-split-splice->vector _%$%tl57505877%_ '0)))
                    (let ((_%$%tl57535883%_
                           (let ()
                             (declare (not safe))
                             (##vector-ref _%__splice3369333694%_ '1)))
                          (_%$%target57515880%_
                           (let ()
                             (declare (not safe))
                             (##vector-ref _%__splice3369333694%_ '0))))
                      (if (gx#stx-null? _%$%tl57535883%_)
                          (letrec ((_%$%loop57545886%_
                                    (lambda (_%$%hd57525890%_
                                             _%$%rest57585893%_)
                                      (if (gx#stx-pair? _%$%hd57525890%_)
                                          (let ((_%$%e57555895%_
                                                 (gx#syntax-e
                                                  _%$%hd57525890%_)))
                                            (let ((_%$%lp-tl57575902%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e57555895%_)))
                                                  (_%$%lp-hd57565899%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e57555895%_))))
                                              (_%$%loop57545886%_
                                               _%$%lp-tl57575902%_
                                               (cons _%$%lp-hd57565899%_
                                                     _%$%rest57585893%_))))
                                          (let ((_%$%rest57595905%_
                                                 (reverse _%$%rest57585893%_)))
                                            (if (gx#stx-null? _%$%tl57475867%_)
                                                (_%__kont3368933690%_
                                                 _%$%rest57595905%_
                                                 _%$%hd57495874%_
                                                 _%$%value57445857%_
                                                 _%$%hd57315816%_
                                                 _%$%hd57285806%_
                                                 _%$%hd57225786%_)
                                                (let ()
                                                  (declare (not safe))
                                                  (_%$%g56765765%_))))))))
                            (_%$%loop57545886%_ _%$%target57515880%_ '()))
                          (let () (declare (not safe)) (_%$%g56765765%_)))))
                  (let () (declare (not safe)) (_%$%g56765765%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (let ()
                                                    (declare (not safe))
                                                    (_%$%g56765765%_)))))
                                          (let ()
                                            (declare (not safe))
                                            (_%$%g56765765%_))))))))
                      (_%$%loop57395838%_ _%$%target57365832%_ '()))))
                 (_%__match3374133742%_
                  (lambda (_%$%e56825976%_
                           _%$%hd56835980%_
                           _%$%tl56845983%_
                           _%$%e56855986%_
                           _%$%hd56865990%_
                           _%$%tl56875993%_
                           _%$%e56885996%_
                           _%$%hd56896000%_
                           _%$%tl56906003%_
                           _%$%e56916006%_
                           _%$%hd56926010%_
                           _%$%tl56936013%_
                           _%$%e56946016%_
                           _%$%hd56956020%_
                           _%$%tl56966023%_
                           _%$%e56976026%_
                           _%$%hd56986030%_
                           _%$%tl56996033%_
                           _%__splice3368733688%_
                           _%$%target57006036%_
                           _%$%tl57026039%_)
                    (letrec ((_%$%loop57036042%_
                              (lambda (_%$%hd57016046%_ _%$%value57076049%_)
                                (if (gx#stx-pair? _%$%hd57016046%_)
                                    (let ((_%$%e57046051%_
                                           (gx#syntax-e _%$%hd57016046%_)))
                                      (let ((_%$%lp-tl57066058%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e57046051%_)))
                                            (_%$%lp-hd57056055%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e57046051%_))))
                                        (_%$%loop57036042%_
                                         _%$%lp-tl57066058%_
                                         (cons _%$%lp-hd57056055%_
                                               _%$%value57076049%_))))
                                    (let ((_%$%value57086061%_
                                           (reverse _%$%value57076049%_)))
                                      (if (gx#stx-pair? _%$%tl56996033%_)
                                          (let ((_%$%e57096064%_
                                                 (gx#syntax-e
                                                  _%$%tl56996033%_)))
                                            (let ((_%$%tl57116071%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e57096064%_)))
                                                  (_%$%hd57106068%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e57096064%_))))
                                              (if (gx#stx-null?
                                                   _%$%hd57106068%_)
                                                  (if (gx#stx-null?
                                                       _%$%tl57116071%_)
                                                      (_%__kont3368533686%_
                                                       _%$%value57086061%_
                                                       _%$%hd56956020%_
                                                       _%$%hd56926010%_
                                                       _%$%hd56865990%_)
                                                      (_%__match3378733788%_
                                                       _%$%e56825976%_
                                                       _%$%hd56835980%_
                                                       _%$%tl56845983%_
                                                       _%$%e56855986%_
                                                       _%$%hd56865990%_
                                                       _%$%tl56875993%_
                                                       _%$%e56885996%_
                                                       _%$%hd56896000%_
                                                       _%$%tl56906003%_
                                                       _%$%e56916006%_
                                                       _%$%hd56926010%_
                                                       _%$%tl56936013%_
                                                       _%$%e56946016%_
                                                       _%$%hd56956020%_
                                                       _%$%tl56966023%_
                                                       _%$%e56976026%_
                                                       _%$%hd56986030%_
                                                       _%$%tl56996033%_
                                                       _%__splice3368733688%_
                                                       _%$%target57006036%_
                                                       _%$%tl57026039%_))
                                                  (_%__match3378733788%_
                                                   _%$%e56825976%_
                                                   _%$%hd56835980%_
                                                   _%$%tl56845983%_
                                                   _%$%e56855986%_
                                                   _%$%hd56865990%_
                                                   _%$%tl56875993%_
                                                   _%$%e56885996%_
                                                   _%$%hd56896000%_
                                                   _%$%tl56906003%_
                                                   _%$%e56916006%_
                                                   _%$%hd56926010%_
                                                   _%$%tl56936013%_
                                                   _%$%e56946016%_
                                                   _%$%hd56956020%_
                                                   _%$%tl56966023%_
                                                   _%$%e56976026%_
                                                   _%$%hd56986030%_
                                                   _%$%tl56996033%_
                                                   _%__splice3368733688%_
                                                   _%$%target57006036%_
                                                   _%$%tl57026039%_))))
                                          (_%__match3378733788%_
                                           _%$%e56825976%_
                                           _%$%hd56835980%_
                                           _%$%tl56845983%_
                                           _%$%e56855986%_
                                           _%$%hd56865990%_
                                           _%$%tl56875993%_
                                           _%$%e56885996%_
                                           _%$%hd56896000%_
                                           _%$%tl56906003%_
                                           _%$%e56916006%_
                                           _%$%hd56926010%_
                                           _%$%tl56936013%_
                                           _%$%e56946016%_
                                           _%$%hd56956020%_
                                           _%$%tl56966023%_
                                           _%$%e56976026%_
                                           _%$%hd56986030%_
                                           _%$%tl56996033%_
                                           _%__splice3368733688%_
                                           _%$%target57006036%_
                                           _%$%tl57026039%_)))))))
                      (_%$%loop57036042%_ _%$%target57006036%_ '())))))
            (if (gx#stx-pair? _%__stx3368233683%_)
                (let ((_%$%e56825976%_ (gx#syntax-e _%__stx3368233683%_)))
                  (let ((_%$%tl56845983%_
                         (let () (declare (not safe)) (##cdr _%$%e56825976%_)))
                        (_%$%hd56835980%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%e56825976%_))))
                    (if (gx#stx-pair? _%$%tl56845983%_)
                        (let ((_%$%e56855986%_ (gx#syntax-e _%$%tl56845983%_)))
                          (let ((_%$%tl56875993%_
                                 (let ()
                                   (declare (not safe))
                                   (##cdr _%$%e56855986%_)))
                                (_%$%hd56865990%_
                                 (let ()
                                   (declare (not safe))
                                   (##car _%$%e56855986%_))))
                            (if (gx#stx-pair? _%$%tl56875993%_)
                                (let ((_%$%e56885996%_
                                       (gx#syntax-e _%$%tl56875993%_)))
                                  (let ((_%$%tl56906003%_
                                         (let ()
                                           (declare (not safe))
                                           (##cdr _%$%e56885996%_)))
                                        (_%$%hd56896000%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%e56885996%_))))
                                    (if (gx#stx-pair? _%$%hd56896000%_)
                                        (let ((_%$%e56916006%_
                                               (gx#syntax-e _%$%hd56896000%_)))
                                          (let ((_%$%tl56936013%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e56916006%_)))
                                                (_%$%hd56926010%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e56916006%_))))
                                            (if (gx#stx-pair? _%$%tl56936013%_)
                                                (let ((_%$%e56946016%_
                                                       (gx#syntax-e
                                                        _%$%tl56936013%_)))
                                                  (let ((_%$%tl56966023%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e56946016%_)))
                                                        (_%$%hd56956020%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e56946016%_))))
                                                    (if (gx#stx-null?
                                                         _%$%tl56966023%_)
                                                        (if (gx#stx-pair?
                                                             _%$%tl56906003%_)
                                                            (let ((_%$%e56976026%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (gx#syntax-e _%$%tl56906003%_)))
                      (let ((_%$%tl56996033%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e56976026%_)))
                            (_%$%hd56986030%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e56976026%_))))
                        (if (gx#stx-pair/null? _%$%hd56986030%_)
                            (let ((_%__splice3368733688%_
                                   (gx#syntax-split-splice->vector
                                    _%$%hd56986030%_
                                    '0)))
                              (let ((_%$%tl57026039%_
                                     (let ()
                                       (declare (not safe))
                                       (##vector-ref
                                        _%__splice3368733688%_
                                        '1)))
                                    (_%$%target57006036%_
                                     (let ()
                                       (declare (not safe))
                                       (##vector-ref
                                        _%__splice3368733688%_
                                        '0))))
                                (if (gx#stx-null? _%$%tl57026039%_)
                                    (_%__match3374133742%_
                                     _%$%e56825976%_
                                     _%$%hd56835980%_
                                     _%$%tl56845983%_
                                     _%$%e56855986%_
                                     _%$%hd56865990%_
                                     _%$%tl56875993%_
                                     _%$%e56885996%_
                                     _%$%hd56896000%_
                                     _%$%tl56906003%_
                                     _%$%e56916006%_
                                     _%$%hd56926010%_
                                     _%$%tl56936013%_
                                     _%$%e56946016%_
                                     _%$%hd56956020%_
                                     _%$%tl56966023%_
                                     _%$%e56976026%_
                                     _%$%hd56986030%_
                                     _%$%tl56996033%_
                                     _%__splice3368733688%_
                                     _%$%target57006036%_
                                     _%$%tl57026039%_)
                                    (let ()
                                      (declare (not safe))
                                      (_%$%g56765765%_)))))
                            (let () (declare (not safe)) (_%$%g56765765%_)))))
                    (let () (declare (not safe)) (_%$%g56765765%_)))
                (let () (declare (not safe)) (_%$%g56765765%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (let ()
                                                  (declare (not safe))
                                                  (_%$%g56765765%_)))))
                                        (let ()
                                          (declare (not safe))
                                          (_%$%g56765765%_)))))
                                (let ()
                                  (declare (not safe))
                                  (_%$%g56765765%_)))))
                        (let () (declare (not safe)) (_%$%g56765765%_)))))
                (let () (declare (not safe)) (_%$%g56765765%_))))))))
  (define |gerbil-ascent/core/ordered-call[:0:]#dispatch-ordered-call|
    (lambda (_%$stx6122%_)
      (let* ((_%$%g61266168%_
              (lambda (_%$%g61276164%_)
                (gx#raise-syntax-error
                 '#f
                 '"Bad syntax; invalid match target"
                 _%$%g61276164%_)))
             (_%$%g61256357%_
              (lambda (_%$%g61276172%_)
                (if (gx#stx-pair? _%$%g61276172%_)
                    (let ((_%$%e61336175%_ (gx#syntax-e _%$%g61276172%_)))
                      (let ((_%$%hd61346179%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e61336175%_)))
                            (_%$%tl61356182%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e61336175%_))))
                        (if (gx#stx-pair? _%$%tl61356182%_)
                            (let ((_%$%e61366185%_
                                   (gx#syntax-e _%$%tl61356182%_)))
                              (let ((_%$%hd61376189%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e61366185%_)))
                                    (_%$%tl61386192%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e61366185%_))))
                                (if (gx#stx-pair/null? _%$%hd61376189%_)
                                    (let ((_g33944_
                                           (gx#syntax-split-splice
                                            _%$%hd61376189%_
                                            '0)))
                                      (begin
                                        (let ((_g33945_
                                               (let ()
                                                 (declare (not safe))
                                                 (if (##values? _g33944_)
                                                     (##values-length _g33944_)
                                                     1))))
                                          (if (not (let ()
                                                     (declare (not safe))
                                                     (##fx= _g33945_ 2)))
                                              (error "Context expects 2 values"
                                                     _g33945_)))
                                        (let ((_%$%target61396195%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##values-ref _g33944_ 0)))
                                              (_%$%tl61416198%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##values-ref _g33944_ 1))))
                                          (if (gx#stx-null? _%$%tl61416198%_)
                                              (letrec ((_%$%loop61426201%_
                                                        (lambda (_%$%hd61406205%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%$%wrap61466208%_)
                  (if (gx#stx-pair? _%$%hd61406205%_)
                      (let ((_%$%e61436210%_ (gx#syntax-e _%$%hd61406205%_)))
                        (let ((_%$%lp-hd61446214%_
                               (let ()
                                 (declare (not safe))
                                 (##car _%$%e61436210%_)))
                              (_%$%lp-tl61456217%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%$%e61436210%_))))
                          (_%$%loop61426201%_
                           _%$%lp-tl61456217%_
                           (cons _%$%lp-hd61446214%_ _%$%wrap61466208%_))))
                      (let ((_%$%wrap61476220%_ (reverse _%$%wrap61466208%_)))
                        (if (gx#stx-pair? _%$%tl61386192%_)
                            (let ((_%$%e61486223%_
                                   (gx#syntax-e _%$%tl61386192%_)))
                              (let ((_%$%hd61496227%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e61486223%_)))
                                    (_%$%tl61506230%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e61486223%_))))
                                (if (gx#stx-pair? _%$%tl61506230%_)
                                    (let ((_%$%e61516233%_
                                           (gx#syntax-e _%$%tl61506230%_)))
                                      (let ((_%$%hd61526237%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e61516233%_)))
                                            (_%$%tl61536240%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e61516233%_))))
                                        (if (gx#stx-pair? _%$%tl61536240%_)
                                            (let ((_%$%e61546243%_
                                                   (gx#syntax-e
                                                    _%$%tl61536240%_)))
                                              (let ((_%$%hd61556247%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e61546243%_)))
                                                    (_%$%tl61566250%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e61546243%_))))
                                                (if (gx#stx-pair?
                                                     _%$%hd61556247%_)
                                                    (let ((_%$%e61576253%_
                                                           (gx#syntax-e
                                                            _%$%hd61556247%_)))
                                                      (let ((_%$%hd61586257%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##car _%$%e61576253%_)))
                    (_%$%tl61596260%_
                     (let () (declare (not safe)) (##cdr _%$%e61576253%_))))
                (if (gx#stx-pair? _%$%tl61596260%_)
                    (let ((_%$%e61606263%_ (gx#syntax-e _%$%tl61596260%_)))
                      (let ((_%$%hd61616267%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e61606263%_)))
                            (_%$%tl61626270%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e61606263%_))))
                        (if (gx#stx-null? _%$%tl61626270%_)
                            (if (gx#stx-null? _%$%tl61566250%_)
                                (cons (gx#datum->syntax '#f 'match)
                                      (cons _%$%hd61526237%_
                                            (cons (cons (cons (gx#datum->syntax
                                                               '#f
                                                               '@list)
                                                              '())
                                                        (cons (let ((__tmp33947
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (lambda (_%$%g63086321%_ _%$%g63096324%_)
                               (cons _%$%g63086321%_ _%$%g63096324%_)))
                            (__tmp33946
                             (cons (cons (gx#datum->syntax
                                          '#f
                                          'ordered-call-values)
                                         (cons _%$%hd61496227%_
                                               (cons (cons _%$%hd61586257%_
                                                           (cons _%$%hd61616267%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (cons '()
                                                           (cons '() '())))))
                                   '())))
                        (declare (not safe))
                        (foldr__0 __tmp33947 __tmp33946 _%$%wrap61476220%_))
                      '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons (cons (cons (gx#datum->syntax
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             '#f
                             '@list)
                            (cons (gx#datum->syntax '#f 'one) '()))
                      (cons (let ((__tmp33949
                                   (lambda (_%$%g63106327%_ _%$%g63116330%_)
                                     (cons _%$%g63106327%_ _%$%g63116330%_)))
                                  (__tmp33948
                                   (cons (cons (gx#datum->syntax
                                                '#f
                                                'ordered-call-values)
                                               (cons _%$%hd61496227%_
                                                     (cons (cons _%$%hd61586257%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (cons _%$%hd61616267%_ '()))
                   (cons '()
                         (cons (cons (gx#datum->syntax '#f 'one) '()) '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                         '())))
                              (declare (not safe))
                              (foldr__0
                               __tmp33949
                               __tmp33948
                               _%$%wrap61476220%_))
                            '()))
                (cons (cons (cons (gx#datum->syntax '#f '@list)
                                  (cons (gx#datum->syntax '#f 'one)
                                        (cons (gx#datum->syntax '#f 'two)
                                              '())))
                            (cons (let ((__tmp33951
                                         (lambda (_%$%g63126333%_
                                                  _%$%g63136336%_)
                                           (cons _%$%g63126333%_
                                                 _%$%g63136336%_)))
                                        (__tmp33950
                                         (cons (cons (gx#datum->syntax
                                                      '#f
                                                      'ordered-call-values)
                                                     (cons _%$%hd61496227%_
                                                           (cons (cons _%$%hd61586257%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               (cons _%$%hd61616267%_ '()))
                         (cons '()
                               (cons (cons (gx#datum->syntax '#f 'one)
                                           (cons (gx#datum->syntax '#f 'two)
                                                 '()))
                                     '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               '())))
                                    (declare (not safe))
                                    (foldr__0
                                     __tmp33951
                                     __tmp33950
                                     _%$%wrap61476220%_))
                                  '()))
                      (cons (cons (cons (gx#datum->syntax '#f '@list)
                                        (cons (gx#datum->syntax '#f 'one)
                                              (cons (gx#datum->syntax '#f 'two)
                                                    (cons (gx#datum->syntax
                                                           '#f
                                                           'three)
                                                          '()))))
                                  (cons (let ((__tmp33953
                                               (lambda (_%$%g63146339%_
                                                        _%$%g63156342%_)
                                                 (cons _%$%g63146339%_
                                                       _%$%g63156342%_)))
                                              (__tmp33952
                                               (cons (cons (gx#datum->syntax
                                                            '#f
                                                            'ordered-call-values)
                                                           (cons _%$%hd61496227%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (cons (cons _%$%hd61586257%_
                                     (cons _%$%hd61616267%_ '()))
                               (cons '()
                                     (cons (cons (gx#datum->syntax '#f 'one)
                                                 (cons (gx#datum->syntax
                                                        '#f
                                                        'two)
                                                       (cons (gx#datum->syntax
                                                              '#f
                                                              'three)
                                                             '())))
                                           '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     '())))
                                          (declare (not safe))
                                          (foldr__0
                                           __tmp33953
                                           __tmp33952
                                           _%$%wrap61476220%_))
                                        '()))
                            (cons (cons (cons (gx#datum->syntax '#f '@list)
                                              (cons (gx#datum->syntax '#f 'one)
                                                    (cons (gx#datum->syntax
                                                           '#f
                                                           'two)
                                                          (cons (gx#datum->syntax
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '#f
                         'three)
                        (cons (gx#datum->syntax '#f 'four) '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        (cons (let ((__tmp33955
                                                     (lambda (_%$%g63166345%_
                                                              _%$%g63176348%_)
                                                       (cons _%$%g63166345%_
                                                             _%$%g63176348%_)))
                                                    (__tmp33954
                                                     (cons (cons (gx#datum->syntax
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          '#f
                          'ordered-call-values)
                         (cons _%$%hd61496227%_
                               (cons (cons _%$%hd61586257%_
                                           (cons _%$%hd61616267%_ '()))
                                     (cons '()
                                           (cons (cons (gx#datum->syntax
                                                        '#f
                                                        'one)
                                                       (cons (gx#datum->syntax
                                                              '#f
                                                              'two)
                                                             (cons (gx#datum->syntax
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            '#f
                            'three)
                           (cons (gx#datum->syntax '#f 'four) '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 '())))))
                   '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (declare (not safe))
                                                (foldr__0
                                                 __tmp33955
                                                 __tmp33954
                                                 _%$%wrap61476220%_))
                                              '()))
                                  (cons (cons (gx#datum->syntax '#f 'else)
                                              (cons (let ((__tmp33957
                                                           (lambda (_%$%g63186351%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%$%g63196354%_)
                     (cons _%$%g63186351%_ _%$%g63196354%_)))
                  (__tmp33956
                   (cons (cons (gx#datum->syntax '#f 'apply)
                               (cons _%$%hd61496227%_
                                     (cons (cons (gx#datum->syntax '#f 'map)
                                                 (cons (cons (gx#datum->syntax
                                                              '#f
                                                              'lambda)
                                                             (cons (cons _%$%hd61586257%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                 '())
                           (cons _%$%hd61616267%_ '())))
               (cons _%$%hd61526237%_ '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           '())))
                         '())))
              (declare (not safe))
              (foldr__0 __tmp33957 __tmp33956 _%$%wrap61476220%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '()))
                                        '()))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                (_%$%g61266168%_ _%$%g61276172%_))
                            (_%$%g61266168%_ _%$%g61276172%_))))
                    (_%$%g61266168%_ _%$%g61276172%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%g61266168%_
                                                     _%$%g61276172%_))))
                                            (_%$%g61266168%_
                                             _%$%g61276172%_))))
                                    (_%$%g61266168%_ _%$%g61276172%_))))
                            (_%$%g61266168%_ _%$%g61276172%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (_%$%loop61426201%_
                                                 _%$%target61396195%_
                                                 '()))
                                              (_%$%g61266168%_
                                               _%$%g61276172%_)))))
                                    (_%$%g61266168%_ _%$%g61276172%_))))
                            (_%$%g61266168%_ _%$%g61276172%_))))
                    (_%$%g61266168%_ _%$%g61276172%_)))))
        (_%$%g61256357%_ _%$stx6122%_)))))
