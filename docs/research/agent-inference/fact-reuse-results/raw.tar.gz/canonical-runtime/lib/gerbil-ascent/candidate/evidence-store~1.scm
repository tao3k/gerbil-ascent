(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39957_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39959_|
    (##structure
     gx#syntax-quote::t
     'make-evidence-entry
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39961_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39963_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39964_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-candidate
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39965_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-receipt
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39966_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-handle
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39968_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-snapshot-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39969_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-candidate-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39970_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-receipt-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39971_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-handle-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39973_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39974_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-candidate
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39975_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-receipt
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39976_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-handle
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39978_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-snapshot-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39979_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-candidate-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39980_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-receipt-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g39981_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-handle-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[:0:]#evidence-entry|
    (let ((__obj39868
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj39868
         'gerbil-ascent/candidate/evidence-store#evidence-entry::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39868 'evidence-entry '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj39868
         '(snapshot candidate receipt handle)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj39868
         '(snapshot candidate receipt handle)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39868 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39868 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39868 '#t '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39868 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39868 '#f '13 '#f '#f))
      (let ((__tmp39956 |gerbil-ascent/candidate/evidence-store[1]#_g39957_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj39868 __tmp39956 '4 '#f '#f))
      (let ((__tmp39958 |gerbil-ascent/candidate/evidence-store[1]#_g39959_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj39868 __tmp39958 '14 '#f '#f))
      (let ((__tmp39960 |gerbil-ascent/candidate/evidence-store[1]#_g39961_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj39868 __tmp39960 '15 '#f '#f))
      (let ((__tmp39962
             (cons (cons 'snapshot
                         |gerbil-ascent/candidate/evidence-store[1]#_g39963_|)
                   (cons (cons 'candidate
                               |gerbil-ascent/candidate/evidence-store[1]#_g39964_|)
                         (cons (cons 'receipt
                                     |gerbil-ascent/candidate/evidence-store[1]#_g39965_|)
                               (cons (cons 'handle
                                           |gerbil-ascent/candidate/evidence-store[1]#_g39966_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj39868 __tmp39962 '16 '#f '#f))
      (let ((__tmp39967
             (cons (cons 'snapshot
                         |gerbil-ascent/candidate/evidence-store[1]#_g39968_|)
                   (cons (cons 'candidate
                               |gerbil-ascent/candidate/evidence-store[1]#_g39969_|)
                         (cons (cons 'receipt
                                     |gerbil-ascent/candidate/evidence-store[1]#_g39970_|)
                               (cons (cons 'handle
                                           |gerbil-ascent/candidate/evidence-store[1]#_g39971_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj39868 __tmp39967 '17 '#f '#f))
      (let ((__tmp39972
             (cons (cons 'snapshot
                         |gerbil-ascent/candidate/evidence-store[1]#_g39973_|)
                   (cons (cons 'candidate
                               |gerbil-ascent/candidate/evidence-store[1]#_g39974_|)
                         (cons (cons 'receipt
                                     |gerbil-ascent/candidate/evidence-store[1]#_g39975_|)
                               (cons (cons 'handle
                                           |gerbil-ascent/candidate/evidence-store[1]#_g39976_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj39868 __tmp39972 '18 '#f '#f))
      (let ((__tmp39977
             (cons (cons 'snapshot
                         |gerbil-ascent/candidate/evidence-store[1]#_g39978_|)
                   (cons (cons 'candidate
                               |gerbil-ascent/candidate/evidence-store[1]#_g39979_|)
                         (cons (cons 'receipt
                                     |gerbil-ascent/candidate/evidence-store[1]#_g39980_|)
                               (cons (cons 'handle
                                           |gerbil-ascent/candidate/evidence-store[1]#_g39981_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj39868 __tmp39977 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39868 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39868 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39868 '() '21 '#f '#f))
      __obj39868)))
