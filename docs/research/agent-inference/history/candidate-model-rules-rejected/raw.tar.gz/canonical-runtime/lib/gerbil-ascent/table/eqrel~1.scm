(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/eqrel[1]#_g34339_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34341_|
    (##structure
     gx#syntax-quote::t
     'make-eqrel-component
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34343_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34345_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34346_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34348_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34349_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34351_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-component-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34352_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-component-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34354_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-component-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34355_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-component-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34357_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34359_|
    (##structure
     gx#syntax-quote::t
     'make-eqrel-cut
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34361_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34363_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34364_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34366_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34367_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut-view-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34369_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-cut-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34370_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-cut-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34372_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-cut-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34373_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-cut-view-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34375_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34377_|
    (##structure
     gx#syntax-quote::t
     'make-eqrel-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34379_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34381_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-components
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34382_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34383_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-published
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34384_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-origin
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34386_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-components-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34387_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34388_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-published-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34389_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-origin-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34391_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-components
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34392_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34393_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-published
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34394_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-origin
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34396_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-components-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34397_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34398_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-published-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34399_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-origin-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34401_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34403_|
    (##structure
     gx#syntax-quote::t
     'make-coordinate-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34405_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34407_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-bound?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34408_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34409_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-coherent?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34411_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-bound?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34412_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34413_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-coherent?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34415_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-bound?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34416_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34417_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-coherent?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34419_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-bound?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34420_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34421_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-coherent?-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/table/eqrel[:0:]#eqrel-component|
      (let ((__obj34145
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34145
           'gerbil-ascent/table/eqrel#eqrel-component::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34145 'eqrel-component '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34145 '(members size) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34145 '(members size) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34145 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34145 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34145 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34145 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34145 '#f '13 '#f '#f))
        (let ((__tmp34338 |gerbil-ascent/table/eqrel[1]#_g34339_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34145 __tmp34338 '4 '#f '#f))
        (let ((__tmp34340 |gerbil-ascent/table/eqrel[1]#_g34341_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34145 __tmp34340 '14 '#f '#f))
        (let ((__tmp34342 |gerbil-ascent/table/eqrel[1]#_g34343_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34145 __tmp34342 '15 '#f '#f))
        (let ((__tmp34344
               (cons (cons 'members |gerbil-ascent/table/eqrel[1]#_g34345_|)
                     (cons (cons 'size |gerbil-ascent/table/eqrel[1]#_g34346_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34145 __tmp34344 '16 '#f '#f))
        (let ((__tmp34347
               (cons (cons 'members |gerbil-ascent/table/eqrel[1]#_g34348_|)
                     (cons (cons 'size |gerbil-ascent/table/eqrel[1]#_g34349_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34145 __tmp34347 '17 '#f '#f))
        (let ((__tmp34350
               (cons (cons 'members |gerbil-ascent/table/eqrel[1]#_g34351_|)
                     (cons (cons 'size |gerbil-ascent/table/eqrel[1]#_g34352_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34145 __tmp34350 '18 '#f '#f))
        (let ((__tmp34353
               (cons (cons 'members |gerbil-ascent/table/eqrel[1]#_g34354_|)
                     (cons (cons 'size |gerbil-ascent/table/eqrel[1]#_g34355_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34145 __tmp34353 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34145 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34145 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34145 '() '21 '#f '#f))
        __obj34145))
    (define |gerbil-ascent/table/eqrel[:0:]#eqrel-cut|
      (let ((__obj34146
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34146
           'gerbil-ascent/table/eqrel#eqrel-cut::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34146 'eqrel-cut '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34146 '(count view) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34146 '(count view) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34146 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34146 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34146 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34146 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34146 '#f '13 '#f '#f))
        (let ((__tmp34356 |gerbil-ascent/table/eqrel[1]#_g34357_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34146 __tmp34356 '4 '#f '#f))
        (let ((__tmp34358 |gerbil-ascent/table/eqrel[1]#_g34359_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34146 __tmp34358 '14 '#f '#f))
        (let ((__tmp34360 |gerbil-ascent/table/eqrel[1]#_g34361_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34146 __tmp34360 '15 '#f '#f))
        (let ((__tmp34362
               (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g34363_|)
                     (cons (cons 'view |gerbil-ascent/table/eqrel[1]#_g34364_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34146 __tmp34362 '16 '#f '#f))
        (let ((__tmp34365
               (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g34366_|)
                     (cons (cons 'view |gerbil-ascent/table/eqrel[1]#_g34367_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34146 __tmp34365 '17 '#f '#f))
        (let ((__tmp34368
               (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g34369_|)
                     (cons (cons 'view |gerbil-ascent/table/eqrel[1]#_g34370_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34146 __tmp34368 '18 '#f '#f))
        (let ((__tmp34371
               (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g34372_|)
                     (cons (cons 'view |gerbil-ascent/table/eqrel[1]#_g34373_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34146 __tmp34371 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34146 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34146 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34146 '() '21 '#f '#f))
        __obj34146))
    (define |gerbil-ascent/table/eqrel[:0:]#eqrel-state|
      (let ((__obj34147
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34147
           'gerbil-ascent/table/eqrel#eqrel-state::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34147 'eqrel-state '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34147
           '(components count published origin)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34147
           '(components count published origin)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34147 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34147 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34147 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34147 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34147 '#f '13 '#f '#f))
        (let ((__tmp34374 |gerbil-ascent/table/eqrel[1]#_g34375_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34147 __tmp34374 '4 '#f '#f))
        (let ((__tmp34376 |gerbil-ascent/table/eqrel[1]#_g34377_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34147 __tmp34376 '14 '#f '#f))
        (let ((__tmp34378 |gerbil-ascent/table/eqrel[1]#_g34379_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34147 __tmp34378 '15 '#f '#f))
        (let ((__tmp34380
               (cons (cons 'components |gerbil-ascent/table/eqrel[1]#_g34381_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/eqrel[1]#_g34382_|)
                           (cons (cons 'published
                                       |gerbil-ascent/table/eqrel[1]#_g34383_|)
                                 (cons (cons 'origin
                                             |gerbil-ascent/table/eqrel[1]#_g34384_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34147 __tmp34380 '16 '#f '#f))
        (let ((__tmp34385
               (cons (cons 'components |gerbil-ascent/table/eqrel[1]#_g34386_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/eqrel[1]#_g34387_|)
                           (cons (cons 'published
                                       |gerbil-ascent/table/eqrel[1]#_g34388_|)
                                 (cons (cons 'origin
                                             |gerbil-ascent/table/eqrel[1]#_g34389_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34147 __tmp34385 '17 '#f '#f))
        (let ((__tmp34390
               (cons (cons 'components |gerbil-ascent/table/eqrel[1]#_g34391_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/eqrel[1]#_g34392_|)
                           (cons (cons 'published
                                       |gerbil-ascent/table/eqrel[1]#_g34393_|)
                                 (cons (cons 'origin
                                             |gerbil-ascent/table/eqrel[1]#_g34394_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34147 __tmp34390 '18 '#f '#f))
        (let ((__tmp34395
               (cons (cons 'components |gerbil-ascent/table/eqrel[1]#_g34396_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/eqrel[1]#_g34397_|)
                           (cons (cons 'published
                                       |gerbil-ascent/table/eqrel[1]#_g34398_|)
                                 (cons (cons 'origin
                                             |gerbil-ascent/table/eqrel[1]#_g34399_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34147 __tmp34395 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34147 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34147 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34147 '() '21 '#f '#f))
        __obj34147))
    (define |gerbil-ascent/table/eqrel[:0:]#coordinate-key|
      (let ((__obj34148
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34148
           'gerbil-ascent/table/eqrel#coordinate-key::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34148 'coordinate-key '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34148
           '(bound? value coherent?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34148
           '(bound? value coherent?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34148 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34148 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34148 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34148 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34148 '#f '13 '#f '#f))
        (let ((__tmp34400 |gerbil-ascent/table/eqrel[1]#_g34401_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34148 __tmp34400 '4 '#f '#f))
        (let ((__tmp34402 |gerbil-ascent/table/eqrel[1]#_g34403_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34148 __tmp34402 '14 '#f '#f))
        (let ((__tmp34404 |gerbil-ascent/table/eqrel[1]#_g34405_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34148 __tmp34404 '15 '#f '#f))
        (let ((__tmp34406
               (cons (cons 'bound? |gerbil-ascent/table/eqrel[1]#_g34407_|)
                     (cons (cons 'value
                                 |gerbil-ascent/table/eqrel[1]#_g34408_|)
                           (cons (cons 'coherent?
                                       |gerbil-ascent/table/eqrel[1]#_g34409_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34148 __tmp34406 '16 '#f '#f))
        (let ((__tmp34410
               (cons (cons 'bound? |gerbil-ascent/table/eqrel[1]#_g34411_|)
                     (cons (cons 'value
                                 |gerbil-ascent/table/eqrel[1]#_g34412_|)
                           (cons (cons 'coherent?
                                       |gerbil-ascent/table/eqrel[1]#_g34413_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34148 __tmp34410 '17 '#f '#f))
        (let ((__tmp34414
               (cons (cons 'bound? |gerbil-ascent/table/eqrel[1]#_g34415_|)
                     (cons (cons 'value
                                 |gerbil-ascent/table/eqrel[1]#_g34416_|)
                           (cons (cons 'coherent?
                                       |gerbil-ascent/table/eqrel[1]#_g34417_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34148 __tmp34414 '18 '#f '#f))
        (let ((__tmp34418
               (cons (cons 'bound? |gerbil-ascent/table/eqrel[1]#_g34419_|)
                     (cons (cons 'value
                                 |gerbil-ascent/table/eqrel[1]#_g34420_|)
                           (cons (cons 'coherent?
                                       |gerbil-ascent/table/eqrel[1]#_g34421_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34148 __tmp34418 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34148 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34148 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34148 '() '21 '#f '#f))
        __obj34148))))
