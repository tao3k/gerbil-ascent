(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "std/crypto/digest")
    (load-module "std/encoding/hex")
    (load-module "gerbil-ascent/candidate/types"))
  (load-module "gerbil-ascent/candidate/program-identity~0"))
