(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37917_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37919_|
    (##structure
     gx#syntax-quote::t
     'make-positive-nonmembership
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37921_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37923_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37924_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37925_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37926_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37927_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37928_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-program-fingerprint
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37929_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37930_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37931_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-closure
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37933_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37934_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37935_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37936_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37937_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37938_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-program-fingerprint-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37939_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37940_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37941_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-closure-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37943_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37944_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37945_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37946_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37947_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37948_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-program-fingerprint
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37949_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37950_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37951_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-closure
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37953_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37954_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37955_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37956_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37957_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37958_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-program-fingerprint-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37959_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37960_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37961_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-closure-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[:0:]#positive-nonmembership|
    (let ((__obj37792
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj37792
         'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj37792
         'positive-nonmembership
         '3
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj37792
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  program-fingerprint
                  query
                  work-budget
                  closure)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj37792
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  program-fingerprint
                  query
                  work-budget
                  closure)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37792 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37792 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37792 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37792 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37792 '#f '13 '#f '#f))
      (let ((__tmp37916 |gerbil-ascent/candidate/nonmembership[1]#_g37917_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj37792 __tmp37916 '4 '#f '#f))
      (let ((__tmp37918 |gerbil-ascent/candidate/nonmembership[1]#_g37919_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj37792 __tmp37918 '14 '#f '#f))
      (let ((__tmp37920 |gerbil-ascent/candidate/nonmembership[1]#_g37921_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj37792 __tmp37920 '15 '#f '#f))
      (let ((__tmp37922
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g37923_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g37924_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g37925_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g37926_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g37927_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g37928_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g37929_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g37930_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g37931_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj37792 __tmp37922 '16 '#f '#f))
      (let ((__tmp37932
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g37933_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g37934_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g37935_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g37936_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g37937_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g37938_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g37939_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g37940_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g37941_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj37792 __tmp37932 '17 '#f '#f))
      (let ((__tmp37942
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g37943_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g37944_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g37945_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g37946_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g37947_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g37948_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g37949_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g37950_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g37951_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj37792 __tmp37942 '18 '#f '#f))
      (let ((__tmp37952
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g37953_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g37954_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g37955_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g37956_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g37957_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g37958_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g37959_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g37960_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g37961_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj37792 __tmp37952 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37792 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37792 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37792 '() '21 '#f '#f))
      __obj37792)))
