(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/datum[1]#_g33993_|
    (##structure
     gx#syntax-quote::t
     'datum-frame::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g33995_|
    (##structure
     gx#syntax-quote::t
     'make-datum-frame
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g33997_|
    (##structure
     gx#syntax-quote::t
     'datum-frame?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g33999_|
    (##structure
     gx#syntax-quote::t
     'datum-frame-pair
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34000_|
    (##structure
     gx#syntax-quote::t
     'datum-frame-depth
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34001_|
    (##structure
     gx#syntax-quote::t
     'datum-frame-tail?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34003_|
    (##structure
     gx#syntax-quote::t
     'datum-frame-pair-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34004_|
    (##structure
     gx#syntax-quote::t
     'datum-frame-depth-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34005_|
    (##structure
     gx#syntax-quote::t
     'datum-frame-tail?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34007_|
    (##structure
     gx#syntax-quote::t
     '&datum-frame-pair
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34008_|
    (##structure
     gx#syntax-quote::t
     '&datum-frame-depth
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34009_|
    (##structure
     gx#syntax-quote::t
     '&datum-frame-tail?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34011_|
    (##structure
     gx#syntax-quote::t
     '&datum-frame-pair-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34012_|
    (##structure
     gx#syntax-quote::t
     '&datum-frame-depth-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34013_|
    (##structure
     gx#syntax-quote::t
     '&datum-frame-tail?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[:0:]#datum-frame|
    (let ((__obj33929
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj33929
         'gerbil-ascent/candidate/datum#datum-frame::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33929 'datum-frame '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33929 '(pair depth tail?) '6 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33929 '(pair depth tail?) '8 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33929 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33929 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33929 '#t '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33929 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33929 '#f '13 '#f '#f))
      (let ((__tmp33992 |gerbil-ascent/candidate/datum[1]#_g33993_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj33929 __tmp33992 '4 '#f '#f))
      (let ((__tmp33994 |gerbil-ascent/candidate/datum[1]#_g33995_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj33929 __tmp33994 '14 '#f '#f))
      (let ((__tmp33996 |gerbil-ascent/candidate/datum[1]#_g33997_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj33929 __tmp33996 '15 '#f '#f))
      (let ((__tmp33998
             (cons (cons 'pair |gerbil-ascent/candidate/datum[1]#_g33999_|)
                   (cons (cons 'depth
                               |gerbil-ascent/candidate/datum[1]#_g34000_|)
                         (cons (cons 'tail?
                                     |gerbil-ascent/candidate/datum[1]#_g34001_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33929 __tmp33998 '16 '#f '#f))
      (let ((__tmp34002
             (cons (cons 'pair |gerbil-ascent/candidate/datum[1]#_g34003_|)
                   (cons (cons 'depth
                               |gerbil-ascent/candidate/datum[1]#_g34004_|)
                         (cons (cons 'tail?
                                     |gerbil-ascent/candidate/datum[1]#_g34005_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33929 __tmp34002 '17 '#f '#f))
      (let ((__tmp34006
             (cons (cons 'pair |gerbil-ascent/candidate/datum[1]#_g34007_|)
                   (cons (cons 'depth
                               |gerbil-ascent/candidate/datum[1]#_g34008_|)
                         (cons (cons 'tail?
                                     |gerbil-ascent/candidate/datum[1]#_g34009_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33929 __tmp34006 '18 '#f '#f))
      (let ((__tmp34010
             (cons (cons 'pair |gerbil-ascent/candidate/datum[1]#_g34011_|)
                   (cons (cons 'depth
                               |gerbil-ascent/candidate/datum[1]#_g34012_|)
                         (cons (cons 'tail?
                                     |gerbil-ascent/candidate/datum[1]#_g34013_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj33929 __tmp34010 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33929 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33929 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj33929 '() '21 '#f '#f))
      __obj33929)))
