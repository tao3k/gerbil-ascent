import importlib.util,json,sys,time,shutil
from pathlib import Path
p=Path.cwd()/'tools/research/candidate-model.py';spec=importlib.util.spec_from_file_location('m',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
run=Path(sys.argv[1]).resolve();m.reuse_verify(run);stages=run/'label-stages';stages.mkdir(exist_ok=False);finished={}
while len(finished)<6:
 rows=json.loads((run/'reuse-ledger.json').read_text());pending=[r for r in rows if r.get('stop') and (r['case'],r['arm']) not in finished]
 if not pending:time.sleep(1);continue
 for row in pending:
  key=(row['case'],row['arm']);stage=stages/f'{key[0]}-{key[1]}';stage.mkdir()
  for name in ['plan.json','plan.sha256','qualification.json']:shutil.copy2(run/name,stage/name)
  (stage/'calls').symlink_to(run/'calls',target_is_directory=True)
  m.save(stage/'reuse-ledger.json',[row]);m.save(stage/'source-receipt.json',{'parentRun':str(run),'parentPlanSha256':m.digest(run/'plan.json'),'rowSha256':__import__('hashlib').sha256(json.dumps(row,sort_keys=True).encode()).hexdigest(),'scope':'Independent annotation of completed immutable trajectory through the existing implementation.'})
  m.reuse_annotate(stage)
  labels=json.loads((stage/'reuse-annotation-ledger.json').read_text());assert len(labels)==1
  finished[key]=labels[0]
  m.save(run/'pipeline-annotation-progress.json',{'completed':[list(k) for k in finished],'expected':6})
  print('ANNOTATION_PHASE_DONE',key,flush=True)
rows=json.loads((run/'reuse-ledger.json').read_text());m.save(run/'reuse-annotation-ledger.json',[finished[(r['case'],r['arm'])] for r in rows]);m.reuse_verify(run)
print('ALL_ANNOTATIONS_COMPLETE',flush=True)
