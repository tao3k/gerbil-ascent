(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/core/relation-view")
    (load-module "gerbil-ascent/program/view-replay")
    (load-module "clan/poo/object")
    (load-module "gerbil-ascent/table/storage")
    (load-module "gerbil-ascent/table/eqrel")
    (load-module "gerbil-ascent/table/trrel-uf")
    (load-module "gerbil-ascent/table/provider"))
  (load-module "gerbil-ascent/program/view-state~0"))
