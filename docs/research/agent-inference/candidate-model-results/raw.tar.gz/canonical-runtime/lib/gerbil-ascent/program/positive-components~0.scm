(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/positive-components::timestamp 1791689700)
  (define gerbil-ascent/program/positive-components#gerbil-ascent-run-positive-components!
    (lambda (_%analysis18037%_
             _%schema18038%_
             _%initial18039%_
             _%workers18040%_
             _%merge18041%_
             _%canceled?18042%_)
      (let* ((_%components18044%_
              (let ()
                (declare (not safe))
                (gerbil-ascent/program/component-plan#gerbil-ascent-positive-components
                 _%analysis18037%_)))
             (_%frontier18046%_ (vector-copy _%initial18039%_))
             (_%sizes18048%_ (vector-map length _%frontier18046%_))
             (_%known18050%_
              (let ((__tmp36714 (vector-length _%initial18039%_)))
                (declare (not safe))
                (##make-vector __tmp36714 '#f)))
             (_%done18052%_
              (let ((__tmp36715 (length _%components18044%_)))
                (declare (not safe))
                (##make-vector __tmp36715 '#f)))
             (_%snapshots18054%_
              (let ((__tmp36716 (length _%components18044%_)))
                (declare (not safe))
                (##make-vector __tmp36716 '#f))))
        (for-each
         (lambda (_%component18057%_)
           (if (null? (##structure-ref
                       _%component18057%_
                       '3
                       gerbil-ascent/program/component-plan#positive-component::t
                       '#f))
               (vector-set!
                _%done18052%_
                (##structure-ref
                 _%component18057%_
                 '1
                 gerbil-ascent/program/component-plan#positive-component::t
                 '#f)
                '#t)
               (for-each
                (lambda (_%index18059%_)
                  (let ((_%table18061%_
                         (let ()
                           (declare (not safe))
                           (make-hash-table__%
                            '#f
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value))))
                    (for-each
                     (lambda (_%row18063%_)
                       (let ()
                         (declare (not safe))
                         (__hash-put! _%table18061%_ _%row18063%_ '#t)))
                     (vector-ref _%frontier18046%_ _%index18059%_))
                    (vector-set!
                     _%known18050%_
                     _%index18059%_
                     _%table18061%_)))
                (##structure-ref
                 _%component18057%_
                 '2
                 gerbil-ascent/program/component-plan#positive-component::t
                 '#f))))
         _%components18044%_)
        (let ((__tmp36726
               (vector _%analysis18037%_ _%initial18039%_ 'components))
              (__tmp36725
               (filter (lambda (_%component18065%_)
                         (pair? (##structure-ref
                                 _%component18065%_
                                 '3
                                 gerbil-ascent/program/component-plan#positive-component::t
                                 '#f)))
                       _%components18044%_))
              (__tmp36724
               (lambda (_%component18067%_ _%emit!18068%_ _%checkpoint!18069%_)
                 (let* ((_%id18071%_
                         (##structure-ref
                          _%component18067%_
                          '1
                          gerbil-ascent/program/component-plan#positive-component::t
                          '#f))
                        (_%snapshot18073%_
                         (vector-ref _%snapshots18054%_ _%id18071%_)))
                   (declare (not safe))
                   (gerbil-ascent/program/component-worker#gerbil-ascent-run-positive-component!
                    _%component18067%_
                    _%schema18038%_
                    _%snapshot18073%_
                    _%emit!18068%_
                    _%checkpoint!18069%_))))
              (__tmp36723
               (lambda (_%atom18076%_ _%row18077%_)
                 (let* ((_%index18079%_ (vector-ref _%atom18076%_ '0))
                        (_%table18081%_
                         (vector-ref _%known18050%_ _%index18079%_)))
                   (if (let ()
                         (declare (not safe))
                         (hash-get _%table18081%_ _%row18077%_))
                       '#!void
                       (begin
                         (_%merge18041%_ _%atom18076%_ _%row18077%_)
                         (let ()
                           (declare (not safe))
                           (hash-put! _%table18081%_ _%row18077%_ '#t))
                         (vector-set!
                          _%frontier18046%_
                          _%index18079%_
                          (cons _%row18077%_
                                (vector-ref _%frontier18046%_ _%index18079%_)))
                         (vector-set!
                          _%sizes18048%_
                          _%index18079%_
                          (+ '1
                             (vector-ref _%sizes18048%_ _%index18079%_))))))))
              (__tmp36718
               (lambda (_%component18084%_)
                 (if (let ((__tmp36720
                            (lambda (_%id18086%_)
                              (vector-ref _%done18052%_ _%id18086%_)))
                           (__tmp36719
                            (##structure-ref
                             _%component18084%_
                             '4
                             gerbil-ascent/program/component-plan#positive-component::t
                             '#f)))
                       (declare (not safe))
                       (andmap__0 __tmp36720 __tmp36719))
                     (begin
                       (vector-set!
                        _%snapshots18054%_
                        (##structure-ref
                         _%component18084%_
                         '1
                         gerbil-ascent/program/component-plan#positive-component::t
                         '#f)
                        (let ((__tmp36722
                               (let ()
                                 (declare (not safe))
                                 (##vector-copy _%frontier18046%_)))
                              (__tmp36721
                               (let ()
                                 (declare (not safe))
                                 (##vector-copy _%sizes18048%_))))
                          (declare (not safe))
                          (##structure
                           gerbil-ascent/program/component-worker#component-snapshot::t
                           __tmp36722
                           __tmp36721)))
                       '#t)
                     '#f)))
              (__tmp36717
               (lambda (_%component18088%_)
                 (let ((_%id18090%_
                        (##structure-ref
                         _%component18088%_
                         '1
                         gerbil-ascent/program/component-plan#positive-component::t
                         '#f)))
                   (vector-set! _%snapshots18054%_ _%id18090%_ '#f)
                   (vector-set! _%done18052%_ _%id18090%_ '#t)))))
          (declare (not safe))
          (gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__%
           __tmp36726
           __tmp36725
           _%workers18040%_
           __tmp36724
           __tmp36723
           _%canceled?18042%_
           __tmp36718
           __tmp36717))))))
