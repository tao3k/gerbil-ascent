(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/proof-frame::timestamp 1791692690)
  (begin
    (define gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
      (let ((__tmp33834 (list))
            (__tmp33833
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'proof-binding-flow
         __tmp33834
         '(fresh head clauses)
         __tmp33833
         '#f)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-flow?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t)))
    (define gerbil-ascent/candidate/proof-frame#make-proof-binding-flow
      (lambda _%$args29257%_
        (apply make-instance
               gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
               _%$args29257%_)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-flow-fresh
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'fresh)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-flow-head
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'head)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-flow-clauses
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'clauses)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-flow-fresh-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'fresh)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-flow-head-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'head)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-flow-clauses-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'clauses)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-flow-fresh
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'fresh)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-flow-head
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'head)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-flow-clauses
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'clauses)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-flow-fresh-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'fresh)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-flow-head-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'head)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-flow-clauses-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
         'clauses)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
      (let ((__tmp33836 (list))
            (__tmp33835
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
         'proof-binding-clause
         __tmp33836
         '(relation apply)
         __tmp33835
         '#f)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-clause?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/proof-frame#proof-binding-clause::t)))
    (define gerbil-ascent/candidate/proof-frame#make-proof-binding-clause
      (lambda _%$args29254%_
        (apply make-instance
               gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
               _%$args29254%_)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-clause-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
         'relation)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-clause-apply
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
         'apply)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-clause-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
         'relation)))
    (define gerbil-ascent/candidate/proof-frame#proof-binding-clause-apply-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
         'apply)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-clause-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
         'relation)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-clause-apply
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
         'apply)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-clause-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
         'relation)))
    (define gerbil-ascent/candidate/proof-frame#&proof-binding-clause-apply-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
         'apply)))
    (define gerbil-ascent/candidate/proof-frame#prepare-proof-binding-flow
      (lambda (_%head29055%_ _%body29056%_)
        (let ((_%slots29058%_
               (let () (declare (not safe)) (make-hash-table-eq)))
              (_%size29059%_ '0)
              (_%unbound29060%_
               (let () (declare (not safe)) (##gensym 'unbound))))
          (letrec ((_%slot29062%_
                    (lambda (_%name29246%_)
                      (let ((_%$e29248%_
                             (let ()
                               (declare (not safe))
                               (__hash-get _%slots29058%_ _%name29246%_))))
                        (if _%$e29248%_
                            (values _%$e29248%_)
                            (let ((_%index29252%_ _%size29059%_))
                              (set! _%size29059%_ (+ _%size29059%_ '1))
                              (let ()
                                (declare (not safe))
                                (__hash-put!
                                 _%slots29058%_
                                 _%name29246%_
                                 _%index29252%_))
                              _%index29252%_)))))
                   (_%bound?29063%_
                    (lambda (_%frame29243%_ _%index29244%_)
                      (not (eq? (vector-ref _%frame29243%_ _%index29244%_)
                                _%unbound29060%_))))
                   (_%prepare-atom29064%_
                    (lambda (_%atom29221%_)
                      (let ((__tmp33839
                             (lambda (_%term29223%_ _%next29224%_)
                               (if (eq? _%term29223%_ '?_)
                                   (lambda (_%row29227%_ _%frame29228%_)
                                     (_%next29224%_
                                      (cdr _%row29227%_)
                                      _%frame29228%_))
                                   (if (let ()
                                         (declare (not safe))
                                         (gerbil-ascent/candidate/program#candidate-variable?
                                          _%term29223%_))
                                       (let ((_%index29231%_
                                              (_%slot29062%_ _%term29223%_)))
                                         (lambda (_%row29233%_ _%frame29234%_)
                                           (if (if (_%bound?29063%_
                                                    _%frame29234%_
                                                    _%index29231%_)
                                                   (equal? (vector-ref
                                                            _%frame29234%_
                                                            _%index29231%_)
                                                           (car _%row29233%_))
                                                   (begin
                                                     (vector-set!
                                                      _%frame29234%_
                                                      _%index29231%_
                                                      (car _%row29233%_))
                                                     '#t))
                                               (_%next29224%_
                                                (cdr _%row29233%_)
                                                _%frame29234%_)
                                               '#f)))
                                       (lambda (_%row29237%_ _%frame29238%_)
                                         (if (equal? _%term29223%_
                                                     (car _%row29237%_))
                                             (_%next29224%_
                                              (cdr _%row29237%_)
                                              _%frame29238%_)
                                             '#f))))))
                            (__tmp33838
                             (lambda (_%_row29240%_ _%_frame29241%_) '#t))
                            (__tmp33837 (cdr _%atom29221%_)))
                        (declare (not safe))
                        (foldr__0 __tmp33839 __tmp33838 __tmp33837))))
                   (_%prepare-fixed29065%_
                    (lambda (_%clause29089%_)
                      (let* ((_%$%clause2909029097%_ _%clause29089%_)
                             (_%$%E2909229100%_
                              (lambda ()
                                (let ()
                                  (declare (not safe))
                                  (error '"No clause matching"
                                         _%$%clause2909029097%_
                                         '([mode . _])))
                                '#!void))
                             (_%$%K2909329213%_
                              (lambda (_%mode29103%_)
                                (let* ((_%form29105%_
                                        (if (eq? _%mode29103%_ 'where)
                                            (cadr _%clause29089%_)
                                            (caddr _%clause29089%_)))
                                       (_%inputs29107%_
                                        (map _%slot29062%_
                                             (cdr _%form29105%_)))
                                       (_%output29109%_
                                        (if (eq? _%mode29103%_ 'compute)
                                            (_%slot29062%_
                                             (cadr _%clause29089%_))
                                            '#f)))
                                  (letrec ((_%read-one29112%_
                                            (lambda (_%frame29209%_)
                                              (let ((_%index29211%_
                                                     (car _%inputs29107%_)))
                                                (if (_%bound?29063%_
                                                     _%frame29209%_
                                                     _%index29211%_)
                                                    (vector-ref
                                                     _%frame29209%_
                                                     _%index29211%_)
                                                    '#f)))))
                                    (let ((_%$e29114%_ _%mode29103%_))
                                      (if (eq? 'where _%$e29114%_)
                                          (let ((_%$e29117%_
                                                 (car _%form29105%_)))
                                            (if (eq? 'even? _%$e29117%_)
                                                (lambda (_%frame29120%_)
                                                  (let ((_%value29122%_
                                                         (_%read-one29112%_
                                                          _%frame29120%_)))
                                                    (if (exact-integer?
                                                         _%value29122%_)
                                                        (even? _%value29122%_)
                                                        '#f)))
                                                (if (eq? '< _%$e29117%_)
                                                    (let* ((_%$%inputs2912329132%_
                                                            _%inputs29107%_)
                                                           (_%$%E2912529135%_
                                                            (lambda ()
                                                              (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (error '"No clause matching"
                               _%$%inputs2912329132%_
                               '([left right])))
                      '#!void))
                   (_%$%K2912629146%_
                    (lambda (_%right29138%_ _%left29139%_)
                      (lambda (_%frame29141%_)
                        (let ((_%a29143%_
                               (vector-ref _%frame29141%_ _%left29139%_))
                              (_%b29144%_
                               (vector-ref _%frame29141%_ _%right29138%_)))
                          (if (exact-integer? _%a29143%_)
                              (if (exact-integer? _%b29144%_)
                                  (< _%a29143%_ _%b29144%_)
                                  '#f)
                              '#f))))))
              (if (pair? _%$%inputs2912329132%_)
                  (let ((_%$%hd2912729149%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%inputs2912329132%_)))
                        (_%$%tl2912829151%_
                         (let ()
                           (declare (not safe))
                           (##cdr _%$%inputs2912329132%_))))
                    (let ((_%left29154%_ _%$%hd2912729149%_))
                      (if (pair? _%$%tl2912829151%_)
                          (let ((_%$%hd2912929156%_
                                 (let ()
                                   (declare (not safe))
                                   (##car _%$%tl2912829151%_)))
                                (_%$%tl2913029158%_
                                 (let ()
                                   (declare (not safe))
                                   (##cdr _%$%tl2912829151%_))))
                            (let ((_%right29161%_ _%$%hd2912929156%_))
                              (if (null? _%$%tl2913029158%_)
                                  (_%$%K2912629146%_
                                   _%right29161%_
                                   _%left29154%_)
                                  (_%$%E2912529135%_))))
                          (_%$%E2912529135%_))))
                  (_%$%E2912529135%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '#!void)))
                                          (if (eq? 'compute _%$e29114%_)
                                              (let ((_%$e29163%_
                                                     (car _%form29105%_)))
                                                (if (eq? 'identity _%$e29163%_)
                                                    (let ((_%input29166%_
                                                           (car _%inputs29107%_)))
                                                      (lambda (_%frame29168%_)
                                                        (if (_%bound?29063%_
                                                             _%frame29168%_
                                                             _%input29166%_)
                                                            (if (_%bound?29063%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%frame29168%_
                         _%output29109%_)
                        '#f
                        (begin
                          (vector-set!
                           _%frame29168%_
                           _%output29109%_
                           (vector-ref _%frame29168%_ _%input29166%_))
                          '#t))
                    '#f)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (if (eq? '+ _%$e29163%_)
                                                        (let* ((_%$%inputs2916929178%_
                                                                _%inputs29107%_)
                                                               (_%$%E2917129181%_
                                                                (lambda ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (let ()
                            (declare (not safe))
                            (error '"No clause matching"
                                   _%$%inputs2916929178%_
                                   '([left right])))
                          '#!void))
                       (_%$%K2917229192%_
                        (lambda (_%right29184%_ _%left29185%_)
                          (lambda (_%frame29187%_)
                            (let ((_%a29189%_
                                   (vector-ref _%frame29187%_ _%left29185%_))
                                  (_%b29190%_
                                   (vector-ref _%frame29187%_ _%right29184%_)))
                              (if (_%bound?29063%_
                                   _%frame29187%_
                                   _%output29109%_)
                                  '#f
                                  (if (exact-integer? _%a29189%_)
                                      (if (exact-integer? _%b29190%_)
                                          (begin
                                            (vector-set!
                                             _%frame29187%_
                                             _%output29109%_
                                             (+ _%a29189%_ _%b29190%_))
                                            '#t)
                                          '#f)
                                      '#f)))))))
                  (if (pair? _%$%inputs2916929178%_)
                      (let ((_%$%hd2917329195%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%inputs2916929178%_)))
                            (_%$%tl2917429197%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%inputs2916929178%_))))
                        (let ((_%left29200%_ _%$%hd2917329195%_))
                          (if (pair? _%$%tl2917429197%_)
                              (let ((_%$%hd2917529202%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%tl2917429197%_)))
                                    (_%$%tl2917629204%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%tl2917429197%_))))
                                (let ((_%right29207%_ _%$%hd2917529202%_))
                                  (if (null? _%$%tl2917629204%_)
                                      (_%$%K2917229192%_
                                       _%right29207%_
                                       _%left29200%_)
                                      (_%$%E2917129181%_))))
                              (_%$%E2917129181%_))))
                      (_%$%E2917129181%_)))
                '#!void)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              '#!void))))))))
                        (if (pair? _%$%clause2909029097%_)
                            (let* ((_%$%hd2909429216%_
                                    (let ()
                                      (declare (not safe))
                                      (##car _%$%clause2909029097%_)))
                                   (_%mode29219%_ _%$%hd2909429216%_))
                              (_%$%K2909329213%_ _%mode29219%_))
                            (_%$%E2909229100%_))))))
            (let* ((_%clauses29069%_
                    (map (lambda (_%clause29067%_)
                           (if (let ((__tmp33840 (car _%clause29067%_)))
                                 (declare (not safe))
                                 (##memq __tmp33840 '(where compute)))
                               (let ((__tmp33841
                                      (_%prepare-fixed29065%_
                                       _%clause29067%_)))
                                 (declare (not safe))
                                 (##structure
                                  gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
                                  '#f
                                  __tmp33841))
                               (let ((__tmp33843 (car _%clause29067%_))
                                     (__tmp33842
                                      (_%prepare-atom29064%_ _%clause29067%_)))
                                 (declare (not safe))
                                 (##structure
                                  gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
                                  __tmp33843
                                  __tmp33842))))
                         _%body29056%_))
                   (_%getters29079%_
                    (map (lambda (_%term29071%_)
                           (if (let ()
                                 (declare (not safe))
                                 (gerbil-ascent/candidate/program#candidate-variable?
                                  _%term29071%_))
                               (let ((_%index29073%_
                                      (_%slot29062%_ _%term29071%_)))
                                 (lambda (_%frame29075%_)
                                   (if (_%bound?29063%_
                                        _%frame29075%_
                                        _%index29073%_)
                                       '#!void
                                       (let ()
                                         (declare (not safe))
                                         (error '"unbound positive proof head"
                                                _%term29071%_)))
                                   (vector-ref _%frame29075%_ _%index29073%_)))
                               (lambda (_%_frame29077%_) _%term29071%_)))
                         (cdr _%head29055%_))))
              (let ((__tmp33846
                     (lambda () (make-vector _%size29059%_ _%unbound29060%_)))
                    (__tmp33844
                     (lambda (_%frame29083%_)
                       (let ((__tmp33845
                              (lambda (_%$%g2908429086%_)
                                (_%$%g2908429086%_ _%frame29083%_))))
                         (declare (not safe))
                         (##map __tmp33845 _%getters29079%_)))))
                (declare (not safe))
                (##structure
                 gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
                 __tmp33846
                 __tmp33844
                 _%clauses29069%_)))))))))
