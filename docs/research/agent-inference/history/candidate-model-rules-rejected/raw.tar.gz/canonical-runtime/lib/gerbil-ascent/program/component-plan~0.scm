(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/component-plan::timestamp 1791687878)
  (begin
    (define gerbil-ascent/program/component-plan#positive-component::t
      (let ((__tmp35528 (list)) (__tmp35527 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/component-plan#positive-component::t
         'positive-component
         __tmp35528
         '(id members rules predecessors)
         __tmp35527
         '#f)))
    (define gerbil-ascent/program/component-plan#positive-component?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/component-plan#positive-component::t)))
    (define gerbil-ascent/program/component-plan#make-positive-component
      (lambda _%$args17938%_
        (apply make-instance
               gerbil-ascent/program/component-plan#positive-component::t
               _%$args17938%_)))
    (define gerbil-ascent/program/component-plan#positive-component-id
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/component-plan#positive-component::t
         'id)))
    (define gerbil-ascent/program/component-plan#positive-component-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/component-plan#positive-component::t
         'members)))
    (define gerbil-ascent/program/component-plan#positive-component-rules
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/component-plan#positive-component::t
         'rules)))
    (define gerbil-ascent/program/component-plan#positive-component-predecessors
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/component-plan#positive-component::t
         'predecessors)))
    (define gerbil-ascent/program/component-plan#positive-component-id-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/component-plan#positive-component::t
         'id)))
    (define gerbil-ascent/program/component-plan#positive-component-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/component-plan#positive-component::t
         'members)))
    (define gerbil-ascent/program/component-plan#positive-component-rules-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/component-plan#positive-component::t
         'rules)))
    (define gerbil-ascent/program/component-plan#positive-component-predecessors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/component-plan#positive-component::t
         'predecessors)))
    (define gerbil-ascent/program/component-plan#&positive-component-id
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/component-plan#positive-component::t
         'id)))
    (define gerbil-ascent/program/component-plan#&positive-component-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/component-plan#positive-component::t
         'members)))
    (define gerbil-ascent/program/component-plan#&positive-component-rules
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/component-plan#positive-component::t
         'rules)))
    (define gerbil-ascent/program/component-plan#&positive-component-predecessors
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/component-plan#positive-component::t
         'predecessors)))
    (define gerbil-ascent/program/component-plan#&positive-component-id-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/component-plan#positive-component::t
         'id)))
    (define gerbil-ascent/program/component-plan#&positive-component-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/component-plan#positive-component::t
         'members)))
    (define gerbil-ascent/program/component-plan#&positive-component-rules-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/component-plan#positive-component::t
         'rules)))
    (define gerbil-ascent/program/component-plan#&positive-component-predecessors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/component-plan#positive-component::t
         'predecessors)))
    (define gerbil-ascent/program/component-plan#publish-component-rule!
      (lambda (_%component17934%_ _%plan17935%_ _%pivots17936%_)
        (##structure-set!
         _%component17934%_
         (cons (vector _%plan17935%_ _%pivots17936%_)
               (##structure-ref
                _%component17934%_
                '3
                gerbil-ascent/program/component-plan#positive-component::t
                '#f))
         '3
         gerbil-ascent/program/component-plan#positive-component::t
         '#f)))
    (define gerbil-ascent/program/component-plan#project-component-rule!
      (lambda (_%rule17871%_ _%membership17872%_)
        (let ((_%full17874%_ (vector-ref _%rule17871%_ '5))
              (_%pivots17875%_ (vector-ref _%rule17871%_ '2)))
          (if (let ()
                (declare (not safe))
                (gerbil-ascent/core/positive-plan#gerbil-ascent-pure-positive-plan?
                 _%full17874%_))
              '#!void
              (let ()
                (declare (not safe))
                (error '"unsupported ASCENT positive SCC rule")))
          (letrec ((_%owner17877%_
                    (lambda (_%output17932%_)
                      (vector-ref
                       _%membership17872%_
                       (vector-ref (vector-ref _%output17932%_ '0) '0)))))
            (let* ((_%$%g1787817887%_ (vector-ref _%full17874%_ '0))
                   (_%$%E1788117891%_
                    (lambda ()
                      (let ()
                        (declare (not safe))
                        (error '"No clause matching"
                               _%$%g1787817887%_
                               '([])
                               '([first . rest])))
                      '#!void)))
              (let ((_%$%K1788517929%_ (lambda () '#!void))
                    (_%$%K1788217913%_
                     (lambda (_%rest17895%_ _%first17896%_)
                       (let ((_%component17898%_
                              (_%owner17877%_ _%first17896%_)))
                         (if (let ((__tmp35639
                                    (lambda (_%output17900%_)
                                      (eq? _%component17898%_
                                           (_%owner17877%_ _%output17900%_)))))
                               (declare (not safe))
                               (andmap__0 __tmp35639 _%rest17895%_))
                             (gerbil-ascent/program/component-plan#publish-component-rule!
                              _%component17898%_
                              _%full17874%_
                              _%pivots17875%_)
                             (let ((_%grouped17902%_
                                    (let ()
                                      (declare (not safe))
                                      (make-hash-table-eq))))
                               (for-each
                                (lambda (_%output17904%_)
                                  (let ((__tmp35641
                                         (_%owner17877%_ _%output17904%_))
                                        (__tmp35640
                                         (lambda (_%$%g1790517907%_)
                                           (cons _%output17904%_
                                                 _%$%g1790517907%_))))
                                    (declare (not safe))
                                    (__hash-update!__%
                                     _%grouped17902%_
                                     __tmp35641
                                     __tmp35640
                                     '())))
                                (vector-ref _%full17874%_ '0))
                               (let ((__tmp35642
                                      (lambda (_%component17910%_
                                               _%outputs17911%_)
                                        (gerbil-ascent/program/component-plan#publish-component-rule!
                                         _%component17910%_
                                         (let ((__tmp35643
                                                (reverse! _%outputs17911%_)))
                                           (declare (not safe))
                                           (gerbil-ascent/core/positive-plan#gerbil-ascent-positive-plan-with-outputs
                                            _%full17874%_
                                            __tmp35643))
                                         _%pivots17875%_))))
                                 (declare (not safe))
                                 (__hash-for-each
                                  __tmp35642
                                  _%grouped17902%_))))))))
                (let ((_%$%try-match1788017925%_
                       (lambda ()
                         (if (pair? _%$%g1787817887%_)
                             (let ((_%$%tl1788417918%_
                                    (let ()
                                      (declare (not safe))
                                      (##cdr _%$%g1787817887%_)))
                                   (_%$%hd1788317916%_
                                    (let ()
                                      (declare (not safe))
                                      (##car _%$%g1787817887%_))))
                               (let ((_%first17921%_ _%$%hd1788317916%_)
                                     (_%rest17923%_ _%$%tl1788417918%_))
                                 (_%$%K1788217913%_
                                  _%rest17923%_
                                  _%first17921%_)))
                             (_%$%E1788117891%_)))))
                  (if (null? _%$%g1787817887%_)
                      '#!void
                      (_%$%try-match1788017925%_)))))))))
    (define gerbil-ascent/program/component-plan#bitmap-first-visit!
      (lambda (_%bitmap17861%_ _%id17862%_)
        (let* ((_%byte17864%_ (quotient _%id17862%_ '8))
               (_%mask17866%_ (arithmetic-shift '1 (modulo _%id17862%_ '8)))
               (_%previous17868%_
                (u8vector-ref _%bitmap17861%_ _%byte17864%_)))
          (if (zero? (bitwise-and _%previous17868%_ _%mask17866%_))
              (begin
                (u8vector-set!
                 _%bitmap17861%_
                 _%byte17864%_
                 (bitwise-ior _%previous17868%_ _%mask17866%_))
                '#t)
              '#f))))
    (define gerbil-ascent/program/component-plan#predecessor-first-visit!
      (lambda (_%seen17846%_ _%target17847%_ _%id17848%_ _%first17849%_)
        (let ((_%members17851%_ (vector-ref _%seen17846%_ _%target17847%_)))
          (if _%members17851%_
              '#!void
              (begin
                (set! _%members17851%_
                      (let () (declare (not safe)) (make-hash-table-eqv)))
                (let ()
                  (declare (not safe))
                  (hash-put! _%members17851%_ _%first17849%_ '#t))
                (vector-set! _%seen17846%_ _%target17847%_ _%members17851%_)))
          (if (u8vector? _%members17851%_)
              (gerbil-ascent/program/component-plan#bitmap-first-visit!
               _%members17851%_
               _%id17848%_)
              (if (let ()
                    (declare (not safe))
                    (hash-get _%members17851%_ _%id17848%_))
                  '#f
                  (let ()
                    (let ()
                      (declare (not safe))
                      (hash-put! _%members17851%_ _%id17848%_ '#t))
                    (if (>= (let ()
                              (declare (not safe))
                              (hash-length _%members17851%_))
                            (max '32
                                 (quotient
                                  (vector-length _%seen17846%_)
                                  '128)))
                        (let ((_%bitmap17856%_
                               (make-u8vector
                                (quotient
                                 (+ (vector-length _%seen17846%_) '7)
                                 '8)
                                '0)))
                          (let ((__tmp35644
                                 (lambda (_%key17858%_ _%_17859%_)
                                   (gerbil-ascent/program/component-plan#bitmap-first-visit!
                                    _%bitmap17856%_
                                    _%key17858%_))))
                            (declare (not safe))
                            (hash-for-each __tmp35644 _%members17851%_))
                          (vector-set!
                           _%seen17846%_
                           _%target17847%_
                           _%bitmap17856%_))
                        '#!void)
                    '#t))))))
    (define gerbil-ascent/program/component-plan#register-component-predecessor!
      (lambda (_%from17836%_ _%to17837%_ _%seen17838%_)
        (if (eq? _%from17836%_ _%to17837%_)
            '#!void
            (let ((_%id17840%_
                   (##structure-ref
                    _%from17836%_
                    '1
                    gerbil-ascent/program/component-plan#positive-component::t
                    '#f))
                  (_%previous17841%_
                   (##structure-ref
                    _%to17837%_
                    '4
                    gerbil-ascent/program/component-plan#positive-component::t
                    '#f)))
              (if (and (pair? _%previous17841%_)
                       (eqv? _%id17840%_
                             (let ()
                               (declare (not safe))
                               (##car _%previous17841%_))))
                  '#!void
                  (if (or (null? _%previous17841%_)
                          (gerbil-ascent/program/component-plan#predecessor-first-visit!
                           _%seen17838%_
                           (##structure-ref
                            _%to17837%_
                            '1
                            gerbil-ascent/program/component-plan#positive-component::t
                            '#f)
                           _%id17840%_
                           (car _%previous17841%_)))
                      (##structure-set!
                       _%to17837%_
                       (cons _%id17840%_ _%previous17841%_)
                       '4
                       gerbil-ascent/program/component-plan#positive-component::t
                       '#f)
                      '#!void))))))
    (define gerbil-ascent/program/component-plan#+positive-components-cache+
      (let ((__tmp35645 (make-mutex 'ascent-positive-components)))
        (declare (not safe))
        (make-hash-table-eq 'weak-keys: '#t 'lock: __tmp35645)))
    (define gerbil-ascent/program/component-plan#gerbil-ascent-positive-components
      (lambda (_%analysis17829%_)
        (let ((_%$e17831%_
               (let ()
                 (declare (not safe))
                 (__hash-get
                  gerbil-ascent/program/component-plan#+positive-components-cache+
                  _%analysis17829%_))))
          (if _%$e17831%_
              _%$e17831%_
              (let ((_%fresh17834%_
                     (gerbil-ascent/program/component-plan#gerbil-ascent-compile-positive-components
                      _%analysis17829%_)))
                (let ()
                  (declare (not safe))
                  (__hash-put!
                   gerbil-ascent/program/component-plan#+positive-components-cache+
                   _%analysis17829%_
                   _%fresh17834%_))
                _%fresh17834%_)))))
    (define gerbil-ascent/program/component-plan#gerbil-ascent-component-mode?
      (lambda (_%session?17816%_
               _%workers17817%_
               _%canceled?17818%_
               _%analysis17819%_
               _%schema17820%_)
        (if _%session?17816%_
            '#f
            (if (or (> _%workers17817%_ '1) _%canceled?17818%_)
                (if (let ((__tmp35647
                           (lambda (_%rules17825%_)
                             (let ((__tmp35648
                                    (lambda (_%rule17827%_)
                                      (let ((__tmp35649
                                             (vector-ref _%rule17827%_ '5)))
                                        (declare (not safe))
                                        (gerbil-ascent/core/positive-plan#gerbil-ascent-pure-positive-plan?
                                         __tmp35649)))))
                               (declare (not safe))
                               (andmap__0 __tmp35648 _%rules17825%_))))
                          (__tmp35646
                           (vector->list (vector-ref _%analysis17819%_ '5))))
                      (declare (not safe))
                      (andmap__0 __tmp35647 __tmp35646))
                    (if (let ((__tmp35650
                               (vector->list (vector-ref _%schema17820%_ '9))))
                          (declare (not safe))
                          (andmap__0
                           gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                           __tmp35650))
                        (if (let ((__tmp35651
                                   (vector->list
                                    (vector-ref _%schema17820%_ '5))))
                              (declare (not safe))
                              (andmap__0
                               gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                               __tmp35651))
                            (if (let ((__tmp35652
                                       (vector->list
                                        (vector-ref _%schema17820%_ '7))))
                                  (declare (not safe))
                                  (andmap__0 not __tmp35652))
                                (let ((__tmp35653
                                       (vector->list
                                        (vector-ref _%schema17820%_ '3))))
                                  (declare (not safe))
                                  (andmap__0 not __tmp35653))
                                '#f)
                            '#f)
                        '#f)
                    '#f)
                '#f))))
    (define gerbil-ascent/program/component-plan#gerbil-ascent-compile-positive-components
      (lambda (_%analysis17784%_)
        (let* ((_%successors17786%_ (vector-ref _%analysis17784%_ '6))
               (_%count17788%_ (vector-length _%successors17786%_))
               (_%groups17790%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/core/dependency-graph#gerbil-ascent-graph-components
                   _%successors17786%_)))
               (_%membership17792%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count17788%_ '#f)))
               (_%components17797%_
                (let ((__tmp35656
                       (lambda (_%id17794%_ _%members17795%_)
                         (let ()
                           (declare (not safe))
                           (##structure
                            gerbil-ascent/program/component-plan#positive-component::t
                            _%id17794%_
                            _%members17795%_
                            '()
                            '()))))
                      (__tmp35654
                       (let ((__tmp35655
                              (let ()
                                (declare (not safe))
                                (##length _%groups17790%_))))
                         (declare (not safe))
                         (##iota __tmp35655))))
                  (declare (not safe))
                  (##map __tmp35656 __tmp35654 _%groups17790%_)))
               (_%predecessors-seen17799%_
                (let ((__tmp35657
                       (let ()
                         (declare (not safe))
                         (##length _%groups17790%_))))
                  (declare (not safe))
                  (##make-vector __tmp35657 '#f))))
          (let ((__tmp35658
                 (lambda (_%component17802%_)
                   (for-each
                    (lambda (_%relation17804%_)
                      (vector-set!
                       _%membership17792%_
                       _%relation17804%_
                       _%component17802%_))
                    (##structure-ref
                     _%component17802%_
                     '2
                     gerbil-ascent/program/component-plan#positive-component::t
                     '#f)))))
            (declare (not safe))
            (##for-each __tmp35658 _%components17797%_))
          (let ((__tmp35660
                 (lambda (_%rules17806%_)
                   (for-each
                    (lambda (_%$%g1780717809%_)
                      (gerbil-ascent/program/component-plan#project-component-rule!
                       _%$%g1780717809%_
                       _%membership17792%_))
                    _%rules17806%_)))
                (__tmp35659 (vector->list (vector-ref _%analysis17784%_ '5))))
            (declare (not safe))
            (##for-each __tmp35660 __tmp35659))
          (let ((__tmp35662
                 (lambda (_%source17812%_)
                   (for-each
                    (lambda (_%target17814%_)
                      (gerbil-ascent/program/component-plan#register-component-predecessor!
                       (vector-ref _%membership17792%_ _%source17812%_)
                       (vector-ref _%membership17792%_ _%target17814%_)
                       _%predecessors-seen17799%_))
                    (vector-ref _%successors17786%_ _%source17812%_))))
                (__tmp35661
                 (let () (declare (not safe)) (##iota _%count17788%_))))
            (declare (not safe))
            (##for-each __tmp35662 __tmp35661))
          _%components17797%_)))))
