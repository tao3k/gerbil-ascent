(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(define |gerbil-ascent/program/update-selection[:0:]#select-affected|
  (lambda (_%$stx13026%_)
    (let* ((_%$%g1303013059%_
            (lambda (_%$%g1303113055%_)
              (let ()
                (declare (not safe))
                (gx#raise-syntax-error
                 '#f
                 '"Bad syntax; invalid match target"
                 _%$%g1303113055%_))))
           (_%$%g1302913155%_
            (lambda (_%$%g1303113063%_)
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%$%g1303113063%_))
                  (let ((_%$%e1303613066%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%$%g1303113063%_))))
                    (let ((_%$%hd1303713070%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1303613066%_)))
                          (_%$%tl1303813073%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1303613066%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl1303813073%_))
                          (let ((_%$%e1303913076%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl1303813073%_))))
                            (let ((_%$%hd1304013080%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e1303913076%_)))
                                  (_%$%tl1304113083%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e1303913076%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%tl1304113083%_))
                                  (let ((_%$%e1304213086%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%tl1304113083%_))))
                                    (let ((_%$%hd1304313090%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e1304213086%_)))
                                          (_%$%tl1304413093%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e1304213086%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl1304413093%_))
                                          (let ((_%$%e1304513096%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl1304413093%_))))
                                            (let ((_%$%hd1304613100%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e1304513096%_)))
                                                  (_%$%tl1304713103%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e1304513096%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%hd1304613100%_))
                                                  (let ((_%$%e1304813106%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%hd1304613100%_))))
                                                    (let ((_%$%hd1304913110%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e1304813106%_)))
                                                          (_%$%tl1305013113%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e1304813106%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-pair?
                                                             _%$%tl1305013113%_))
                                                          (let ((_%$%e1305113116%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%$%tl1305013113%_))))
                    (let ((_%$%hd1305213120%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1305113116%_)))
                          (_%$%tl1305313123%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1305113116%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-null? _%$%tl1305313123%_))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-null? _%$%tl1304713103%_))
                              (cons (let ()
                                      (declare (not safe))
                                      (gx#datum->syntax__0 '#f 'let))
                                    (cons (cons (cons (let ()
                                                        (declare (not safe))
                                                        (gx#datum->syntax__0
                                                         '#f
                                                         'bitmap))
                                                      (cons _%$%hd1304013080%_
                                                            '()))
                                                (cons (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'source))
                                                            (cons _%$%hd1304313090%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          '()))
              '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                          (cons (cons (let ()
                                                        (declare (not safe))
                                                        (gx#datum->syntax__0
                                                         '#f
                                                         'def))
                                                      (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (declare (not safe))
                            (gx#datum->syntax__0 '#f 'keep?))
                          (cons _%$%hd1304913110%_ '()))
                    (cons (cons (let ()
                                  (declare (not safe))
                                  (gx#datum->syntax__0 '#f 'vector-ref))
                                (cons (let ()
                                        (declare (not safe))
                                        (gx#datum->syntax__0 '#f 'bitmap))
                                      (cons _%$%hd1305213120%_ '())))
                          '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (cons (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'let))
                                                            (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (declare (not safe))
                            (gx#datum->syntax__0 '#f 'scan))
                          (cons (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'remaining))
                                            (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'source))
                                                  '()))
                                      '())
                                (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0 '#f 'match))
                                            (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'remaining))
                                                  (cons (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f '@list))
                            '())
                      (cons (let ()
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'source))
                            '()))
                (cons (cons (cons (let ()
                                    (declare (not safe))
                                    (gx#datum->syntax__0 '#f '@list))
                                  (cons _%$%hd1304913110%_
                                        (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'rest))))
                            (cons (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'cond))
                                        (cons (cons (cons (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#datum->syntax__0
                                                             '#f
                                                             'keep?))
                                                          (cons _%$%hd1304913110%_
                                                                '()))
                                                    (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'scan))
                        (cons (let ()
                                (declare (not safe))
                                (gx#datum->syntax__0 '#f 'rest))
                              '()))
                  '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (cons (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'eq?))
                        (cons (let ()
                                (declare (not safe))
                                (gx#datum->syntax__0 '#f 'remaining))
                              (cons (let ()
                                      (declare (not safe))
                                      (gx#datum->syntax__0 '#f 'source))
                                    '())))
                  (cons (cons (let ()
                                (declare (not safe))
                                (gx#datum->syntax__0 '#f 'filter))
                              (cons (let ()
                                      (declare (not safe))
                                      (gx#datum->syntax__0 '#f 'keep?))
                                    (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0 '#f 'rest))
                                          '())))
                        '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'else))
                        (cons (cons (let ()
                                      (declare (not safe))
                                      (gx#datum->syntax__0
                                       '#f
                                       'with-list-builder))
                                    (cons (cons (let ()
                                                  (declare (not safe))
                                                  (gx#datum->syntax__0
                                                   '#f
                                                   'collect))
                                                '())
                                          (cons (cons (let ()
                                                        (declare (not safe))
                                                        (gx#datum->syntax__0
                                                         '#f
                                                         'let))
                                                      (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'prefix))
                                                            (cons (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                        (declare (not safe))
                                        (gx#datum->syntax__0 '#f 'pending))
                                      (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'source))
                                            '()))
                                '())
                          (cons (cons (let ()
                                        (declare (not safe))
                                        (gx#datum->syntax__0 '#f 'unless))
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'eq?))
                                                  (cons (let ()
                                                          (declare (not safe))
                                                          (gx#datum->syntax__0
                                                           '#f
                                                           'pending))
                                                        (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'remaining))
                      '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (cons (cons (let ()
                                                          (declare (not safe))
                                                          (gx#datum->syntax__0
                                                           '#f
                                                           'collect))
                                                        (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'car))
                            (cons (let ()
                                    (declare (not safe))
                                    (gx#datum->syntax__0 '#f 'pending))
                                  '()))
                      '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'prefix))
                      (cons (cons (let ()
                                    (declare (not safe))
                                    (gx#datum->syntax__0 '#f 'cdr))
                                  (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'pending))
                                        '()))
                            '()))
                '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (cons (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'for-each))
                                                            (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                  (declare (not safe))
                                  (gx#datum->syntax__0 '#f 'lambda))
                                (cons (cons _%$%hd1304913110%_ '())
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'when))
                                                  (cons (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'keep?))
                      (cons _%$%hd1304913110%_ '()))
                (cons (cons (let ()
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'collect))
                            (cons _%$%hd1304913110%_ '()))
                      '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            '())))
                          (cons (let ()
                                  (declare (not safe))
                                  (gx#datum->syntax__0 '#f 'rest))
                                '())))
              '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                              '()))
                  '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                  '()))
                      '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                      '()))))
              '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                              (_%$%g1303013059%_ _%$%g1303113063%_))
                          (_%$%g1303013059%_ _%$%g1303113063%_))))
                  (_%$%g1303013059%_ _%$%g1303113063%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%$%g1303013059%_
                                                   _%$%g1303113063%_))))
                                          (_%$%g1303013059%_
                                           _%$%g1303113063%_))))
                                  (_%$%g1303013059%_ _%$%g1303113063%_))))
                          (_%$%g1303013059%_ _%$%g1303113063%_))))
                  (_%$%g1303013059%_ _%$%g1303113063%_)))))
      (_%$%g1302913155%_ _%$stx13026%_))))
