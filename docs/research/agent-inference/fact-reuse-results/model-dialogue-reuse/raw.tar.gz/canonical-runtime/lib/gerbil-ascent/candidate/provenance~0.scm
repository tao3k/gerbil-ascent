(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/provenance::timestamp 1791693098)
  (begin
    (define gerbil-ascent/candidate/provenance#positive-proof::t
      (let ((__tmp33958 (list)) (__tmp33957 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/provenance#positive-proof::t
         'positive-proof
         __tmp33958
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  query
                  work-budget
                  nodes
                  roots)
         __tmp33957
         '#f)))
    (define gerbil-ascent/candidate/provenance#positive-proof?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/provenance#positive-proof::t)))
    (define gerbil-ascent/candidate/provenance#make-positive-proof
      (lambda _%$args29733%_
        (apply make-instance
               gerbil-ascent/candidate/provenance#positive-proof::t
               _%$args29733%_)))
    (define gerbil-ascent/candidate/provenance#positive-proof-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'status)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/provenance#positive-proof-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/provenance#positive-proof-query
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'query)))
    (define gerbil-ascent/candidate/provenance#positive-proof-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'work-budget)))
    (define gerbil-ascent/candidate/provenance#positive-proof-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#positive-proof-roots
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'roots)))
    (define gerbil-ascent/candidate/provenance#positive-proof-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'status)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/provenance#positive-proof-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/provenance#positive-proof-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/provenance#positive-proof-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'query)))
    (define gerbil-ascent/candidate/provenance#positive-proof-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'work-budget)))
    (define gerbil-ascent/candidate/provenance#positive-proof-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#positive-proof-roots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'roots)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'status)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-query
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'query)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'work-budget)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-roots
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-proof::t
         'roots)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'status)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'query)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'work-budget)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#&positive-proof-roots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-proof::t
         'roots)))
    (define gerbil-ascent/candidate/provenance#proof-node::t
      (let ((__tmp33960 (list)) (__tmp33959 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/provenance#proof-node::t
         'proof-node
         __tmp33960
         '(id kind relation row label inputs)
         __tmp33959
         '#f)))
    (define gerbil-ascent/candidate/provenance#proof-node?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/provenance#proof-node::t)))
    (define gerbil-ascent/candidate/provenance#make-proof-node
      (lambda _%$args29730%_
        (apply make-instance
               gerbil-ascent/candidate/provenance#proof-node::t
               _%$args29730%_)))
    (define gerbil-ascent/candidate/provenance#proof-node-id
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'id)))
    (define gerbil-ascent/candidate/provenance#proof-node-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'kind)))
    (define gerbil-ascent/candidate/provenance#proof-node-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#proof-node-row
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'row)))
    (define gerbil-ascent/candidate/provenance#proof-node-label
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'label)))
    (define gerbil-ascent/candidate/provenance#proof-node-inputs
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'inputs)))
    (define gerbil-ascent/candidate/provenance#proof-node-id-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'id)))
    (define gerbil-ascent/candidate/provenance#proof-node-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'kind)))
    (define gerbil-ascent/candidate/provenance#proof-node-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#proof-node-row-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'row)))
    (define gerbil-ascent/candidate/provenance#proof-node-label-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'label)))
    (define gerbil-ascent/candidate/provenance#proof-node-inputs-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'inputs)))
    (define gerbil-ascent/candidate/provenance#&proof-node-id
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'id)))
    (define gerbil-ascent/candidate/provenance#&proof-node-kind
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'kind)))
    (define gerbil-ascent/candidate/provenance#&proof-node-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#&proof-node-row
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'row)))
    (define gerbil-ascent/candidate/provenance#&proof-node-label
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'label)))
    (define gerbil-ascent/candidate/provenance#&proof-node-inputs
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-node::t
         'inputs)))
    (define gerbil-ascent/candidate/provenance#&proof-node-id-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'id)))
    (define gerbil-ascent/candidate/provenance#&proof-node-kind-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'kind)))
    (define gerbil-ascent/candidate/provenance#&proof-node-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#&proof-node-row-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'row)))
    (define gerbil-ascent/candidate/provenance#&proof-node-label-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'label)))
    (define gerbil-ascent/candidate/provenance#&proof-node-inputs-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-node::t
         'inputs)))
    (define gerbil-ascent/candidate/provenance#proof-relation::t
      (let ((__tmp33962 (list)) (__tmp33961 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/provenance#proof-relation::t
         'proof-relation
         __tmp33962
         '(nodes tail members)
         __tmp33961
         '#f)))
    (define gerbil-ascent/candidate/provenance#proof-relation?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/provenance#proof-relation::t)))
    (define gerbil-ascent/candidate/provenance#make-proof-relation
      (lambda _%$args29727%_
        (apply make-instance
               gerbil-ascent/candidate/provenance#proof-relation::t
               _%$args29727%_)))
    (define gerbil-ascent/candidate/provenance#proof-relation-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#proof-relation-tail
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'tail)))
    (define gerbil-ascent/candidate/provenance#proof-relation-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'members)))
    (define gerbil-ascent/candidate/provenance#proof-relation-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#proof-relation-tail-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'tail)))
    (define gerbil-ascent/candidate/provenance#proof-relation-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'members)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-tail
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'tail)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#proof-relation::t
         'members)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'nodes)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-tail-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'tail)))
    (define gerbil-ascent/candidate/provenance#&proof-relation-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#proof-relation::t
         'members)))
    (define gerbil-ascent/candidate/provenance#positive-atom?
      (lambda (_%atom29725%_)
        (if (pair? _%atom29725%_)
            (if (symbol? (let () (declare (not safe)) (##car _%atom29725%_)))
                (not (let ((__tmp33963
                            (let ()
                              (declare (not safe))
                              (##car _%atom29725%_))))
                       (declare (not safe))
                       (##memq __tmp33963 '(not where compute reduce))))
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/provenance#positive-fixed-clause?
      (lambda (_%clause29714%_)
        (if (list? _%clause29714%_)
            (if (pair? _%clause29714%_)
                (let ((_%$e29716%_
                       (let () (declare (not safe)) (##car _%clause29714%_))))
                  (if (eq? 'where _%$e29716%_)
                      (if (= (let ()
                               (declare (not safe))
                               (##length _%clause29714%_))
                             '2)
                          (if (list? (cadr _%clause29714%_))
                              (if (pair? (cadr _%clause29714%_))
                                  (let ((_%$e29719%_ (caadr _%clause29714%_)))
                                    (if (eq? 'even? _%$e29719%_)
                                        (= (length (cadr _%clause29714%_)) '2)
                                        (if (eq? '< _%$e29719%_)
                                            (= (length (cadr _%clause29714%_))
                                               '3)
                                            '#f)))
                                  '#f)
                              '#f)
                          '#f)
                      (if (eq? 'compute _%$e29716%_)
                          (if (= (let ()
                                   (declare (not safe))
                                   (##length _%clause29714%_))
                                 '3)
                              (if (let ((__tmp33964 (cadr _%clause29714%_)))
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/program#candidate-variable?
                                     __tmp33964))
                                  (if (list? (caddr _%clause29714%_))
                                      (if (pair? (caddr _%clause29714%_))
                                          (let ((_%$e29722%_
                                                 (caaddr _%clause29714%_)))
                                            (if (eq? 'identity _%$e29722%_)
                                                (= (length (caddr _%clause29714%_))
                                                   '2)
                                                (if (eq? '+ _%$e29722%_)
                                                    (= (length (caddr _%clause29714%_))
                                                       '3)
                                                    '#f)))
                                          '#f)
                                      '#f)
                                  '#f)
                              '#f)
                          '#f)))
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/provenance#positive-rule-body?
      (lambda (_%rule29707%_)
        (let ((__tmp33966
               (lambda (_%clause29709%_)
                 (let ((_%$e29711%_
                        (gerbil-ascent/candidate/provenance#positive-atom?
                         _%clause29709%_)))
                   (if _%$e29711%_
                       _%$e29711%_
                       (gerbil-ascent/candidate/provenance#positive-fixed-clause?
                        _%clause29709%_)))))
              (__tmp33965 (vector-ref _%rule29707%_ '1)))
          (declare (not safe))
          (andmap__0 __tmp33966 __tmp33965))))
    (define gerbil-ascent/candidate/provenance#positive-rules?
      (lambda (_%spec29705%_)
        (let ((__tmp33967
               (##structure-ref
                _%spec29705%_
                '3
                gerbil-ascent/candidate/types#reasoning-candidate::t
                '#f)))
          (declare (not safe))
          (andmap__0
           gerbil-ascent/candidate/provenance#positive-rule-body?
           __tmp33967))))
    (define gerbil-ascent/candidate/provenance#candidate-positive-proof/option
      (lambda (_%snapshot29529%_
               _%spec29530%_
               _%candidate-digest29531%_
               _%native-status29532%_
               _%native-rows29533%_
               _%max-steps29534%_
               _%retain-closed-absence?29535%_)
        (if (and (exact-integer? _%max-steps29534%_) (> _%max-steps29534%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid positive proof work budget"
                     _%max-steps29534%_)))
        (let ((_%query29537%_
               (vector-ref
                (##structure-ref
                 _%spec29530%_
                 '4
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f)
                '0)))
          (letrec ((_%result29539%_
                    (lambda (_%status29701%_ _%nodes29702%_ _%roots29703%_)
                      (let ((__tmp33971
                             (##structure-ref
                              _%snapshot29529%_
                              '1
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp33970
                             (##structure-ref
                              _%snapshot29529%_
                              '2
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp33969
                             (##structure-ref
                              _%snapshot29529%_
                              '3
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp33968
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                _%query29537%_))))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/provenance#positive-proof::t
                         _%status29701%_
                         __tmp33971
                         __tmp33970
                         __tmp33969
                         _%candidate-digest29531%_
                         __tmp33968
                         _%max-steps29534%_
                         _%nodes29702%_
                         _%roots29703%_)))))
            (if (or (not (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                            _%snapshot29529%_)))
                    (not (eq? _%native-status29532%_ 'complete))
                    (not (gerbil-ascent/candidate/provenance#positive-rules?
                          _%spec29530%_)))
                (_%result29539%_ 'unsupported '() '())
                (let ((_%index29547%_
                       (let ()
                         (declare (not safe))
                         (make-hash-table__%
                          '#f
                          absent-value
                          absent-value
                          absent-value
                          absent-value
                          absent-value
                          absent-value
                          absent-value
                          absent-value)))
                      (_%plans29548%_
                       (map gerbil-ascent/candidate/grounding-plan#prepare-grounding-rule
                            (##structure-ref
                             _%spec29530%_
                             '3
                             gerbil-ascent/candidate/types#reasoning-candidate::t
                             '#f)))
                      (_%query-match29549%_
                       (let ()
                         (declare (not safe))
                         (gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
                          _%query29537%_)))
                      (_%nodes29550%_ '())
                      (_%next-id29551%_ '0)
                      (_%derived-count29552%_ '0)
                      (_%steps29553%_ '0)
                      (_%material29554%_
                       (if _%retain-closed-absence?29535%_
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/candidate/certificate-limits#make-certificate-material-budget))
                           '#f))
                      (_%bounded?29555%_ '#f)
                      (_%derived-limit29556%_
                       (cadr (##structure-ref
                              _%spec29530%_
                              '5
                              gerbil-ascent/candidate/types#reasoning-candidate::t
                              '#f))))
                  (letrec ((_%facts29558%_
                            (lambda (_%name29697%_)
                              (let ((_%relation29699%_
                                     (let ()
                                       (declare (not safe))
                                       (__hash-get
                                        _%index29547%_
                                        _%name29697%_))))
                                (if _%relation29699%_
                                    (##structure-ref
                                     _%relation29699%_
                                     '1
                                     gerbil-ascent/candidate/provenance#proof-relation::t
                                     '#f)
                                    '()))))
                           (_%active?29559%_
                            (lambda () (not _%bounded?29555%_)))
                           (_%known?29560%_
                            (lambda (_%name29691%_ _%row29692%_)
                              (let ((_%relation29694%_
                                     (let ()
                                       (declare (not safe))
                                       (__hash-get
                                        _%index29547%_
                                        _%name29691%_))))
                                (if _%relation29694%_
                                    (let ((__tmp33972
                                           (##structure-ref
                                            _%relation29694%_
                                            '3
                                            gerbil-ascent/candidate/provenance#proof-relation::t
                                            '#f)))
                                      (declare (not safe))
                                      (hash-get __tmp33972 _%row29692%_))
                                    '#f))))
                           (_%reserve-row!29561%_
                            (lambda (_%row29683%_)
                              (let ((_%$e29685%_ (not _%material29554%_)))
                                (if _%$e29685%_
                                    _%$e29685%_
                                    (let ((_%$e29688%_
                                           (let ()
                                             (declare (not safe))
                                             (gerbil-ascent/candidate/certificate-limits#certificate-material-reserve!
                                              _%material29554%_
                                              _%row29683%_))))
                                      (if _%$e29688%_
                                          _%$e29688%_
                                          (begin
                                            (set! _%bounded?29555%_ '#t)
                                            '#f)))))))
                           (_%install!29562%_
                            (lambda (_%node29669%_)
                              (let* ((_%name29671%_
                                      (##structure-ref
                                       _%node29669%_
                                       '3
                                       gerbil-ascent/candidate/provenance#proof-node::t
                                       '#f))
                                     (_%relation29678%_
                                      (let ((_%$e29673%_
                                             (let ()
                                               (declare (not safe))
                                               (__hash-get
                                                _%index29547%_
                                                _%name29671%_))))
                                        (if _%$e29673%_
                                            _%$e29673%_
                                            (let ((_%owned29676%_
                                                   (let ((__tmp33973
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (make-hash-table__%
                                                             '#f
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value
                                                             absent-value))))
                                                     (declare (not safe))
                                                     (##structure
                                                      gerbil-ascent/candidate/provenance#proof-relation::t
                                                      '()
                                                      '#f
                                                      __tmp33973))))
                                              (let ()
                                                (declare (not safe))
                                                (__hash-put!
                                                 _%index29547%_
                                                 _%name29671%_
                                                 _%owned29676%_))
                                              _%owned29676%_))))
                                     (_%cell29680%_ (list _%node29669%_)))
                                (if (##structure-ref
                                     _%relation29678%_
                                     '2
                                     gerbil-ascent/candidate/provenance#proof-relation::t
                                     '#f)
                                    (set-cdr!
                                     (##structure-ref
                                      _%relation29678%_
                                      '2
                                      gerbil-ascent/candidate/provenance#proof-relation::t
                                      '#f)
                                     _%cell29680%_)
                                    (##structure-set!
                                     _%relation29678%_
                                     _%cell29680%_
                                     '1
                                     gerbil-ascent/candidate/provenance#proof-relation::t
                                     '#f))
                                (##structure-set!
                                 _%relation29678%_
                                 _%cell29680%_
                                 '2
                                 gerbil-ascent/candidate/provenance#proof-relation::t
                                 '#f)
                                (let ((__tmp33975
                                       (##structure-ref
                                        _%relation29678%_
                                        '3
                                        gerbil-ascent/candidate/provenance#proof-relation::t
                                        '#f))
                                      (__tmp33974
                                       (##structure-ref
                                        _%node29669%_
                                        '4
                                        gerbil-ascent/candidate/provenance#proof-node::t
                                        '#f)))
                                  (declare (not safe))
                                  (hash-put!
                                   __tmp33975
                                   __tmp33974
                                   _%node29669%_))
                                (set! _%nodes29550%_
                                      (cons _%node29669%_ _%nodes29550%_)))))
                           (_%add!29563%_
                            (lambda (_%kind29661%_
                                     _%name29662%_
                                     _%row29663%_
                                     _%label29664%_
                                     _%inputs29665%_)
                              (if (if _%bounded?29555%_
                                      '#f
                                      (if (_%known?29560%_
                                           _%name29662%_
                                           _%row29663%_)
                                          '#f
                                          (_%reserve-row!29561%_
                                           _%row29663%_)))
                                  (let ((_%node29667%_
                                         (let ((__tmp33977
                                                (let ()
                                                  (declare (not safe))
                                                  (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                                   _%row29663%_)))
                                               (__tmp33976
                                                (let ()
                                                  (declare (not safe))
                                                  (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                                   _%inputs29665%_))))
                                           (declare (not safe))
                                           (##structure
                                            gerbil-ascent/candidate/provenance#proof-node::t
                                            _%next-id29551%_
                                            _%kind29661%_
                                            _%name29662%_
                                            __tmp33977
                                            _%label29664%_
                                            __tmp33976))))
                                    (set! _%next-id29551%_
                                          (+ _%next-id29551%_ '1))
                                    (_%install!29562%_ _%node29667%_))
                                  '#!void))))
                    (let ((__tmp33979
                           (lambda (_%entry29565%_)
                             (let ((_%position29567%_ '0))
                               (let ((__tmp33981
                                      (lambda (_%row29569%_)
                                        (set! _%position29567%_
                                              (+ _%position29567%_ '1))
                                        (_%add!29563%_
                                         'source
                                         (car _%entry29565%_)
                                         _%row29569%_
                                         _%position29567%_
                                         '())))
                                     (__tmp33980 (caddr _%entry29565%_)))
                                 (declare (not safe))
                                 (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                                  _%active?29559%_
                                  __tmp33981
                                  __tmp33980)))))
                          (__tmp33978
                           (##structure-ref
                            _%snapshot29529%_
                            '4
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f)))
                      (declare (not safe))
                      (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                       _%active?29559%_
                       __tmp33979
                       __tmp33978))
                    (let ((__tmp33983
                           (lambda (_%fact29571%_)
                             (_%add!29563%_
                              'candidate
                              (vector-ref _%fact29571%_ '0)
                              (vector-ref _%fact29571%_ '1)
                              (vector-ref _%fact29571%_ '2)
                              '())))
                          (__tmp33982
                           (##structure-ref
                            _%spec29530%_
                            '2
                            gerbil-ascent/candidate/types#reasoning-candidate::t
                            '#f)))
                      (declare (not safe))
                      (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                       _%active?29559%_
                       __tmp33983
                       __tmp33982))
                    (let _%saturate29573%_ ()
                      (let ((_%pending29576%_ '())
                            (_%pending-count29577%_ '0)
                            (_%pending-index29578%_ '#f))
                        (let ((__tmp33984
                               (lambda (_%rule29580%_)
                                 (let ((_%rule29583%_ _%rule29580%_))
                                   (let ((_%name29600%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%rule29583%_
                                             '1
                                             '#f
                                             '#f)))
                                         (_%render29601%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%rule29583%_
                                             '2
                                             '#f
                                             '#f)))
                                         (_%body29602%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%rule29583%_
                                             '3
                                             '#f
                                             '#f)))
                                         (_%label29603%_
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%rule29583%_
                                             '4
                                             '#f
                                             '#f))))
                                     (letrec ((_%walk29605%_
                                               (lambda (_%remaining29607%_
                                                        _%bindings29608%_
                                                        _%inputs29609%_)
                                                 (if _%bounded?29555%_
                                                     '#!void
                                                     (if (null? _%remaining29607%_)
                                                         (let ((_%row29611%_
                                                                (_%render29601%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%bindings29608%_)))
                   (if (or (_%known?29560%_ _%name29600%_ _%row29611%_)
                           (let ((_%members29616%_
                                  (and _%pending-index29578%_
                                       (let ()
                                         (declare (not safe))
                                         (hash-get
                                          _%pending-index29578%_
                                          _%name29600%_)))))
                             (and _%members29616%_
                                  (let ()
                                    (declare (not safe))
                                    (hash-get
                                     _%members29616%_
                                     _%row29611%_)))))
                       '#!void
                       (begin
                         (if (>= (+ _%derived-count29552%_
                                    _%pending-count29577%_)
                                 _%derived-limit29556%_)
                             (set! _%bounded?29555%_ '#t)
                             '#!void)
                         (if (if _%bounded?29555%_
                                 '#f
                                 (_%reserve-row!29561%_ _%row29611%_))
                             (let* ((_%node29618%_
                                     (let ((__tmp33987
                                            (+ _%next-id29551%_
                                               _%pending-count29577%_))
                                           (__tmp33986
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                               _%row29611%_)))
                                           (__tmp33985
                                            (reverse _%inputs29609%_)))
                                       (declare (not safe))
                                       (##structure
                                        gerbil-ascent/candidate/provenance#proof-node::t
                                        __tmp33987
                                        'rule
                                        _%name29600%_
                                        __tmp33986
                                        _%label29603%_
                                        __tmp33985)))
                                    (_%members29625%_
                                     (let ((_%$e29620%_
                                            (if _%pending-index29578%_
                                                (let ()
                                                  (declare (not safe))
                                                  (hash-get
                                                   _%pending-index29578%_
                                                   _%name29600%_))
                                                '#f)))
                                       (if _%$e29620%_
                                           _%$e29620%_
                                           (let ((_%table29623%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (make-hash-table__%
                                                     '#f
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value))))
                                             (if _%pending-index29578%_
                                                 '#!void
                                                 (set! _%pending-index29578%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (make-hash-table-eq))))
                                             (let ()
                                               (declare (not safe))
                                               (hash-put!
                                                _%pending-index29578%_
                                                _%name29600%_
                                                _%table29623%_))
                                             _%table29623%_)))))
                               (let ((__tmp33988
                                      (let ()
                                        (declare (not safe))
                                        (##unchecked-structure-ref
                                         _%node29618%_
                                         '4
                                         '#f
                                         '#f))))
                                 (declare (not safe))
                                 (hash-put!
                                  _%members29625%_
                                  __tmp33988
                                  _%node29618%_))
                               (set! _%pending29576%_
                                     (cons _%node29618%_ _%pending29576%_))
                               (set! _%pending-count29577%_
                                     (+ _%pending-count29577%_ '1)))
                             '#!void))))
                 (let* ((_%clause29628%_ (car _%remaining29607%_))
                        (_%clause29630%_ _%clause29628%_))
                   (if (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%clause29630%_
                          '1
                          '#f
                          '#f))
                       (let ((__tmp33990
                              (lambda (_%node29645%_)
                                (if _%bounded?29555%_
                                    '#!void
                                    (begin
                                      (set! _%steps29553%_
                                            (+ _%steps29553%_ '1))
                                      (if (> _%steps29553%_ _%max-steps29534%_)
                                          (set! _%bounded?29555%_ '#t)
                                          (let ((_%next29647%_
                                                 ((let ()
                                                    (declare (not safe))
                                                    (##unchecked-structure-ref
                                                     _%clause29630%_
                                                     '2
                                                     '#f
                                                     '#f))
                                                  (##structure-ref
                                                   _%node29645%_
                                                   '4
                                                   gerbil-ascent/candidate/provenance#proof-node::t
                                                   '#f)
                                                  _%bindings29608%_)))
                                            (if _%next29647%_
                                                (_%walk29605%_
                                                 (cdr _%remaining29607%_)
                                                 _%next29647%_
                                                 (cons (##structure-ref
                                                        _%node29645%_
                                                        '1
                                                        gerbil-ascent/candidate/provenance#proof-node::t
                                                        '#f)
                                                       _%inputs29609%_))
                                                '#!void)))))))
                             (__tmp33989
                              (_%facts29558%_
                               (let ()
                                 (declare (not safe))
                                 (##unchecked-structure-ref
                                  _%clause29630%_
                                  '1
                                  '#f
                                  '#f)))))
                         (declare (not safe))
                         (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                          _%active?29559%_
                          __tmp33990
                          __tmp33989))
                       (begin
                         (set! _%steps29553%_ (+ _%steps29553%_ '1))
                         (if (> _%steps29553%_ _%max-steps29534%_)
                             (set! _%bounded?29555%_ '#t)
                             (let ((_%next29643%_
                                    ((let ()
                                       (declare (not safe))
                                       (##unchecked-structure-ref
                                        _%clause29630%_
                                        '2
                                        '#f
                                        '#f))
                                     _%bindings29608%_)))
                               (if _%next29643%_
                                   (_%walk29605%_
                                    (cdr _%remaining29607%_)
                                    _%next29643%_
                                    _%inputs29609%_)
                                   '#!void)))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                       (_%walk29605%_
                                        _%body29602%_
                                        '()
                                        '())))))))
                          (declare (not safe))
                          (gerbil-ascent/candidate/certificate-limits#certificate-for-each-while
                           _%active?29559%_
                           __tmp33984
                           _%plans29548%_))
                        (if _%bounded?29555%_
                            (_%result29539%_ 'bounded '() '())
                            (if (null? _%pending29576%_)
                                (let* ((_%matching29651%_
                                        (filter (lambda (_%node29649%_)
                                                  (_%query-match29549%_
                                                   (##structure-ref
                                                    _%node29649%_
                                                    '4
                                                    gerbil-ascent/candidate/provenance#proof-node::t
                                                    '#f)
                                                   '()))
                                                (_%facts29558%_
                                                 (car _%query29537%_))))
                                       (_%rows29653%_
                                        (let ()
                                          (declare (not safe))
                                          (##map gerbil-ascent/candidate/provenance#proof-node-row
                                                 _%matching29651%_)))
                                       (_%roots29655%_
                                        (let ()
                                          (declare (not safe))
                                          (##map gerbil-ascent/candidate/provenance#proof-node-id
                                                 _%matching29651%_))))
                                  (if (and (pair? _%roots29655%_)
                                           (let ()
                                             (declare (not safe))
                                             (gerbil-ascent/candidate/funs#candidate-same-row-set?
                                              _%rows29653%_
                                              _%native-rows29533%_)))
                                      (_%result29539%_
                                       'complete
                                       (let ()
                                         (declare (not safe))
                                         (##reverse _%nodes29550%_))
                                       _%roots29655%_)
                                      (if (and _%retain-closed-absence?29535%_
                                               (null? _%roots29655%_)
                                               (null? _%native-rows29533%_))
                                          (_%result29539%_
                                           'closed-absent
                                           (let ()
                                             (declare (not safe))
                                             (##reverse _%nodes29550%_))
                                           '())
                                          (_%result29539%_
                                           'unsupported
                                           '()
                                           '()))))
                                (begin
                                  (let ((__tmp33991
                                         (let ()
                                           (declare (not safe))
                                           (##reverse _%pending29576%_))))
                                    (declare (not safe))
                                    (##for-each _%install!29562%_ __tmp33991))
                                  (set! _%next-id29551%_
                                        (+ _%next-id29551%_
                                           _%pending-count29577%_))
                                  (set! _%derived-count29552%_
                                        (+ _%derived-count29552%_
                                           _%pending-count29577%_))
                                  (_%saturate29573%_)))))))))))))
    (define gerbil-ascent/candidate/provenance#candidate-positive-proof
      (lambda (_%snapshot29522%_
               _%spec29523%_
               _%candidate-digest29524%_
               _%native-status29525%_
               _%native-rows29526%_
               _%max-steps29527%_)
        (gerbil-ascent/candidate/provenance#candidate-positive-proof/option
         _%snapshot29522%_
         _%spec29523%_
         _%candidate-digest29524%_
         _%native-status29525%_
         _%native-rows29526%_
         _%max-steps29527%_
         '#f)))
    (define gerbil-ascent/candidate/provenance#candidate-positive-closed-absence
      (lambda (_%snapshot29515%_
               _%spec29516%_
               _%candidate-digest29517%_
               _%native-status29518%_
               _%native-rows29519%_
               _%max-steps29520%_)
        (gerbil-ascent/candidate/provenance#candidate-positive-proof/option
         _%snapshot29515%_
         _%spec29516%_
         _%candidate-digest29517%_
         _%native-status29518%_
         _%native-rows29519%_
         _%max-steps29520%_
         '#t)))
    (define gerbil-ascent/candidate/provenance#proof-metadata-lookup
      (lambda (_%entries29463%_)
        (let* ((_%$%entries2946429474%_ _%entries29463%_)
               (_%$%else2946729488%_
                (lambda ()
                  (let ((_%index29482%_
                         (let ()
                           (declare (not safe))
                           (make-hash-table__%
                            '#f
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value))))
                    (for-each
                     (lambda (_%entry29484%_)
                       (if (let ((__tmp33992 (car _%entry29484%_)))
                             (declare (not safe))
                             (__hash-get _%index29482%_ __tmp33992))
                           '#!void
                           (let ((__tmp33994 (car _%entry29484%_))
                                 (__tmp33993 (cdr _%entry29484%_)))
                             (declare (not safe))
                             (__hash-put!
                              _%index29482%_
                              __tmp33994
                              __tmp33993))))
                     _%entries29463%_)
                    (lambda (_%key29486%_)
                      (let ()
                        (declare (not safe))
                        (__hash-get _%index29482%_ _%key29486%_)))))))
          (let ((_%$%K2947229512%_ (lambda () (lambda (_%_29510%_) '#f)))
                (_%$%K2946929496%_
                 (lambda (_%entry29492%_)
                   (lambda (_%key29494%_)
                     (if (equal? _%key29494%_ (car _%entry29492%_))
                         (cdr _%entry29492%_)
                         '#f)))))
            (let ((_%$%try-match2946629506%_
                   (lambda ()
                     (if (pair? _%$%entries2946429474%_)
                         (let ((_%$%tl2947129501%_
                                (let ()
                                  (declare (not safe))
                                  (##cdr _%$%entries2946429474%_)))
                               (_%$%hd2947029499%_
                                (let ()
                                  (declare (not safe))
                                  (##car _%$%entries2946429474%_))))
                           (if (null? _%$%tl2947129501%_)
                               (let ((_%entry29504%_ _%$%hd2947029499%_))
                                 (_%$%K2946929496%_ _%entry29504%_))
                               (_%$%else2946729488%_)))
                         (_%$%else2946729488%_)))))
              (if (null? _%$%entries2946429474%_)
                  (_%$%K2947229512%_)
                  (_%$%try-match2946629506%_)))))))
    (define gerbil-ascent/candidate/provenance#positive-rule-replay::t
      (let ((__tmp33996 (list))
            (__tmp33995
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'positive-rule-replay
         __tmp33996
         '(relation input-count execute)
         __tmp33995
         '#f)))
    (define gerbil-ascent/candidate/provenance#positive-rule-replay?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/provenance#positive-rule-replay::t)))
    (define gerbil-ascent/candidate/provenance#make-positive-rule-replay
      (lambda _%$args29460%_
        (apply make-instance
               gerbil-ascent/candidate/provenance#positive-rule-replay::t
               _%$args29460%_)))
    (define gerbil-ascent/candidate/provenance#positive-rule-replay-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#positive-rule-replay-input-count
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'input-count)))
    (define gerbil-ascent/candidate/provenance#positive-rule-replay-execute
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'execute)))
    (define gerbil-ascent/candidate/provenance#positive-rule-replay-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#positive-rule-replay-input-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'input-count)))
    (define gerbil-ascent/candidate/provenance#positive-rule-replay-execute-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'execute)))
    (define gerbil-ascent/candidate/provenance#&positive-rule-replay-relation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#&positive-rule-replay-input-count
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'input-count)))
    (define gerbil-ascent/candidate/provenance#&positive-rule-replay-execute
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'execute)))
    (define gerbil-ascent/candidate/provenance#&positive-rule-replay-relation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'relation)))
    (define gerbil-ascent/candidate/provenance#&positive-rule-replay-input-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'input-count)))
    (define gerbil-ascent/candidate/provenance#&positive-rule-replay-execute-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/provenance#positive-rule-replay::t
         'execute)))
    (define gerbil-ascent/candidate/provenance#prepare-positive-rule-replay
      (lambda (_%rule29367%_)
        (let* ((_%$%rule2936829376%_ _%rule29367%_)
               (_%$%E2937029379%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%rule2936829376%_
                           '(#(head body _))))
                  '#!void))
               (_%$%K2937129444%_
                (lambda (_%body29382%_ _%head29383%_)
                  (let* ((_%flow29385%_
                          (let ()
                            (declare (not safe))
                            (gerbil-ascent/candidate/proof-frame#prepare-proof-binding-flow
                             _%head29383%_
                             _%body29382%_)))
                         (_%render29387%_
                          (let ()
                            (declare (not safe))
                            (##unchecked-structure-ref
                             _%flow29385%_
                             '2
                             '#f
                             '#f)))
                         (_%fresh29389%_
                          (let ()
                            (declare (not safe))
                            (##unchecked-structure-ref
                             _%flow29385%_
                             '1
                             '#f
                             '#f)))
                         (_%replay29435%_
                          (let ((__tmp33999
                                 (lambda (_%clause29391%_ _%next29392%_)
                                   (let* ((_%clause29395%_ _%clause29391%_)
                                          (_%evaluate29411%_
                                           (let ()
                                             (declare (not safe))
                                             (##unchecked-structure-ref
                                              _%clause29395%_
                                              '2
                                              '#f
                                              '#f))))
                                     (if (let ()
                                           (declare (not safe))
                                           (##unchecked-structure-ref
                                            _%clause29395%_
                                            '1
                                            '#f
                                            '#f))
                                         (lambda (_%inputs29413%_
                                                  _%frame29414%_
                                                  _%by-id29415%_
                                                  _%before29416%_
                                                  _%row29417%_)
                                           (let ((_%id29419%_
                                                  (car _%inputs29413%_)))
                                             (if (exact-integer? _%id29419%_)
                                                 (if (<= '0 _%id29419%_)
                                                     (if (< _%id29419%_
                                                            _%before29416%_)
                                                         (let ((_%input29421%_
                                                                (vector-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%by-id29415%_
                         _%id29419%_)))
                   (if (eq? (##structure-ref
                             _%input29421%_
                             '3
                             gerbil-ascent/candidate/provenance#proof-node::t
                             '#f)
                            (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%clause29395%_
                               '1
                               '#f
                               '#f)))
                       (if (_%evaluate29411%_
                            (##structure-ref
                             _%input29421%_
                             '4
                             gerbil-ascent/candidate/provenance#proof-node::t
                             '#f)
                            _%frame29414%_)
                           (_%next29392%_
                            (cdr _%inputs29413%_)
                            _%frame29414%_
                            _%by-id29415%_
                            _%before29416%_
                            _%row29417%_)
                           '#f)
                       '#f))
                 '#f)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     '#f)
                                                 '#f)))
                                         (lambda (_%inputs29423%_
                                                  _%frame29424%_
                                                  _%by-id29425%_
                                                  _%before29426%_
                                                  _%row29427%_)
                                           (if (_%evaluate29411%_
                                                _%frame29424%_)
                                               (_%next29392%_
                                                _%inputs29423%_
                                                _%frame29424%_
                                                _%by-id29425%_
                                                _%before29426%_
                                                _%row29427%_)
                                               '#f))))))
                                (__tmp33998
                                 (lambda (_%inputs29429%_
                                          _%frame29430%_
                                          _%_by-id29431%_
                                          _%_before29432%_
                                          _%row29433%_)
                                   (if (null? _%inputs29429%_)
                                       (equal? _%row29433%_
                                               (_%render29387%_
                                                _%frame29430%_))
                                       '#f)))
                                (__tmp33997
                                 (let ()
                                   (declare (not safe))
                                   (##unchecked-structure-ref
                                    _%flow29385%_
                                    '3
                                    '#f
                                    '#f))))
                            (declare (not safe))
                            (foldr__0 __tmp33999 __tmp33998 __tmp33997))))
                    (let ((__tmp34003 (car _%head29383%_))
                          (__tmp34001
                           (let ((__tmp34002
                                  (filter gerbil-ascent/candidate/provenance#positive-atom?
                                          _%body29382%_)))
                             (declare (not safe))
                             (##length __tmp34002)))
                          (__tmp34000
                           (lambda (_%inputs29438%_
                                    _%_bindings29439%_
                                    _%by-id29440%_
                                    _%before29441%_
                                    _%row29442%_)
                             (_%replay29435%_
                              _%inputs29438%_
                              (_%fresh29389%_)
                              _%by-id29440%_
                              _%before29441%_
                              _%row29442%_))))
                      (declare (not safe))
                      (##structure
                       gerbil-ascent/candidate/provenance#positive-rule-replay::t
                       __tmp34003
                       __tmp34001
                       __tmp34000))))))
          (if (vector? _%$%rule2936829376%_)
              (if (let ((__tmp34004
                         (let ()
                           (declare (not safe))
                           (##vector-length _%$%rule2936829376%_))))
                    (declare (not safe))
                    (##fx= __tmp34004 '3))
                  (let* ((_%$%e2937229447%_
                          (let ()
                            (declare (not safe))
                            (##vector-ref _%$%rule2936829376%_ '0)))
                         (_%head29450%_ _%$%e2937229447%_)
                         (_%$%e2937329452%_
                          (let ()
                            (declare (not safe))
                            (##vector-ref _%$%rule2936829376%_ '1)))
                         (_%body29455%_ _%$%e2937329452%_)
                         (_%$%e2937429457%_
                          (let ()
                            (declare (not safe))
                            (##vector-ref _%$%rule2936829376%_ '2))))
                    (_%$%K2937129444%_ _%body29455%_ _%head29450%_))
                  (_%$%E2937029379%_))
              (_%$%E2937029379%_)))))
    (define gerbil-ascent/candidate/provenance#candidate-verify-positive-proof
      (lambda (_%snapshot29297%_
               _%spec29298%_
               _%candidate-digest29299%_
               _%native-status29300%_
               _%native-rows29301%_
               _%proof29302%_
               _%max-nodes29303%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%proof29302%_
               'gerbil-ascent/candidate/provenance#positive-proof::t))
            (if (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                   _%snapshot29297%_))
                (if (eq? (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%proof29302%_
                            '1
                            '#f
                            '#f))
                         'complete)
                    (if (eq? _%native-status29300%_ 'complete)
                        (if (gerbil-ascent/candidate/provenance#positive-rules?
                             _%spec29298%_)
                            (if (exact-integer? _%max-nodes29303%_)
                                (if (> _%max-nodes29303%_ '0)
                                    (if (equal? (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%proof29302%_
                                                   '2
                                                   '#f
                                                   '#f))
                                                (##structure-ref
                                                 _%snapshot29297%_
                                                 '1
                                                 gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                 '#f))
                                        (if (equal? (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%proof29302%_
                                                       '3
                                                       '#f
                                                       '#f))
                                                    (##structure-ref
                                                     _%snapshot29297%_
                                                     '2
                                                     gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                     '#f))
                                            (if (equal? (let ()
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           _%proof29302%_
                                                           '4
                                                           '#f
                                                           '#f))
                                                        (##structure-ref
                                                         _%snapshot29297%_
                                                         '3
                                                         gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                         '#f))
                                                (if (equal? (let ()
                                                              (declare
                                                                (not safe))
                                                              (##unchecked-structure-ref
                                                               _%proof29302%_
                                                               '5
                                                               '#f
                                                               '#f))
                                                            _%candidate-digest29299%_)
                                                    (if (equal? (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%proof29302%_
                           '6
                           '#f
                           '#f))
                        (vector-ref
                         (##structure-ref
                          _%spec29298%_
                          '4
                          gerbil-ascent/candidate/types#reasoning-candidate::t
                          '#f)
                         '0))
                (let* ((_%nodes29305%_
                        (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%proof29302%_
                           '8
                           '#f
                           '#f)))
                       (_%node-count29307%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                           _%nodes29305%_
                           _%max-nodes29303%_))))
                  (if _%node-count29307%_
                      (if (let ((__tmp34005
                                 (let ()
                                   (declare (not safe))
                                   (##unchecked-structure-ref
                                    _%proof29302%_
                                    '9
                                    '#f
                                    '#f))))
                            (declare (not safe))
                            (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                             __tmp34005
                             _%node-count29307%_))
                          (let* ((_%by-id29310%_
                                  (make-vector _%node-count29307%_ '#f))
                                 (_%arities29312%_
                                  (gerbil-ascent/candidate/provenance#proof-metadata-lookup
                                   (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/funs#candidate-schema-of
                                      _%snapshot29297%_
                                      _%spec29298%_))))
                                 (_%source29314%_
                                  (##structure-ref
                                   _%snapshot29297%_
                                   '4
                                   gerbil-ascent/candidate/types#reasoning-snapshot::t
                                   '#f))
                                 (_%facts29316%_
                                  (##structure-ref
                                   _%spec29298%_
                                   '2
                                   gerbil-ascent/candidate/types#reasoning-candidate::t
                                   '#f))
                                 (_%rules29318%_
                                  (##structure-ref
                                   _%spec29298%_
                                   '3
                                   gerbil-ascent/candidate/types#reasoning-candidate::t
                                   '#f))
                                 (_%query29320%_
                                  (let ()
                                    (declare (not safe))
                                    (##unchecked-structure-ref
                                     _%proof29302%_
                                     '6
                                     '#f
                                     '#f)))
                                 (_%source-rows29324%_
                                  (gerbil-ascent/candidate/provenance#proof-metadata-lookup
                                   (map (lambda (_%entry29322%_)
                                          (cons (car _%entry29322%_)
                                                (list->vector
                                                 (caddr _%entry29322%_))))
                                        _%source29314%_)))
                                 (_%fact-keys29326%_
                                  (if (pair? _%facts29316%_)
                                      (let ()
                                        (declare (not safe))
                                        (make-hash-table__%
                                         '#f
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value
                                         absent-value))
                                      '#f))
                                 (_%rule-labels29330%_
                                  (gerbil-ascent/candidate/provenance#proof-metadata-lookup
                                   (map (lambda (_%rule29328%_)
                                          (cons (vector-ref _%rule29328%_ '2)
                                                (gerbil-ascent/candidate/provenance#prepare-positive-rule-replay
                                                 _%rule29328%_)))
                                        _%rules29318%_)))
                                 (_%match-query29332%_
                                  (let ()
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/grounding-plan#prepare-grounding-atom
                                     _%query29320%_))))
                            (for-each
                             (lambda (_%fact29335%_)
                               (let ((__tmp34006
                                      (list (vector-ref _%fact29335%_ '2)
                                            (vector-ref _%fact29335%_ '0)
                                            (vector-ref _%fact29335%_ '1))))
                                 (declare (not safe))
                                 (hash-put!
                                  _%fact-keys29326%_
                                  __tmp34006
                                  '#t)))
                             _%facts29316%_)
                            (letrec ((_%existing-input?29337%_
                                      (lambda (_%id29364%_ _%before29365%_)
                                        (if (exact-integer? _%id29364%_)
                                            (if (<= '0 _%id29364%_)
                                                (< _%id29364%_ _%before29365%_)
                                                '#f)
                                            '#f)))
                                     (_%node-valid?29338%_
                                      (lambda (_%node29352%_ _%index29353%_)
                                        (if (let ()
                                              (declare (not safe))
                                              (##structure-instance-of?
                                               _%node29352%_
                                               'gerbil-ascent/candidate/provenance#proof-node::t))
                                            (if (exact-integer?
                                                 (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%node29352%_
                                                    '1
                                                    '#f
                                                    '#f)))
                                                (if (= (let ()
                                                         (declare (not safe))
                                                         (##unchecked-structure-ref
                                                          _%node29352%_
                                                          '1
                                                          '#f
                                                          '#f))
                                                       _%index29353%_)
                                                    (if (symbol? (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%node29352%_
                            '3
                            '#f
                            '#f)))
                (if (let ((_%arity29355%_
                           (let ((__tmp34007
                                  (let ()
                                    (declare (not safe))
                                    (##unchecked-structure-ref
                                     _%node29352%_
                                     '3
                                     '#f
                                     '#f))))
                             (declare (not safe))
                             (_%arities29312%_ __tmp34007))))
                      (and _%arity29355%_
                           (equal? (let ((__tmp34008
                                          (let ()
                                            (declare (not safe))
                                            (##unchecked-structure-ref
                                             _%node29352%_
                                             '4
                                             '#f
                                             '#f))))
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                                      __tmp34008
                                      _%arity29355%_))
                                   _%arity29355%_)))
                    (let ((_%$e29357%_
                           (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%node29352%_
                              '2
                              '#f
                              '#f))))
                      (if (eq? 'source _%$e29357%_)
                          (if (null? (let ()
                                       (declare (not safe))
                                       (##unchecked-structure-ref
                                        _%node29352%_
                                        '6
                                        '#f
                                        '#f)))
                              (let ((_%rows29360%_
                                     (let ((__tmp34009
                                            (let ()
                                              (declare (not safe))
                                              (##unchecked-structure-ref
                                               _%node29352%_
                                               '3
                                               '#f
                                               '#f))))
                                       (declare (not safe))
                                       (_%source-rows29324%_ __tmp34009))))
                                (if _%rows29360%_
                                    (if (exact-integer?
                                         (let ()
                                           (declare (not safe))
                                           (##unchecked-structure-ref
                                            _%node29352%_
                                            '5
                                            '#f
                                            '#f)))
                                        (if (<= '1
                                                (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%node29352%_
                                                   '5
                                                   '#f
                                                   '#f)))
                                            (if (<= (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%node29352%_
                                                       '5
                                                       '#f
                                                       '#f))
                                                    (vector-length
                                                     _%rows29360%_))
                                                (equal? (let ()
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           _%node29352%_
                                                           '4
                                                           '#f
                                                           '#f))
                                                        (vector-ref
                                                         _%rows29360%_
                                                         (- (let ()
                                                              (declare
                                                                (not safe))
                                                              (##unchecked-structure-ref
                                                               _%node29352%_
                                                               '5
                                                               '#f
                                                               '#f))
                                                            '1)))
                                                '#f)
                                            '#f)
                                        '#f)
                                    '#f))
                              '#f)
                          (if (eq? 'candidate _%$e29357%_)
                              (if (null? (let ()
                                           (declare (not safe))
                                           (##unchecked-structure-ref
                                            _%node29352%_
                                            '6
                                            '#f
                                            '#f)))
                                  (if _%fact-keys29326%_
                                      (let ((__tmp34010
                                             (list (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%node29352%_
                                                      '5
                                                      '#f
                                                      '#f))
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%node29352%_
                                                      '3
                                                      '#f
                                                      '#f))
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%node29352%_
                                                      '4
                                                      '#f
                                                      '#f)))))
                                        (declare (not safe))
                                        (__hash-get
                                         _%fact-keys29326%_
                                         __tmp34010))
                                      '#f)
                                  '#f)
                              (if (eq? 'rule _%$e29357%_)
                                  (let ((_%plan29362%_
                                         (let ((__tmp34011
                                                (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%node29352%_
                                                   '5
                                                   '#f
                                                   '#f))))
                                           (declare (not safe))
                                           (_%rule-labels29330%_ __tmp34011))))
                                    (if _%plan29362%_
                                        (if (eq? (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%node29352%_
                                                    '3
                                                    '#f
                                                    '#f))
                                                 (##direct-structure-ref
                                                  _%plan29362%_
                                                  '1
                                                  gerbil-ascent/candidate/provenance#positive-rule-replay::t
                                                  '#f))
                                            (if (equal? (let ((__tmp34013
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (##unchecked-structure-ref _%node29352%_ '6 '#f '#f)))
                      (__tmp34012
                       (##direct-structure-ref
                        _%plan29362%_
                        '2
                        gerbil-ascent/candidate/provenance#positive-rule-replay::t
                        '#f)))
                  (declare (not safe))
                  (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                   __tmp34013
                   __tmp34012))
                (##direct-structure-ref
                 _%plan29362%_
                 '2
                 gerbil-ascent/candidate/provenance#positive-rule-replay::t
                 '#f))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                ((##direct-structure-ref
                                                  _%plan29362%_
                                                  '3
                                                  gerbil-ascent/candidate/provenance#positive-rule-replay::t
                                                  '#f)
                                                 (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%node29352%_
                                                    '6
                                                    '#f
                                                    '#f))
                                                 '()
                                                 _%by-id29310%_
                                                 _%index29353%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%node29352%_
                                                    '4
                                                    '#f
                                                    '#f)))
                                                '#f)
                                            '#f)
                                        '#f))
                                  '#f))))
                    '#f)
                '#f)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '#f)
                                                '#f)
                                            '#f))))
                              (if (let _%loop29340%_ ((_%remaining29342%_
                                                       _%nodes29305%_)
                                                      (_%index29343%_ '0))
                                    (or (null? _%remaining29342%_)
                                        (and (_%node-valid?29338%_
                                              (car _%remaining29342%_)
                                              _%index29343%_)
                                             (begin
                                               (vector-set!
                                                _%by-id29310%_
                                                _%index29343%_
                                                (car _%remaining29342%_))
                                               (_%loop29340%_
                                                (cdr _%remaining29342%_)
                                                (+ _%index29343%_ '1))))))
                                  (if (let ((__tmp34015
                                             (lambda (_%id29348%_)
                                               (and (_%existing-input?29337%_
                                                     _%id29348%_
                                                     _%node-count29307%_)
                                                    (eq? (##structure-ref
                                                          (vector-ref
                                                           _%by-id29310%_
                                                           _%id29348%_)
                                                          '3
                                                          gerbil-ascent/candidate/provenance#proof-node::t
                                                          '#f)
                                                         (car _%query29320%_))
                                                    (_%match-query29332%_
                                                     (##structure-ref
                                                      (vector-ref
                                                       _%by-id29310%_
                                                       _%id29348%_)
                                                      '4
                                                      gerbil-ascent/candidate/provenance#proof-node::t
                                                      '#f)
                                                     '()))))
                                            (__tmp34014
                                             (let ()
                                               (declare (not safe))
                                               (##unchecked-structure-ref
                                                _%proof29302%_
                                                '9
                                                '#f
                                                '#f))))
                                        (declare (not safe))
                                        (andmap__0 __tmp34015 __tmp34014))
                                      (let ((__tmp34016
                                             (map (lambda (_%id29350%_)
                                                    (##structure-ref
                                                     (vector-ref
                                                      _%by-id29310%_
                                                      _%id29350%_)
                                                     '4
                                                     gerbil-ascent/candidate/provenance#proof-node::t
                                                     '#f))
                                                  (let ()
                                                    (declare (not safe))
                                                    (##unchecked-structure-ref
                                                     _%proof29302%_
                                                     '9
                                                     '#f
                                                     '#f)))))
                                        (declare (not safe))
                                        (gerbil-ascent/candidate/funs#candidate-same-row-set?
                                         __tmp34016
                                         _%native-rows29301%_))
                                      '#f)
                                  '#f)))
                          '#f)
                      '#f))
                '#f)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '#f)
                                                '#f)
                                            '#f)
                                        '#f)
                                    '#f)
                                '#f)
                            '#f)
                        '#f)
                    '#f)
                '#f)
            '#f)))))
