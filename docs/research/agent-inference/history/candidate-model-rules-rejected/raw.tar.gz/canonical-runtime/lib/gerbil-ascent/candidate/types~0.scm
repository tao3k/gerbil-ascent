(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/types::timestamp 1791687874)
  (begin
    (define gerbil-ascent/candidate/types#reasoning-snapshot::t
      (let ((__tmp34695 (list)) (__tmp34694 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/types#reasoning-snapshot::t
         'reasoning-snapshot
         __tmp34695
         '(identity generation digest relations)
         __tmp34694
         '#f)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/types#reasoning-snapshot::t)))
    (define gerbil-ascent/candidate/types#make-reasoning-snapshot
      (lambda _%$args26826%_
        (apply make-instance
               gerbil-ascent/candidate/types#reasoning-snapshot::t
               _%$args26826%_)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'identity)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'generation)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'digest)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot-relations
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'relations)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'identity)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'generation)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'digest)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot-relations-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'relations)))
    (define gerbil-ascent/candidate/types#&reasoning-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'identity)))
    (define gerbil-ascent/candidate/types#&reasoning-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'generation)))
    (define gerbil-ascent/candidate/types#&reasoning-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'digest)))
    (define gerbil-ascent/candidate/types#&reasoning-snapshot-relations
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'relations)))
    (define gerbil-ascent/candidate/types#&reasoning-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'identity)))
    (define gerbil-ascent/candidate/types#&reasoning-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'generation)))
    (define gerbil-ascent/candidate/types#&reasoning-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'digest)))
    (define gerbil-ascent/candidate/types#&reasoning-snapshot-relations-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-snapshot::t
         'relations)))
    (define gerbil-ascent/candidate/types#reasoning-diagnostic::t
      (let ((__tmp34697 (list)) (__tmp34696 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'reasoning-diagnostic
         __tmp34697
         '(code path detail)
         __tmp34696
         '#f)))
    (define gerbil-ascent/candidate/types#reasoning-diagnostic?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/types#reasoning-diagnostic::t)))
    (define gerbil-ascent/candidate/types#make-reasoning-diagnostic
      (lambda _%$args26823%_
        (apply make-instance
               gerbil-ascent/candidate/types#reasoning-diagnostic::t
               _%$args26823%_)))
    (define gerbil-ascent/candidate/types#reasoning-diagnostic-code
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'code)))
    (define gerbil-ascent/candidate/types#reasoning-diagnostic-path
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'path)))
    (define gerbil-ascent/candidate/types#reasoning-diagnostic-detail
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'detail)))
    (define gerbil-ascent/candidate/types#reasoning-diagnostic-code-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'code)))
    (define gerbil-ascent/candidate/types#reasoning-diagnostic-path-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'path)))
    (define gerbil-ascent/candidate/types#reasoning-diagnostic-detail-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'detail)))
    (define gerbil-ascent/candidate/types#&reasoning-diagnostic-code
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'code)))
    (define gerbil-ascent/candidate/types#&reasoning-diagnostic-path
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'path)))
    (define gerbil-ascent/candidate/types#&reasoning-diagnostic-detail
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'detail)))
    (define gerbil-ascent/candidate/types#&reasoning-diagnostic-code-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'code)))
    (define gerbil-ascent/candidate/types#&reasoning-diagnostic-path-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'path)))
    (define gerbil-ascent/candidate/types#&reasoning-diagnostic-detail-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-diagnostic::t
         'detail)))
    (define gerbil-ascent/candidate/types#reasoning-candidate::t
      (let ((__tmp34699 (list)) (__tmp34698 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/types#reasoning-candidate::t
         'reasoning-candidate
         __tmp34699
         '(relations facts rules query limits)
         __tmp34698
         '#f)))
    (define gerbil-ascent/candidate/types#reasoning-candidate?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/types#reasoning-candidate::t)))
    (define gerbil-ascent/candidate/types#make-reasoning-candidate
      (lambda _%$args26820%_
        (apply make-instance
               gerbil-ascent/candidate/types#reasoning-candidate::t
               _%$args26820%_)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-relations
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'relations)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-facts
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'facts)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-rules
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'rules)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-query
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'query)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-limits
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'limits)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-relations-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'relations)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-facts-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'facts)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-rules-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'rules)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'query)))
    (define gerbil-ascent/candidate/types#reasoning-candidate-limits-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'limits)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-relations
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'relations)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-facts
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'facts)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-rules
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'rules)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-query
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'query)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-limits
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'limits)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-relations-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'relations)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-facts-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'facts)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-rules-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'rules)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'query)))
    (define gerbil-ascent/candidate/types#&reasoning-candidate-limits-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#reasoning-candidate::t
         'limits)))
    (define gerbil-ascent/candidate/types#candidate-rejection::t
      (let ((__tmp34701 (list)) (__tmp34700 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/types#candidate-rejection::t
         'candidate-rejection
         __tmp34701
         '(diagnostic)
         __tmp34700
         '#f)))
    (define gerbil-ascent/candidate/types#candidate-rejection?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/types#candidate-rejection::t)))
    (define gerbil-ascent/candidate/types#make-candidate-rejection
      (lambda _%$args26817%_
        (apply make-instance
               gerbil-ascent/candidate/types#candidate-rejection::t
               _%$args26817%_)))
    (define gerbil-ascent/candidate/types#candidate-rejection-diagnostic
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/types#candidate-rejection::t
         'diagnostic)))
    (define gerbil-ascent/candidate/types#candidate-rejection-diagnostic-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/types#candidate-rejection::t
         'diagnostic)))
    (define gerbil-ascent/candidate/types#&candidate-rejection-diagnostic
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/types#candidate-rejection::t
         'diagnostic)))
    (define gerbil-ascent/candidate/types#&candidate-rejection-diagnostic-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/types#candidate-rejection::t
         'diagnostic)))
    (define gerbil-ascent/candidate/types#+max-relations+ '64)
    (define gerbil-ascent/candidate/types#+max-rules+ '64)
    (define gerbil-ascent/candidate/types#+max-input-facts+ '1024)
    (define gerbil-ascent/candidate/types#+max-derived-facts+ '4096)
    (define gerbil-ascent/candidate/types#+max-output-facts+ '4096)
    (define gerbil-ascent/candidate/types#reasoning-snapshot-content-digest
      (lambda (_%identity26746%_ _%generation26747%_ _%relations26748%_)
        (let* ((_%bytes26768%_
                (let* ((_%bytes26752%_
                        (let ((__tmp34702
                               (call-with-output-string
                                '""
                                (lambda (_%port26750%_)
                                  (write (list 'reasoning-snapshot-v1
                                               _%identity26746%_
                                               _%generation26747%_
                                               _%relations26748%_)
                                         _%port26750%_)))))
                          (declare (not safe))
                          (##string->utf8 __tmp34702)))
                       (_%bytes26757%_ _%bytes26752%_))
                  (declare (not safe))
                  (std/crypto/digest#__sha256 _%bytes26757%_)))
               (_%start26771%_ '0)
               (_%end26774%_
                (let ()
                  (declare (not safe))
                  (##u8vector-length _%bytes26768%_)))
               (_%bytes26779%_ _%bytes26768%_))
          (if (and (let () (declare (not safe)) (##fx>= _%start26771%_ '0))
                   (let ((__tmp34703
                          (let ((__tmp34704
                                 (let ()
                                   (declare (not safe))
                                   (##u8vector-length _%bytes26779%_))))
                            (declare (not safe))
                            (##fxmax __tmp34704 '1))))
                     (declare (not safe))
                     (##fx< _%start26771%_ __tmp34703)))
              (let ((_%start26794%_ _%start26771%_))
                (if (let ((__tmp34705
                           (let ()
                             (declare (not safe))
                             (##u8vector-length _%bytes26779%_))))
                      (declare (not safe))
                      (##fx<= _%start26794%_ _%end26774%_ __tmp34705))
                    (let ((_%end26807%_ _%end26774%_))
                      (declare (not safe))
                      (std/encoding/hex#__hex-encode__%
                       _%bytes26779%_
                       _%start26794%_
                       _%end26807%_))
                    (begin
                      (raise-contract-violation-error
                       '"contract violation"
                       'context:
                       'gerbil-ascent/candidate/types
                       'contract:
                       '(in-range-inclusive? start (u8vector-length bytes))
                       'value:
                       _%end26774%_)
                      '#!void)))
              (begin
                (raise-contract-violation-error
                 '"contract violation"
                 'context:
                 'gerbil-ascent/candidate/types
                 'contract:
                 '(in-range? 0 (fxmax (u8vector-length bytes) 1))
                 'value:
                 _%start26771%_)
                '#!void)))))
    (define gerbil-ascent/candidate/types#snapshot-scalar?
      (lambda (_%value26735%_)
        (let ((_%$e26737%_ (exact-integer? _%value26735%_)))
          (if _%$e26737%_
              _%$e26737%_
              (let ((_%$e26740%_ (boolean? _%value26735%_)))
                (if _%$e26740%_
                    _%$e26740%_
                    (let ((_%$e26743%_ (symbol? _%value26735%_)))
                      (if _%$e26743%_
                          _%$e26743%_
                          (char? _%value26735%_)))))))))
    (define gerbil-ascent/candidate/types#snapshot-row-valid?
      (lambda (_%row26732%_ _%arity26733%_)
        (if (list? _%row26732%_)
            (if (= (let () (declare (not safe)) (##length _%row26732%_))
                   _%arity26733%_)
                (let ()
                  (declare (not safe))
                  (andmap__0
                   gerbil-ascent/candidate/types#snapshot-scalar?
                   _%row26732%_))
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/types#snapshot-relation-valid?
      (lambda (_%entry26726%_ _%names26727%_ _%remaining-facts26728%_)
        (if (list? _%entry26726%_)
            (if (= (let () (declare (not safe)) (##length _%entry26726%_)) '3)
                (if (symbol? (car _%entry26726%_))
                    (if (let ((__tmp34706 (car _%entry26726%_)))
                          (declare (not safe))
                          (hash-get _%names26727%_ __tmp34706))
                        '#f
                        (if (exact-integer? (cadr _%entry26726%_))
                            (if (<= '0 (cadr _%entry26726%_))
                                (if (list? (caddr _%entry26726%_))
                                    (if (<= (length (caddr _%entry26726%_))
                                            _%remaining-facts26728%_)
                                        (if (let ((__tmp34708
                                                   (lambda (_%row26730%_)
                                                     (gerbil-ascent/candidate/types#snapshot-row-valid?
                                                      _%row26730%_
                                                      (cadr _%entry26726%_))))
                                                  (__tmp34707
                                                   (caddr _%entry26726%_)))
                                              (declare (not safe))
                                              (andmap__0
                                               __tmp34708
                                               __tmp34707))
                                            (begin
                                              (let ((__tmp34709
                                                     (car _%entry26726%_)))
                                                (declare (not safe))
                                                (hash-put!
                                                 _%names26727%_
                                                 __tmp34709
                                                 '#t))
                                              '#t)
                                            '#f)
                                        '#f)
                                    '#f)
                                '#f)
                            '#f))
                    '#f)
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/types#reasoning-snapshot-valid?
      (lambda (_%snapshot26715%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%snapshot26715%_
               'gerbil-ascent/candidate/types#reasoning-snapshot::t))
            (if (or (symbol? (let ()
                               (declare (not safe))
                               (##unchecked-structure-ref
                                _%snapshot26715%_
                                '1
                                '#f
                                '#f)))
                    (string? (let ()
                               (declare (not safe))
                               (##unchecked-structure-ref
                                _%snapshot26715%_
                                '1
                                '#f
                                '#f))))
                (if (exact-integer?
                     (let ()
                       (declare (not safe))
                       (##unchecked-structure-ref
                        _%snapshot26715%_
                        '2
                        '#f
                        '#f)))
                    (if (<= '0
                            (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%snapshot26715%_
                               '2
                               '#f
                               '#f)))
                        (let ((_%relations26720%_
                               (let ()
                                 (declare (not safe))
                                 (##unchecked-structure-ref
                                  _%snapshot26715%_
                                  '4
                                  '#f
                                  '#f)))
                              (_%names26721%_
                               (let ()
                                 (declare (not safe))
                                 (make-hash-table__%
                                  '#f
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value)))
                              (_%facts26722%_ '0))
                          (if (let ()
                                (declare (not safe))
                                (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                                 _%relations26720%_
                                 '131072
                                 '128))
                              (if (list? _%relations26720%_)
                                  (if (<= (let ()
                                            (declare (not safe))
                                            (##length _%relations26720%_))
                                          gerbil-ascent/candidate/types#+max-relations+)
                                      (if (let ((__tmp34710
                                                 (lambda (_%entry26724%_)
                                                   (and (gerbil-ascent/candidate/types#snapshot-relation-valid?
                                                         _%entry26724%_
                                                         _%names26721%_
                                                         (- gerbil-ascent/candidate/types#+max-input-facts+
                                                            _%facts26722%_))
                                                        (begin
                                                          (set! _%facts26722%_
                                                                (+ _%facts26722%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (length (caddr _%entry26724%_))))
                  '#t)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (declare (not safe))
                                            (andmap__0
                                             __tmp34710
                                             _%relations26720%_))
                                          (equal? (let ()
                                                    (declare (not safe))
                                                    (##unchecked-structure-ref
                                                     _%snapshot26715%_
                                                     '3
                                                     '#f
                                                     '#f))
                                                  (gerbil-ascent/candidate/types#reasoning-snapshot-content-digest
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%snapshot26715%_
                                                      '1
                                                      '#f
                                                      '#f))
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%snapshot26715%_
                                                      '2
                                                      '#f
                                                      '#f))
                                                   _%relations26720%_))
                                          '#f)
                                      '#f)
                                  '#f)
                              '#f))
                        '#f)
                    '#f)
                '#f)
            '#f)))))
