(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/eqrel::timestamp 1791689671)
  (begin
    (define gerbil-ascent/table/eqrel#eqrel-component::t
      (let ((__tmp34146 (list)) (__tmp34145 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/eqrel#eqrel-component::t
         'eqrel-component
         __tmp34146
         '(members size)
         __tmp34145
         '#f)))
    (define gerbil-ascent/table/eqrel#eqrel-component?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/eqrel#eqrel-component::t)))
    (define gerbil-ascent/table/eqrel#make-eqrel-component
      (lambda _%$args1685%_
        (apply make-instance
               gerbil-ascent/table/eqrel#eqrel-component::t
               _%$args1685%_)))
    (define gerbil-ascent/table/eqrel#eqrel-component-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#eqrel-component::t
         'members)))
    (define gerbil-ascent/table/eqrel#eqrel-component-size
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#eqrel-component::t
         'size)))
    (define gerbil-ascent/table/eqrel#eqrel-component-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#eqrel-component::t
         'members)))
    (define gerbil-ascent/table/eqrel#eqrel-component-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#eqrel-component::t
         'size)))
    (define gerbil-ascent/table/eqrel#&eqrel-component-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#eqrel-component::t
         'members)))
    (define gerbil-ascent/table/eqrel#&eqrel-component-size
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#eqrel-component::t
         'size)))
    (define gerbil-ascent/table/eqrel#&eqrel-component-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#eqrel-component::t
         'members)))
    (define gerbil-ascent/table/eqrel#&eqrel-component-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#eqrel-component::t
         'size)))
    (define gerbil-ascent/table/eqrel#eqrel-cut::t
      (let ((__tmp34148 (list)) (__tmp34147 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/eqrel#eqrel-cut::t
         'eqrel-cut
         __tmp34148
         '(count view)
         __tmp34147
         '#f)))
    (define gerbil-ascent/table/eqrel#eqrel-cut?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/eqrel#eqrel-cut::t)))
    (define gerbil-ascent/table/eqrel#make-eqrel-cut
      (lambda _%$args1682%_
        (apply make-instance
               gerbil-ascent/table/eqrel#eqrel-cut::t
               _%$args1682%_)))
    (define gerbil-ascent/table/eqrel#eqrel-cut-count
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#eqrel-cut::t
         'count)))
    (define gerbil-ascent/table/eqrel#eqrel-cut-view
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#eqrel-cut::t
         'view)))
    (define gerbil-ascent/table/eqrel#eqrel-cut-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#eqrel-cut::t
         'count)))
    (define gerbil-ascent/table/eqrel#eqrel-cut-view-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#eqrel-cut::t
         'view)))
    (define gerbil-ascent/table/eqrel#&eqrel-cut-count
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#eqrel-cut::t
         'count)))
    (define gerbil-ascent/table/eqrel#&eqrel-cut-view
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#eqrel-cut::t
         'view)))
    (define gerbil-ascent/table/eqrel#&eqrel-cut-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#eqrel-cut::t
         'count)))
    (define gerbil-ascent/table/eqrel#&eqrel-cut-view-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#eqrel-cut::t
         'view)))
    (define gerbil-ascent/table/eqrel#eqrel-state::t
      (let ((__tmp34150 (list)) (__tmp34149 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/eqrel#eqrel-state::t
         'eqrel-state
         __tmp34150
         '(components count published origin)
         __tmp34149
         '#f)))
    (define gerbil-ascent/table/eqrel#eqrel-state?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/eqrel#eqrel-state::t)))
    (define gerbil-ascent/table/eqrel#make-eqrel-state
      (lambda _%$args1679%_
        (apply make-instance
               gerbil-ascent/table/eqrel#eqrel-state::t
               _%$args1679%_)))
    (define gerbil-ascent/table/eqrel#eqrel-state-components
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#eqrel-state::t
         'components)))
    (define gerbil-ascent/table/eqrel#eqrel-state-count
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#eqrel-state::t
         'count)))
    (define gerbil-ascent/table/eqrel#eqrel-state-published
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#eqrel-state::t
         'published)))
    (define gerbil-ascent/table/eqrel#eqrel-state-origin
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#eqrel-state::t
         'origin)))
    (define gerbil-ascent/table/eqrel#eqrel-state-components-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#eqrel-state::t
         'components)))
    (define gerbil-ascent/table/eqrel#eqrel-state-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#eqrel-state::t
         'count)))
    (define gerbil-ascent/table/eqrel#eqrel-state-published-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#eqrel-state::t
         'published)))
    (define gerbil-ascent/table/eqrel#eqrel-state-origin-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#eqrel-state::t
         'origin)))
    (define gerbil-ascent/table/eqrel#&eqrel-state-components
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#eqrel-state::t
         'components)))
    (define gerbil-ascent/table/eqrel#&eqrel-state-count
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#eqrel-state::t
         'count)))
    (define gerbil-ascent/table/eqrel#&eqrel-state-published
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#eqrel-state::t
         'published)))
    (define gerbil-ascent/table/eqrel#&eqrel-state-origin
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#eqrel-state::t
         'origin)))
    (define gerbil-ascent/table/eqrel#&eqrel-state-components-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#eqrel-state::t
         'components)))
    (define gerbil-ascent/table/eqrel#&eqrel-state-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#eqrel-state::t
         'count)))
    (define gerbil-ascent/table/eqrel#&eqrel-state-published-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#eqrel-state::t
         'published)))
    (define gerbil-ascent/table/eqrel#&eqrel-state-origin-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#eqrel-state::t
         'origin)))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-state?
      gerbil-ascent/table/eqrel#eqrel-state?)
    (define gerbil-ascent/table/eqrel#empty-cut
      (lambda ()
        (let ((__tmp34151
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/core/relation-view#gerbil-ascent-explicit-view
                  '()
                  '0))))
          (declare (not safe))
          (##structure gerbil-ascent/table/eqrel#eqrel-cut::t '0 __tmp34151))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-state
      (lambda ()
        (let* ((_%empty1676%_ (gerbil-ascent/table/eqrel#empty-cut))
               (__tmp34152
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value))))
          (declare (not safe))
          (##structure
           gerbil-ascent/table/eqrel#eqrel-state::t
           __tmp34152
           '0
           _%empty1676%_
           _%empty1676%_))))
    (define gerbil-ascent/table/eqrel#member-key
      (lambda (_%width1671%_ _%group1672%_ _%node1673%_)
        (list _%width1671%_ _%group1672%_ _%node1673%_)))
    (define gerbil-ascent/table/eqrel#coordinate-key::t
      (let ((__tmp34154 (list))
            (__tmp34153
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/eqrel#coordinate-key::t
         'coordinate-key
         __tmp34154
         '(bound? value coherent?)
         __tmp34153
         '#f)))
    (define gerbil-ascent/table/eqrel#coordinate-key?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/eqrel#coordinate-key::t)))
    (define gerbil-ascent/table/eqrel#make-coordinate-key
      (lambda _%$args1668%_
        (apply make-instance
               gerbil-ascent/table/eqrel#coordinate-key::t
               _%$args1668%_)))
    (define gerbil-ascent/table/eqrel#coordinate-key-bound?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#coordinate-key::t
         'bound?)))
    (define gerbil-ascent/table/eqrel#coordinate-key-value
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#coordinate-key::t
         'value)))
    (define gerbil-ascent/table/eqrel#coordinate-key-coherent?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/eqrel#coordinate-key::t
         'coherent?)))
    (define gerbil-ascent/table/eqrel#coordinate-key-bound?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#coordinate-key::t
         'bound?)))
    (define gerbil-ascent/table/eqrel#coordinate-key-value-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#coordinate-key::t
         'value)))
    (define gerbil-ascent/table/eqrel#coordinate-key-coherent?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/eqrel#coordinate-key::t
         'coherent?)))
    (define gerbil-ascent/table/eqrel#&coordinate-key-bound?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#coordinate-key::t
         'bound?)))
    (define gerbil-ascent/table/eqrel#&coordinate-key-value
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#coordinate-key::t
         'value)))
    (define gerbil-ascent/table/eqrel#&coordinate-key-coherent?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/eqrel#coordinate-key::t
         'coherent?)))
    (define gerbil-ascent/table/eqrel#&coordinate-key-bound?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#coordinate-key::t
         'bound?)))
    (define gerbil-ascent/table/eqrel#&coordinate-key-value-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#coordinate-key::t
         'value)))
    (define gerbil-ascent/table/eqrel#&coordinate-key-coherent?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/eqrel#coordinate-key::t
         'coherent?)))
    (define gerbil-ascent/table/eqrel#compile-coordinate-key
      (lambda (_%coordinate1657%_ _%columns1658%_ _%key1659%_)
        (let ((_%bound?1661%_ '#f) (_%value1662%_ '#f) (_%coherent?1663%_ '#t))
          (for-each
           (lambda (_%column1665%_ _%selected1666%_)
             (if (= _%column1665%_ _%coordinate1657%_)
                 (if _%bound?1661%_
                     (set! _%coherent?1663%_
                           (if _%coherent?1663%_
                               (equal? _%value1662%_ _%selected1666%_)
                               '#f))
                     (begin
                       (set! _%bound?1661%_ '#t)
                       (set! _%value1662%_ _%selected1666%_)))
                 '#!void))
           _%columns1658%_
           _%key1659%_)
          (let ()
            (declare (not safe))
            (##structure
             gerbil-ascent/table/eqrel#coordinate-key::t
             _%bound?1661%_
             _%value1662%_
             _%coherent?1663%_)))))
    (define gerbil-ascent/table/eqrel#coordinate-accepts?
      (lambda (_%constraint1644%_ _%value1645%_)
        (let ((_%constraint1647%_ _%constraint1644%_))
          (if (let ()
                (declare (not safe))
                (##unchecked-structure-ref _%constraint1647%_ '3 '#f '#f))
              (let ((_%$e1654%_
                     (not (let ()
                            (declare (not safe))
                            (##unchecked-structure-ref
                             _%constraint1647%_
                             '1
                             '#f
                             '#f)))))
                (if _%$e1654%_
                    _%$e1654%_
                    (equal? (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%constraint1647%_
                               '2
                               '#f
                               '#f))
                            _%value1645%_)))
              '#f))))
    (define gerbil-ascent/table/eqrel#coordinate-members
      (lambda (_%constraint1629%_ _%members1630%_)
        (let ((_%constraint1632%_ _%constraint1629%_))
          (if (let ()
                (declare (not safe))
                (##unchecked-structure-ref _%constraint1632%_ '3 '#f '#f))
              (if (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%constraint1632%_ '1 '#f '#f))
                  (let ((_%found1642%_
                         (member (let ()
                                   (declare (not safe))
                                   (##unchecked-structure-ref
                                    _%constraint1632%_
                                    '2
                                    '#f
                                    '#f))
                                 _%members1630%_)))
                    (if _%found1642%_ (list (car _%found1642%_)) '()))
                  _%members1630%_)
              '()))))
    (define gerbil-ascent/table/eqrel#visit-selected-members!
      (lambda (_%left-key1597%_
               _%right-key1598%_
               _%lefts1599%_
               _%rights1600%_
               _%emit1601%_)
        (let* ((_%forward1603%_
                (gerbil-ascent/table/eqrel#coordinate-members
                 _%right-key1598%_
                 _%rights1600%_))
               (_%backward1605%_
                (gerbil-ascent/table/eqrel#coordinate-members
                 _%left-key1597%_
                 _%rights1600%_))
               (_%both1615%_
                (if (or (eq? _%forward1603%_ _%rights1600%_)
                        (eq? _%backward1605%_ _%rights1600%_))
                    _%rights1600%_
                    (filter (lambda (_%b1610%_)
                              (let ((_%$e1612%_
                                     (gerbil-ascent/table/eqrel#coordinate-accepts?
                                      _%right-key1598%_
                                      _%b1610%_)))
                                (if _%$e1612%_
                                    _%$e1612%_
                                    (gerbil-ascent/table/eqrel#coordinate-accepts?
                                     _%left-key1597%_
                                     _%b1610%_))))
                            _%rights1600%_))))
          (for-each
           (lambda (_%a1618%_)
             (let ((_%forward?1620%_
                    (gerbil-ascent/table/eqrel#coordinate-accepts?
                     _%left-key1597%_
                     _%a1618%_))
                   (_%backward?1621%_
                    (gerbil-ascent/table/eqrel#coordinate-accepts?
                     _%right-key1598%_
                     _%a1618%_)))
               (for-each
                (lambda (_%b1623%_)
                  (if (and _%forward?1620%_
                           (gerbil-ascent/table/eqrel#coordinate-accepts?
                            _%right-key1598%_
                            _%b1623%_))
                      (_%emit1601%_ _%a1618%_ _%b1623%_)
                      '#!void)
                  (if (and _%backward?1621%_
                           (gerbil-ascent/table/eqrel#coordinate-accepts?
                            _%left-key1597%_
                            _%b1623%_))
                      (_%emit1601%_ _%b1623%_ _%a1618%_)
                      '#!void))
                (if (and _%forward?1620%_ _%backward?1621%_)
                    _%both1615%_
                    (if _%forward?1620%_
                        _%forward1603%_
                        (if _%backward?1621%_ _%backward1605%_ '()))))))
           _%lefts1599%_))))
    (define gerbil-ascent/table/eqrel#injection-view
      (lambda (_%prefix1546%_
               _%diagonals1547%_
               _%lefts1548%_
               _%rights1549%_
               _%count1550%_)
        (letrec ((_%emit1552%_
                  (lambda (_%consume1593%_ _%a1594%_ _%b1595%_)
                    (_%consume1593%_
                     (let ((__tmp34155 (list _%a1594%_ _%b1595%_)))
                       (declare (not safe))
                       (##append _%prefix1546%_ __tmp34155)))))
                 (_%visit1553%_
                  (lambda (_%columns1561%_ _%key1562%_ _%consume1563%_)
                    (if (and (list? _%columns1561%_)
                             (list? _%key1562%_)
                             (= (let ()
                                  (declare (not safe))
                                  (##length _%columns1561%_))
                                (let ()
                                  (declare (not safe))
                                  (##length _%key1562%_)))
                             (let ((__tmp34156
                                    (lambda (_%n1565%_)
                                      (and (exact-integer? _%n1565%_)
                                           (>= _%n1565%_ '0)
                                           (< _%n1565%_
                                              (+ '2
                                                 (length _%prefix1546%_)))))))
                               (declare (not safe))
                               (andmap__0 __tmp34156 _%columns1561%_)))
                        '#!void
                        (let ()
                          (declare (not safe))
                          (error '"invalid ASCENT eqrel view key")))
                    (if (null? _%columns1561%_)
                        (begin
                          (for-each
                           (lambda (_%node1567%_)
                             (_%emit1552%_
                              _%consume1563%_
                              _%node1567%_
                              _%node1567%_))
                           _%diagonals1547%_)
                          (for-each
                           (lambda (_%a1569%_)
                             (for-each
                              (lambda (_%b1571%_)
                                (_%emit1552%_
                                 _%consume1563%_
                                 _%a1569%_
                                 _%b1571%_)
                                (_%emit1552%_
                                 _%consume1563%_
                                 _%b1571%_
                                 _%a1569%_))
                              _%rights1549%_))
                           _%lefts1548%_))
                        (let ((_%offset1573%_ (length _%prefix1546%_)))
                          (if (let ((__tmp34157
                                     (lambda (_%column1575%_ _%value1576%_)
                                       (or (>= _%column1575%_ _%offset1573%_)
                                           (equal? (list-ref
                                                    _%prefix1546%_
                                                    _%column1575%_)
                                                   _%value1576%_)))))
                                (declare (not safe))
                                (andmap__1
                                 __tmp34157
                                 _%columns1561%_
                                 _%key1562%_))
                              (let ((_%left-key1581%_
                                     (gerbil-ascent/table/eqrel#compile-coordinate-key
                                      _%offset1573%_
                                      _%columns1561%_
                                      _%key1562%_))
                                    (_%right-key1582%_
                                     (gerbil-ascent/table/eqrel#compile-coordinate-key
                                      (+ _%offset1573%_ '1)
                                      _%columns1561%_
                                      _%key1562%_)))
                                (for-each
                                 (lambda (_%node1584%_)
                                   (if (and (gerbil-ascent/table/eqrel#coordinate-accepts?
                                             _%left-key1581%_
                                             _%node1584%_)
                                            (gerbil-ascent/table/eqrel#coordinate-accepts?
                                             _%right-key1582%_
                                             _%node1584%_))
                                       (_%emit1552%_
                                        _%consume1563%_
                                        _%node1584%_
                                        _%node1584%_)
                                       '#!void))
                                 _%diagonals1547%_)
                                (gerbil-ascent/table/eqrel#visit-selected-members!
                                 _%left-key1581%_
                                 _%right-key1582%_
                                 _%lefts1548%_
                                 _%rights1549%_
                                 (lambda (_%$%g15851588%_ _%$%g15861590%_)
                                   (_%emit1552%_
                                    _%consume1563%_
                                    _%$%g15851588%_
                                    _%$%g15861590%_))))
                              '#!void))))))
          (let ((__tmp34160
                 (+ (length _%diagonals1547%_)
                    (length _%lefts1548%_)
                    (length _%rights1549%_)))
                (__tmp34158
                 (lambda (_%row1555%_)
                   (let ((_%found?1557%_ '#f))
                     (_%visit1553%_
                      (let ((__tmp34159 (length _%row1555%_)))
                        (declare (not safe))
                        (##iota __tmp34159))
                      _%row1555%_
                      (lambda (_%_1559%_) (set! _%found?1557%_ '#t)))
                     _%found?1557%_))))
            (declare (not safe))
            (##structure
             gerbil-ascent/core/relation-view#relation-view::t
             '#f
             '#f
             '0
             'delta
             _%count1550%_
             __tmp34160
             _%visit1553%_
             __tmp34158
             '#f
             '#f)))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-insert!
      (lambda (_%state1487%_ _%row1488%_ _%budget1489%_)
        (let* ((_%components1491%_
                (##structure-ref
                 _%state1487%_
                 '1
                 gerbil-ascent/table/eqrel#eqrel-state::t
                 '#f))
               (_%width1493%_ (length _%row1488%_))
               (_%_1495%_
                (if (let () (declare (not safe)) (##memq _%width1493%_ '(2 3)))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"ASCENT eqrel requires two or three columns"
                             _%row1488%_))))
               (_%group1497%_ (if (= _%width1493%_ '3) (car _%row1488%_) '#f))
               (_%prefix1499%_
                (if (= _%width1493%_ '3) (list _%group1497%_) '()))
               (_%pair1501%_
                (if (= _%width1493%_ '3) (cdr _%row1488%_) _%row1488%_))
               (_%left1503%_ (car _%pair1501%_))
               (_%right1505%_ (cadr _%pair1501%_))
               (_%same-node?1507%_ (equal? _%left1503%_ _%right1505%_))
               (_%left-key1509%_
                (list _%width1493%_ _%group1497%_ _%left1503%_))
               (_%right-key1511%_
                (if _%same-node?1507%_
                    _%left-key1509%_
                    (list _%width1493%_ _%group1497%_ _%right1505%_)))
               (_%a1513%_
                (let ()
                  (declare (not safe))
                  (hash-get _%components1491%_ _%left-key1509%_)))
               (_%b1515%_
                (if _%same-node?1507%_
                    _%a1513%_
                    (let ()
                      (declare (not safe))
                      (hash-get _%components1491%_ _%right-key1511%_))))
               (_%left-size1517%_
                (if _%a1513%_
                    (##structure-ref
                     _%a1513%_
                     '2
                     gerbil-ascent/table/eqrel#eqrel-component::t
                     '#f)
                    '1))
               (_%right-size1519%_
                (if _%b1515%_
                    (##structure-ref
                     _%b1515%_
                     '2
                     gerbil-ascent/table/eqrel#eqrel-component::t
                     '#f)
                    '1))
               (_%merge?1524%_
                (not (let ((_%$e1521%_ _%same-node?1507%_))
                       (if _%$e1521%_
                           _%$e1521%_
                           (if _%a1513%_
                               (if _%b1515%_ (eq? _%a1513%_ _%b1515%_) '#f)
                               '#f)))))
               (_%diagonals1529%_
                (let ((__tmp34162 (if _%a1513%_ '() (list _%left1503%_)))
                      (__tmp34161
                       (if (or _%b1515%_ _%same-node?1507%_)
                           '()
                           (list _%right1505%_))))
                  (declare (not safe))
                  (##append __tmp34162 __tmp34161)))
               (_%needed1531%_
                (+ (let () (declare (not safe)) (##length _%diagonals1529%_))
                   (if _%merge?1524%_
                       (* '2 _%left-size1517%_ _%right-size1519%_)
                       '0))))
          (if (> _%needed1531%_ _%budget1489%_)
              (let ()
                (declare (not safe))
                (error '"ASCENT eqrel output fact budget exceeded"))
              '#!void)
          (if _%a1513%_
              '#!void
              (begin
                (set! _%a1513%_
                      (let ((__tmp34163 (list _%left1503%_)))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/table/eqrel#eqrel-component::t
                         __tmp34163
                         '1)))
                (let ()
                  (declare (not safe))
                  (hash-put! _%components1491%_ _%left-key1509%_ _%a1513%_))))
          (if _%b1515%_
              '#!void
              (begin
                (set! _%b1515%_
                      (if _%same-node?1507%_
                          _%a1513%_
                          (let ((__tmp34164 (list _%right1505%_)))
                            (declare (not safe))
                            (##structure
                             gerbil-ascent/table/eqrel#eqrel-component::t
                             __tmp34164
                             '1))))
                (let ()
                  (declare (not safe))
                  (hash-put! _%components1491%_ _%right-key1511%_ _%b1515%_))))
          (let ((_%lefts1534%_
                 (if _%merge?1524%_
                     (##structure-ref
                      _%a1513%_
                      '1
                      gerbil-ascent/table/eqrel#eqrel-component::t
                      '#f)
                     '()))
                (_%rights1535%_
                 (if _%merge?1524%_
                     (##structure-ref
                      _%b1515%_
                      '1
                      gerbil-ascent/table/eqrel#eqrel-component::t
                      '#f)
                     '())))
            (if _%merge?1524%_
                (let* ((_%large1537%_
                        (if (>= _%left-size1517%_ _%right-size1519%_)
                            _%a1513%_
                            _%b1515%_))
                       (_%small1539%_
                        (if (eq? _%large1537%_ _%a1513%_) _%b1515%_ _%a1513%_))
                       (_%members1541%_
                        (##structure-ref
                         _%small1539%_
                         '1
                         gerbil-ascent/table/eqrel#eqrel-component::t
                         '#f)))
                  (for-each
                   (lambda (_%node1544%_)
                     (let ((__tmp34165
                            (list _%width1493%_ _%group1497%_ _%node1544%_)))
                       (declare (not safe))
                       (hash-put!
                        _%components1491%_
                        __tmp34165
                        _%large1537%_)))
                   _%members1541%_)
                  (##structure-set!
                   _%large1537%_
                   (append _%members1541%_
                           (##structure-ref
                            _%large1537%_
                            '1
                            gerbil-ascent/table/eqrel#eqrel-component::t
                            '#f))
                   '1
                   gerbil-ascent/table/eqrel#eqrel-component::t
                   '#f)
                  (##structure-set!
                   _%large1537%_
                   (+ _%left-size1517%_ _%right-size1519%_)
                   '2
                   gerbil-ascent/table/eqrel#eqrel-component::t
                   '#f))
                '#!void)
            (##structure-set!
             _%state1487%_
             (+ (##structure-ref
                 _%state1487%_
                 '2
                 gerbil-ascent/table/eqrel#eqrel-state::t
                 '#f)
                _%needed1531%_)
             '2
             gerbil-ascent/table/eqrel#eqrel-state::t
             '#f)
            (gerbil-ascent/table/eqrel#injection-view
             _%prefix1499%_
             _%diagonals1529%_
             _%lefts1534%_
             _%rights1535%_
             _%needed1531%_)))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-extension
      (lambda (_%state1481%_
               _%_all1482%_
               _%_pending1483%_
               _%row1484%_
               _%budget1485%_)
        (let ((__tmp34166
               (gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-insert!
                _%state1481%_
                _%row1484%_
                _%budget1485%_)))
          (declare (not safe))
          (gerbil-ascent/core/relation-view#gerbil-ascent-view-rows
           __tmp34166))))
    (define gerbil-ascent/table/eqrel#capture
      (lambda (_%state1469%_ _%indexed?1470%_)
        (let ((_%seen1472%_ (let () (declare (not safe)) (make-hash-table-eq)))
              (_%blocks1473%_ '())
              (_%nodes1474%_
               (let ((__tmp34167
                      (##structure-ref
                       _%state1469%_
                       '1
                       gerbil-ascent/table/eqrel#eqrel-state::t
                       '#f)))
                 (declare (not safe))
                 (hash-length __tmp34167))))
          (let ((__tmp34169
                 (lambda (_%key1476%_ _%component1477%_)
                   (if (let ()
                         (declare (not safe))
                         (__hash-get _%seen1472%_ _%component1477%_))
                       '#!void
                       (begin
                         (let ()
                           (declare (not safe))
                           (__hash-put! _%seen1472%_ _%component1477%_ '#t))
                         (let ((_%spine1479%_
                                (##structure-ref
                                 _%component1477%_
                                 '1
                                 gerbil-ascent/table/eqrel#eqrel-component::t
                                 '#f)))
                           (set! _%blocks1473%_
                                 (cons (let ((__tmp34170
                                              (if (= (car _%key1476%_) '3)
                                                  (list (cadr _%key1476%_))
                                                  '())))
                                         (declare (not safe))
                                         (##structure
                                          gerbil-ascent/core/relation-view#rectangle::t
                                          __tmp34170
                                          _%spine1479%_
                                          _%spine1479%_))
                                       _%blocks1473%_)))))))
                (__tmp34168
                 (##structure-ref
                  _%state1469%_
                  '1
                  gerbil-ascent/table/eqrel#eqrel-state::t
                  '#f)))
            (declare (not safe))
            (hash-for-each __tmp34169 __tmp34168))
          (let ((__tmp34174
                 (##structure-ref
                  _%state1469%_
                  '2
                  gerbil-ascent/table/eqrel#eqrel-state::t
                  '#f))
                (__tmp34171
                 (let ((__tmp34173
                        (##structure-ref
                         _%state1469%_
                         '2
                         gerbil-ascent/table/eqrel#eqrel-state::t
                         '#f))
                       (__tmp34172 (* '2 _%nodes1474%_)))
                   (declare (not safe))
                   (gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__%
                    _%blocks1473%_
                    __tmp34173
                    __tmp34172
                    _%indexed?1470%_))))
            (declare (not safe))
            (##structure
             gerbil-ascent/table/eqrel#eqrel-cut::t
             __tmp34174
             __tmp34171)))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze__%
      (lambda (_%state1454%_ _%indexed?1455%_)
        (let ((_%cut1457%_
               (gerbil-ascent/table/eqrel#capture
                _%state1454%_
                _%indexed?1455%_)))
          (##structure-set!
           _%state1454%_
           _%cut1457%_
           '3
           gerbil-ascent/table/eqrel#eqrel-state::t
           '#f)
          (let ()
            (declare (not safe))
            (##unchecked-structure-ref _%cut1457%_ '2 '#f '#f)))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze__0
      (lambda (_%state1462%_)
        (let ((_%indexed?1464%_ '#t))
          (gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze__%
           _%state1462%_
           _%indexed?1464%_))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze
      (lambda _g34175_
        (let ((_g34176_ (let () (declare (not safe)) (##length _g34175_))))
          (cond ((let () (declare (not safe)) (##fx= _g34176_ 1))
                 (apply gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze__0
                        _g34175_))
                ((let () (declare (not safe)) (##fx= _g34176_ 2))
                 (apply gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze__%
                        _g34175_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze
                  _g34175_))))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!__%
      (lambda (_%state1426%_ _%count1427%_ _%indexed?1428%_)
        (let* ((_%published1430%_
                (##structure-ref
                 _%state1426%_
                 '3
                 gerbil-ascent/table/eqrel#eqrel-state::t
                 '#f))
               (_%origin1432%_
                (if (= _%count1427%_
                       (- (##structure-ref
                           _%state1426%_
                           '2
                           gerbil-ascent/table/eqrel#eqrel-state::t
                           '#f)
                          (##structure-ref
                           _%published1430%_
                           '1
                           gerbil-ascent/table/eqrel#eqrel-cut::t
                           '#f)))
                    _%published1430%_
                    (##structure-ref
                     _%state1426%_
                     '4
                     gerbil-ascent/table/eqrel#eqrel-state::t
                     '#f)))
               (_%next1434%_
                (gerbil-ascent/table/eqrel#capture
                 _%state1426%_
                 _%indexed?1428%_))
               (_%total1436%_
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-ref _%next1434%_ '2 '#f '#f))))
          (if (= _%count1427%_
                 (- (let ()
                      (declare (not safe))
                      (##unchecked-structure-ref _%next1434%_ '1 '#f '#f))
                    (##structure-ref
                     _%origin1432%_
                     '1
                     gerbil-ascent/table/eqrel#eqrel-cut::t
                     '#f)))
              '#!void
              (let ()
                (declare (not safe))
                (error '"ASCENT eqrel delta origin mismatch")))
          (let ((_%delta1439%_
                 (if (= (##structure-ref
                         _%origin1432%_
                         '1
                         gerbil-ascent/table/eqrel#eqrel-cut::t
                         '#f)
                        '0)
                     _%total1436%_
                     (let ((__tmp34177
                            (##structure-ref
                             _%origin1432%_
                             '2
                             gerbil-ascent/table/eqrel#eqrel-cut::t
                             '#f)))
                       (declare (not safe))
                       (gerbil-ascent/core/relation-view#gerbil-ascent-view-difference
                        _%total1436%_
                        __tmp34177
                        _%count1427%_)))))
            (##structure-set!
             _%state1426%_
             _%origin1432%_
             '4
             gerbil-ascent/table/eqrel#eqrel-state::t
             '#f)
            (##structure-set!
             _%state1426%_
             _%next1434%_
             '3
             gerbil-ascent/table/eqrel#eqrel-state::t
             '#f)
            (values _%total1436%_ _%delta1439%_)))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!__0
      (lambda (_%state1444%_ _%count1445%_)
        (let ((_%indexed?1447%_ '#t))
          (gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!__%
           _%state1444%_
           _%count1445%_
           _%indexed?1447%_))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!
      (lambda _g34178_
        (let ((_g34179_ (let () (declare (not safe)) (##length _g34178_))))
          (cond ((let () (declare (not safe)) (##fx= _g34179_ 2))
                 (apply gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!__0
                        _g34178_))
                ((let () (declare (not safe)) (##fx= _g34179_ 3))
                 (apply gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!__%
                        _g34178_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!
                  _g34178_))))))
    (define gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-observation
      (lambda (_%state1423%_)
        (list (let ((__tmp34180
                     (##structure-ref
                      _%state1423%_
                      '1
                      gerbil-ascent/table/eqrel#eqrel-state::t
                      '#f)))
                (declare (not safe))
                (hash-length __tmp34180))
              (##structure-ref
               _%state1423%_
               '2
               gerbil-ascent/table/eqrel#eqrel-state::t
               '#f))))))
