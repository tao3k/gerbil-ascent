(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/datum::timestamp 1791689671)
  (begin
    (define gerbil-ascent/candidate/datum#datum-frame::t
      (let ((__tmp33869 (list))
            (__tmp33868
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/datum#datum-frame::t
         'datum-frame
         __tmp33869
         '(pair depth tail?)
         __tmp33868
         '#f)))
    (define gerbil-ascent/candidate/datum#datum-frame?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/candidate/datum#datum-frame::t)))
    (define gerbil-ascent/candidate/datum#make-datum-frame
      (lambda _%$args26713%_
        (apply make-instance
               gerbil-ascent/candidate/datum#datum-frame::t
               _%$args26713%_)))
    (define gerbil-ascent/candidate/datum#datum-frame-pair
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/datum#datum-frame::t
         'pair)))
    (define gerbil-ascent/candidate/datum#datum-frame-depth
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/datum#datum-frame::t
         'depth)))
    (define gerbil-ascent/candidate/datum#datum-frame-tail?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/datum#datum-frame::t
         'tail?)))
    (define gerbil-ascent/candidate/datum#datum-frame-pair-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/datum#datum-frame::t
         'pair)))
    (define gerbil-ascent/candidate/datum#datum-frame-depth-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/datum#datum-frame::t
         'depth)))
    (define gerbil-ascent/candidate/datum#datum-frame-tail?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/datum#datum-frame::t
         'tail?)))
    (define gerbil-ascent/candidate/datum#&datum-frame-pair
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/datum#datum-frame::t
         'pair)))
    (define gerbil-ascent/candidate/datum#&datum-frame-depth
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/datum#datum-frame::t
         'depth)))
    (define gerbil-ascent/candidate/datum#&datum-frame-tail?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/datum#datum-frame::t
         'tail?)))
    (define gerbil-ascent/candidate/datum#&datum-frame-pair-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/datum#datum-frame::t
         'pair)))
    (define gerbil-ascent/candidate/datum#&datum-frame-depth-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/datum#datum-frame::t
         'depth)))
    (define gerbil-ascent/candidate/datum#&datum-frame-tail?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/datum#datum-frame::t
         'tail?)))
    (define gerbil-ascent/candidate/datum#candidate-datum-scalar?
      (lambda (_%value26702%_)
        (let ((_%$e26704%_ (exact-integer? _%value26702%_)))
          (if _%$e26704%_
              _%$e26704%_
              (let ((_%$e26707%_ (boolean? _%value26702%_)))
                (if _%$e26707%_
                    _%$e26707%_
                    (let ((_%$e26710%_ (symbol? _%value26702%_)))
                      (if _%$e26710%_
                          _%$e26710%_
                          (char? _%value26702%_)))))))))
    (define gerbil-ascent/candidate/datum#reasoning-bounded-data?
      (lambda (_%datum26567%_ _%max-nodes26568%_ _%max-depth26569%_)
        (let ((_%active26571%_
               (let () (declare (not safe)) (make-hash-table-eq))))
          (letrec ((_%activate26573%_
                    (lambda (_%prefix26691%_
                             _%depth26692%_
                             _%count26693%_
                             _%remaining26694%_
                             _%frames26695%_
                             _%step26696%_
                             _%stride26697%_)
                      (if (zero? _%count26693%_)
                          (_%visit26576%_
                           _%prefix26691%_
                           _%depth26692%_
                           _%remaining26694%_
                           _%frames26695%_)
                          (if (let ()
                                (declare (not safe))
                                (__hash-get _%active26571%_ _%prefix26691%_))
                              '#f
                              (let ()
                                (let ()
                                  (declare (not safe))
                                  (__hash-put!
                                   _%active26571%_
                                   _%prefix26691%_
                                   '#t))
                                (_%activate26573%_
                                 (_%step26696%_ _%prefix26691%_)
                                 (+ _%depth26692%_ _%stride26697%_)
                                 (- _%count26693%_ '1)
                                 _%remaining26694%_
                                 (cons (let ()
                                         (declare (not safe))
                                         (##structure
                                          gerbil-ascent/candidate/datum#datum-frame::t
                                          _%prefix26691%_
                                          _%depth26692%_
                                          '#t))
                                       _%frames26695%_)
                                 _%step26696%_
                                 _%stride26697%_))))))
                   (_%scan-spine26574%_
                    (lambda (_%start26654%_
                             _%depth26655%_
                             _%remaining26656%_
                             _%frames26657%_)
                      (let _%scan26659%_ ((_%cursor26661%_ _%start26654%_)
                                          (_%fast26662%_ _%start26654%_)
                                          (_%left26663%_ _%remaining26656%_)
                                          (_%count26664%_ '0))
                        (if (<= _%left26663%_ '0)
                            '#f
                            (if (pair? _%cursor26661%_)
                                (let ((_%head26668%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%cursor26661%_))))
                                  (if (pair? _%head26668%_)
                                      (_%activate26573%_
                                       _%start26654%_
                                       _%depth26655%_
                                       _%count26664%_
                                       _%left26663%_
                                       _%frames26657%_
                                       cdr
                                       '0)
                                      (if (or (<= _%left26663%_ '1)
                                              (not (or (null? _%head26668%_)
                                                       (gerbil-ascent/candidate/datum#candidate-datum-scalar?
                                                        _%head26668%_))))
                                          '#f
                                          (let* ((_%next26679%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (##cdr _%cursor26661%_)))
                                                 (_%next-fast26683%_
                                                  (if (pair? _%fast26662%_)
                                                      (let ((_%tail26681%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##cdr _%fast26662%_))))
                (if (pair? _%tail26681%_)
                    (let () (declare (not safe)) (##cdr _%tail26681%_))
                    '#f))
              '#f)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (if (and (pair? _%next26679%_)
                                                     (eq? _%next26679%_
                                                          _%next-fast26683%_))
                                                '#f
                                                (_%scan26659%_
                                                 _%next26679%_
                                                 _%next-fast26683%_
                                                 (- _%left26663%_ '2)
                                                 (+ _%count26664%_ '1)))))))
                                (if (or (null? _%cursor26661%_)
                                        (gerbil-ascent/candidate/datum#candidate-datum-scalar?
                                         _%cursor26661%_))
                                    (_%resume26577%_
                                     (- _%left26663%_ '1)
                                     _%frames26657%_)
                                    '#f))))))
                   (_%scan-nest26575%_
                    (lambda (_%start26623%_
                             _%depth26624%_
                             _%remaining26625%_
                             _%frames26626%_)
                      (let _%scan26628%_ ((_%cursor26630%_ _%start26623%_)
                                          (_%fast26631%_ _%start26623%_)
                                          (_%level26632%_ _%depth26624%_)
                                          (_%left26633%_ _%remaining26625%_)
                                          (_%count26634%_ '0))
                        (if (<= _%left26633%_ '0)
                            '#f
                            (if (pair? _%cursor26630%_)
                                (if (> _%level26632%_ _%max-depth26569%_)
                                    '#f
                                    (if (null? (let ()
                                                 (declare (not safe))
                                                 (##cdr _%cursor26630%_)))
                                        (if (<= _%left26633%_ '1)
                                            '#f
                                            (let* ((_%next26642%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##car _%cursor26630%_)))
                                                   (_%next-fast26646%_
                                                    (if (pair? _%fast26631%_)
                                                        (let ((_%head26644%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (##car _%fast26631%_))))
                  (if (pair? _%head26644%_)
                      (let () (declare (not safe)) (##car _%head26644%_))
                      '#f))
                '#f)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (if (and (pair? _%next26642%_)
                                                       (eq? _%next26642%_
                                                            _%next-fast26646%_))
                                                  '#f
                                                  (_%scan26628%_
                                                   _%next26642%_
                                                   _%next-fast26646%_
                                                   (+ _%level26632%_ '1)
                                                   (- _%left26633%_ '2)
                                                   (+ _%count26634%_ '1)))))
                                        (_%activate26573%_
                                         _%start26623%_
                                         _%depth26624%_
                                         _%count26634%_
                                         _%left26633%_
                                         _%frames26626%_
                                         car
                                         '1)))
                                (if (or (null? _%cursor26630%_)
                                        (gerbil-ascent/candidate/datum#candidate-datum-scalar?
                                         _%cursor26630%_))
                                    (_%resume26577%_
                                     (- _%left26633%_ '1)
                                     _%frames26626%_)
                                    '#f))))))
                   (_%visit26576%_
                    (lambda (_%value26606%_
                             _%depth26607%_
                             _%remaining26608%_
                             _%frames26609%_)
                      (if (<= _%remaining26608%_ '0)
                          '#f
                          (if (pair? _%value26606%_)
                              (if (or (> _%depth26607%_ _%max-depth26569%_)
                                      (let ()
                                        (declare (not safe))
                                        (__hash-get
                                         _%active26571%_
                                         _%value26606%_)))
                                  '#f
                                  (let ((_%head26616%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%value26606%_))))
                                    (if (pair? _%head26616%_)
                                        (if (null? (let ()
                                                     (declare (not safe))
                                                     (##cdr _%value26606%_)))
                                            (_%scan-nest26575%_
                                             _%value26606%_
                                             _%depth26607%_
                                             _%remaining26608%_
                                             _%frames26609%_)
                                            (begin
                                              (let ()
                                                (declare (not safe))
                                                (__hash-put!
                                                 _%active26571%_
                                                 _%value26606%_
                                                 '#t))
                                              (_%visit26576%_
                                               _%head26616%_
                                               (+ _%depth26607%_ '1)
                                               (- _%remaining26608%_ '1)
                                               (cons (let ()
                                                       (declare (not safe))
                                                       (##structure
                                                        gerbil-ascent/candidate/datum#datum-frame::t
                                                        _%value26606%_
                                                        _%depth26607%_
                                                        '#f))
                                                     _%frames26609%_))))
                                        (_%scan-spine26574%_
                                         _%value26606%_
                                         _%depth26607%_
                                         _%remaining26608%_
                                         _%frames26609%_))))
                              (if (or (null? _%value26606%_)
                                      (gerbil-ascent/candidate/datum#candidate-datum-scalar?
                                       _%value26606%_))
                                  (_%resume26577%_
                                   (- _%remaining26608%_ '1)
                                   _%frames26609%_)
                                  '#f)))))
                   (_%resume26577%_
                    (lambda (_%remaining26579%_ _%frames26580%_)
                      (if (null? _%frames26580%_)
                          '#t
                          (let* ((_%frame26582%_ (car _%frames26580%_))
                                 (_%frame26584%_ _%frame26582%_)
                                 (_%pair26595%_
                                  (let ()
                                    (declare (not safe))
                                    (##unchecked-structure-ref
                                     _%frame26584%_
                                     '1
                                     '#f
                                     '#f))))
                            (if (let ()
                                  (declare (not safe))
                                  (##unchecked-structure-ref
                                   _%frame26584%_
                                   '3
                                   '#f
                                   '#f))
                                (begin
                                  (let ()
                                    (declare (not safe))
                                    (__hash-put!
                                     _%active26571%_
                                     _%pair26595%_
                                     '#f))
                                  (_%resume26577%_
                                   _%remaining26579%_
                                   (cdr _%frames26580%_)))
                                (let ((_%tail26597%_ (cdr _%pair26595%_)))
                                  (if (<= _%remaining26579%_ '0)
                                      '#f
                                      (if (pair? _%tail26597%_)
                                          (let ()
                                            (let ()
                                              (declare (not safe))
                                              (##unchecked-structure-set!
                                               _%frame26584%_
                                               '#t
                                               '3
                                               '#f
                                               '#f))
                                            (_%visit26576%_
                                             _%tail26597%_
                                             (let ()
                                               (declare (not safe))
                                               (##unchecked-structure-ref
                                                _%frame26584%_
                                                '2
                                                '#f
                                                '#f))
                                             _%remaining26579%_
                                             _%frames26580%_))
                                          (if (or (null? _%tail26597%_)
                                                  (gerbil-ascent/candidate/datum#candidate-datum-scalar?
                                                   _%tail26597%_))
                                              (let ()
                                                (let ()
                                                  (declare (not safe))
                                                  (__hash-put!
                                                   _%active26571%_
                                                   _%pair26595%_
                                                   '#f))
                                                (_%resume26577%_
                                                 (- _%remaining26579%_ '1)
                                                 (cdr _%frames26580%_)))
                                              '#f))))))))))
            (_%visit26576%_ _%datum26567%_ '0 _%max-nodes26568%_ '())))))
    (define gerbil-ascent/candidate/datum#candidate-copy-pairs
      (lambda (_%datum26532%_)
        (let* ((_%$%datum2653326541%_ _%datum26532%_)
               (_%$%else2653526549%_ (lambda () _%datum26532%_))
               (_%$%K2653726555%_
                (lambda (_%tail26552%_ _%head26553%_)
                  (cons (gerbil-ascent/candidate/datum#candidate-copy-pairs
                         _%head26553%_)
                        (gerbil-ascent/candidate/datum#candidate-copy-pairs
                         _%tail26552%_)))))
          (if (pair? _%$%datum2653326541%_)
              (let ((_%$%hd2653826558%_
                     (let ()
                       (declare (not safe))
                       (##car _%$%datum2653326541%_)))
                    (_%$%tl2653926560%_
                     (let ()
                       (declare (not safe))
                       (##cdr _%$%datum2653326541%_))))
                (let* ((_%head26563%_ _%$%hd2653826558%_)
                       (_%tail26565%_ _%$%tl2653926560%_))
                  (_%$%K2653726555%_ _%tail26565%_ _%head26563%_)))
              (_%$%else2653526549%_)))))))
