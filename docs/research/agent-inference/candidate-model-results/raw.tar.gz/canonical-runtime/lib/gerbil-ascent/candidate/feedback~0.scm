(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/feedback::timestamp 1791689722)
  (begin
    (define gerbil-ascent/candidate/feedback#reasoning-feedback::t
      (let ((__tmp39418 (list))
            (__tmp39417
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reasoning-feedback
         __tmp39418
         '(status reason missing extra)
         __tmp39417
         '#f)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/feedback#reasoning-feedback::t)))
    (define gerbil-ascent/candidate/feedback#make-reasoning-feedback
      (lambda _%$args30288%_
        (apply make-instance
               gerbil-ascent/candidate/feedback#reasoning-feedback::t
               _%$args30288%_)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'status)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-reason
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reason)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-missing
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'missing)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-extra
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'extra)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'status)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-reason-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reason)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-missing-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'missing)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-extra-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'extra)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'status)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-reason
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reason)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-missing
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'missing)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-extra
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'extra)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'status)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-reason-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reason)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-missing-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'missing)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-extra-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'extra)))
    (define gerbil-ascent/candidate/feedback#refuse-feedback
      (lambda (_%reason30286%_)
        (let ()
          (declare (not safe))
          (##structure
           gerbil-ascent/candidate/feedback#reasoning-feedback::t
           'inconclusive
           _%reason30286%_
           '()
           '()))))
    (define gerbil-ascent/candidate/feedback#receipt-feedback-reason
      (lambda (_%snapshot30279%_ _%candidate30280%_ _%receipt30281%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
               _%receipt30281%_
               _%snapshot30279%_
               _%candidate30280%_))
            (if (eq? (##structure-ref
                      _%receipt30281%_
                      '1
                      gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                      '#f)
                     'complete)
                '#f
                (##structure-ref
                 _%receipt30281%_
                 '1
                 gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                 '#f))
            'unbound)))
    (define gerbil-ascent/candidate/feedback#reasoning-compare-rows
      (lambda (_%snapshot30272%_
               _%candidate30273%_
               _%receipt30274%_
               _%expected30275%_)
        (let ((_%reason30277%_
               (gerbil-ascent/candidate/feedback#receipt-feedback-reason
                _%snapshot30272%_
                _%candidate30273%_
                _%receipt30274%_)))
          (if _%reason30277%_
              (gerbil-ascent/candidate/feedback#refuse-feedback
               _%reason30277%_)
              (gerbil-ascent/candidate/feedback#compare-qualified-rows
               _%receipt30274%_
               _%expected30275%_)))))
    (define gerbil-ascent/candidate/feedback#reasoning-compare-attempts
      (lambda (_%snapshot30259%_
               _%candidate30260%_
               _%receipt30261%_
               _%reference-candidate30262%_
               _%reference-receipt30263%_)
        (let ((_%reason30265%_
               (gerbil-ascent/candidate/feedback#receipt-feedback-reason
                _%snapshot30259%_
                _%candidate30260%_
                _%receipt30261%_)))
          (if _%reason30265%_
              (gerbil-ascent/candidate/feedback#refuse-feedback
               _%reason30265%_)
              (if (let ()
                    (declare (not safe))
                    (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                     _%reference-receipt30263%_
                     _%snapshot30259%_
                     _%reference-candidate30262%_))
                  (if (eq? (##structure-ref
                            _%reference-receipt30263%_
                            '1
                            gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                            '#f)
                           'complete)
                      (if (equal? (##structure-ref
                                   _%receipt30261%_
                                   '6
                                   gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                   '#f)
                                  (##structure-ref
                                   _%reference-receipt30263%_
                                   '6
                                   gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                   '#f))
                          (gerbil-ascent/candidate/feedback#compare-qualified-rows
                           _%receipt30261%_
                           (##structure-ref
                            _%reference-receipt30263%_
                            '7
                            gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                            '#f))
                          (gerbil-ascent/candidate/feedback#refuse-feedback
                           'query-mismatch))
                      (gerbil-ascent/candidate/feedback#refuse-feedback
                       'reference-incomplete))
                  (gerbil-ascent/candidate/feedback#refuse-feedback
                   'reference-unbound))))))
    (define gerbil-ascent/candidate/feedback#compare-qualified-rows
      (lambda (_%receipt30229%_ _%expected30230%_)
        (if (and (let ()
                   (declare (not safe))
                   (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                    _%expected30230%_
                    '16384
                    '128))
                 (list? _%expected30230%_)
                 (let* ((_%arity30232%_
                         (length (cdr (##structure-ref
                                       _%receipt30229%_
                                       '6
                                       gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                       '#f))))
                        (__tmp39419
                         (lambda (_%row30234%_)
                           (and (list? _%row30234%_)
                                (= (let ()
                                     (declare (not safe))
                                     (##length _%row30234%_))
                                   _%arity30232%_)
                                (let ()
                                  (declare (not safe))
                                  (andmap__0
                                   gerbil-ascent/candidate/program#scalar?
                                   _%row30234%_))))))
                   (declare (not safe))
                   (andmap__0 __tmp39419 _%expected30230%_)))
            (let ((_%actual-set30238%_
                   (let ()
                     (declare (not safe))
                     (make-hash-table__%
                      '#f
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value)))
                  (_%expected-set30239%_
                   (let ()
                     (declare (not safe))
                     (make-hash-table__%
                      '#f
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value)))
                  (_%actual30240%_ '())
                  (_%wanted30241%_ '()))
              (letrec ((_%insert30243%_
                        (lambda (_%rows30252%_ _%table30253%_)
                          (let ((_%unique30255%_ '()))
                            (for-each
                             (lambda (_%row30257%_)
                               (if (let ()
                                     (declare (not safe))
                                     (hash-get _%table30253%_ _%row30257%_))
                                   '#!void
                                   (begin
                                     (let ()
                                       (declare (not safe))
                                       (hash-put!
                                        _%table30253%_
                                        _%row30257%_
                                        '#t))
                                     (set! _%unique30255%_
                                           (cons _%row30257%_
                                                 _%unique30255%_)))))
                             _%rows30252%_)
                            (let ()
                              (declare (not safe))
                              (##reverse _%unique30255%_))))))
                (set! _%actual30240%_
                      (_%insert30243%_
                       (##structure-ref
                        _%receipt30229%_
                        '7
                        gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                        '#f)
                       _%actual-set30238%_))
                (set! _%wanted30241%_
                      (_%insert30243%_
                       _%expected30230%_
                       _%expected-set30239%_))
                (let ((_%missing30249%_
                       (let ((__tmp39420
                              (lambda (_%row30245%_)
                                (not (let ()
                                       (declare (not safe))
                                       (__hash-get
                                        _%actual-set30238%_
                                        _%row30245%_))))))
                         (declare (not safe))
                         (##filter __tmp39420 _%wanted30241%_)))
                      (_%extra30250%_
                       (let ((__tmp39421
                              (lambda (_%row30247%_)
                                (not (let ()
                                       (declare (not safe))
                                       (__hash-get
                                        _%expected-set30239%_
                                        _%row30247%_))))))
                         (declare (not safe))
                         (##filter __tmp39421 _%actual30240%_))))
                  (let ((__tmp39424
                         (if (and (null? _%missing30249%_)
                                  (null? _%extra30250%_))
                             'match
                             'mismatch))
                        (__tmp39423
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/datum#candidate-copy-pairs
                            _%missing30249%_)))
                        (__tmp39422
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/datum#candidate-copy-pairs
                            _%extra30250%_))))
                    (declare (not safe))
                    (##structure
                     gerbil-ascent/candidate/feedback#reasoning-feedback::t
                     __tmp39424
                     '#f
                     __tmp39423
                     __tmp39422)))))
            (gerbil-ascent/candidate/feedback#refuse-feedback
             'invalid-reference))))))
