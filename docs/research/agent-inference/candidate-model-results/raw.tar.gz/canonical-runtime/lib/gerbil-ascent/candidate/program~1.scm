(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/program[1]#_g36728_|
    (##structure
     gx#syntax-quote::t
     'candidate-declaration::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36730_|
    (##structure
     gx#syntax-quote::t
     'make-candidate-declaration
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36732_|
    (##structure
     gx#syntax-quote::t
     'candidate-declaration?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36734_|
    (##structure
     gx#syntax-quote::t
     'candidate-declaration-arity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36735_|
    (##structure
     gx#syntax-quote::t
     'candidate-declaration-source?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36737_|
    (##structure
     gx#syntax-quote::t
     'candidate-declaration-arity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36738_|
    (##structure
     gx#syntax-quote::t
     'candidate-declaration-source?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36740_|
    (##structure
     gx#syntax-quote::t
     '&candidate-declaration-arity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36741_|
    (##structure
     gx#syntax-quote::t
     '&candidate-declaration-source?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36743_|
    (##structure
     gx#syntax-quote::t
     '&candidate-declaration-arity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[1]#_g36744_|
    (##structure
     gx#syntax-quote::t
     '&candidate-declaration-source?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/program[:0:]#candidate-declaration|
    (let ((__obj36524
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj36524
         'gerbil-ascent/candidate/program#candidate-declaration::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj36524
         'candidate-declaration
         '3
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36524 '(arity source?) '6 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36524 '(arity source?) '8 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36524 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36524 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36524 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36524 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36524 '#f '13 '#f '#f))
      (let ((__tmp36727 |gerbil-ascent/candidate/program[1]#_g36728_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj36524 __tmp36727 '4 '#f '#f))
      (let ((__tmp36729 |gerbil-ascent/candidate/program[1]#_g36730_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj36524 __tmp36729 '14 '#f '#f))
      (let ((__tmp36731 |gerbil-ascent/candidate/program[1]#_g36732_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj36524 __tmp36731 '15 '#f '#f))
      (let ((__tmp36733
             (cons (cons 'arity |gerbil-ascent/candidate/program[1]#_g36734_|)
                   (cons (cons 'source?
                               |gerbil-ascent/candidate/program[1]#_g36735_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36524 __tmp36733 '16 '#f '#f))
      (let ((__tmp36736
             (cons (cons 'arity |gerbil-ascent/candidate/program[1]#_g36737_|)
                   (cons (cons 'source?
                               |gerbil-ascent/candidate/program[1]#_g36738_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36524 __tmp36736 '17 '#f '#f))
      (let ((__tmp36739
             (cons (cons 'arity |gerbil-ascent/candidate/program[1]#_g36740_|)
                   (cons (cons 'source?
                               |gerbil-ascent/candidate/program[1]#_g36741_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36524 __tmp36739 '18 '#f '#f))
      (let ((__tmp36742
             (cons (cons 'arity |gerbil-ascent/candidate/program[1]#_g36743_|)
                   (cons (cons 'source?
                               |gerbil-ascent/candidate/program[1]#_g36744_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36524 __tmp36742 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36524 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36524 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36524 '() '21 '#f '#f))
      __obj36524)))
