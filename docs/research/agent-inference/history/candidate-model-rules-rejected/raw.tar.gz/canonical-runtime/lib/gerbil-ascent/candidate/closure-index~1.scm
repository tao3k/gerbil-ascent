(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/closure-index[1]#_g34124_|
    (##structure
     gx#syntax-quote::t
     'closure-relation::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34126_|
    (##structure
     gx#syntax-quote::t
     'make-closure-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34128_|
    (##structure
     gx#syntax-quote::t
     'closure-relation?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34130_|
    (##structure
     gx#syntax-quote::t
     'closure-relation-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34131_|
    (##structure
     gx#syntax-quote::t
     'closure-relation-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34132_|
    (##structure
     gx#syntax-quote::t
     'closure-relation-source
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34134_|
    (##structure
     gx#syntax-quote::t
     'closure-relation-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34135_|
    (##structure
     gx#syntax-quote::t
     'closure-relation-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34136_|
    (##structure
     gx#syntax-quote::t
     'closure-relation-source-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34138_|
    (##structure
     gx#syntax-quote::t
     '&closure-relation-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34139_|
    (##structure
     gx#syntax-quote::t
     '&closure-relation-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34140_|
    (##structure
     gx#syntax-quote::t
     '&closure-relation-source
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34142_|
    (##structure
     gx#syntax-quote::t
     '&closure-relation-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34143_|
    (##structure
     gx#syntax-quote::t
     '&closure-relation-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[1]#_g34144_|
    (##structure
     gx#syntax-quote::t
     '&closure-relation-source-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/closure-index[:0:]#closure-relation|
    (let ((__obj34014
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34014
         'gerbil-ascent/candidate/closure-index#closure-relation::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34014 'closure-relation '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34014
         '(rows members source)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34014
         '(rows members source)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34014 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34014 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34014 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34014 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34014 '#f '13 '#f '#f))
      (let ((__tmp34123 |gerbil-ascent/candidate/closure-index[1]#_g34124_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34014 __tmp34123 '4 '#f '#f))
      (let ((__tmp34125 |gerbil-ascent/candidate/closure-index[1]#_g34126_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34014 __tmp34125 '14 '#f '#f))
      (let ((__tmp34127 |gerbil-ascent/candidate/closure-index[1]#_g34128_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34014 __tmp34127 '15 '#f '#f))
      (let ((__tmp34129
             (cons (cons 'rows
                         |gerbil-ascent/candidate/closure-index[1]#_g34130_|)
                   (cons (cons 'members
                               |gerbil-ascent/candidate/closure-index[1]#_g34131_|)
                         (cons (cons 'source
                                     |gerbil-ascent/candidate/closure-index[1]#_g34132_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34014 __tmp34129 '16 '#f '#f))
      (let ((__tmp34133
             (cons (cons 'rows
                         |gerbil-ascent/candidate/closure-index[1]#_g34134_|)
                   (cons (cons 'members
                               |gerbil-ascent/candidate/closure-index[1]#_g34135_|)
                         (cons (cons 'source
                                     |gerbil-ascent/candidate/closure-index[1]#_g34136_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34014 __tmp34133 '17 '#f '#f))
      (let ((__tmp34137
             (cons (cons 'rows
                         |gerbil-ascent/candidate/closure-index[1]#_g34138_|)
                   (cons (cons 'members
                               |gerbil-ascent/candidate/closure-index[1]#_g34139_|)
                         (cons (cons 'source
                                     |gerbil-ascent/candidate/closure-index[1]#_g34140_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34014 __tmp34137 '18 '#f '#f))
      (let ((__tmp34141
             (cons (cons 'rows
                         |gerbil-ascent/candidate/closure-index[1]#_g34142_|)
                   (cons (cons 'members
                               |gerbil-ascent/candidate/closure-index[1]#_g34143_|)
                         (cons (cons 'source
                                     |gerbil-ascent/candidate/closure-index[1]#_g34144_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34014 __tmp34141 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34014 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34014 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34014 '() '21 '#f '#f))
      __obj34014)))
