(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/program/objects")
    (load-module "gerbil-ascent/program/scheme-checked")
    (load-module "gerbil-ascent/program/scheme-admission")
    (load-module "clan/poo/object"))
  (begin))
