(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/core/positive-plan::timestamp 1791689689)
  (begin
    (define gerbil-ascent/core/positive-plan#+positive-plans+
      (let ((__tmp35074 (make-mutex 'ascent-positive-plans)))
        (declare (not safe))
        (make-hash-table-eq 'weak-keys: '#t 'lock: __tmp35074)))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-positive-plan
      (lambda (_%rule9908%_)
        (let ((_%entry9910%_
               (let ()
                 (declare (not safe))
                 (__hash-get
                  gerbil-ascent/core/positive-plan#+positive-plans+
                  _%rule9908%_))))
          (if _%entry9910%_
              (cdr _%entry9910%_)
              (let ((_%plan9912%_
                     (gerbil-ascent/core/positive-plan#gerbil-ascent-compile-positive-plan
                      (vector-ref _%rule9908%_ '0)
                      (vector-ref _%rule9908%_ '1))))
                (let ((__tmp35075 (cons '#t _%plan9912%_)))
                  (declare (not safe))
                  (__hash-put!
                   gerbil-ascent/core/positive-plan#+positive-plans+
                   _%rule9908%_
                   __tmp35075))
                _%plan9912%_)))))
    (define gerbil-ascent/core/positive-plan#map-projected-terms
      (lambda (_%lower9834%_ _%original9835%_ _%slots9836%_ _%columns9837%_)
        (let* ((_%$%columns98389848%_ _%columns9837%_)
               (_%$%else98419885%_
                (lambda ()
                  (letrec ((_%increasing?9856%_
                            (lambda (_%remaining9879%_ _%prior9880%_)
                              (let ((_%$e9882%_ (null? _%remaining9879%_)))
                                (if _%$e9882%_
                                    _%$e9882%_
                                    (if (> (car _%remaining9879%_)
                                           _%prior9880%_)
                                        (_%increasing?9856%_
                                         (cdr _%remaining9879%_)
                                         (car _%remaining9879%_))
                                        '#f))))))
                    (if (_%increasing?9856%_ _%columns9837%_ '-1)
                        (let _%select9858%_ ((_%sources9860%_ _%original9835%_)
                                             (_%actions9861%_ _%slots9836%_)
                                             (_%selected9862%_ _%columns9837%_)
                                             (_%position9863%_ '0))
                          (if (null? _%selected9862%_)
                              '()
                              (let* ((_%distance9865%_
                                      (- (car _%selected9862%_)
                                         _%position9863%_))
                                     (_%source9867%_
                                      (list-tail
                                       _%sources9860%_
                                       _%distance9865%_))
                                     (_%action9869%_
                                      (list-tail
                                       _%actions9861%_
                                       _%distance9865%_))
                                     (_%key9871%_
                                      (_%lower9834%_
                                       (car _%source9867%_)
                                       (car _%action9869%_))))
                                (cons _%key9871%_
                                      (_%select9858%_
                                       (cdr _%source9867%_)
                                       (cdr _%action9869%_)
                                       (cdr _%selected9862%_)
                                       (+ (car _%selected9862%_) '1))))))
                        (let ((_%sources9874%_ (list->vector _%original9835%_))
                              (_%actions9875%_ (list->vector _%slots9836%_)))
                          (map (lambda (_%column9877%_)
                                 (_%lower9834%_
                                  (vector-ref _%sources9874%_ _%column9877%_)
                                  (vector-ref _%actions9875%_ _%column9877%_)))
                               _%columns9837%_)))))))
          (let ((_%$%K98469905%_ (lambda () '()))
                (_%$%K98439891%_
                 (lambda (_%column9889%_)
                   (list (_%lower9834%_
                          (list-ref _%original9835%_ _%column9889%_)
                          (list-ref _%slots9836%_ _%column9889%_))))))
            (let ((_%$%try-match98409901%_
                   (lambda ()
                     (if (pair? _%$%columns98389848%_)
                         (let ((_%$%tl98459896%_
                                (let ()
                                  (declare (not safe))
                                  (##cdr _%$%columns98389848%_)))
                               (_%$%hd98449894%_
                                (let ()
                                  (declare (not safe))
                                  (##car _%$%columns98389848%_))))
                           (if (null? _%$%tl98459896%_)
                               (let ((_%column9899%_ _%$%hd98449894%_))
                                 (_%$%K98439891%_ _%column9899%_))
                               (_%$%else98419885%_)))
                         (_%$%else98419885%_)))))
              (if (null? _%$%columns98389848%_)
                  (_%$%K98469905%_)
                  (_%$%try-match98409901%_)))))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-compile-positive-plan
      (lambda (_%heads9675%_ _%body9676%_)
        (let ((__tmp35076
               (lambda (_%unsupported9678%_)
                 (let ((_%slots9680%_
                        (let () (declare (not safe)) (make-hash-table-eq)))
                       (_%scope9681%_ '#f)
                       (_%count9682%_ '0)
                       (_%pure?9683%_ '#t))
                   (letrec* ((_%ensure-scope!9685%_
                              (lambda ()
                                (let ((_%$e9831%_ _%scope9681%_))
                                  (if _%$e9831%_
                                      _%$e9831%_
                                      (begin
                                        (set! _%scope9681%_
                                              (let ()
                                                (declare (not safe))
                                                (__hash->list _%slots9680%_)))
                                        _%scope9681%_)))))
                             (_%read-slot9686%_
                              (lambda (_%name9825%_)
                                (let ((_%$e9827%_
                                       (let ()
                                         (declare (not safe))
                                         (__hash-get
                                          _%slots9680%_
                                          _%name9825%_))))
                                  (if _%$e9827%_
                                      _%$e9827%_
                                      (_%unsupported9678%_ '#f)))))
                             (_%fresh-slot!9687%_
                              (lambda (_%name9821%_)
                                (let ((_%slot9823%_ _%count9682%_))
                                  (set! _%count9682%_ (+ _%count9682%_ '1))
                                  (let ()
                                    (declare (not safe))
                                    (__hash-put!
                                     _%slots9680%_
                                     _%name9821%_
                                     _%slot9823%_))
                                  (if _%scope9681%_
                                      (set! _%scope9681%_
                                            (cons (cons _%name9821%_
                                                        _%slot9823%_)
                                                  _%scope9681%_))
                                      '#!void)
                                  _%slot9823%_)))
                             (_%lower-call__3490334904%_
                              (lambda (_%names9771%_
                                       _%procedure9772%_
                                       _%diagnostic9773%_
                                       _%payload9774%_
                                       _%visible9775%_)
                                (if (and (list? _%names9771%_)
                                         (procedure? _%procedure9772%_))
                                    '#!void
                                    (_%unsupported9678%_ '#f))
                                (set! _%pure?9683%_ '#f)
                                (let ((_%fast9777%_
                                       (let ((__tmp35077
                                              (map _%read-slot9686%_
                                                   _%names9771%_)))
                                         (declare (not safe))
                                         (gerbil-ascent/core/expression-plan#gerbil-ascent-compile-frame-call
                                          _%procedure9772%_
                                          __tmp35077)))
                                      (_%stable-inputs?9778%_
                                       (let ()
                                         (declare (not safe))
                                         (gerbil-ascent/core/expression-plan#gerbil-ascent-compile-input-guard
                                          _%names9771%_))))
                                  (letrec ((_%fallback9780%_
                                            (lambda (_%current-procedure9791%_
                                                     _%current-names9792%_
                                                     _%frame9793%_)
                                              (let ((__tmp35078
                                                     (map (lambda (_%entry9795%_)
                                                            (cons (car _%entry9795%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (vector-ref _%frame9793%_ (cdr _%entry9795%_))))
                  _%visible9775%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (declare (not safe))
                                                (gerbil-ascent/core/rule-bindings#gerbil-ascent-call-with-bindings
                                                 _%current-procedure9791%_
                                                 _%current-names9792%_
                                                 __tmp35078
                                                 _%diagnostic9773%_)))))
                                    (if _%payload9774%_
                                        (lambda (_%frame9782%_)
                                          (let* ((_%current-procedure9784%_
                                                  (vector-ref
                                                   _%payload9774%_
                                                   '1))
                                                 (_%current-names9786%_
                                                  (vector-ref
                                                   _%payload9774%_
                                                   '0)))
                                            (if (and (eq? _%current-procedure9784%_
                                                          _%procedure9772%_)
                                                     (let ()
                                                       (declare (not safe))
                                                       (_%stable-inputs?9778%_
                                                        _%current-names9786%_)))
                                                (let ()
                                                  (declare (not safe))
                                                  (_%fast9777%_ _%frame9782%_))
                                                (_%fallback9780%_
                                                 _%current-procedure9784%_
                                                 _%current-names9786%_
                                                 _%frame9782%_))))
                                        (lambda (_%frame9789%_)
                                          (if (let ()
                                                (declare (not safe))
                                                (_%stable-inputs?9778%_
                                                 _%names9771%_))
                                              (let ()
                                                (declare (not safe))
                                                (_%fast9777%_ _%frame9789%_))
                                              (_%fallback9780%_
                                               _%procedure9772%_
                                               _%names9771%_
                                               _%frame9789%_))))))))
                             (_%lower-call__0__3490534907%_
                              (lambda (_%names9800%_
                                       _%procedure9801%_
                                       _%diagnostic9802%_)
                                (let* ((_%payload9804%_ '#f)
                                       (_%visible9806%_
                                        (_%ensure-scope!9685%_)))
                                  (_%lower-call__3490334904%_
                                   _%names9800%_
                                   _%procedure9801%_
                                   _%diagnostic9802%_
                                   _%payload9804%_
                                   _%visible9806%_))))
                             (_%lower-call__1__3490634908%_
                              (lambda (_%names9808%_
                                       _%procedure9809%_
                                       _%diagnostic9810%_
                                       _%payload9811%_)
                                (let ((_%visible9813%_
                                       (_%ensure-scope!9685%_)))
                                  (_%lower-call__3490334904%_
                                   _%names9808%_
                                   _%procedure9809%_
                                   _%diagnostic9810%_
                                   _%payload9811%_
                                   _%visible9813%_))))
                             (_%lower-call9688%_
                              (lambda _g35079_
                                (let ((_g35080_
                                       (let ()
                                         (declare (not safe))
                                         (##length _g35079_))))
                                  (cond ((let ()
                                           (declare (not safe))
                                           (##fx= _g35080_ 3))
                                         (apply _%lower-call__0__3490534907%_
                                                _g35079_))
                                        ((let ()
                                           (declare (not safe))
                                           (##fx= _g35080_ 4))
                                         (apply _%lower-call__1__3490634908%_
                                                _g35079_))
                                        ((let ()
                                           (declare (not safe))
                                           (##fx= _g35080_ 5))
                                         (apply _%lower-call__3490334904%_
                                                _g35079_))
                                        (else
                                         (##raise-wrong-number-of-arguments-exception
                                          'case-lambda-dispatch
                                          _g35079_))))))
                             (_%lower9689%_
                              (lambda (_%term9754%_ _%head?9755%_)
                                (let ((_%$e9757%_ (car _%term9754%_)))
                                  (if (or (eq? 'literal _%$e9757%_)
                                          (eq? 'wildcard _%$e9757%_))
                                      _%term9754%_
                                      (if (eq? 'expression _%$e9757%_)
                                          (let ((_%payload9763%_
                                                 (cdr _%term9754%_)))
                                            (if (and (vector? _%payload9763%_)
                                                     (= (let ()
                                                          (declare (not safe))
                                                          (##vector-length
                                                           _%payload9763%_))
                                                        '2))
                                                '#!void
                                                (_%unsupported9678%_ '#f))
                                            (cons 'expression
                                                  (_%lower-call__1__3490634908%_
                                                   (vector-ref
                                                    _%payload9763%_
                                                    '0)
                                                   (vector-ref
                                                    _%payload9763%_
                                                    '1)
                                                   '"unbound ASCENT expression variable"
                                                   _%payload9763%_)))
                                          (if (eq? 'variable _%$e9757%_)
                                              (let ((_%slot9765%_
                                                     (let ((__tmp35081
                                                            (cdr _%term9754%_)))
                                                       (declare (not safe))
                                                       (__hash-get
                                                        _%slots9680%_
                                                        __tmp35081))))
                                                (if _%slot9765%_
                                                    (cons 'bound _%slot9765%_)
                                                    (if _%head?9755%_
                                                        (_%unsupported9678%_
                                                         '#f)
                                                        (cons 'fresh
                                                              (_%fresh-slot!9687%_
                                                               (cdr _%term9754%_))))))
                                              (_%unsupported9678%_ '#f))))))))
                     (let* ((_%actions9741%_
                             (map (lambda (_%clause9691%_)
                                    (let ((_%$e9693%_
                                           (vector-ref _%clause9691%_ '0)))
                                      (if (eq? 'atom _%$e9693%_)
                                          (let* ((_%atom9696%_
                                                  (vector-ref
                                                   _%clause9691%_
                                                   '1))
                                                 (_%original9698%_
                                                  (vector-ref _%atom9696%_ '1))
                                                 (_%columns9700%_
                                                  (vector-ref _%atom9696%_ '2))
                                                 (_%prior-count9702%_
                                                  _%count9682%_)
                                                 (_%_checked-columns9708%_
                                                  (if (and (list? _%columns9700%_)
                                                           (let* ((_%width9704%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (length _%original9698%_))
                          (__tmp35082
                           (lambda (_%column9706%_)
                             (and (exact-integer? _%column9706%_)
                                  (<= '0 _%column9706%_)
                                  (< _%column9706%_ _%width9704%_)))))
                     (declare (not safe))
                     (andmap__0 __tmp35082 _%columns9700%_)))
              '#!void
              (_%unsupported9678%_ '#f)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (_%prior-scope9712%_
                                                  (if (let ((__tmp35083
                                                             (lambda (_%term9710%_)
                                                               (eq? (car _%term9710%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            'expression))))
                (declare (not safe))
                (ormap__0 __tmp35083 _%original9698%_))
              (_%ensure-scope!9685%_)
              '#f))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (_%terms9716%_
                                                  (map (lambda (_%term9714%_)
                                                         (_%lower9689%_
                                                          _%term9714%_
                                                          '#f))
                                                       _%original9698%_))
                                                 (_%keys9733%_
                                                  (gerbil-ascent/core/positive-plan#map-projected-terms
                                                   (lambda (_%source9718%_
                                                            _%action9719%_)
                                                     (if (or (eq? (car _%action9719%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          'literal)
                     (and (eq? (car _%action9719%_) 'bound)
                          (< (cdr _%action9719%_) _%prior-count9702%_))
                     (and (eq? (car _%source9718%_) 'expression)
                          (let ((__tmp35085
                                 (lambda (_%name9727%_)
                                   (let ((_%slot9729%_
                                          (let ()
                                            (declare (not safe))
                                            (__hash-get
                                             _%slots9680%_
                                             _%name9727%_))))
                                     (and _%slot9729%_
                                          (< _%slot9729%_
                                             _%prior-count9702%_)))))
                                (__tmp35084
                                 (vector-ref (cdr _%source9718%_) '0)))
                            (declare (not safe))
                            (andmap__0 __tmp35085 __tmp35084))))
                 '#!void
                 (_%unsupported9678%_ '#f))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (if (eq? (car _%source9718%_)
                                                              'expression)
                                                         (let ((_%payload9731%_
                                                                (cdr _%source9718%_)))
                                                           (cons 'expression
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (_%lower-call__3490334904%_
                          (vector-ref _%payload9731%_ '0)
                          (vector-ref _%payload9731%_ '1)
                          '"unbound ASCENT expression variable"
                          _%payload9731%_
                          _%prior-scope9712%_)))
                 _%action9719%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   _%original9698%_
                                                   _%terms9716%_
                                                   _%columns9700%_)))
                                            (vector _%atom9696%_
                                                    _%terms9716%_
                                                    _%keys9733%_
                                                    (gerbil-ascent/core/positive-plan#compile-parts-matcher
                                                     _%terms9716%_)
                                                    (gerbil-ascent/core/positive-plan#compile-selected-parts-matcher
                                                     _%terms9716%_
                                                     _%columns9700%_
                                                     _%keys9733%_)))
                                          (if (eq? 'guard _%$e9693%_)
                                              (vector 'guard
                                                      (_%lower-call__0__3490534907%_
                                                       (vector-ref
                                                        _%clause9691%_
                                                        '1)
                                                       (vector-ref
                                                        _%clause9691%_
                                                        '2)
                                                       '"unbound ASCENT clause variable"))
                                              (if (eq? 'binding _%$e9693%_)
                                                  (let* ((_%call9736%_
                                                          (_%lower-call__0__3490534907%_
                                                           (vector-ref
                                                            _%clause9691%_
                                                            '2)
                                                           (vector-ref
                                                            _%clause9691%_
                                                            '3)
                                                           '"unbound ASCENT clause variable"))
                                                         (_%slot9738%_
                                                          (_%fresh-slot!9687%_
                                                           (vector-ref
                                                            _%clause9691%_
                                                            '1))))
                                                    (vector 'binding
                                                            _%slot9738%_
                                                            _%call9736%_))
                                                  (_%unsupported9678%_
                                                   '#f))))))
                                  _%body9676%_))
                            (_%outputs9749%_
                             (map (lambda (_%head9743%_)
                                    (let ((_%terms9747%_
                                           (map (lambda (_%term9745%_)
                                                  (_%lower9689%_
                                                   _%term9745%_
                                                   '#t))
                                                (vector-ref _%head9743%_ '1))))
                                      (vector _%head9743%_
                                              _%terms9747%_
                                              (gerbil-ascent/core/positive-plan#compile-parts-output
                                               _%terms9747%_))))
                                  _%heads9675%_)))
                       (vector _%outputs9749%_
                               (gerbil-ascent/core/positive-plan#compile-action-segments
                                _%actions9741%_)
                               _%count9682%_
                               _%pure?9683%_
                               (let ((__tmp35086
                                      (let ((__tmp35087
                                             (lambda (_%action9752%_)
                                               (vector? (vector-ref
                                                         _%action9752%_
                                                         '0)))))
                                        (declare (not safe))
                                        (##filter
                                         __tmp35087
                                         _%actions9741%_))))
                                 (declare (not safe))
                                 (##length __tmp35086)))))))))
          (declare (not safe))
          (##call-with-current-continuation __tmp35076))))
    (define gerbil-ascent/core/positive-plan#callback-prefix
      (lambda (_%actions9632%_)
        (let* ((_%$%actions96339642%_ _%actions9632%_)
               (_%$%E96369646%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%actions96339642%_
                           '([])
                           '([action . remaining])))
                  '#!void)))
          (let ((_%$%K96409672%_ (lambda () (values '() '())))
                (_%$%K96379656%_
                 (lambda (_%remaining9650%_ _%action9651%_)
                   (if (vector? (vector-ref _%action9651%_ '0))
                       (values '() _%actions9632%_)
                       (let ((_g35088_
                              (gerbil-ascent/core/positive-plan#callback-prefix
                               _%remaining9650%_)))
                         (begin
                           (let ((_g35089_
                                  (let ()
                                    (declare (not safe))
                                    (if (##values? _g35088_)
                                        (##values-length _g35088_)
                                        1))))
                             (if (not (let ()
                                        (declare (not safe))
                                        (##fx= _g35089_ 2)))
                                 (error "Context expects 2 values" _g35089_)))
                           (let ((_%prefix9653%_
                                  (let ()
                                    (declare (not safe))
                                    (##values-ref _g35088_ 0)))
                                 (_%suffix9654%_
                                  (let ()
                                    (declare (not safe))
                                    (##values-ref _g35088_ 1))))
                             (values (cons _%action9651%_ _%prefix9653%_)
                                     _%suffix9654%_))))))))
            (let ((_%$%try-match96359668%_
                   (lambda ()
                     (if (pair? _%$%actions96339642%_)
                         (let ((_%$%tl96399661%_
                                (let ()
                                  (declare (not safe))
                                  (##cdr _%$%actions96339642%_)))
                               (_%$%hd96389659%_
                                (let ()
                                  (declare (not safe))
                                  (##car _%$%actions96339642%_))))
                           (let ((_%action9664%_ _%$%hd96389659%_)
                                 (_%remaining9666%_ _%$%tl96399661%_))
                             (_%$%K96379656%_
                              _%remaining9666%_
                              _%action9664%_)))
                         (_%$%E96369646%_)))))
              (if (null? _%$%actions96339642%_)
                  (_%$%K96409672%_)
                  (_%$%try-match96359668%_)))))))
    (define gerbil-ascent/core/positive-plan#compile-action-segments
      (lambda (_%actions9627%_)
        (if (null? _%actions9627%_)
            '()
            (if (vector? (vector-ref (car _%actions9627%_) '0))
                (cons (car _%actions9627%_)
                      (gerbil-ascent/core/positive-plan#compile-action-segments
                       (cdr _%actions9627%_)))
                (let ((_g35090_
                       (gerbil-ascent/core/positive-plan#callback-prefix
                        _%actions9627%_)))
                  (begin
                    (let ((_g35091_
                           (let ()
                             (declare (not safe))
                             (if (##values? _g35090_)
                                 (##values-length _g35090_)
                                 1))))
                      (if (not (let ()
                                 (declare (not safe))
                                 (##fx= _g35091_ 2)))
                          (error "Context expects 2 values" _g35091_)))
                    (let ((_%segment9629%_
                           (let ()
                             (declare (not safe))
                             (##values-ref _g35090_ 0)))
                          (_%remaining9630%_
                           (let ()
                             (declare (not safe))
                             (##values-ref _g35090_ 1))))
                      (cons (vector 'callbacks
                                    (let ()
                                      (declare (not safe))
                                      (gerbil-ascent/core/expression-plan#gerbil-ascent-compile-frame-sequence
                                       _%segment9629%_)))
                            (gerbil-ascent/core/positive-plan#compile-action-segments
                             _%remaining9630%_)))))))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-positive-plan-with-outputs
      (lambda (_%plan9624%_ _%outputs9625%_)
        (vector _%outputs9625%_
                (vector-ref _%plan9624%_ '1)
                (vector-ref _%plan9624%_ '2)
                (vector-ref _%plan9624%_ '3)
                (vector-ref _%plan9624%_ '4))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-pure-positive-plan?
      (lambda (_%plan9622%_)
        (if _%plan9622%_ (vector-ref _%plan9622%_ '3) '#f)))
    (define gerbil-ascent/core/positive-plan#match-row!
      (lambda (_%terms9610%_ _%row9611%_ _%frame9612%_)
        (if (null? _%terms9610%_)
            '#t
            (let* ((_%term9614%_ (car _%terms9610%_))
                   (_%value9616%_ (car _%row9611%_)))
              (if (let ((_%$e9619%_ (car _%term9614%_)))
                    (if (eq? 'fresh _%$e9619%_)
                        (begin
                          (vector-set!
                           _%frame9612%_
                           (cdr _%term9614%_)
                           _%value9616%_)
                          '#t)
                        (if (eq? 'bound _%$e9619%_)
                            (equal? (vector-ref
                                     _%frame9612%_
                                     (cdr _%term9614%_))
                                    _%value9616%_)
                            (if (eq? 'literal _%$e9619%_)
                                (equal? (cdr _%term9614%_) _%value9616%_)
                                (if (eq? 'expression _%$e9619%_)
                                    (equal? ((cdr _%term9614%_) _%frame9612%_)
                                            _%value9616%_)
                                    (if (eq? 'wildcard _%$e9619%_)
                                        '#t
                                        '#!void))))))
                  (gerbil-ascent/core/positive-plan#match-row!
                   (cdr _%terms9610%_)
                   (cdr _%row9611%_)
                   _%frame9612%_)
                  '#f)))))
    (define gerbil-ascent/core/positive-plan#match-parts!
      (lambda (_%terms9574%_
               _%prefix9575%_
               _%left9576%_
               _%right9577%_
               _%frame9578%_)
        (if (pair? _%prefix9575%_)
            (if (let ((_%selected9580%_ (car _%terms9574%_))
                      (_%stored9582%_
                       (let () (declare (not safe)) (##car _%prefix9575%_)))
                      (_%bindings9584%_ _%frame9578%_))
                  (let ((_%$e9587%_ (car _%selected9580%_)))
                    (if (eq? 'fresh _%$e9587%_)
                        (begin
                          (vector-set!
                           _%bindings9584%_
                           (cdr _%selected9580%_)
                           _%stored9582%_)
                          '#t)
                        (if (eq? 'bound _%$e9587%_)
                            (equal? (vector-ref
                                     _%bindings9584%_
                                     (cdr _%selected9580%_))
                                    _%stored9582%_)
                            (if (eq? 'literal _%$e9587%_)
                                (equal? (cdr _%selected9580%_) _%stored9582%_)
                                (if (eq? 'expression _%$e9587%_)
                                    (equal? ((cdr _%selected9580%_)
                                             _%bindings9584%_)
                                            _%stored9582%_)
                                    (if (eq? 'wildcard _%$e9587%_)
                                        '#t
                                        '#!void)))))))
                (gerbil-ascent/core/positive-plan#match-parts!
                 (cdr _%terms9574%_)
                 (let () (declare (not safe)) (##cdr _%prefix9575%_))
                 _%left9576%_
                 _%right9577%_
                 _%frame9578%_)
                '#f)
            (if (let ((_%selected9590%_ (car _%terms9574%_))
                      (_%stored9592%_ _%left9576%_)
                      (_%bindings9594%_ _%frame9578%_))
                  (let ((_%$e9597%_ (car _%selected9590%_)))
                    (if (eq? 'fresh _%$e9597%_)
                        (begin
                          (vector-set!
                           _%bindings9594%_
                           (cdr _%selected9590%_)
                           _%stored9592%_)
                          '#t)
                        (if (eq? 'bound _%$e9597%_)
                            (equal? (vector-ref
                                     _%bindings9594%_
                                     (cdr _%selected9590%_))
                                    _%stored9592%_)
                            (if (eq? 'literal _%$e9597%_)
                                (equal? (cdr _%selected9590%_) _%stored9592%_)
                                (if (eq? 'expression _%$e9597%_)
                                    (equal? ((cdr _%selected9590%_)
                                             _%bindings9594%_)
                                            _%stored9592%_)
                                    (if (eq? 'wildcard _%$e9597%_)
                                        '#t
                                        '#!void)))))))
                (let ((_%selected9600%_ (cadr _%terms9574%_))
                      (_%stored9602%_ _%right9577%_)
                      (_%bindings9604%_ _%frame9578%_))
                  (let ((_%$e9607%_ (car _%selected9600%_)))
                    (if (eq? 'fresh _%$e9607%_)
                        (begin
                          (vector-set!
                           _%bindings9604%_
                           (cdr _%selected9600%_)
                           _%stored9602%_)
                          '#t)
                        (if (eq? 'bound _%$e9607%_)
                            (equal? (vector-ref
                                     _%bindings9604%_
                                     (cdr _%selected9600%_))
                                    _%stored9602%_)
                            (if (eq? 'literal _%$e9607%_)
                                (equal? (cdr _%selected9600%_) _%stored9602%_)
                                (if (eq? 'expression _%$e9607%_)
                                    (equal? ((cdr _%selected9600%_)
                                             _%bindings9604%_)
                                            _%stored9602%_)
                                    (if (eq? 'wildcard _%$e9607%_)
                                        '#t
                                        '#!void)))))))
                '#f))))
    (define gerbil-ascent/core/positive-plan#compile-parts-matcher
      (lambda (_%terms9376%_)
        (let* ((_%$%terms93779419%_ _%terms9376%_)
               (_%$%else93819432%_
                (lambda ()
                  (lambda (_%prefix9427%_
                           _%left9428%_
                           _%right9429%_
                           _%frame9430%_)
                    (gerbil-ascent/core/positive-plan#match-parts!
                     _%terms9376%_
                     _%prefix9427%_
                     _%left9428%_
                     _%right9429%_
                     _%frame9430%_)))))
          (let ((_%$%K94099547%_
                 (lambda (_%b9539%_ _%a9540%_)
                   (lambda (_%prefix9542%_
                            _%left9543%_
                            _%right9544%_
                            _%frame9545%_)
                     (if (null? _%prefix9542%_)
                         (begin
                           (vector-set! _%frame9545%_ _%a9540%_ _%left9543%_)
                           (vector-set! _%frame9545%_ _%b9539%_ _%right9544%_)
                           '#t)
                         (gerbil-ascent/core/positive-plan#match-parts!
                          _%terms9376%_
                          _%prefix9542%_
                          _%left9543%_
                          _%right9544%_
                          _%frame9545%_)))))
                (_%$%K93969497%_
                 (lambda (_%c9488%_ _%b9489%_ _%a9490%_)
                   (lambda (_%prefix9492%_
                            _%left9493%_
                            _%right9494%_
                            _%frame9495%_)
                     (if (and (pair? _%prefix9492%_)
                              (null? (let ()
                                       (declare (not safe))
                                       (##cdr _%prefix9492%_))))
                         (begin
                           (vector-set!
                            _%frame9495%_
                            _%a9490%_
                            (car _%prefix9492%_))
                           (vector-set! _%frame9495%_ _%b9489%_ _%left9493%_)
                           (vector-set! _%frame9495%_ _%c9488%_ _%right9494%_)
                           '#t)
                         (gerbil-ascent/core/positive-plan#match-parts!
                          _%terms9376%_
                          _%prefix9492%_
                          _%left9493%_
                          _%right9494%_
                          _%frame9495%_)))))
                (_%$%K93839445%_
                 (lambda (_%c9436%_ _%b9437%_ _%a9438%_)
                   (lambda (_%prefix9440%_
                            _%left9441%_
                            _%right9442%_
                            _%frame9443%_)
                     (if (and (pair? _%prefix9440%_)
                              (null? (let ()
                                       (declare (not safe))
                                       (##cdr _%prefix9440%_))))
                         (if (equal? (vector-ref _%frame9443%_ _%a9438%_)
                                     (car _%prefix9440%_))
                             (if (equal? (vector-ref _%frame9443%_ _%b9437%_)
                                         _%left9441%_)
                                 (begin
                                   (vector-set!
                                    _%frame9443%_
                                    _%c9436%_
                                    _%right9442%_)
                                   '#t)
                                 '#f)
                             '#f)
                         (gerbil-ascent/core/positive-plan#match-parts!
                          _%terms9376%_
                          _%prefix9440%_
                          _%left9441%_
                          _%right9442%_
                          _%frame9443%_))))))
            (if (pair? _%$%terms93779419%_)
                (let ((_%$%tl94119552%_
                       (let ()
                         (declare (not safe))
                         (##cdr _%$%terms93779419%_)))
                      (_%$%hd94109550%_
                       (let ()
                         (declare (not safe))
                         (##car _%$%terms93779419%_))))
                  (if (pair? _%$%hd94109550%_)
                      (let ((_%$%tl94179557%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%hd94109550%_)))
                            (_%$%hd94169555%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%hd94109550%_))))
                        (if (let ()
                              (declare (not safe))
                              (##eq? _%$%hd94169555%_ 'fresh))
                            (if (pair? _%$%tl94119552%_)
                                (let ((_%$%tl94139564%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%tl94119552%_)))
                                      (_%$%hd94129562%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%$%tl94119552%_))))
                                  (if (pair? _%$%hd94129562%_)
                                      (let ((_%$%tl94159569%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%hd94129562%_)))
                                            (_%$%hd94149567%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%hd94129562%_))))
                                        (if (let ()
                                              (declare (not safe))
                                              (##eq? _%$%hd94149567%_ 'fresh))
                                            (if (null? _%$%tl94139564%_)
                                                (let ((_%a9560%_
                                                       _%$%tl94179557%_)
                                                      (_%b9572%_
                                                       _%$%tl94159569%_))
                                                  (_%$%K94099547%_
                                                   _%b9572%_
                                                   _%a9560%_))
                                                (if (pair? _%$%tl94139564%_)
                                                    (let ((_%$%tl94029526%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%tl94139564%_)))
                                                          (_%$%hd94019524%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%tl94139564%_))))
                                                      (if (pair? _%$%hd94019524%_)
                                                          (let ((_%$%tl94049531%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ()
                           (declare (not safe))
                           (##cdr _%$%hd94019524%_)))
                        (_%$%hd94039529%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%hd94019524%_))))
                    (if (let ()
                          (declare (not safe))
                          (##eq? _%$%hd94039529%_ 'fresh))
                        (if (null? _%$%tl94029526%_)
                            (let ((_%a9510%_ _%$%tl94179557%_)
                                  (_%b9522%_ _%$%tl94159569%_)
                                  (_%c9534%_ _%$%tl94049531%_))
                              (_%$%K93969497%_ _%c9534%_ _%b9522%_ _%a9510%_))
                            (_%$%else93819432%_))
                        (_%$%else93819432%_)))
                  (_%$%else93819432%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%else93819432%_)))
                                            (_%$%else93819432%_)))
                                      (_%$%else93819432%_)))
                                (_%$%else93819432%_))
                            (if (let ()
                                  (declare (not safe))
                                  (##eq? _%$%hd94169555%_ 'bound))
                                (if (pair? _%$%tl94119552%_)
                                    (let ((_%$%tl93879462%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%tl94119552%_)))
                                          (_%$%hd93869460%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%tl94119552%_))))
                                      (if (pair? _%$%hd93869460%_)
                                          (let ((_%$%tl93939467%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%hd93869460%_)))
                                                (_%$%hd93929465%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%hd93869460%_))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (##eq? _%$%hd93929465%_
                                                         'bound))
                                                (if (pair? _%$%tl93879462%_)
                                                    (let ((_%$%tl93899474%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%tl93879462%_)))
                                                          (_%$%hd93889472%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%tl93879462%_))))
                                                      (if (pair? _%$%hd93889472%_)
                                                          (let ((_%$%tl93919479%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ()
                           (declare (not safe))
                           (##cdr _%$%hd93889472%_)))
                        (_%$%hd93909477%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%hd93889472%_))))
                    (if (let ()
                          (declare (not safe))
                          (##eq? _%$%hd93909477%_ 'fresh))
                        (if (null? _%$%tl93899474%_)
                            (let ((_%a9458%_ _%$%tl94179557%_)
                                  (_%b9470%_ _%$%tl93939467%_)
                                  (_%c9482%_ _%$%tl93919479%_))
                              (_%$%K93839445%_ _%c9482%_ _%b9470%_ _%a9458%_))
                            (_%$%else93819432%_))
                        (_%$%else93819432%_)))
                  (_%$%else93819432%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%else93819432%_))
                                                (_%$%else93819432%_)))
                                          (_%$%else93819432%_)))
                                    (_%$%else93819432%_))
                                (_%$%else93819432%_))))
                      (_%$%else93819432%_)))
                (_%$%else93819432%_))))))
    (define gerbil-ascent/core/positive-plan#compile-selected-parts-matcher
      (lambda (_%terms9303%_ _%columns9304%_ _%keys9305%_)
        (let* ((_%$%terms93069324%_ _%terms9303%_)
               (_%$%else93089332%_ (lambda () '#f))
               (_%$%K93109345%_
                (lambda (_%slot9335%_)
                  (if (member '0 _%columns9304%_)
                      (if (member '1 _%columns9304%_)
                          (if (let ((__tmp35092
                                     (lambda (_%column9337%_ _%key9338%_)
                                       (equal? _%key9338%_
                                               (list-ref
                                                _%terms9303%_
                                                _%column9337%_)))))
                                (declare (not safe))
                                (andmap__1
                                 __tmp35092
                                 _%columns9304%_
                                 _%keys9305%_))
                              (lambda (_%prefix9340%_
                                       _%left9341%_
                                       _%right9342%_
                                       _%frame9343%_)
                                (if (and (pair? _%prefix9340%_)
                                         (null? (let ()
                                                  (declare (not safe))
                                                  (##cdr _%prefix9340%_))))
                                    (begin
                                      (vector-set!
                                       _%frame9343%_
                                       _%slot9335%_
                                       _%right9342%_)
                                      '#t)
                                    (gerbil-ascent/core/positive-plan#match-parts!
                                     _%terms9303%_
                                     _%prefix9340%_
                                     _%left9341%_
                                     _%right9342%_
                                     _%frame9343%_)))
                              '#f)
                          '#f)
                      '#f))))
          (if (pair? _%$%terms93069324%_)
              (let ((_%$%hd93119348%_
                     (let () (declare (not safe)) (##car _%$%terms93069324%_)))
                    (_%$%tl93129350%_
                     (let ()
                       (declare (not safe))
                       (##cdr _%$%terms93069324%_))))
                (if (pair? _%$%hd93119348%_)
                    (let ((_%$%hd93219353%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%hd93119348%_))))
                      (if (let ()
                            (declare (not safe))
                            (##eq? _%$%hd93219353%_ 'bound))
                          (if (pair? _%$%tl93129350%_)
                              (let ((_%$%hd93139356%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%tl93129350%_)))
                                    (_%$%tl93149358%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%tl93129350%_))))
                                (if (pair? _%$%hd93139356%_)
                                    (let ((_%$%hd93199361%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%hd93139356%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (##eq? _%$%hd93199361%_ 'bound))
                                          (if (pair? _%$%tl93149358%_)
                                              (let ((_%$%hd93159364%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%tl93149358%_)))
                                                    (_%$%tl93169366%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%tl93149358%_))))
                                                (if (pair? _%$%hd93159364%_)
                                                    (let ((_%$%hd93179369%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%hd93159364%_)))
                                                          (_%$%tl93189371%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%hd93159364%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (##eq? _%$%hd93179369%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           'fresh))
                  (let ((_%slot9374%_ _%$%tl93189371%_))
                    (if (null? _%$%tl93169366%_)
                        (_%$%K93109345%_ _%slot9374%_)
                        (_%$%else93089332%_)))
                  (_%$%else93089332%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%else93089332%_)))
                                              (_%$%else93089332%_))
                                          (_%$%else93089332%_)))
                                    (_%$%else93089332%_)))
                              (_%$%else93089332%_))
                          (_%$%else93089332%_)))
                    (_%$%else93089332%_)))
              (_%$%else93089332%_)))))
    (define gerbil-ascent/core/positive-plan#term-value
      (lambda (_%term9297%_ _%frame9298%_)
        (let ((_%$e9300%_ (car _%term9297%_)))
          (if (eq? 'literal _%$e9300%_)
              (cdr _%term9297%_)
              (if (eq? 'expression _%$e9300%_)
                  ((cdr _%term9297%_) _%frame9298%_)
                  (vector-ref _%frame9298%_ (cdr _%term9297%_)))))))
    (define gerbil-ascent/core/positive-plan#compile-parts-output
      (lambda (_%terms9051%_)
        (if (and (<= (length _%terms9051%_) '4)
                 (let ((__tmp35093
                        (lambda (_%term9053%_)
                          (eq? (car _%term9053%_) 'bound))))
                   (declare (not safe))
                   (andmap__0 __tmp35093 _%terms9051%_)))
            (let* ((_%$%g90549088%_ (map cdr _%terms9051%_))
                   (_%$%else90609100%_
                    (lambda ()
                      (lambda (_%frame9096%_)
                        (let ((__tmp35094
                               (let ((__tmp35096
                                      (lambda (_%slot9098%_)
                                        (vector-ref
                                         _%frame9096%_
                                         _%slot9098%_)))
                                     (__tmp35095 (map cdr _%terms9051%_)))
                                 (declare (not safe))
                                 (##map __tmp35096 __tmp35095))))
                          (declare (not safe))
                          (##apply list __tmp35094))))))
              (let ((_%$%K90869290%_
                     (lambda () (lambda (_%frame9288%_) (list))))
                    (_%$%K90839274%_
                     (lambda (_%one9264%_)
                       (lambda (_%frame9266%_)
                         (let* ((_%slot9268%_ _%one9264%_)
                                (_%next9270%_
                                 (vector-ref _%frame9266%_ _%slot9268%_)))
                           (list _%next9270%_)))))
                    (_%$%K90789243%_
                     (lambda (_%two9226%_ _%one9227%_)
                       (lambda (_%frame9229%_)
                         (let* ((_%slot9231%_ _%one9227%_)
                                (_%next9233%_
                                 (vector-ref _%frame9229%_ _%slot9231%_))
                                (_%slot9237%_ _%two9226%_)
                                (_%next9239%_
                                 (vector-ref _%frame9229%_ _%slot9237%_)))
                           (list _%next9233%_ _%next9239%_)))))
                    (_%$%K90719198%_
                     (lambda (_%three9174%_ _%two9175%_ _%one9176%_)
                       (lambda (_%frame9178%_)
                         (let* ((_%slot9180%_ _%one9176%_)
                                (_%next9182%_
                                 (vector-ref _%frame9178%_ _%slot9180%_))
                                (_%slot9186%_ _%two9175%_)
                                (_%next9188%_
                                 (vector-ref _%frame9178%_ _%slot9186%_))
                                (_%slot9192%_ _%three9174%_)
                                (_%next9194%_
                                 (vector-ref _%frame9178%_ _%slot9192%_)))
                           (list _%next9182%_ _%next9188%_ _%next9194%_)))))
                    (_%$%K90629139%_
                     (lambda (_%four9104%_
                              _%three9106%_
                              _%two9108%_
                              _%one9110%_)
                       (lambda (_%frame9113%_)
                         (let* ((_%slot9115%_ _%one9110%_)
                                (_%next9117%_
                                 (vector-ref _%frame9113%_ _%slot9115%_))
                                (_%slot9121%_ _%two9108%_)
                                (_%next9123%_
                                 (vector-ref _%frame9113%_ _%slot9121%_))
                                (_%slot9127%_ _%three9106%_)
                                (_%next9129%_
                                 (vector-ref _%frame9113%_ _%slot9127%_))
                                (_%slot9133%_ _%four9104%_)
                                (_%next9135%_
                                 (vector-ref _%frame9113%_ _%slot9133%_)))
                           (list _%next9117%_
                                 _%next9123%_
                                 _%next9129%_
                                 _%next9135%_))))))
                (let ((_%$%try-match90569284%_
                       (lambda ()
                         (if (pair? _%$%g90549088%_)
                             (let ((_%$%tl90859279%_
                                    (let ()
                                      (declare (not safe))
                                      (##cdr _%$%g90549088%_)))
                                   (_%$%hd90849277%_
                                    (let ()
                                      (declare (not safe))
                                      (##car _%$%g90549088%_))))
                               (if (null? _%$%tl90859279%_)
                                   (let ((_%one9282%_ _%$%hd90849277%_))
                                     (_%$%K90839274%_ _%one9282%_))
                                   (if (pair? _%$%tl90859279%_)
                                       (let ((_%$%tl90829255%_
                                              (let ()
                                                (declare (not safe))
                                                (##cdr _%$%tl90859279%_)))
                                             (_%$%hd90819253%_
                                              (let ()
                                                (declare (not safe))
                                                (##car _%$%tl90859279%_))))
                                         (if (null? _%$%tl90829255%_)
                                             (let ((_%one9251%_
                                                    _%$%hd90849277%_)
                                                   (_%two9258%_
                                                    _%$%hd90819253%_))
                                               (_%$%K90789243%_
                                                _%two9258%_
                                                _%one9251%_))
                                             (if (pair? _%$%tl90829255%_)
                                                 (let ((_%$%tl90779217%_
                                                        (let ()
                                                          (declare (not safe))
                                                          (##cdr _%$%tl90829255%_)))
                                                       (_%$%hd90769215%_
                                                        (let ()
                                                          (declare (not safe))
                                                          (##car _%$%tl90829255%_))))
                                                   (if (null? _%$%tl90779217%_)
                                                       (let ((_%one9206%_
                                                              _%$%hd90849277%_)
                                                             (_%two9213%_
                                                              _%$%hd90819253%_)
                                                             (_%three9220%_
                                                              _%$%hd90769215%_))
                                                         (_%$%K90719198%_
                                                          _%three9220%_
                                                          _%two9213%_
                                                          _%one9206%_))
                                                       (if (pair? _%$%tl90779217%_)
                                                           (let ((_%$%tl90709165%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (let ()
                            (declare (not safe))
                            (##cdr _%$%tl90779217%_)))
                         (_%$%hd90699163%_
                          (let ()
                            (declare (not safe))
                            (##car _%$%tl90779217%_))))
                     (if (null? _%$%tl90709165%_)
                         (let ((_%one9147%_ _%$%hd90849277%_)
                               (_%two9154%_ _%$%hd90819253%_)
                               (_%three9161%_ _%$%hd90769215%_)
                               (_%four9168%_ _%$%hd90699163%_))
                           (_%$%K90629139%_
                            _%four9168%_
                            _%three9161%_
                            _%two9154%_
                            _%one9147%_))
                         (_%$%else90609100%_)))
                   (_%$%else90609100%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (_%$%else90609100%_))))
                                       (_%$%else90609100%_))))
                             (_%$%else90609100%_)))))
                  (if (null? _%$%g90549088%_)
                      (_%$%K90869290%_)
                      (_%$%try-match90569284%_)))))
            (lambda (_%frame9293%_)
              (map (lambda (_%term9295%_)
                     (gerbil-ascent/core/positive-plan#term-value
                      _%term9295%_
                      _%frame9293%_))
                   _%terms9051%_)))))
    (define gerbil-ascent/core/positive-plan#emit-parts-heads!
      (lambda (_%heads9043%_ _%frame9044%_ _%emit-row!9045%_)
        (if (null? _%heads9043%_)
            '#!void
            (begin
              (let ((_%head9047%_ (car _%heads9043%_)))
                (_%emit-row!9045%_
                 (vector-ref _%head9047%_ '0)
                 (if (> (vector-length _%head9047%_) '2)
                     ((vector-ref _%head9047%_ '2) _%frame9044%_)
                     (map (lambda (_%term9049%_)
                            (gerbil-ascent/core/positive-plan#term-value
                             _%term9049%_
                             _%frame9044%_))
                          (vector-ref _%head9047%_ '1)))))
              (gerbil-ascent/core/positive-plan#emit-parts-heads!
               (cdr _%heads9043%_)
               _%frame9044%_
               _%emit-row!9045%_)))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__%
      (lambda (_%plan9002%_
               _%frame9003%_
               _%delta-at9004%_
               _%rows-access9005%_
               _%emit-row!9006%_
               _%checkpoint!9007%_
               _%parts-access9008%_)
        (if (and (vector? _%frame9003%_)
                 (>= (let ()
                       (declare (not safe))
                       (##vector-length _%frame9003%_))
                     (vector-ref _%plan9002%_ '2)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"ASCENT positive plan frame is smaller than compiled extent")))
        (if (and (exact-integer? _%delta-at9004%_)
                 (or (= _%delta-at9004%_ '-1)
                     (and (<= '0 _%delta-at9004%_)
                          (< _%delta-at9004%_ (vector-ref _%plan9002%_ '4)))))
            '#!void
            (let ()
              (declare (not safe))
              (error '"ASCENT positive plan delta selector outside compiled atom extent")))
        (gerbil-ascent/core/positive-plan#visit-positive-atoms!
         (vector-ref _%plan9002%_ '1)
         (vector-ref _%plan9002%_ '0)
         _%frame9003%_
         _%delta-at9004%_
         '0
         _%rows-access9005%_
         _%emit-row!9006%_
         _%checkpoint!9007%_
         _%parts-access9008%_)))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__0
      (lambda (_%plan9016%_
               _%frame9017%_
               _%delta-at9018%_
               _%rows-access9019%_
               _%emit-row!9020%_)
        (let* ((_%checkpoint!9022%_ '#f) (_%parts-access9024%_ '#f))
          (gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__%
           _%plan9016%_
           _%frame9017%_
           _%delta-at9018%_
           _%rows-access9019%_
           _%emit-row!9020%_
           _%checkpoint!9022%_
           _%parts-access9024%_))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__1
      (lambda (_%plan9026%_
               _%frame9027%_
               _%delta-at9028%_
               _%rows-access9029%_
               _%emit-row!9030%_
               _%checkpoint!9031%_)
        (let ((_%parts-access9033%_ '#f))
          (gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__%
           _%plan9026%_
           _%frame9027%_
           _%delta-at9028%_
           _%rows-access9029%_
           _%emit-row!9030%_
           _%checkpoint!9031%_
           _%parts-access9033%_))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!
      (lambda _g35097_
        (let ((_g35098_ (let () (declare (not safe)) (##length _g35097_))))
          (cond ((let () (declare (not safe)) (##fx= _g35098_ 5))
                 (apply gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__0
                        _g35097_))
                ((let () (declare (not safe)) (##fx= _g35098_ 6))
                 (apply gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__1
                        _g35097_))
                ((let () (declare (not safe)) (##fx= _g35098_ 7))
                 (apply gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__%
                        _g35097_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!
                  _g35097_))))))
    (define gerbil-ascent/core/positive-plan#visit-positive-atoms!
      (lambda (_%atoms8797%_
               _%heads8798%_
               _%frame8799%_
               _%delta-at8800%_
               _%depth8801%_
               _%rows-access8802%_
               _%emit-row!8803%_
               _%checkpoint!8804%_
               _%parts-access8805%_)
        (let* ((_%$%atoms89398948%_ _%atoms8797%_)
               (_%$%E89428952%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%atoms89398948%_
                           '([])
                           '([action . _])))
                  '#!void)))
          (let ((_%$%K89468998%_
                 (lambda ()
                   (gerbil-ascent/core/positive-plan#emit-parts-heads!
                    _%heads8798%_
                    _%frame8799%_
                    _%emit-row!8803%_)))
                (_%$%K89438986%_
                 (lambda (_%action8956%_)
                   (let ((_%$e8958%_ (vector-ref _%action8956%_ '0)))
                     (if (eq? 'callbacks _%$e8958%_)
                         (if ((vector-ref _%action8956%_ '1) _%frame8799%_)
                             (gerbil-ascent/core/positive-plan#visit-positive-atoms!
                              (cdr _%atoms8797%_)
                              _%heads8798%_
                              _%frame8799%_
                              _%delta-at8800%_
                              _%depth8801%_
                              _%rows-access8802%_
                              _%emit-row!8803%_
                              _%checkpoint!8804%_
                              _%parts-access8805%_)
                             '#!void)
                         (if (and _%parts-access8805%_
                                  (_%parts-access8805%_
                                   (vector-ref _%action8956%_ '0)
                                   _%frame8799%_
                                   (= _%depth8801%_ _%delta-at8800%_)
                                   (vector-ref _%action8956%_ '2)
                                   (lambda (_%prefix8961%_
                                            _%left8962%_
                                            _%right8963%_)
                                     (if _%checkpoint!8804%_
                                         (_%checkpoint!8804%_)
                                         '#!void)
                                     (if ((or (vector-ref _%action8956%_ '4)
                                              (vector-ref _%action8956%_ '3))
                                          _%prefix8961%_
                                          _%left8962%_
                                          _%right8963%_
                                          _%frame8799%_)
                                         (if (null? (cdr _%atoms8797%_))
                                             (gerbil-ascent/core/positive-plan#emit-parts-heads!
                                              _%heads8798%_
                                              _%frame8799%_
                                              _%emit-row!8803%_)
                                             (gerbil-ascent/core/positive-plan#visit-positive-atoms!
                                              (cdr _%atoms8797%_)
                                              _%heads8798%_
                                              _%frame8799%_
                                              _%delta-at8800%_
                                              (+ _%depth8801%_ '1)
                                              _%rows-access8802%_
                                              _%emit-row!8803%_
                                              _%checkpoint!8804%_
                                              _%parts-access8805%_))
                                         '#!void))))
                             '#!void
                             (let ((_%rows8968%_
                                    (_%rows-access8802%_
                                     (vector-ref _%action8956%_ '0)
                                     _%frame8799%_
                                     (= _%depth8801%_ _%delta-at8800%_)
                                     (vector-ref _%action8956%_ '2))))
                               (if (or (pair? _%rows8968%_)
                                       (null? _%rows8968%_))
                                   (let _%candidates8974%_ ((_%remaining8976%_
                                                             _%rows8968%_))
                                     (if (null? _%remaining8976%_)
                                         '#!void
                                         (begin
                                           (if _%checkpoint!8804%_
                                               (_%checkpoint!8804%_)
                                               '#!void)
                                           (if (gerbil-ascent/core/positive-plan#match-row!
                                                (vector-ref _%action8956%_ '1)
                                                (car _%remaining8976%_)
                                                _%frame8799%_)
                                               (if (null? (cdr _%atoms8797%_))
                                                   (gerbil-ascent/core/positive-plan#emit-parts-heads!
                                                    _%heads8798%_
                                                    _%frame8799%_
                                                    _%emit-row!8803%_)
                                                   (gerbil-ascent/core/positive-plan#visit-positive-atoms!
                                                    (cdr _%atoms8797%_)
                                                    _%heads8798%_
                                                    _%frame8799%_
                                                    _%delta-at8800%_
                                                    (+ _%depth8801%_ '1)
                                                    _%rows-access8802%_
                                                    _%emit-row!8803%_
                                                    _%checkpoint!8804%_
                                                    _%parts-access8805%_))
                                               '#!void)
                                           (_%candidates8974%_
                                            (cdr _%remaining8976%_)))))
                                   (if (let ()
                                         (declare (not safe))
                                         (gerbil-ascent/core/relation-view#gerbil-ascent-row-parts?
                                          _%rows8968%_))
                                       (let ((__tmp35099
                                              (lambda (_%prefix8979%_
                                                       _%left8980%_
                                                       _%right8981%_)
                                                (if _%checkpoint!8804%_
                                                    (_%checkpoint!8804%_)
                                                    '#!void)
                                                (if ((vector-ref
                                                      _%action8956%_
                                                      '3)
                                                     _%prefix8979%_
                                                     _%left8980%_
                                                     _%right8981%_
                                                     _%frame8799%_)
                                                    (if (null? (cdr _%atoms8797%_))
                                                        (gerbil-ascent/core/positive-plan#emit-parts-heads!
                                                         _%heads8798%_
                                                         _%frame8799%_
                                                         _%emit-row!8803%_)
                                                        (gerbil-ascent/core/positive-plan#visit-positive-atoms!
                                                         (cdr _%atoms8797%_)
                                                         _%heads8798%_
                                                         _%frame8799%_
                                                         _%delta-at8800%_
                                                         (+ _%depth8801%_ '1)
                                                         _%rows-access8802%_
                                                         _%emit-row!8803%_
                                                         _%checkpoint!8804%_
                                                         _%parts-access8805%_))
                                                    '#!void))))
                                         (declare (not safe))
                                         (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row-parts
                                          __tmp35099
                                          _%rows8968%_))
                                       (let ((__tmp35100
                                              (lambda (_%row8984%_)
                                                (if _%checkpoint!8804%_
                                                    (_%checkpoint!8804%_)
                                                    '#!void)
                                                (if (gerbil-ascent/core/positive-plan#match-row!
                                                     (vector-ref
                                                      _%action8956%_
                                                      '1)
                                                     _%row8984%_
                                                     _%frame8799%_)
                                                    (if (null? (cdr _%atoms8797%_))
                                                        (gerbil-ascent/core/positive-plan#emit-parts-heads!
                                                         _%heads8798%_
                                                         _%frame8799%_
                                                         _%emit-row!8803%_)
                                                        (gerbil-ascent/core/positive-plan#visit-positive-atoms!
                                                         (cdr _%atoms8797%_)
                                                         _%heads8798%_
                                                         _%frame8799%_
                                                         _%delta-at8800%_
                                                         (+ _%depth8801%_ '1)
                                                         _%rows-access8802%_
                                                         _%emit-row!8803%_
                                                         _%checkpoint!8804%_
                                                         _%parts-access8805%_))
                                                    '#!void))))
                                         (declare (not safe))
                                         (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
                                          __tmp35100
                                          _%rows8968%_)))))))))))
            (let ((_%$%try-match89418994%_
                   (lambda ()
                     (if (pair? _%$%atoms89398948%_)
                         (let* ((_%$%hd89448989%_
                                 (let ()
                                   (declare (not safe))
                                   (##car _%$%atoms89398948%_)))
                                (_%action8992%_ _%$%hd89448989%_))
                           (_%$%K89438986%_ _%action8992%_))
                         (_%$%E89428952%_)))))
              (if (null? _%$%atoms89398948%_)
                  (_%$%K89468998%_)
                  (_%$%try-match89418994%_)))))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-index-key
      (lambda (_%terms8788%_
               _%columns8789%_
               _%environment8790%_
               _%slot-terms8791%_)
        (if _%slot-terms8791%_
            (map (lambda (_%term8793%_)
                   (gerbil-ascent/core/positive-plan#term-value
                    _%term8793%_
                    _%environment8790%_))
                 _%slot-terms8791%_)
            (map (lambda (_%column8795%_)
                   (gerbil-ascent/core/positive-plan#index-term-value
                    (list-ref _%terms8788%_ _%column8795%_)
                    _%environment8790%_))
                 _%columns8789%_))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-index-key/terms
      (lambda (_%key-terms8783%_ _%environment8784%_)
        (map (lambda (_%term8786%_)
               (gerbil-ascent/core/positive-plan#index-term-value
                _%term8786%_
                _%environment8784%_))
             _%key-terms8783%_)))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-index-value
      (lambda (_%term8779%_ _%environment8780%_ _%slot-term8781%_)
        (if _%slot-term8781%_
            (gerbil-ascent/core/positive-plan#term-value
             _%slot-term8781%_
             _%environment8780%_)
            (gerbil-ascent/core/positive-plan#index-term-value
             _%term8779%_
             _%environment8780%_))))
    (define gerbil-ascent/core/positive-plan#index-term-value
      (lambda (_%term8771%_ _%environment8772%_)
        (let ((_%$e8774%_ (car _%term8771%_)))
          (if (eq? 'literal _%$e8774%_)
              (cdr _%term8771%_)
              (if (eq? 'expression _%$e8774%_)
                  (let ((__tmp35101 (cdr _%term8771%_)))
                    (declare (not safe))
                    (gerbil-ascent/core/rule-bindings#gerbil-ascent-expression-value
                     __tmp35101
                     _%environment8772%_))
                  (let ((_%bound8777%_
                         (assq (cdr _%term8771%_) _%environment8772%_)))
                    (if _%bound8777%_
                        '#!void
                        (let ((__tmp35102 (cdr _%term8771%_)))
                          (declare (not safe))
                          (error '"unbound ASCENT index variable" __tmp35102)))
                    (cdr _%bound8777%_)))))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-emit-heads!
      (lambda (_%heads8761%_ _%environment8762%_ _%emit-row!8763%_)
        (let _%emit8765%_ ((_%remaining8767%_ _%heads8761%_))
          (if (null? _%remaining8767%_)
              '#!void
              (begin
                (let ((_%head8769%_ (car _%remaining8767%_)))
                  (_%emit-row!8763%_
                   _%head8769%_
                   (let ((__tmp35103 (vector-ref _%head8769%_ '1)))
                     (declare (not safe))
                     (gerbil-ascent/core/rule-bindings#gerbil-ascent-head-row
                      __tmp35103
                      _%environment8762%_))))
                (_%emit8765%_ (cdr _%remaining8767%_)))))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-prepare-rule-activations
      (lambda (_%active8755%_)
        (vector-map
         (lambda (_%rules8757%_)
           (map (lambda (_%rule8759%_)
                  (vector (vector-ref _%rule8759%_ '0)
                          (vector-ref _%rule8759%_ '1)
                          (vector-ref _%rule8759%_ '2)
                          (vector-ref _%rule8759%_ '3)
                          (list->vector
                           (gerbil-ascent/core/positive-plan#active-prefix
                            (vector-ref _%rule8759%_ '1)))
                          (gerbil-ascent/core/positive-plan#gerbil-ascent-positive-plan
                           _%rule8759%_)))
                _%rules8757%_))
         _%active8755%_)))
    (define gerbil-ascent/core/positive-plan#active-prefix
      (lambda (_%body8749%_)
        (if (and (pair? _%body8749%_)
                 (eq? (vector-ref
                       (let () (declare (not safe)) (##car _%body8749%_))
                       '0)
                      'atom))
            (let ((_%atom8751%_ (vector-ref (car _%body8749%_) '1)))
              (cons (vector-ref _%atom8751%_ '0)
                    (if (and (null? (vector-ref _%atom8751%_ '2))
                             (let ((__tmp35105
                                    (lambda (_%term8753%_)
                                      (eq? (car _%term8753%_) 'variable)))
                                   (__tmp35104 (vector-ref _%atom8751%_ '1)))
                               (declare (not safe))
                               (andmap__0 __tmp35105 __tmp35104)))
                        (gerbil-ascent/core/positive-plan#active-prefix
                         (cdr _%body8749%_))
                        '())))
            '())))))
