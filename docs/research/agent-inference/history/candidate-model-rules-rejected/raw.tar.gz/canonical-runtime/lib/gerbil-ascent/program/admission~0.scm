(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/admission::timestamp 1791687860)
  (begin
    (define gerbil-ascent/program/admission#gerbil-ascent-check-replacement-rows!
      (lambda (_%name15638%_ _%rows15639%_ _%width15640%_ _%check15641%_)
        (if (list? _%rows15639%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT replacement source rows"
                     _%name15638%_
                     _%rows15639%_)))
        (for-each
         (lambda (_%row15643%_)
           (if (and (list? _%row15643%_)
                    (= (let () (declare (not safe)) (##length _%row15643%_))
                       _%width15640%_))
               '#!void
               (let ()
                 (declare (not safe))
                 (error '"invalid ASCENT replacement source row"
                        _%name15638%_
                        _%row15643%_)))
           (if _%check15641%_ (_%check15641%_ _%row15643%_) '#!void))
         _%rows15639%_)))
    (define gerbil-ascent/program/admission#gerbil-ascent-initialize-source-row!
      (lambda (_%stored15629%_
               _%width15630%_
               _%check15631%_
               _%present15632%_
               _%all15633%_
               _%index15634%_
               _%count15635%_
               _%output-limit15636%_)
        (if (and (list? _%stored15629%_)
                 (= (let () (declare (not safe)) (##length _%stored15629%_))
                    _%width15630%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT storage provider row" _%stored15629%_)))
        (if _%check15631%_ (_%check15631%_ _%stored15629%_) '#!void)
        (gerbil-ascent/program/admission#gerbil-ascent-admit-source-row!
         _%stored15629%_
         _%present15632%_
         _%all15633%_
         _%index15634%_
         _%count15635%_
         _%output-limit15636%_)))
    (define gerbil-ascent/program/admission#gerbil-ascent-admit-source-row!
      (lambda (_%stored15620%_
               _%present15621%_
               _%all15622%_
               _%index15623%_
               _%count15624%_
               _%output-limit15625%_)
        (let ()
          (declare (not safe))
          (hash-put! _%present15621%_ _%stored15620%_ '#t))
        (let ((_%next-count15627%_ (+ _%count15624%_ '1)))
          (if (> _%next-count15627%_ _%output-limit15625%_)
              (let ()
                (declare (not safe))
                (error '"ASCENT source fact budget exceeded"))
              '#!void)
          (vector-set!
           _%all15622%_
           _%index15623%_
           (cons _%stored15620%_ (vector-ref _%all15622%_ _%index15623%_)))
          _%next-count15627%_)))
    (define gerbil-ascent/program/admission#gerbil-ascent-prepare-storage-batch
      (lambda (_%expanded15432%_
               _%width15433%_
               _%check15434%_
               _%present15435%_
               _%count15436%_
               _%output-limit15437%_)
        (if (list? _%expanded15432%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"ASCENT storage provider returned non-list rows")))
        (let* ((_%batch-seen15439%_
                (if (pair? _%expanded15432%_)
                    (if (pair? (let ()
                                 (declare (not safe))
                                 (##cdr _%expanded15432%_)))
                        (let ()
                          (declare (not safe))
                          (make-hash-table__%
                           '#f
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value))
                        '#f)
                    '#f))
               (_%accepted15615%_
                (let* ((_%head15441%_ (cons '#f '()))
                       (_%tail15444%_ _%head15441%_))
                  (for-each
                   (lambda (_%stored15607%_)
                     (if (and (list? _%stored15607%_)
                              (= (let ()
                                   (declare (not safe))
                                   (##length _%stored15607%_))
                                 _%width15433%_))
                         '#!void
                         (let ()
                           (declare (not safe))
                           (error '"invalid ASCENT storage provider row"
                                  _%stored15607%_)))
                     (if _%check15434%_
                         (_%check15434%_ _%stored15607%_)
                         '#!void)
                     (if (or (let ()
                               (declare (not safe))
                               (hash-get _%present15435%_ _%stored15607%_))
                             (and _%batch-seen15439%_
                                  (let ()
                                    (declare (not safe))
                                    (__hash-get
                                     _%batch-seen15439%_
                                     _%stored15607%_))))
                         '#!void
                         (begin
                           (if _%batch-seen15439%_
                               (let ()
                                 (declare (not safe))
                                 (__hash-put!
                                  _%batch-seen15439%_
                                  _%stored15607%_
                                  '#t))
                               '#!void)
                           (let ((_%new-tail15612%_
                                  (cons _%stored15607%_ '())))
                             (let ()
                               (declare (not safe))
                               (##set-cdr! _%tail15444%_ _%new-tail15612%_))
                             (set! _%tail15444%_ _%new-tail15612%_)))))
                   _%expanded15432%_)
                  (let () (declare (not safe)) (##cdr _%head15441%_))))
               (_%added-count15617%_
                (if _%batch-seen15439%_
                    (let ()
                      (declare (not safe))
                      (__hash-length _%batch-seen15439%_))
                    (if (pair? _%accepted15615%_) '1 '0))))
          (if (> (+ _%count15436%_ _%added-count15617%_) _%output-limit15437%_)
              (let ()
                (declare (not safe))
                (error '"ASCENT session output fact budget exceeded"))
              '#!void)
          (values _%accepted15615%_ _%added-count15617%_))))))
