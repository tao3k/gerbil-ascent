prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/table

(begin
  (declare-type
   gerbil-ascent/table/access#extend-scalar-index!
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/access)))
  (declare-type
   gerbil-ascent/table/access#gerbil-ascent-physical-index-single-rows
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/access)))
  (declare-type
   gerbil-ascent/table/access#gerbil-ascent-physical-index-build
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/access)))
  (declare-type
   gerbil-ascent/table/access#gerbil-ascent-physical-index-extend!
   (@lambda 4
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/access)))
  (declare-type
   gerbil-ascent/table/access#gerbil-ascent-physical-index-rows
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/access))))
