(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/candidate/datum")
    (load-module "gerbil-ascent/candidate/program")
    (load-module "gerbil-ascent/candidate/reasoning"))
  (load-module "gerbil-ascent/candidate/feedback~0"))
