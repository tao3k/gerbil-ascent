import ast,importlib.util,json,hashlib,tarfile,shutil
from pathlib import Path
p=Path.cwd()/'tools/research/candidate-model.py';spec=importlib.util.spec_from_file_location('m',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b=m.RUNTIME.parent;run=b/'complete-branch-reuse';doc=m.ROOT/'docs/research/agent-inference/fact-reuse-results/complete-branch-reuse';plan=m.reuse_verify(run);report=json.loads((doc/'report.json').read_text());calls=[]
for row in report['trajectories']:
 spent=0
 for call in row['calls']:
  d=run/'calls'/f"{row['case']}-{row['arm']}"/str(call['turn']);req=json.loads((d/'request.json').read_text());meta=json.loads((d/'response.json').read_text());term=meta['terminal'];u=term['usage']
  assert call['grossTokens']==u['input_tokens']+u['output_tokens']
  assert u['output_tokens']<=req['max_output_tokens'] and u['input_tokens']<=call['inputReservation']
  assert req['text']['format']['schema']==plan['tool']['parameters'] and req['reasoning']=={'effort':'low'} and 'instructions' not in req
  assert spent+call['reservation']<=plan['budget'];spent+=call['grossTokens'];assert spent<=plan['budget']
  if not call['failure']:
   action,encoding,cid=m.branch_action(term);assert action==call['action'] and encoding==call['wireEncoding']
   assert m.judge_selection(plan['tasks'][row['case']],call['selection'])==call['evaluation']
  if call['turn']:
   prev=json.loads((d.parent/str(call['turn']-1)/'request.json').read_text());prev_term=json.loads((d.parent/str(call['turn']-1)/'response.json').read_text())['terminal']
   history=prev['input']+prev_term['output'];assert req['input'][:len(history)]==history
   added=req['input'][len(history):]
   last=json.loads(added[-1]['content']);assert last['question']=='Choose one available parentId and optionId to expand while searching for the highest-value feasible complete selection.'
  calls.append({'case':row['case'],'arm':row['arm'],'turn':call['turn'],'status':term['status'],'model':term.get('model'),'input':u['input_tokens'],'output':u['output_tokens'],'thinking':u['output_tokens_details']['reasoning_tokens'],'failure':call['failure']})
 assert spent==row['grossTokens'] and row['shutdown']['clean']
raw_files={}
for name in ['model-dialogue-reuse','remaining-budget-reuse','complete-branch-reuse']:
 parent=m.ROOT/'docs/research/agent-inference/fact-reuse-results'/name
 integrity=json.loads((parent/'integrity.json').read_text())
 assert all(m.digest(parent/n)==h for n,h in integrity['files'].items())
 raw_files[name]=m.digest(parent/'raw.tar.gz')
controls=[]
for name in ['dialogue-qualification','required-tool-qualification','branch-turn-qualification','structured-branch-turn-qualification']:
 receipts=json.loads((b/name/'receipt.json').read_text());controls.append({'name':name,'calls':receipts,'knownTokens':sum(r['usage']['input_tokens']+r['usage']['output_tokens'] for r in receipts if r.get('usage')),'unknownCostCalls':sum(not r.get('usage') for r in receipts)})
parents=[json.loads((m.ROOT/'docs/research/agent-inference/fact-reuse-results'/n/'report.json').read_text()) for n in ['model-dialogue-reuse','remaining-budget-reuse']]
cap=json.loads((m.RUNTIME/'source-capture.json').read_text())
live_drift=[n for n,h in cap['sourceSha256'].items() if m.digest(m.ROOT/n)!=h]
audit={'passed':True,'planSha256':m.digest(run/'plan.json'),'taskAndSelectionJudgeUnchanged':True,'sourceCapture':cap,'liveSourceDriftAtAudit':live_drift,'solverCalls':calls,'outputTruncatedCalls':sum(c['status']=='incomplete' for c in calls),'invalidActionTrajectories':sum(bool(r.get('failure')) for r in report['trajectories']),'unknownCostCalls':report['solverUnknownCostCalls'],'budgetPerTrajectory':65536,'allActualInputAndThinkingCharged':True,'rawArchiveSha256':raw_files,'controls':controls,'allAttemptsKnownSolverTokens':sum(r['solverKnownTokens'] for r in parents+[report]),'allAttemptsKnownAnnotationTokens':sum(r['annotationKnownTokens'] for r in parents+[report]),'controlKnownTokens':sum(c['knownTokens'] for c in controls),'controlUnknownCostCalls':sum(c['unknownCostCalls'] for c in controls),'repeatMeasurementScope':'Only independently true positive path/ready derivations with explicit supported premises. Negative/absence repetitions, resource/value recomputation, hidden reasoning, annotation completeness and inter-rater agreement are not established. Zero observed repeats is not evidence of zero true repeats.'}
m.save(doc/'audit.json',audit)
with tarfile.open(doc/'qualification-raw.tar.gz','w:gz') as tar:
 tar.add(b/'latest-proof-frame-qualification',arcname='qualification')
 for directory in ['current-proof-frame-build','latest-proof-frame-rebuild']:
  for f in (b/directory).iterdir():
   if f.is_file():tar.add(f,arcname='build/'+directory+'/'+f.name)
 for directory in ['dialogue-qualification','required-tool-qualification','branch-turn-qualification','structured-branch-turn-qualification']:
  tar.add(b/directory,arcname='controls/'+directory)
 for name in ['ascent-build-latest.py','ascent-rebuild-bound.py','ascent-qualify-latest.py','ascent-rules-latest.py','ascent-latest-store-test.py','ascent-branch-turn-check.py','ascent-structured-turn-check.py','ascent-pipeline-labels.py','ascent-final-audit.py']:
  tar.add(Path('/tmp')/name,arcname='scripts/'+name)
 for name in ['model-dialogue','remaining-budget','complete-branch']:
  for phase in ['freeze','solve','labels','report']:
   f=b/(name+'-'+phase+'.log')
   if f.exists():tar.add(f,arcname='logs/'+f.name)
print('FINAL_AUDIT_OK',len(calls),audit['allAttemptsKnownSolverTokens'],audit['allAttemptsKnownAnnotationTokens'],audit['controlKnownTokens'],flush=True)
