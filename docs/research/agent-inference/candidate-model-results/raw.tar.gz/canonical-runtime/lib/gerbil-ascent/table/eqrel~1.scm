(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/eqrel[1]#_g34320_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34322_|
    (##structure
     gx#syntax-quote::t
     'make-eqrel-component
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34324_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34326_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34327_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34329_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34330_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34332_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-component-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34333_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-component-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34335_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-component-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34336_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-component-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34338_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34340_|
    (##structure
     gx#syntax-quote::t
     'make-eqrel-cut
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34342_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34344_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34345_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34347_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34348_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut-view-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34350_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-cut-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34351_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-cut-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34353_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-cut-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34354_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-cut-view-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34356_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34358_|
    (##structure
     gx#syntax-quote::t
     'make-eqrel-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34360_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34362_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-components
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34363_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34364_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-published
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34365_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-origin
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34367_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-components-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34368_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34369_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-published-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34370_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-origin-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34372_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-components
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34373_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34374_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-published
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34375_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-origin
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34377_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-components-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34378_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34379_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-published-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34380_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-origin-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34382_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34384_|
    (##structure
     gx#syntax-quote::t
     'make-coordinate-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34386_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34388_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-bound?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34389_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34390_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-coherent?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34392_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-bound?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34393_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34394_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-coherent?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34396_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-bound?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34397_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34398_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-coherent?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34400_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-bound?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34401_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g34402_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-coherent?-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/table/eqrel[:0:]#eqrel-component|
      (let ((__obj34141
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34141
           'gerbil-ascent/table/eqrel#eqrel-component::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34141 'eqrel-component '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34141 '(members size) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34141 '(members size) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34141 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34141 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34141 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34141 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34141 '#f '13 '#f '#f))
        (let ((__tmp34319 |gerbil-ascent/table/eqrel[1]#_g34320_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34141 __tmp34319 '4 '#f '#f))
        (let ((__tmp34321 |gerbil-ascent/table/eqrel[1]#_g34322_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34141 __tmp34321 '14 '#f '#f))
        (let ((__tmp34323 |gerbil-ascent/table/eqrel[1]#_g34324_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34141 __tmp34323 '15 '#f '#f))
        (let ((__tmp34325
               (cons (cons 'members |gerbil-ascent/table/eqrel[1]#_g34326_|)
                     (cons (cons 'size |gerbil-ascent/table/eqrel[1]#_g34327_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34141 __tmp34325 '16 '#f '#f))
        (let ((__tmp34328
               (cons (cons 'members |gerbil-ascent/table/eqrel[1]#_g34329_|)
                     (cons (cons 'size |gerbil-ascent/table/eqrel[1]#_g34330_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34141 __tmp34328 '17 '#f '#f))
        (let ((__tmp34331
               (cons (cons 'members |gerbil-ascent/table/eqrel[1]#_g34332_|)
                     (cons (cons 'size |gerbil-ascent/table/eqrel[1]#_g34333_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34141 __tmp34331 '18 '#f '#f))
        (let ((__tmp34334
               (cons (cons 'members |gerbil-ascent/table/eqrel[1]#_g34335_|)
                     (cons (cons 'size |gerbil-ascent/table/eqrel[1]#_g34336_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34141 __tmp34334 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34141 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34141 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34141 '() '21 '#f '#f))
        __obj34141))
    (define |gerbil-ascent/table/eqrel[:0:]#eqrel-cut|
      (let ((__obj34142
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34142
           'gerbil-ascent/table/eqrel#eqrel-cut::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34142 'eqrel-cut '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34142 '(count view) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34142 '(count view) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34142 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34142 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34142 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34142 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34142 '#f '13 '#f '#f))
        (let ((__tmp34337 |gerbil-ascent/table/eqrel[1]#_g34338_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34142 __tmp34337 '4 '#f '#f))
        (let ((__tmp34339 |gerbil-ascent/table/eqrel[1]#_g34340_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34142 __tmp34339 '14 '#f '#f))
        (let ((__tmp34341 |gerbil-ascent/table/eqrel[1]#_g34342_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34142 __tmp34341 '15 '#f '#f))
        (let ((__tmp34343
               (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g34344_|)
                     (cons (cons 'view |gerbil-ascent/table/eqrel[1]#_g34345_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34142 __tmp34343 '16 '#f '#f))
        (let ((__tmp34346
               (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g34347_|)
                     (cons (cons 'view |gerbil-ascent/table/eqrel[1]#_g34348_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34142 __tmp34346 '17 '#f '#f))
        (let ((__tmp34349
               (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g34350_|)
                     (cons (cons 'view |gerbil-ascent/table/eqrel[1]#_g34351_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34142 __tmp34349 '18 '#f '#f))
        (let ((__tmp34352
               (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g34353_|)
                     (cons (cons 'view |gerbil-ascent/table/eqrel[1]#_g34354_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34142 __tmp34352 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34142 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34142 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34142 '() '21 '#f '#f))
        __obj34142))
    (define |gerbil-ascent/table/eqrel[:0:]#eqrel-state|
      (let ((__obj34143
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34143
           'gerbil-ascent/table/eqrel#eqrel-state::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34143 'eqrel-state '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34143
           '(components count published origin)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34143
           '(components count published origin)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34143 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34143 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34143 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34143 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34143 '#f '13 '#f '#f))
        (let ((__tmp34355 |gerbil-ascent/table/eqrel[1]#_g34356_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34143 __tmp34355 '4 '#f '#f))
        (let ((__tmp34357 |gerbil-ascent/table/eqrel[1]#_g34358_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34143 __tmp34357 '14 '#f '#f))
        (let ((__tmp34359 |gerbil-ascent/table/eqrel[1]#_g34360_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34143 __tmp34359 '15 '#f '#f))
        (let ((__tmp34361
               (cons (cons 'components |gerbil-ascent/table/eqrel[1]#_g34362_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/eqrel[1]#_g34363_|)
                           (cons (cons 'published
                                       |gerbil-ascent/table/eqrel[1]#_g34364_|)
                                 (cons (cons 'origin
                                             |gerbil-ascent/table/eqrel[1]#_g34365_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34143 __tmp34361 '16 '#f '#f))
        (let ((__tmp34366
               (cons (cons 'components |gerbil-ascent/table/eqrel[1]#_g34367_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/eqrel[1]#_g34368_|)
                           (cons (cons 'published
                                       |gerbil-ascent/table/eqrel[1]#_g34369_|)
                                 (cons (cons 'origin
                                             |gerbil-ascent/table/eqrel[1]#_g34370_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34143 __tmp34366 '17 '#f '#f))
        (let ((__tmp34371
               (cons (cons 'components |gerbil-ascent/table/eqrel[1]#_g34372_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/eqrel[1]#_g34373_|)
                           (cons (cons 'published
                                       |gerbil-ascent/table/eqrel[1]#_g34374_|)
                                 (cons (cons 'origin
                                             |gerbil-ascent/table/eqrel[1]#_g34375_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34143 __tmp34371 '18 '#f '#f))
        (let ((__tmp34376
               (cons (cons 'components |gerbil-ascent/table/eqrel[1]#_g34377_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/eqrel[1]#_g34378_|)
                           (cons (cons 'published
                                       |gerbil-ascent/table/eqrel[1]#_g34379_|)
                                 (cons (cons 'origin
                                             |gerbil-ascent/table/eqrel[1]#_g34380_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34143 __tmp34376 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34143 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34143 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34143 '() '21 '#f '#f))
        __obj34143))
    (define |gerbil-ascent/table/eqrel[:0:]#coordinate-key|
      (let ((__obj34144
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34144
           'gerbil-ascent/table/eqrel#coordinate-key::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34144 'coordinate-key '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34144
           '(bound? value coherent?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34144
           '(bound? value coherent?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34144 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34144 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34144 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34144 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34144 '#f '13 '#f '#f))
        (let ((__tmp34381 |gerbil-ascent/table/eqrel[1]#_g34382_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34144 __tmp34381 '4 '#f '#f))
        (let ((__tmp34383 |gerbil-ascent/table/eqrel[1]#_g34384_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34144 __tmp34383 '14 '#f '#f))
        (let ((__tmp34385 |gerbil-ascent/table/eqrel[1]#_g34386_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34144 __tmp34385 '15 '#f '#f))
        (let ((__tmp34387
               (cons (cons 'bound? |gerbil-ascent/table/eqrel[1]#_g34388_|)
                     (cons (cons 'value
                                 |gerbil-ascent/table/eqrel[1]#_g34389_|)
                           (cons (cons 'coherent?
                                       |gerbil-ascent/table/eqrel[1]#_g34390_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34144 __tmp34387 '16 '#f '#f))
        (let ((__tmp34391
               (cons (cons 'bound? |gerbil-ascent/table/eqrel[1]#_g34392_|)
                     (cons (cons 'value
                                 |gerbil-ascent/table/eqrel[1]#_g34393_|)
                           (cons (cons 'coherent?
                                       |gerbil-ascent/table/eqrel[1]#_g34394_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34144 __tmp34391 '17 '#f '#f))
        (let ((__tmp34395
               (cons (cons 'bound? |gerbil-ascent/table/eqrel[1]#_g34396_|)
                     (cons (cons 'value
                                 |gerbil-ascent/table/eqrel[1]#_g34397_|)
                           (cons (cons 'coherent?
                                       |gerbil-ascent/table/eqrel[1]#_g34398_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34144 __tmp34395 '18 '#f '#f))
        (let ((__tmp34399
               (cons (cons 'bound? |gerbil-ascent/table/eqrel[1]#_g34400_|)
                     (cons (cons 'value
                                 |gerbil-ascent/table/eqrel[1]#_g34401_|)
                           (cons (cons 'coherent?
                                       |gerbil-ascent/table/eqrel[1]#_g34402_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34144 __tmp34399 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34144 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34144 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34144 '() '21 '#f '#f))
        __obj34144))))
