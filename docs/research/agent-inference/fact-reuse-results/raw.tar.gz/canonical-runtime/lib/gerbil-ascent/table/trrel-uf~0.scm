(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/trrel-uf::timestamp 1791690988)
  (begin
    (define gerbil-ascent/table/trrel-uf#uf-node::t
      (let ((__tmp34490 (list)) (__tmp34489 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/trrel-uf#uf-node::t
         'uf-node
         __tmp34490
         '(parent members size reach predecessors order)
         __tmp34489
         '#f)))
    (define gerbil-ascent/table/trrel-uf#uf-node?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/trrel-uf#uf-node::t)))
    (define gerbil-ascent/table/trrel-uf#make-uf-node
      (lambda _%$args1317%_
        (apply make-instance
               gerbil-ascent/table/trrel-uf#uf-node::t
               _%$args1317%_)))
    (define gerbil-ascent/table/trrel-uf#uf-node-parent
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'parent)))
    (define gerbil-ascent/table/trrel-uf#uf-node-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'members)))
    (define gerbil-ascent/table/trrel-uf#uf-node-size
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'size)))
    (define gerbil-ascent/table/trrel-uf#uf-node-reach
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'reach)))
    (define gerbil-ascent/table/trrel-uf#uf-node-predecessors
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'predecessors)))
    (define gerbil-ascent/table/trrel-uf#uf-node-order
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'order)))
    (define gerbil-ascent/table/trrel-uf#uf-node-parent-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'parent)))
    (define gerbil-ascent/table/trrel-uf#uf-node-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'members)))
    (define gerbil-ascent/table/trrel-uf#uf-node-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'size)))
    (define gerbil-ascent/table/trrel-uf#uf-node-reach-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'reach)))
    (define gerbil-ascent/table/trrel-uf#uf-node-predecessors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'predecessors)))
    (define gerbil-ascent/table/trrel-uf#uf-node-order-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'order)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-parent
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'parent)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'members)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-size
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'size)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-reach
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'reach)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-predecessors
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'predecessors)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-order
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-node::t
         'order)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-parent-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'parent)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'members)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'size)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-reach-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'reach)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-predecessors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'predecessors)))
    (define gerbil-ascent/table/trrel-uf#&uf-node-order-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-node::t
         'order)))
    (define gerbil-ascent/table/trrel-uf#uf-group::t
      (let ((__tmp34492 (list)) (__tmp34491 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/trrel-uf#uf-group::t
         'uf-group
         __tmp34492
         '(nodes roots next-order indexed?)
         __tmp34491
         '#f)))
    (define gerbil-ascent/table/trrel-uf#uf-group?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/trrel-uf#uf-group::t)))
    (define gerbil-ascent/table/trrel-uf#make-uf-group
      (lambda _%$args1314%_
        (apply make-instance
               gerbil-ascent/table/trrel-uf#uf-group::t
               _%$args1314%_)))
    (define gerbil-ascent/table/trrel-uf#uf-group-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'nodes)))
    (define gerbil-ascent/table/trrel-uf#uf-group-roots
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'roots)))
    (define gerbil-ascent/table/trrel-uf#uf-group-next-order
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'next-order)))
    (define gerbil-ascent/table/trrel-uf#uf-group-indexed?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'indexed?)))
    (define gerbil-ascent/table/trrel-uf#uf-group-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'nodes)))
    (define gerbil-ascent/table/trrel-uf#uf-group-roots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'roots)))
    (define gerbil-ascent/table/trrel-uf#uf-group-next-order-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'next-order)))
    (define gerbil-ascent/table/trrel-uf#uf-group-indexed?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'indexed?)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-nodes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'nodes)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-roots
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'roots)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-next-order
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'next-order)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-indexed?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-group::t
         'indexed?)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-nodes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'nodes)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-roots-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'roots)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-next-order-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'next-order)))
    (define gerbil-ascent/table/trrel-uf#&uf-group-indexed?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-group::t
         'indexed?)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion::t
      (let ((__tmp34494 (list))
            (__tmp34493
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/trrel-uf#uf-insertion::t
         'uf-insertion
         __tmp34494
         '(group-key group row left-node right-node a b)
         __tmp34493
         '#f)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/table/trrel-uf#uf-insertion::t)))
    (define gerbil-ascent/table/trrel-uf#make-uf-insertion
      (lambda _%$args1311%_
        (apply make-instance
               gerbil-ascent/table/trrel-uf#uf-insertion::t
               _%$args1311%_)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-group-key
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group-key)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-group
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-row
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'row)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-left-node
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'left-node)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-right-node
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'right-node)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-a
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'a)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-b
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'b)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-group-key-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group-key)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-group-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-row-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'row)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-left-node-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'left-node)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-right-node-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'right-node)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-a-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'a)))
    (define gerbil-ascent/table/trrel-uf#uf-insertion-b-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'b)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-group-key
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group-key)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-group
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-row
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'row)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-left-node
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'left-node)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-right-node
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'right-node)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-a
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'a)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-b
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'b)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-group-key-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group-key)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-group-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'group)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-row-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'row)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-left-node-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'left-node)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-right-node-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'right-node)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-a-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'a)))
    (define gerbil-ascent/table/trrel-uf#&uf-insertion-b-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#uf-insertion::t
         'b)))
    (define gerbil-ascent/table/trrel-uf#frozen-members::t
      (let ((__tmp34496 (list))
            (__tmp34495
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/trrel-uf#frozen-members::t
         'frozen-members
         __tmp34496
         '(rows count)
         __tmp34495
         '#f)))
    (define gerbil-ascent/table/trrel-uf#frozen-members?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/table/trrel-uf#frozen-members::t)))
    (define gerbil-ascent/table/trrel-uf#make-frozen-members
      (lambda _%$args1308%_
        (apply make-instance
               gerbil-ascent/table/trrel-uf#frozen-members::t
               _%$args1308%_)))
    (define gerbil-ascent/table/trrel-uf#frozen-members-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'rows)))
    (define gerbil-ascent/table/trrel-uf#frozen-members-count
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'count)))
    (define gerbil-ascent/table/trrel-uf#frozen-members-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'rows)))
    (define gerbil-ascent/table/trrel-uf#frozen-members-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'count)))
    (define gerbil-ascent/table/trrel-uf#&frozen-members-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'rows)))
    (define gerbil-ascent/table/trrel-uf#&frozen-members-count
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'count)))
    (define gerbil-ascent/table/trrel-uf#&frozen-members-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'rows)))
    (define gerbil-ascent/table/trrel-uf#&frozen-members-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/trrel-uf#frozen-members::t
         'count)))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-state
      (lambda ()
        (let ()
          (declare (not safe))
          (make-hash-table__%
           '#f
           absent-value
           absent-value
           absent-value
           absent-value
           absent-value
           absent-value
           absent-value
           absent-value))))
    (define gerbil-ascent/table/trrel-uf#root
      (lambda (_%node1305%_)
        (if (##structure-ref
             _%node1305%_
             '1
             gerbil-ascent/table/trrel-uf#uf-node::t
             '#f)
            (gerbil-ascent/table/trrel-uf#root
             (##structure-ref
              _%node1305%_
              '1
              gerbil-ascent/table/trrel-uf#uf-node::t
              '#f))
            _%node1305%_)))
    (define gerbil-ascent/table/trrel-uf#reachable?
      (lambda (_%from1299%_ _%to1300%_)
        (let ((_%$e1302%_ (eq? _%from1299%_ _%to1300%_)))
          (if _%$e1302%_
              _%$e1302%_
              (let ((__tmp34497
                     (##structure-ref
                      _%from1299%_
                      '4
                      gerbil-ascent/table/trrel-uf#uf-node::t
                      '#f)))
                (declare (not safe))
                (hash-get __tmp34497 _%to1300%_))))))
    (define gerbil-ascent/table/trrel-uf#fresh
      (lambda (_%node1295%_ _%order1296%_ _%indexed?1297%_)
        (let ((__tmp34500 (list _%node1295%_))
              (__tmp34499 (let () (declare (not safe)) (make-hash-table-eq)))
              (__tmp34498
               (if _%indexed?1297%_
                   (let () (declare (not safe)) (make-hash-table-eq))
                   '#f)))
          (declare (not safe))
          (##structure
           gerbil-ascent/table/trrel-uf#uf-node::t
           '#f
           __tmp34500
           '1
           __tmp34499
           __tmp34498
           _%order1296%_))))
    (define gerbil-ascent/table/trrel-uf#ordered-neighbors
      (lambda (_%node1289%_ _%table1290%_)
        (let ((__tmp34502
               (lambda (_%a1292%_ _%b1293%_)
                 (> (##structure-ref
                     _%a1292%_
                     '6
                     gerbil-ascent/table/trrel-uf#uf-node::t
                     '#f)
                    (##structure-ref
                     _%b1293%_
                     '6
                     gerbil-ascent/table/trrel-uf#uf-node::t
                     '#f))))
              (__tmp34501
               (cons _%node1289%_
                     (let () (declare (not safe)) (hash-keys _%table1290%_)))))
          (declare (not safe))
          (##list-sort __tmp34502 __tmp34501))))
    (define gerbil-ascent/table/trrel-uf#rebuild-predecessors!
      (lambda (_%roots1280%_)
        (for-each
         (lambda (_%n1282%_)
           (##structure-set!
            _%n1282%_
            (let () (declare (not safe)) (make-hash-table-eq))
            '5
            gerbil-ascent/table/trrel-uf#uf-node::t
            '#f))
         _%roots1280%_)
        (for-each
         (lambda (_%n1284%_)
           (let ((__tmp34504
                  (lambda (_%target1286%_ _%_1287%_)
                    (let ((__tmp34505
                           (##structure-ref
                            _%target1286%_
                            '5
                            gerbil-ascent/table/trrel-uf#uf-node::t
                            '#f)))
                      (declare (not safe))
                      (hash-put! __tmp34505 _%n1284%_ '#t))))
                 (__tmp34503
                  (##structure-ref
                   _%n1284%_
                   '4
                   gerbil-ascent/table/trrel-uf#uf-node::t
                   '#f)))
             (declare (not safe))
             (hash-for-each __tmp34504 __tmp34503)))
         _%roots1280%_)))
    (define gerbil-ascent/table/trrel-uf#retire-cycle-predecessors!
      (lambda (_%winner1272%_ _%cycle1273%_)
        (for-each
         (lambda (_%n1275%_)
           (if (eq? _%n1275%_ _%winner1272%_)
               '#!void
               (let ((__tmp34507
                      (lambda (_%target1277%_ _%_1278%_)
                        (let ((__tmp34508
                               (##structure-ref
                                _%target1277%_
                                '5
                                gerbil-ascent/table/trrel-uf#uf-node::t
                                '#f)))
                          (declare (not safe))
                          (hash-remove! __tmp34508 _%n1275%_))))
                     (__tmp34506
                      (##structure-ref
                       _%n1275%_
                       '4
                       gerbil-ascent/table/trrel-uf#uf-node::t
                       '#f)))
                 (declare (not safe))
                 (hash-for-each __tmp34507 __tmp34506)))
           (let ((__tmp34509
                  (##structure-ref
                   _%winner1272%_
                   '5
                   gerbil-ascent/table/trrel-uf#uf-node::t
                   '#f)))
             (declare (not safe))
             (hash-remove! __tmp34509 _%n1275%_)))
         _%cycle1273%_)))
    (define gerbil-ascent/table/trrel-uf#merge-cycle!
      (lambda (_%group1241%_ _%roots1242%_ _%cycle1243%_)
        (let* ((_%winner1248%_
                (let ((__tmp34512
                       (lambda (_%n1245%_ _%best1246%_)
                         (if (> (##structure-ref
                                 _%n1245%_
                                 '3
                                 gerbil-ascent/table/trrel-uf#uf-node::t
                                 '#f)
                                (##structure-ref
                                 _%best1246%_
                                 '3
                                 gerbil-ascent/table/trrel-uf#uf-node::t
                                 '#f))
                             _%n1245%_
                             _%best1246%_)))
                      (__tmp34511 (car _%cycle1243%_))
                      (__tmp34510 (cdr _%cycle1243%_)))
                  (declare (not safe))
                  (foldl__0 __tmp34512 __tmp34511 __tmp34510)))
               (_%merged1250%_
                (##structure-ref
                 _%winner1248%_
                 '2
                 gerbil-ascent/table/trrel-uf#uf-node::t
                 '#f))
               (_%size1252%_
                (##structure-ref
                 _%winner1248%_
                 '3
                 gerbil-ascent/table/trrel-uf#uf-node::t
                 '#f)))
          (if (##structure-ref
               _%group1241%_
               '4
               gerbil-ascent/table/trrel-uf#uf-group::t
               '#f)
              (gerbil-ascent/table/trrel-uf#retire-cycle-predecessors!
               _%winner1248%_
               _%cycle1243%_)
              '#!void)
          (for-each
           (lambda (_%n1255%_)
             (if (eq? _%n1255%_ _%winner1248%_)
                 '#!void
                 (begin
                   (set! _%merged1250%_
                         (append (##structure-ref
                                  _%n1255%_
                                  '2
                                  gerbil-ascent/table/trrel-uf#uf-node::t
                                  '#f)
                                 _%merged1250%_))
                   (set! _%size1252%_
                         (+ _%size1252%_
                            (##structure-ref
                             _%n1255%_
                             '3
                             gerbil-ascent/table/trrel-uf#uf-node::t
                             '#f)))
                   (##structure-set!
                    _%n1255%_
                    _%winner1248%_
                    '1
                    gerbil-ascent/table/trrel-uf#uf-node::t
                    '#f)
                   (##structure-set!
                    _%n1255%_
                    '()
                    '2
                    gerbil-ascent/table/trrel-uf#uf-node::t
                    '#f)
                   (##structure-set!
                    _%n1255%_
                    '0
                    '3
                    gerbil-ascent/table/trrel-uf#uf-node::t
                    '#f)
                   (##structure-set!
                    _%n1255%_
                    (let () (declare (not safe)) (make-hash-table-eq))
                    '4
                    gerbil-ascent/table/trrel-uf#uf-node::t
                    '#f)
                   (##structure-set!
                    _%n1255%_
                    '#f
                    '5
                    gerbil-ascent/table/trrel-uf#uf-node::t
                    '#f))))
           _%cycle1243%_)
          (##structure-set!
           _%winner1248%_
           _%merged1250%_
           '2
           gerbil-ascent/table/trrel-uf#uf-node::t
           '#f)
          (##structure-set!
           _%winner1248%_
           _%size1252%_
           '3
           gerbil-ascent/table/trrel-uf#uf-node::t
           '#f)
          (set! _%roots1242%_
                (filter (lambda (_%n1257%_)
                          (not (##structure-ref
                                _%n1257%_
                                '1
                                gerbil-ascent/table/trrel-uf#uf-node::t
                                '#f)))
                        _%roots1242%_))
          (##structure-set!
           _%group1241%_
           _%roots1242%_
           '2
           gerbil-ascent/table/trrel-uf#uf-group::t
           '#f)
          (for-each
           (lambda (_%n1259%_)
             (if (and (eq? _%n1259%_ _%winner1248%_)
                      (or (null? (cdr _%roots1242%_))
                          (= (let ((__tmp34513
                                    (##structure-ref
                                     _%n1259%_
                                     '4
                                     gerbil-ascent/table/trrel-uf#uf-node::t
                                     '#f)))
                               (declare (not safe))
                               (hash-length __tmp34513))
                             (- (length _%cycle1243%_) '1))))
                 (##structure-set!
                  _%n1259%_
                  (let () (declare (not safe)) (make-hash-table-eq))
                  '4
                  gerbil-ascent/table/trrel-uf#uf-node::t
                  '#f)
                 (if (or (eq? _%n1259%_ _%winner1248%_)
                         (let ((__tmp34514
                                (##structure-ref
                                 _%n1259%_
                                 '4
                                 gerbil-ascent/table/trrel-uf#uf-node::t
                                 '#f)))
                           (declare (not safe))
                           (hash-get __tmp34514 _%winner1248%_)))
                     (for-each
                      (lambda (_%target1267%_)
                        (if (or (not (eq? _%target1267%_ _%winner1248%_))
                                (eq? _%n1259%_ _%winner1248%_))
                            (let ((__tmp34515
                                   (##structure-ref
                                    _%n1259%_
                                    '4
                                    gerbil-ascent/table/trrel-uf#uf-node::t
                                    '#f)))
                              (declare (not safe))
                              (hash-remove! __tmp34515 _%target1267%_))
                            '#!void))
                      _%cycle1243%_)
                     '#!void)))
           _%roots1242%_))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-insert!
      (lambda (_%groups1205%_ _%row1206%_ _%budget1207%_)
        (let* ((_%width1209%_ (length _%row1206%_))
               (_%_1211%_
                (if (let () (declare (not safe)) (##memq _%width1209%_ '(2 3)))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"ASCENT trrel requires two or three columns"
                             _%row1206%_))))
               (_%group-key1213%_
                (list _%width1209%_
                      (if (= _%width1209%_ '3) (car _%row1206%_) '#f)))
               (_%pair1215%_
                (if (= _%width1209%_ '3) (cdr _%row1206%_) _%row1206%_))
               (_%left1217%_ (car _%pair1215%_))
               (_%right1219%_ (cadr _%pair1215%_))
               (_%stored1221%_
                (let ()
                  (declare (not safe))
                  (hash-get _%groups1205%_ _%group-key1213%_)))
               (_%group1226%_
                (let ((_%$e1223%_ _%stored1221%_))
                  (if _%$e1223%_
                      _%$e1223%_
                      (let ((__tmp34516
                             (let ()
                               (declare (not safe))
                               (make-hash-table__%
                                '#f
                                absent-value
                                absent-value
                                absent-value
                                absent-value
                                absent-value
                                absent-value
                                absent-value
                                absent-value))))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/table/trrel-uf#uf-group::t
                         __tmp34516
                         '()
                         '0
                         '#f)))))
               (_%nodes1228%_
                (##structure-ref
                 _%group1226%_
                 '1
                 gerbil-ascent/table/trrel-uf#uf-group::t
                 '#f))
               (_%left-node1230%_
                (let ()
                  (declare (not safe))
                  (hash-get _%nodes1228%_ _%left1217%_)))
               (_%right-node1232%_
                (let ()
                  (declare (not safe))
                  (hash-get _%nodes1228%_ _%right1219%_)))
               (_%a1234%_
                (if _%left-node1230%_
                    (gerbil-ascent/table/trrel-uf#root _%left-node1230%_)
                    (gerbil-ascent/table/trrel-uf#fresh
                     _%left1217%_
                     (+ '2
                        (##structure-ref
                         _%group1226%_
                         '3
                         gerbil-ascent/table/trrel-uf#uf-group::t
                         '#f))
                     (##structure-ref
                      _%group1226%_
                      '4
                      gerbil-ascent/table/trrel-uf#uf-group::t
                      '#f))))
               (_%b1236%_
                (if (equal? _%left1217%_ _%right1219%_)
                    _%a1234%_
                    (if _%right-node1232%_
                        (gerbil-ascent/table/trrel-uf#root _%right-node1232%_)
                        (gerbil-ascent/table/trrel-uf#fresh
                         _%right1219%_
                         (+ '1
                            (##structure-ref
                             _%group1226%_
                             '3
                             gerbil-ascent/table/trrel-uf#uf-group::t
                             '#f))
                         (##structure-ref
                          _%group1226%_
                          '4
                          gerbil-ascent/table/trrel-uf#uf-group::t
                          '#f)))))
               (_%admitted?1238%_
                (if _%left-node1230%_
                    (if _%right-node1232%_
                        (gerbil-ascent/table/trrel-uf#reachable?
                         _%a1234%_
                         _%b1236%_)
                        '#f)
                    '#f)))
          (if _%admitted?1238%_
              (begin
                (if (< _%budget1207%_ '0)
                    (let ()
                      (declare (not safe))
                      (error '"ASCENT trrel output fact budget exceeded"))
                    '#!void)
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__0
                   '()
                   '0
                   '0)))
              (gerbil-ascent/table/trrel-uf#insert-components!
               _%groups1205%_
               (let ()
                 (declare (not safe))
                 (##structure
                  gerbil-ascent/table/trrel-uf#uf-insertion::t
                  _%group-key1213%_
                  _%group1226%_
                  _%row1206%_
                  _%left-node1230%_
                  _%right-node1232%_
                  _%a1234%_
                  _%b1236%_))
               _%budget1207%_)))))
    (define gerbil-ascent/table/trrel-uf#insert-components!
      (lambda (_%groups1088%_ _%admission1089%_ _%budget1090%_)
        (let* ((_%$%admission10911103%_ _%admission1089%_)
               (_%$%E10931106%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%admission10911103%_
                           '((uf-insertion
                              group-key
                              group
                              row
                              left-node
                              right-node
                              a
                              b))))
                  '#!void))
               (_%$%K10941167%_
                (lambda (_%b1109%_
                         _%a1110%_
                         _%right-node1111%_
                         _%left-node1112%_
                         _%row1113%_
                         _%group1114%_
                         _%group-key1115%_)
                  (let* ((_%width1117%_ (car _%group-key1115%_))
                         (_%nodes1119%_
                          (##structure-ref
                           _%group1114%_
                           '1
                           gerbil-ascent/table/trrel-uf#uf-group::t
                           '#f))
                         (_%pair1121%_
                          (if (= _%width1117%_ '3)
                              (cdr _%row1113%_)
                              _%row1113%_))
                         (_%left1123%_ (car _%pair1121%_))
                         (_%right1125%_ (cadr _%pair1121%_))
                         (_%new1130%_
                          (let ((__tmp34518
                                 (if _%left-node1112%_ '() (list _%a1110%_)))
                                (__tmp34517
                                 (if (or _%right-node1111%_
                                         (eq? _%a1110%_ _%b1109%_))
                                     '()
                                     (list _%b1109%_))))
                            (declare (not safe))
                            (##append __tmp34518 __tmp34517)))
                         (_%roots1132%_
                          (append _%new1130%_
                                  (##structure-ref
                                   _%group1114%_
                                   '2
                                   gerbil-ascent/table/trrel-uf#uf-group::t
                                   '#f)))
                         (_%preds1136%_
                          (if (##structure-ref
                               _%group1114%_
                               '4
                               gerbil-ascent/table/trrel-uf#uf-group::t
                               '#f)
                              (gerbil-ascent/table/trrel-uf#ordered-neighbors
                               _%a1110%_
                               (##structure-ref
                                _%a1110%_
                                '5
                                gerbil-ascent/table/trrel-uf#uf-node::t
                                '#f))
                              (let ((__tmp34519
                                     (lambda (_%p1134%_)
                                       (gerbil-ascent/table/trrel-uf#reachable?
                                        _%p1134%_
                                        _%a1110%_))))
                                (declare (not safe))
                                (##filter __tmp34519 _%roots1132%_))))
                         (_%succs1140%_
                          (if (##structure-ref
                               _%group1114%_
                               '4
                               gerbil-ascent/table/trrel-uf#uf-group::t
                               '#f)
                              (gerbil-ascent/table/trrel-uf#ordered-neighbors
                               _%b1109%_
                               (##structure-ref
                                _%b1109%_
                                '4
                                gerbil-ascent/table/trrel-uf#uf-node::t
                                '#f))
                              (let ((__tmp34520
                                     (lambda (_%s1138%_)
                                       (gerbil-ascent/table/trrel-uf#reachable?
                                        _%b1109%_
                                        _%s1138%_))))
                                (declare (not safe))
                                (##filter __tmp34520 _%roots1132%_))))
                         (_%cycle1144%_
                          (if (eq? _%a1110%_ _%b1109%_)
                              '#f
                              (if (gerbil-ascent/table/trrel-uf#reachable?
                                   _%b1109%_
                                   _%a1110%_)
                                  (let ((__tmp34521
                                         (lambda (_%p1142%_)
                                           (gerbil-ascent/table/trrel-uf#reachable?
                                            _%b1109%_
                                            _%p1142%_))))
                                    (declare (not safe))
                                    (##filter __tmp34521 _%preds1136%_))
                                  '#f)))
                         (_%changes1146%_ '())
                         (_%needed1148%_
                          (let () (declare (not safe)) (##length _%new1130%_)))
                         (_%added1150%_ '()))
                    (let ((__tmp34522
                           (lambda (_%p1153%_)
                             (let ((__tmp34523
                                    (lambda (_%s1155%_)
                                      (if (gerbil-ascent/table/trrel-uf#reachable?
                                           _%p1153%_
                                           _%s1155%_)
                                          '#!void
                                          (begin
                                            (set! _%needed1148%_
                                                  (+ _%needed1148%_
                                                     (* (##structure-ref
                                                         _%p1153%_
                                                         '3
                                                         gerbil-ascent/table/trrel-uf#uf-node::t
                                                         '#f)
                                                        (##structure-ref
                                                         _%s1155%_
                                                         '3
                                                         gerbil-ascent/table/trrel-uf#uf-node::t
                                                         '#f))))
                                            (set! _%changes1146%_
                                                  (cons (cons _%p1153%_
                                                              _%s1155%_)
                                                        _%changes1146%_)))))))
                               (declare (not safe))
                               (##for-each __tmp34523 _%succs1140%_)))))
                      (declare (not safe))
                      (##for-each __tmp34522 _%preds1136%_))
                    (if (> _%needed1148%_ _%budget1090%_)
                        (let ()
                          (declare (not safe))
                          (error '"ASCENT trrel output fact budget exceeded"))
                        '#!void)
                    (let ((_%prefix1157%_
                           (if (= _%width1117%_ '3)
                               (list (car _%row1113%_))
                               '())))
                      (let ((__tmp34524
                             (lambda (_%n1159%_)
                               (let ((_%members1161%_
                                      (##structure-ref
                                       _%n1159%_
                                       '2
                                       gerbil-ascent/table/trrel-uf#uf-node::t
                                       '#f)))
                                 (set! _%added1150%_
                                       (cons (let ()
                                               (declare (not safe))
                                               (##structure
                                                gerbil-ascent/core/relation-view#rectangle::t
                                                _%prefix1157%_
                                                _%members1161%_
                                                _%members1161%_))
                                             _%added1150%_))))))
                        (declare (not safe))
                        (##for-each __tmp34524 _%new1130%_))
                      (let ((__tmp34525
                             (lambda (_%change1163%_)
                               (set! _%added1150%_
                                     (cons (let ((__tmp34527
                                                  (##structure-ref
                                                   (car _%change1163%_)
                                                   '2
                                                   gerbil-ascent/table/trrel-uf#uf-node::t
                                                   '#f))
                                                 (__tmp34526
                                                  (##structure-ref
                                                   (cdr _%change1163%_)
                                                   '2
                                                   gerbil-ascent/table/trrel-uf#uf-node::t
                                                   '#f)))
                                             (declare (not safe))
                                             (##structure
                                              gerbil-ascent/core/relation-view#rectangle::t
                                              _%prefix1157%_
                                              __tmp34527
                                              __tmp34526))
                                           _%added1150%_)))))
                        (declare (not safe))
                        (##for-each __tmp34525 _%changes1146%_)))
                    (if (null? _%new1130%_)
                        '#!void
                        (begin
                          (let ()
                            (declare (not safe))
                            (hash-put!
                             _%groups1088%_
                             _%group-key1115%_
                             _%group1114%_))
                          (if _%left-node1112%_
                              '#!void
                              (let ()
                                (declare (not safe))
                                (hash-put!
                                 _%nodes1119%_
                                 _%left1123%_
                                 _%a1110%_)))
                          (if _%right-node1111%_
                              '#!void
                              (let ()
                                (declare (not safe))
                                (hash-put!
                                 _%nodes1119%_
                                 _%right1125%_
                                 _%b1109%_)))
                          (##structure-set!
                           _%group1114%_
                           _%roots1132%_
                           '2
                           gerbil-ascent/table/trrel-uf#uf-group::t
                           '#f)
                          (##structure-set!
                           _%group1114%_
                           (+ '2
                              (##structure-ref
                               _%group1114%_
                               '3
                               gerbil-ascent/table/trrel-uf#uf-group::t
                               '#f))
                           '3
                           gerbil-ascent/table/trrel-uf#uf-group::t
                           '#f)))
                    (if (##structure-ref
                         _%group1114%_
                         '4
                         gerbil-ascent/table/trrel-uf#uf-group::t
                         '#f)
                        '#!void
                        (if (> (let ()
                                 (declare (not safe))
                                 (##length _%roots1132%_))
                               '64)
                            (begin
                              (##structure-set!
                               _%group1114%_
                               '#t
                               '4
                               gerbil-ascent/table/trrel-uf#uf-group::t
                               '#f)
                              (gerbil-ascent/table/trrel-uf#rebuild-predecessors!
                               _%roots1132%_))
                            '#!void))
                    (if (and _%cycle1144%_
                             (= (let ()
                                  (declare (not safe))
                                  (##length _%cycle1144%_))
                                (let ()
                                  (declare (not safe))
                                  (##length _%roots1132%_))))
                        '#!void
                        (let ((__tmp34528
                               (lambda (_%change1165%_)
                                 (let ((__tmp34530
                                        (##structure-ref
                                         (car _%change1165%_)
                                         '4
                                         gerbil-ascent/table/trrel-uf#uf-node::t
                                         '#f))
                                       (__tmp34529 (cdr _%change1165%_)))
                                   (declare (not safe))
                                   (hash-put! __tmp34530 __tmp34529 '#t))
                                 (if (##structure-ref
                                      _%group1114%_
                                      '4
                                      gerbil-ascent/table/trrel-uf#uf-group::t
                                      '#f)
                                     (let ((__tmp34532
                                            (##structure-ref
                                             (cdr _%change1165%_)
                                             '5
                                             gerbil-ascent/table/trrel-uf#uf-node::t
                                             '#f))
                                           (__tmp34531 (car _%change1165%_)))
                                       (declare (not safe))
                                       (hash-put! __tmp34532 __tmp34531 '#t))
                                     '#!void))))
                          (declare (not safe))
                          (##for-each __tmp34528 _%changes1146%_)))
                    (if _%cycle1144%_
                        (gerbil-ascent/table/trrel-uf#merge-cycle!
                         _%group1114%_
                         _%roots1132%_
                         _%cycle1144%_)
                        '#!void)
                    (let ((__tmp34534
                           (let ()
                             (declare (not safe))
                             (##reverse _%added1150%_)))
                          (__tmp34533
                           (let ()
                             (declare (not safe))
                             (##length _%added1150%_))))
                      (declare (not safe))
                      (gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__0
                       __tmp34534
                       _%needed1148%_
                       __tmp34533))))))
          (if (let ()
                (declare (not safe))
                (##structure-direct-instance-of?
                 _%$%admission10911103%_
                 'gerbil-ascent/table/trrel-uf#uf-insertion::t))
              (let* ((_%$%e10951170%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission10911103%_
                         '1
                         '#f
                         '#f)))
                     (_%group-key1173%_ _%$%e10951170%_)
                     (_%$%e10961175%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission10911103%_
                         '2
                         '#f
                         '#f)))
                     (_%group1178%_ _%$%e10961175%_)
                     (_%$%e10971180%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission10911103%_
                         '3
                         '#f
                         '#f)))
                     (_%row1183%_ _%$%e10971180%_)
                     (_%$%e10981185%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission10911103%_
                         '4
                         '#f
                         '#f)))
                     (_%left-node1188%_ _%$%e10981185%_)
                     (_%$%e10991190%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission10911103%_
                         '5
                         '#f
                         '#f)))
                     (_%right-node1193%_ _%$%e10991190%_)
                     (_%$%e11001195%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission10911103%_
                         '6
                         '#f
                         '#f)))
                     (_%a1198%_ _%$%e11001195%_)
                     (_%$%e11011200%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%admission10911103%_
                         '7
                         '#f
                         '#f)))
                     (_%b1203%_ _%$%e11011200%_))
                (_%$%K10941167%_
                 _%b1203%_
                 _%a1198%_
                 _%right-node1193%_
                 _%left-node1188%_
                 _%row1183%_
                 _%group1178%_
                 _%group-key1173%_))
              (_%$%E10931106%_)))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-observation
      (lambda (_%groups1077%_)
        (let ((_%nodes1079%_ '0) (_%components1080%_ '0) (_%arcs1081%_ '0))
          (let ((__tmp34535
                 (lambda (_%_1083%_ _%g1084%_)
                   (set! _%nodes1079%_
                         (+ _%nodes1079%_
                            (let ((__tmp34536
                                   (##structure-ref
                                    _%g1084%_
                                    '1
                                    gerbil-ascent/table/trrel-uf#uf-group::t
                                    '#f)))
                              (declare (not safe))
                              (hash-length __tmp34536))))
                   (set! _%components1080%_
                         (+ _%components1080%_
                            (length (##structure-ref
                                     _%g1084%_
                                     '2
                                     gerbil-ascent/table/trrel-uf#uf-group::t
                                     '#f))))
                   (for-each
                    (lambda (_%n1086%_)
                      (set! _%arcs1081%_
                            (+ _%arcs1081%_
                               (let ((__tmp34537
                                      (##structure-ref
                                       _%n1086%_
                                       '4
                                       gerbil-ascent/table/trrel-uf#uf-node::t
                                       '#f)))
                                 (declare (not safe))
                                 (hash-length __tmp34537)))))
                    (##structure-ref
                     _%g1084%_
                     '2
                     gerbil-ascent/table/trrel-uf#uf-group::t
                     '#f)))))
            (declare (not safe))
            (hash-for-each __tmp34535 _%groups1077%_))
          (vector _%nodes1079%_ _%components1080%_ _%arcs1081%_))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-validate
      (lambda (_%groups1014%_)
        (letrec ((_%require!1016%_
                  (lambda (_%ok1074%_ _%message1075%_)
                    (if _%ok1074%_
                        '#!void
                        (let ()
                          (declare (not safe))
                          (error _%message1075%_)))))
                 (_%unique?1017%_
                  (lambda (_%values1062%_ _%same?1063%_)
                    (let _%loop1065%_ ((_%rest1067%_ _%values1062%_))
                      (let ((_%$e1069%_ (null? _%rest1067%_)))
                        (if _%$e1069%_
                            _%$e1069%_
                            (if (let ((__tmp34539
                                       (lambda (_%v1072%_)
                                         (_%same?1063%_
                                          (car _%rest1067%_)
                                          _%v1072%_)))
                                      (__tmp34538 (cdr _%rest1067%_)))
                                  (declare (not safe))
                                  (ormap__0 __tmp34539 __tmp34538))
                                '#f
                                (_%loop1065%_ (cdr _%rest1067%_))))))))
                 (_%checked-root1018%_
                  (lambda (_%node1055%_)
                    (let _%loop1057%_ ((_%n1059%_ _%node1055%_)
                                       (_%seen1060%_ '()))
                      (_%require!1016%_
                       (not (memq _%n1059%_ _%seen1060%_))
                       '"ASCENT UF parent cycle")
                      (if (##structure-ref
                           _%n1059%_
                           '1
                           gerbil-ascent/table/trrel-uf#uf-node::t
                           '#f)
                          (_%loop1057%_
                           (##structure-ref
                            _%n1059%_
                            '1
                            gerbil-ascent/table/trrel-uf#uf-node::t
                            '#f)
                           (cons _%n1059%_ _%seen1060%_))
                          _%n1059%_)))))
          (let ((__tmp34540
                 (lambda (_%_1020%_ _%group1021%_)
                   (let ((_%nodes1023%_
                          (##structure-ref
                           _%group1021%_
                           '1
                           gerbil-ascent/table/trrel-uf#uf-group::t
                           '#f))
                         (_%roots1024%_
                          (##structure-ref
                           _%group1021%_
                           '2
                           gerbil-ascent/table/trrel-uf#uf-group::t
                           '#f)))
                     (_%require!1016%_
                      (_%unique?1017%_ _%roots1024%_ eq?)
                      '"ASCENT UF duplicate root")
                     (let _%loop1026%_ ((_%remaining1028%_ _%roots1024%_)
                                        (_%ceiling1029%_
                                         (+ '1
                                            (##structure-ref
                                             _%group1021%_
                                             '3
                                             gerbil-ascent/table/trrel-uf#uf-group::t
                                             '#f))))
                       (if (null? _%remaining1028%_)
                           '#!void
                           (let ((_%order1031%_
                                  (##structure-ref
                                   (car _%remaining1028%_)
                                   '6
                                   gerbil-ascent/table/trrel-uf#uf-node::t
                                   '#f)))
                             (_%require!1016%_
                              (if (exact-integer? _%order1031%_)
                                  (if (> _%order1031%_ '0)
                                      (< _%order1031%_ _%ceiling1029%_)
                                      '#f)
                                  '#f)
                              '"ASCENT UF root scan order mismatch")
                             (_%loop1026%_
                              (cdr _%remaining1028%_)
                              _%order1031%_))))
                     (let ((__tmp34541
                            (lambda (_%value1033%_ _%node1034%_)
                              (let ((_%owner1036%_
                                     (_%checked-root1018%_ _%node1034%_)))
                                (_%require!1016%_
                                 (memq _%owner1036%_ _%roots1024%_)
                                 '"ASCENT UF missing root")
                                (_%require!1016%_
                                 (member _%value1033%_
                                         (##structure-ref
                                          _%owner1036%_
                                          '2
                                          gerbil-ascent/table/trrel-uf#uf-node::t
                                          '#f))
                                 '"ASCENT UF missing member")
                                (if (##structure-ref
                                     _%node1034%_
                                     '1
                                     gerbil-ascent/table/trrel-uf#uf-node::t
                                     '#f)
                                    (_%require!1016%_
                                     (if (null? (##structure-ref
                                                 _%node1034%_
                                                 '2
                                                 gerbil-ascent/table/trrel-uf#uf-node::t
                                                 '#f))
                                         (if (= (##structure-ref
                                                 _%node1034%_
                                                 '3
                                                 gerbil-ascent/table/trrel-uf#uf-node::t
                                                 '#f)
                                                '0)
                                             (if (= (let ((__tmp34542
                                                           (##structure-ref
                                                            _%node1034%_
                                                            '4
                                                            gerbil-ascent/table/trrel-uf#uf-node::t
                                                            '#f)))
                                                      (declare (not safe))
                                                      (hash-length __tmp34542))
                                                    '0)
                                                 (not (##structure-ref
                                                       _%node1034%_
                                                       '5
                                                       gerbil-ascent/table/trrel-uf#uf-node::t
                                                       '#f))
                                                 '#f)
                                             '#f)
                                         '#f)
                                     '"ASCENT UF absorbed storage retained")
                                    '#!void)))))
                       (declare (not safe))
                       (hash-for-each __tmp34541 _%nodes1023%_))
                     (for-each
                      (lambda (_%n1038%_)
                        (let ((_%members1040%_
                               (##structure-ref
                                _%n1038%_
                                '2
                                gerbil-ascent/table/trrel-uf#uf-node::t
                                '#f)))
                          (_%require!1016%_
                           (not (##structure-ref
                                 _%n1038%_
                                 '1
                                 gerbil-ascent/table/trrel-uf#uf-node::t
                                 '#f))
                           '"ASCENT UF non-root owner")
                          (_%require!1016%_
                           (if (> (##structure-ref
                                   _%n1038%_
                                   '3
                                   gerbil-ascent/table/trrel-uf#uf-node::t
                                   '#f)
                                  '0)
                               (if (= (##structure-ref
                                       _%n1038%_
                                       '3
                                       gerbil-ascent/table/trrel-uf#uf-node::t
                                       '#f)
                                      (length _%members1040%_))
                                   (_%unique?1017%_ _%members1040%_ equal?)
                                   '#f)
                               '#f)
                           '"ASCENT UF member size mismatch")
                          (for-each
                           (lambda (_%value1042%_)
                             (let ((_%node1044%_
                                    (let ()
                                      (declare (not safe))
                                      (hash-get _%nodes1023%_ _%value1042%_))))
                               (_%require!1016%_
                                (if _%node1044%_
                                    (eq? (_%checked-root1018%_ _%node1044%_)
                                         _%n1038%_)
                                    '#f)
                                '"ASCENT UF wrong member owner")))
                           _%members1040%_))
                        (if (##structure-ref
                             _%group1021%_
                             '4
                             gerbil-ascent/table/trrel-uf#uf-group::t
                             '#f)
                            (begin
                              (_%require!1016%_
                               (let ((__tmp34543
                                      (##structure-ref
                                       _%n1038%_
                                       '5
                                       gerbil-ascent/table/trrel-uf#uf-node::t
                                       '#f)))
                                 (declare (not safe))
                                 (##structure-direct-instance-of?
                                  __tmp34543
                                  'HashTable::t))
                               '"ASCENT UF missing predecessor map")
                              (let ((__tmp34545
                                     (lambda (_%predecessor1046%_ _%_1047%_)
                                       (_%require!1016%_
                                        (if (eq? _%n1038%_ _%predecessor1046%_)
                                            '#f
                                            (if (memq _%predecessor1046%_
                                                      _%roots1024%_)
                                                (let ((__tmp34546
                                                       (##structure-ref
                                                        _%predecessor1046%_
                                                        '4
                                                        gerbil-ascent/table/trrel-uf#uf-node::t
                                                        '#f)))
                                                  (declare (not safe))
                                                  (hash-get
                                                   __tmp34546
                                                   _%n1038%_))
                                                '#f))
                                        '"ASCENT UF stale predecessor key")))
                                    (__tmp34544
                                     (##structure-ref
                                      _%n1038%_
                                      '5
                                      gerbil-ascent/table/trrel-uf#uf-node::t
                                      '#f)))
                                (declare (not safe))
                                (hash-for-each __tmp34545 __tmp34544)))
                            (_%require!1016%_
                             (not (##structure-ref
                                   _%n1038%_
                                   '5
                                   gerbil-ascent/table/trrel-uf#uf-node::t
                                   '#f))
                             '"ASCENT UF premature predecessor map"))
                        (let ((__tmp34548
                               (lambda (_%target1049%_ _%_1050%_)
                                 (if (##structure-ref
                                      _%group1021%_
                                      '4
                                      gerbil-ascent/table/trrel-uf#uf-group::t
                                      '#f)
                                     (_%require!1016%_
                                      (let ((__tmp34549
                                             (##structure-ref
                                              _%target1049%_
                                              '5
                                              gerbil-ascent/table/trrel-uf#uf-node::t
                                              '#f)))
                                        (declare (not safe))
                                        (hash-get __tmp34549 _%n1038%_))
                                      '"ASCENT UF missing predecessor key")
                                     '#!void)
                                 (_%require!1016%_
                                  (if (eq? _%n1038%_ _%target1049%_)
                                      '#f
                                      (memq _%target1049%_ _%roots1024%_))
                                  '"ASCENT UF stale reach key")
                                 (let ((__tmp34551
                                        (lambda (_%successor1052%_ _%_1053%_)
                                          (_%require!1016%_
                                           (gerbil-ascent/table/trrel-uf#reachable?
                                            _%n1038%_
                                            _%successor1052%_)
                                           '"ASCENT UF incomplete root closure")))
                                       (__tmp34550
                                        (##structure-ref
                                         _%target1049%_
                                         '4
                                         gerbil-ascent/table/trrel-uf#uf-node::t
                                         '#f)))
                                   (declare (not safe))
                                   (hash-for-each __tmp34551 __tmp34550))))
                              (__tmp34547
                               (##structure-ref
                                _%n1038%_
                                '4
                                gerbil-ascent/table/trrel-uf#uf-node::t
                                '#f)))
                          (declare (not safe))
                          (hash-for-each __tmp34548 __tmp34547)))
                      _%roots1024%_)))))
            (declare (not safe))
            (hash-for-each __tmp34540 _%groups1014%_))
          '#t)))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-extension
      (lambda (_%groups1008%_
               _%_all1009%_
               _%_pending1010%_
               _%row1011%_
               _%budget1012%_)
        (let ((__tmp34552
               (gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-insert!
                _%groups1008%_
                _%row1011%_
                _%budget1012%_)))
          (declare (not safe))
          (gerbil-ascent/core/relation-view#gerbil-ascent-view-rows
           __tmp34552))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__%
      (lambda (_%groups945%_ _%indexed?946%_)
        (let ((_%blocks948%_ '()) (_%count949%_ '0) (_%units950%_ '0))
          (let ((__tmp34553
                 (lambda (_%key952%_ _%group953%_)
                   (let ((_%members955%_
                          (let () (declare (not safe)) (make-hash-table-eq)))
                         (_%prefix956%_
                          (if (= (car _%key952%_) '3)
                              (list (cadr _%key952%_))
                              '())))
                     (for-each
                      (lambda (_%node958%_)
                        (let ((_%owned960%_
                               (map values
                                    (##structure-ref
                                     _%node958%_
                                     '2
                                     gerbil-ascent/table/trrel-uf#uf-node::t
                                     '#f))))
                          (set! _%units950%_
                                (+ _%units950%_
                                   (##structure-ref
                                    _%node958%_
                                    '3
                                    gerbil-ascent/table/trrel-uf#uf-node::t
                                    '#f)))
                          (let ((__tmp34554
                                 (let ((__tmp34555
                                        (##structure-ref
                                         _%node958%_
                                         '3
                                         gerbil-ascent/table/trrel-uf#uf-node::t
                                         '#f)))
                                   (declare (not safe))
                                   (##structure
                                    gerbil-ascent/table/trrel-uf#frozen-members::t
                                    _%owned960%_
                                    __tmp34555))))
                            (declare (not safe))
                            (__hash-put!
                             _%members955%_
                             _%node958%_
                             __tmp34554))))
                      (##structure-ref
                       _%group953%_
                       '2
                       gerbil-ascent/table/trrel-uf#uf-group::t
                       '#f))
                     (for-each
                      (lambda (_%node962%_)
                        (let* ((_%left964%_
                                (let ()
                                  (declare (not safe))
                                  (__hash-get _%members955%_ _%node962%_)))
                               (_%left966%_ _%left964%_))
                          (letrec ((_%capture978%_
                                    (lambda (_%target983%_)
                                      (let* ((_%right985%_
                                              (let ()
                                                (declare (not safe))
                                                (__hash-get
                                                 _%members955%_
                                                 _%target983%_)))
                                             (_%right987%_ _%right985%_))
                                        (set! _%count949%_
                                              (+ _%count949%_
                                                 (* (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%left966%_
                                                       '2
                                                       '#f
                                                       '#f))
                                                    (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%right987%_
                                                       '2
                                                       '#f
                                                       '#f)))))
                                        (set! _%units950%_ (+ _%units950%_ '1))
                                        (set! _%blocks948%_
                                              (cons (let ((__tmp34557
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##unchecked-structure-ref
                                                              _%left966%_
                                                              '1
                                                              '#f
                                                              '#f)))
                                                          (__tmp34556
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##unchecked-structure-ref
                                                              _%right987%_
                                                              '1
                                                              '#f
                                                              '#f))))
                                                      (declare (not safe))
                                                      (##structure
                                                       gerbil-ascent/core/relation-view#rectangle::t
                                                       _%prefix956%_
                                                       __tmp34557
                                                       __tmp34556))
                                                    _%blocks948%_))))))
                            (_%capture978%_ _%node962%_)
                            (let ((__tmp34559
                                   (lambda (_%target980%_ _%_981%_)
                                     (_%capture978%_ _%target980%_)))
                                  (__tmp34558
                                   (##structure-ref
                                    _%node962%_
                                    '4
                                    gerbil-ascent/table/trrel-uf#uf-node::t
                                    '#f)))
                              (declare (not safe))
                              (hash-for-each __tmp34559 __tmp34558)))))
                      (##structure-ref
                       _%group953%_
                       '2
                       gerbil-ascent/table/trrel-uf#uf-group::t
                       '#f))))))
            (declare (not safe))
            (hash-for-each __tmp34553 _%groups945%_))
          (let ((__tmp34560
                 (let () (declare (not safe)) (##reverse _%blocks948%_))))
            (declare (not safe))
            (gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__%
             __tmp34560
             _%count949%_
             _%units950%_
             _%indexed?946%_)))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__0
      (lambda (_%groups1001%_)
        (let ((_%indexed?1003%_ '#t))
          (gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__%
           _%groups1001%_
           _%indexed?1003%_))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze
      (lambda _g34561_
        (let ((_g34562_ (let () (declare (not safe)) (##length _g34561_))))
          (cond ((let () (declare (not safe)) (##fx= _g34562_ 1))
                 (apply gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__0
                        _g34561_))
                ((let () (declare (not safe)) (##fx= _g34562_ 2))
                 (apply gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze__%
                        _g34561_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze
                  _g34561_))))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-frontier-extension
      gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-insert!)
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-snapshot
      gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-freeze)
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-view-count
      gerbil-ascent/core/relation-view#relation-view-count)
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-view-for-each
      (lambda (_%view941%_ _%consume942%_)
        (let ()
          (declare (not safe))
          (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
           _%consume942%_
           _%view941%_))))
    (define gerbil-ascent/table/trrel-uf#gerbil-ascent-trrel-uf-view-lookup
      (lambda (_%view931%_ _%columns932%_ _%key933%_)
        (if (and (list? _%columns932%_)
                 (list? _%key933%_)
                 (= (let () (declare (not safe)) (##length _%columns932%_))
                    (let () (declare (not safe)) (##length _%key933%_)))
                 (let ((__tmp34563
                        (lambda (_%column935%_)
                          (and (exact-integer? _%column935%_)
                               (>= _%column935%_ '0)))))
                   (declare (not safe))
                   (andmap__0 __tmp34563 _%columns932%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT UF view key")))
        (let ((_%rows937%_ '()))
          (let ((__tmp34565
                 (lambda (_%row939%_)
                   (set! _%rows937%_ (cons _%row939%_ _%rows937%_))))
                (__tmp34564
                 (let ()
                   (declare (not safe))
                   (gerbil-ascent/core/relation-view#gerbil-ascent-view-select
                    _%view931%_
                    _%columns932%_
                    _%key933%_))))
            (declare (not safe))
            (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
             __tmp34565
             __tmp34564))
          (let () (declare (not safe)) (##reverse _%rows937%_)))))))
