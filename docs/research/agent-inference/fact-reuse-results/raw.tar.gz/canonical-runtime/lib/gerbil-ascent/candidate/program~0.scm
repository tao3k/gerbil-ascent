(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/program::timestamp 1791691018)
  (begin
    (define gerbil-ascent/candidate/program#scalar?
      (lambda (_%value27094%_)
        (let ((_%$e27096%_ (exact-integer? _%value27094%_)))
          (if _%$e27096%_
              _%$e27096%_
              (let ((_%$e27099%_ (boolean? _%value27094%_)))
                (if _%$e27099%_
                    _%$e27099%_
                    (let ((_%$e27102%_ (symbol? _%value27094%_)))
                      (if _%$e27102%_
                          _%$e27102%_
                          (char? _%value27094%_)))))))))
    (define gerbil-ascent/candidate/program#reject
      (lambda (_%code27090%_ _%path27091%_ _%detail27092%_)
        (let ((__tmp37010
               (let ((__tmp37011
                      (let ()
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/types#reasoning-diagnostic::t
                         _%code27090%_
                         _%path27091%_
                         _%detail27092%_))))
                 (declare (not safe))
                 (##structure
                  gerbil-ascent/candidate/types#candidate-rejection::t
                  __tmp37011))))
          (declare (not safe))
          (raise __tmp37010))))
    (define gerbil-ascent/candidate/program#candidate-variable?
      (lambda (_%value27086%_)
        (if (symbol? _%value27086%_)
            (let ((_%spelling27088%_
                   (let ()
                     (declare (not safe))
                     (##symbol->string _%value27086%_))))
              (if (> (let ()
                       (declare (not safe))
                       (##string-length _%spelling27088%_))
                     '1)
                  (let ((__tmp37012 (string-ref _%spelling27088%_ '0)))
                    (declare (not safe))
                    (##char=? __tmp37012 '#\?))
                  '#f))
            '#f)))
    (define gerbil-ascent/candidate/program#candidate-term?
      (lambda (_%value27084%_)
        (if (gerbil-ascent/candidate/program#scalar? _%value27084%_)
            (not (eq? _%value27084%_ '?))
            '#f)))
    (define gerbil-ascent/candidate/program#candidate-parse
      (lambda (_%datum27062%_)
        (if (and (let ()
                   (declare (not safe))
                   (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                    _%datum27062%_
                    '16384
                    '128))
                 (list? _%datum27062%_)
                 (pair? _%datum27062%_)
                 (eq? (let () (declare (not safe)) (##car _%datum27062%_))
                      'candidate)
                 (<= (length (let ()
                               (declare (not safe))
                               (##cdr _%datum27062%_)))
                     '256))
            '#!void
            (gerbil-ascent/candidate/program#reject
             'invalid-candidate
             '(candidate)
             'expected-inert-candidate-list))
        (let _%loop27064%_ ((_%clauses27066%_ (cdr _%datum27062%_))
                            (_%index27067%_ '1)
                            (_%relations27068%_ '())
                            (_%facts27069%_ '())
                            (_%rules27070%_ '())
                            (_%query27071%_ '#f)
                            (_%limits27072%_ '#f))
          (if (null? _%clauses27066%_)
              (begin
                (if _%query27071%_
                    '#!void
                    (gerbil-ascent/candidate/program#reject
                     'missing-query
                     '(query)
                     'required))
                (if _%limits27072%_
                    '#!void
                    (gerbil-ascent/candidate/program#reject
                     'missing-limits
                     '(limits)
                     'required))
                (if (> (length _%relations27068%_)
                       gerbil-ascent/candidate/types#+max-relations+)
                    (gerbil-ascent/candidate/program#reject
                     'relation-limit
                     '(relations)
                     gerbil-ascent/candidate/types#+max-relations+)
                    '#!void)
                (if (> (length _%rules27070%_)
                       gerbil-ascent/candidate/types#+max-rules+)
                    (gerbil-ascent/candidate/program#reject
                     'rule-limit
                     '(rules)
                     gerbil-ascent/candidate/types#+max-rules+)
                    '#!void)
                (let ((__tmp37015 (reverse _%relations27068%_))
                      (__tmp37014 (reverse _%facts27069%_))
                      (__tmp37013 (reverse _%rules27070%_)))
                  (declare (not safe))
                  (##structure
                   gerbil-ascent/candidate/types#reasoning-candidate::t
                   __tmp37015
                   __tmp37014
                   __tmp37013
                   _%query27071%_
                   _%limits27072%_)))
              (let ((_%clause27074%_ (car _%clauses27066%_))
                    (_%path27075%_ (list 'clause _%index27067%_)))
                (if (and (list? _%clause27074%_)
                         (pair? _%clause27074%_)
                         (symbol? (let ()
                                    (declare (not safe))
                                    (##car _%clause27074%_))))
                    '#!void
                    (gerbil-ascent/candidate/program#reject
                     'invalid-clause
                     _%path27075%_
                     _%clause27074%_))
                (let ((_%$e27077%_ (car _%clause27074%_)))
                  (if (eq? 'relation _%$e27077%_)
                      (begin
                        (if (and (= (length _%clause27074%_) '3)
                                 (symbol? (cadr _%clause27074%_))
                                 (exact-integer? (caddr _%clause27074%_))
                                 (<= '0 (caddr _%clause27074%_)))
                            '#!void
                            (gerbil-ascent/candidate/program#reject
                             'invalid-relation
                             _%path27075%_
                             _%clause27074%_))
                        (_%loop27064%_
                         (cdr _%clauses27066%_)
                         (+ _%index27067%_ '1)
                         (cons (cons (cadr _%clause27074%_)
                                     (caddr _%clause27074%_))
                               _%relations27068%_)
                         _%facts27069%_
                         _%rules27070%_
                         _%query27071%_
                         _%limits27072%_))
                      (if (eq? 'fact _%$e27077%_)
                          (begin
                            (if (and (>= (length _%clause27074%_) '2)
                                     (symbol? (cadr _%clause27074%_))
                                     (let ((__tmp37017
                                            (lambda (_%value27080%_)
                                              (and (gerbil-ascent/candidate/program#scalar?
                                                    _%value27080%_)
                                                   (if (gerbil-ascent/candidate/program#candidate-variable?
                                                        _%value27080%_)
                                                       '#f
                                                       (not (eq? _%value27080%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '?))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           (__tmp37016 (cddr _%clause27074%_)))
                                       (declare (not safe))
                                       (andmap__0 __tmp37017 __tmp37016)))
                                '#!void
                                (gerbil-ascent/candidate/program#reject
                                 'invalid-fact
                                 _%path27075%_
                                 _%clause27074%_))
                            (_%loop27064%_
                             (cdr _%clauses27066%_)
                             (+ _%index27067%_ '1)
                             _%relations27068%_
                             (cons (vector (cadr _%clause27074%_)
                                           (cddr _%clause27074%_)
                                           _%index27067%_)
                                   _%facts27069%_)
                             _%rules27070%_
                             _%query27071%_
                             _%limits27072%_))
                          (if (eq? 'rule _%$e27077%_)
                              (begin
                                (if (>= (length _%clause27074%_) '3)
                                    '#!void
                                    (gerbil-ascent/candidate/program#reject
                                     'invalid-rule
                                     _%path27075%_
                                     _%clause27074%_))
                                (_%loop27064%_
                                 (cdr _%clauses27066%_)
                                 (+ _%index27067%_ '1)
                                 _%relations27068%_
                                 _%facts27069%_
                                 (cons (vector (cadr _%clause27074%_)
                                               (cddr _%clause27074%_)
                                               _%index27067%_)
                                       _%rules27070%_)
                                 _%query27071%_
                                 _%limits27072%_))
                              (if (eq? 'query _%$e27077%_)
                                  (begin
                                    (if _%query27071%_
                                        (gerbil-ascent/candidate/program#reject
                                         'duplicate-query
                                         _%path27075%_
                                         _%clause27074%_)
                                        '#!void)
                                    (if (>= (length _%clause27074%_) '2)
                                        '#!void
                                        (gerbil-ascent/candidate/program#reject
                                         'invalid-query
                                         _%path27075%_
                                         _%clause27074%_))
                                    (_%loop27064%_
                                     (cdr _%clauses27066%_)
                                     (+ _%index27067%_ '1)
                                     _%relations27068%_
                                     _%facts27069%_
                                     _%rules27070%_
                                     (vector (cdr _%clause27074%_)
                                             _%index27067%_)
                                     _%limits27072%_))
                                  (if (eq? 'limits _%$e27077%_)
                                      (begin
                                        (if _%limits27072%_
                                            (gerbil-ascent/candidate/program#reject
                                             'duplicate-limits
                                             _%path27075%_
                                             _%clause27074%_)
                                            '#!void)
                                        (if (and (= (length _%clause27074%_)
                                                    '4)
                                                 (let ((__tmp37019
                                                        (lambda (_%value27082%_)
                                                          (and (exact-integer?
                                                                _%value27082%_)
                                                               (> _%value27082%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          '0))))
               (__tmp37018 (cdr _%clause27074%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (declare (not safe))
                                                   (andmap__0
                                                    __tmp37019
                                                    __tmp37018))
                                                 (<= (cadr _%clause27074%_)
                                                     gerbil-ascent/candidate/types#+max-input-facts+)
                                                 (<= (caddr _%clause27074%_)
                                                     gerbil-ascent/candidate/types#+max-derived-facts+)
                                                 (<= (cadddr _%clause27074%_)
                                                     gerbil-ascent/candidate/types#+max-output-facts+))
                                            '#!void
                                            (gerbil-ascent/candidate/program#reject
                                             'invalid-limits
                                             _%path27075%_
                                             _%clause27074%_))
                                        (_%loop27064%_
                                         (cdr _%clauses27066%_)
                                         (+ _%index27067%_ '1)
                                         _%relations27068%_
                                         _%facts27069%_
                                         _%rules27070%_
                                         _%query27071%_
                                         (cdr _%clause27074%_)))
                                      (gerbil-ascent/candidate/program#reject
                                       'unsupported-construct
                                       _%path27075%_
                                       (car _%clause27074%_)))))))))))))
    (define gerbil-ascent/candidate/program#candidate-declaration::t
      (let ((__tmp37021 (list)) (__tmp37020 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/program#candidate-declaration::t
         'candidate-declaration
         __tmp37021
         '(arity source?)
         __tmp37020
         '#f)))
    (define gerbil-ascent/candidate/program#candidate-declaration?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/program#candidate-declaration::t)))
    (define gerbil-ascent/candidate/program#make-candidate-declaration
      (lambda _%$args27059%_
        (apply make-instance
               gerbil-ascent/candidate/program#candidate-declaration::t
               _%$args27059%_)))
    (define gerbil-ascent/candidate/program#candidate-declaration-arity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/program#candidate-declaration::t
         'arity)))
    (define gerbil-ascent/candidate/program#candidate-declaration-source?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/program#candidate-declaration::t
         'source?)))
    (define gerbil-ascent/candidate/program#candidate-declaration-arity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/program#candidate-declaration::t
         'arity)))
    (define gerbil-ascent/candidate/program#candidate-declaration-source?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/program#candidate-declaration::t
         'source?)))
    (define gerbil-ascent/candidate/program#&candidate-declaration-arity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/program#candidate-declaration::t
         'arity)))
    (define gerbil-ascent/candidate/program#&candidate-declaration-source?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/program#candidate-declaration::t
         'source?)))
    (define gerbil-ascent/candidate/program#&candidate-declaration-arity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/program#candidate-declaration::t
         'arity)))
    (define gerbil-ascent/candidate/program#&candidate-declaration-source?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/program#candidate-declaration::t
         'source?)))
    (define gerbil-ascent/candidate/program#candidate-schema
      (lambda (_%source27050%_ _%derived27051%_)
        (let ((_%schema27053%_
               (let () (declare (not safe)) (make-hash-table-eq))))
          (for-each
           (lambda (_%entry27055%_)
             (if (let ((__tmp37022 (car _%entry27055%_)))
                   (declare (not safe))
                   (__hash-get _%schema27053%_ __tmp37022))
                 '#!void
                 (let ((__tmp37025 (car _%entry27055%_))
                       (__tmp37023
                        (let ((__tmp37024 (cadr _%entry27055%_)))
                          (declare (not safe))
                          (##structure
                           gerbil-ascent/candidate/program#candidate-declaration::t
                           __tmp37024
                           '#t))))
                   (declare (not safe))
                   (__hash-put! _%schema27053%_ __tmp37025 __tmp37023))))
           _%source27050%_)
          (for-each
           (lambda (_%entry27057%_)
             (if (let ((__tmp37026 (car _%entry27057%_)))
                   (declare (not safe))
                   (__hash-get _%schema27053%_ __tmp37026))
                 (gerbil-ascent/candidate/program#reject
                  'duplicate-relation
                  '(relations)
                  (car _%entry27057%_))
                 '#!void)
             (let ((__tmp37029 (car _%entry27057%_))
                   (__tmp37027
                    (let ((__tmp37028 (cdr _%entry27057%_)))
                      (declare (not safe))
                      (##structure
                       gerbil-ascent/candidate/program#candidate-declaration::t
                       __tmp37028
                       '#f))))
               (declare (not safe))
               (__hash-put! _%schema27053%_ __tmp37029 __tmp37027)))
           _%derived27051%_)
          _%schema27053%_)))
    (define gerbil-ascent/candidate/program#candidate-bind!
      (lambda (_%bound27047%_ _%term27048%_)
        (if (gerbil-ascent/candidate/program#logic-variable? _%term27048%_)
            (let ()
              (declare (not safe))
              (hash-put! _%bound27047%_ _%term27048%_ '#t))
            '#!void)
        _%bound27047%_))
    (define gerbil-ascent/candidate/program#atom-check
      (lambda (_%atom27038%_ _%schema27039%_ _%path27040%_)
        (if (and (list? _%atom27038%_)
                 (pair? _%atom27038%_)
                 (symbol? (let () (declare (not safe)) (##car _%atom27038%_))))
            '#!void
            (gerbil-ascent/candidate/program#reject
             'invalid-atom
             _%path27040%_
             _%atom27038%_))
        (let ((_%declaration27042%_
               (let ((__tmp37030 (car _%atom27038%_)))
                 (declare (not safe))
                 (hash-get _%schema27039%_ __tmp37030))))
          (if _%declaration27042%_
              '#!void
              (gerbil-ascent/candidate/program#reject
               'unknown-relation
               _%path27040%_
               (car _%atom27038%_)))
          (if (= (length (cdr _%atom27038%_))
                 (##structure-ref
                  _%declaration27042%_
                  '1
                  gerbil-ascent/candidate/program#candidate-declaration::t
                  '#f))
              '#!void
              (gerbil-ascent/candidate/program#reject
               'arity-mismatch
               _%path27040%_
               (car _%atom27038%_)))
          (for-each
           (lambda (_%term27044%_ _%position27045%_)
             (if (gerbil-ascent/candidate/program#candidate-term?
                  _%term27044%_)
                 '#!void
                 (gerbil-ascent/candidate/program#reject
                  'invalid-term
                  (let ((__tmp37031 (list 'term _%position27045%_)))
                    (declare (not safe))
                    (##append _%path27040%_ __tmp37031))
                  _%term27044%_)))
           (cdr _%atom27038%_)
           (let ((__tmp37032 (length (cdr _%atom27038%_))))
             (declare (not safe))
             (##iota __tmp37032 '1))))))
    (define gerbil-ascent/candidate/program#logic-variable?
      (lambda (_%value27036%_)
        (if (gerbil-ascent/candidate/program#candidate-variable?
             _%value27036%_)
            (not (eq? _%value27036%_ '?_))
            '#f)))
    (define gerbil-ascent/candidate/program#require-bound-inputs
      (lambda (_%inputs27029%_ _%bound27030%_ _%path27031%_)
        (for-each
         (lambda (_%input27033%_ _%position27034%_)
           (if (and (gerbil-ascent/candidate/program#logic-variable?
                     _%input27033%_)
                    (let ()
                      (declare (not safe))
                      (hash-get _%bound27030%_ _%input27033%_)))
               '#!void
               (gerbil-ascent/candidate/program#reject
                'unbound-operator-input
                (let ((__tmp37033 (list 'input _%position27034%_)))
                  (declare (not safe))
                  (##append _%path27031%_ __tmp37033))
                _%input27033%_)))
         _%inputs27029%_
         (let ((__tmp37034 (length _%inputs27029%_)))
           (declare (not safe))
           (##iota __tmp37034 '1)))))
    (define gerbil-ascent/candidate/program#+candidate-reducer-specs+
      '((count 0) (sum 1) (min 1) (max 1)))
    (define gerbil-ascent/candidate/program#+candidate-operator-specs+
      '((where (even? 1) (< 2)) (compute (identity 1) (+ 2))))
    (define gerbil-ascent/candidate/program#candidate-language-description
      (lambda ()
        (let ((__tmp37035
               (list 'candidate-language
                     'v1
                     '(forms (relation NAME ARITY)
                             (fact SOURCE TERM ...)
                             (rule HEAD BODY ...)
                             (query RELATION TERM ...)
                             (limits INPUT DERIVED OUTPUT))
                     '(body (RELATION TERM ...)
                            (not (RELATION TERM ...))
                            (where (OP INPUT ...))
                            (compute OUTPUT (OP INPUT ...))
                            (reduce OUTPUT
                                    (MODE INPUT ...)
                                    (RELATION TERM ...)))
                     (cons 'operators
                           gerbil-ascent/candidate/program#+candidate-operator-specs+)
                     (cons 'reducers
                           gerbil-ascent/candidate/program#+candidate-reducer-specs+)
                     '(binding positive-atoms-bind
                               negation-and-operators-read-bound
                               compute-and-reduce-bind-fresh)
                     '(operator-inputs bound-variables-only)
                     '(diagnostic-index-base 1)
                     '(scope syntax-description-not-source-authority-or-task-intent))))
          (declare (not safe))
          (gerbil-ascent/candidate/datum#candidate-copy-pairs __tmp37035))))
    (define gerbil-ascent/candidate/program#checked-operation
      (lambda (_%form27015%_ _%mode27016%_ _%bound27017%_ _%path27018%_)
        (if (and (list? _%form27015%_)
                 (pair? _%form27015%_)
                 (symbol? (let () (declare (not safe)) (##car _%form27015%_))))
            '#!void
            (gerbil-ascent/candidate/program#reject
             'invalid-operator
             _%path27018%_
             _%form27015%_))
        (let ((_%operation27020%_ (car _%form27015%_))
              (_%inputs27021%_ (cdr _%form27015%_)))
          (let* ((_%tier27023%_
                  (assq _%mode27016%_
                        gerbil-ascent/candidate/program#+candidate-operator-specs+))
                 (_%spec27025%_
                  (if _%tier27023%_
                      (assq _%operation27020%_ (cdr _%tier27023%_))
                      '#f)))
            (if (and _%spec27025%_
                     (= (length _%inputs27021%_) (cadr _%spec27025%_)))
                '#!void
                (gerbil-ascent/candidate/program#reject
                 'unsupported-operator
                 _%path27018%_
                 _%form27015%_)))
          (gerbil-ascent/candidate/program#require-bound-inputs
           _%inputs27021%_
           _%bound27017%_
           _%path27018%_))))
    (define gerbil-ascent/candidate/program#candidate-check-body-clause
      (lambda (_%clause26987%_ _%schema26988%_ _%bound26989%_ _%path26990%_)
        (if (and (list? _%clause26987%_)
                 (pair? _%clause26987%_)
                 (symbol? (let ()
                            (declare (not safe))
                            (##car _%clause26987%_))))
            '#!void
            (gerbil-ascent/candidate/program#reject
             'invalid-body-clause
             _%path26990%_
             _%clause26987%_))
        (let ((_%$e26992%_ (car _%clause26987%_)))
          (if (eq? 'not _%$e26992%_)
              (begin
                (if (= (length _%clause26987%_) '2)
                    '#!void
                    (gerbil-ascent/candidate/program#reject
                     'invalid-negation
                     _%path26990%_
                     _%clause26987%_))
                (let ((_%atom26995%_ (cadr _%clause26987%_)))
                  (gerbil-ascent/candidate/program#atom-check
                   _%atom26995%_
                   _%schema26988%_
                   _%path26990%_)
                  (for-each
                   (lambda (_%term26997%_ _%position26998%_)
                     (if (and (gerbil-ascent/candidate/program#logic-variable?
                               _%term26997%_)
                              (not (let ()
                                     (declare (not safe))
                                     (hash-get _%bound26989%_ _%term26997%_))))
                         (gerbil-ascent/candidate/program#reject
                          'unsafe-negation
                          (let ((__tmp37036 (list 'term _%position26998%_)))
                            (declare (not safe))
                            (##append _%path26990%_ __tmp37036))
                          _%term26997%_)
                         '#!void))
                   (cdr _%atom26995%_)
                   (let ((__tmp37037 (length (cdr _%atom26995%_))))
                     (declare (not safe))
                     (##iota __tmp37037 '1))))
                _%bound26989%_)
              (if (eq? 'where _%$e26992%_)
                  (begin
                    (if (= (length _%clause26987%_) '2)
                        '#!void
                        (gerbil-ascent/candidate/program#reject
                         'invalid-filter
                         _%path26990%_
                         _%clause26987%_))
                    (gerbil-ascent/candidate/program#checked-operation
                     (cadr _%clause26987%_)
                     'where
                     _%bound26989%_
                     _%path26990%_)
                    _%bound26989%_)
                  (if (eq? 'compute _%$e26992%_)
                      (begin
                        (if (and (= (length _%clause26987%_) '3)
                                 (gerbil-ascent/candidate/program#logic-variable?
                                  (cadr _%clause26987%_)))
                            '#!void
                            (gerbil-ascent/candidate/program#reject
                             'invalid-computation
                             _%path26990%_
                             _%clause26987%_))
                        (if (let ((__tmp37038 (cadr _%clause26987%_)))
                              (declare (not safe))
                              (hash-get _%bound26989%_ __tmp37038))
                            (gerbil-ascent/candidate/program#reject
                             'duplicate-binding
                             _%path26990%_
                             (cadr _%clause26987%_))
                            '#!void)
                        (gerbil-ascent/candidate/program#checked-operation
                         (caddr _%clause26987%_)
                         'compute
                         _%bound26989%_
                         _%path26990%_)
                        (gerbil-ascent/candidate/program#candidate-bind!
                         _%bound26989%_
                         (cadr _%clause26987%_)))
                      (if (eq? 'reduce _%$e26992%_)
                          (begin
                            (if (and (= (length _%clause26987%_) '4)
                                     (gerbil-ascent/candidate/program#logic-variable?
                                      (cadr _%clause26987%_))
                                     (list? (caddr _%clause26987%_))
                                     (pair? (caddr _%clause26987%_)))
                                '#!void
                                (gerbil-ascent/candidate/program#reject
                                 'invalid-reduction
                                 _%path26990%_
                                 _%clause26987%_))
                            (if (let ((__tmp37039 (cadr _%clause26987%_)))
                                  (declare (not safe))
                                  (hash-get _%bound26989%_ __tmp37039))
                                (gerbil-ascent/candidate/program#reject
                                 'duplicate-binding
                                 _%path26990%_
                                 (cadr _%clause26987%_))
                                '#!void)
                            (let* ((_%mode27000%_ (caaddr _%clause26987%_))
                                   (_%inputs27002%_ (cdaddr _%clause26987%_))
                                   (_%atom27004%_ (cadddr _%clause26987%_)))
                              (if (and (symbol? _%mode27000%_)
                                       (let ((_%spec27007%_
                                              (assq _%mode27000%_
                                                    gerbil-ascent/candidate/program#+candidate-reducer-specs+)))
                                         (and _%spec27007%_
                                              (= (length _%inputs27002%_)
                                                 (cadr _%spec27007%_))))
                                       (let ()
                                         (declare (not safe))
                                         (andmap__0
                                          gerbil-ascent/candidate/program#logic-variable?
                                          _%inputs27002%_)))
                                  '#!void
                                  (gerbil-ascent/candidate/program#reject
                                   'unsupported-reduction
                                   _%path26990%_
                                   (caddr _%clause26987%_)))
                              (gerbil-ascent/candidate/program#atom-check
                               _%atom27004%_
                               _%schema26988%_
                               (let ()
                                 (declare (not safe))
                                 (##append _%path26990%_ '(aggregate))))
                              (for-each
                               (lambda (_%input27009%_)
                                 (if (memq _%input27009%_ (cdr _%atom27004%_))
                                     '#!void
                                     (gerbil-ascent/candidate/program#reject
                                      'reduction-input-absent
                                      _%path26990%_
                                      _%input27009%_)))
                               _%inputs27002%_))
                            (gerbil-ascent/candidate/program#candidate-bind!
                             _%bound26989%_
                             (cadr _%clause26987%_)))
                          (begin
                            (gerbil-ascent/candidate/program#atom-check
                             _%clause26987%_
                             _%schema26988%_
                             _%path26990%_)
                            (for-each
                             (lambda (_%$%g2701027012%_)
                               (gerbil-ascent/candidate/program#candidate-bind!
                                _%bound26989%_
                                _%$%g2701027012%_))
                             (cdr _%clause26987%_))
                            _%bound26989%_))))))))
    (define gerbil-ascent/candidate/program#candidate-inspect
      (lambda (_%snapshot26938%_ _%candidate26939%_)
        (let* ((_%spec26941%_
                (gerbil-ascent/candidate/program#candidate-parse
                 _%candidate26939%_))
               (_%source26943%_
                (##structure-ref
                 _%snapshot26938%_
                 '4
                 gerbil-ascent/candidate/types#reasoning-snapshot::t
                 '#f))
               (_%derived26945%_
                (##structure-ref
                 _%spec26941%_
                 '1
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f))
               (_%schema26947%_
                (gerbil-ascent/candidate/program#candidate-schema
                 _%source26943%_
                 _%derived26945%_)))
          (for-each
           (lambda (_%fact26950%_)
             (let ((_%name26952%_ (vector-ref _%fact26950%_ '0))
                   (_%row26953%_ (vector-ref _%fact26950%_ '1))
                   (_%path26954%_
                    (list 'clause (vector-ref _%fact26950%_ '2))))
               (let ((_%declaration26956%_
                      (let ()
                        (declare (not safe))
                        (__hash-get _%schema26947%_ _%name26952%_))))
                 (if (and _%declaration26956%_
                          (##structure-ref
                           _%declaration26956%_
                           '2
                           gerbil-ascent/candidate/program#candidate-declaration::t
                           '#f))
                     '#!void
                     (gerbil-ascent/candidate/program#reject
                      'fact-needs-source
                      _%path26954%_
                      _%name26952%_))
                 (if (= (length _%row26953%_)
                        (##structure-ref
                         _%declaration26956%_
                         '1
                         gerbil-ascent/candidate/program#candidate-declaration::t
                         '#f))
                     '#!void
                     (gerbil-ascent/candidate/program#reject
                      'arity-mismatch
                      _%path26954%_
                      _%name26952%_)))))
           (##structure-ref
            _%spec26941%_
            '2
            gerbil-ascent/candidate/types#reasoning-candidate::t
            '#f))
          (for-each
           (lambda (_%rule26958%_)
             (let* ((_%head26960%_ (vector-ref _%rule26958%_ '0))
                    (_%body26962%_ (vector-ref _%rule26958%_ '1))
                    (_%path26964%_
                     (list 'clause (vector-ref _%rule26958%_ '2)))
                    (_%bound26966%_
                     (let () (declare (not safe)) (make-hash-table-eq))))
               (gerbil-ascent/candidate/program#atom-check
                _%head26960%_
                _%schema26947%_
                (let () (declare (not safe)) (##append _%path26964%_ '(head))))
               (if (##structure-ref
                    (let ((__tmp37040 (car _%head26960%_)))
                      (declare (not safe))
                      (hash-ref__0 _%schema26947%_ __tmp37040))
                    '2
                    gerbil-ascent/candidate/program#candidate-declaration::t
                    '#f)
                   (gerbil-ascent/candidate/program#reject
                    'rule-writes-source
                    (let ()
                      (declare (not safe))
                      (##append _%path26964%_ '(head)))
                    (car _%head26960%_))
                   '#!void)
               (for-each
                (lambda (_%clause26969%_ _%position26970%_)
                  (set! _%bound26966%_
                        (gerbil-ascent/candidate/program#candidate-check-body-clause
                         _%clause26969%_
                         _%schema26947%_
                         _%bound26966%_
                         (let ((__tmp37041 (list 'body _%position26970%_)))
                           (declare (not safe))
                           (##append _%path26964%_ __tmp37041)))))
                _%body26962%_
                (let ((__tmp37042 (length _%body26962%_)))
                  (declare (not safe))
                  (##iota __tmp37042 '1)))
               (for-each
                (lambda (_%term26972%_ _%position26973%_)
                  (if (eq? _%term26972%_ '?_)
                      (gerbil-ascent/candidate/program#reject
                       'wildcard-head
                       (let ((__tmp37043 (list 'head 'term _%position26973%_)))
                         (declare (not safe))
                         (##append _%path26964%_ __tmp37043))
                       _%term26972%_)
                      (if (and (gerbil-ascent/candidate/program#candidate-variable?
                                _%term26972%_)
                               (not (let ()
                                      (declare (not safe))
                                      (hash-get
                                       _%bound26966%_
                                       _%term26972%_))))
                          (gerbil-ascent/candidate/program#reject
                           'unbound-head-variable
                           (let ((__tmp37044
                                  (list 'head 'term _%position26973%_)))
                             (declare (not safe))
                             (##append _%path26964%_ __tmp37044))
                           _%term26972%_)
                          '#!void)))
                (cdr _%head26960%_)
                (let ((__tmp37045 (length (cdr _%head26960%_))))
                  (declare (not safe))
                  (##iota __tmp37045 '1)))))
           (##structure-ref
            _%spec26941%_
            '3
            gerbil-ascent/candidate/types#reasoning-candidate::t
            '#f))
          (let* ((_%query26977%_
                  (vector-ref
                   (##structure-ref
                    _%spec26941%_
                    '4
                    gerbil-ascent/candidate/types#reasoning-candidate::t
                    '#f)
                   '0))
                 (_%path26979%_
                  (list 'clause
                        (vector-ref
                         (##structure-ref
                          _%spec26941%_
                          '4
                          gerbil-ascent/candidate/types#reasoning-candidate::t
                          '#f)
                         '1))))
            (gerbil-ascent/candidate/program#atom-check
             _%query26977%_
             _%schema26947%_
             _%path26979%_))
          (let ((_%source-count26984%_
                 (let ((__tmp37046
                        (map (lambda (_%entry26982%_)
                               (length (caddr _%entry26982%_)))
                             _%source26943%_)))
                   (declare (not safe))
                   (##apply + __tmp37046)))
                (_%candidate-count26985%_
                 (length (##structure-ref
                          _%spec26941%_
                          '2
                          gerbil-ascent/candidate/types#reasoning-candidate::t
                          '#f))))
            (if (> (+ _%source-count26984%_ _%candidate-count26985%_)
                   (car (##structure-ref
                         _%spec26941%_
                         '5
                         gerbil-ascent/candidate/types#reasoning-candidate::t
                         '#f)))
                (gerbil-ascent/candidate/program#reject
                 'input-budget
                 '(limits input)
                 (+ _%source-count26984%_ _%candidate-count26985%_))
                '#!void))
          _%spec26941%_)))
    (define gerbil-ascent/candidate/program#candidate-term->object
      (lambda (_%term26933%_)
        (if (eq? _%term26933%_ '?_)
            (let ()
              (declare (not safe))
              (gerbil-ascent/program/objects#gerbil-ascent-wildcard))
            (if (gerbil-ascent/candidate/program#candidate-variable?
                 _%term26933%_)
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/program/objects#gerbil-ascent-variable
                   _%term26933%_))
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/program/objects#gerbil-ascent-literal
                   _%term26933%_))))))
    (define gerbil-ascent/candidate/program#candidate-atom->object
      (lambda (_%atom26931%_)
        (let ((__tmp37048 (car _%atom26931%_))
              (__tmp37047
               (map gerbil-ascent/candidate/program#candidate-term->object
                    (cdr _%atom26931%_))))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-atom
           __tmp37048
           __tmp37047))))
    (define gerbil-ascent/candidate/program#candidate-body->object
      (lambda (_%clause26921%_)
        (let ((_%$e26923%_ (car _%clause26921%_)))
          (if (eq? 'not _%$e26923%_)
              (let ((_%atom26926%_ (cadr _%clause26921%_)))
                (let ((__tmp37050 (car _%atom26926%_))
                      (__tmp37049
                       (map gerbil-ascent/candidate/program#candidate-term->object
                            (cdr _%atom26926%_))))
                  (declare (not safe))
                  (gerbil-ascent/program/objects#gerbil-ascent-negation
                   __tmp37050
                   __tmp37049)))
              (if (eq? 'where _%$e26923%_)
                  (let ((__tmp37052 (caadr _%clause26921%_))
                        (__tmp37051 (cdadr _%clause26921%_)))
                    (declare (not safe))
                    (gerbil-ascent/program/scheme-checked#relational-where
                     __tmp37052
                     __tmp37051))
                  (if (eq? 'compute _%$e26923%_)
                      (let ((__tmp37055 (cadr _%clause26921%_))
                            (__tmp37054 (caaddr _%clause26921%_))
                            (__tmp37053 (cdaddr _%clause26921%_)))
                        (declare (not safe))
                        (gerbil-ascent/program/scheme-checked#relational-compute
                         __tmp37055
                         __tmp37054
                         __tmp37053))
                      (if (eq? 'reduce _%$e26923%_)
                          (let ((_%operator26928%_ (caddr _%clause26921%_))
                                (_%atom26929%_ (cadddr _%clause26921%_)))
                            (let ((__tmp37060 (cadr _%clause26921%_))
                                  (__tmp37059 (car _%operator26928%_))
                                  (__tmp37058 (cdr _%operator26928%_))
                                  (__tmp37057 (car _%atom26929%_))
                                  (__tmp37056
                                   (map gerbil-ascent/candidate/program#candidate-term->object
                                        (cdr _%atom26929%_))))
                              (declare (not safe))
                              (gerbil-ascent/program/scheme-checked#relational-reducer
                               __tmp37060
                               __tmp37059
                               __tmp37058
                               __tmp37057
                               __tmp37056)))
                          (gerbil-ascent/candidate/program#candidate-atom->object
                           _%clause26921%_))))))))
    (define gerbil-ascent/candidate/program#candidate-fact-partition
      (lambda (_%facts26883%_)
        (if (pair? _%facts26883%_)
            (let ((_%groups26885%_
                   (let () (declare (not safe)) (make-hash-table-eq))))
              (let ((__tmp37061
                     (lambda (_%fact26887%_)
                       (let* ((_%$%fact2688826896%_ _%fact26887%_)
                              (_%$%E2689026899%_
                               (lambda ()
                                 (let ()
                                   (declare (not safe))
                                   (error '"No clause matching"
                                          _%$%fact2688826896%_
                                          '((vector name row _))))
                                 '#!void))
                              (_%$%K2689126905%_
                               (lambda (_%row26902%_ _%name26903%_)
                                 (let ((__tmp37062
                                        (cons _%row26902%_
                                              (let ()
                                                (declare (not safe))
                                                (__hash-ref__%
                                                 _%groups26885%_
                                                 _%name26903%_
                                                 '())))))
                                   (declare (not safe))
                                   (__hash-put!
                                    _%groups26885%_
                                    _%name26903%_
                                    __tmp37062)))))
                         (if (vector? _%$%fact2688826896%_)
                             (if (let ((__tmp37063
                                        (let ()
                                          (declare (not safe))
                                          (##vector-length
                                           _%$%fact2688826896%_))))
                                   (declare (not safe))
                                   (##fx= __tmp37063 '3))
                                 (let* ((_%$%e2689226908%_
                                         (let ()
                                           (declare (not safe))
                                           (##vector-ref
                                            _%$%fact2688826896%_
                                            '0)))
                                        (_%name26911%_ _%$%e2689226908%_)
                                        (_%$%e2689326913%_
                                         (let ()
                                           (declare (not safe))
                                           (##vector-ref
                                            _%$%fact2688826896%_
                                            '1)))
                                        (_%row26916%_ _%$%e2689326913%_)
                                        (_%$%e2689426918%_
                                         (let ()
                                           (declare (not safe))
                                           (##vector-ref
                                            _%$%fact2688826896%_
                                            '2))))
                                   (_%$%K2689126905%_
                                    _%row26916%_
                                    _%name26911%_))
                                 (_%$%E2689026899%_))
                             (_%$%E2689026899%_))))))
                (declare (not safe))
                (##for-each __tmp37061 _%facts26883%_))
              _%groups26885%_)
            '#f)))
    (define gerbil-ascent/candidate/program#candidate-program
      (lambda (_%snapshot26879%_ _%spec26880%_)
        (let ((__tmp37064
               (lambda ()
                 (gerbil-ascent/candidate/program#candidate-lower-program
                  _%snapshot26879%_
                  _%spec26880%_))))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-construct-inert-program
           __tmp37064))))
    (define gerbil-ascent/candidate/program#candidate-lower-program
      (lambda (_%snapshot26851%_ _%spec26852%_)
        (let* ((_%source26854%_
                (##structure-ref
                 _%snapshot26851%_
                 '4
                 gerbil-ascent/candidate/types#reasoning-snapshot::t
                 '#f))
               (_%facts26856%_
                (gerbil-ascent/candidate/program#candidate-fact-partition
                 (##structure-ref
                  _%spec26852%_
                  '2
                  gerbil-ascent/candidate/types#reasoning-candidate::t
                  '#f)))
               (_%derived26858%_
                (##structure-ref
                 _%spec26852%_
                 '1
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f))
               (_%source-relations26864%_
                (map (lambda (_%entry26860%_)
                       (let ((_%name26862%_ (car _%entry26860%_)))
                         (let ((__tmp37068 (cadr _%entry26860%_))
                               (__tmp37065
                                (let ((__tmp37067 (caddr _%entry26860%_))
                                      (__tmp37066
                                       (if _%facts26856%_
                                           (reverse (let ()
                                                      (declare (not safe))
                                                      (__hash-ref__%
                                                       _%facts26856%_
                                                       _%name26862%_
                                                       '())))
                                           '())))
                                  (declare (not safe))
                                  (##append __tmp37067 __tmp37066))))
                           (declare (not safe))
                           (gerbil-ascent/program/objects#gerbil-ascent-relation__0
                            _%name26862%_
                            __tmp37068
                            __tmp37065))))
                     _%source26854%_))
               (_%derived-relations26868%_
                (map (lambda (_%entry26866%_)
                       (let ((__tmp37070 (car _%entry26866%_))
                             (__tmp37069 (cdr _%entry26866%_)))
                         (declare (not safe))
                         (gerbil-ascent/program/objects#gerbil-ascent-relation__0
                          __tmp37070
                          __tmp37069
                          '())))
                     _%derived26858%_))
               (_%relations26870%_
                (let ()
                  (declare (not safe))
                  (##append
                   _%source-relations26864%_
                   _%derived-relations26868%_)))
               (_%rules26874%_
                (map (lambda (_%rule26872%_)
                       (let ((__tmp37072
                              (list (gerbil-ascent/candidate/program#candidate-atom->object
                                     (vector-ref _%rule26872%_ '0))))
                             (__tmp37071
                              (map gerbil-ascent/candidate/program#candidate-body->object
                                   (vector-ref _%rule26872%_ '1))))
                         (declare (not safe))
                         (gerbil-ascent/program/objects#gerbil-ascent-rule
                          __tmp37072
                          __tmp37071)))
                     (##structure-ref
                      _%spec26852%_
                      '3
                      gerbil-ascent/candidate/types#reasoning-candidate::t
                      '#f)))
               (_%limits26876%_
                (##structure-ref
                 _%spec26852%_
                 '5
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f)))
          (let ((__tmp37076 (car _%limits26876%_))
                (__tmp37075 (cadr _%limits26876%_))
                (__tmp37074 (caddr _%limits26876%_))
                (__tmp37073 (map car _%source26854%_)))
            (declare (not safe))
            (gerbil-ascent/program/objects#gerbil-ascent-program__%
             _%relations26870%_
             _%rules26874%_
             __tmp37076
             __tmp37075
             __tmp37074
             __tmp37073)))))
    (define gerbil-ascent/candidate/program#candidate-planner-path
      (lambda (_%spec26848%_ _%path26849%_)
        (if (and (list? _%path26849%_)
                 (= (let () (declare (not safe)) (##length _%path26849%_)) '4)
                 (eq? (car _%path26849%_) 'rule)
                 (exact-integer? (cadr _%path26849%_))
                 (<= '0 (cadr _%path26849%_))
                 (< (cadr _%path26849%_)
                    (length (##structure-ref
                             _%spec26848%_
                             '3
                             gerbil-ascent/candidate/types#reasoning-candidate::t
                             '#f)))
                 (let ((__tmp37077 (caddr _%path26849%_)))
                   (declare (not safe))
                   (##memq __tmp37077 '(body head)))
                 (exact-integer? (cadddr _%path26849%_)))
            (list 'clause
                  (vector-ref
                   (list-ref
                    (##structure-ref
                     _%spec26848%_
                     '3
                     gerbil-ascent/candidate/types#reasoning-candidate::t
                     '#f)
                    (cadr _%path26849%_))
                   '2)
                  (caddr _%path26849%_)
                  (+ '1 (cadddr _%path26849%_)))
            _%path26849%_)))))
