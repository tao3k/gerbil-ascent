(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/table/funs")
    (load-module "gerbil-ascent/table/provider"))
  (load-module "gerbil-ascent/table/access~0"))
