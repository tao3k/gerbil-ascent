# SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
"""Frozen operational repair: bounded extraction, unchanged semantic rubric."""
import argparse,json
from .crosspath_search_v4 import BASE,ROOT,Native,canonical,sha,save,init,verify,provider,provider_key,charge_usage
from .crosspath_annotation_v4 import validate_annotations
PLAN=BASE/'annotation-bounded-plan.json'

def freeze():
    original=json.loads((BASE/'frozen-plan.json').read_text());verify(original)
    if PLAN.exists():raise RuntimeError('bounded measurement already frozen')
    p={'schema':'ascent.annotation.bounded.v2','solverPlanSha256':sha((BASE/'frozen-plan.json').read_bytes()),'rubricSha256':sha(original['annotationRubric'].encode()),'sourceSha256':sha((ROOT/'python/src/ascent_test_support/crosspath_annotation_bounded.py').read_bytes()),'reportSourceSha256':sha((ROOT/'python/src/ascent_test_support/crosspath_report_bounded.py').read_bytes()),'validatorSha256':sha((ROOT/'python/src/ascent_test_support/crosspath_annotation_v4.py').read_bytes()),'callsPerChunk':2,'maxOutputTokens':8192,'coverage':'Every returned solver reasoning segment, in original order, including failed calls; no outcome-based selection. No annotation retry.','crossChunkRule':'Positive native-grounded derive episodes only. Same immutable phase source, exact claimKey including ordered stated edges, earlier non-overlapping derive. Cross-chunk prior link is deterministic key matching; count separately from model-extracted within-chunk links. Alternative stated premises remain distinct.','scope':'Operational repair frozen after solver outcomes/whole-phase output failures, before bounded extraction. Original rubric unchanged and original failed measurement kept. Same-provider labels not exhaustive or independent human truth; no unseen thought inferred.'}
    save(PLAN,p);(BASE/'annotation-bounded-plan.sha256').write_text(sha(PLAN.read_bytes())+'\n');print('BOUNDED-ANNOTATION-FROZEN',flush=True)

def check(p,solver):
    verify(solver)
    if sha(PLAN.read_bytes())!=(BASE/'annotation-bounded-plan.sha256').read_text().strip():raise RuntimeError('measurement plan drift')
    if sha((BASE/'frozen-plan.json').read_bytes())!=p['solverPlanSha256'] or sha(solver['annotationRubric'].encode())!=p['rubricSha256']:raise RuntimeError('solver/rubric drift')
    for field,path in [('sourceSha256','crosspath_annotation_bounded.py'),('reportSourceSha256','crosspath_report_bounded.py'),('validatorSha256','crosspath_annotation_v4.py')]:
        if sha((ROOT/'python/src/ascent_test_support'/path).read_bytes())!=p[field]:raise RuntimeError('measurement producer drift')

def merge_episode(e, prior, offset, index_offset, text_hash):
    e={**e,'index':e['index']+index_offset,'span':[v+offset for v in e['span']],'textSha256':text_hash,'repeatLinkMethod':'within_chunk' if e['prior'] is not None else None}
    if e['prior'] is not None:e['prior']+=index_offset
    positive=e['fragment'] is None or e['ready'] is True
    if e['kind']=='derive' and e['nativeTruthMatches'] and positive and e['prior'] is None:
        earlier=next((x for x in prior if x['kind']=='derive' and x['nativeTruthMatches'] and x['claimKey']==e['claimKey'] and x['span'][0]<offset and x['span'][1]<=e['span'][0]),None)
        if earlier:
            e.update(prior=earlier['index'],definiteRepeatedDerivation=True,repeatLinkMethod='deterministic_cross_chunk_identical_key')
    return e

def run():
    solver=json.loads((BASE/'frozen-plan.json').read_text());p=json.loads(PLAN.read_text());check(p,solver)
    out=BASE/'annotations-bounded';out.mkdir(exist_ok=False);receipts=[]
    ledger=json.loads((BASE/'ledger.json').read_text());key=provider_key()
    for row in ledger['phases']:
        case=next(c for c in solver['cases'] if c['id']==row['case']);folder=BASE/'paid'/f"{row['case']}-{row['arm']}-{row['phase']}"
        pieces=[];segments=[];length=0
        for c in row['calls']:
            text=(folder/f"{c['turn']}.thinking.txt").read_text();piece=f"\n[call {c['turn']}]\n"+text
            segments.append({'turn':c['turn'],'start':length,'end':length+len(piece),'thinkingSha256':c['thinkingSha256']});pieces.append(piece);length+=len(piece)
        text=''.join(pieces);blind=sha(text.encode())[:20];dest=out/blind;dest.mkdir(exist_ok=False);(dest/'thinking.txt').write_text(text)
        measure={'blindedId':blind,'phaseKey':str(folder.relative_to(BASE)),'textSha256':sha(text.encode()),'segments':segments,'failure':None,'accepted':[],'rejected':[],'chunks':[],'measurementGrossTokens':0,'method':'fixed consecutive two-call chunks; unchanged semantic rubric; deterministic matching across chunks'}
        native=Native()
        try:
            init(native,case,'fresh');raw,_=native.call(op='packet');cert=raw['certificate'];paths=next(x[2] for x in cert['finiteClosure'] if x[0]=='path');ready=[x[0] for x in next(x[2] for x in cert['finiteClosure'] if x[0]=='ready')]
        finally:native.close()
        idx=0
        for first in range(0,len(segments),p['callsPerChunk']):
            last=min(first+p['callsPerChunk'],len(segments));start=segments[first]['start'];end=segments[last-1]['end'];chunk=text[start:end]
            sub=dest/f'chunk-{first}';sub.mkdir();(sub/'thinking.txt').write_text(chunk)
            request={'model':solver['model'],'input':[{'role':'user','content':canonical({'edges':case['edges'],'needs':case['needs'],'reasoningText':chunk})}],'instructions':solver['annotationRubric'],'tools':[solver['annotatorTool']],'tool_choice':{'type':'function','name':'annotate'},'reasoning':{'effort':'none'},'max_output_tokens':p['maxOutputTokens'],'stream':True,'store':False}
            save(sub/'request.json',request);_,meta=provider(request,key,sub/'response.json');term=meta.get('terminal') or {}
            receipt={'start':start,'end':end,'thinkingSha256':sha(chunk.encode()),'usage':term.get('usage'),'failure':None,'accepted':[],'rejected':[],'providerSeconds':meta.get('providerSeconds')}
            try:
                receipt['measurementGrossTokens']=charge_usage(receipt['usage']);measure['measurementGrossTokens']+=receipt['measurementGrossTokens']
                if meta.get('error') or term.get('status')!='completed':raise ValueError('annotation_provider_incomplete_or_error')
                results=[x for x in term.get('output',[]) if x.get('type')=='function_call' and x.get('name')=='annotate']
                if len(results)!=1:raise ValueError('expected exactly one annotate call')
                arr=json.loads(results[0]['arguments'])['annotations']
                accepted,rejected=validate_annotations(chunk,arr,case['needs'],case['edges'],paths,ready)
                receipt['accepted']=accepted;receipt['rejected']=rejected
                for e in accepted:measure['accepted'].append(merge_episode(e,measure['accepted'],start,idx,measure['textSha256']))
                measure['rejected'].extend({'chunkFirstCall':first,**r} for r in rejected);idx+=len(arr)
            except (ValueError,KeyError,TypeError) as e:
                receipt['failure']=str(e);measure['failure']='one_or_more_chunk_failures'
            save(sub/'receipt.json',receipt);measure['chunks'].append(receipt);save(dest/'receipt.json',measure)
            print('BOUNDED-LABEL',blind,first,'accepted',len(receipt['accepted']),'rejected',len(receipt['rejected']),'failure',receipt['failure'],flush=True)
        save(dest/'receipt.json',measure);receipts.append(measure);save(BASE/'annotation-bounded-ledger.json',{'measurementPlanSha256':sha(PLAN.read_bytes()),'annotations':receipts})
    check(p,solver);print('BOUNDED-ANNOTATION-OK',len(receipts),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('command',choices=['freeze','run']);args=parser.parse_args();globals()[args.command]()
