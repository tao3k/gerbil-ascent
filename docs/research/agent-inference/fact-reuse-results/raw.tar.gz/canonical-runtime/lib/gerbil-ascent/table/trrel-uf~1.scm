(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/trrel-uf[1]#_g34647_|
    (##structure
     gx#syntax-quote::t
     'uf-node::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34649_|
    (##structure
     gx#syntax-quote::t
     'make-uf-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34651_|
    (##structure
     gx#syntax-quote::t
     'uf-node?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34653_|
    (##structure
     gx#syntax-quote::t
     'uf-node-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34654_|
    (##structure
     gx#syntax-quote::t
     'uf-node-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34655_|
    (##structure
     gx#syntax-quote::t
     'uf-node-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34656_|
    (##structure
     gx#syntax-quote::t
     'uf-node-reach
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34657_|
    (##structure
     gx#syntax-quote::t
     'uf-node-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34658_|
    (##structure
     gx#syntax-quote::t
     'uf-node-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34660_|
    (##structure
     gx#syntax-quote::t
     'uf-node-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34661_|
    (##structure
     gx#syntax-quote::t
     'uf-node-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34662_|
    (##structure
     gx#syntax-quote::t
     'uf-node-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34663_|
    (##structure
     gx#syntax-quote::t
     'uf-node-reach-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34664_|
    (##structure
     gx#syntax-quote::t
     'uf-node-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34665_|
    (##structure
     gx#syntax-quote::t
     'uf-node-order-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34667_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-parent
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34668_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34669_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34670_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-reach
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34671_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34672_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34674_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-parent-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34675_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34676_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34677_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-reach-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34678_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34679_|
    (##structure
     gx#syntax-quote::t
     '&uf-node-order-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34681_|
    (##structure
     gx#syntax-quote::t
     'uf-group::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34683_|
    (##structure
     gx#syntax-quote::t
     'make-uf-group
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34685_|
    (##structure
     gx#syntax-quote::t
     'uf-group?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34687_|
    (##structure
     gx#syntax-quote::t
     'uf-group-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34688_|
    (##structure
     gx#syntax-quote::t
     'uf-group-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34689_|
    (##structure
     gx#syntax-quote::t
     'uf-group-next-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34690_|
    (##structure
     gx#syntax-quote::t
     'uf-group-indexed?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34692_|
    (##structure
     gx#syntax-quote::t
     'uf-group-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34693_|
    (##structure
     gx#syntax-quote::t
     'uf-group-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34694_|
    (##structure
     gx#syntax-quote::t
     'uf-group-next-order-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34695_|
    (##structure
     gx#syntax-quote::t
     'uf-group-indexed?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34697_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34698_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34699_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-next-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34700_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-indexed?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34702_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34703_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34704_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-next-order-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34705_|
    (##structure
     gx#syntax-quote::t
     '&uf-group-indexed?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34707_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34709_|
    (##structure
     gx#syntax-quote::t
     'make-uf-insertion
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34711_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34713_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-group-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34714_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-group
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34715_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34716_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-left-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34717_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-right-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34718_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-a
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34719_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-b
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34721_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-group-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34722_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-group-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34723_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34724_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-left-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34725_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-right-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34726_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-a-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34727_|
    (##structure
     gx#syntax-quote::t
     'uf-insertion-b-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34729_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-group-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34730_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-group
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34731_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34732_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-left-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34733_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-right-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34734_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-a
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34735_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-b
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34737_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-group-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34738_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-group-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34739_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34740_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-left-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34741_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-right-node-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34742_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-a-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34743_|
    (##structure
     gx#syntax-quote::t
     '&uf-insertion-b-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34745_|
    (##structure
     gx#syntax-quote::t
     'frozen-members::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34747_|
    (##structure
     gx#syntax-quote::t
     'make-frozen-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34749_|
    (##structure
     gx#syntax-quote::t
     'frozen-members?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34751_|
    (##structure
     gx#syntax-quote::t
     'frozen-members-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34752_|
    (##structure
     gx#syntax-quote::t
     'frozen-members-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34754_|
    (##structure
     gx#syntax-quote::t
     'frozen-members-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34755_|
    (##structure
     gx#syntax-quote::t
     'frozen-members-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34757_|
    (##structure
     gx#syntax-quote::t
     '&frozen-members-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34758_|
    (##structure
     gx#syntax-quote::t
     '&frozen-members-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34760_|
    (##structure
     gx#syntax-quote::t
     '&frozen-members-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel-uf[1]#_g34761_|
    (##structure
     gx#syntax-quote::t
     '&frozen-members-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/table/trrel-uf[:0:]#uf-node|
      (let ((__obj34485
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34485
           'gerbil-ascent/table/trrel-uf#uf-node::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34485 'uf-node '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34485
           '(parent members size reach predecessors order)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34485
           '(parent members size reach predecessors order)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34485 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34485 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34485 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34485 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34485 '#f '13 '#f '#f))
        (let ((__tmp34646 |gerbil-ascent/table/trrel-uf[1]#_g34647_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34485 __tmp34646 '4 '#f '#f))
        (let ((__tmp34648 |gerbil-ascent/table/trrel-uf[1]#_g34649_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34485 __tmp34648 '14 '#f '#f))
        (let ((__tmp34650 |gerbil-ascent/table/trrel-uf[1]#_g34651_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34485 __tmp34650 '15 '#f '#f))
        (let ((__tmp34652
               (cons (cons 'parent |gerbil-ascent/table/trrel-uf[1]#_g34653_|)
                     (cons (cons 'members
                                 |gerbil-ascent/table/trrel-uf[1]#_g34654_|)
                           (cons (cons 'size
                                       |gerbil-ascent/table/trrel-uf[1]#_g34655_|)
                                 (cons (cons 'reach
                                             |gerbil-ascent/table/trrel-uf[1]#_g34656_|)
                                       (cons (cons 'predecessors
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34657_|)
                                             (cons (cons 'order
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34658_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34485 __tmp34652 '16 '#f '#f))
        (let ((__tmp34659
               (cons (cons 'parent |gerbil-ascent/table/trrel-uf[1]#_g34660_|)
                     (cons (cons 'members
                                 |gerbil-ascent/table/trrel-uf[1]#_g34661_|)
                           (cons (cons 'size
                                       |gerbil-ascent/table/trrel-uf[1]#_g34662_|)
                                 (cons (cons 'reach
                                             |gerbil-ascent/table/trrel-uf[1]#_g34663_|)
                                       (cons (cons 'predecessors
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34664_|)
                                             (cons (cons 'order
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34665_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34485 __tmp34659 '17 '#f '#f))
        (let ((__tmp34666
               (cons (cons 'parent |gerbil-ascent/table/trrel-uf[1]#_g34667_|)
                     (cons (cons 'members
                                 |gerbil-ascent/table/trrel-uf[1]#_g34668_|)
                           (cons (cons 'size
                                       |gerbil-ascent/table/trrel-uf[1]#_g34669_|)
                                 (cons (cons 'reach
                                             |gerbil-ascent/table/trrel-uf[1]#_g34670_|)
                                       (cons (cons 'predecessors
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34671_|)
                                             (cons (cons 'order
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34672_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34485 __tmp34666 '18 '#f '#f))
        (let ((__tmp34673
               (cons (cons 'parent |gerbil-ascent/table/trrel-uf[1]#_g34674_|)
                     (cons (cons 'members
                                 |gerbil-ascent/table/trrel-uf[1]#_g34675_|)
                           (cons (cons 'size
                                       |gerbil-ascent/table/trrel-uf[1]#_g34676_|)
                                 (cons (cons 'reach
                                             |gerbil-ascent/table/trrel-uf[1]#_g34677_|)
                                       (cons (cons 'predecessors
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34678_|)
                                             (cons (cons 'order
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34679_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34485 __tmp34673 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34485 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34485 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34485 '() '21 '#f '#f))
        __obj34485))
    (define |gerbil-ascent/table/trrel-uf[:0:]#uf-group|
      (let ((__obj34486
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34486
           'gerbil-ascent/table/trrel-uf#uf-group::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34486 'uf-group '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34486
           '(nodes roots next-order indexed?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34486
           '(nodes roots next-order indexed?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34486 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34486 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34486 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34486 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34486 '#f '13 '#f '#f))
        (let ((__tmp34680 |gerbil-ascent/table/trrel-uf[1]#_g34681_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34486 __tmp34680 '4 '#f '#f))
        (let ((__tmp34682 |gerbil-ascent/table/trrel-uf[1]#_g34683_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34486 __tmp34682 '14 '#f '#f))
        (let ((__tmp34684 |gerbil-ascent/table/trrel-uf[1]#_g34685_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34486 __tmp34684 '15 '#f '#f))
        (let ((__tmp34686
               (cons (cons 'nodes |gerbil-ascent/table/trrel-uf[1]#_g34687_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/table/trrel-uf[1]#_g34688_|)
                           (cons (cons 'next-order
                                       |gerbil-ascent/table/trrel-uf[1]#_g34689_|)
                                 (cons (cons 'indexed?
                                             |gerbil-ascent/table/trrel-uf[1]#_g34690_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34486 __tmp34686 '16 '#f '#f))
        (let ((__tmp34691
               (cons (cons 'nodes |gerbil-ascent/table/trrel-uf[1]#_g34692_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/table/trrel-uf[1]#_g34693_|)
                           (cons (cons 'next-order
                                       |gerbil-ascent/table/trrel-uf[1]#_g34694_|)
                                 (cons (cons 'indexed?
                                             |gerbil-ascent/table/trrel-uf[1]#_g34695_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34486 __tmp34691 '17 '#f '#f))
        (let ((__tmp34696
               (cons (cons 'nodes |gerbil-ascent/table/trrel-uf[1]#_g34697_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/table/trrel-uf[1]#_g34698_|)
                           (cons (cons 'next-order
                                       |gerbil-ascent/table/trrel-uf[1]#_g34699_|)
                                 (cons (cons 'indexed?
                                             |gerbil-ascent/table/trrel-uf[1]#_g34700_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34486 __tmp34696 '18 '#f '#f))
        (let ((__tmp34701
               (cons (cons 'nodes |gerbil-ascent/table/trrel-uf[1]#_g34702_|)
                     (cons (cons 'roots
                                 |gerbil-ascent/table/trrel-uf[1]#_g34703_|)
                           (cons (cons 'next-order
                                       |gerbil-ascent/table/trrel-uf[1]#_g34704_|)
                                 (cons (cons 'indexed?
                                             |gerbil-ascent/table/trrel-uf[1]#_g34705_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34486 __tmp34701 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34486 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34486 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34486 '() '21 '#f '#f))
        __obj34486))
    (define |gerbil-ascent/table/trrel-uf[:0:]#uf-insertion|
      (let ((__obj34487
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34487
           'gerbil-ascent/table/trrel-uf#uf-insertion::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34487 'uf-insertion '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34487
           '(group-key group row left-node right-node a b)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34487
           '(group-key group row left-node right-node a b)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34487 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34487 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34487 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34487 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34487 '#f '13 '#f '#f))
        (let ((__tmp34706 |gerbil-ascent/table/trrel-uf[1]#_g34707_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34487 __tmp34706 '4 '#f '#f))
        (let ((__tmp34708 |gerbil-ascent/table/trrel-uf[1]#_g34709_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34487 __tmp34708 '14 '#f '#f))
        (let ((__tmp34710 |gerbil-ascent/table/trrel-uf[1]#_g34711_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34487 __tmp34710 '15 '#f '#f))
        (let ((__tmp34712
               (cons (cons 'group-key
                           |gerbil-ascent/table/trrel-uf[1]#_g34713_|)
                     (cons (cons 'group
                                 |gerbil-ascent/table/trrel-uf[1]#_g34714_|)
                           (cons (cons 'row
                                       |gerbil-ascent/table/trrel-uf[1]#_g34715_|)
                                 (cons (cons 'left-node
                                             |gerbil-ascent/table/trrel-uf[1]#_g34716_|)
                                       (cons (cons 'right-node
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34717_|)
                                             (cons (cons 'a
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34718_|)
                                                   (cons (cons 'b
                                                               |gerbil-ascent/table/trrel-uf[1]#_g34719_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34487 __tmp34712 '16 '#f '#f))
        (let ((__tmp34720
               (cons (cons 'group-key
                           |gerbil-ascent/table/trrel-uf[1]#_g34721_|)
                     (cons (cons 'group
                                 |gerbil-ascent/table/trrel-uf[1]#_g34722_|)
                           (cons (cons 'row
                                       |gerbil-ascent/table/trrel-uf[1]#_g34723_|)
                                 (cons (cons 'left-node
                                             |gerbil-ascent/table/trrel-uf[1]#_g34724_|)
                                       (cons (cons 'right-node
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34725_|)
                                             (cons (cons 'a
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34726_|)
                                                   (cons (cons 'b
                                                               |gerbil-ascent/table/trrel-uf[1]#_g34727_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34487 __tmp34720 '17 '#f '#f))
        (let ((__tmp34728
               (cons (cons 'group-key
                           |gerbil-ascent/table/trrel-uf[1]#_g34729_|)
                     (cons (cons 'group
                                 |gerbil-ascent/table/trrel-uf[1]#_g34730_|)
                           (cons (cons 'row
                                       |gerbil-ascent/table/trrel-uf[1]#_g34731_|)
                                 (cons (cons 'left-node
                                             |gerbil-ascent/table/trrel-uf[1]#_g34732_|)
                                       (cons (cons 'right-node
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34733_|)
                                             (cons (cons 'a
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34734_|)
                                                   (cons (cons 'b
                                                               |gerbil-ascent/table/trrel-uf[1]#_g34735_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34487 __tmp34728 '18 '#f '#f))
        (let ((__tmp34736
               (cons (cons 'group-key
                           |gerbil-ascent/table/trrel-uf[1]#_g34737_|)
                     (cons (cons 'group
                                 |gerbil-ascent/table/trrel-uf[1]#_g34738_|)
                           (cons (cons 'row
                                       |gerbil-ascent/table/trrel-uf[1]#_g34739_|)
                                 (cons (cons 'left-node
                                             |gerbil-ascent/table/trrel-uf[1]#_g34740_|)
                                       (cons (cons 'right-node
                                                   |gerbil-ascent/table/trrel-uf[1]#_g34741_|)
                                             (cons (cons 'a
                                                         |gerbil-ascent/table/trrel-uf[1]#_g34742_|)
                                                   (cons (cons 'b
                                                               |gerbil-ascent/table/trrel-uf[1]#_g34743_|)
                                                         '())))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34487 __tmp34736 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34487 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34487 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34487 '() '21 '#f '#f))
        __obj34487))
    (define |gerbil-ascent/table/trrel-uf[:0:]#frozen-members|
      (let ((__obj34488
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34488
           'gerbil-ascent/table/trrel-uf#frozen-members::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34488 'frozen-members '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34488 '(rows count) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34488 '(rows count) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34488 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34488 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34488 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34488 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34488 '#f '13 '#f '#f))
        (let ((__tmp34744 |gerbil-ascent/table/trrel-uf[1]#_g34745_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34488 __tmp34744 '4 '#f '#f))
        (let ((__tmp34746 |gerbil-ascent/table/trrel-uf[1]#_g34747_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34488 __tmp34746 '14 '#f '#f))
        (let ((__tmp34748 |gerbil-ascent/table/trrel-uf[1]#_g34749_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34488 __tmp34748 '15 '#f '#f))
        (let ((__tmp34750
               (cons (cons 'rows |gerbil-ascent/table/trrel-uf[1]#_g34751_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/trrel-uf[1]#_g34752_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34488 __tmp34750 '16 '#f '#f))
        (let ((__tmp34753
               (cons (cons 'rows |gerbil-ascent/table/trrel-uf[1]#_g34754_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/trrel-uf[1]#_g34755_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34488 __tmp34753 '17 '#f '#f))
        (let ((__tmp34756
               (cons (cons 'rows |gerbil-ascent/table/trrel-uf[1]#_g34757_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/trrel-uf[1]#_g34758_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34488 __tmp34756 '18 '#f '#f))
        (let ((__tmp34759
               (cons (cons 'rows |gerbil-ascent/table/trrel-uf[1]#_g34760_|)
                     (cons (cons 'count
                                 |gerbil-ascent/table/trrel-uf[1]#_g34761_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34488 __tmp34759 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34488 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34488 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34488 '() '21 '#f '#f))
        __obj34488))))
