# SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
"""Paid bounded pilot: Python owns byte IO/cost; frozen Scheme owns semantics."""
import argparse, hashlib, json, os, selectors, subprocess, time, shutil
from datetime import datetime, timezone
from pathlib import Path
from .model_study import provider, response_outcome
from .movie_study import provider_key
from ascent_engine.conversation import ResponseHistory
ROOT = Path.cwd().resolve()
BASE = ROOT / '.cache/ascent/crosspath-search-v3'
SNAP = ROOT / '.cache/ascent/crosspath-search/snapshot'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def save(p, x):
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n')

class Native:

    def __init__(self):
        env = os.environ.copy()
        env['GERBIL_PATH'] = str(SNAP / '.gerbil')
        env['GERBIL_LOADPATH'] = str(SNAP / '.gerbil/lib')
        env['LIBRARY_PATH'] = subprocess.check_output(['brew', '--prefix', 'openssl@3'], text=True).strip() + '/lib'
        for k in ('CC', 'CFLAGS', 'CPPFLAGS', 'LDFLAGS', 'CPATH', 'C_INCLUDE_PATH', 'CPLUS_INCLUDE_PATH', 'NIX_CFLAGS_COMPILE', 'NIX_LDFLAGS', 'DEVELOPER_DIR', 'SDKROOT'):
            env.pop(k, None)
        self.err = (BASE / 'native-stderr.log').open('a')
        self.p = subprocess.Popen([str(SNAP / '.gerbil/bin/crosspath-search'), '-:max-heap=1G,debug=q'], cwd=SNAP, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.err, text=True, bufsize=1)

    def call(self, **kw):
        began = time.monotonic()
        self.p.stdin.write(json.dumps(kw) + '\n')
        self.p.stdin.flush()
        s = selectors.DefaultSelector()
        s.register(self.p.stdout, selectors.EVENT_READ)
        if not s.select(20):
            self.close()
            raise TimeoutError('native reply deadline')
        s.close()
        line = self.p.stdout.readline()
        if not line:
            raise RuntimeError('native exited; see native-stderr.log')
        r = json.loads(line)
        if 'error' in r:
            raise RuntimeError(r['error'])
        return (r, time.monotonic() - began)

    def close(self):
        if self.p.poll() is None:
            self.p.terminate()
            try:
                self.p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.p.kill()
                self.p.wait(timeout=5)
        self.err.close()
def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False)

def input_reserve(request):
    return len(canonical(request).encode()) + 4096 + 128 * len(request['input'])

def charge_usage(usage):
    if not isinstance(usage, dict) or not all((type(usage.get(k)) is int and usage[k] >= 0 for k in ('input_tokens', 'output_tokens'))):
        raise ValueError('missing_usage_budget_unknown')
    total = usage['input_tokens'] + usage['output_tokens']
    if 'total_tokens' in usage and usage['total_tokens'] != total:
        raise ValueError('inconsistent_total_usage')
    for field, detail, limit in [('output_tokens_details', 'reasoning_tokens', 'output_tokens'), ('input_tokens_details', 'cached_tokens', 'input_tokens')]:
        value = usage.get(field, {}).get(detail) if isinstance(usage.get(field, {}), dict) else None
        if value is not None and (type(value) is not int or not 0 <= value <= usage[limit]):
            raise ValueError('inconsistent_usage_breakdown')
    return total

import itertools
from .crosspath_search_v2 import task, EDGES, NEEDS, ANNOTATION_RUBRIC, ANNOTATOR_TOOL
from .crosspath_search_v2 import bound_files as inherited_binding, packet, init
from .crosspath_branch import BranchQueue, parse_expansion
CASES=[task(220411,'branch-search-4')]
CALIBRATION=task(330419,'branch-calibration-5')
TOOLS=[{'type':'function','name':'expand','description':'Expand exactly one unvisited child of the supplied parent.','parameters':{'type':'object','properties':{'optionId':{'type':'integer'}},'required':['optionId'],'additionalProperties':False}}]
INSTRUCTIONS='''Perform ONE local branch expansion, not a complete search. Call expand exactly once with an allowed optionId for the specified parent. Do not enumerate a tree or solve the global optimum. Eligible option iff BOTH positive-length directed paths of its fragment F exist in source edges. needs columns: [fragmentId, firstFrom, firstTo, secondFrom, secondTo]. Option IDs differ from fragment IDs. The common starting solution is certified feasible and non-optimal; no optimum is shown. Choose a useful unexplored child. Counterfactual totals are native arithmetic for prefix plus common seed suffix; they DO NOT certify eligibility. A suffix over budget can be repaired by future choices; prefix resource limits cannot. Prioritize a promising local value/resource tradeoff while checking fragment eligibility. Relevant shared immutable Fact and proof fragments may be cited directly from evidence; do not re-prove a checked fact. Identify F IDs/path endpoints naturally when deriving or citing them; do not fabricate derivations for audit. Stop thinking after this local choice and immediately call expand. Each call receives a fresh bounded branch context; earlier thinking is not replayed. The external controller retains the frontier and incumbent. It performs native evaluation and keeps valid candidates independently of subsequent truncation. Input and all output including thinking are charged against 65536 per phase; unused budget is reported as unused, never savings.'''
ANNOTATION_RUBRIC += ''' Calls are separate branch contexts over the SAME immutable source. A repeated source-bound deduction across calls can have a prior link even if the chosen option, search prefix or goal changes: qualification is invariant. Distinguish a new alternative witness from replaying exactly the same ordered direct edges. Extract atomic path episodes when present, as well as complete F conjunction episodes; do not invent an atomic quote by filling missing premises. For path-only episodes use fragment null, ready null and one endpoint pair. Conjunction-only support and explicit edge-chain support are distinct identities. Mere reuse/reference is never a repeated derivation. Packet-covered rederivation is a separate measure from a repeated earlier textual derivation. Negative/ambiguous deductions are retained but not admitted as definite positive repeats.'''
PRODUCERS=['python/src/ascent_test_support/crosspath_search_v3.py','python/src/ascent_test_support/crosspath_branch.py','python/src/ascent_test_support/crosspath_annotation_v3.py','python/src/ascent_test_support/crosspath_report_v3.py']

def seed_for(native,c,goal):
    # Enumeration is byte-level proposal generation only; Scheme owns feasibility/objective.
    groups=[[o['id'] for o in c['options'] if o['stage']==s] for s in range(goal['stages'])]
    for proposal in itertools.product(*groups):
        checked,_=native.call(op='evaluate',goal=goal,selection=list(proposal))
        if checked['valid']:
            grade,_=native.call(op='grade',goal=goal,selection=list(proposal))
            if not grade['optimal']:return {'selection':list(proposal),'grade':grade}
    raise RuntimeError('no non-optimal feasible seed')

def qualify():
    BASE.mkdir(exist_ok=True)
    native=Native();cases=[]
    try:
        for c in [CALIBRATION,*CASES]:
            expected=None;receipts=[]
            for arm in ('baseline','fresh','retained'):
                init(native,c,arm);folder=BASE/'qualification-packets'/c['id']/arm;folder.mkdir(parents=True,exist_ok=False)
                a,ar=packet(native,folder);b,br=packet(native,folder)
                if a!=b or ar['reused'] or br['reused']!=(arm=='retained'):raise RuntimeError('packet/state mismatch')
                if expected is not None and expected!=a:raise RuntimeError('evidence mismatch')
                expected=a;receipts.append({'arm':arm,'first':ar,'second':br})
            init(native,c,'fresh');seeds=[seed_for(native,c,g) for g in c['goals']]
            if any(s['grade']['gap']<=0 or not s['grade']['valid'] for s in seeds):raise RuntimeError('seed gate')
            cases.append({'task':c['id'],'packetSha256':sha(canonical(expected).encode()),'seeds':seeds,'packetStateChecks':receipts})
        save(BASE/'qualification.json',{'cases':cases,'nativeGraderSha256':sha((SNAP/'.gerbil/bin/crosspath-search').read_bytes()),'inheritedQualificationSha256':sha((ROOT/'.cache/ascent/crosspath-search/qualification.json').read_bytes()),'scope':'Unchanged qualified native grader/kernel; source-byte binding, packet parity, native seed feasibility and strict non-optimality checked before outcomes.'})
    finally:native.close()
    print('BRANCH-QUALIFICATION-OK',flush=True)

def freeze():
    if (BASE/'frozen-plan.json').exists():raise RuntimeError('already frozen')
    binding=inherited_binding()
    binding.update({p:sha((ROOT/p).read_bytes()) for p in PRODUCERS})
    p={'schema':'ascent.branch-search.v3','frozenAtUtc':datetime.now(timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'cases':CASES,'calibration':CALIBRATION,'order':['baseline','fresh','retained'],'model':'deepseek-flash','reasoningEffort':'low','totalTokenBudget':65536,'perCallOutputCap':3072,'maxCalls':128,'maxConsecutiveCallFailures':3,'instructions':INSTRUCTIONS,'tools':TOOLS,'annotationRubric':ANNOTATION_RUBRIC,'annotatorTool':ANNOTATOR_TOOL,'annotationOutputCap':8192,'binding':binding,'qualificationSha256':sha((BASE/'qualification.json').read_bytes()),'calibrationGate':'Three disjoint root expansions, one per arm. All complete, exactly one valid expansion, no output truncation. Must pass before confirmatory calls; no tuning/retry after outcomes in this version. Calibration costs outside confirmatory budget, separately reported.','searchPolicy':'Depth-first explicit scheduled parent; model selects one unvisited child. Scheme raw-source prefix validity admits frontier; each child completed with common seed suffix and independently evaluated. Raw-source complete optimum hidden until scoring. Common incumbent always remains available. Fresh bounded context per call, identical policy and seed in all arms.','failurePolicy':'Known-cost truncated/invalid call retained and charged; same bounded parent offered on next NEW call (no continuation of incomplete thinking, no credit for incomplete actions), up to three consecutive failures. Unknown usage stops phase. Each failed expansion/invalid completion preserved. Final incumbent selected mechanically, no extra model submit; report controller-selected outcome separately.','budgetPolicy':'All provider input + output (reasoning subset) charged including cached input and failed calls. Byte+4096+128 reserve, actual usage authoritative. Stop before reservation exceeds remaining; unused reserve or output ceiling never called savings. Curves use last observed candidate at common gross-token checkpoints 16384/32768/49152, no future outcomes/interpolation.','annotationScope':'Frozen blinded same-provider extraction with exact quotes, native claim truth, prior links and premise identity; extraction completeness/inter-rater agreement unvalidated. Atomic path and F-conjunction units distinct. Alternative witnesses not counted as identical-premise repeats. Across-goal matches reported separately.','causalBoundary':'Fresh/retained packets are byte-identical, only native cache state differs; model differences descriptive. Baseline omits initial evidence, shares raw source, common seed and arithmetic. No optional fragment tool in any arm for this bounded branch experiment.','buildScope':'Inherited frozen production candidate kernel, unchanged native bridge/independent raw-source grader and transitive artifacts; current candidate bytes checked, not entire checkout build/remote CI.'}
    save(BASE/'frozen-plan.json',p);(BASE/'frozen-plan.sha256').write_text(sha((BASE/'frozen-plan.json').read_bytes())+'\n');print('BRANCH-FROZEN',flush=True)

def verify(plan):
    if sha((BASE/'frozen-plan.json').read_bytes())!=(BASE/'frozen-plan.sha256').read_text().strip():raise RuntimeError('plan drift')
    if sha((BASE/'qualification.json').read_bytes())!=plan['qualificationSha256']:raise RuntimeError('qualification drift')
    for path,h in plan['binding'].items():
        if sha((ROOT/path).read_bytes())!=h:raise RuntimeError('binding drift '+path)
    for p in (SNAP/'candidate').glob('*.ss'):
        if p.read_bytes()!=(ROOT/'candidate'/p.name).read_bytes():raise RuntimeError('candidate source drift')

def thinking_text(meta,dest=None):
    term=meta.get('terminal') or {}
    text='\n'.join(x.get('text','') for item in term.get('output',[]) if item.get('type')=='reasoning' for x in item.get('content',[]) if x.get('type')=='reasoning_text')
    if not text and dest and dest.with_suffix('.events.jsonl').exists():
        events=[json.loads(l) for l in dest.with_suffix('.events.jsonl').read_text().splitlines()]
        text=''.join(e.get('delta','') for e in events if e.get('type')=='response.reasoning_text.delta')
    return text

def public_check(raw):
    return {k:raw[k] for k in ('cost','risk','value','depth') if k in raw}

def context(native,c,phase,arm,folder,parent,allowed,seed,best,last,evidence):
    options=[]
    for oid in allowed:
        prefix=parent+[oid];complete=prefix+seed[len(prefix):]
        a,_=native.call(op='inspect',goal=c['goals'][phase],selection=prefix)
        b,_=native.call(op='evaluate',goal=c['goals'][phase],selection=complete)
        options.append({'option':c['options'][oid],'prefixTotals':public_check(a),'seedSuffixTotals':public_check(b)})
    return {'source':{'edges':c['edges'],'needs':c['needs'],'needsColumns':['fragmentId','firstFrom','firstTo','secondFrom','secondTo']},'evidence':evidence,'commonSeed':seed,'goal':{k:v for k,v in c['goals'][phase].items() if k!='bonuses'},'parent':parent,'unvisitedChildren':options,'incumbent':best,'lastExpansion':last,'instruction':'Choose exactly one of these children, then expand; no global search in this response.'}

def run_phase(plan,c,phase,arm,native,folder,calibration=False):
    folder.mkdir(parents=True,exist_ok=False)
    qual=next(q for q in json.loads((BASE/'qualification.json').read_text())['cases'] if q['task']==c['id'])
    seed=qual['seeds'][phase]['selection'];evidence=None;build=None
    if arm!='baseline':
        evidence,build=packet(native,folder)
        if sha(canonical(evidence).encode())!=qual['packetSha256']:raise RuntimeError('packet drift')
    best={'selection':seed,'evaluation':public_check(qual['seeds'][phase]['grade'])}
    row={'case':c['id'],'phase':phase,'arm':arm,'packet':build,'seed':qual['seeds'][phase],'calls':[],'expansions':[],'failure':None,'budget':plan['totalTokenBudget'],'observedTotalTokens':0,'calibration':calibration}
    queue=BranchQueue(c['goals'][phase]['stages'],c['options']);last=None;consecutive=0;key=provider_key()
    for turn in range(1 if calibration else plan['maxCalls']):
        pending=queue.next()
        if pending is None:row['stopReason']='tree_exhausted';break
        parent,allowed=pending
        q=context(native,c,phase,arm,folder,parent,allowed,seed,best,last,evidence)
        request={'model':plan['model'],'input':[{'role':'user','content':canonical(q)}],'instructions':plan['instructions'],'tools':plan['tools'],'tool_choice':'auto','reasoning':{'effort':plan['reasoningEffort']},'max_output_tokens':plan['perCallOutputCap'],'stream':True,'store':False}
        reserve=input_reserve(request)
        if row['observedTotalTokens']+reserve+plan['perCallOutputCap']>plan['totalTokenBudget']:
            row['stopReason']='remaining_below_input_output_reservation';break
        save(folder/f'{turn}.request.json',request);dest=folder/f'{turn}.response.json'
        _,meta=provider(request,key,dest);term=meta.get('terminal') or {};text=thinking_text(meta,dest)
        (folder/f'{turn}.thinking.txt').write_text(text)
        call={'turn':turn,'parent':parent,'allowed':allowed,'usage':term.get('usage'),'providerSeconds':meta.get('providerSeconds'),'status':term.get('status'),'outcome':term.get('status') or meta.get('error'),'thinkingSha256':sha(text.encode()),'failure':None,'inputReserve':reserve,'maxOutput':plan['perCallOutputCap']}
        row['calls'].append(call)
        try:
            charged=charge_usage(call['usage']);row['observedTotalTokens']+=charged;call['grossTokens']=charged;call['cumulativeGrossTokens']=row['observedTotalTokens']
            if call['usage']['input_tokens']>reserve or call['usage']['output_tokens']>plan['perCallOutputCap'] or row['observedTotalTokens']>plan['totalTokenBudget']:raise ValueError('budget_protocol_violation')
        except ValueError as e:
            call['failure']=str(e);row['failure']=str(e);save(folder/'receipt.json',row);break
        try:
            if meta.get('error') or term.get('status')!='completed':raise ValueError('provider_incomplete_or_error')
            oid=parse_expansion(term,allowed);prefix=parent+[oid]
            raw,seconds=native.call(op='inspect',goal=c['goals'][phase],selection=prefix)
            complete=prefix+seed[len(prefix):];checked,cs=native.call(op='evaluate',goal=c['goals'][phase],selection=complete)
            child=queue.expand(parent,oid,raw['valid'])
            expansion={'turn':turn,'parent':parent,'child':child,'optionId':oid,'prefix':raw,'completion':complete,'evaluation':checked,'nativeSeconds':seconds+cs,'atGrossTokens':row['observedTotalTokens']}
            row['expansions'].append(expansion)
            if checked['valid'] and checked['value']>best['evaluation']['value']:best={'selection':complete,'evaluation':public_check(checked)}
            last={'parent':parent,'child':child,'prefixValid':raw['valid'],'completionValid':checked['valid'],'completionTotals':public_check(checked)}
            consecutive=0
        except (ValueError,KeyError,TypeError,json.JSONDecodeError) as e:
            call['failure']=str(e);consecutive+=1
            if consecutive>=plan['maxConsecutiveCallFailures']:row['failure']='consecutive_failed_calls';save(folder/'receipt.json',row);break
        row['incumbent']=best;save(folder/'receipt.json',row)
        print('BRANCH',arm,phase,turn,'gross',row['observedTotalTokens'],'depth',len(parent)+1,'failure',call['failure'],flush=True)
    row.setdefault('stopReason','calibration_one_call' if calibration else 'call_limit_or_failure')
    row['incumbent']=best;row['bestGrade'],_=native.call(op='grade',goal=c['goals'][phase],selection=best['selection'])
    row['unusedBudget']=plan['totalTokenBudget']-row['observedTotalTokens'];row['modelSubmitted']=False;row['outcomeSelection']='controller incumbent, including common seed; not model submission'
    save(folder/'receipt.json',row);print('PHASE',arm,phase,'gap',row['bestGrade'].get('gap'),'calls',len(row['calls']),'unused',row['unusedBudget'],flush=True)
    return row

def calibrate(plan):
    verify(plan);rows=[];native=Native()
    try:
        for arm in plan['order']:
            init(native,CALIBRATION,arm);r=run_phase(plan,CALIBRATION,0,arm,native,BASE/'calibration'/arm,True);rows.append(r)
            save(BASE/'calibration-ledger.json',{'phases':rows,'passed':False})
    finally:native.close()
    passed=all(len(r['expansions'])==1 and not r['calls'][0]['failure'] and r['calls'][0]['status']=='completed' for r in rows)
    save(BASE/'calibration-ledger.json',{'phases':rows,'passed':passed,'grossTokens':sum(r['observedTotalTokens'] for r in rows),'gate':'No capped/incomplete call; exactly one completed scheduled expansion in every arm.'})
    if not passed:raise RuntimeError('calibration gate failed; main study not run')
    print('BRANCH-CALIBRATION-PASSED',flush=True)

def run(plan):
    verify(plan)
    if not json.loads((BASE/'calibration-ledger.json').read_text())['passed']:raise RuntimeError('calibration not passed')
    paid=BASE/'paid';paid.mkdir(exist_ok=False);rows=[]
    for arm in plan['order']:
        native=Native()
        try:
            for c in CASES:
                init(native,c,arm)
                for phase in range(2):
                    rows.append(run_phase(plan,c,phase,arm,native,paid/f"{c['id']}-{arm}-{phase}"))
                    save(BASE/'ledger.json',{'planSha256':sha((BASE/'frozen-plan.json').read_bytes()),'phases':rows})
        finally:native.close()
    verify(plan);save(BASE/'post-run-binding.json',{'verified':True,'files':len(plan['binding'])});print('BRANCH-RUN-OK',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('command',choices=['qualify','freeze','calibrate','run']);a=p.parse_args()
    if a.command=='qualify':qualify()
    elif a.command=='freeze':freeze()
    else:globals()[a.command](json.loads((BASE/'frozen-plan.json').read_text()))
