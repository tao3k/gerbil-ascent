(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/reasoning[1]#_g39718_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39720_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-receipt
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39722_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39724_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39725_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39726_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39727_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39728_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39729_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39730_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39731_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-diagnostics
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39732_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39733_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39734_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-nonmembership
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39735_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-stratified
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39737_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39738_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39739_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39740_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39741_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39742_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39743_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39744_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-diagnostics-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39745_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39746_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39747_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-nonmembership-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39748_|
    (##structure
     gx#syntax-quote::t
     'reasoning-receipt-stratified-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39750_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39751_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39752_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39753_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39754_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39755_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39756_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39757_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-diagnostics
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39758_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39759_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39760_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-nonmembership
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39761_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-stratified
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39763_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39764_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39765_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39766_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39767_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39768_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39769_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39770_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-diagnostics-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39771_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39772_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39773_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-nonmembership-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39774_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-receipt-stratified-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39776_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39778_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39780_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39782_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39783_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-support
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39784_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-reachable
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39786_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39787_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-support-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39788_|
    (##structure
     gx#syntax-quote::t
     'reasoning-evidence-reachable-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39790_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39791_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-support
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39792_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-reachable
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39794_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39795_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-support-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39796_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-evidence-reachable-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39798_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39800_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-stratified-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39802_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39804_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39805_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-finite
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39806_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39807_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39809_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39810_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-finite-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39811_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39812_|
    (##structure
     gx#syntax-quote::t
     'reasoning-stratified-evidence-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39814_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39815_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-finite
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39816_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39817_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39819_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39820_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-finite-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39821_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-proof-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39822_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-stratified-evidence-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39824_|
    (##structure
     gx#syntax-quote::t
     'captured-stage::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39826_|
    (##structure
     gx#syntax-quote::t
     'make-captured-stage
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39828_|
    (##structure
     gx#syntax-quote::t
     'captured-stage?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39830_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-ok?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39831_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39833_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-ok?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39834_|
    (##structure
     gx#syntax-quote::t
     'captured-stage-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39836_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-ok?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39837_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39839_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-ok?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39840_|
    (##structure
     gx#syntax-quote::t
     '&captured-stage-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39842_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39844_|
    (##structure
     gx#syntax-quote::t
     'make-attempt-observation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39846_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39848_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39849_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39851_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39852_|
    (##structure
     gx#syntax-quote::t
     'attempt-observation-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39854_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39855_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-evidence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39857_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/reasoning[1]#_g39858_|
    (##structure
     gx#syntax-quote::t
     '&attempt-observation-evidence-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/reasoning[:0:]#reasoning-receipt|
      (let ((__obj39636
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39636
           'gerbil-ascent/candidate/reasoning#reasoning-receipt::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39636
           'reasoning-receipt
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39636
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    rows
                    diagnostics
                    evidence
                    proof
                    nonmembership
                    stratified)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39636
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    rows
                    diagnostics
                    evidence
                    proof
                    nonmembership
                    stratified)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39636 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39636 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39636 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39636 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39636 '#f '13 '#f '#f))
        (let ((__tmp39717 |gerbil-ascent/candidate/reasoning[1]#_g39718_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39636 __tmp39717 '4 '#f '#f))
        (let ((__tmp39719 |gerbil-ascent/candidate/reasoning[1]#_g39720_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39636 __tmp39719 '14 '#f '#f))
        (let ((__tmp39721 |gerbil-ascent/candidate/reasoning[1]#_g39722_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39636 __tmp39721 '15 '#f '#f))
        (let ((__tmp39723
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39724_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g39725_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g39726_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g39727_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g39728_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g39729_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g39730_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g39731_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g39732_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g39733_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g39734_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g39735_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj39636 __tmp39723 '16 '#f '#f))
        (let ((__tmp39736
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39737_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g39738_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g39739_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g39740_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g39741_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g39742_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g39743_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g39744_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g39745_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g39746_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g39747_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g39748_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj39636 __tmp39736 '17 '#f '#f))
        (let ((__tmp39749
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39750_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g39751_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g39752_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g39753_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g39754_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g39755_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g39756_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g39757_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g39758_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g39759_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g39760_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g39761_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj39636 __tmp39749 '18 '#f '#f))
        (let ((__tmp39762
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39763_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/reasoning[1]#_g39764_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/reasoning[1]#_g39765_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/reasoning[1]#_g39766_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/reasoning[1]#_g39767_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/reasoning[1]#_g39768_|)
                                                   (cons (cons 'rows
                                                               |gerbil-ascent/candidate/reasoning[1]#_g39769_|)
                                                         (cons (cons 'diagnostics
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/reasoning[1]#_g39770_|)
                       (cons (cons 'evidence
                                   |gerbil-ascent/candidate/reasoning[1]#_g39771_|)
                             (cons (cons 'proof
                                         |gerbil-ascent/candidate/reasoning[1]#_g39772_|)
                                   (cons (cons 'nonmembership
                                               |gerbil-ascent/candidate/reasoning[1]#_g39773_|)
                                         (cons (cons 'stratified
                                                     |gerbil-ascent/candidate/reasoning[1]#_g39774_|)
                                               '()))))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj39636 __tmp39762 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39636 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39636 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39636 '() '21 '#f '#f))
        __obj39636))
    (define |gerbil-ascent/candidate/reasoning[:0:]#reasoning-evidence|
      (let ((__obj39637
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39637
           'gerbil-ascent/candidate/reasoning#reasoning-evidence::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39637
           'reasoning-evidence
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39637
           '(kind support reachable)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39637
           '(kind support reachable)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39637 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39637 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39637 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39637 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39637 '#f '13 '#f '#f))
        (let ((__tmp39775 |gerbil-ascent/candidate/reasoning[1]#_g39776_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39637 __tmp39775 '4 '#f '#f))
        (let ((__tmp39777 |gerbil-ascent/candidate/reasoning[1]#_g39778_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39637 __tmp39777 '14 '#f '#f))
        (let ((__tmp39779 |gerbil-ascent/candidate/reasoning[1]#_g39780_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39637 __tmp39779 '15 '#f '#f))
        (let ((__tmp39781
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g39782_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g39783_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g39784_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39637 __tmp39781 '16 '#f '#f))
        (let ((__tmp39785
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g39786_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g39787_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g39788_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39637 __tmp39785 '17 '#f '#f))
        (let ((__tmp39789
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g39790_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g39791_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g39792_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39637 __tmp39789 '18 '#f '#f))
        (let ((__tmp39793
               (cons (cons 'kind
                           |gerbil-ascent/candidate/reasoning[1]#_g39794_|)
                     (cons (cons 'support
                                 |gerbil-ascent/candidate/reasoning[1]#_g39795_|)
                           (cons (cons 'reachable
                                       |gerbil-ascent/candidate/reasoning[1]#_g39796_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39637 __tmp39793 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39637 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39637 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39637 '() '21 '#f '#f))
        __obj39637))
    (define |gerbil-ascent/candidate/reasoning[:0:]#reasoning-stratified-evidence|
      (let ((__obj39638
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39638
           'gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39638
           'reasoning-stratified-evidence
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39638
           '(status finite proof work-budget)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39638
           '(status finite proof work-budget)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39638 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39638 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39638 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39638 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39638 '#f '13 '#f '#f))
        (let ((__tmp39797 |gerbil-ascent/candidate/reasoning[1]#_g39798_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39638 __tmp39797 '4 '#f '#f))
        (let ((__tmp39799 |gerbil-ascent/candidate/reasoning[1]#_g39800_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39638 __tmp39799 '14 '#f '#f))
        (let ((__tmp39801 |gerbil-ascent/candidate/reasoning[1]#_g39802_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39638 __tmp39801 '15 '#f '#f))
        (let ((__tmp39803
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39804_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g39805_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g39806_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g39807_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39638 __tmp39803 '16 '#f '#f))
        (let ((__tmp39808
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39809_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g39810_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g39811_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g39812_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39638 __tmp39808 '17 '#f '#f))
        (let ((__tmp39813
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39814_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g39815_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g39816_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g39817_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39638 __tmp39813 '18 '#f '#f))
        (let ((__tmp39818
               (cons (cons 'status
                           |gerbil-ascent/candidate/reasoning[1]#_g39819_|)
                     (cons (cons 'finite
                                 |gerbil-ascent/candidate/reasoning[1]#_g39820_|)
                           (cons (cons 'proof
                                       |gerbil-ascent/candidate/reasoning[1]#_g39821_|)
                                 (cons (cons 'work-budget
                                             |gerbil-ascent/candidate/reasoning[1]#_g39822_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39638 __tmp39818 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39638 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39638 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39638 '() '21 '#f '#f))
        __obj39638))
    (define |gerbil-ascent/candidate/reasoning[:0:]#captured-stage|
      (let ((__obj39639
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39639
           'gerbil-ascent/candidate/reasoning#captured-stage::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39639 'captured-stage '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39639 '(ok? value) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39639 '(ok? value) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39639 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39639 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39639 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39639 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39639 '#f '13 '#f '#f))
        (let ((__tmp39823 |gerbil-ascent/candidate/reasoning[1]#_g39824_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39639 __tmp39823 '4 '#f '#f))
        (let ((__tmp39825 |gerbil-ascent/candidate/reasoning[1]#_g39826_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39639 __tmp39825 '14 '#f '#f))
        (let ((__tmp39827 |gerbil-ascent/candidate/reasoning[1]#_g39828_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39639 __tmp39827 '15 '#f '#f))
        (let ((__tmp39829
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g39830_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g39831_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39639 __tmp39829 '16 '#f '#f))
        (let ((__tmp39832
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g39833_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g39834_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39639 __tmp39832 '17 '#f '#f))
        (let ((__tmp39835
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g39836_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g39837_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39639 __tmp39835 '18 '#f '#f))
        (let ((__tmp39838
               (cons (cons 'ok?
                           |gerbil-ascent/candidate/reasoning[1]#_g39839_|)
                     (cons (cons 'value
                                 |gerbil-ascent/candidate/reasoning[1]#_g39840_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39639 __tmp39838 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39639 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39639 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39639 '() '21 '#f '#f))
        __obj39639))
    (define |gerbil-ascent/candidate/reasoning[:0:]#attempt-observation|
      (let ((__obj39640
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39640
           'gerbil-ascent/candidate/reasoning#attempt-observation::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj39640
           'attempt-observation
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39640 '(rows evidence) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39640 '(rows evidence) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39640 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39640 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39640 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39640 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39640 '#f '13 '#f '#f))
        (let ((__tmp39841 |gerbil-ascent/candidate/reasoning[1]#_g39842_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39640 __tmp39841 '4 '#f '#f))
        (let ((__tmp39843 |gerbil-ascent/candidate/reasoning[1]#_g39844_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39640 __tmp39843 '14 '#f '#f))
        (let ((__tmp39845 |gerbil-ascent/candidate/reasoning[1]#_g39846_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj39640 __tmp39845 '15 '#f '#f))
        (let ((__tmp39847
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g39848_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g39849_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39640 __tmp39847 '16 '#f '#f))
        (let ((__tmp39850
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g39851_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g39852_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39640 __tmp39850 '17 '#f '#f))
        (let ((__tmp39853
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g39854_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g39855_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39640 __tmp39853 '18 '#f '#f))
        (let ((__tmp39856
               (cons (cons 'rows
                           |gerbil-ascent/candidate/reasoning[1]#_g39857_|)
                     (cons (cons 'evidence
                                 |gerbil-ascent/candidate/reasoning[1]#_g39858_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj39640 __tmp39856 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39640 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39640 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj39640 '() '21 '#f '#f))
        __obj39640))))
