(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/source-snapshot::timestamp 1791689699)
  (begin
    (define gerbil-ascent/program/source-snapshot#source-snapshot::t
      (let ((__tmp36507 (list))
            (__tmp36506
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/source-snapshot#source-snapshot::t
         'source-snapshot
         __tmp36507
         '(template program declarations rows materializations)
         __tmp36506
         '#f)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/source-snapshot#source-snapshot::t)))
    (define gerbil-ascent/program/source-snapshot#make-source-snapshot
      (lambda _%$args13022%_
        (apply make-instance
               gerbil-ascent/program/source-snapshot#source-snapshot::t
               _%$args13022%_)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-template
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'template)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-program
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'program)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-declarations
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'declarations)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'rows)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-materializations
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'materializations)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-template-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'template)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-program-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'program)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-declarations-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'declarations)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'rows)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-materializations-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'materializations)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-template
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'template)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-program
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'program)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-declarations
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'declarations)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'rows)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-materializations
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'materializations)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-template-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'template)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-program-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'program)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-declarations-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'declarations)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'rows)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-materializations-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'materializations)))
    (define gerbil-ascent/program/source-snapshot#source-materialization::t
      (let ((__tmp36509 (list))
            (__tmp36508
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/source-snapshot#source-materialization::t
         'source-materialization
         __tmp36509
         '(base additions rows scalar?)
         __tmp36508
         '#f)))
    (define gerbil-ascent/program/source-snapshot#source-materialization?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/source-snapshot#source-materialization::t)))
    (define gerbil-ascent/program/source-snapshot#make-source-materialization
      (lambda _%$args13019%_
        (apply make-instance
               gerbil-ascent/program/source-snapshot#source-materialization::t
               _%$args13019%_)))
    (define gerbil-ascent/program/source-snapshot#source-materialization-base
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'base)))
    (define gerbil-ascent/program/source-snapshot#source-materialization-additions
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'additions)))
    (define gerbil-ascent/program/source-snapshot#source-materialization-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'rows)))
    (define gerbil-ascent/program/source-snapshot#source-materialization-scalar?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'scalar?)))
    (define gerbil-ascent/program/source-snapshot#source-materialization-base-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'base)))
    (define gerbil-ascent/program/source-snapshot#source-materialization-additions-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'additions)))
    (define gerbil-ascent/program/source-snapshot#source-materialization-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'rows)))
    (define gerbil-ascent/program/source-snapshot#source-materialization-scalar?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'scalar?)))
    (define gerbil-ascent/program/source-snapshot#&source-materialization-base
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'base)))
    (define gerbil-ascent/program/source-snapshot#&source-materialization-additions
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'additions)))
    (define gerbil-ascent/program/source-snapshot#&source-materialization-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'rows)))
    (define gerbil-ascent/program/source-snapshot#&source-materialization-scalar?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'scalar?)))
    (define gerbil-ascent/program/source-snapshot#&source-materialization-base-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'base)))
    (define gerbil-ascent/program/source-snapshot#&source-materialization-additions-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'additions)))
    (define gerbil-ascent/program/source-snapshot#&source-materialization-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'rows)))
    (define gerbil-ascent/program/source-snapshot#&source-materialization-scalar?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'scalar?)))
    (define gerbil-ascent/program/source-snapshot#capture-source-materialization
      (lambda (_%base13010%_ _%additions13011%_ _%rows13012%_)
        (let ((__tmp36510
               (let ((__tmp36511
                      (lambda ()
                        (let ((__tmp36512
                               (lambda (_%$%g1301413016%_)
                                 (let ()
                                   (declare (not safe))
                                   (andmap__0
                                    gerbil-ascent/program/scheme-checked#relational-scalar?
                                    _%$%g1301413016%_)))))
                          (declare (not safe))
                          (andmap__0 __tmp36512 _%rows13012%_)))))
                 (declare (not safe))
                 (__make-atomic-promise __tmp36511))))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/source-snapshot#source-materialization::t
           _%base13010%_
           _%additions13011%_
           _%rows13012%_
           __tmp36510))))
    (define gerbil-ascent/program/source-snapshot#__materialize-source-log
      (lambda (_%base12996%_ _%additions12997%_ _%previous12998%_)
        (let ((_%previous13001%_ _%previous12998%_))
          (if (and (eq? _%base12996%_
                        (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%previous13001%_
                           '1
                           '#f
                           '#f)))
                   (eq? _%additions12997%_
                        (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%previous13001%_
                           '2
                           '#f
                           '#f))))
              _%previous13001%_
              (gerbil-ascent/program/source-snapshot#capture-source-materialization
               _%base12996%_
               _%additions12997%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/program/source-log#gerbil-ascent-source-log-rows
                  _%base12996%_
                  _%additions12997%_)))))))
    (define gerbil-ascent/program/source-snapshot#materialize-source-log
      (lambda (_%base12982%_ _%additions12983%_ _%previous12984%_)
        (let ((_%previous12987%_ _%previous12984%_))
          (gerbil-ascent/program/source-snapshot#__materialize-source-log
           _%base12982%_
           _%additions12983%_
           _%previous12987%_))))
    (define gerbil-ascent/program/source-snapshot#__gerbil-ascent-source-log-snapshot-equal?
      (lambda (_%snapshot12954%_
               _%candidate12955%_
               _%index12956%_
               _%log12957%_
               _%rows12958%_)
        (let ((_%snapshot12961%_ _%snapshot12954%_))
          (if (eq? _%candidate12955%_
                   (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref _%snapshot12961%_ '2 '#f '#f)))
              (let* ((_%materialization12970%_
                      (vector-ref
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%snapshot12961%_
                          '5
                          '#f
                          '#f))
                       _%index12956%_))
                     (_%materialization12972%_ _%materialization12970%_))
                (if (eq? (car _%log12957%_)
                         (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%materialization12972%_
                            '1
                            '#f
                            '#f)))
                    (if (eq? (cdr _%log12957%_)
                             (let ()
                               (declare (not safe))
                               (##unchecked-structure-ref
                                _%materialization12972%_
                                '2
                                '#f
                                '#f)))
                        (eq? _%rows12958%_
                             (let ()
                               (declare (not safe))
                               (##unchecked-structure-ref
                                _%materialization12972%_
                                '3
                                '#f
                                '#f)))
                        '#f)
                    '#f))
              '#f))))
    (define gerbil-ascent/program/source-snapshot#gerbil-ascent-source-log-snapshot-equal?
      (lambda (_%snapshot12938%_
               _%candidate12939%_
               _%index12940%_
               _%log12941%_
               _%rows12942%_)
        (let ((_%snapshot12945%_ _%snapshot12938%_))
          (gerbil-ascent/program/source-snapshot#__gerbil-ascent-source-log-snapshot-equal?
           _%snapshot12945%_
           _%candidate12939%_
           _%index12940%_
           _%log12941%_
           _%rows12942%_))))
    (define gerbil-ascent/program/source-snapshot#__gerbil-ascent-source-snapshot-scalar?
      (lambda (_%snapshot12911%_
               _%candidate12912%_
               _%index12913%_
               _%rows12914%_)
        (let ((_%snapshot12917%_ _%snapshot12911%_))
          (if (eq? _%candidate12912%_
                   (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref _%snapshot12917%_ '2 '#f '#f)))
              (let* ((_%materialization12926%_
                      (vector-ref
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%snapshot12917%_
                          '5
                          '#f
                          '#f))
                       _%index12913%_))
                     (_%materialization12928%_ _%materialization12926%_))
                (if (eq? _%rows12914%_
                         (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%materialization12928%_
                            '3
                            '#f
                            '#f)))
                    (force (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%materialization12928%_
                              '4
                              '#f
                              '#f)))
                    '#f))
              '#f))))
    (define gerbil-ascent/program/source-snapshot#gerbil-ascent-source-snapshot-scalar?
      (lambda (_%snapshot12896%_
               _%candidate12897%_
               _%index12898%_
               _%rows12899%_)
        (let ((_%snapshot12902%_ _%snapshot12896%_))
          (gerbil-ascent/program/source-snapshot#__gerbil-ascent-source-snapshot-scalar?
           _%snapshot12902%_
           _%candidate12897%_
           _%index12898%_
           _%rows12899%_))))
    (define gerbil-ascent/program/source-snapshot#gerbil-ascent-source-snapshot
      (lambda (_%program12886%_)
        (let* ((_%declarations12888%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%program12886%_ 'relations)))
               (_%rows12892%_
                (list->vector
                 (map (lambda (_%relation12890%_)
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref _%relation12890%_ 'rows)))
                      _%declarations12888%_)))
               (__tmp36513
                (vector-map
                 (lambda (_%base12894%_)
                   (gerbil-ascent/program/source-snapshot#capture-source-materialization
                    _%base12894%_
                    '()
                    _%base12894%_))
                 _%rows12892%_)))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/source-snapshot#source-snapshot::t
           _%program12886%_
           _%program12886%_
           _%declarations12888%_
           _%rows12892%_
           __tmp36513))))
    (define gerbil-ascent/program/source-snapshot#gerbil-ascent-prepare-source-snapshot
      (lambda (_%snapshot12881%_ _%rows12882%_)
        (gerbil-ascent/program/source-snapshot#prepare-source-snapshot
         _%snapshot12881%_
         _%rows12882%_
         (vector-map
          (lambda (_%base12884%_)
            (gerbil-ascent/program/source-snapshot#capture-source-materialization
             _%base12884%_
             '()
             _%base12884%_))
          _%rows12882%_)
         '#f)))
    (define gerbil-ascent/program/source-snapshot#__gerbil-ascent-prepare-source-log-snapshot
      (lambda (_%snapshot12524%_ _%logs12525%_)
        (let ((_%snapshot12528%_ _%snapshot12524%_))
          (if (= (vector-length _%logs12525%_)
                 (vector-length
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%snapshot12528%_ '4 '#f '#f))))
              '#!void
              (let ()
                (declare (not safe))
                (error '"invalid ASCENT source snapshot width")))
          (let ((_%rows12537%_
                 (let ((__tmp36514 (vector-length _%logs12525%_)))
                   (declare (not safe))
                   (##make-vector __tmp36514)))
                (_%materializations12538%_
                 (let ((__tmp36515 (vector-length _%logs12525%_)))
                   (declare (not safe))
                   (##make-vector __tmp36515)))
                (_%changed?12539%_ '#f))
            (let ((_%$start12541%_ '0)
                  (_%$end12543%_ (vector-length _%logs12525%_)))
              (if (> _%$start12541%_ _%$end12543%_)
                  (let ((_%$start12546%_ '0)
                        (_%$end12548%_ (vector-length _%logs12525%_))
                        (_%$step12550%_ '-1))
                    (if (> _%$step12550%_ '0)
                        (let _%loop12554%_ ((_%k12557%_ _%$start12546%_))
                          (if (< _%k12557%_ _%$end12548%_)
                              (begin
                                (let* ((_%$%g1256212569%_
                                        (vector-ref _%logs12525%_ _%k12557%_))
                                       (_%$%E1256412573%_
                                        (lambda ()
                                          (let ()
                                            (declare (not safe))
                                            (error '"No clause matching"
                                                   _%$%g1256212569%_
                                                   '([base . additions])))
                                          '#!void))
                                       (_%$%K1256512626%_
                                        (lambda (_%additions12576%_
                                                 _%base12577%_)
                                          (let* ((_%previous12579%_
                                                  (vector-ref
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%snapshot12528%_
                                                      '5
                                                      '#f
                                                      '#f))
                                                   _%k12557%_))
                                                 (_%next12617%_
                                                  (let* ((_%base12581%_
                                                          _%base12577%_)
                                                         (_%additions12584%_
                                                          _%additions12576%_)
                                                         (_%previous12587%_
                                                          _%previous12579%_)
                                                         (_%previous12591%_
                                                          _%previous12587%_))
                                                    (gerbil-ascent/program/source-snapshot#__materialize-source-log
                                                     _%base12581%_
                                                     _%additions12584%_
                                                     _%previous12591%_)))
                                                 (_%next12619%_ _%next12617%_))
                                            (if (eq? _%next12619%_
                                                     _%previous12579%_)
                                                '#!void
                                                (set! _%changed?12539%_ '#t))
                                            (vector-set!
                                             _%materializations12538%_
                                             _%k12557%_
                                             _%next12619%_)
                                            (vector-set!
                                             _%rows12537%_
                                             _%k12557%_
                                             (let ()
                                               (declare (not safe))
                                               (##unchecked-structure-ref
                                                _%next12619%_
                                                '3
                                                '#f
                                                '#f)))))))
                                  (if (pair? _%$%g1256212569%_)
                                      (let ((_%$%hd1256612629%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%g1256212569%_)))
                                            (_%$%tl1256712631%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%g1256212569%_))))
                                        (let* ((_%base12634%_
                                                _%$%hd1256612629%_)
                                               (_%additions12636%_
                                                _%$%tl1256712631%_))
                                          (_%$%K1256512626%_
                                           _%additions12636%_
                                           _%base12634%_)))
                                      (_%$%E1256412573%_)))
                                (_%loop12554%_ (+ _%k12557%_ _%$step12550%_)))
                              '#!void))
                        (if (< _%$step12550%_ '0)
                            (let _%loop12639%_ ((_%k12641%_ _%$start12546%_))
                              (if (> _%k12641%_ _%$end12548%_)
                                  (begin
                                    (let* ((_%$%g1264512652%_
                                            (vector-ref
                                             _%logs12525%_
                                             _%k12641%_))
                                           (_%$%E1264712656%_
                                            (lambda ()
                                              (let ()
                                                (declare (not safe))
                                                (error '"No clause matching"
                                                       _%$%g1264512652%_
                                                       '([base . additions])))
                                              '#!void))
                                           (_%$%K1264812703%_
                                            (lambda (_%additions12659%_
                                                     _%base12660%_)
                                              (let* ((_%previous12662%_
                                                      (vector-ref
                                                       (let ()
                                                         (declare (not safe))
                                                         (##unchecked-structure-ref
                                                          _%snapshot12528%_
                                                          '5
                                                          '#f
                                                          '#f))
                                                       _%k12641%_))
                                                     (_%next12694%_
                                                      (let* ((_%base12664%_
                                                              _%base12660%_)
                                                             (_%additions12667%_
                                                              _%additions12659%_)
                                                             (_%previous12670%_
                                                              _%previous12662%_)
                                                             (_%previous12674%_
                                                              _%previous12670%_))
                                                        (gerbil-ascent/program/source-snapshot#__materialize-source-log
                                                         _%base12664%_
                                                         _%additions12667%_
                                                         _%previous12674%_)))
                                                     (_%next12696%_
                                                      _%next12694%_))
                                                (if (eq? _%next12696%_
                                                         _%previous12662%_)
                                                    '#!void
                                                    (set! _%changed?12539%_
                                                          '#t))
                                                (vector-set!
                                                 _%materializations12538%_
                                                 _%k12641%_
                                                 _%next12696%_)
                                                (vector-set!
                                                 _%rows12537%_
                                                 _%k12641%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%next12696%_
                                                    '3
                                                    '#f
                                                    '#f)))))))
                                      (if (pair? _%$%g1264512652%_)
                                          (let ((_%$%hd1264912706%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%g1264512652%_)))
                                                (_%$%tl1265012708%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%g1264512652%_))))
                                            (let* ((_%base12711%_
                                                    _%$%hd1264912706%_)
                                                   (_%additions12713%_
                                                    _%$%tl1265012708%_))
                                              (_%$%K1264812703%_
                                               _%additions12713%_
                                               _%base12711%_)))
                                          (_%$%E1264712656%_)))
                                    (_%loop12639%_
                                     (+ _%k12641%_ _%$step12550%_)))
                                  '#!void))
                            (let ()
                              (raise-contract-violation-error
                               '"contract violation"
                               'context:
                               'gerbil-ascent/program/source-snapshot
                               'contract:
                               '(not (zero? -1))
                               'value:
                               _%$step12550%_)
                              '#!void))))
                  (let ((_%$start12716%_ '0)
                        (_%$end12718%_ (vector-length _%logs12525%_))
                        (_%$step12720%_ '1))
                    (if (> _%$step12720%_ '0)
                        (let _%loop12724%_ ((_%k12727%_ _%$start12716%_))
                          (if (< _%k12727%_ _%$end12718%_)
                              (begin
                                (let* ((_%$%g1273212739%_
                                        (vector-ref _%logs12525%_ _%k12727%_))
                                       (_%$%E1273412743%_
                                        (lambda ()
                                          (let ()
                                            (declare (not safe))
                                            (error '"No clause matching"
                                                   _%$%g1273212739%_
                                                   '([base . additions])))
                                          '#!void))
                                       (_%$%K1273512791%_
                                        (lambda (_%additions12746%_
                                                 _%base12747%_)
                                          (let* ((_%previous12749%_
                                                  (vector-ref
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%snapshot12528%_
                                                      '5
                                                      '#f
                                                      '#f))
                                                   _%k12727%_))
                                                 (_%next12782%_
                                                  (let* ((_%base12751%_
                                                          _%base12747%_)
                                                         (_%additions12754%_
                                                          _%additions12746%_)
                                                         (_%previous12757%_
                                                          _%previous12749%_)
                                                         (_%previous12761%_
                                                          _%previous12757%_))
                                                    (gerbil-ascent/program/source-snapshot#__materialize-source-log
                                                     _%base12751%_
                                                     _%additions12754%_
                                                     _%previous12761%_)))
                                                 (_%next12784%_ _%next12782%_))
                                            (if (eq? _%next12784%_
                                                     _%previous12749%_)
                                                '#!void
                                                (set! _%changed?12539%_ '#t))
                                            (vector-set!
                                             _%materializations12538%_
                                             _%k12727%_
                                             _%next12784%_)
                                            (vector-set!
                                             _%rows12537%_
                                             _%k12727%_
                                             (let ()
                                               (declare (not safe))
                                               (##unchecked-structure-ref
                                                _%next12784%_
                                                '3
                                                '#f
                                                '#f)))))))
                                  (if (pair? _%$%g1273212739%_)
                                      (let ((_%$%hd1273612794%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%g1273212739%_)))
                                            (_%$%tl1273712796%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%g1273212739%_))))
                                        (let* ((_%base12799%_
                                                _%$%hd1273612794%_)
                                               (_%additions12801%_
                                                _%$%tl1273712796%_))
                                          (_%$%K1273512791%_
                                           _%additions12801%_
                                           _%base12799%_)))
                                      (_%$%E1273412743%_)))
                                (_%loop12724%_ (+ _%k12727%_ _%$step12720%_)))
                              '#!void))
                        (if (< _%$step12720%_ '0)
                            (let _%loop12804%_ ((_%k12806%_ _%$start12716%_))
                              (if (> _%k12806%_ _%$end12718%_)
                                  (begin
                                    (let* ((_%$%g1281012817%_
                                            (vector-ref
                                             _%logs12525%_
                                             _%k12806%_))
                                           (_%$%E1281212821%_
                                            (lambda ()
                                              (let ()
                                                (declare (not safe))
                                                (error '"No clause matching"
                                                       _%$%g1281012817%_
                                                       '([base . additions])))
                                              '#!void))
                                           (_%$%K1281312868%_
                                            (lambda (_%additions12824%_
                                                     _%base12825%_)
                                              (let* ((_%previous12827%_
                                                      (vector-ref
                                                       (let ()
                                                         (declare (not safe))
                                                         (##unchecked-structure-ref
                                                          _%snapshot12528%_
                                                          '5
                                                          '#f
                                                          '#f))
                                                       _%k12806%_))
                                                     (_%next12859%_
                                                      (let* ((_%base12829%_
                                                              _%base12825%_)
                                                             (_%additions12832%_
                                                              _%additions12824%_)
                                                             (_%previous12835%_
                                                              _%previous12827%_)
                                                             (_%previous12839%_
                                                              _%previous12835%_))
                                                        (gerbil-ascent/program/source-snapshot#__materialize-source-log
                                                         _%base12829%_
                                                         _%additions12832%_
                                                         _%previous12839%_)))
                                                     (_%next12861%_
                                                      _%next12859%_))
                                                (if (eq? _%next12861%_
                                                         _%previous12827%_)
                                                    '#!void
                                                    (set! _%changed?12539%_
                                                          '#t))
                                                (vector-set!
                                                 _%materializations12538%_
                                                 _%k12806%_
                                                 _%next12861%_)
                                                (vector-set!
                                                 _%rows12537%_
                                                 _%k12806%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%next12861%_
                                                    '3
                                                    '#f
                                                    '#f)))))))
                                      (if (pair? _%$%g1281012817%_)
                                          (let ((_%$%hd1281412871%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%g1281012817%_)))
                                                (_%$%tl1281512873%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%g1281012817%_))))
                                            (let* ((_%base12876%_
                                                    _%$%hd1281412871%_)
                                                   (_%additions12878%_
                                                    _%$%tl1281512873%_))
                                              (_%$%K1281312868%_
                                               _%additions12878%_
                                               _%base12876%_)))
                                          (_%$%E1281212821%_)))
                                    (_%loop12804%_
                                     (+ _%k12806%_ _%$step12720%_)))
                                  '#!void))
                            (let ()
                              (raise-contract-violation-error
                               '"contract violation"
                               'context:
                               'gerbil-ascent/program/source-snapshot
                               'contract:
                               '(not (zero? 1))
                               'value:
                               _%$step12720%_)
                              '#!void))))))
            (if _%changed?12539%_
                (gerbil-ascent/program/source-snapshot#prepare-source-snapshot
                 _%snapshot12528%_
                 _%rows12537%_
                 _%materializations12538%_
                 '#t)
                _%snapshot12528%_)))))
    (define gerbil-ascent/program/source-snapshot#gerbil-ascent-prepare-source-log-snapshot
      (lambda (_%snapshot12511%_ _%logs12512%_)
        (let ((_%snapshot12515%_ _%snapshot12511%_))
          (gerbil-ascent/program/source-snapshot#__gerbil-ascent-prepare-source-log-snapshot
           _%snapshot12515%_
           _%logs12512%_))))
    (define gerbil-ascent/program/source-snapshot#prepare-source-snapshot
      (lambda (_%snapshot12408%_
               _%rows12409%_
               _%materializations12410%_
               _%roots-changed?12411%_)
        (let* ((_%$%snapshot1241212422%_ _%snapshot12408%_)
               (_%$%E1241412425%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%snapshot1241212422%_
                           '((source-snapshot
                              template
                              program
                              declarations
                              previous
                              _))))
                  '#!void))
               (_%$%K1241512485%_
                (lambda (_%previous12428%_
                         _%declarations12429%_
                         _%program12430%_
                         _%template12431%_)
                  (if (= (vector-length _%rows12409%_)
                         (vector-length _%previous12428%_))
                      '#!void
                      (let ()
                        (declare (not safe))
                        (error '"invalid ASCENT source snapshot width")))
                  (let* ((_%changed?12433%_ '#f)
                         (_%next12464%_
                          (map (lambda (_%prototype12435%_
                                        _%declaration12436%_
                                        _%index12437%_)
                                 (let ((_%replacement12439%_
                                        (vector-ref
                                         _%rows12409%_
                                         _%index12437%_)))
                                   (if (eq? _%replacement12439%_
                                            (vector-ref
                                             _%previous12428%_
                                             _%index12437%_))
                                       _%declaration12436%_
                                       (begin
                                         (set! _%changed?12433%_ '#t)
                                         (let ((__obj36504
                                                (let ()
                                                  (declare (not safe))
                                                  (##structure
                                                   clan/poo/object#object::t
                                                   '#f
                                                   '#f
                                                   '#f
                                                   '#f
                                                   '#f
                                                   '#f
                                                   '#f))))
                                           (let ((__tmp36517
                                                  (list (cons 'rows
                                                              (let ((__tmp36518
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (lambda (_%@12458%_) _%replacement12439%_)))
                        (declare (not safe))
                        (##structure
                         clan/poo/object#$self-slot-spec::t
                         __tmp36518)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (__tmp36516 (list)))
                                             (declare (not safe))
                                             (clan/poo/object#object:::init!__%
                                              '#f
                                              _%prototype12435%_
                                              __tmp36517
                                              __tmp36516
                                              __obj36504))
                                           __obj36504)))))
                               (let ()
                                 (declare (not safe))
                                 (clan/poo/object#.ref
                                  _%template12431%_
                                  'relations))
                               _%declarations12429%_
                               (let ((__tmp36519
                                      (vector-length _%rows12409%_)))
                                 (declare (not safe))
                                 (##iota __tmp36519)))))
                    (if _%changed?12433%_
                        (let ((__tmp36520
                               (let ((__obj36505
                                      (let ()
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#object::t
                                         '#f
                                         '#f
                                         '#f
                                         '#f
                                         '#f
                                         '#f
                                         '#f))))
                                 (let ((__tmp36522
                                        (list (cons 'relations
                                                    (let ((__tmp36523
                                                           (lambda (_%@12479%_)
                                                             _%next12464%_)))
                                                      (declare (not safe))
                                                      (##structure
                                                       clan/poo/object#$self-slot-spec::t
                                                       __tmp36523)))))
                                       (__tmp36521 (list)))
                                   (declare (not safe))
                                   (clan/poo/object#object:::init!__%
                                    '#f
                                    _%template12431%_
                                    __tmp36522
                                    __tmp36521
                                    __obj36505))
                                 __obj36505)))
                          (declare (not safe))
                          (##structure
                           gerbil-ascent/program/source-snapshot#source-snapshot::t
                           _%template12431%_
                           __tmp36520
                           _%next12464%_
                           _%rows12409%_
                           _%materializations12410%_))
                        (if _%roots-changed?12411%_
                            (let ()
                              (declare (not safe))
                              (##structure
                               gerbil-ascent/program/source-snapshot#source-snapshot::t
                               _%template12431%_
                               _%program12430%_
                               _%declarations12429%_
                               _%previous12428%_
                               _%materializations12410%_))
                            _%snapshot12408%_))))))
          (if (let ()
                (declare (not safe))
                (##structure-direct-instance-of?
                 _%$%snapshot1241212422%_
                 'gerbil-ascent/program/source-snapshot#source-snapshot::t))
              (let* ((_%$%e1241612488%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%snapshot1241212422%_
                         '1
                         '#f
                         '#f)))
                     (_%template12491%_ _%$%e1241612488%_)
                     (_%$%e1241712493%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%snapshot1241212422%_
                         '2
                         '#f
                         '#f)))
                     (_%program12496%_ _%$%e1241712493%_)
                     (_%$%e1241812498%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%snapshot1241212422%_
                         '3
                         '#f
                         '#f)))
                     (_%declarations12501%_ _%$%e1241812498%_)
                     (_%$%e1241912503%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%snapshot1241212422%_
                         '4
                         '#f
                         '#f)))
                     (_%previous12506%_ _%$%e1241912503%_)
                     (_%$%e1242012508%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%snapshot1241212422%_
                         '5
                         '#f
                         '#f))))
                (_%$%K1241512485%_
                 _%previous12506%_
                 _%declarations12501%_
                 _%program12496%_
                 _%template12491%_))
              (_%$%E1241412425%_)))))))
