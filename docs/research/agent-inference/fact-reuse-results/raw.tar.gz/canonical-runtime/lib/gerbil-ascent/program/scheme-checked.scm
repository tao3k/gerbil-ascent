(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/program/objects")
    (load-module "gerbil-ascent/program/aggregators")
    (load-module "clan/poo/object")
    (load-module "gerbil-ascent/table/provider")
    (load-module "gerbil-ascent/table/storage"))
  (load-module "gerbil-ascent/program/scheme-checked~0"))
