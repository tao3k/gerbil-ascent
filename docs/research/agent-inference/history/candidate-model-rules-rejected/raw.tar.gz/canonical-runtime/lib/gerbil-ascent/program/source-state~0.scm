(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/source-state::timestamp 1791687885)
  (begin
    (define gerbil-ascent/program/source-state#source-state::t
      (let ((__tmp36804 (list))
            (__tmp36803
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/source-state#source-state::t
         'source-state
         __tmp36804
         '(originals additions overrides snapshot)
         __tmp36803
         '#f)))
    (define gerbil-ascent/program/source-state#source-state?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/source-state#source-state::t)))
    (define gerbil-ascent/program/source-state#make-source-state
      (lambda _%$args17467%_
        (apply make-instance
               gerbil-ascent/program/source-state#source-state::t
               _%$args17467%_)))
    (define gerbil-ascent/program/source-state#source-state-originals
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-state#source-state::t
         'originals)))
    (define gerbil-ascent/program/source-state#source-state-additions
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-state#source-state::t
         'additions)))
    (define gerbil-ascent/program/source-state#source-state-overrides
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-state#source-state::t
         'overrides)))
    (define gerbil-ascent/program/source-state#source-state-snapshot
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-state#source-state::t
         'snapshot)))
    (define gerbil-ascent/program/source-state#source-state-originals-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-state#source-state::t
         'originals)))
    (define gerbil-ascent/program/source-state#source-state-additions-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-state#source-state::t
         'additions)))
    (define gerbil-ascent/program/source-state#source-state-overrides-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-state#source-state::t
         'overrides)))
    (define gerbil-ascent/program/source-state#source-state-snapshot-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-state#source-state::t
         'snapshot)))
    (define gerbil-ascent/program/source-state#&source-state-originals
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-state#source-state::t
         'originals)))
    (define gerbil-ascent/program/source-state#&source-state-additions
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-state#source-state::t
         'additions)))
    (define gerbil-ascent/program/source-state#&source-state-overrides
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-state#source-state::t
         'overrides)))
    (define gerbil-ascent/program/source-state#&source-state-snapshot
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-state#source-state::t
         'snapshot)))
    (define gerbil-ascent/program/source-state#&source-state-originals-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-state#source-state::t
         'originals)))
    (define gerbil-ascent/program/source-state#&source-state-additions-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-state#source-state::t
         'additions)))
    (define gerbil-ascent/program/source-state#&source-state-overrides-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-state#source-state::t
         'overrides)))
    (define gerbil-ascent/program/source-state#&source-state-snapshot-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-state#source-state::t
         'snapshot)))
    (define gerbil-ascent/program/source-state#gerbil-ascent-source-state
      (lambda (_%program17457%_ _%relations17458%_)
        (let* ((_%originals17462%_
                (list->vector
                 (map (lambda (_%relation17460%_)
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref _%relation17460%_ 'rows)))
                      _%relations17458%_)))
               (_%count17464%_
                (let ()
                  (declare (not safe))
                  (##vector-length _%originals17462%_))))
          (let ((__tmp36807
                 (let ()
                   (declare (not safe))
                   (##make-vector _%count17464%_ '())))
                (__tmp36806
                 (let ()
                   (declare (not safe))
                   (##make-vector _%count17464%_ '#f)))
                (__tmp36805
                 (let ()
                   (declare (not safe))
                   (gerbil-ascent/program/source-snapshot#gerbil-ascent-source-snapshot
                    _%program17457%_))))
            (declare (not safe))
            (##structure
             gerbil-ascent/program/source-state#source-state::t
             _%originals17462%_
             __tmp36807
             __tmp36806
             __tmp36805)))))
    (define gerbil-ascent/program/source-state#__gerbil-ascent-source-state-rows
      (lambda (_%state17441%_ _%index17442%_)
        (let* ((_%state17445%_ _%state17441%_)
               (_%$e17454%_
                (vector-ref
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%state17445%_ '3 '#f '#f))
                 _%index17442%_)))
          (if _%$e17454%_
              _%$e17454%_
              (let ((__tmp36809
                     (vector-ref
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref _%state17445%_ '1 '#f '#f))
                      _%index17442%_))
                    (__tmp36808
                     (vector-ref
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref _%state17445%_ '2 '#f '#f))
                      _%index17442%_)))
                (declare (not safe))
                (gerbil-ascent/program/source-log#gerbil-ascent-source-log-rows
                 __tmp36809
                 __tmp36808))))))
    (define gerbil-ascent/program/source-state#gerbil-ascent-source-state-rows
      (lambda (_%state17428%_ _%index17429%_)
        (let ((_%state17432%_ _%state17428%_))
          (gerbil-ascent/program/source-state#__gerbil-ascent-source-state-rows
           _%state17432%_
           _%index17429%_))))
    (define gerbil-ascent/program/source-state#__gerbil-ascent-prepare-source-replacement
      (lambda (_%state17298%_ _%index17299%_ _%rows17300%_)
        (let* ((_%state17303%_ _%state17298%_)
               (_%logs17312%_
                (let ((__tmp36810
                       (vector-length
                        (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%state17303%_
                           '1
                           '#f
                           '#f)))))
                  (declare (not safe))
                  (##make-vector __tmp36810))))
          (let ((_%$start17314%_ '0)
                (_%$end17316%_
                 (let ()
                   (declare (not safe))
                   (##vector-length _%logs17312%_))))
            (if (> _%$start17314%_ _%$end17316%_)
                (let ((_%$start17319%_ '0)
                      (_%$end17321%_
                       (let ()
                         (declare (not safe))
                         (##vector-length _%logs17312%_)))
                      (_%$step17323%_ '-1))
                  (if (> _%$step17323%_ '0)
                      (let _%loop17327%_ ((_%k17330%_ _%$start17319%_))
                        (if (< _%k17330%_ _%$end17321%_)
                            (begin
                              (vector-set!
                               _%logs17312%_
                               _%k17330%_
                               (if (= _%k17330%_ _%index17299%_)
                                   (cons _%rows17300%_ '())
                                   (let ((_%$e17337%_
                                          (vector-ref
                                           (let ()
                                             (declare (not safe))
                                             (##unchecked-structure-ref
                                              _%state17303%_
                                              '3
                                              '#f
                                              '#f))
                                           _%k17330%_)))
                                     (if _%$e17337%_
                                         (cons _%$e17337%_ '())
                                         (cons (vector-ref
                                                (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%state17303%_
                                                   '1
                                                   '#f
                                                   '#f))
                                                _%k17330%_)
                                               (vector-ref
                                                (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%state17303%_
                                                   '2
                                                   '#f
                                                   '#f))
                                                _%k17330%_))))))
                              (_%loop17327%_ (+ _%k17330%_ _%$step17323%_)))
                            '#!void))
                      (if (< _%$step17323%_ '0)
                          (let _%loop17346%_ ((_%k17348%_ _%$start17319%_))
                            (if (> _%k17348%_ _%$end17321%_)
                                (begin
                                  (vector-set!
                                   _%logs17312%_
                                   _%k17348%_
                                   (if (= _%k17348%_ _%index17299%_)
                                       (cons _%rows17300%_ '())
                                       (let ((_%$e17354%_
                                              (vector-ref
                                               (let ()
                                                 (declare (not safe))
                                                 (##unchecked-structure-ref
                                                  _%state17303%_
                                                  '3
                                                  '#f
                                                  '#f))
                                               _%k17348%_)))
                                         (if _%$e17354%_
                                             (cons _%$e17354%_ '())
                                             (cons (vector-ref
                                                    (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%state17303%_
                                                       '1
                                                       '#f
                                                       '#f))
                                                    _%k17348%_)
                                                   (vector-ref
                                                    (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%state17303%_
                                                       '2
                                                       '#f
                                                       '#f))
                                                    _%k17348%_))))))
                                  (_%loop17346%_
                                   (+ _%k17348%_ _%$step17323%_)))
                                '#!void))
                          (let ()
                            (raise-contract-violation-error
                             '"contract violation"
                             'context:
                             'gerbil-ascent/program/source-state
                             'contract:
                             '(not (zero? -1))
                             'value:
                             _%$step17323%_)
                            '#!void))))
                (let ((_%$start17363%_ '0)
                      (_%$end17365%_
                       (let ()
                         (declare (not safe))
                         (##vector-length _%logs17312%_)))
                      (_%$step17367%_ '1))
                  (if (> _%$step17367%_ '0)
                      (let _%loop17371%_ ((_%k17374%_ _%$start17363%_))
                        (if (< _%k17374%_ _%$end17365%_)
                            (begin
                              (vector-set!
                               _%logs17312%_
                               _%k17374%_
                               (if (= _%k17374%_ _%index17299%_)
                                   (cons _%rows17300%_ '())
                                   (let ((_%$e17381%_
                                          (vector-ref
                                           (let ()
                                             (declare (not safe))
                                             (##unchecked-structure-ref
                                              _%state17303%_
                                              '3
                                              '#f
                                              '#f))
                                           _%k17374%_)))
                                     (if _%$e17381%_
                                         (cons _%$e17381%_ '())
                                         (cons (vector-ref
                                                (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%state17303%_
                                                   '1
                                                   '#f
                                                   '#f))
                                                _%k17374%_)
                                               (vector-ref
                                                (let ()
                                                  (declare (not safe))
                                                  (##unchecked-structure-ref
                                                   _%state17303%_
                                                   '2
                                                   '#f
                                                   '#f))
                                                _%k17374%_))))))
                              (_%loop17371%_ (+ _%k17374%_ _%$step17367%_)))
                            '#!void))
                      (if (< _%$step17367%_ '0)
                          (let _%loop17390%_ ((_%k17392%_ _%$start17363%_))
                            (if (> _%k17392%_ _%$end17365%_)
                                (begin
                                  (vector-set!
                                   _%logs17312%_
                                   _%k17392%_
                                   (if (= _%k17392%_ _%index17299%_)
                                       (cons _%rows17300%_ '())
                                       (let ((_%$e17398%_
                                              (vector-ref
                                               (let ()
                                                 (declare (not safe))
                                                 (##unchecked-structure-ref
                                                  _%state17303%_
                                                  '3
                                                  '#f
                                                  '#f))
                                               _%k17392%_)))
                                         (if _%$e17398%_
                                             (cons _%$e17398%_ '())
                                             (cons (vector-ref
                                                    (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%state17303%_
                                                       '1
                                                       '#f
                                                       '#f))
                                                    _%k17392%_)
                                                   (vector-ref
                                                    (let ()
                                                      (declare (not safe))
                                                      (##unchecked-structure-ref
                                                       _%state17303%_
                                                       '2
                                                       '#f
                                                       '#f))
                                                    _%k17392%_))))))
                                  (_%loop17390%_
                                   (+ _%k17392%_ _%$step17367%_)))
                                '#!void))
                          (let ()
                            (raise-contract-violation-error
                             '"contract violation"
                             'context:
                             'gerbil-ascent/program/source-state
                             'contract:
                             '(not (zero? 1))
                             'value:
                             _%$step17367%_)
                            '#!void))))))
          (let* ((_%snapshot17407%_
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%state17303%_ '4 '#f '#f)))
                 (_%logs17410%_ _%logs17312%_)
                 (_%snapshot17414%_ _%snapshot17407%_))
            (declare (not safe))
            (gerbil-ascent/program/source-snapshot#__gerbil-ascent-prepare-source-log-snapshot
             _%snapshot17414%_
             _%logs17410%_)))))
    (define gerbil-ascent/program/source-state#gerbil-ascent-prepare-source-replacement
      (lambda (_%state17284%_ _%index17285%_ _%rows17286%_)
        (let ((_%state17289%_ _%state17284%_))
          (gerbil-ascent/program/source-state#__gerbil-ascent-prepare-source-replacement
           _%state17289%_
           _%index17285%_
           _%rows17286%_))))
    (define gerbil-ascent/program/source-state#__gerbil-ascent-commit-source-replacement!
      (lambda (_%state17269%_ _%index17270%_ _%rows17271%_ _%cut17272%_)
        (let ((_%state17275%_ _%state17269%_))
          (let ()
            (declare (not safe))
            (##unchecked-structure-set!
             _%state17275%_
             _%cut17272%_
             '4
             '#f
             '#f))
          (vector-set!
           (let ()
             (declare (not safe))
             (##unchecked-structure-ref _%state17275%_ '3 '#f '#f))
           _%index17270%_
           _%rows17271%_)
          (vector-set!
           (let ()
             (declare (not safe))
             (##unchecked-structure-ref _%state17275%_ '2 '#f '#f))
           _%index17270%_
           '()))))
    (define gerbil-ascent/program/source-state#gerbil-ascent-commit-source-replacement!
      (lambda (_%state17254%_ _%index17255%_ _%rows17256%_ _%cut17257%_)
        (let ((_%state17260%_ _%state17254%_))
          (gerbil-ascent/program/source-state#__gerbil-ascent-commit-source-replacement!
           _%state17260%_
           _%index17255%_
           _%rows17256%_
           _%cut17257%_))))))
