(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/core/relation-view::timestamp 1791687540)
  (begin
    (define gerbil-ascent/core/relation-view#relation-view::t
      (let ((__tmp3697 (list)) (__tmp3696 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/core/relation-view#relation-view::t
         'relation-view
         __tmp3697
         '(identity
           generation
           revision
           lane
           count
           units
           visit
           contains
           export
           parts)
         __tmp3696
         '#f)))
    (define gerbil-ascent/core/relation-view#relation-view?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/core/relation-view#relation-view::t)))
    (define gerbil-ascent/core/relation-view#make-relation-view
      (lambda _%$args846%_
        (apply make-instance
               gerbil-ascent/core/relation-view#relation-view::t
               _%$args846%_)))
    (define gerbil-ascent/core/relation-view#relation-view-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'identity)))
    (define gerbil-ascent/core/relation-view#relation-view-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'generation)))
    (define gerbil-ascent/core/relation-view#relation-view-revision
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'revision)))
    (define gerbil-ascent/core/relation-view#relation-view-lane
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'lane)))
    (define gerbil-ascent/core/relation-view#relation-view-count
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'count)))
    (define gerbil-ascent/core/relation-view#relation-view-units
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'units)))
    (define gerbil-ascent/core/relation-view#relation-view-visit
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'visit)))
    (define gerbil-ascent/core/relation-view#relation-view-contains
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'contains)))
    (define gerbil-ascent/core/relation-view#relation-view-export
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'export)))
    (define gerbil-ascent/core/relation-view#relation-view-parts
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'parts)))
    (define gerbil-ascent/core/relation-view#relation-view-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'identity)))
    (define gerbil-ascent/core/relation-view#relation-view-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'generation)))
    (define gerbil-ascent/core/relation-view#relation-view-revision-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'revision)))
    (define gerbil-ascent/core/relation-view#relation-view-lane-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'lane)))
    (define gerbil-ascent/core/relation-view#relation-view-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'count)))
    (define gerbil-ascent/core/relation-view#relation-view-units-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'units)))
    (define gerbil-ascent/core/relation-view#relation-view-visit-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'visit)))
    (define gerbil-ascent/core/relation-view#relation-view-contains-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'contains)))
    (define gerbil-ascent/core/relation-view#relation-view-export-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'export)))
    (define gerbil-ascent/core/relation-view#relation-view-parts-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'parts)))
    (define gerbil-ascent/core/relation-view#&relation-view-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'identity)))
    (define gerbil-ascent/core/relation-view#&relation-view-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'generation)))
    (define gerbil-ascent/core/relation-view#&relation-view-revision
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'revision)))
    (define gerbil-ascent/core/relation-view#&relation-view-lane
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'lane)))
    (define gerbil-ascent/core/relation-view#&relation-view-count
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'count)))
    (define gerbil-ascent/core/relation-view#&relation-view-units
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'units)))
    (define gerbil-ascent/core/relation-view#&relation-view-visit
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'visit)))
    (define gerbil-ascent/core/relation-view#&relation-view-contains
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'contains)))
    (define gerbil-ascent/core/relation-view#&relation-view-export
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'export)))
    (define gerbil-ascent/core/relation-view#&relation-view-parts
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#relation-view::t
         'parts)))
    (define gerbil-ascent/core/relation-view#&relation-view-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'identity)))
    (define gerbil-ascent/core/relation-view#&relation-view-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'generation)))
    (define gerbil-ascent/core/relation-view#&relation-view-revision-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'revision)))
    (define gerbil-ascent/core/relation-view#&relation-view-lane-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'lane)))
    (define gerbil-ascent/core/relation-view#&relation-view-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'count)))
    (define gerbil-ascent/core/relation-view#&relation-view-units-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'units)))
    (define gerbil-ascent/core/relation-view#&relation-view-visit-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'visit)))
    (define gerbil-ascent/core/relation-view#&relation-view-contains-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'contains)))
    (define gerbil-ascent/core/relation-view#&relation-view-export-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'export)))
    (define gerbil-ascent/core/relation-view#&relation-view-parts-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#relation-view::t
         'parts)))
    (define gerbil-ascent/core/relation-view#part-visitors::t
      (let ((__tmp3699 (list)) (__tmp3698 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/core/relation-view#part-visitors::t
         'part-visitors
         __tmp3699
         '(checked admitted)
         __tmp3698
         '#f)))
    (define gerbil-ascent/core/relation-view#part-visitors?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/core/relation-view#part-visitors::t)))
    (define gerbil-ascent/core/relation-view#make-part-visitors
      (lambda _%$args843%_
        (apply make-instance
               gerbil-ascent/core/relation-view#part-visitors::t
               _%$args843%_)))
    (define gerbil-ascent/core/relation-view#part-visitors-checked
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#part-visitors::t
         'checked)))
    (define gerbil-ascent/core/relation-view#part-visitors-admitted
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#part-visitors::t
         'admitted)))
    (define gerbil-ascent/core/relation-view#part-visitors-checked-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#part-visitors::t
         'checked)))
    (define gerbil-ascent/core/relation-view#part-visitors-admitted-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#part-visitors::t
         'admitted)))
    (define gerbil-ascent/core/relation-view#&part-visitors-checked
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#part-visitors::t
         'checked)))
    (define gerbil-ascent/core/relation-view#&part-visitors-admitted
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#part-visitors::t
         'admitted)))
    (define gerbil-ascent/core/relation-view#&part-visitors-checked-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#part-visitors::t
         'checked)))
    (define gerbil-ascent/core/relation-view#&part-visitors-admitted-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#part-visitors::t
         'admitted)))
    (define gerbil-ascent/core/relation-view#row-stream::t
      (let ((__tmp3701 (list)) (__tmp3700 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/core/relation-view#row-stream::t
         'row-stream
         __tmp3701
         '(view columns key)
         __tmp3700
         '#f)))
    (define gerbil-ascent/core/relation-view#row-stream?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/core/relation-view#row-stream::t)))
    (define gerbil-ascent/core/relation-view#make-row-stream
      (lambda _%$args840%_
        (apply make-instance
               gerbil-ascent/core/relation-view#row-stream::t
               _%$args840%_)))
    (define gerbil-ascent/core/relation-view#row-stream-view
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#row-stream::t
         'view)))
    (define gerbil-ascent/core/relation-view#row-stream-columns
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#row-stream::t
         'columns)))
    (define gerbil-ascent/core/relation-view#row-stream-key
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#row-stream::t
         'key)))
    (define gerbil-ascent/core/relation-view#row-stream-view-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#row-stream::t
         'view)))
    (define gerbil-ascent/core/relation-view#row-stream-columns-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#row-stream::t
         'columns)))
    (define gerbil-ascent/core/relation-view#row-stream-key-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#row-stream::t
         'key)))
    (define gerbil-ascent/core/relation-view#&row-stream-view
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#row-stream::t
         'view)))
    (define gerbil-ascent/core/relation-view#&row-stream-columns
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#row-stream::t
         'columns)))
    (define gerbil-ascent/core/relation-view#&row-stream-key
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#row-stream::t
         'key)))
    (define gerbil-ascent/core/relation-view#&row-stream-view-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#row-stream::t
         'view)))
    (define gerbil-ascent/core/relation-view#&row-stream-columns-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#row-stream::t
         'columns)))
    (define gerbil-ascent/core/relation-view#&row-stream-key-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#row-stream::t
         'key)))
    (define gerbil-ascent/core/relation-view#rectangle::t
      (let ((__tmp3703 (list)) (__tmp3702 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/core/relation-view#rectangle::t
         'rectangle
         __tmp3703
         '(prefix left right)
         __tmp3702
         '#f)))
    (define gerbil-ascent/core/relation-view#rectangle?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/core/relation-view#rectangle::t)))
    (define gerbil-ascent/core/relation-view#make-rectangle
      (lambda _%$args837%_
        (apply make-instance
               gerbil-ascent/core/relation-view#rectangle::t
               _%$args837%_)))
    (define gerbil-ascent/core/relation-view#rectangle-prefix
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#rectangle::t
         'prefix)))
    (define gerbil-ascent/core/relation-view#rectangle-left
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#rectangle::t
         'left)))
    (define gerbil-ascent/core/relation-view#rectangle-right
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#rectangle::t
         'right)))
    (define gerbil-ascent/core/relation-view#rectangle-prefix-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#rectangle::t
         'prefix)))
    (define gerbil-ascent/core/relation-view#rectangle-left-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#rectangle::t
         'left)))
    (define gerbil-ascent/core/relation-view#rectangle-right-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#rectangle::t
         'right)))
    (define gerbil-ascent/core/relation-view#&rectangle-prefix
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#rectangle::t
         'prefix)))
    (define gerbil-ascent/core/relation-view#&rectangle-left
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#rectangle::t
         'left)))
    (define gerbil-ascent/core/relation-view#&rectangle-right
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#rectangle::t
         'right)))
    (define gerbil-ascent/core/relation-view#&rectangle-prefix-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#rectangle::t
         'prefix)))
    (define gerbil-ascent/core/relation-view#&rectangle-left-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#rectangle::t
         'left)))
    (define gerbil-ascent/core/relation-view#&rectangle-right-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#rectangle::t
         'right)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket::t
      (let ((__tmp3705 (list))
            (__tmp3704
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/core/relation-view#rectangle-bucket::t
         'rectangle-bucket
         __tmp3705
         '(members blocks count plain)
         __tmp3704
         '#f)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/core/relation-view#rectangle-bucket::t)))
    (define gerbil-ascent/core/relation-view#make-rectangle-bucket
      (lambda _%$args834%_
        (apply make-instance
               gerbil-ascent/core/relation-view#rectangle-bucket::t
               _%$args834%_)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'members)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket-blocks
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'blocks)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket-count
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'count)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket-plain
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'plain)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'members)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket-blocks-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'blocks)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'count)))
    (define gerbil-ascent/core/relation-view#rectangle-bucket-plain-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'plain)))
    (define gerbil-ascent/core/relation-view#&rectangle-bucket-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'members)))
    (define gerbil-ascent/core/relation-view#&rectangle-bucket-blocks
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'blocks)))
    (define gerbil-ascent/core/relation-view#&rectangle-bucket-count
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'count)))
    (define gerbil-ascent/core/relation-view#&rectangle-bucket-plain
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'plain)))
    (define gerbil-ascent/core/relation-view#&rectangle-bucket-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'members)))
    (define gerbil-ascent/core/relation-view#&rectangle-bucket-blocks-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'blocks)))
    (define gerbil-ascent/core/relation-view#&rectangle-bucket-count-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'count)))
    (define gerbil-ascent/core/relation-view#&rectangle-bucket-plain-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/core/relation-view#rectangle-bucket::t
         'plain)))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-view-bind
      (lambda (_%view828%_
               _%identity829%_
               _%generation830%_
               _%revision831%_
               _%lane832%_)
        (let ((__tmp3711
               (##structure-ref
                _%view828%_
                '5
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp3710
               (##structure-ref
                _%view828%_
                '6
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp3709
               (##structure-ref
                _%view828%_
                '7
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp3708
               (##structure-ref
                _%view828%_
                '8
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp3707
               (##structure-ref
                _%view828%_
                '9
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp3706
               (##structure-ref
                _%view828%_
                '10
                gerbil-ascent/core/relation-view#relation-view::t
                '#f)))
          (declare (not safe))
          (##structure
           gerbil-ascent/core/relation-view#relation-view::t
           _%identity829%_
           _%generation830%_
           _%revision831%_
           _%lane832%_
           __tmp3711
           __tmp3710
           __tmp3709
           __tmp3708
           __tmp3707
           __tmp3706))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-view-with-export
      (lambda (_%view825%_ _%export826%_)
        (let ((__tmp3720
               (##structure-ref
                _%view825%_
                '1
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp3719
               (##structure-ref
                _%view825%_
                '2
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp3718
               (##structure-ref
                _%view825%_
                '3
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp3717
               (##structure-ref
                _%view825%_
                '4
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp3716
               (##structure-ref
                _%view825%_
                '5
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp3715
               (##structure-ref
                _%view825%_
                '6
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp3714
               (##structure-ref
                _%view825%_
                '7
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp3713
               (##structure-ref
                _%view825%_
                '8
                gerbil-ascent/core/relation-view#relation-view::t
                '#f))
              (__tmp3712
               (##structure-ref
                _%view825%_
                '10
                gerbil-ascent/core/relation-view#relation-view::t
                '#f)))
          (declare (not safe))
          (##structure
           gerbil-ascent/core/relation-view#relation-view::t
           __tmp3720
           __tmp3719
           __tmp3718
           __tmp3717
           __tmp3716
           __tmp3715
           __tmp3714
           __tmp3713
           _%export826%_
           __tmp3712))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
      (lambda (_%consume819%_ _%rows820%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%rows820%_
               'gerbil-ascent/core/relation-view#relation-view::t))
            ((let ()
               (declare (not safe))
               (##unchecked-structure-ref _%rows820%_ '7 '#f '#f))
             '()
             '()
             _%consume819%_)
            (if (let ()
                  (declare (not safe))
                  (##structure-instance-of?
                   _%rows820%_
                   'gerbil-ascent/core/relation-view#row-stream::t))
                ((##structure-ref
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%rows820%_ '1 '#f '#f))
                  '7
                  gerbil-ascent/core/relation-view#relation-view::t
                  '#f)
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%rows820%_ '2 '#f '#f))
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%rows820%_ '3 '#f '#f))
                 _%consume819%_)
                (for-each _%consume819%_ _%rows820%_)))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-any-row?
      (lambda (_%predicate812%_ _%rows813%_)
        (let ((__tmp3721
               (lambda (_%done815%_)
                 (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
                  (lambda (_%row817%_)
                    (if (_%predicate812%_ _%row817%_)
                        (_%done815%_ '#t)
                        '#!void))
                  _%rows813%_)
                 '#f)))
          (declare (not safe))
          (##call-with-current-continuation __tmp3721))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-row-count
      (lambda (_%rows810%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%rows810%_
               'gerbil-ascent/core/relation-view#relation-view::t))
            (let ()
              (declare (not safe))
              (##unchecked-structure-ref _%rows810%_ '5 '#f '#f))
            (length _%rows810%_))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-view-select
      (lambda (_%view806%_ _%columns807%_ _%key808%_)
        (if (and (null? _%columns807%_) (null? _%key808%_))
            _%view806%_
            (let ()
              (declare (not safe))
              (##structure
               gerbil-ascent/core/relation-view#row-stream::t
               _%view806%_
               _%columns807%_
               _%key808%_)))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-row-parts?
      (lambda (_%rows801%_)
        (if (if (let ()
                  (declare (not safe))
                  (##structure-instance-of?
                   _%rows801%_
                   'gerbil-ascent/core/relation-view#relation-view::t))
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-ref _%rows801%_ '10 '#f '#f))
                (and (let ()
                       (declare (not safe))
                       (##structure-instance-of?
                        _%rows801%_
                        'gerbil-ascent/core/relation-view#row-stream::t))
                     (##structure-ref
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref _%rows801%_ '1 '#f '#f))
                      '10
                      gerbil-ascent/core/relation-view#relation-view::t
                      '#f)))
            '#t
            '#f)))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-admitted-row-parts?
      (lambda (_%view797%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%view797%_
               'gerbil-ascent/core/relation-view#relation-view::t))
            (let ((_%parts799%_
                   (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref _%view797%_ '10 '#f '#f))))
              (if (let ()
                    (declare (not safe))
                    (##structure-instance-of?
                     _%parts799%_
                     'gerbil-ascent/core/relation-view#part-visitors::t))
                  (if (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref _%parts799%_ '2 '#f '#f))
                      '#t
                      '#f)
                  '#f))
            '#f)))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row-parts
      (lambda (_%consume794%_ _%rows795%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%rows795%_
               'gerbil-ascent/core/relation-view#relation-view::t))
            (gerbil-ascent/core/relation-view#gerbil-ascent-visit-view-parts!
             _%rows795%_
             '()
             '()
             _%consume794%_)
            (gerbil-ascent/core/relation-view#gerbil-ascent-visit-view-parts!
             (##structure-ref
              _%rows795%_
              '1
              gerbil-ascent/core/relation-view#row-stream::t
              '#f)
             (##structure-ref
              _%rows795%_
              '2
              gerbil-ascent/core/relation-view#row-stream::t
              '#f)
             (##structure-ref
              _%rows795%_
              '3
              gerbil-ascent/core/relation-view#row-stream::t
              '#f)
             _%consume794%_))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-visit-view-parts!
      (lambda (_%view787%_ _%columns788%_ _%key789%_ _%consume790%_)
        (let ((_%parts792%_
               (##structure-ref
                _%view787%_
                '10
                gerbil-ascent/core/relation-view#relation-view::t
                '#f)))
          ((if (let ()
                 (declare (not safe))
                 (##structure-instance-of?
                  _%parts792%_
                  'gerbil-ascent/core/relation-view#part-visitors::t))
               (let ()
                 (declare (not safe))
                 (##unchecked-structure-ref _%parts792%_ '1 '#f '#f))
               _%parts792%_)
           _%columns788%_
           _%key789%_
           _%consume790%_))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-visit-admitted-view-parts!
      (lambda (_%view782%_ _%columns783%_ _%key784%_ _%consume785%_)
        (if (gerbil-ascent/core/relation-view#gerbil-ascent-admitted-row-parts?
             _%view782%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"ASCENT view lacks admitted parts")))
        ((##structure-ref
          (##structure-ref
           _%view782%_
           '10
           gerbil-ascent/core/relation-view#relation-view::t
           '#f)
          '2
          gerbil-ascent/core/relation-view#part-visitors::t
          '#f)
         _%columns783%_
         _%key784%_
         _%consume785%_)))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-view-contains?
      (lambda (_%view779%_ _%row780%_)
        ((##structure-ref
          _%view779%_
          '8
          gerbil-ascent/core/relation-view#relation-view::t
          '#f)
         _%row780%_)))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-view-rows
      (lambda (_%view773%_)
        (if (##structure-ref
             _%view773%_
             '9
             gerbil-ascent/core/relation-view#relation-view::t
             '#f)
            ((##structure-ref
              _%view773%_
              '9
              gerbil-ascent/core/relation-view#relation-view::t
              '#f))
            (let ((_%rows775%_ '()))
              (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
               (lambda (_%row777%_)
                 (set! _%rows775%_ (cons _%row777%_ _%rows775%_)))
               _%view773%_)
              (let () (declare (not safe)) (##reverse _%rows775%_))))))
    (define gerbil-ascent/core/relation-view#matches-key?
      (lambda (_%row766%_ _%columns767%_ _%key768%_)
        (let ((__tmp3722
               (lambda (_%column770%_ _%value771%_)
                 (equal? (list-ref _%row766%_ _%column770%_) _%value771%_))))
          (declare (not safe))
          (andmap__1 __tmp3722 _%columns767%_ _%key768%_))))
    (define gerbil-ascent/core/relation-view#ordered-key-offsets
      (lambda (_%columns755%_ _%key756%_)
        (if (list? _%columns755%_)
            (if (list? _%key756%_)
                (if (= (let () (declare (not safe)) (##length _%columns755%_))
                       (let () (declare (not safe)) (##length _%key756%_)))
                    (let ((__tmp3723
                           (lambda (_%unordered758%_)
                             (let* ((_%previous760%_ '0)
                                    (__tmp3724
                                     (lambda (_%column762%_)
                                       (if (and (exact-integer? _%column762%_)
                                                (>= _%column762%_
                                                    _%previous760%_))
                                           '#!void
                                           (_%unordered758%_ '#f))
                                       (let ((_%offset764%_
                                              (- _%column762%_
                                                 _%previous760%_)))
                                         (set! _%previous760%_ _%column762%_)
                                         _%offset764%_))))
                               (declare (not safe))
                               (##map __tmp3724 _%columns755%_)))))
                      (declare (not safe))
                      (##call-with-current-continuation __tmp3723))
                    '#f)
                '#f)
            '#f)))
    (define gerbil-ascent/core/relation-view#matches-offset-key?
      (lambda (_%row746%_ _%offsets747%_ _%key748%_)
        (let ((_%$e750%_ (null? _%offsets747%_)))
          (if _%$e750%_
              _%$e750%_
              (let ((_%rest753%_ (list-tail _%row746%_ (car _%offsets747%_))))
                (if (equal? (list-ref _%rest753%_ '0) (car _%key748%_))
                    (gerbil-ascent/core/relation-view#matches-offset-key?
                     _%rest753%_
                     (cdr _%offsets747%_)
                     (cdr _%key748%_))
                    '#f))))))
    (define gerbil-ascent/core/relation-view#compile-explicit-key-match
      (lambda (_%columns733%_ _%key734%_)
        (let ((_%offsets736%_
               (gerbil-ascent/core/relation-view#ordered-key-offsets
                _%columns733%_
                _%key734%_)))
          (if _%offsets736%_
              (lambda (_%$%g737739%_)
                (gerbil-ascent/core/relation-view#matches-offset-key?
                 _%$%g737739%_
                 _%offsets736%_
                 _%key734%_))
              (lambda (_%$%g741743%_)
                (gerbil-ascent/core/relation-view#matches-key?
                 _%$%g741743%_
                 _%columns733%_
                 _%key734%_))))))
    (define gerbil-ascent/core/relation-view#matches-prefix?
      (lambda (_%row727%_ _%prefix728%_)
        (let ((_%$e730%_ (null? _%prefix728%_)))
          (if _%$e730%_
              _%$e730%_
              (if (pair? _%row727%_)
                  (if (equal? (let () (declare (not safe)) (##car _%row727%_))
                              (car _%prefix728%_))
                      (gerbil-ascent/core/relation-view#matches-prefix?
                       (let () (declare (not safe)) (##cdr _%row727%_))
                       (cdr _%prefix728%_))
                      '#f)
                  '#f)))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-explicit-view
      (lambda (_%rows722%_ _%count723%_)
        (gerbil-ascent/core/relation-view#gerbil-ascent-lazy-explicit-view
         (map (lambda (_%row725%_) (map values _%row725%_)) _%rows722%_)
         _%count723%_)))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-lazy-explicit-view
      (lambda (_%snapshot706%_ _%count707%_)
        (letrec ((_%rows709%_
                  (lambda ()
                    (if (promise? _%snapshot706%_)
                        (force _%snapshot706%_)
                        _%snapshot706%_))))
          (let ((__tmp3726
                 (lambda (_%columns711%_ _%key712%_ _%consume713%_)
                   (let ((_%matches?715%_
                          (gerbil-ascent/core/relation-view#compile-explicit-key-match
                           _%columns711%_
                           _%key712%_)))
                     (for-each
                      (lambda (_%row717%_)
                        (if (let ()
                              (declare (not safe))
                              (_%matches?715%_ _%row717%_))
                            (_%consume713%_ (map values _%row717%_))
                            '#!void))
                      (_%rows709%_)))))
                (__tmp3725
                 (lambda (_%row719%_)
                   (if (member _%row719%_ (_%rows709%_)) '#t '#f))))
            (declare (not safe))
            (##structure
             gerbil-ascent/core/relation-view#relation-view::t
             '#f
             '#f
             '0
             'total
             _%count707%_
             _%count707%_
             __tmp3726
             __tmp3725
             '#f
             '#f)))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-view-union
      (lambda (_%left686%_ _%right687%_)
        (let ((__tmp3733
               (+ (##structure-ref
                   _%left686%_
                   '5
                   gerbil-ascent/core/relation-view#relation-view::t
                   '#f)
                  (##structure-ref
                   _%right687%_
                   '5
                   gerbil-ascent/core/relation-view#relation-view::t
                   '#f)))
              (__tmp3732
               (+ (##structure-ref
                   _%left686%_
                   '6
                   gerbil-ascent/core/relation-view#relation-view::t
                   '#f)
                  (##structure-ref
                   _%right687%_
                   '6
                   gerbil-ascent/core/relation-view#relation-view::t
                   '#f)))
              (__tmp3731
               (lambda (_%columns689%_ _%key690%_ _%consume691%_)
                 ((##structure-ref
                   _%left686%_
                   '7
                   gerbil-ascent/core/relation-view#relation-view::t
                   '#f)
                  _%columns689%_
                  _%key690%_
                  _%consume691%_)
                 ((##structure-ref
                   _%right687%_
                   '7
                   gerbil-ascent/core/relation-view#relation-view::t
                   '#f)
                  _%columns689%_
                  _%key690%_
                  _%consume691%_)))
              (__tmp3730
               (lambda (_%row693%_)
                 (let ((_%$e695%_
                        (gerbil-ascent/core/relation-view#gerbil-ascent-view-contains?
                         _%left686%_
                         _%row693%_)))
                   (if _%$e695%_
                       _%$e695%_
                       (gerbil-ascent/core/relation-view#gerbil-ascent-view-contains?
                        _%right687%_
                        _%row693%_)))))
              (__tmp3727
               (if (##structure-ref
                    _%left686%_
                    '10
                    gerbil-ascent/core/relation-view#relation-view::t
                    '#f)
                   (if (##structure-ref
                        _%right687%_
                        '10
                        gerbil-ascent/core/relation-view#relation-view::t
                        '#f)
                       (let ((__tmp3729
                              (lambda (_%columns698%_
                                       _%key699%_
                                       _%consume700%_)
                                (gerbil-ascent/core/relation-view#gerbil-ascent-visit-view-parts!
                                 _%left686%_
                                 _%columns698%_
                                 _%key699%_
                                 _%consume700%_)
                                (gerbil-ascent/core/relation-view#gerbil-ascent-visit-view-parts!
                                 _%right687%_
                                 _%columns698%_
                                 _%key699%_
                                 _%consume700%_)))
                             (__tmp3728
                              (if (gerbil-ascent/core/relation-view#gerbil-ascent-admitted-row-parts?
                                   _%left686%_)
                                  (if (gerbil-ascent/core/relation-view#gerbil-ascent-admitted-row-parts?
                                       _%right687%_)
                                      (lambda (_%columns702%_
                                               _%key703%_
                                               _%consume704%_)
                                        (gerbil-ascent/core/relation-view#gerbil-ascent-visit-admitted-view-parts!
                                         _%left686%_
                                         _%columns702%_
                                         _%key703%_
                                         _%consume704%_)
                                        (gerbil-ascent/core/relation-view#gerbil-ascent-visit-admitted-view-parts!
                                         _%right687%_
                                         _%columns702%_
                                         _%key703%_
                                         _%consume704%_))
                                      '#f)
                                  '#f)))
                         (declare (not safe))
                         (##structure
                          gerbil-ascent/core/relation-view#part-visitors::t
                          __tmp3729
                          __tmp3728))
                       '#f)
                   '#f)))
          (declare (not safe))
          (##structure
           gerbil-ascent/core/relation-view#relation-view::t
           '#f
           '#f
           '0
           'delta
           __tmp3733
           __tmp3732
           __tmp3731
           __tmp3730
           '#f
           __tmp3727))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-view-difference
      (lambda (_%newer641%_ _%older642%_ _%count643%_)
        (if (and (exact-integer? _%count643%_)
                 (>= _%count643%_ '0)
                 (gerbil-ascent/core/relation-view#gerbil-ascent-row-parts?
                  _%newer641%_)
                 (gerbil-ascent/core/relation-view#gerbil-ascent-row-parts?
                  _%older642%_)
                 (= _%count643%_
                    (- (##structure-ref
                        _%newer641%_
                        '5
                        gerbil-ascent/core/relation-view#relation-view::t
                        '#f)
                       (##structure-ref
                        _%older642%_
                        '5
                        gerbil-ascent/core/relation-view#relation-view::t
                        '#f))))
            '#!void
            (let ()
              (declare (not safe))
              (error '"ASCENT view difference requires coherent part cuts")))
        (let ((_%admitted?645%_
               (if (gerbil-ascent/core/relation-view#gerbil-ascent-admitted-row-parts?
                    _%newer641%_)
                   (gerbil-ascent/core/relation-view#gerbil-ascent-admitted-row-parts?
                    _%older642%_)
                   '#f)))
          (letrec ((_%parts647%_
                    (lambda (_%columns667%_
                             _%key668%_
                             _%consume669%_
                             _%admitted?670%_)
                      ((if _%admitted?670%_
                           gerbil-ascent/core/relation-view#gerbil-ascent-visit-admitted-view-parts!
                           gerbil-ascent/core/relation-view#gerbil-ascent-visit-view-parts!)
                       _%newer641%_
                       _%columns667%_
                       _%key668%_
                       (lambda (_%prefix672%_ _%left673%_ _%right674%_)
                         (let ((_%found?676%_ '#f)
                               (_%row677%_
                                (let ((__tmp3734
                                       (list _%left673%_ _%right674%_)))
                                  (declare (not safe))
                                  (##append _%prefix672%_ __tmp3734))))
                           ((if _%admitted?670%_
                                gerbil-ascent/core/relation-view#gerbil-ascent-visit-admitted-view-parts!
                                gerbil-ascent/core/relation-view#gerbil-ascent-visit-view-parts!)
                            _%older642%_
                            (let ((_%$e679%_
                                   (let ()
                                     (declare (not safe))
                                     (##length _%row677%_))))
                              (if (eq? '2 _%$e679%_)
                                  '(0 1)
                                  (if (eq? '3 _%$e679%_)
                                      '(0 1 2)
                                      (let ((__tmp3735
                                             (let ()
                                               (declare (not safe))
                                               (##length _%row677%_))))
                                        (declare (not safe))
                                        (##iota __tmp3735)))))
                            _%row677%_
                            (lambda (_%_prefix682%_ _%_left683%_ _%_right684%_)
                              (set! _%found?676%_ '#t)))
                           (if _%found?676%_
                               '#!void
                               (_%consume669%_
                                _%prefix672%_
                                _%left673%_
                                _%right674%_))))))))
            (let ((__tmp3742
                   (+ (##structure-ref
                       _%newer641%_
                       '6
                       gerbil-ascent/core/relation-view#relation-view::t
                       '#f)
                      (##structure-ref
                       _%older642%_
                       '6
                       gerbil-ascent/core/relation-view#relation-view::t
                       '#f)))
                  (__tmp3740
                   (lambda (_%columns649%_ _%key650%_ _%consume651%_)
                     (_%parts647%_
                      _%columns649%_
                      _%key650%_
                      (lambda (_%prefix653%_ _%left654%_ _%right655%_)
                        (_%consume651%_
                         (let ((__tmp3741 (list _%left654%_ _%right655%_)))
                           (declare (not safe))
                           (##append _%prefix653%_ __tmp3741))))
                      '#f)))
                  (__tmp3739
                   (lambda (_%row657%_)
                     (if (gerbil-ascent/core/relation-view#gerbil-ascent-view-contains?
                          _%newer641%_
                          _%row657%_)
                         (not (gerbil-ascent/core/relation-view#gerbil-ascent-view-contains?
                               _%older642%_
                               _%row657%_))
                         '#f)))
                  (__tmp3736
                   (let ((__tmp3738
                          (lambda (_%columns659%_ _%key660%_ _%consume661%_)
                            (_%parts647%_
                             _%columns659%_
                             _%key660%_
                             _%consume661%_
                             '#f)))
                         (__tmp3737
                          (if _%admitted?645%_
                              (lambda (_%columns663%_
                                       _%key664%_
                                       _%consume665%_)
                                (_%parts647%_
                                 _%columns663%_
                                 _%key664%_
                                 _%consume665%_
                                 '#t))
                              '#f)))
                     (declare (not safe))
                     (##structure
                      gerbil-ascent/core/relation-view#part-visitors::t
                      __tmp3738
                      __tmp3737))))
              (declare (not safe))
              (##structure
               gerbil-ascent/core/relation-view#relation-view::t
               '#f
               '#f
               '0
               'delta
               _%count643%_
               __tmp3742
               __tmp3740
               __tmp3739
               '#f
               __tmp3736))))))
    (define gerbil-ascent/core/relation-view#matches-coordinate?
      (lambda (_%value630%_ _%coordinate631%_ _%columns632%_ _%key633%_)
        (let ((__tmp3743
               (lambda (_%column635%_ _%selected636%_)
                 (let ((_%$e638%_ (not (= _%column635%_ _%coordinate631%_))))
                   (if _%$e638%_
                       _%$e638%_
                       (equal? _%value630%_ _%selected636%_))))))
          (declare (not safe))
          (andmap__1 __tmp3743 _%columns632%_ _%key633%_))))
    (define gerbil-ascent/core/relation-view#captured-member
      (lambda (_%routes597%_ _%members598%_ _%coordinate599%_ _%value600%_)
        (let _%find602%_ ((_%hits604%_
                           (let ((_%$e627%_
                                  (let* ((_%h606%_
                                          (vector-ref
                                           _%routes597%_
                                           _%coordinate599%_))
                                         (_%key609%_ _%value600%_)
                                         (_%h613%_
                                          (let ()
                                            (declare (not safe))
                                            (cast HashTable::interface
                                                  _%h606%_)))
                                         (_%h615%_ _%h613%_))
                                    (declare (not safe))
                                    (__hash-get _%h615%_ _%key609%_))))
                             (if _%$e627%_ _%$e627%_ '()))))
          (if (pair? _%hits604%_)
              (if (eq? (##direct-structure-ref
                        (cdar _%hits604%_)
                        '1
                        gerbil-ascent/core/relation-view#rectangle-bucket::t
                        '#f)
                       _%members598%_)
                  (let () (declare (not safe)) (##car _%hits604%_))
                  (_%find602%_
                   (let () (declare (not safe)) (##cdr _%hits604%_))))
              '#f))))
    (define gerbil-ascent/core/relation-view#selected-members
      (lambda (_%members579%_
               _%coordinate580%_
               _%columns581%_
               _%key582%_
               _%routes583%_)
        (let _%find585%_ ((_%remaining587%_ _%columns581%_)
                          (_%values588%_ _%key582%_))
          (if (null? _%remaining587%_)
              _%members579%_
              (if (= (car _%remaining587%_) _%coordinate580%_)
                  (let ((_%present594%_
                         (if _%routes583%_
                             (let ((_%hit592%_
                                    (gerbil-ascent/core/relation-view#captured-member
                                     _%routes583%_
                                     _%members579%_
                                     _%coordinate580%_
                                     (car _%values588%_))))
                               (if _%hit592%_ (car _%hit592%_) '#f))
                             (member (car _%values588%_) _%members579%_))))
                    (if (and _%present594%_
                             (gerbil-ascent/core/relation-view#matches-coordinate?
                              (car _%present594%_)
                              _%coordinate580%_
                              _%columns581%_
                              _%key582%_))
                        (if _%routes583%_
                            _%present594%_
                            (list (car _%present594%_)))
                        '()))
                  (_%find585%_ (cdr _%remaining587%_) (cdr _%values588%_)))))))
    (define gerbil-ascent/core/relation-view#visit-right-members
      (lambda (_%prefix574%_ _%left575%_ _%rights576%_ _%consume577%_)
        (if (null? _%rights576%_)
            '#!void
            (begin
              (_%consume577%_ _%prefix574%_ _%left575%_ (car _%rights576%_))
              (gerbil-ascent/core/relation-view#visit-right-members
               _%prefix574%_
               _%left575%_
               (cdr _%rights576%_)
               _%consume577%_)))))
    (define gerbil-ascent/core/relation-view#visit-left-members
      (lambda (_%prefix569%_ _%lefts570%_ _%rights571%_ _%consume572%_)
        (if (null? _%lefts570%_)
            '#!void
            (begin
              (gerbil-ascent/core/relation-view#visit-right-members
               _%prefix569%_
               (car _%lefts570%_)
               _%rights571%_
               _%consume572%_)
              (gerbil-ascent/core/relation-view#visit-left-members
               _%prefix569%_
               (cdr _%lefts570%_)
               _%rights571%_
               _%consume572%_)))))
    (define gerbil-ascent/core/relation-view#visit-rectangle-parts__%
      (lambda (_%block543%_
               _%columns544%_
               _%key545%_
               _%consume546%_
               _%routes547%_)
        (let ((_%offset549%_
               (length (##structure-ref
                        _%block543%_
                        '1
                        gerbil-ascent/core/relation-view#rectangle::t
                        '#f))))
          (if (let ((__tmp3744
                     (lambda (_%column551%_)
                       (< _%column551%_ (+ _%offset549%_ '2)))))
                (declare (not safe))
                (andmap__0 __tmp3744 _%columns544%_))
              '#!void
              (let ()
                (declare (not safe))
                (error '"invalid ASCENT UF view column"))))
        (gerbil-ascent/core/relation-view#visit-admitted-rectangle-parts
         _%block543%_
         _%columns544%_
         _%key545%_
         _%consume546%_
         _%routes547%_)))
    (define gerbil-ascent/core/relation-view#visit-rectangle-parts__0
      (lambda (_%block556%_ _%columns557%_ _%key558%_ _%consume559%_)
        (let ((_%routes561%_ '#f))
          (gerbil-ascent/core/relation-view#visit-rectangle-parts__%
           _%block556%_
           _%columns557%_
           _%key558%_
           _%consume559%_
           _%routes561%_))))
    (define gerbil-ascent/core/relation-view#visit-rectangle-parts
      (lambda _g3745_
        (let ((_g3746_ (let () (declare (not safe)) (##length _g3745_))))
          (cond ((let () (declare (not safe)) (##fx= _g3746_ 4))
                 (apply gerbil-ascent/core/relation-view#visit-rectangle-parts__0
                        _g3745_))
                ((let () (declare (not safe)) (##fx= _g3746_ 5))
                 (apply gerbil-ascent/core/relation-view#visit-rectangle-parts__%
                        _g3745_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/core/relation-view#visit-rectangle-parts
                  _g3745_))))))
    (define gerbil-ascent/core/relation-view#visit-admitted-rectangle-parts
      (lambda (_%block522%_
               _%columns523%_
               _%key524%_
               _%consume525%_
               _%routes526%_)
        (let* ((_%prefix528%_
                (##structure-ref
                 _%block522%_
                 '1
                 gerbil-ascent/core/relation-view#rectangle::t
                 '#f))
               (_%offset530%_ (length _%prefix528%_)))
          (if (let ((__tmp3747
                     (lambda (_%column533%_ _%value534%_)
                       (or (>= _%column533%_ _%offset530%_)
                           (equal? (list-ref _%prefix528%_ _%column533%_)
                                   _%value534%_)))))
                (declare (not safe))
                (andmap__1 __tmp3747 _%columns523%_ _%key524%_))
              (let ((_%lefts539%_
                     (gerbil-ascent/core/relation-view#selected-members
                      (##structure-ref
                       _%block522%_
                       '2
                       gerbil-ascent/core/relation-view#rectangle::t
                       '#f)
                      _%offset530%_
                      _%columns523%_
                      _%key524%_
                      _%routes526%_))
                    (_%rights540%_
                     (gerbil-ascent/core/relation-view#selected-members
                      (##structure-ref
                       _%block522%_
                       '3
                       gerbil-ascent/core/relation-view#rectangle::t
                       '#f)
                      (+ _%offset530%_ '1)
                      _%columns523%_
                      _%key524%_
                      _%routes526%_)))
                (gerbil-ascent/core/relation-view#visit-left-members
                 _%prefix528%_
                 _%lefts539%_
                 _%rights540%_
                 _%consume525%_))
              '#!void))))
    (define gerbil-ascent/core/relation-view#visit-admitted-blocks
      (lambda (_%blocks516%_
               _%columns517%_
               _%key518%_
               _%consume519%_
               _%routes520%_)
        (if (null? _%blocks516%_)
            '#!void
            (begin
              (gerbil-ascent/core/relation-view#visit-admitted-rectangle-parts
               (car _%blocks516%_)
               _%columns517%_
               _%key518%_
               _%consume519%_
               _%routes520%_)
              (gerbil-ascent/core/relation-view#visit-admitted-blocks
               (cdr _%blocks516%_)
               _%columns517%_
               _%key518%_
               _%consume519%_
               _%routes520%_)))))
    (define gerbil-ascent/core/relation-view#rectangle-routing
      (lambda (_%blocks314%_)
        (let* ((_%arity319%_
                (let ((__tmp3748
                       (lambda (_%block316%_ _%n317%_)
                         (max _%n317%_
                              (+ '2
                                 (length (##structure-ref
                                          _%block316%_
                                          '1
                                          gerbil-ascent/core/relation-view#rectangle::t
                                          '#f)))))))
                  (declare (not safe))
                  (foldl__0 __tmp3748 '0 _%blocks314%_)))
               (_%owners323%_
                (list->vector
                 (let ((__tmp3750
                        (lambda (_%_321%_)
                          (let () (declare (not safe)) (make-hash-table-eq))))
                       (__tmp3749 (iota _%arity319%_)))
                   (declare (not safe))
                   (##map __tmp3750 __tmp3749))))
               (_%routes327%_
                (list->vector
                 (let ((__tmp3752
                        (lambda (_%_325%_)
                          (let ()
                            (declare (not safe))
                            (make-hash-table__%
                             '#f
                             absent-value
                             absent-value
                             absent-value
                             absent-value
                             absent-value
                             absent-value
                             absent-value
                             absent-value))))
                       (__tmp3751 (iota _%arity319%_)))
                   (declare (not safe))
                   (##map __tmp3752 __tmp3751)))))
          (for-each
           (lambda (_%block330%_ _%ordinal331%_)
             (let* ((_%prefix333%_
                     (##structure-ref
                      _%block330%_
                      '1
                      gerbil-ascent/core/relation-view#rectangle::t
                      '#f))
                    (_%offset335%_ (length _%prefix333%_)))
               (letrec ((_%add!338%_
                         (lambda (_%column343%_ _%identity344%_ _%members345%_)
                           (let* ((_%table347%_
                                   (vector-ref _%owners323%_ _%column343%_))
                                  (_%bucket412%_
                                   (let ((_%$e381%_
                                          (let* ((_%h349%_ _%table347%_)
                                                 (_%key352%_ _%identity344%_)
                                                 (_%h356%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (cast HashTable::interface
                                                          _%h349%_)))
                                                 (_%h358%_ _%h356%_))
                                            (declare (not safe))
                                            (__hash-get _%h358%_ _%key352%_))))
                                     (if _%$e381%_
                                         _%$e381%_
                                         (let ((_%fresh384%_
                                                (let ()
                                                  (declare (not safe))
                                                  (##structure
                                                   gerbil-ascent/core/relation-view#rectangle-bucket::t
                                                   _%members345%_
                                                   '()
                                                   '0
                                                   '()))))
                                           (let* ((_%h386%_ _%table347%_)
                                                  (_%key389%_ _%identity344%_)
                                                  (_%value392%_ _%fresh384%_)
                                                  (_%h396%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (cast HashTable::interface
                                                           _%h386%_)))
                                                  (_%h398%_ _%h396%_))
                                             (declare (not safe))
                                             (__hash-put!
                                              _%h398%_
                                              _%key389%_
                                              _%value392%_))
                                           _%fresh384%_)))))
                             (##direct-structure-set!
                              _%bucket412%_
                              (cons (cons _%ordinal331%_ _%block330%_)
                                    (##direct-structure-ref
                                     _%bucket412%_
                                     '2
                                     gerbil-ascent/core/relation-view#rectangle-bucket::t
                                     '#f))
                              '2
                              gerbil-ascent/core/relation-view#rectangle-bucket::t
                              '#f)
                             (##direct-structure-set!
                              _%bucket412%_
                              (+ '1
                                 (##direct-structure-ref
                                  _%bucket412%_
                                  '3
                                  gerbil-ascent/core/relation-view#rectangle-bucket::t
                                  '#f))
                              '3
                              gerbil-ascent/core/relation-view#rectangle-bucket::t
                              '#f)))))
                 (let ((__tmp3754
                        (lambda (_%column340%_ _%value341%_)
                          (_%add!338%_
                           _%column340%_
                           _%prefix333%_
                           (list _%value341%_))))
                       (__tmp3753
                        (let () (declare (not safe)) (##iota _%offset335%_))))
                   (declare (not safe))
                   (##for-each __tmp3754 __tmp3753 _%prefix333%_))
                 (_%add!338%_
                  _%offset335%_
                  (##structure-ref
                   _%block330%_
                   '2
                   gerbil-ascent/core/relation-view#rectangle::t
                   '#f)
                  (##structure-ref
                   _%block330%_
                   '2
                   gerbil-ascent/core/relation-view#rectangle::t
                   '#f))
                 (_%add!338%_
                  (+ _%offset335%_ '1)
                  (##structure-ref
                   _%block330%_
                   '3
                   gerbil-ascent/core/relation-view#rectangle::t
                   '#f)
                  (##structure-ref
                   _%block330%_
                   '3
                   gerbil-ascent/core/relation-view#rectangle::t
                   '#f)))))
           _%blocks314%_
           (let ((__tmp3755 (length _%blocks314%_)))
             (declare (not safe))
             (##iota __tmp3755)))
          (let ((__tmp3757
                 (lambda (_%column415%_)
                   (let* ((_%proc486%_
                           (lambda (_%_417%_ _%bucket418%_)
                             (let ((_%bucket420%_ _%bucket418%_))
                               (let ((__tmp3758
                                      (reverse (let ()
                                                 (declare (not safe))
                                                 (##unchecked-structure-ref
                                                  _%bucket420%_
                                                  '2
                                                  '#f
                                                  '#f)))))
                                 (declare (not safe))
                                 (##unchecked-structure-set!
                                  _%bucket420%_
                                  __tmp3758
                                  '2
                                  '#f
                                  '#f))
                               (let ((__tmp3759
                                      (map cdr
                                           (let ()
                                             (declare (not safe))
                                             (##unchecked-structure-ref
                                              _%bucket420%_
                                              '2
                                              '#f
                                              '#f)))))
                                 (declare (not safe))
                                 (##unchecked-structure-set!
                                  _%bucket420%_
                                  __tmp3759
                                  '4
                                  '#f
                                  '#f))
                               (let ((_%table428%_
                                      (vector-ref
                                       _%routes327%_
                                       _%column415%_)))
                                 (for-each
                                  (lambda (_%member430%_)
                                    (let ((_%hits459%_
                                           (let ((_%$e456%_
                                                  (let* ((_%h432%_
                                                          _%table428%_)
                                                         (_%key435%_
                                                          _%member430%_)
                                                         (_%h439%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (cast HashTable::interface
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          _%h432%_)))
                 (_%h441%_ _%h439%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (declare (not safe))
                                                    (__hash-get
                                                     _%h441%_
                                                     _%key435%_))))
                                             (if _%$e456%_ _%$e456%_ '()))))
                                      (if (and (pair? _%hits459%_)
                                               (eq? (cdar _%hits459%_)
                                                    _%bucket420%_))
                                          '#!void
                                          (let* ((_%h461%_ _%table428%_)
                                                 (_%key464%_ _%member430%_)
                                                 (_%value467%_
                                                  (cons (cons (list _%member430%_)
                                                              _%bucket420%_)
                                                        _%hits459%_))
                                                 (_%h471%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (cast HashTable::interface
                                                          _%h461%_)))
                                                 (_%h473%_ _%h471%_))
                                            (declare (not safe))
                                            (__hash-put!
                                             _%h473%_
                                             _%key464%_
                                             _%value467%_)))))
                                  (let ()
                                    (declare (not safe))
                                    (##unchecked-structure-ref
                                     _%bucket420%_
                                     '1
                                     '#f
                                     '#f)))))))
                          (_%h489%_ (vector-ref _%owners323%_ _%column415%_))
                          (_%proc494%_ _%proc486%_)
                          (_%h504%_
                           (let ()
                             (declare (not safe))
                             (cast HashTable::interface _%h489%_)))
                          (_%h506%_ _%h504%_))
                     (declare (not safe))
                     (__hash-for-each _%proc494%_ _%h506%_))))
                (__tmp3756 (iota _%arity319%_)))
            (declare (not safe))
            (##for-each __tmp3757 __tmp3756))
          _%routes327%_)))
    (define gerbil-ascent/core/relation-view#routed-rectangles
      (lambda (_%routes261%_ _%blocks262%_ _%columns263%_ _%key264%_)
        (if (null? _%columns263%_)
            _%blocks262%_
            (let ((_%selected266%_ '#f) (_%cost267%_ '+inf.0))
              (for-each
               (lambda (_%column269%_ _%value270%_)
                 (if (>= _%column269%_ (vector-length _%routes261%_))
                     (let ()
                       (declare (not safe))
                       (error '"invalid ASCENT UF view column"))
                     '#!void)
                 (if (> _%cost267%_ '1)
                     (let* ((_%buckets298%_
                             (let ((_%$e295%_
                                    (let* ((_%h272%_
                                            (vector-ref
                                             _%routes261%_
                                             _%column269%_))
                                           (_%key275%_ _%value270%_)
                                           (_%h279%_
                                            (let ()
                                              (declare (not safe))
                                              (cast HashTable::interface
                                                    _%h272%_)))
                                           (_%h281%_ _%h279%_))
                                      (declare (not safe))
                                      (__hash-get _%h281%_ _%key275%_))))
                               (if _%$e295%_ _%$e295%_ '())))
                            (_%size303%_
                             (let ((__tmp3760
                                    (lambda (_%hit300%_ _%n301%_)
                                      (+ _%n301%_
                                         (##direct-structure-ref
                                          (cdr _%hit300%_)
                                          '3
                                          gerbil-ascent/core/relation-view#rectangle-bucket::t
                                          '#f)))))
                               (declare (not safe))
                               (foldl__0 __tmp3760 '0 _%buckets298%_))))
                       (if (< _%size303%_ _%cost267%_)
                           (begin
                             (set! _%selected266%_ _%buckets298%_)
                             (set! _%cost267%_ _%size303%_))
                           '#!void))
                     '#!void))
               _%columns263%_
               _%key264%_)
              (if (null? _%selected266%_)
                  '()
                  (if (null? (cdr _%selected266%_))
                      (##direct-structure-ref
                       (cdar _%selected266%_)
                       '4
                       gerbil-ascent/core/relation-view#rectangle-bucket::t
                       '#f)
                      (let ((__tmp3761
                             (let ((__tmp3764
                                    (lambda (_%a309%_ _%b310%_)
                                      (< (car _%a309%_) (car _%b310%_))))
                                   (__tmp3762
                                    (let ((__tmp3763
                                           (map (lambda (_%hit312%_)
                                                  (##direct-structure-ref
                                                   (cdr _%hit312%_)
                                                   '2
                                                   gerbil-ascent/core/relation-view#rectangle-bucket::t
                                                   '#f))
                                                _%selected266%_)))
                                      (declare (not safe))
                                      (##apply append __tmp3763))))
                               (declare (not safe))
                               (##list-sort __tmp3764 __tmp3762))))
                        (declare (not safe))
                        (##map cdr __tmp3761))))))))
    (define gerbil-ascent/core/relation-view#rectangle-contains?
      (lambda (_%block252%_ _%row253%_ _%width254%_)
        (let* ((_%prefix256%_
                (##structure-ref
                 _%block252%_
                 '1
                 gerbil-ascent/core/relation-view#rectangle::t
                 '#f))
               (_%offset258%_ (length _%prefix256%_)))
          (if (= _%width254%_ (+ _%offset258%_ '2))
              (if (gerbil-ascent/core/relation-view#matches-prefix?
                   _%row253%_
                   _%prefix256%_)
                  (if (member (list-ref _%row253%_ _%offset258%_)
                              (##structure-ref
                               _%block252%_
                               '2
                               gerbil-ascent/core/relation-view#rectangle::t
                               '#f))
                      (if (member (list-ref _%row253%_ (+ _%offset258%_ '1))
                                  (##structure-ref
                                   _%block252%_
                                   '3
                                   gerbil-ascent/core/relation-view#rectangle::t
                                   '#f))
                          '#t
                          '#f)
                      '#f)
                  '#f)
              '#f))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__%
      (lambda (_%blocks145%_ _%count146%_ _%units147%_ _%indexed?148%_)
        (let* ((_%routes150%_
                (if _%indexed?148%_
                    (if (pair? _%blocks145%_)
                        (gerbil-ascent/core/relation-view#rectangle-routing
                         _%blocks145%_)
                        '#f)
                    '#f))
               (_%membership-routes152%_
                (if _%routes150%_
                    (if (pair? (cdr _%blocks145%_))
                        (if (pair? (cddr _%blocks145%_)) _%routes150%_ '#f)
                        '#f)
                    '#f))
               (_%query-columns154%_
                (if _%membership-routes152%_
                    (let ((__tmp3765
                           (let ()
                             (declare (not safe))
                             (##vector-length _%membership-routes152%_))))
                      (declare (not safe))
                      (##iota __tmp3765))
                    '#f))
               (_%grouped?156%_
                (if (pair? _%blocks145%_)
                    (= (length (##structure-ref
                                (let ()
                                  (declare (not safe))
                                  (##car _%blocks145%_))
                                '1
                                gerbil-ascent/core/relation-view#rectangle::t
                                '#f))
                       '1)
                    '#f)))
          (letrec ((_%selected159%_
                    (lambda (_%columns235%_ _%key236%_)
                      (if _%routes150%_
                          (gerbil-ascent/core/relation-view#routed-rectangles
                           _%routes150%_
                           _%blocks145%_
                           _%columns235%_
                           _%key236%_)
                          _%blocks145%_)))
                   (_%validate-key!160%_
                    (lambda (_%columns230%_ _%key231%_)
                      (if (and (list? _%columns230%_)
                               (list? _%key231%_)
                               (= (let ()
                                    (declare (not safe))
                                    (##length _%columns230%_))
                                  (let ()
                                    (declare (not safe))
                                    (##length _%key231%_)))
                               (let ((__tmp3766
                                      (lambda (_%column233%_)
                                        (and (exact-integer? _%column233%_)
                                             (>= _%column233%_ '0)))))
                                 (declare (not safe))
                                 (andmap__0 __tmp3766 _%columns230%_)))
                          '#!void
                          (let ()
                            (declare (not safe))
                            (error '"invalid ASCENT UF view key")))))
                   (_%visit-admitted161%_
                    (lambda (_%columns190%_ _%key191%_ _%consume192%_)
                      (if (and _%grouped?156%_
                               _%routes150%_
                               (pair? _%columns190%_)
                               (= (let ()
                                    (declare (not safe))
                                    (##car _%columns190%_))
                                  '0))
                          (let ((_%hits225%_
                                 (let ((_%$e222%_
                                        (let* ((_%h194%_
                                                (vector-ref _%routes150%_ '0))
                                               (_%key197%_ (car _%key191%_))
                                               (_%h201%_
                                                (let ()
                                                  (declare (not safe))
                                                  (cast HashTable::interface
                                                        _%h194%_)))
                                               (_%h203%_ _%h201%_))
                                          (declare (not safe))
                                          (__hash-get _%h203%_ _%key197%_))))
                                   (if _%$e222%_ _%$e222%_ '()))))
                            (if (null? _%hits225%_)
                                '#!void
                                (if (and (null? (cdr _%hits225%_))
                                         (= (##direct-structure-ref
                                             (cdar _%hits225%_)
                                             '3
                                             gerbil-ascent/core/relation-view#rectangle-bucket::t
                                             '#f)
                                            '1)
                                         (= (length (##structure-ref
                                                     (car (##direct-structure-ref
                                                           (cdar _%hits225%_)
                                                           '4
                                                           gerbil-ascent/core/relation-view#rectangle-bucket::t
                                                           '#f))
                                                     '1
                                                     gerbil-ascent/core/relation-view#rectangle::t
                                                     '#f))
                                            '1))
                                    (gerbil-ascent/core/relation-view#visit-admitted-rectangle-parts
                                     (car (##direct-structure-ref
                                           (cdar _%hits225%_)
                                           '4
                                           gerbil-ascent/core/relation-view#rectangle-bucket::t
                                           '#f))
                                     (cdr _%columns190%_)
                                     (cdr _%key191%_)
                                     _%consume192%_
                                     _%routes150%_)
                                    (gerbil-ascent/core/relation-view#visit-admitted-blocks
                                     (_%selected159%_
                                      _%columns190%_
                                      _%key191%_)
                                     _%columns190%_
                                     _%key191%_
                                     _%consume192%_
                                     _%routes150%_))))
                          (gerbil-ascent/core/relation-view#visit-admitted-blocks
                           (_%selected159%_ _%columns190%_ _%key191%_)
                           _%columns190%_
                           _%key191%_
                           _%consume192%_
                           _%routes150%_)))))
            (let ((__tmp3772
                   (lambda (_%columns163%_ _%key164%_ _%consume165%_)
                     (_%validate-key!160%_ _%columns163%_ _%key164%_)
                     (for-each
                      (lambda (_%block167%_)
                        (gerbil-ascent/core/relation-view#visit-rectangle-parts__%
                         _%block167%_
                         _%columns163%_
                         _%key164%_
                         (lambda (_%prefix169%_ _%left170%_ _%right171%_)
                           (_%consume165%_
                            (let ((__tmp3773 (list _%left170%_ _%right171%_)))
                              (declare (not safe))
                              (##append _%prefix169%_ __tmp3773))))
                         _%routes150%_))
                      (_%selected159%_ _%columns163%_ _%key164%_))))
                  (__tmp3769
                   (lambda (_%row173%_)
                     (let ((_%width175%_ (length _%row173%_)))
                       (if (>= _%width175%_ '2)
                           (if (or (not _%membership-routes152%_)
                                   (<= _%width175%_
                                       (vector-length
                                        _%membership-routes152%_)))
                               (let ((__tmp3771
                                      (lambda (_%$%g179181%_)
                                        (gerbil-ascent/core/relation-view#rectangle-contains?
                                         _%$%g179181%_
                                         _%row173%_
                                         _%width175%_)))
                                     (__tmp3770
                                      (if _%membership-routes152%_
                                          (gerbil-ascent/core/relation-view#routed-rectangles
                                           _%membership-routes152%_
                                           _%blocks145%_
                                           (if (= _%width175%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (##vector-length
                                                     _%membership-routes152%_)))
                                               _%query-columns154%_
                                               (take _%query-columns154%_
                                                     _%width175%_))
                                           _%row173%_)
                                          _%blocks145%_)))
                                 (declare (not safe))
                                 (ormap__0 __tmp3771 __tmp3770))
                               '#f)
                           '#f))))
                  (__tmp3767
                   (let ((__tmp3768
                          (lambda (_%columns184%_ _%key185%_ _%consume186%_)
                            (_%validate-key!160%_ _%columns184%_ _%key185%_)
                            (for-each
                             (lambda (_%block188%_)
                               (gerbil-ascent/core/relation-view#visit-rectangle-parts__%
                                _%block188%_
                                _%columns184%_
                                _%key185%_
                                _%consume186%_
                                _%routes150%_))
                             (_%selected159%_ _%columns184%_ _%key185%_)))))
                     (declare (not safe))
                     (##structure
                      gerbil-ascent/core/relation-view#part-visitors::t
                      __tmp3768
                      _%visit-admitted161%_))))
              (declare (not safe))
              (##structure
               gerbil-ascent/core/relation-view#relation-view::t
               '#f
               '#f
               '0
               'total
               _%count146%_
               _%units147%_
               __tmp3772
               __tmp3769
               '#f
               __tmp3767))))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__0
      (lambda (_%blocks241%_ _%count242%_ _%units243%_)
        (let ((_%indexed?245%_ '#f))
          (gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__%
           _%blocks241%_
           _%count242%_
           _%units243%_
           _%indexed?245%_))))
    (define gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view
      (lambda _g3774_
        (let ((_g3775_ (let () (declare (not safe)) (##length _g3774_))))
          (cond ((let () (declare (not safe)) (##fx= _g3775_ 3))
                 (apply gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__0
                        _g3774_))
                ((let () (declare (not safe)) (##fx= _g3775_ 4))
                 (apply gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view__%
                        _g3774_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/core/relation-view#gerbil-ascent-rectangle-view
                  _g3774_))))))))
