# SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
"""Portable preserved branch receipts and conservative matched-budget endpoints."""
import json,tarfile
from .crosspath_search_v3 import ROOT,BASE,sha,save,canonical,verify
DOC=ROOT/'docs/research/agent-inference'

def produce():
    plan=json.loads((BASE/'frozen-plan.json').read_text());verify(plan)
    ledger=json.loads((BASE/'ledger.json').read_text());labs=json.loads((BASE/'annotation-ledger.json').read_text())
    qual=json.loads((BASE/'qualification.json').read_text());cal=json.loads((BASE/'calibration-ledger.json').read_text())
    lookup={a['phaseKey']:a for a in labs['annotations']};rows=[];integrity=[]
    for r in ledger['phases']:
        folder=BASE/'paid'/f"{r['case']}-{r['arm']}-{r['phase']}";lab=lookup[str(folder.relative_to(BASE))]
        episodes=lab['accepted'];exp=r['expansions'];seed=r['seed']['grade'];curves=[]
        for budget in (16384,32768,49152):
            available=r['observedTotalTokens']>=budget
            visited=[x for x in exp if x['atGrossTokens']<=budget]
            values=[seed['value']]+[x['evaluation']['value'] for x in visited if x['evaluation']['valid']]
            curves.append({'grossCheckpoint':budget,'reached':available,'bestValue':max(values) if available else None,'gainFromSeed':max(values)-seed['value'] if available else None,'prefixes':len(visited) if available else None,'maxAdmittedDepth':max([len(x['child']) for x in visited if x['prefix']['valid']],default=0) if available else None})
        row={'task':r['case'],'goal':r['phase'],'arm':r['arm'],'grossTokens':r['observedTotalTokens'],'unusedBudget':r['unusedBudget'],'thinkingTokens':sum(c['usage'].get('output_tokens_details',{}).get('reasoning_tokens',0) for c in r['calls'] if isinstance(c.get('usage'),dict)),'calls':len(r['calls']),'failedCalls':sum(bool(c['failure']) for c in r['calls']),'truncatedCalls':sum(c['status']=='incomplete' for c in r['calls']),'phaseFailure':r['failure'],'stopReason':r['stopReason'],'seedValue':seed['value'],'seedGap':seed['gap'],'bestValue':r['bestGrade']['value'],'gainFromSeed':r['bestGrade']['value']-seed['value'],'bestGap':r['bestGrade']['gap'],'executedExpansions':len(exp),'invalidPrefixes':sum(not x['prefix']['valid'] for x in exp),'invalidCompletions':sum(not x['evaluation']['valid'] for x in exp),'maxAttemptedDepth':max([len(x['child']) for x in exp],default=0),'maxAdmittedDepth':max([len(x['child']) for x in exp if x['prefix']['valid']],default=0),'uniqueCompleteCandidates':len({canonical(x['completion']) for x in exp if x['evaluation']['valid']}),'newCandidatesBeyondSeed':len({canonical(x['completion']) for x in exp if x['evaluation']['valid'] and x['completion']!=r['seed']['selection']}),'rootWidth':len({x['child'][0] for x in exp if len(x['child'])==1}),'deriveEpisodes':sum(e['kind']=='derive' for e in episodes),'repeatedDerivations':sum(e['definiteRepeatedDerivation'] for e in episodes),'reuseEpisodes':sum(e['kind']=='reuse' for e in episodes),'packetCoveredDerivations':sum(e['kind']=='derive' and e['nativeTruthMatches'] for e in episodes) if r['packet'] else None,'annotationFailure':lab['failure'],'rejectedLabels':len(lab['rejected']),'measurementGrossTokens':lab.get('measurementGrossTokens',0),'nativePacketReused':r['packet']['reused'] if r['packet'] else None,'nativeProofSeconds':r['packet']['nativeSeconds'] if r['packet'] else 0,'checkpoints':curves}
        rows.append(row)
        for c in r['calls']:
            request=json.loads((folder/f"{c['turn']}.request.json").read_text());content=json.loads(request['input'][0]['content'])
            text=(folder/f"{c['turn']}.thinking.txt").read_text()
            assert sha(text.encode())==c['thinkingSha256']
            assert content['commonSeed']==r['seed']['selection']
            assert c['grossTokens']==c['usage']['input_tokens']+c['usage']['output_tokens']
            assert c['usage']['output_tokens']<=plan['perCallOutputCap']
        assert sum(c['grossTokens'] for c in r['calls'])==r['observedTotalTokens']<=plan['totalTokenBudget']
        for e in episodes:
            text=(BASE/'annotations'/lab['blindedId']/'thinking.txt').read_text();assert text[e['span'][0]:e['span'][1]]==e['quote']
        integrity.append({'phaseKey':str(folder.relative_to(BASE)),'chargesAndSpansVerified':True})
    # Initial root inputs are identical except initial packet; later inputs reflect observed branches.
    for phase in (0,1):
        inputs=[]
        for arm in plan['order']:
            folder=BASE/'paid'/f"{plan['cases'][0]['id']}-{arm}-{phase}"
            inputs.append(json.loads(json.loads((folder/'0.request.json').read_text())['input'][0]['content']))
        assert inputs[1]==inputs[2]
        assert inputs[0]['evidence'] is None
        for x in inputs:x.pop('evidence')
        assert inputs[0]==inputs[1]==inputs[2]
    cross=[]
    for arm in plan['order']:
        a=lookup[f"paid/{plan['cases'][0]['id']}-{arm}-0"]['accepted'];b=lookup[f"paid/{plan['cases'][0]['id']}-{arm}-1"]['accepted']
        matches=[{'goal0Episode':x['index'],'goal1Episode':y['index'],'claimKey':x['claimKey']} for x in a for y in b if x['kind']==y['kind']=='derive' and x['nativeTruthMatches'] and y['nativeTruthMatches'] and x['claimKey']==y['claimKey']]
        cross.append({'arm':arm,'matchingPairs':matches,'uniqueRepeatedClaimKeys':len({canonical(x['claimKey']) for x in matches})})
    summary={}
    for arm in plan['order']:
        rs=[r for r in rows if r['arm']==arm]
        summary[arm]={k:sum(r[k] for r in rs) for k in ['grossTokens','unusedBudget','thinkingTokens','calls','failedCalls','truncatedCalls','executedExpansions','invalidPrefixes','invalidCompletions','deriveEpisodes','repeatedDerivations','reuseEpisodes','measurementGrossTokens']}
        summary[arm].update(gains=[r['gainFromSeed'] for r in rs],gaps=[r['bestGap'] for r in rs],depths=[r['maxAdmittedDepth'] for r in rs])
    raw={}
    for dirname in ['paid','calibration','annotations','qualification-packets']:
        for p in sorted((BASE/dirname).rglob('*')):
            if p.is_file():raw[str(p.relative_to(BASE))]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
    bundle=DOC/'crosspath-search-v3-raw.tar.gz'
    with tarfile.open(bundle,'w:gz') as tar:
        for dirname in ['paid','calibration','annotations','qualification-packets']:tar.add(BASE/dirname,arcname=dirname)
        for name in ['frozen-plan.json','frozen-plan.sha256','qualification.json','calibration-ledger.json','ledger.json','annotation-ledger.json','post-run-binding.json']:tar.add(BASE/name,arcname=name)
        for p in plan['binding']:
            if p.startswith('python/src/ascent_test_support/') or p.startswith('tools/crosspath-'):tar.add(ROOT/p,arcname='producers/'+p)
    result={'schema':'ascent.branch.report.v3','planSha256':sha((BASE/'frozen-plan.json').read_bytes()),'summary':summary,'table':rows,'crossGoalMatches':cross,'calibrationGrossTokens':cal['grossTokens'],'calibrationPassed':cal['passed'],'solverGrossTokens':sum(r['grossTokens'] for r in rows),'measurementGrossTokens':sum(r['measurementGrossTokens'] for r in rows),'rawBundle':{'sha256':sha(bundle.read_bytes()),'bytes':bundle.stat().st_size},'limitations':['One fixed disjoint task, two goals, fixed order and stochastic model; descriptive pilot, no statistical causal claim.','Fresh and retained have identical model-visible packets/policy; only native state differs, so thinking differences cannot establish a cache-state cognitive effect.','Common seed is independently feasible and non-optimal; seed quality is not model search achievement. Controller selects incumbent, not a model submit.','Every input and all output, including failed output and prefix-cache input, count. Unused ceiling is unused budget, not savings. Checkpoints use only completed expansions before spend boundary.','Depth means native-admitted executed prefix length. Every seeded complete candidate has length seven by construction; full-plan length is not exploration depth.','Annotation extraction is same-provider, partially blinded, exact-span/native-truth validated; completeness and independent-rater agreement unvalidated. Absence of labels is not absence of repetition.','Each call resets reasoning history and receives frontier/incumbent plus immutable source; this is a controlled external-memory search scenario, not arbitrary long-context reasoning.','Prefix validity is legitimate selected-branch feedback; counterfactual child totals omit eligibility. No model gets the optimum or eligibility-pruned option list.']}
    save(DOC/'crosspath-search-v3-report.json',result);save(DOC/'crosspath-search-v3-ledger.json',{'frozenPlan':plan,'qualification':qual,'calibration':cal,'phases':ledger['phases'],'annotations':labs['annotations'],'rawArtifacts':raw,'report':result})
    save(DOC/'crosspath-search-v3-integrity.json',{'verified':True,'planSha256':result['planSha256'],'bindingFiles':len(plan['binding']),'phaseChecks':integrity,'rootInputParity':True,'rawBundleSha256':result['rawBundle']['sha256']})
    md=['# Explicit branch search with a common feasible seed','',f"Frozen plan `{result['planSha256']}`. Disjoint three-call calibration passed: {cal['grossTokens']} gross tokens. Six confirmatory phases, {sum(r['calls'] for r in rows)} solver calls. Scheme grader and annotation rules frozen before all calls.",'','A call chooses one previously unexplored child of a scheduled parent. Native raw-source checking admits the prefix; a deterministic common seed suffix creates an additional candidate. The starting solution is identical across arms for each goal, feasible, strictly non-optimal. A known-cost incomplete response is retained and charged, never admitted as an expansion; later bounded calls may progress. Unknown usage stops the phase. The controller preserves and returns the incumbent independently of model output completion.','',f"Solver cost: {result['solverGrossTokens']}; separate annotation cost: {result['measurementGrossTokens']}. Per-phase ceiling 65,536 input + all output tokens; output cap 3,072. Every unused token is reported as unused budget, never efficiency savings.",'','| Arm / goal | Calls / failed / truncated | Gross / unused | Seed → best value | Gap | Expansions / valid depth | Repeated / derived / reuse |','|---|---:|---:|---:|---:|---:|---:|']
    for r in rows:md.append(f"| {r['arm']} / {r['goal']} | {r['calls']} / {r['failedCalls']} / {r['truncatedCalls']} | {r['grossTokens']} / {r['unusedBudget']} | {r['seedValue']} → {r['bestValue']} | {r['bestGap']} | {r['executedExpansions']} / {r['maxAdmittedDepth']} | {r['repeatedDerivations']} / {r['deriveEpisodes']} / {r['reuseEpisodes']} |")
    md+=['','## Matched gross-token checkpoints','','Best observed completed candidate before each boundary. A phase that never reaches a checkpoint is missing there; its under-budget endpoint is not substituted.','', '| Arm / goal | Gross checkpoint | Reached | Gain from seed | Expansions | Valid prefix depth |','|---|---:|---|---:|---:|---:|']
    for r in rows:
        for c in r['checkpoints']:md.append(f"| {r['arm']} / {r['goal']} | {c['grossCheckpoint']} | {c['reached']} | {c['gainFromSeed']} | {c['prefixes']} | {c['maxAdmittedDepth']} |")
    md+=['','All raw requests, returned reasoning, failed calls, invalid prefixes/completions, certificate store, exact span labels and native grades are retained in [the portable ledger](crosspath-search-v3-ledger.json) and [raw archive](crosspath-search-v3-raw.tar.gz).','',*result['limitations']]
    (DOC/'crosspath-search-v3-report.md').write_text('\n'.join(md)+'\n')
    spans=['# Frozen direct-derivation annotations, branch search','','Source text is returned external-model reasoning. Exact half-open Unicode character spans are validated. Definite repeats require an earlier grounded derivation with identical conclusion and ordered explicit premises; alternative witnesses and goal-dependent checks remain separate. Extraction is not independent human ground truth.','']
    for lab in labs['annotations']:
        spans +=[f"## {lab['phaseKey']}",'',f"Text SHA `{lab['textSha256']}`; annotation failure `{lab['failure']}`.",'']
        for e in lab['accepted']:spans +=[f"- Episode {e['index']}: {e['kind']}; F{e['fragment']}; span {e['span']}; prior {e['prior']}; definite repeat {e['definiteRepeatedDerivation']}; native truth {e['nativeTruthMatches']}",'','> '+e['quote'].replace('\n','\n> '),'']
        if lab['rejected']:spans +=['Rejected labels retained:',canonical(lab['rejected']),'']
    (DOC/'crosspath-v3-thinking-annotations.md').write_text('\n'.join(spans)+'\n');print(json.dumps(result['summary'],indent=2),flush=True)

if __name__=='__main__':produce()
