import json,hashlib,tarfile,shutil
from pathlib import Path
root=Path.cwd();base=root/'.cache/ascent/shared-premise';native=root/'.cache/ascent/candidate-interaction';doc=root/'docs/research/agent-inference/fact-reuse-results/shared-premise-diagnostic'
failures=[
 ('uv-sync.log','Dependency preflight DNS failure; later authorized sync succeeded'),
 ('cffi-api-build.log','Incorrect API builder arguments rejected'),
 ('cffi-api-build-gcc.log','Requested GCC executable absent'),
 ('cffi-api-build-success.log','Compiler selection preflight retained; explicit GCC qualification is separate'),
 ('native-source-manifest-build.log','Source newer than compiled module rejected; not bypassed'),
 ('freeze.log','Moving workspace source hash rejected during freeze'),
 ('snapshot-freeze.log','Missing os import in consumer freezer; fixed before paid calls'),
 ('diagnostic-freeze.log','Lean version lookup attempted unrelated dependency resolution; fixed before paid calls'),
 ('quint-typecheck.log','Finite model set/list type mismatch rejected; fixed model checked separately'),
 ('quint-run.log','Same ill-typed model refused execution')]
entries=[]
for name,why in failures:
 p=base/name
 if p.exists():entries.append({'receipt':f'preflight/{name}','sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'reason':why,'countsAsPass':False,'solverCalled':False})
r=json.loads((native/'shared-premise-final-qualification/receipt.json').read_text())
for x in r:
 if not x['passed']:entries.append({'receipt':'native/shared-premise-final-qualification/receipt.json','reason':'Earlier full-Gxi EOF cleanup exceeded five seconds and required termination','result':x,'countsAsPass':False,'solverCalled':False})
(doc/'engineering-failures.json').write_text(json.dumps(entries,indent=2)+'\n')
selected={}
for p in base.glob('*.log'):selected['preflight/'+p.name]=p
for p in base.glob('*result.txt'):selected['preflight/'+p.name]=p
for d in native.glob('shared-premise-*'):
 for p in d.rglob('*'):
  if p.is_file() and p.suffix in ('.json','.log','.txt','.ss','.py') and not any('previous' in x for x in p.relative_to(d).parts):selected['native/'+str(p.relative_to(native))]=p
capture=json.loads((base/'source-snapshot/.research-source.json').read_text())
for name in capture['snapshotInputsSha256']:
 p=base/'source-snapshot'/name
 if p.exists():selected['rebuild-source/'+name]=p
selected['rebuild-source/.research-source.json']=base/'source-snapshot/.research-source.json'
for p in Path('/tmp').glob('ascent-shared*'):
 if p.is_file() and p.suffix in ('.py','.log'):selected['producer-scripts/'+p.name]=p
# No .env, credentials, caches, .venv or unrelated worktree files are selected.
with tarfile.open(doc/'qualification-raw.tar.gz','w:gz') as a:
 for name,p in sorted(selected.items()):a.add(p,arcname=name,recursive=False)
manifest={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in selected.items()}
(doc/'qualification-inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
starts=json.loads((native/'shared-premise-snapshot-qualification/receipt.json').read_text());rules=json.loads((native/'shared-premise-snapshot-qualification/rules/receipt.json').read_text())
assert len(starts)==9 and all(x['passed'] and x['shutdown']['clean'] for x in starts)
assert all(sum(c['checks'] for c in x['checks'])==448 and x['shutdown']['clean'] for x in rules['results'])
summary={'nativeStarts':9,'nativeCleanExits':9,'rules':[{'mode':x['mode'],'checks':448,'shutdown':x['shutdown']} for x in rules['results']],'apiAndAbiPassed':True,'consumerAdmissionTests':5,'quintConformanceRows':32,'quintSampledTraces':1000,'leanProof':'ProofDag.lean','leanVersion':'4.34.0','publishedReplayPassed':True,'freshDirectoryPublicApiTestPassed':True,'reportJsonByteIdentical':True,'earlierFailureCount':len(entries),'allSelectedEngineeringReceiptsSha256':manifest}
(doc/'qualification-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(doc/'integrity.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(doc.iterdir()) if p.is_file() and p.name!='integrity.json'},indent=2)+'\n')
print('ARCHIVE_OK',len(selected),'files',len(entries),'retained engineering failures')
