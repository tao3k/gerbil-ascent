(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38394_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38396_|
    (##structure
     gx#syntax-quote::t
     'make-positive-nonmembership
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38398_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38400_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38401_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38402_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38403_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38404_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38405_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-program-fingerprint
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38406_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38407_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38408_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-closure
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38410_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38411_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38412_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38413_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38414_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38415_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-program-fingerprint-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38416_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38417_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38418_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-closure-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38420_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38421_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38422_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38423_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38424_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38425_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-program-fingerprint
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38426_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38427_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38428_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-closure
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38430_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38431_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38432_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38433_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38434_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38435_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-program-fingerprint-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38436_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38437_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g38438_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-closure-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[:0:]#positive-nonmembership|
    (let ((__obj38213
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj38213
         'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj38213
         'positive-nonmembership
         '3
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj38213
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  program-fingerprint
                  query
                  work-budget
                  closure)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj38213
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  program-fingerprint
                  query
                  work-budget
                  closure)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj38213 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj38213 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj38213 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj38213 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj38213 '#f '13 '#f '#f))
      (let ((__tmp38393 |gerbil-ascent/candidate/nonmembership[1]#_g38394_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj38213 __tmp38393 '4 '#f '#f))
      (let ((__tmp38395 |gerbil-ascent/candidate/nonmembership[1]#_g38396_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj38213 __tmp38395 '14 '#f '#f))
      (let ((__tmp38397 |gerbil-ascent/candidate/nonmembership[1]#_g38398_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj38213 __tmp38397 '15 '#f '#f))
      (let ((__tmp38399
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g38400_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g38401_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g38402_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g38403_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g38404_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g38405_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g38406_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g38407_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g38408_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj38213 __tmp38399 '16 '#f '#f))
      (let ((__tmp38409
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g38410_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g38411_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g38412_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g38413_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g38414_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g38415_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g38416_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g38417_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g38418_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj38213 __tmp38409 '17 '#f '#f))
      (let ((__tmp38419
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g38420_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g38421_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g38422_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g38423_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g38424_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g38425_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g38426_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g38427_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g38428_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj38213 __tmp38419 '18 '#f '#f))
      (let ((__tmp38429
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g38430_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g38431_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g38432_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g38433_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g38434_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g38435_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g38436_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g38437_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g38438_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj38213 __tmp38429 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj38213 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj38213 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj38213 '() '21 '#f '#f))
      __obj38213)))
