(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/result[1]#_g35056_|
    (##structure
     gx#syntax-quote::t
     'owned-publication::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g35058_|
    (##structure
     gx#syntax-quote::t
     'make-owned-publication
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g35060_|
    (##structure
     gx#syntax-quote::t
     'owned-publication?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g35062_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g35063_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-snapshots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g35064_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-sizes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g35065_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-position-of
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g35067_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g35068_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-snapshots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g35069_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-sizes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g35070_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-position-of-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g35072_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g35073_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-snapshots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g35074_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-sizes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g35075_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-position-of
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g35077_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g35078_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-snapshots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g35079_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-sizes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g35080_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-position-of-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[:0:]#owned-publication|
    (let ((__obj34846
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34846
         'gerbil-ascent/program/result#owned-publication::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34846 'owned-publication '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34846
         '(result snapshots sizes position-of)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34846
         '(result snapshots sizes position-of)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34846 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34846 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34846 '#t '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34846 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34846 '#f '13 '#f '#f))
      (let ((__tmp35055 |gerbil-ascent/program/result[1]#_g35056_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34846 __tmp35055 '4 '#f '#f))
      (let ((__tmp35057 |gerbil-ascent/program/result[1]#_g35058_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34846 __tmp35057 '14 '#f '#f))
      (let ((__tmp35059 |gerbil-ascent/program/result[1]#_g35060_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34846 __tmp35059 '15 '#f '#f))
      (let ((__tmp35061
             (cons (cons 'result |gerbil-ascent/program/result[1]#_g35062_|)
                   (cons (cons 'snapshots
                               |gerbil-ascent/program/result[1]#_g35063_|)
                         (cons (cons 'sizes
                                     |gerbil-ascent/program/result[1]#_g35064_|)
                               (cons (cons 'position-of
                                           |gerbil-ascent/program/result[1]#_g35065_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34846 __tmp35061 '16 '#f '#f))
      (let ((__tmp35066
             (cons (cons 'result |gerbil-ascent/program/result[1]#_g35067_|)
                   (cons (cons 'snapshots
                               |gerbil-ascent/program/result[1]#_g35068_|)
                         (cons (cons 'sizes
                                     |gerbil-ascent/program/result[1]#_g35069_|)
                               (cons (cons 'position-of
                                           |gerbil-ascent/program/result[1]#_g35070_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34846 __tmp35066 '17 '#f '#f))
      (let ((__tmp35071
             (cons (cons 'result |gerbil-ascent/program/result[1]#_g35072_|)
                   (cons (cons 'snapshots
                               |gerbil-ascent/program/result[1]#_g35073_|)
                         (cons (cons 'sizes
                                     |gerbil-ascent/program/result[1]#_g35074_|)
                               (cons (cons 'position-of
                                           |gerbil-ascent/program/result[1]#_g35075_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34846 __tmp35071 '18 '#f '#f))
      (let ((__tmp35076
             (cons (cons 'result |gerbil-ascent/program/result[1]#_g35077_|)
                   (cons (cons 'snapshots
                               |gerbil-ascent/program/result[1]#_g35078_|)
                         (cons (cons 'sizes
                                     |gerbil-ascent/program/result[1]#_g35079_|)
                               (cons (cons 'position-of
                                           |gerbil-ascent/program/result[1]#_g35080_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34846 __tmp35076 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34846 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34846 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34846 '() '21 '#f '#f))
      __obj34846)))
