(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/funs[:0:]#gerbil-ascent-index-batch!|
    (lambda (_%$stx3516%_)
      (let* ((_%$%g35203546%_
              (lambda (_%$%g35213542%_)
                (gx#raise-syntax-error
                 '#f
                 '"Bad syntax; invalid match target"
                 _%$%g35213542%_)))
             (_%$%g35193632%_
              (lambda (_%$%g35213550%_)
                (if (gx#stx-pair? _%$%g35213550%_)
                    (let ((_%$%e35263553%_ (gx#syntax-e _%$%g35213550%_)))
                      (let ((_%$%hd35273557%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e35263553%_)))
                            (_%$%tl35283560%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e35263553%_))))
                        (if (gx#stx-pair? _%$%tl35283560%_)
                            (let ((_%$%e35293563%_
                                   (gx#syntax-e _%$%tl35283560%_)))
                              (let ((_%$%hd35303567%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e35293563%_)))
                                    (_%$%tl35313570%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e35293563%_))))
                                (if (gx#stx-pair? _%$%tl35313570%_)
                                    (let ((_%$%e35323573%_
                                           (gx#syntax-e _%$%tl35313570%_)))
                                      (let ((_%$%hd35333577%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e35323573%_)))
                                            (_%$%tl35343580%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e35323573%_))))
                                        (if (gx#stx-pair? _%$%tl35343580%_)
                                            (let ((_%$%e35353583%_
                                                   (gx#syntax-e
                                                    _%$%tl35343580%_)))
                                              (let ((_%$%hd35363587%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e35353583%_)))
                                                    (_%$%tl35373590%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e35353583%_))))
                                                (if (gx#stx-pair?
                                                     _%$%tl35373590%_)
                                                    (let ((_%$%e35383593%_
                                                           (gx#syntax-e
                                                            _%$%tl35373590%_)))
                                                      (let ((_%$%hd35393597%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##car _%$%e35383593%_)))
                    (_%$%tl35403600%_
                     (let () (declare (not safe)) (##cdr _%$%e35383593%_))))
                (if (gx#stx-null? _%$%tl35403600%_)
                    (cons (gx#datum->syntax '#f 'let*)
                          (cons (cons (cons (gx#datum->syntax '#f 'target)
                                            (cons _%$%hd35303567%_ '()))
                                      (cons (cons (gx#datum->syntax
                                                   '#f
                                                   'row-slot)
                                                  (cons (cons (gx#datum->syntax
                                                               '#f
                                                               'vector)
                                                              (cons '#f '()))
                                                        '()))
                                            (cons (cons (gx#datum->syntax
                                                         '#f
                                                         'prepend-row)
                                                        (cons (cons (gx#datum->syntax
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             '#f
                             'lambda)
                            (cons (cons (gx#datum->syntax '#f 'bucket) '())
                                  (cons (cons (gx#datum->syntax '#f 'cons)
                                              (cons (cons (gx#datum->syntax
                                                           '#f
                                                           'vector-ref)
                                                          (cons (gx#datum->syntax
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '#f
                         'row-slot)
                        (cons '0 '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (cons (cons (gx#datum->syntax
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '#f
                         'or)
                        (cons (gx#datum->syntax '#f 'bucket)
                              (cons (cons (gx#datum->syntax '#f '@list) '())
                                    '())))
                  '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        '())))
                      '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  '())))
                                (cons (cons (gx#datum->syntax '#f 'for-each)
                                            (cons (cons (gx#datum->syntax
                                                         '#f
                                                         'lambda)
                                                        (cons (cons _%$%hd35363587%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            '())
                      (cons (cons (gx#datum->syntax '#f 'let)
                                  (cons (cons (gx#datum->syntax '#f 'selected)
                                              (cons _%$%hd35393597%_ '()))
                                        (cons (cons (gx#datum->syntax
                                                     '#f
                                                     'vector-set!)
                                                    (cons (gx#datum->syntax
                                                           '#f
                                                           'row-slot)
                                                          (cons '0
                                                                (cons _%$%hd35363587%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (cons (cons (gx#datum->syntax
                                                           '#f
                                                           'hash-update!)
                                                          (cons (gx#datum->syntax
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '#f
                         'target)
                        (cons (gx#datum->syntax '#f 'selected)
                              (cons (gx#datum->syntax '#f 'prepend-row)
                                    (cons '#f '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '()))))
                            '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons _%$%hd35333577%_ '())))
                                      (cons (gx#datum->syntax '#f 'target)
                                            '()))))
                    (_%$%g35203546%_ _%$%g35213550%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%g35203546%_
                                                     _%$%g35213550%_))))
                                            (_%$%g35203546%_
                                             _%$%g35213550%_))))
                                    (_%$%g35203546%_ _%$%g35213550%_))))
                            (_%$%g35203546%_ _%$%g35213550%_))))
                    (_%$%g35203546%_ _%$%g35213550%_)))))
        (_%$%g35193632%_ _%$stx3516%_))))
  (define |gerbil-ascent/table/funs[:0:]#forward-key-step|
    (lambda (_%$stx3636%_)
      (let* ((_%$%g36403681%_
              (lambda (_%$%g36413677%_)
                (gx#raise-syntax-error
                 '#f
                 '"Bad syntax; invalid match target"
                 _%$%g36413677%_)))
             (_%$%g36393818%_
              (lambda (_%$%g36413685%_)
                (if (gx#stx-pair? _%$%g36413685%_)
                    (let ((_%$%e36493688%_ (gx#syntax-e _%$%g36413685%_)))
                      (let ((_%$%hd36503692%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e36493688%_)))
                            (_%$%tl36513695%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e36493688%_))))
                        (if (gx#stx-pair? _%$%tl36513695%_)
                            (let ((_%$%e36523698%_
                                   (gx#syntax-e _%$%tl36513695%_)))
                              (let ((_%$%hd36533702%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e36523698%_)))
                                    (_%$%tl36543705%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e36523698%_))))
                                (if (gx#stx-pair? _%$%tl36543705%_)
                                    (let ((_%$%e36553708%_
                                           (gx#syntax-e _%$%tl36543705%_)))
                                      (let ((_%$%hd36563712%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e36553708%_)))
                                            (_%$%tl36573715%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e36553708%_))))
                                        (if (gx#stx-pair? _%$%tl36573715%_)
                                            (let ((_%$%e36583718%_
                                                   (gx#syntax-e
                                                    _%$%tl36573715%_)))
                                              (let ((_%$%hd36593722%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e36583718%_)))
                                                    (_%$%tl36603725%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e36583718%_))))
                                                (if (gx#stx-pair?
                                                     _%$%hd36593722%_)
                                                    (let ((_%$%e36613728%_
                                                           (gx#syntax-e
                                                            _%$%hd36593722%_)))
                                                      (let ((_%$%hd36623732%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##car _%$%e36613728%_)))
                    (_%$%tl36633735%_
                     (let () (declare (not safe)) (##cdr _%$%e36613728%_))))
                (if (gx#stx-pair? _%$%tl36633735%_)
                    (let ((_%$%e36643738%_ (gx#syntax-e _%$%tl36633735%_)))
                      (let ((_%$%hd36653742%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e36643738%_)))
                            (_%$%tl36663745%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e36643738%_))))
                        (if (gx#stx-pair? _%$%tl36663745%_)
                            (let ((_%$%e36673748%_
                                   (gx#syntax-e _%$%tl36663745%_)))
                              (let ((_%$%hd36683752%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e36673748%_)))
                                    (_%$%tl36693755%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e36673748%_))))
                                (if (gx#stx-null? _%$%tl36693755%_)
                                    (if (gx#stx-pair? _%$%tl36603725%_)
                                        (let ((_%$%e36703758%_
                                               (gx#syntax-e _%$%tl36603725%_)))
                                          (let ((_%$%hd36713762%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e36703758%_)))
                                                (_%$%tl36723765%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e36703758%_))))
                                            (if (gx#stx-pair? _%$%tl36723765%_)
                                                (let ((_%$%e36733768%_
                                                       (gx#syntax-e
                                                        _%$%tl36723765%_)))
                                                  (let ((_%$%hd36743772%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e36733768%_)))
                                                        (_%$%tl36753775%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e36733768%_))))
                                                    (if (gx#stx-null?
                                                         _%$%tl36753775%_)
                                                        (cons (gx#datum->syntax
                                                               '#f
                                                               'match)
                                                              (cons _%$%hd36563712%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons (cons (cons (gx#datum->syntax '#f '@list)
                                              '())
                                        (cons (cons (gx#datum->syntax
                                                     '#f
                                                     '@list)
                                                    '())
                                              '()))
                                  (cons (cons (cons (gx#datum->syntax
                                                     '#f
                                                     '@list)
                                                    (cons _%$%hd36623732%_
                                                          _%$%hd36653742%_))
                                              (cons (cons (gx#datum->syntax
                                                           '#f
                                                           'let)
                                                          (cons (cons _%$%hd36683752%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons (cons (gx#datum->syntax '#f 'list-tail)
                                          (cons _%$%hd36533702%_
                                                (cons _%$%hd36713762%_ '())))
                                    '()))
                        (cons (cons (gx#datum->syntax '#f 'cons)
                                    (cons (cons (gx#datum->syntax '#f 'car)
                                                (cons _%$%hd36683752%_ '()))
                                          (cons _%$%hd36743772%_ '())))
                              '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '()))
                                        '()))))
                (_%$%g36403681%_ _%$%g36413685%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (_%$%g36403681%_
                                                 _%$%g36413685%_))))
                                        (_%$%g36403681%_ _%$%g36413685%_))
                                    (_%$%g36403681%_ _%$%g36413685%_))))
                            (_%$%g36403681%_ _%$%g36413685%_))))
                    (_%$%g36403681%_ _%$%g36413685%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%g36403681%_
                                                     _%$%g36413685%_))))
                                            (_%$%g36403681%_
                                             _%$%g36413685%_))))
                                    (_%$%g36403681%_ _%$%g36413685%_))))
                            (_%$%g36403681%_ _%$%g36413685%_))))
                    (_%$%g36403681%_ _%$%g36413685%_)))))
        (_%$%g36393818%_ _%$stx3636%_)))))
