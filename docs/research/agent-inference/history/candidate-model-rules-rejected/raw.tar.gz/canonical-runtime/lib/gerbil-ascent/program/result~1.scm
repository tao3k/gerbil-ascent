(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/result[1]#_g34454_|
    (##structure
     gx#syntax-quote::t
     'owned-publication::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34456_|
    (##structure
     gx#syntax-quote::t
     'make-owned-publication
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34458_|
    (##structure
     gx#syntax-quote::t
     'owned-publication?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34460_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34461_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-snapshots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34462_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-sizes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34463_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-position-of
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34465_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34466_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-snapshots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34467_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-sizes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34468_|
    (##structure
     gx#syntax-quote::t
     'owned-publication-position-of-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34470_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34471_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-snapshots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34472_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-sizes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34473_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-position-of
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34475_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34476_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-snapshots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34477_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-sizes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[1]#_g34478_|
    (##structure
     gx#syntax-quote::t
     '&owned-publication-position-of-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/result[:0:]#owned-publication|
    (let ((__obj34185
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34185
         'gerbil-ascent/program/result#owned-publication::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34185 'owned-publication '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34185
         '(result snapshots sizes position-of)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34185
         '(result snapshots sizes position-of)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34185 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34185 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34185 '#t '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34185 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34185 '#f '13 '#f '#f))
      (let ((__tmp34453 |gerbil-ascent/program/result[1]#_g34454_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34185 __tmp34453 '4 '#f '#f))
      (let ((__tmp34455 |gerbil-ascent/program/result[1]#_g34456_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34185 __tmp34455 '14 '#f '#f))
      (let ((__tmp34457 |gerbil-ascent/program/result[1]#_g34458_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34185 __tmp34457 '15 '#f '#f))
      (let ((__tmp34459
             (cons (cons 'result |gerbil-ascent/program/result[1]#_g34460_|)
                   (cons (cons 'snapshots
                               |gerbil-ascent/program/result[1]#_g34461_|)
                         (cons (cons 'sizes
                                     |gerbil-ascent/program/result[1]#_g34462_|)
                               (cons (cons 'position-of
                                           |gerbil-ascent/program/result[1]#_g34463_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34185 __tmp34459 '16 '#f '#f))
      (let ((__tmp34464
             (cons (cons 'result |gerbil-ascent/program/result[1]#_g34465_|)
                   (cons (cons 'snapshots
                               |gerbil-ascent/program/result[1]#_g34466_|)
                         (cons (cons 'sizes
                                     |gerbil-ascent/program/result[1]#_g34467_|)
                               (cons (cons 'position-of
                                           |gerbil-ascent/program/result[1]#_g34468_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34185 __tmp34464 '17 '#f '#f))
      (let ((__tmp34469
             (cons (cons 'result |gerbil-ascent/program/result[1]#_g34470_|)
                   (cons (cons 'snapshots
                               |gerbil-ascent/program/result[1]#_g34471_|)
                         (cons (cons 'sizes
                                     |gerbil-ascent/program/result[1]#_g34472_|)
                               (cons (cons 'position-of
                                           |gerbil-ascent/program/result[1]#_g34473_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34185 __tmp34469 '18 '#f '#f))
      (let ((__tmp34474
             (cons (cons 'result |gerbil-ascent/program/result[1]#_g34475_|)
                   (cons (cons 'snapshots
                               |gerbil-ascent/program/result[1]#_g34476_|)
                         (cons (cons 'sizes
                                     |gerbil-ascent/program/result[1]#_g34477_|)
                               (cons (cons 'position-of
                                           |gerbil-ascent/program/result[1]#_g34478_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34185 __tmp34474 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34185 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34185 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34185 '() '21 '#f '#f))
      __obj34185)))
