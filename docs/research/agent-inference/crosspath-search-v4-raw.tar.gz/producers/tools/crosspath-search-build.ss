;;; SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
(import (only-in :gerbil/compiler compile-exe execute-pending-compile-jobs!))
(export main)
(def (main . args)
  (compile-exe "tools/crosspath-search.ss"
    [output-dir: (path-expand "lib" (gerbil-path))
     output-file: (path-expand "bin/crosspath-search" (gerbil-path))
     invoke-gsc: #t keep-scm: #t parallel: #t])
  (execute-pending-compile-jobs!)
  (displayln "CROSSPATH-SEARCH-BUILD-OK")
  (exit 0))
