(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/access::timestamp 1791691005)
  (begin
    (define gerbil-ascent/table/access#extend-scalar-index!
      (lambda (_%index14217%_ _%rows14218%_ _%column14219%_)
        (let* ((_%target14221%_ _%index14217%_)
               (_%row-slot14224%_ (vector '#f))
               (_%prepend-row14233%_
                (lambda (_%bucket14227%_)
                  (cons (vector-ref _%row-slot14224%_ '0)
                        (let ((_%$e14230%_ _%bucket14227%_))
                          (if _%$e14230%_ _%$e14230%_ '()))))))
          (for-each
           (lambda (_%row14237%_)
             (let ((_%selected14239%_ (list-ref _%row14237%_ _%column14219%_)))
               (vector-set! _%row-slot14224%_ '0 _%row14237%_)
               (let ()
                 (declare (not safe))
                 (hash-update!__%
                  _%target14221%_
                  _%selected14239%_
                  _%prepend-row14233%_
                  '#f))))
           _%rows14218%_)
          _%target14221%_)))
    (define gerbil-ascent/table/access#gerbil-ascent-physical-index-single-rows
      (lambda (_%index14211%_ _%value14212%_)
        (let ((_%$e14214%_
               (let ()
                 (declare (not safe))
                 (hash-get _%index14211%_ _%value14212%_))))
          (if _%$e14214%_ _%$e14214%_ '()))))
    (define gerbil-ascent/table/access#gerbil-ascent-physical-index-build
      (lambda (_%provider14207%_ _%rows14208%_ _%columns14209%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
               _%provider14207%_))
            (if (and (pair? _%columns14209%_)
                     (null? (let ()
                              (declare (not safe))
                              (##cdr _%columns14209%_))))
                (let ((__tmp35183
                       (gerbil-ascent/table/access#extend-scalar-index!
                        (let ()
                          (declare (not safe))
                          (make-hash-table__%
                           '#f
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value))
                        _%rows14208%_
                        (car _%columns14209%_))))
                  (declare (not safe))
                  (gerbil-ascent/table/funs#gerbil-ascent-index-order!
                   __tmp35183))
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/table/funs#gerbil-ascent-index-build
                   _%rows14208%_
                   _%columns14209%_)))
            (let ((__tmp35185
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/table/funs#gerbil-ascent-index-row-snapshot
                      _%rows14208%_)))
                  (__tmp35184 (map values _%columns14209%_)))
              (declare (not safe))
              (gerbil-ascent/table/provider#gerbil-ascent-index-provider-build
               _%provider14207%_
               __tmp35185
               __tmp35184)))))
    (define gerbil-ascent/table/access#gerbil-ascent-physical-index-extend!
      (lambda (_%provider14202%_ _%index14203%_ _%rows14204%_ _%columns14205%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
               _%provider14202%_))
            (if (and (pair? _%columns14205%_)
                     (null? (let ()
                              (declare (not safe))
                              (##cdr _%columns14205%_))))
                (gerbil-ascent/table/access#extend-scalar-index!
                 _%index14203%_
                 _%rows14204%_
                 (car _%columns14205%_))
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/table/funs#gerbil-ascent-index-extend!
                   _%index14203%_
                   _%rows14204%_
                   _%columns14205%_)))
            (let ((__tmp35187
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/table/funs#gerbil-ascent-index-row-snapshot
                      _%rows14204%_)))
                  (__tmp35186 (map values _%columns14205%_)))
              (declare (not safe))
              (gerbil-ascent/table/provider#gerbil-ascent-index-provider-extend!
               _%provider14202%_
               _%index14203%_
               __tmp35187
               __tmp35186)))))
    (define gerbil-ascent/table/access#gerbil-ascent-physical-index-rows
      (lambda (_%provider14193%_ _%index14194%_ _%key14195%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
               _%provider14193%_))
            (if (and (pair? _%key14195%_)
                     (null? (let ()
                              (declare (not safe))
                              (##cdr _%key14195%_))))
                (gerbil-ascent/table/access#gerbil-ascent-physical-index-single-rows
                 _%index14194%_
                 (car _%key14195%_))
                (let ((_%$e14197%_
                       (let ()
                         (declare (not safe))
                         (hash-get _%index14194%_ _%key14195%_))))
                  (if _%$e14197%_ _%$e14197%_ '())))
            (let ((_%matched14200%_
                   (let ((__tmp35188 (map values _%key14195%_)))
                     (declare (not safe))
                     (gerbil-ascent/table/provider#gerbil-ascent-index-provider-lookup
                      _%provider14193%_
                      _%index14194%_
                      __tmp35188))))
              (if (list? _%matched14200%_)
                  '#!void
                  (let ()
                    (declare (not safe))
                    (error '"ASCENT index provider returned non-list rows"
                           _%matched14200%_)))
              _%matched14200%_))))))
