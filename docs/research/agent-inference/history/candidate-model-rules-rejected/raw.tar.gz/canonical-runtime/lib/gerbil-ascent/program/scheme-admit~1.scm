(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/scheme-admit[1]#_g37888_|
    (##structure
     gx#syntax-quote::t
     'relational-admission::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37890_|
    (##structure
     gx#syntax-quote::t
     'make-relational-admission
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37892_|
    (##structure
     gx#syntax-quote::t
     'relational-admission?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37894_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-run
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37896_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-run-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37898_|
    (##structure
     gx#syntax-quote::t
     '&relational-admission-run
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37900_|
    (##structure
     gx#syntax-quote::t
     '&relational-admission-run-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37902_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37904_|
    (##structure
     gx#syntax-quote::t
     'make-relational-diagnostic
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37906_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37908_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic-code
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37909_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic-path
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37910_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic-detail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37912_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic-code-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37913_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic-path-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37914_|
    (##structure
     gx#syntax-quote::t
     'relational-diagnostic-detail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37916_|
    (##structure
     gx#syntax-quote::t
     '&relational-diagnostic-code
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37917_|
    (##structure
     gx#syntax-quote::t
     '&relational-diagnostic-path
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37918_|
    (##structure
     gx#syntax-quote::t
     '&relational-diagnostic-detail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37920_|
    (##structure
     gx#syntax-quote::t
     '&relational-diagnostic-code-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37921_|
    (##structure
     gx#syntax-quote::t
     '&relational-diagnostic-path-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37922_|
    (##structure
     gx#syntax-quote::t
     '&relational-diagnostic-detail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37924_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-report::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37926_|
    (##structure
     gx#syntax-quote::t
     'make-relational-admission-report
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37928_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-report?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37930_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-report-admission
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37931_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-report-diagnostic
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37933_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-report-admission-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37934_|
    (##structure
     gx#syntax-quote::t
     'relational-admission-report-diagnostic-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37936_|
    (##structure
     gx#syntax-quote::t
     '&relational-admission-report-admission
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37937_|
    (##structure
     gx#syntax-quote::t
     '&relational-admission-report-diagnostic
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37939_|
    (##structure
     gx#syntax-quote::t
     '&relational-admission-report-admission-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-admit[1]#_g37940_|
    (##structure
     gx#syntax-quote::t
     '&relational-admission-report-diagnostic-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/scheme-admit[:0:]#relational-admission|
      (let ((__obj37783
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37783
           'gerbil-ascent/program/scheme-admit#relational-admission::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37783
           'relational-admission
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37783 '(run) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37783 '(run) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37783 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37783 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37783 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37783 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37783 '#f '13 '#f '#f))
        (let ((__tmp37887 |gerbil-ascent/program/scheme-admit[1]#_g37888_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37783 __tmp37887 '4 '#f '#f))
        (let ((__tmp37889 |gerbil-ascent/program/scheme-admit[1]#_g37890_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37783 __tmp37889 '14 '#f '#f))
        (let ((__tmp37891 |gerbil-ascent/program/scheme-admit[1]#_g37892_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37783 __tmp37891 '15 '#f '#f))
        (let ((__tmp37893
               (cons (cons 'run
                           |gerbil-ascent/program/scheme-admit[1]#_g37894_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj37783 __tmp37893 '16 '#f '#f))
        (let ((__tmp37895
               (cons (cons 'run
                           |gerbil-ascent/program/scheme-admit[1]#_g37896_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj37783 __tmp37895 '17 '#f '#f))
        (let ((__tmp37897
               (cons (cons 'run
                           |gerbil-ascent/program/scheme-admit[1]#_g37898_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj37783 __tmp37897 '18 '#f '#f))
        (let ((__tmp37899
               (cons (cons 'run
                           |gerbil-ascent/program/scheme-admit[1]#_g37900_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj37783 __tmp37899 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37783 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37783 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37783 '() '21 '#f '#f))
        __obj37783))
    (define |gerbil-ascent/program/scheme-admit[:0:]#relational-diagnostic|
      (let ((__obj37784
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37784
           'gerbil-ascent/program/scheme-admit#relational-diagnostic::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37784
           'relational-diagnostic
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37784
           '(code path detail)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37784
           '(code path detail)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37784 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37784 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37784 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37784 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37784 '#f '13 '#f '#f))
        (let ((__tmp37901 |gerbil-ascent/program/scheme-admit[1]#_g37902_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37784 __tmp37901 '4 '#f '#f))
        (let ((__tmp37903 |gerbil-ascent/program/scheme-admit[1]#_g37904_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37784 __tmp37903 '14 '#f '#f))
        (let ((__tmp37905 |gerbil-ascent/program/scheme-admit[1]#_g37906_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37784 __tmp37905 '15 '#f '#f))
        (let ((__tmp37907
               (cons (cons 'code
                           |gerbil-ascent/program/scheme-admit[1]#_g37908_|)
                     (cons (cons 'path
                                 |gerbil-ascent/program/scheme-admit[1]#_g37909_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/program/scheme-admit[1]#_g37910_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37784 __tmp37907 '16 '#f '#f))
        (let ((__tmp37911
               (cons (cons 'code
                           |gerbil-ascent/program/scheme-admit[1]#_g37912_|)
                     (cons (cons 'path
                                 |gerbil-ascent/program/scheme-admit[1]#_g37913_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/program/scheme-admit[1]#_g37914_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37784 __tmp37911 '17 '#f '#f))
        (let ((__tmp37915
               (cons (cons 'code
                           |gerbil-ascent/program/scheme-admit[1]#_g37916_|)
                     (cons (cons 'path
                                 |gerbil-ascent/program/scheme-admit[1]#_g37917_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/program/scheme-admit[1]#_g37918_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37784 __tmp37915 '18 '#f '#f))
        (let ((__tmp37919
               (cons (cons 'code
                           |gerbil-ascent/program/scheme-admit[1]#_g37920_|)
                     (cons (cons 'path
                                 |gerbil-ascent/program/scheme-admit[1]#_g37921_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/program/scheme-admit[1]#_g37922_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37784 __tmp37919 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37784 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37784 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37784 '() '21 '#f '#f))
        __obj37784))
    (define |gerbil-ascent/program/scheme-admit[:0:]#relational-admission-report|
      (let ((__obj37785
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37785
           'gerbil-ascent/program/scheme-admit#relational-admission-report::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37785
           'relational-admission-report
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37785
           '(admission diagnostic)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37785
           '(admission diagnostic)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37785 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37785 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37785 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37785 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37785 '#f '13 '#f '#f))
        (let ((__tmp37923 |gerbil-ascent/program/scheme-admit[1]#_g37924_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37785 __tmp37923 '4 '#f '#f))
        (let ((__tmp37925 |gerbil-ascent/program/scheme-admit[1]#_g37926_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37785 __tmp37925 '14 '#f '#f))
        (let ((__tmp37927 |gerbil-ascent/program/scheme-admit[1]#_g37928_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37785 __tmp37927 '15 '#f '#f))
        (let ((__tmp37929
               (cons (cons 'admission
                           |gerbil-ascent/program/scheme-admit[1]#_g37930_|)
                     (cons (cons 'diagnostic
                                 |gerbil-ascent/program/scheme-admit[1]#_g37931_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37785 __tmp37929 '16 '#f '#f))
        (let ((__tmp37932
               (cons (cons 'admission
                           |gerbil-ascent/program/scheme-admit[1]#_g37933_|)
                     (cons (cons 'diagnostic
                                 |gerbil-ascent/program/scheme-admit[1]#_g37934_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37785 __tmp37932 '17 '#f '#f))
        (let ((__tmp37935
               (cons (cons 'admission
                           |gerbil-ascent/program/scheme-admit[1]#_g37936_|)
                     (cons (cons 'diagnostic
                                 |gerbil-ascent/program/scheme-admit[1]#_g37937_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37785 __tmp37935 '18 '#f '#f))
        (let ((__tmp37938
               (cons (cons 'admission
                           |gerbil-ascent/program/scheme-admit[1]#_g37939_|)
                     (cons (cons 'diagnostic
                                 |gerbil-ascent/program/scheme-admit[1]#_g37940_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37785 __tmp37938 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37785 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37785 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37785 '() '21 '#f '#f))
        __obj37785))))
