(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34311_|
    (##structure
     gx#syntax-quote::t
     'lattice-round::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34313_|
    (##structure
     gx#syntax-quote::t
     'make-lattice-round
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34315_|
    (##structure
     gx#syntax-quote::t
     'lattice-round?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34317_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-table
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34318_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-changes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34319_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-sequence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34320_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-ordered?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34322_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-table-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34323_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-changes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34324_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-sequence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34325_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-ordered?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34327_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-table
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34328_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-changes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34329_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-sequence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34330_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-ordered?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34332_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-table-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34333_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-changes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34334_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-sequence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34335_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-ordered?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34337_|
    (##structure
     gx#syntax-quote::t
     'lattice-change::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34339_|
    (##structure
     gx#syntax-quote::t
     'make-lattice-change
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34341_|
    (##structure
     gx#syntax-quote::t
     'lattice-change?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34343_|
    (##structure
     gx#syntax-quote::t
     'lattice-change-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34344_|
    (##structure
     gx#syntax-quote::t
     'lattice-change-sequence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34346_|
    (##structure
     gx#syntax-quote::t
     'lattice-change-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34347_|
    (##structure
     gx#syntax-quote::t
     'lattice-change-sequence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34349_|
    (##structure
     gx#syntax-quote::t
     '&lattice-change-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34350_|
    (##structure
     gx#syntax-quote::t
     '&lattice-change-sequence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34352_|
    (##structure
     gx#syntax-quote::t
     '&lattice-change-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34353_|
    (##structure
     gx#syntax-quote::t
     '&lattice-change-sequence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34355_|
    (gx#core-deserialize-mark
     '(0
       (id . _%id15707%_)
       (arg . _%arg15770%_)
       ($%arg15683 . _%$%arg1568315754%_)
       ($%arg15682 . _%$%arg1568215740%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34356_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g34355_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34359_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34360_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g34359_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34362_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g34359_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34364_|
    (gx#core-deserialize-mark
     '(0
       (id . _%id15827%_)
       (arg . _%arg15890%_)
       ($%arg15804 . _%$%arg1580415874%_)
       ($%arg15803 . _%$%arg1580315860%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34365_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g34364_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34368_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34369_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g34368_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34371_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g34368_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34373_|
    (gx#core-deserialize-mark
     '(0
       (id . _%id15947%_)
       ($%arg15923 . _%$%arg1592315980%_)
       (arg . _%arg16010%_)
       ($%arg15924 . _%$%arg1592415994%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34374_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g34373_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34377_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34378_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g34377_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34380_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g34377_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34382_|
    (gx#core-deserialize-mark
     '(0
       ($%arg16044 . _%$%arg1604416114%_)
       (id . _%id16067%_)
       ($%arg16043 . _%$%arg1604316100%_)
       (arg . _%arg16130%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34383_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g34382_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34386_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34387_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g34386_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g34389_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g34386_|)))
  (begin
    (define |gerbil-ascent/program/lattice-frontier[:0:]#lattice-round|
      (let ((__obj34254
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34254
           'gerbil-ascent/program/lattice-frontier#lattice-round::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 'lattice-round '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34254
           '(table changes sequence ordered?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34254
           '(table changes sequence ordered?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 '#f '13 '#f '#f))
        (let ((__tmp34310
               |gerbil-ascent/program/lattice-frontier[1]#_g34311_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 __tmp34310 '4 '#f '#f))
        (let ((__tmp34312
               |gerbil-ascent/program/lattice-frontier[1]#_g34313_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 __tmp34312 '14 '#f '#f))
        (let ((__tmp34314
               |gerbil-ascent/program/lattice-frontier[1]#_g34315_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 __tmp34314 '15 '#f '#f))
        (let ((__tmp34316
               (cons (cons 'table
                           |gerbil-ascent/program/lattice-frontier[1]#_g34317_|)
                     (cons (cons 'changes
                                 |gerbil-ascent/program/lattice-frontier[1]#_g34318_|)
                           (cons (cons 'sequence
                                       |gerbil-ascent/program/lattice-frontier[1]#_g34319_|)
                                 (cons (cons 'ordered?
                                             |gerbil-ascent/program/lattice-frontier[1]#_g34320_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 __tmp34316 '16 '#f '#f))
        (let ((__tmp34321
               (cons (cons 'table
                           |gerbil-ascent/program/lattice-frontier[1]#_g34322_|)
                     (cons (cons 'changes
                                 |gerbil-ascent/program/lattice-frontier[1]#_g34323_|)
                           (cons (cons 'sequence
                                       |gerbil-ascent/program/lattice-frontier[1]#_g34324_|)
                                 (cons (cons 'ordered?
                                             |gerbil-ascent/program/lattice-frontier[1]#_g34325_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 __tmp34321 '17 '#f '#f))
        (let ((__tmp34326
               (cons (cons 'table
                           |gerbil-ascent/program/lattice-frontier[1]#_g34327_|)
                     (cons (cons 'changes
                                 |gerbil-ascent/program/lattice-frontier[1]#_g34328_|)
                           (cons (cons 'sequence
                                       |gerbil-ascent/program/lattice-frontier[1]#_g34329_|)
                                 (cons (cons 'ordered?
                                             |gerbil-ascent/program/lattice-frontier[1]#_g34330_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 __tmp34326 '18 '#f '#f))
        (let ((__tmp34331
               (cons (cons 'table
                           |gerbil-ascent/program/lattice-frontier[1]#_g34332_|)
                     (cons (cons 'changes
                                 |gerbil-ascent/program/lattice-frontier[1]#_g34333_|)
                           (cons (cons 'sequence
                                       |gerbil-ascent/program/lattice-frontier[1]#_g34334_|)
                                 (cons (cons 'ordered?
                                             |gerbil-ascent/program/lattice-frontier[1]#_g34335_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 __tmp34331 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34254 '() '21 '#f '#f))
        __obj34254))
    (define |gerbil-ascent/program/lattice-frontier[:0:]#lattice-change|
      (let ((__obj34255
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34255
           'gerbil-ascent/program/lattice-frontier#lattice-change::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 'lattice-change '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '(row sequence) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '(row sequence) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '#f '13 '#f '#f))
        (let ((__tmp34336
               |gerbil-ascent/program/lattice-frontier[1]#_g34337_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 __tmp34336 '4 '#f '#f))
        (let ((__tmp34338
               |gerbil-ascent/program/lattice-frontier[1]#_g34339_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 __tmp34338 '14 '#f '#f))
        (let ((__tmp34340
               |gerbil-ascent/program/lattice-frontier[1]#_g34341_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 __tmp34340 '15 '#f '#f))
        (let ((__tmp34342
               (cons (cons 'row
                           |gerbil-ascent/program/lattice-frontier[1]#_g34343_|)
                     (cons (cons 'sequence
                                 |gerbil-ascent/program/lattice-frontier[1]#_g34344_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 __tmp34342 '16 '#f '#f))
        (let ((__tmp34345
               (cons (cons 'row
                           |gerbil-ascent/program/lattice-frontier[1]#_g34346_|)
                     (cons (cons 'sequence
                                 |gerbil-ascent/program/lattice-frontier[1]#_g34347_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 __tmp34345 '17 '#f '#f))
        (let ((__tmp34348
               (cons (cons 'row
                           |gerbil-ascent/program/lattice-frontier[1]#_g34349_|)
                     (cons (cons 'sequence
                                 |gerbil-ascent/program/lattice-frontier[1]#_g34350_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 __tmp34348 '18 '#f '#f))
        (let ((__tmp34351
               (cons (cons 'row
                           |gerbil-ascent/program/lattice-frontier[1]#_g34352_|)
                     (cons (cons 'sequence
                                 |gerbil-ascent/program/lattice-frontier[1]#_g34353_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 __tmp34351 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34255 '() '21 '#f '#f))
        __obj34255))
    (define |gerbil-ascent/program/lattice-frontier[:0:]#@lattice-frontier-ref|
      (lambda (_%$stx15664%_)
        (let* ((_%__stx3415134152%_ _%$stx15664%_)
               (_%$%g1566915690%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3415134152%_)))))
          (let ((_%__kont3415434155%_
                 (lambda (_%$%g1567115756%_)
                   (cons (let ((__tmp34354
                                |gerbil-ascent/program/lattice-frontier[1]#_g34356_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp34354
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'frontier))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'key))
                                                 '()))
                                     (cons (let ((__tmp34357
                                                  (lambda (_%$%g1577115774%_
                                                           _%$%g1577215777%_)
                                                    (cons _%$%g1577115774%_
                                                          _%$%g1577215777%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp34357
                                              '()
                                              _%$%g1567115756%_))
                                           '()))
                               (cons (cons (let ((__tmp34358
                                                  |gerbil-ascent/program/lattice-frontier[1]#_g34360_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp34358
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'frontier))
                     (cons (let ((__tmp34361
                                  |gerbil-ascent/program/lattice-frontier[1]#_g34362_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp34361 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'lattice-round))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f '__lattice-frontier-ref))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'frontier))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'key))
                                 '())))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3415834159%_
                 (lambda (_%$%g1568415697%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0 '#f 'lattice-frontier-ref)))))
            (let* ((_%$%g1566815709%_
                    (lambda ()
                      (let ((_%$%g1568415697%_ _%__stx3415134152%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1568415697%_))
                            (_%__kont3415834159%_ _%$%g1568415697%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1566915690%_))))))
                   (_%__match3417434175%_
                    (lambda (_%$%e1567215716%_
                             _%$%hd1567315720%_
                             _%$%tl1567415723%_
                             _%__splice3415634157%_
                             _%$%target1567515726%_
                             _%$%tl1567715729%_)
                      (letrec ((_%$%loop1567815732%_
                                (lambda (_%$%hd1567615736%_
                                         _%$%arg1568215739%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1567615736%_))
                                      (let ((_%$%e1567915742%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1567615736%_))))
                                        (let ((_%$%lp-tl1568115749%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1567915742%_)))
                                              (_%$%lp-hd1568015746%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1567915742%_))))
                                          (_%$%loop1567815732%_
                                           _%$%lp-tl1568115749%_
                                           (cons _%$%lp-hd1568015746%_
                                                 _%$%arg1568215739%_))))
                                      (let ((_%$%arg1568315752%_
                                             (reverse _%$%arg1568215739%_)))
                                        (_%__kont3415434155%_
                                         _%$%arg1568315752%_))))))
                        (_%$%loop1567815732%_ _%$%target1567515726%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3415134152%_))
                  (let ((_%$%e1567215716%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3415134152%_))))
                    (let ((_%$%tl1567415723%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1567215716%_)))
                          (_%$%hd1567315720%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1567215716%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1567415723%_))
                          (let ((_%__splice3415634157%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1567415723%_
                                    '0))))
                            (let ((_%$%tl1567715729%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3415634157%_ '1)))
                                  (_%$%target1567515726%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3415634157%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1567715729%_))
                                  (_%__match3417434175%_
                                   _%$%e1567215716%_
                                   _%$%hd1567315720%_
                                   _%$%tl1567415723%_
                                   _%__splice3415634157%_
                                   _%$%target1567515726%_
                                   _%$%tl1567715729%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1566815709%_)))))
                          (let () (declare (not safe)) (_%$%g1566815709%_)))))
                  (let () (declare (not safe)) (_%$%g1566815709%_))))))))
    (define |gerbil-ascent/program/lattice-frontier[:0:]#@lattice-frontier-stage!|
      (lambda (_%$stx15785%_)
        (let* ((_%__stx3417734178%_ _%$stx15785%_)
               (_%$%g1579015811%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3417734178%_)))))
          (let ((_%__kont3418034181%_
                 (lambda (_%$%g1579215876%_)
                   (cons (let ((__tmp34363
                                |gerbil-ascent/program/lattice-frontier[1]#_g34365_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp34363
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'frontier))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'key))
                                                 (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'row))
                                                       '())))
                                     (cons (let ((__tmp34366
                                                  (lambda (_%$%g1589115894%_
                                                           _%$%g1589215897%_)
                                                    (cons _%$%g1589115894%_
                                                          _%$%g1589215897%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp34366
                                              '()
                                              _%$%g1579215876%_))
                                           '()))
                               (cons (cons (let ((__tmp34367
                                                  |gerbil-ascent/program/lattice-frontier[1]#_g34369_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp34367
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'frontier))
                     (cons (let ((__tmp34370
                                  |gerbil-ascent/program/lattice-frontier[1]#_g34371_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp34370 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'lattice-round))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f '__lattice-frontier-stage!))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'frontier))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'key))
                                 (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'row))
                                       '()))))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3418434185%_
                 (lambda (_%$%g1580515818%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0 '#f 'lattice-frontier-stage!)))))
            (let* ((_%$%g1578915829%_
                    (lambda ()
                      (let ((_%$%g1580515818%_ _%__stx3417734178%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1580515818%_))
                            (_%__kont3418434185%_ _%$%g1580515818%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1579015811%_))))))
                   (_%__match3420034201%_
                    (lambda (_%$%e1579315836%_
                             _%$%hd1579415840%_
                             _%$%tl1579515843%_
                             _%__splice3418234183%_
                             _%$%target1579615846%_
                             _%$%tl1579815849%_)
                      (letrec ((_%$%loop1579915852%_
                                (lambda (_%$%hd1579715856%_
                                         _%$%arg1580315859%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1579715856%_))
                                      (let ((_%$%e1580015862%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1579715856%_))))
                                        (let ((_%$%lp-tl1580215869%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1580015862%_)))
                                              (_%$%lp-hd1580115866%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1580015862%_))))
                                          (_%$%loop1579915852%_
                                           _%$%lp-tl1580215869%_
                                           (cons _%$%lp-hd1580115866%_
                                                 _%$%arg1580315859%_))))
                                      (let ((_%$%arg1580415872%_
                                             (reverse _%$%arg1580315859%_)))
                                        (_%__kont3418034181%_
                                         _%$%arg1580415872%_))))))
                        (_%$%loop1579915852%_ _%$%target1579615846%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3417734178%_))
                  (let ((_%$%e1579315836%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3417734178%_))))
                    (let ((_%$%tl1579515843%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1579315836%_)))
                          (_%$%hd1579415840%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1579315836%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1579515843%_))
                          (let ((_%__splice3418234183%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1579515843%_
                                    '0))))
                            (let ((_%$%tl1579815849%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3418234183%_ '1)))
                                  (_%$%target1579615846%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3418234183%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1579815849%_))
                                  (_%__match3420034201%_
                                   _%$%e1579315836%_
                                   _%$%hd1579415840%_
                                   _%$%tl1579515843%_
                                   _%__splice3418234183%_
                                   _%$%target1579615846%_
                                   _%$%tl1579815849%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1578915829%_)))))
                          (let () (declare (not safe)) (_%$%g1578915829%_)))))
                  (let () (declare (not safe)) (_%$%g1578915829%_))))))))
    (define |gerbil-ascent/program/lattice-frontier[:0:]#@lattice-frontier-rows|
      (lambda (_%$stx15905%_)
        (let* ((_%__stx3420334204%_ _%$stx15905%_)
               (_%$%g1591015931%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3420334204%_)))))
          (let ((_%__kont3420634207%_
                 (lambda (_%$%g1591215996%_)
                   (cons (let ((__tmp34372
                                |gerbil-ascent/program/lattice-frontier[1]#_g34374_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp34372
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'frontier))
                                           '())
                                     (cons (let ((__tmp34375
                                                  (lambda (_%$%g1601116014%_
                                                           _%$%g1601216017%_)
                                                    (cons _%$%g1601116014%_
                                                          _%$%g1601216017%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp34375
                                              '()
                                              _%$%g1591215996%_))
                                           '()))
                               (cons (cons (let ((__tmp34376
                                                  |gerbil-ascent/program/lattice-frontier[1]#_g34378_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp34376
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'frontier))
                     (cons (let ((__tmp34379
                                  |gerbil-ascent/program/lattice-frontier[1]#_g34380_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp34379 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'lattice-round))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f '__lattice-frontier-rows))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'frontier))
                           '()))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3421034211%_
                 (lambda (_%$%g1592515938%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0 '#f 'lattice-frontier-rows)))))
            (let* ((_%$%g1590915949%_
                    (lambda ()
                      (let ((_%$%g1592515938%_ _%__stx3420334204%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1592515938%_))
                            (_%__kont3421034211%_ _%$%g1592515938%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1591015931%_))))))
                   (_%__match3422634227%_
                    (lambda (_%$%e1591315956%_
                             _%$%hd1591415960%_
                             _%$%tl1591515963%_
                             _%__splice3420834209%_
                             _%$%target1591615966%_
                             _%$%tl1591815969%_)
                      (letrec ((_%$%loop1591915972%_
                                (lambda (_%$%hd1591715976%_
                                         _%$%arg1592315979%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1591715976%_))
                                      (let ((_%$%e1592015982%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1591715976%_))))
                                        (let ((_%$%lp-tl1592215989%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1592015982%_)))
                                              (_%$%lp-hd1592115986%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1592015982%_))))
                                          (_%$%loop1591915972%_
                                           _%$%lp-tl1592215989%_
                                           (cons _%$%lp-hd1592115986%_
                                                 _%$%arg1592315979%_))))
                                      (let ((_%$%arg1592415992%_
                                             (reverse _%$%arg1592315979%_)))
                                        (_%__kont3420634207%_
                                         _%$%arg1592415992%_))))))
                        (_%$%loop1591915972%_ _%$%target1591615966%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3420334204%_))
                  (let ((_%$%e1591315956%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3420334204%_))))
                    (let ((_%$%tl1591515963%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1591315956%_)))
                          (_%$%hd1591415960%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1591315956%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1591515963%_))
                          (let ((_%__splice3420834209%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1591515963%_
                                    '0))))
                            (let ((_%$%tl1591815969%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3420834209%_ '1)))
                                  (_%$%target1591615966%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3420834209%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1591815969%_))
                                  (_%__match3422634227%_
                                   _%$%e1591315956%_
                                   _%$%hd1591415960%_
                                   _%$%tl1591515963%_
                                   _%__splice3420834209%_
                                   _%$%target1591615966%_
                                   _%$%tl1591815969%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1590915949%_)))))
                          (let () (declare (not safe)) (_%$%g1590915949%_)))))
                  (let () (declare (not safe)) (_%$%g1590915949%_))))))))
    (define |gerbil-ascent/program/lattice-frontier[:0:]#@lattice-frontier-clear!|
      (lambda (_%$stx16025%_)
        (let* ((_%__stx3422934230%_ _%$stx16025%_)
               (_%$%g1603016051%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3422934230%_)))))
          (let ((_%__kont3423234233%_
                 (lambda (_%$%g1603216116%_)
                   (cons (let ((__tmp34381
                                |gerbil-ascent/program/lattice-frontier[1]#_g34383_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp34381
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'frontier))
                                           '())
                                     (cons (let ((__tmp34384
                                                  (lambda (_%$%g1613116134%_
                                                           _%$%g1613216137%_)
                                                    (cons _%$%g1613116134%_
                                                          _%$%g1613216137%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp34384
                                              '()
                                              _%$%g1603216116%_))
                                           '()))
                               (cons (cons (let ((__tmp34385
                                                  |gerbil-ascent/program/lattice-frontier[1]#_g34387_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp34385
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'frontier))
                     (cons (let ((__tmp34388
                                  |gerbil-ascent/program/lattice-frontier[1]#_g34389_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp34388 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'lattice-round))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f '__lattice-frontier-clear!))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'frontier))
                           '()))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3423634237%_
                 (lambda (_%$%g1604516058%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0 '#f 'lattice-frontier-clear!)))))
            (let* ((_%$%g1602916069%_
                    (lambda ()
                      (let ((_%$%g1604516058%_ _%__stx3422934230%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1604516058%_))
                            (_%__kont3423634237%_ _%$%g1604516058%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1603016051%_))))))
                   (_%__match3425234253%_
                    (lambda (_%$%e1603316076%_
                             _%$%hd1603416080%_
                             _%$%tl1603516083%_
                             _%__splice3423434235%_
                             _%$%target1603616086%_
                             _%$%tl1603816089%_)
                      (letrec ((_%$%loop1603916092%_
                                (lambda (_%$%hd1603716096%_
                                         _%$%arg1604316099%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1603716096%_))
                                      (let ((_%$%e1604016102%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1603716096%_))))
                                        (let ((_%$%lp-tl1604216109%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1604016102%_)))
                                              (_%$%lp-hd1604116106%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1604016102%_))))
                                          (_%$%loop1603916092%_
                                           _%$%lp-tl1604216109%_
                                           (cons _%$%lp-hd1604116106%_
                                                 _%$%arg1604316099%_))))
                                      (let ((_%$%arg1604416112%_
                                             (reverse _%$%arg1604316099%_)))
                                        (_%__kont3423234233%_
                                         _%$%arg1604416112%_))))))
                        (_%$%loop1603916092%_ _%$%target1603616086%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3422934230%_))
                  (let ((_%$%e1603316076%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3422934230%_))))
                    (let ((_%$%tl1603516083%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1603316076%_)))
                          (_%$%hd1603416080%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1603316076%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1603516083%_))
                          (let ((_%__splice3423434235%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1603516083%_
                                    '0))))
                            (let ((_%$%tl1603816089%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3423434235%_ '1)))
                                  (_%$%target1603616086%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3423434235%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1603816089%_))
                                  (_%__match3425234253%_
                                   _%$%e1603316076%_
                                   _%$%hd1603416080%_
                                   _%$%tl1603516083%_
                                   _%__splice3423434235%_
                                   _%$%target1603616086%_
                                   _%$%tl1603816089%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1602916069%_)))))
                          (let () (declare (not safe)) (_%$%g1602916069%_)))))
                  (let () (declare (not safe)) (_%$%g1602916069%_))))))))))
