(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/datum[1]#_g34454_|
    (##structure
     gx#syntax-quote::t
     'datum-frame::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34456_|
    (##structure
     gx#syntax-quote::t
     'make-datum-frame
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34458_|
    (##structure
     gx#syntax-quote::t
     'datum-frame?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34460_|
    (##structure
     gx#syntax-quote::t
     'datum-frame-pair
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34461_|
    (##structure
     gx#syntax-quote::t
     'datum-frame-depth
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34462_|
    (##structure
     gx#syntax-quote::t
     'datum-frame-tail?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34464_|
    (##structure
     gx#syntax-quote::t
     'datum-frame-pair-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34465_|
    (##structure
     gx#syntax-quote::t
     'datum-frame-depth-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34466_|
    (##structure
     gx#syntax-quote::t
     'datum-frame-tail?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34468_|
    (##structure
     gx#syntax-quote::t
     '&datum-frame-pair
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34469_|
    (##structure
     gx#syntax-quote::t
     '&datum-frame-depth
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34470_|
    (##structure
     gx#syntax-quote::t
     '&datum-frame-tail?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34472_|
    (##structure
     gx#syntax-quote::t
     '&datum-frame-pair-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34473_|
    (##structure
     gx#syntax-quote::t
     '&datum-frame-depth-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[1]#_g34474_|
    (##structure
     gx#syntax-quote::t
     '&datum-frame-tail?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/datum[:0:]#datum-frame|
    (let ((__obj34390
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34390
         'gerbil-ascent/candidate/datum#datum-frame::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34390 'datum-frame '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34390 '(pair depth tail?) '6 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34390 '(pair depth tail?) '8 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34390 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34390 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34390 '#t '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34390 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34390 '#f '13 '#f '#f))
      (let ((__tmp34453 |gerbil-ascent/candidate/datum[1]#_g34454_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34390 __tmp34453 '4 '#f '#f))
      (let ((__tmp34455 |gerbil-ascent/candidate/datum[1]#_g34456_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34390 __tmp34455 '14 '#f '#f))
      (let ((__tmp34457 |gerbil-ascent/candidate/datum[1]#_g34458_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34390 __tmp34457 '15 '#f '#f))
      (let ((__tmp34459
             (cons (cons 'pair |gerbil-ascent/candidate/datum[1]#_g34460_|)
                   (cons (cons 'depth
                               |gerbil-ascent/candidate/datum[1]#_g34461_|)
                         (cons (cons 'tail?
                                     |gerbil-ascent/candidate/datum[1]#_g34462_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34390 __tmp34459 '16 '#f '#f))
      (let ((__tmp34463
             (cons (cons 'pair |gerbil-ascent/candidate/datum[1]#_g34464_|)
                   (cons (cons 'depth
                               |gerbil-ascent/candidate/datum[1]#_g34465_|)
                         (cons (cons 'tail?
                                     |gerbil-ascent/candidate/datum[1]#_g34466_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34390 __tmp34463 '17 '#f '#f))
      (let ((__tmp34467
             (cons (cons 'pair |gerbil-ascent/candidate/datum[1]#_g34468_|)
                   (cons (cons 'depth
                               |gerbil-ascent/candidate/datum[1]#_g34469_|)
                         (cons (cons 'tail?
                                     |gerbil-ascent/candidate/datum[1]#_g34470_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34390 __tmp34467 '18 '#f '#f))
      (let ((__tmp34471
             (cons (cons 'pair |gerbil-ascent/candidate/datum[1]#_g34472_|)
                   (cons (cons 'depth
                               |gerbil-ascent/candidate/datum[1]#_g34473_|)
                         (cons (cons 'tail?
                                     |gerbil-ascent/candidate/datum[1]#_g34474_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34390 __tmp34471 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34390 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34390 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34390 '() '21 '#f '#f))
      __obj34390)))
