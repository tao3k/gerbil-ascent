(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/t/qualification/ascent-candidate-feedback-test::timestamp
    1791689850)
  (begin
    (define gerbil-ascent/t/qualification/ascent-candidate-feedback-test#append-map
      (lambda (_%f5486%_ _%rows5487%_)
        (let ((__tmp8386 (map _%f5486%_ _%rows5487%_)))
          (declare (not safe))
          (##apply append __tmp8386))))
    (define gerbil-ascent/t/qualification/ascent-candidate-feedback-test#edges
      '((0 1) (0 2) (1 0) (1 2) (2 0) (2 1)))
    (define gerbil-ascent/t/qualification/ascent-candidate-feedback-test#graph
      (lambda (_%mask5482%_)
        (let ((__tmp8388
               (lambda (_%bit5484%_)
                 (if (zero? (bitwise-and
                             _%mask5482%_
                             (arithmetic-shift '1 _%bit5484%_)))
                     '#f
                     (list-ref
                      gerbil-ascent/t/qualification/ascent-candidate-feedback-test#edges
                      _%bit5484%_))))
              (__tmp8387 (let () (declare (not safe)) (##iota '6))))
          (declare (not safe))
          (filter-map__0 __tmp8388 __tmp8387))))
    (define gerbil-ascent/t/qualification/ascent-candidate-feedback-test#oracle
      (lambda (_%pairs5465%_)
        (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#append-map
         (lambda (_%origin5467%_)
           (let _%loop5469%_ ((_%pending5471%_
                               (let ((__tmp8392
                                      (filter (lambda (_%e5480%_)
                                                (= (car _%e5480%_)
                                                   _%origin5467%_))
                                              _%pairs5465%_)))
                                 (declare (not safe))
                                 (##map cadr __tmp8392)))
                              (_%seen5472%_ '()))
             (if (null? _%pending5471%_)
                 (map (lambda (_%target5474%_)
                        (list _%origin5467%_ _%target5474%_))
                      _%seen5472%_)
                 (let ((_%v5476%_ (car _%pending5471%_)))
                   (if (member _%v5476%_ _%seen5472%_)
                       (_%loop5469%_ (cdr _%pending5471%_) _%seen5472%_)
                       (_%loop5469%_
                        (let ((__tmp8391 (cdr _%pending5471%_))
                              (__tmp8389
                               (let ((__tmp8390
                                      (filter (lambda (_%e5478%_)
                                                (= (car _%e5478%_) _%v5476%_))
                                              _%pairs5465%_)))
                                 (declare (not safe))
                                 (##map cadr __tmp8390))))
                          (declare (not safe))
                          (##append __tmp8391 __tmp8389))
                        (cons _%v5476%_ _%seen5472%_)))))))
         '(0 1 2))))
    (define gerbil-ascent/t/qualification/ascent-candidate-feedback-test#proposal
      (lambda (_%variant5460%_)
        (let ((__tmp8394
               (if (eq? _%variant5460%_ 'no-base)
                   '()
                   (if (eq? _%variant5460%_ 'reverse-base)
                       '((rule (path ?x ?y) (edge ?y ?x)))
                       '((rule (path ?x ?y) (edge ?x ?y))))))
              (__tmp8393
               (if (eq? _%variant5460%_ 'no-step)
                   '()
                   (list (list 'rule
                               '(path ?x ?z)
                               '(path ?x ?y)
                               (if (eq? _%variant5460%_ 'wrong-join)
                                   '(edge ?x ?z)
                                   '(edge ?y ?z)))))))
          (declare (not safe))
          (##append
           '(candidate (relation path 2))
           __tmp8394
           __tmp8393
           '((query path ?x ?y) (limits 16 64 128))))))
    (define gerbil-ascent/t/qualification/ascent-candidate-feedback-test#snapshot
      (lambda (_%generation5457%_ _%pairs5458%_)
        (let ((__tmp8395 (list (list 'edge '2 _%pairs5458%_))))
          (declare (not safe))
          (gerbil-ascent/candidate/reasoning#reasoning-source-snapshot
           'candidate-feedback-graph
           _%generation5457%_
           __tmp8395))))
    (define gerbil-ascent/t/qualification/ascent-candidate-feedback-test#compare
      (lambda (_%source5453%_ _%p5454%_ _%wanted5455%_)
        (let ((__tmp8396
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                  _%source5453%_
                  _%p5454%_
                  '#f))))
          (declare (not safe))
          (gerbil-ascent/candidate/feedback#reasoning-compare-rows
           _%source5453%_
           _%p5454%_
           __tmp8396
           _%wanted5455%_))))
    (define gerbil-ascent/t/qualification/ascent-candidate-feedback-test#ascent-candidate-feedback-test
      (let ((__obj8340
             (let ()
               (declare (not safe))
               (##structure std/test/base#TestSuite::t '#f '#f '#f '#f '#f))))
        (let ((__tmp8397
               (lambda ()
                 (let* ((_%tc4097%_
                         (let ((__obj8313
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8398
                                  (lambda ()
                                    (let* ((_%source3931%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#snapshot
                                             '0
                                             '((0 1) (1 2))))
                                           (_%p3933%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#proposal
                                             'correct))
                                           (_%program3935%_
                                            (let ((__tmp8399
                                                   (let ()
                                                     (declare (not safe))
                                                     (gerbil-ascent/candidate/program#candidate-inspect
                                                      _%source3931%_
                                                      _%p3933%_))))
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/program#candidate-program
                                               _%source3931%_
                                               __tmp8399))))
                                      (let* ((_%desc3938%_
                                              '(eq? (validate
                                                     GerbilAscentProgramContract
                                                     program)
                                                    program))
                                             (_%where3941%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@51.23-51.83")
                                             (_%thunk3952%_
                                              (lambda ()
                                                (let* ((_%expected3945%_ '#t)
                                                       (_%result3948%_
                                                        (eq? (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (clan/poo/mop#validate
                        gerbil-ascent/program/types#GerbilAscentProgramContract
                        _%program3935%_))
                     _%program3935%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3945%_
                                                         _%result3948%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8400
                                                               (let ((__obj8310
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8401
                                (cons '(eq? (validate
                                             GerbilAscentProgramContract
                                             program)
                                            program)
                                      (cons 'test:
                                            (cons '(eq? (validate
                                                         GerbilAscentProgramContract
                                                         program)
                                                        program)
                                                  (cons 'result:
                                                        (cons _%result3948%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3945%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8310
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@51.23-51.83"
                            'irritants:
                            __tmp8401))
                         __obj8310)))
                  (declare (not safe))
                  (raise __tmp8400))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3957%_ _%desc3938%_)
                                             (_%where3975%_ _%where3941%_)
                                             (_%thunk3985%_ _%thunk3952%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3957%_
                                         _%where3975%_
                                         _%thunk3985%_))
                                      (let* ((_%desc3995%_
                                              '(reasoning-receipt-status
                                                (reasoning-attempt
                                                 source
                                                 p
                                                 #f)))
                                             (_%where3998%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@52.23-52.81")
                                             (_%thunk4009%_
                                              (lambda ()
                                                (let* ((_%expected4002%_
                                                        'complete)
                                                       (_%result4005%_
                                                        (let ((__tmp8402
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                          _%source3931%_
                          _%p3933%_
                          '#f))))
                  (declare (not safe))
                  (##unchecked-structure-ref __tmp8402 '1 '#f '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4002%_
                                                         _%result4005%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8403
                                                               (let ((__obj8311
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8404
                                (cons '(reasoning-receipt-status
                                        (reasoning-attempt source p #f))
                                      (cons 'test:
                                            (cons '(reasoning-receipt-status
                                                    (reasoning-attempt
                                                     source
                                                     p
                                                     #f))
                                                  (cons 'result:
                                                        (cons _%result4005%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4002%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8311
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@52.23-52.81"
                            'irritants:
                            __tmp8404))
                         __obj8311)))
                  (declare (not safe))
                  (raise __tmp8403))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4014%_ _%desc3995%_)
                                             (_%where4026%_ _%where3998%_)
                                             (_%thunk4036%_ _%thunk4009%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4014%_
                                         _%where4026%_
                                         _%thunk4036%_))
                                      (let* ((_%desc4046%_
                                              '(reasoning-feedback-status
                                                (compare source
                                                         p
                                                         '((0 1)
                                                           (1 2)
                                                           (0 2)))))
                                             (_%where4049%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@53.23-53.90")
                                             (_%thunk4060%_
                                              (lambda ()
                                                (let* ((_%expected4053%_
                                                        'match)
                                                       (_%result4056%_
                                                        (let ((__tmp8405
                                                               (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#compare
                                                                _%source3931%_
                                                                _%p3933%_
                                                                '((0 1)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (1 2)
                          (0 2)))))
                  (declare (not safe))
                  (##unchecked-structure-ref __tmp8405 '1 '#f '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4053%_
                                                         _%result4056%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8406
                                                               (let ((__obj8312
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8407
                                (cons '(reasoning-feedback-status
                                        (compare source
                                                 p
                                                 '((0 1) (1 2) (0 2))))
                                      (cons 'test:
                                            (cons '(reasoning-feedback-status
                                                    (compare source
                                                             p
                                                             '((0 1)
                                                               (1 2)
                                                               (0 2))))
                                                  (cons 'result:
                                                        (cons _%result4056%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4053%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8312
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@53.23-53.90"
                            'irritants:
                            __tmp8407))
                         __obj8312)))
                  (declare (not safe))
                  (raise __tmp8406))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4065%_ _%desc4046%_)
                                             (_%where4077%_ _%where4049%_)
                                             (_%thunk4087%_ _%thunk4060%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4065%_
                                         _%where4077%_
                                         _%thunk4087%_))))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj8313
                              '"candidate root refinement preserves original native rule ancestry"
                              __tmp8398))
                           __obj8313))
                        (_%tc4102%_ _%tc4097%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc4102%_))
                 (let* ((_%tc4615%_
                         (let ((__obj8322
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8408
                                  (lambda ()
                                    (let ((_%kills4113%_
                                           (let ()
                                             (declare (not safe))
                                             (make-hash-table-eq))))
                                      (let ((__tmp8410
                                             (lambda (_%mask4115%_)
                                               (let* ((_%pairs4117%_
                                                       (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#graph
                                                        _%mask4115%_))
                                                      (_%source4119%_
                                                       (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#snapshot
                                                        _%mask4115%_
                                                        _%pairs4117%_))
                                                      (_%wanted4121%_
                                                       (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#oracle
                                                        _%pairs4117%_))
                                                      (__tmp8411
                                                       (lambda (_%variant4124%_)
                                                         (let* ((_%p4126%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#proposal
                          _%variant4124%_))
                        (_%receipt4128%_
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                            _%source4119%_
                            _%p4126%_
                            '#f)))
                        (_%actual4130%_
                         (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%receipt4128%_
                            '7
                            '#f
                            '#f)))
                        (_%feedback4132%_
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                            _%source4119%_
                            _%p4126%_
                            _%receipt4128%_
                            _%wanted4121%_)))
                        (_%missing4136%_
                         (let ((__tmp8412
                                (lambda (_%r4134%_)
                                  (not (member _%r4134%_ _%actual4130%_)))))
                           (declare (not safe))
                           (##filter __tmp8412 _%wanted4121%_)))
                        (_%extra4140%_
                         (filter (lambda (_%r4138%_)
                                   (not (let ()
                                          (declare (not safe))
                                          (##member
                                           _%r4138%_
                                           _%wanted4121%_))))
                                 _%actual4130%_)))
                   (let* ((_%desc4143%_ '(reasoning-receipt-status receipt))
                          (_%where4146%_
                           '"\"t/qualification/ascent-candidate-feedback-test.ss\"@66.33-66.67")
                          (_%thunk4157%_
                           (lambda ()
                             (let* ((_%expected4150%_ 'complete)
                                    (_%result4153%_
                                     (let ()
                                       (declare (not safe))
                                       (##unchecked-structure-ref
                                        _%receipt4128%_
                                        '1
                                        '#f
                                        '#f))))
                               (if (let ()
                                     (declare (not safe))
                                     (std/test/unit#equal-values?
                                      _%expected4150%_
                                      _%result4153%_))
                                   '#!void
                                   (begin
                                     (let ((__tmp8413
                                            (let ((__obj8314
                                                   (let ()
                                                     (declare (not safe))
                                                     (##structure
                                                      std/test/base#TestError::t
                                                      '#f
                                                      '#f
                                                      '#f
                                                      '#f))))
                                              (let ((__tmp8414
                                                     (cons '(reasoning-receipt-status
                                                             receipt)
                                                           (cons 'test:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (cons '(reasoning-receipt-status receipt)
                               (cons 'result:
                                     (cons _%result4153%_
                                           (cons 'expectation:
                                                 (cons _%expected4150%_
                                                       '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (declare (not safe))
                                                (std/test/base#TestError:::init!
                                                 __obj8314
                                                 '"result does not match expectation"
                                                 'where:
                                                 '"\"t/qualification/ascent-candidate-feedback-test.ss\"@66.33-66.67"
                                                 'irritants:
                                                 __tmp8414))
                                              __obj8314)))
                                       (declare (not safe))
                                       (raise __tmp8413))
                                     '#!void)))))
                          (_%desc4162%_ _%desc4143%_)
                          (_%where4189%_ _%where4146%_)
                          (_%thunk4199%_ _%thunk4157%_))
                     (declare (not safe))
                     (std/test/base#__test-check!
                      _%desc4162%_
                      _%where4189%_
                      _%thunk4199%_))
                   (let* ((_%desc4209%_ '(reasoning-receipt-proof receipt))
                          (_%where4212%_
                           '"\"t/qualification/ascent-candidate-feedback-test.ss\"@67.33-67.66")
                          (_%thunk4223%_
                           (lambda ()
                             (let* ((_%expected4216%_ '#f)
                                    (_%result4219%_
                                     (let ()
                                       (declare (not safe))
                                       (##unchecked-structure-ref
                                        _%receipt4128%_
                                        '10
                                        '#f
                                        '#f))))
                               (if (let ()
                                     (declare (not safe))
                                     (std/test/unit#equal-values?
                                      _%expected4216%_
                                      _%result4219%_))
                                   '#!void
                                   (begin
                                     (let ((__tmp8415
                                            (let ((__obj8315
                                                   (let ()
                                                     (declare (not safe))
                                                     (##structure
                                                      std/test/base#TestError::t
                                                      '#f
                                                      '#f
                                                      '#f
                                                      '#f))))
                                              (let ((__tmp8416
                                                     (cons '(reasoning-receipt-proof
                                                             receipt)
                                                           (cons 'test:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (cons '(reasoning-receipt-proof receipt)
                               (cons 'result:
                                     (cons _%result4219%_
                                           (cons 'expectation:
                                                 (cons _%expected4216%_
                                                       '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (declare (not safe))
                                                (std/test/base#TestError:::init!
                                                 __obj8315
                                                 '"result does not match expectation"
                                                 'where:
                                                 '"\"t/qualification/ascent-candidate-feedback-test.ss\"@67.33-67.66"
                                                 'irritants:
                                                 __tmp8416))
                                              __obj8315)))
                                       (declare (not safe))
                                       (raise __tmp8415))
                                     '#!void)))))
                          (_%desc4228%_ _%desc4209%_)
                          (_%where4240%_ _%where4212%_)
                          (_%thunk4250%_ _%thunk4223%_))
                     (declare (not safe))
                     (std/test/base#__test-check!
                      _%desc4228%_
                      _%where4240%_
                      _%thunk4250%_))
                   (let* ((_%desc4260%_
                           '(reasoning-receipt-nonmembership receipt))
                          (_%where4263%_
                           '"\"t/qualification/ascent-candidate-feedback-test.ss\"@68.33-68.74")
                          (_%thunk4274%_
                           (lambda ()
                             (let* ((_%expected4267%_ '#f)
                                    (_%result4270%_
                                     (let ()
                                       (declare (not safe))
                                       (##unchecked-structure-ref
                                        _%receipt4128%_
                                        '11
                                        '#f
                                        '#f))))
                               (if (let ()
                                     (declare (not safe))
                                     (std/test/unit#equal-values?
                                      _%expected4267%_
                                      _%result4270%_))
                                   '#!void
                                   (begin
                                     (let ((__tmp8417
                                            (let ((__obj8316
                                                   (let ()
                                                     (declare (not safe))
                                                     (##structure
                                                      std/test/base#TestError::t
                                                      '#f
                                                      '#f
                                                      '#f
                                                      '#f))))
                                              (let ((__tmp8418
                                                     (cons '(reasoning-receipt-nonmembership
                                                             receipt)
                                                           (cons 'test:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (cons '(reasoning-receipt-nonmembership receipt)
                               (cons 'result:
                                     (cons _%result4270%_
                                           (cons 'expectation:
                                                 (cons _%expected4267%_
                                                       '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (declare (not safe))
                                                (std/test/base#TestError:::init!
                                                 __obj8316
                                                 '"result does not match expectation"
                                                 'where:
                                                 '"\"t/qualification/ascent-candidate-feedback-test.ss\"@68.33-68.74"
                                                 'irritants:
                                                 __tmp8418))
                                              __obj8316)))
                                       (declare (not safe))
                                       (raise __tmp8417))
                                     '#!void)))))
                          (_%desc4279%_ _%desc4260%_)
                          (_%where4291%_ _%where4263%_)
                          (_%thunk4301%_ _%thunk4274%_))
                     (declare (not safe))
                     (std/test/base#__test-check!
                      _%desc4279%_
                      _%where4291%_
                      _%thunk4301%_))
                   (let* ((_%desc4311%_ '(reasoning-feedback-status feedback))
                          (_%where4314%_
                           '"\"t/qualification/ascent-candidate-feedback-test.ss\"@69.33-69.69")
                          (_%thunk4325%_
                           (lambda ()
                             (let* ((_%expected4318%_
                                     (if (and (null? _%missing4136%_)
                                              (null? _%extra4140%_))
                                         'match
                                         'mismatch))
                                    (_%result4321%_
                                     (let ()
                                       (declare (not safe))
                                       (##unchecked-structure-ref
                                        _%feedback4132%_
                                        '1
                                        '#f
                                        '#f))))
                               (if (let ()
                                     (declare (not safe))
                                     (std/test/unit#equal-values?
                                      _%expected4318%_
                                      _%result4321%_))
                                   '#!void
                                   (begin
                                     (let ((__tmp8419
                                            (let ((__obj8317
                                                   (let ()
                                                     (declare (not safe))
                                                     (##structure
                                                      std/test/base#TestError::t
                                                      '#f
                                                      '#f
                                                      '#f
                                                      '#f))))
                                              (let ((__tmp8420
                                                     (cons '(reasoning-feedback-status
                                                             feedback)
                                                           (cons 'test:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (cons '(reasoning-feedback-status feedback)
                               (cons 'result:
                                     (cons _%result4321%_
                                           (cons 'expectation:
                                                 (cons _%expected4318%_
                                                       '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (declare (not safe))
                                                (std/test/base#TestError:::init!
                                                 __obj8317
                                                 '"result does not match expectation"
                                                 'where:
                                                 '"\"t/qualification/ascent-candidate-feedback-test.ss\"@69.33-69.69"
                                                 'irritants:
                                                 __tmp8420))
                                              __obj8317)))
                                       (declare (not safe))
                                       (raise __tmp8419))
                                     '#!void)))))
                          (_%desc4330%_ _%desc4311%_)
                          (_%where4342%_ _%where4314%_)
                          (_%thunk4352%_ _%thunk4325%_))
                     (declare (not safe))
                     (std/test/base#__test-check!
                      _%desc4330%_
                      _%where4342%_
                      _%thunk4352%_))
                   (let* ((_%desc4362%_ '(reasoning-feedback-missing feedback))
                          (_%where4365%_
                           '"\"t/qualification/ascent-candidate-feedback-test.ss\"@71.33-71.70")
                          (_%thunk4376%_
                           (lambda ()
                             (let* ((_%expected4369%_ _%missing4136%_)
                                    (_%result4372%_
                                     (let ()
                                       (declare (not safe))
                                       (##unchecked-structure-ref
                                        _%feedback4132%_
                                        '3
                                        '#f
                                        '#f))))
                               (if (let ()
                                     (declare (not safe))
                                     (std/test/unit#equal-values?
                                      _%expected4369%_
                                      _%result4372%_))
                                   '#!void
                                   (begin
                                     (let ((__tmp8421
                                            (let ((__obj8318
                                                   (let ()
                                                     (declare (not safe))
                                                     (##structure
                                                      std/test/base#TestError::t
                                                      '#f
                                                      '#f
                                                      '#f
                                                      '#f))))
                                              (let ((__tmp8422
                                                     (cons '(reasoning-feedback-missing
                                                             feedback)
                                                           (cons 'test:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (cons '(reasoning-feedback-missing feedback)
                               (cons 'result:
                                     (cons _%result4372%_
                                           (cons 'expectation:
                                                 (cons _%expected4369%_
                                                       '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (declare (not safe))
                                                (std/test/base#TestError:::init!
                                                 __obj8318
                                                 '"result does not match expectation"
                                                 'where:
                                                 '"\"t/qualification/ascent-candidate-feedback-test.ss\"@71.33-71.70"
                                                 'irritants:
                                                 __tmp8422))
                                              __obj8318)))
                                       (declare (not safe))
                                       (raise __tmp8421))
                                     '#!void)))))
                          (_%desc4381%_ _%desc4362%_)
                          (_%where4393%_ _%where4365%_)
                          (_%thunk4403%_ _%thunk4376%_))
                     (declare (not safe))
                     (std/test/base#__test-check!
                      _%desc4381%_
                      _%where4393%_
                      _%thunk4403%_))
                   (let* ((_%desc4413%_ '(reasoning-feedback-extra feedback))
                          (_%where4416%_
                           '"\"t/qualification/ascent-candidate-feedback-test.ss\"@72.33-72.68")
                          (_%thunk4427%_
                           (lambda ()
                             (let* ((_%expected4420%_ _%extra4140%_)
                                    (_%result4423%_
                                     (let ()
                                       (declare (not safe))
                                       (##unchecked-structure-ref
                                        _%feedback4132%_
                                        '4
                                        '#f
                                        '#f))))
                               (if (let ()
                                     (declare (not safe))
                                     (std/test/unit#equal-values?
                                      _%expected4420%_
                                      _%result4423%_))
                                   '#!void
                                   (begin
                                     (let ((__tmp8423
                                            (let ((__obj8319
                                                   (let ()
                                                     (declare (not safe))
                                                     (##structure
                                                      std/test/base#TestError::t
                                                      '#f
                                                      '#f
                                                      '#f
                                                      '#f))))
                                              (let ((__tmp8424
                                                     (cons '(reasoning-feedback-extra
                                                             feedback)
                                                           (cons 'test:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (cons '(reasoning-feedback-extra feedback)
                               (cons 'result:
                                     (cons _%result4423%_
                                           (cons 'expectation:
                                                 (cons _%expected4420%_
                                                       '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (declare (not safe))
                                                (std/test/base#TestError:::init!
                                                 __obj8319
                                                 '"result does not match expectation"
                                                 'where:
                                                 '"\"t/qualification/ascent-candidate-feedback-test.ss\"@72.33-72.68"
                                                 'irritants:
                                                 __tmp8424))
                                              __obj8319)))
                                       (declare (not safe))
                                       (raise __tmp8423))
                                     '#!void)))))
                          (_%desc4432%_ _%desc4413%_)
                          (_%where4444%_ _%where4416%_)
                          (_%thunk4454%_ _%thunk4427%_))
                     (declare (not safe))
                     (std/test/base#__test-check!
                      _%desc4432%_
                      _%where4444%_
                      _%thunk4454%_))
                   (if (eq? _%variant4124%_ 'correct)
                       (let* ((_%desc4464%_
                               '(reasoning-feedback-status feedback))
                              (_%where4467%_
                               '"\"t/qualification/ascent-candidate-feedback-test.ss\"@73.62-73.98")
                              (_%thunk4478%_
                               (lambda ()
                                 (let* ((_%expected4471%_ 'match)
                                        (_%result4474%_
                                         (let ()
                                           (declare (not safe))
                                           (##unchecked-structure-ref
                                            _%feedback4132%_
                                            '1
                                            '#f
                                            '#f))))
                                   (if (let ()
                                         (declare (not safe))
                                         (std/test/unit#equal-values?
                                          _%expected4471%_
                                          _%result4474%_))
                                       '#!void
                                       (begin
                                         (let ((__tmp8425
                                                (let ((__obj8320
                                                       (let ()
                                                         (declare (not safe))
                                                         (##structure
                                                          std/test/base#TestError::t
                                                          '#f
                                                          '#f
                                                          '#f
                                                          '#f))))
                                                  (let ((__tmp8426
                                                         (cons '(reasoning-feedback-status
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         feedback)
                       (cons 'test:
                             (cons '(reasoning-feedback-status feedback)
                                   (cons 'result:
                                         (cons _%result4474%_
                                               (cons 'expectation:
                                                     (cons _%expected4471%_
                                                           '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (declare (not safe))
                                                    (std/test/base#TestError:::init!
                                                     __obj8320
                                                     '"result does not match expectation"
                                                     'where:
                                                     '"\"t/qualification/ascent-candidate-feedback-test.ss\"@73.62-73.98"
                                                     'irritants:
                                                     __tmp8426))
                                                  __obj8320)))
                                           (declare (not safe))
                                           (raise __tmp8425))
                                         '#!void)))))
                              (_%desc4483%_ _%desc4464%_)
                              (_%where4495%_ _%where4467%_)
                              (_%thunk4505%_ _%thunk4478%_))
                         (declare (not safe))
                         (std/test/base#__test-check!
                          _%desc4483%_
                          _%where4495%_
                          _%thunk4505%_))
                       '#!void)
                   (if (eq? (let ()
                              (declare (not safe))
                              (##unchecked-structure-ref
                               _%feedback4132%_
                               '1
                               '#f
                               '#f))
                            'mismatch)
                       (let* ((_%h4515%_ _%kills4113%_)
                              (_%key4518%_ _%variant4124%_)
                              (_%value4521%_ '#t)
                              (_%h4525%_ _%h4515%_)
                              (_%h4527%_ _%h4525%_))
                         (declare (not safe))
                         (__hash-put! _%h4527%_ _%key4518%_ _%value4521%_))
                       '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (declare (not safe))
                                                 (##for-each
                                                  __tmp8411
                                                  '(correct no-base
                                                            no-step
                                                            wrong-join
                                                            reverse-base)))
                                               (if (zero? (modulo (+ _%mask4115%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             '1)
                          '8))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (begin
                                                     (let ((__tmp8427
                                                            (+ _%mask4115%_
                                                               '1)))
                                                       (declare (not safe))
                                                       (displayln
                                                        '"CANDIDATE-FEEDBACK-GRAPHS "
                                                        __tmp8427
                                                        '"/64"))
                                                     (force-output))
                                                   '#!void)))
                                            (__tmp8409
                                             (let ()
                                               (declare (not safe))
                                               (##iota '64))))
                                        (declare (not safe))
                                        (##for-each __tmp8410 __tmp8409))
                                      (let ((__tmp8428
                                             (lambda (_%v4539%_)
                                               (let* ((_%desc4541%_
                                                       '(hash-get kills v))
                                                      (_%where4544%_
                                                       '"\"t/qualification/ascent-candidate-feedback-test.ss\"@78.45-78.63")
                                                      (_%thunk4580%_
                                                       (lambda ()
                                                         (let* ((_%expected4548%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '#t)
                        (_%result4576%_
                         (let* ((_%h4551%_ _%kills4113%_)
                                (_%key4554%_ _%v4539%_)
                                (_%h4558%_ _%h4551%_)
                                (_%h4560%_ _%h4558%_))
                           (declare (not safe))
                           (__hash-get _%h4560%_ _%key4554%_))))
                   (if (let ()
                         (declare (not safe))
                         (std/test/unit#equal-values?
                          _%expected4548%_
                          _%result4576%_))
                       '#!void
                       (begin
                         (let ((__tmp8429
                                (let ((__obj8321
                                       (let ()
                                         (declare (not safe))
                                         (##structure
                                          std/test/base#TestError::t
                                          '#f
                                          '#f
                                          '#f
                                          '#f))))
                                  (let ((__tmp8430
                                         (cons '(hash-get kills v)
                                               (cons 'test:
                                                     (cons '(hash-get kills v)
                                                           (cons 'result:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (cons _%result4576%_
                               (cons 'expectation:
                                     (cons _%expected4548%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                    (declare (not safe))
                                    (std/test/base#TestError:::init!
                                     __obj8321
                                     '"result does not match expectation"
                                     'where:
                                     '"\"t/qualification/ascent-candidate-feedback-test.ss\"@78.45-78.63"
                                     'irritants:
                                     __tmp8430))
                                  __obj8321)))
                           (declare (not safe))
                           (raise __tmp8429))
                         '#!void)))))
              (_%desc4585%_ _%desc4541%_)
              (_%where4595%_ _%where4544%_)
              (_%thunk4605%_ _%thunk4580%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (declare (not safe))
                                                 (std/test/base#__test-check!
                                                  _%desc4585%_
                                                  _%where4595%_
                                                  _%thunk4605%_)))))
                                        (declare (not safe))
                                        (##for-each
                                         __tmp8428
                                         '(no-base no-step
                                                   wrong-join
                                                   reverse-base)))))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj8322
                              '"frozen proposals on 64 held-out graphs with exact differences"
                              __tmp8408))
                           __obj8322))
                        (_%tc4620%_ _%tc4615%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc4620%_))
                 (let* ((_%tc4791%_
                         (let ((__obj8326
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8431
                                  (lambda ()
                                    (let ((_%p4631%_
                                           (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#proposal
                                            'wrong-join)))
                                      (let* ((_%desc4633%_
                                              '(reasoning-feedback-status
                                                (compare (snapshot 0 '((0 1)))
                                                         p
                                                         '((0 1)))))
                                             (_%where4636%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@81.23-81.93")
                                             (_%thunk4647%_
                                              (lambda ()
                                                (let* ((_%expected4640%_
                                                        'match)
                                                       (_%result4643%_
                                                        (let ((__tmp8432
                                                               (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#compare
                                                                (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#snapshot
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '0
                         '((0 1)))
                        _%p4631%_
                        '((0 1)))))
                  (declare (not safe))
                  (##unchecked-structure-ref __tmp8432 '1 '#f '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4640%_
                                                         _%result4643%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8433
                                                               (let ((__obj8323
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8434
                                (cons '(reasoning-feedback-status
                                        (compare (snapshot 0 '((0 1)))
                                                 p
                                                 '((0 1))))
                                      (cons 'test:
                                            (cons '(reasoning-feedback-status
                                                    (compare (snapshot
                                                              0
                                                              '((0 1)))
                                                             p
                                                             '((0 1))))
                                                  (cons 'result:
                                                        (cons _%result4643%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4640%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8323
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@81.23-81.93"
                            'irritants:
                            __tmp8434))
                         __obj8323)))
                  (declare (not safe))
                  (raise __tmp8433))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4652%_ _%desc4633%_)
                                             (_%where4666%_ _%where4636%_)
                                             (_%thunk4676%_ _%thunk4647%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4652%_
                                         _%where4666%_
                                         _%thunk4676%_))
                                      (let ((_%f4686%_
                                             (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#compare
                                              (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#snapshot
                                               '1
                                               '((0 1) (1 2)))
                                              _%p4631%_
                                              '((0 1) (1 2) (0 2)))))
                                        (let* ((_%desc4688%_
                                                '(reasoning-feedback-status f))
                                               (_%where4691%_
                                                '"\"t/qualification/ascent-candidate-feedback-test.ss\"@83.25-83.54")
                                               (_%thunk4702%_
                                                (lambda ()
                                                  (let* ((_%expected4695%_
                                                          'mismatch)
                                                         (_%result4698%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (##unchecked-structure-ref
                                                             _%f4686%_
                                                             '1
                                                             '#f
                                                             '#f))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (std/test/unit#equal-values?
                                                           _%expected4695%_
                                                           _%result4698%_))
                                                        '#!void
                                                        (begin
                                                          (let ((__tmp8435
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ((__obj8324
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestError::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8436
                                  (cons '(reasoning-feedback-status f)
                                        (cons 'test:
                                              (cons '(reasoning-feedback-status
                                                      f)
                                                    (cons 'result:
                                                          (cons _%result4698%_
                                                                (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%expected4695%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                             (declare (not safe))
                             (std/test/base#TestError:::init!
                              __obj8324
                              '"result does not match expectation"
                              'where:
                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@83.25-83.54"
                              'irritants:
                              __tmp8436))
                           __obj8324)))
                    (declare (not safe))
                    (raise __tmp8435))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%desc4707%_ _%desc4688%_)
                                               (_%where4720%_ _%where4691%_)
                                               (_%thunk4730%_ _%thunk4702%_))
                                          (declare (not safe))
                                          (std/test/base#__test-check!
                                           _%desc4707%_
                                           _%where4720%_
                                           _%thunk4730%_))
                                        (let* ((_%desc4740%_
                                                '(reasoning-feedback-missing
                                                  f))
                                               (_%where4743%_
                                                '"\"t/qualification/ascent-candidate-feedback-test.ss\"@84.25-84.55")
                                               (_%thunk4754%_
                                                (lambda ()
                                                  (let* ((_%expected4747%_
                                                          '((0 2)))
                                                         (_%result4750%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (##unchecked-structure-ref
                                                             _%f4686%_
                                                             '3
                                                             '#f
                                                             '#f))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (std/test/unit#equal-values?
                                                           _%expected4747%_
                                                           _%result4750%_))
                                                        '#!void
                                                        (begin
                                                          (let ((__tmp8437
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ((__obj8325
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestError::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8438
                                  (cons '(reasoning-feedback-missing f)
                                        (cons 'test:
                                              (cons '(reasoning-feedback-missing
                                                      f)
                                                    (cons 'result:
                                                          (cons _%result4750%_
                                                                (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%expected4747%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                             (declare (not safe))
                             (std/test/base#TestError:::init!
                              __obj8325
                              '"result does not match expectation"
                              'where:
                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@84.25-84.55"
                              'irritants:
                              __tmp8438))
                           __obj8325)))
                    (declare (not safe))
                    (raise __tmp8437))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%desc4759%_ _%desc4740%_)
                                               (_%where4771%_ _%where4743%_)
                                               (_%thunk4781%_ _%thunk4754%_))
                                          (declare (not safe))
                                          (std/test/base#__test-check!
                                           _%desc4759%_
                                           _%where4771%_
                                           _%thunk4781%_)))))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj8326
                              '"a demonstration pass fails on the held-out chain"
                              __tmp8431))
                           __obj8326))
                        (_%tc4796%_ _%tc4791%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc4796%_))
                 (let* ((_%tc5137%_
                         (let ((__obj8333
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8439
                                  (lambda ()
                                    (let* ((_%p4807%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#proposal
                                             'correct))
                                           (_%source4809%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#snapshot
                                             '0
                                             '((0 1) (1 2))))
                                           (_%receipt4811%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                                               _%source4809%_
                                               _%p4807%_
                                               '1)))
                                           (_%changed4813%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#snapshot
                                             '1
                                             '((0 1))))
                                           (_%bad4815%_
                                            '(candidate
                                              (relation path 2)
                                              (rule (path ?x ?y)
                                                    (helper ?x ?y))
                                              (query path ?x ?y)
                                              (limits 16 64 128)))
                                           (_%rejected4817%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/reasoning#reasoning-attempt__0
                                               _%source4809%_
                                               _%bad4815%_)))
                                           (_%limited4819%_
                                            (let ((__tmp8440
                                                   (reverse (cdr (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (declare (not safe))
                           (##reverse _%p4807%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (declare (not safe))
                                              (##append
                                               __tmp8440
                                               '((limits 16 1 1))))))
                                      (let* ((_%desc4822%_
                                              '(reasoning-feedback-reason
                                                (reasoning-compare-rows
                                                 changed
                                                 p
                                                 receipt
                                                 '((0 1)))))
                                             (_%where4825%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@92.23-92.102")
                                             (_%thunk4836%_
                                              (lambda ()
                                                (let* ((_%expected4829%_
                                                        'unbound)
                                                       (_%result4832%_
                                                        (let ((__tmp8441
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                          _%changed4813%_
                          _%p4807%_
                          _%receipt4811%_
                          '((0 1))))))
                  (declare (not safe))
                  (##unchecked-structure-ref __tmp8441 '2 '#f '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4829%_
                                                         _%result4832%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8442
                                                               (let ((__obj8327
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8443
                                (cons '(reasoning-feedback-reason
                                        (reasoning-compare-rows
                                         changed
                                         p
                                         receipt
                                         '((0 1))))
                                      (cons 'test:
                                            (cons '(reasoning-feedback-reason
                                                    (reasoning-compare-rows
                                                     changed
                                                     p
                                                     receipt
                                                     '((0 1))))
                                                  (cons 'result:
                                                        (cons _%result4832%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4829%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8327
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@92.23-92.102"
                            'irritants:
                            __tmp8443))
                         __obj8327)))
                  (declare (not safe))
                  (raise __tmp8442))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4841%_ _%desc4822%_)
                                             (_%where4862%_ _%where4825%_)
                                             (_%thunk4872%_ _%thunk4836%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4841%_
                                         _%where4862%_
                                         _%thunk4872%_))
                                      (let* ((_%desc4882%_
                                              '(reasoning-feedback-reason
                                                (reasoning-compare-rows
                                                 source
                                                 (proposal 'wrong-join)
                                                 receipt
                                                 [])))
                                             (_%where4885%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@93.23-93.116")
                                             (_%thunk4896%_
                                              (lambda ()
                                                (let* ((_%expected4889%_
                                                        'unbound)
                                                       (_%result4892%_
                                                        (let ((__tmp8444
                                                               (let ((__tmp8445
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#proposal
                               'wrong-join)))
                         (declare (not safe))
                         (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                          _%source4809%_
                          __tmp8445
                          _%receipt4811%_
                          '()))))
                  (declare (not safe))
                  (##unchecked-structure-ref __tmp8444 '2 '#f '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4889%_
                                                         _%result4892%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8446
                                                               (let ((__obj8328
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8447
                                (cons '(reasoning-feedback-reason
                                        (reasoning-compare-rows
                                         source
                                         (proposal 'wrong-join)
                                         receipt
                                         []))
                                      (cons 'test:
                                            (cons '(reasoning-feedback-reason
                                                    (reasoning-compare-rows
                                                     source
                                                     (proposal 'wrong-join)
                                                     receipt
                                                     []))
                                                  (cons 'result:
                                                        (cons _%result4892%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4889%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8328
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@93.23-93.116"
                            'irritants:
                            __tmp8447))
                         __obj8328)))
                  (declare (not safe))
                  (raise __tmp8446))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4901%_ _%desc4882%_)
                                             (_%where4913%_ _%where4885%_)
                                             (_%thunk4923%_ _%thunk4896%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4901%_
                                         _%where4913%_
                                         _%thunk4923%_))
                                      (let* ((_%desc4933%_
                                              '(reasoning-feedback-status
                                                (compare changed p '((0 1)))))
                                             (_%where4936%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@94.23-94.79")
                                             (_%thunk4947%_
                                              (lambda ()
                                                (let* ((_%expected4940%_
                                                        'match)
                                                       (_%result4943%_
                                                        (let ((__tmp8448
                                                               (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#compare
                                                                _%changed4813%_
                                                                _%p4807%_
                                                                '((0 1)))))
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           __tmp8448
                                                           '1
                                                           '#f
                                                           '#f))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4940%_
                                                         _%result4943%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8449
                                                               (let ((__obj8329
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8450
                                (cons '(reasoning-feedback-status
                                        (compare changed p '((0 1))))
                                      (cons 'test:
                                            (cons '(reasoning-feedback-status
                                                    (compare changed
                                                             p
                                                             '((0 1))))
                                                  (cons 'result:
                                                        (cons _%result4943%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4940%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8329
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@94.23-94.79"
                            'irritants:
                            __tmp8450))
                         __obj8329)))
                  (declare (not safe))
                  (raise __tmp8449))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc4952%_ _%desc4933%_)
                                             (_%where4964%_ _%where4936%_)
                                             (_%thunk4974%_ _%thunk4947%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc4952%_
                                         _%where4964%_
                                         _%thunk4974%_))
                                      (let* ((_%desc4984%_
                                              '(reasoning-diagnostic-code
                                                (car (reasoning-receipt-diagnostics
                                                      rejected))))
                                             (_%where4987%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@95.23-95.97")
                                             (_%thunk4998%_
                                              (lambda ()
                                                (let* ((_%expected4991%_
                                                        'unknown-relation)
                                                       (_%result4994%_
                                                        (##structure-ref
                                                         (car (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (##unchecked-structure-ref
                         _%rejected4817%_
                         '8
                         '#f
                         '#f)))
                 '1
                 gerbil-ascent/candidate/types#reasoning-diagnostic::t
                 '#f)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected4991%_
                                                         _%result4994%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8451
                                                               (let ((__obj8330
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8452
                                (cons '(reasoning-diagnostic-code
                                        (car (reasoning-receipt-diagnostics
                                              rejected)))
                                      (cons 'test:
                                            (cons '(reasoning-diagnostic-code
                                                    (car (reasoning-receipt-diagnostics
                                                          rejected)))
                                                  (cons 'result:
                                                        (cons _%result4994%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected4991%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8330
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@95.23-95.97"
                            'irritants:
                            __tmp8452))
                         __obj8330)))
                  (declare (not safe))
                  (raise __tmp8451))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc5003%_ _%desc4984%_)
                                             (_%where5015%_ _%where4987%_)
                                             (_%thunk5025%_ _%thunk4998%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc5003%_
                                         _%where5015%_
                                         _%thunk5025%_))
                                      (let* ((_%desc5035%_
                                              '(reasoning-feedback-reason
                                                (reasoning-compare-rows
                                                 source
                                                 bad
                                                 rejected
                                                 [])))
                                             (_%where5038%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@96.23-96.98")
                                             (_%thunk5049%_
                                              (lambda ()
                                                (let* ((_%expected5042%_
                                                        'rejected)
                                                       (_%result5045%_
                                                        (let ((__tmp8453
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                          _%source4809%_
                          _%bad4815%_
                          _%rejected4817%_
                          '()))))
                  (declare (not safe))
                  (##unchecked-structure-ref __tmp8453 '2 '#f '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected5042%_
                                                         _%result5045%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8454
                                                               (let ((__obj8331
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8455
                                (cons '(reasoning-feedback-reason
                                        (reasoning-compare-rows
                                         source
                                         bad
                                         rejected
                                         []))
                                      (cons 'test:
                                            (cons '(reasoning-feedback-reason
                                                    (reasoning-compare-rows
                                                     source
                                                     bad
                                                     rejected
                                                     []))
                                                  (cons 'result:
                                                        (cons _%result5045%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected5042%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8331
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@96.23-96.98"
                            'irritants:
                            __tmp8455))
                         __obj8331)))
                  (declare (not safe))
                  (raise __tmp8454))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc5054%_ _%desc5035%_)
                                             (_%where5066%_ _%where5038%_)
                                             (_%thunk5076%_ _%thunk5049%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc5054%_
                                         _%where5066%_
                                         _%thunk5076%_))
                                      (let* ((_%desc5086%_
                                              '(reasoning-feedback-status
                                                (compare source limited [])))
                                             (_%where5089%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@97.23-97.78")
                                             (_%thunk5100%_
                                              (lambda ()
                                                (let* ((_%expected5093%_
                                                        'inconclusive)
                                                       (_%result5096%_
                                                        (let ((__tmp8456
                                                               (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#compare
                                                                _%source4809%_
                                                                _%limited4819%_
                                                                '())))
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           __tmp8456
                                                           '1
                                                           '#f
                                                           '#f))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected5093%_
                                                         _%result5096%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8457
                                                               (let ((__obj8332
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8458
                                (cons '(reasoning-feedback-status
                                        (compare source limited []))
                                      (cons 'test:
                                            (cons '(reasoning-feedback-status
                                                    (compare source
                                                             limited
                                                             []))
                                                  (cons 'result:
                                                        (cons _%result5096%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected5093%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8332
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@97.23-97.78"
                            'irritants:
                            __tmp8458))
                         __obj8332)))
                  (declare (not safe))
                  (raise __tmp8457))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc5105%_ _%desc5086%_)
                                             (_%where5117%_ _%where5089%_)
                                             (_%thunk5127%_ _%thunk5100%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc5105%_
                                         _%where5117%_
                                         _%thunk5127%_))))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj8333
                              '"withdrawal, candidate binding, rejected and unfinished attempts"
                              __tmp8439))
                           __obj8333))
                        (_%tc5142%_ _%tc5137%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc5142%_))
                 (let* ((_%tc5438%_
                         (let ((__obj8339
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8459
                                  (lambda ()
                                    (let* ((_%p5153%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#proposal
                                             'correct))
                                           (_%source5155%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#snapshot
                                             '0
                                             '((0 1))))
                                           (_%r5157%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                                               _%source5155%_
                                               _%p5153%_
                                               '1))))
                                      (let* ((_%desc5160%_
                                              '(reasoning-feedback-status
                                                (reasoning-compare-rows
                                                 source
                                                 p
                                                 r
                                                 '((0 1) (0 1)))))
                                             (_%where5163%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@100.23-100.101")
                                             (_%thunk5174%_
                                              (lambda ()
                                                (let* ((_%expected5167%_
                                                        'match)
                                                       (_%result5170%_
                                                        (let ((__tmp8460
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                          _%source5155%_
                          _%p5153%_
                          _%r5157%_
                          '((0 1) (0 1))))))
                  (declare (not safe))
                  (##unchecked-structure-ref __tmp8460 '1 '#f '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected5167%_
                                                         _%result5170%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8461
                                                               (let ((__obj8334
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8462
                                (cons '(reasoning-feedback-status
                                        (reasoning-compare-rows
                                         source
                                         p
                                         r
                                         '((0 1) (0 1))))
                                      (cons 'test:
                                            (cons '(reasoning-feedback-status
                                                    (reasoning-compare-rows
                                                     source
                                                     p
                                                     r
                                                     '((0 1) (0 1))))
                                                  (cons 'result:
                                                        (cons _%result5170%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected5167%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8334
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@100.23-100.101"
                            'irritants:
                            __tmp8462))
                         __obj8334)))
                  (declare (not safe))
                  (raise __tmp8461))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc5179%_ _%desc5160%_)
                                             (_%where5196%_ _%where5163%_)
                                             (_%thunk5206%_ _%thunk5174%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc5179%_
                                         _%where5196%_
                                         _%thunk5206%_))
                                      (let* ((_%row5216%_ (list '0 '2))
                                             (_%wanted5218%_
                                              (list _%row5216%_))
                                             (_%f5220%_
                                              (let ()
                                                (declare (not safe))
                                                (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                                                 _%source5155%_
                                                 _%p5153%_
                                                 _%r5157%_
                                                 _%wanted5218%_))))
                                        (set-car! _%row5216%_ '9)
                                        (let* ((_%desc5223%_
                                                '(reasoning-feedback-missing
                                                  f))
                                               (_%where5226%_
                                                '"\"t/qualification/ascent-candidate-feedback-test.ss\"@104.25-104.55")
                                               (_%thunk5237%_
                                                (lambda ()
                                                  (let* ((_%expected5230%_
                                                          '((0 2)))
                                                         (_%result5233%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (##unchecked-structure-ref
                                                             _%f5220%_
                                                             '3
                                                             '#f
                                                             '#f))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (std/test/unit#equal-values?
                                                           _%expected5230%_
                                                           _%result5233%_))
                                                        '#!void
                                                        (begin
                                                          (let ((__tmp8463
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ((__obj8335
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestError::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8464
                                  (cons '(reasoning-feedback-missing f)
                                        (cons 'test:
                                              (cons '(reasoning-feedback-missing
                                                      f)
                                                    (cons 'result:
                                                          (cons _%result5233%_
                                                                (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%expected5230%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                             (declare (not safe))
                             (std/test/base#TestError:::init!
                              __obj8335
                              '"result does not match expectation"
                              'where:
                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@104.25-104.55"
                              'irritants:
                              __tmp8464))
                           __obj8335)))
                    (declare (not safe))
                    (raise __tmp8463))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%desc5242%_ _%desc5223%_)
                                               (_%where5258%_ _%where5226%_)
                                               (_%thunk5268%_ _%thunk5237%_))
                                          (declare (not safe))
                                          (std/test/base#__test-check!
                                           _%desc5242%_
                                           _%where5258%_
                                           _%thunk5268%_))
                                        (let* ((_%desc5278%_
                                                '(reasoning-feedback-extra f))
                                               (_%where5281%_
                                                '"\"t/qualification/ascent-candidate-feedback-test.ss\"@105.25-105.53")
                                               (_%thunk5292%_
                                                (lambda ()
                                                  (let* ((_%expected5285%_
                                                          '((0 1)))
                                                         (_%result5288%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (##unchecked-structure-ref
                                                             _%f5220%_
                                                             '4
                                                             '#f
                                                             '#f))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (std/test/unit#equal-values?
                                                           _%expected5285%_
                                                           _%result5288%_))
                                                        '#!void
                                                        (begin
                                                          (let ((__tmp8465
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ((__obj8336
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestError::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8466
                                  (cons '(reasoning-feedback-extra f)
                                        (cons 'test:
                                              (cons '(reasoning-feedback-extra
                                                      f)
                                                    (cons 'result:
                                                          (cons _%result5288%_
                                                                (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%expected5285%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                             (declare (not safe))
                             (std/test/base#TestError:::init!
                              __obj8336
                              '"result does not match expectation"
                              'where:
                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@105.25-105.53"
                              'irritants:
                              __tmp8466))
                           __obj8336)))
                    (declare (not safe))
                    (raise __tmp8465))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%desc5297%_ _%desc5278%_)
                                               (_%where5309%_ _%where5281%_)
                                               (_%thunk5319%_ _%thunk5292%_))
                                          (declare (not safe))
                                          (std/test/base#__test-check!
                                           _%desc5297%_
                                           _%where5309%_
                                           _%thunk5319%_)))
                                      (let ((__tmp8468
                                             (lambda (_%bad5329%_)
                                               (let* ((_%desc5331%_
                                                       '(reasoning-feedback-reason
                                                         (reasoning-compare-rows
                                                          source
                                                          p
                                                          r
                                                          bad)))
                                                      (_%where5334%_
                                                       '"\"t/qualification/ascent-candidate-feedback-test.ss\"@106.47-106.114")
                                                      (_%thunk5345%_
                                                       (lambda ()
                                                         (let* ((_%expected5338%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         'invalid-reference)
                        (_%result5341%_
                         (let ((__tmp8469
                                (let ()
                                  (declare (not safe))
                                  (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                                   _%source5155%_
                                   _%p5153%_
                                   _%r5157%_
                                   _%bad5329%_))))
                           (declare (not safe))
                           (##unchecked-structure-ref __tmp8469 '2 '#f '#f))))
                   (if (let ()
                         (declare (not safe))
                         (std/test/unit#equal-values?
                          _%expected5338%_
                          _%result5341%_))
                       '#!void
                       (begin
                         (let ((__tmp8470
                                (let ((__obj8337
                                       (let ()
                                         (declare (not safe))
                                         (##structure
                                          std/test/base#TestError::t
                                          '#f
                                          '#f
                                          '#f
                                          '#f))))
                                  (let ((__tmp8471
                                         (cons '(reasoning-feedback-reason
                                                 (reasoning-compare-rows
                                                  source
                                                  p
                                                  r
                                                  bad))
                                               (cons 'test:
                                                     (cons '(reasoning-feedback-reason
                                                             (reasoning-compare-rows
                                                              source
                                                              p
                                                              r
                                                              bad))
                                                           (cons 'result:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (cons _%result5341%_
                               (cons 'expectation:
                                     (cons _%expected5338%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                    (declare (not safe))
                                    (std/test/base#TestError:::init!
                                     __obj8337
                                     '"result does not match expectation"
                                     'where:
                                     '"\"t/qualification/ascent-candidate-feedback-test.ss\"@106.47-106.114"
                                     'irritants:
                                     __tmp8471))
                                  __obj8337)))
                           (declare (not safe))
                           (raise __tmp8470))
                         '#!void)))))
              (_%desc5350%_ _%desc5331%_)
              (_%where5363%_ _%where5334%_)
              (_%thunk5373%_ _%thunk5345%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (declare (not safe))
                                                 (std/test/base#__test-check!
                                                  _%desc5350%_
                                                  _%where5363%_
                                                  _%thunk5373%_))))
                                            (__tmp8467
                                             (list '((0))
                                                   '((0 1) . 2)
                                                   (list (list '0
                                                               (lambda () '1)))
                                                   (make-list '6000 '(0 1)))))
                                        (declare (not safe))
                                        (##for-each __tmp8468 __tmp8467))
                                      (let ((_%cycle5384%_ (list '(0 1))))
                                        (set-cdr! _%cycle5384%_ _%cycle5384%_)
                                        (let* ((_%desc5386%_
                                                '(reasoning-feedback-reason
                                                  (reasoning-compare-rows
                                                   source
                                                   p
                                                   r
                                                   cycle)))
                                               (_%where5389%_
                                                '"\"t/qualification/ascent-candidate-feedback-test.ss\"@110.25-110.94")
                                               (_%thunk5400%_
                                                (lambda ()
                                                  (let* ((_%expected5393%_
                                                          'invalid-reference)
                                                         (_%result5396%_
                                                          (let ((__tmp8472
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                            _%source5155%_
                            _%p5153%_
                            _%r5157%_
                            _%cycle5384%_))))
                    (declare (not safe))
                    (##unchecked-structure-ref __tmp8472 '2 '#f '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (std/test/unit#equal-values?
                                                           _%expected5393%_
                                                           _%result5396%_))
                                                        '#!void
                                                        (begin
                                                          (let ((__tmp8473
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ((__obj8338
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestError::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8474
                                  (cons '(reasoning-feedback-reason
                                          (reasoning-compare-rows
                                           source
                                           p
                                           r
                                           cycle))
                                        (cons 'test:
                                              (cons '(reasoning-feedback-reason
                                                      (reasoning-compare-rows
                                                       source
                                                       p
                                                       r
                                                       cycle))
                                                    (cons 'result:
                                                          (cons _%result5396%_
                                                                (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%expected5393%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                             (declare (not safe))
                             (std/test/base#TestError:::init!
                              __obj8338
                              '"result does not match expectation"
                              'where:
                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@110.25-110.94"
                              'irritants:
                              __tmp8474))
                           __obj8338)))
                    (declare (not safe))
                    (raise __tmp8473))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%desc5405%_ _%desc5386%_)
                                               (_%where5418%_ _%where5389%_)
                                               (_%thunk5428%_ _%thunk5400%_))
                                          (declare (not safe))
                                          (std/test/base#__test-check!
                                           _%desc5405%_
                                           _%where5418%_
                                           _%thunk5428%_)))))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj8339
                              '"set semantics and bounded reference validation"
                              __tmp8459))
                           __obj8339))
                        (_%tc5443%_ _%tc5438%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc5443%_)))))
          (declare (not safe))
          (std/test/base#TestSuite:::init!
           __obj8340
           '"Candidate execution feedback"
           __tmp8397))
        __obj8340))
    (define gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal__%
      (lambda (_%variant3913%_ _%query3914%_)
        (let ((__tmp8476
               (let ((_%$e3916%_ _%variant3913%_))
                 (if (eq? 'gold _%$e3916%_)
                     '((rule (answer ?city)
                             (route ?city)
                             (not (capital ?city)))
                       (rule (answer ?city) (direct ?city)))
                     (if (eq? 'global _%$e3916%_)
                         '((rule (answer ?city)
                                 (joined ?city)
                                 (not (capital ?city))))
                         '((rule (answer ?city) (joined ?city)))))))
              (__tmp8475 (list _%query3914%_ '(limits 16 64 128))))
          (declare (not safe))
          (##append
           '(candidate
             (relation answer 1)
             (relation joined 1)
             (rule (joined ?city) (route ?city))
             (rule (joined ?city) (direct ?city)))
           __tmp8476
           __tmp8475))))
    (define gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal__0
      (lambda (_%variant3922%_)
        (let ((_%query3924%_ '(query answer ?city)))
          (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal__%
           _%variant3922%_
           _%query3924%_))))
    (define gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal
      (lambda _g8477_
        (let ((_g8478_ (let () (declare (not safe)) (##length _g8477_))))
          (cond ((let () (declare (not safe)) (##fx= _g8478_ 1))
                 (apply gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal__0
                        _g8477_))
                ((let () (declare (not safe)) (##fx= _g8478_ 2))
                 (apply gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal__%
                        _g8477_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal
                  _g8477_))))))
    (define gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-source
      (lambda (_%generation3910%_)
        (let ()
          (declare (not safe))
          (gerbil-ascent/candidate/reasoning#reasoning-source-snapshot
           'scoped-comparison-control
           _%generation3910%_
           '((route 1 ((0) (1) (2)))
             (direct 1 ((0)))
             (capital 1 ((0) (2))))))))
    (define gerbil-ascent/t/qualification/ascent-candidate-feedback-test#ascent-scoped-attempt-feedback-test
      (let ((__obj8366
             (let ()
               (declare (not safe))
               (##structure std/test/base#TestSuite::t '#f '#f '#f '#f '#f))))
        (let ((__tmp8479
               (lambda ()
                 (let* ((_%tc3158%_
                         (let ((__obj8350
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8480
                                  (lambda ()
                                    (let* ((_%source2665%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-source
                                             '0))
                                           (_%gold2667%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal__0
                                             'gold))
                                           (_%reference2669%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                                               _%source2665%_
                                               _%gold2667%_
                                               '#f)))
                                           (_%global2671%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal__0
                                             'global))
                                           (_%positive2673%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal__0
                                             'positive))
                                           (_%global-receipt2675%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                                               _%source2665%_
                                               _%global2671%_
                                               '#f)))
                                           (_%positive-receipt2677%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                                               _%source2665%_
                                               _%positive2673%_
                                               '#f)))
                                           (_%missing2679%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/feedback#reasoning-compare-attempts
                                               _%source2665%_
                                               _%global2671%_
                                               _%global-receipt2675%_
                                               _%gold2667%_
                                               _%reference2669%_)))
                                           (_%extra2681%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/feedback#reasoning-compare-attempts
                                               _%source2665%_
                                               _%positive2673%_
                                               _%positive-receipt2677%_
                                               _%gold2667%_
                                               _%reference2669%_))))
                                      (let ((__tmp8482
                                             (lambda (_%r2684%_)
                                               (let* ((_%desc2686%_
                                                       '(reasoning-receipt-status
                                                         r))
                                                      (_%where2689%_
                                                       '"\"t/qualification/ascent-candidate-feedback-test.ss\"@137.45-137.73")
                                                      (_%thunk2700%_
                                                       (lambda ()
                                                         (let* ((_%expected2693%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         'complete)
                        (_%result2696%_
                         (##structure-ref
                          _%r2684%_
                          '1
                          gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                          '#f)))
                   (if (let ()
                         (declare (not safe))
                         (std/test/unit#equal-values?
                          _%expected2693%_
                          _%result2696%_))
                       '#!void
                       (begin
                         (let ((__tmp8483
                                (let ((__obj8341
                                       (let ()
                                         (declare (not safe))
                                         (##structure
                                          std/test/base#TestError::t
                                          '#f
                                          '#f
                                          '#f
                                          '#f))))
                                  (let ((__tmp8484
                                         (cons '(reasoning-receipt-status r)
                                               (cons 'test:
                                                     (cons '(reasoning-receipt-status
                                                             r)
                                                           (cons 'result:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (cons _%result2696%_
                               (cons 'expectation:
                                     (cons _%expected2693%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                    (declare (not safe))
                                    (std/test/base#TestError:::init!
                                     __obj8341
                                     '"result does not match expectation"
                                     'where:
                                     '"\"t/qualification/ascent-candidate-feedback-test.ss\"@137.45-137.73"
                                     'irritants:
                                     __tmp8484))
                                  __obj8341)))
                           (declare (not safe))
                           (raise __tmp8483))
                         '#!void)))))
              (_%desc2705%_ _%desc2686%_)
              (_%where2730%_ _%where2689%_)
              (_%thunk2740%_ _%thunk2700%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (declare (not safe))
                                                 (std/test/base#__test-check!
                                                  _%desc2705%_
                                                  _%where2730%_
                                                  _%thunk2740%_))))
                                            (__tmp8481
                                             (list _%reference2669%_
                                                   _%global-receipt2675%_
                                                   _%positive-receipt2677%_)))
                                        (declare (not safe))
                                        (##for-each __tmp8482 __tmp8481))
                                      (let* ((_%desc2750%_
                                              '(reasoning-feedback-status
                                                missing))
                                             (_%where2753%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@139.23-139.58")
                                             (_%thunk2764%_
                                              (lambda ()
                                                (let* ((_%expected2757%_
                                                        'mismatch)
                                                       (_%result2760%_
                                                        (let ()
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           _%missing2679%_
                                                           '1
                                                           '#f
                                                           '#f))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected2757%_
                                                         _%result2760%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8485
                                                               (let ((__obj8342
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8486
                                (cons '(reasoning-feedback-status missing)
                                      (cons 'test:
                                            (cons '(reasoning-feedback-status
                                                    missing)
                                                  (cons 'result:
                                                        (cons _%result2760%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected2757%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8342
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@139.23-139.58"
                            'irritants:
                            __tmp8486))
                         __obj8342)))
                  (declare (not safe))
                  (raise __tmp8485))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc2769%_ _%desc2750%_)
                                             (_%where2781%_ _%where2753%_)
                                             (_%thunk2791%_ _%thunk2764%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc2769%_
                                         _%where2781%_
                                         _%thunk2791%_))
                                      (let* ((_%desc2801%_
                                              '(reasoning-feedback-missing
                                                missing))
                                             (_%where2804%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@140.23-140.59")
                                             (_%thunk2815%_
                                              (lambda ()
                                                (let* ((_%expected2808%_
                                                        '((0)))
                                                       (_%result2811%_
                                                        (let ()
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           _%missing2679%_
                                                           '3
                                                           '#f
                                                           '#f))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected2808%_
                                                         _%result2811%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8487
                                                               (let ((__obj8343
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8488
                                (cons '(reasoning-feedback-missing missing)
                                      (cons 'test:
                                            (cons '(reasoning-feedback-missing
                                                    missing)
                                                  (cons 'result:
                                                        (cons _%result2811%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected2808%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8343
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@140.23-140.59"
                            'irritants:
                            __tmp8488))
                         __obj8343)))
                  (declare (not safe))
                  (raise __tmp8487))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc2820%_ _%desc2801%_)
                                             (_%where2832%_ _%where2804%_)
                                             (_%thunk2842%_ _%thunk2815%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc2820%_
                                         _%where2832%_
                                         _%thunk2842%_))
                                      (let* ((_%desc2852%_
                                              '(reasoning-feedback-extra
                                                missing))
                                             (_%where2855%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@141.23-141.57")
                                             (_%thunk2866%_
                                              (lambda ()
                                                (let* ((_%expected2859%_ '())
                                                       (_%result2862%_
                                                        (let ()
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           _%missing2679%_
                                                           '4
                                                           '#f
                                                           '#f))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected2859%_
                                                         _%result2862%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8489
                                                               (let ((__obj8344
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8490
                                (cons '(reasoning-feedback-extra missing)
                                      (cons 'test:
                                            (cons '(reasoning-feedback-extra
                                                    missing)
                                                  (cons 'result:
                                                        (cons _%result2862%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected2859%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8344
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@141.23-141.57"
                            'irritants:
                            __tmp8490))
                         __obj8344)))
                  (declare (not safe))
                  (raise __tmp8489))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc2871%_ _%desc2852%_)
                                             (_%where2883%_ _%where2855%_)
                                             (_%thunk2893%_ _%thunk2866%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc2871%_
                                         _%where2883%_
                                         _%thunk2893%_))
                                      (let* ((_%desc2903%_
                                              '(reasoning-feedback-status
                                                extra))
                                             (_%where2906%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@142.23-142.56")
                                             (_%thunk2917%_
                                              (lambda ()
                                                (let* ((_%expected2910%_
                                                        'mismatch)
                                                       (_%result2913%_
                                                        (let ()
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           _%extra2681%_
                                                           '1
                                                           '#f
                                                           '#f))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected2910%_
                                                         _%result2913%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8491
                                                               (let ((__obj8345
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8492
                                (cons '(reasoning-feedback-status extra)
                                      (cons 'test:
                                            (cons '(reasoning-feedback-status
                                                    extra)
                                                  (cons 'result:
                                                        (cons _%result2913%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected2910%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8345
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@142.23-142.56"
                            'irritants:
                            __tmp8492))
                         __obj8345)))
                  (declare (not safe))
                  (raise __tmp8491))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc2922%_ _%desc2903%_)
                                             (_%where2934%_ _%where2906%_)
                                             (_%thunk2944%_ _%thunk2917%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc2922%_
                                         _%where2934%_
                                         _%thunk2944%_))
                                      (let* ((_%desc2954%_
                                              '(reasoning-feedback-missing
                                                extra))
                                             (_%where2957%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@143.23-143.57")
                                             (_%thunk2968%_
                                              (lambda ()
                                                (let* ((_%expected2961%_ '())
                                                       (_%result2964%_
                                                        (let ()
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           _%extra2681%_
                                                           '3
                                                           '#f
                                                           '#f))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected2961%_
                                                         _%result2964%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8493
                                                               (let ((__obj8346
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8494
                                (cons '(reasoning-feedback-missing extra)
                                      (cons 'test:
                                            (cons '(reasoning-feedback-missing
                                                    extra)
                                                  (cons 'result:
                                                        (cons _%result2964%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected2961%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8346
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@143.23-143.57"
                            'irritants:
                            __tmp8494))
                         __obj8346)))
                  (declare (not safe))
                  (raise __tmp8493))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc2973%_ _%desc2954%_)
                                             (_%where2985%_ _%where2957%_)
                                             (_%thunk2995%_ _%thunk2968%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc2973%_
                                         _%where2985%_
                                         _%thunk2995%_))
                                      (let* ((_%desc3005%_
                                              '(reasoning-feedback-extra
                                                extra))
                                             (_%where3008%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@144.23-144.55")
                                             (_%thunk3019%_
                                              (lambda ()
                                                (let* ((_%expected3012%_
                                                        '((2)))
                                                       (_%result3015%_
                                                        (let ()
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           _%extra2681%_
                                                           '4
                                                           '#f
                                                           '#f))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3012%_
                                                         _%result3015%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8495
                                                               (let ((__obj8347
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8496
                                (cons '(reasoning-feedback-extra extra)
                                      (cons 'test:
                                            (cons '(reasoning-feedback-extra
                                                    extra)
                                                  (cons 'result:
                                                        (cons _%result3015%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3012%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8347
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@144.23-144.55"
                            'irritants:
                            __tmp8496))
                         __obj8347)))
                  (declare (not safe))
                  (raise __tmp8495))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3024%_ _%desc3005%_)
                                             (_%where3036%_ _%where3008%_)
                                             (_%thunk3046%_ _%thunk3019%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3024%_
                                         _%where3036%_
                                         _%thunk3046%_))
                                      (let* ((_%desc3056%_
                                              '(reasoning-feedback-status
                                                (reasoning-compare-attempts
                                                 source
                                                 gold
                                                 reference
                                                 gold
                                                 reference)))
                                             (_%where3059%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@145.23-146.90")
                                             (_%thunk3070%_
                                              (lambda ()
                                                (let* ((_%expected3063%_
                                                        'match)
                                                       (_%result3066%_
                                                        (let ((__tmp8497
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gerbil-ascent/candidate/feedback#reasoning-compare-attempts
                          _%source2665%_
                          _%gold2667%_
                          _%reference2669%_
                          _%gold2667%_
                          _%reference2669%_))))
                  (declare (not safe))
                  (##unchecked-structure-ref __tmp8497 '1 '#f '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3063%_
                                                         _%result3066%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8498
                                                               (let ((__obj8348
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8499
                                (cons '(reasoning-feedback-status
                                        (reasoning-compare-attempts
                                         source
                                         gold
                                         reference
                                         gold
                                         reference))
                                      (cons 'test:
                                            (cons '(reasoning-feedback-status
                                                    (reasoning-compare-attempts
                                                     source
                                                     gold
                                                     reference
                                                     gold
                                                     reference))
                                                  (cons 'result:
                                                        (cons _%result3066%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3063%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8348
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@145.23-146.90"
                            'irritants:
                            __tmp8499))
                         __obj8348)))
                  (declare (not safe))
                  (raise __tmp8498))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3075%_ _%desc3056%_)
                                             (_%where3087%_ _%where3059%_)
                                             (_%thunk3097%_ _%thunk3070%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3075%_
                                         _%where3087%_
                                         _%thunk3097%_))
                                      (let* ((_%desc3107%_
                                              '(reasoning-feedback-status
                                                (reasoning-compare-attempts
                                                 source
                                                 global
                                                 global-receipt
                                                 global
                                                 global-receipt)))
                                             (_%where3110%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@149.23-150.104")
                                             (_%thunk3121%_
                                              (lambda ()
                                                (let* ((_%expected3114%_
                                                        'match)
                                                       (_%result3117%_
                                                        (let ((__tmp8500
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gerbil-ascent/candidate/feedback#reasoning-compare-attempts
                          _%source2665%_
                          _%global2671%_
                          _%global-receipt2675%_
                          _%global2671%_
                          _%global-receipt2675%_))))
                  (declare (not safe))
                  (##unchecked-structure-ref __tmp8500 '1 '#f '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3114%_
                                                         _%result3117%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8501
                                                               (let ((__obj8349
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8502
                                (cons '(reasoning-feedback-status
                                        (reasoning-compare-attempts
                                         source
                                         global
                                         global-receipt
                                         global
                                         global-receipt))
                                      (cons 'test:
                                            (cons '(reasoning-feedback-status
                                                    (reasoning-compare-attempts
                                                     source
                                                     global
                                                     global-receipt
                                                     global
                                                     global-receipt))
                                                  (cons 'result:
                                                        (cons _%result3117%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3114%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8349
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@149.23-150.104"
                            'irritants:
                            __tmp8502))
                         __obj8349)))
                  (declare (not safe))
                  (raise __tmp8501))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3126%_ _%desc3107%_)
                                             (_%where3138%_ _%where3110%_)
                                             (_%thunk3148%_ _%thunk3121%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3126%_
                                         _%where3138%_
                                         _%thunk3148%_))))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj8350
                              '"complete scope errors have exact missing and extra rows"
                              __tmp8480))
                           __obj8350))
                        (_%tc3163%_ _%tc3158%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc3163%_))
                 (let* ((_%tc3671%_
                         (let ((__obj8360
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8503
                                  (lambda ()
                                    (let* ((_%source3174%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-source
                                             '0))
                                           (_%new-source3176%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-source
                                             '1))
                                           (_%gold3178%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal__0
                                             'gold))
                                           (_%p3180%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal__0
                                             'global))
                                           (_%reference3182%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                                               _%source3174%_
                                               _%gold3178%_
                                               '#f)))
                                           (_%current3184%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                                               _%new-source3176%_
                                               _%p3180%_
                                               '#f)))
                                           (_%rejected-p3186%_
                                            '(candidate
                                              (relation answer 1)
                                              (rule (answer ?city)
                                                    (unknown ?city))
                                              (query answer ?city)
                                              (limits 16 64 128)))
                                           (_%rejected3188%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                                               _%new-source3176%_
                                               _%rejected-p3186%_
                                               '#f))))
                                      (let* ((_%desc3191%_
                                              '(reasoning-feedback-reason
                                                (reasoning-compare-attempts
                                                 new-source
                                                 p
                                                 current
                                                 gold
                                                 reference)))
                                             (_%where3194%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@160.23-161.89")
                                             (_%thunk3205%_
                                              (lambda ()
                                                (let* ((_%expected3198%_
                                                        'reference-unbound)
                                                       (_%result3201%_
                                                        (let ((__tmp8504
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gerbil-ascent/candidate/feedback#reasoning-compare-attempts
                          _%new-source3176%_
                          _%p3180%_
                          _%current3184%_
                          _%gold3178%_
                          _%reference3182%_))))
                  (declare (not safe))
                  (##unchecked-structure-ref __tmp8504 '2 '#f '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3198%_
                                                         _%result3201%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8505
                                                               (let ((__obj8351
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8506
                                (cons '(reasoning-feedback-reason
                                        (reasoning-compare-attempts
                                         new-source
                                         p
                                         current
                                         gold
                                         reference))
                                      (cons 'test:
                                            (cons '(reasoning-feedback-reason
                                                    (reasoning-compare-attempts
                                                     new-source
                                                     p
                                                     current
                                                     gold
                                                     reference))
                                                  (cons 'result:
                                                        (cons _%result3201%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3198%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8351
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@160.23-161.89"
                            'irritants:
                            __tmp8506))
                         __obj8351)))
                  (declare (not safe))
                  (raise __tmp8505))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3210%_ _%desc3191%_)
                                             (_%where3232%_ _%where3194%_)
                                             (_%thunk3242%_ _%thunk3205%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3210%_
                                         _%where3232%_
                                         _%thunk3242%_))
                                      (let* ((_%desc3252%_
                                              '(reasoning-feedback-reason
                                                (reasoning-compare-attempts
                                                 source
                                                 p
                                                 current
                                                 gold
                                                 reference)))
                                             (_%where3255%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@162.23-163.85")
                                             (_%thunk3266%_
                                              (lambda ()
                                                (let* ((_%expected3259%_
                                                        'unbound)
                                                       (_%result3262%_
                                                        (let ((__tmp8507
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gerbil-ascent/candidate/feedback#reasoning-compare-attempts
                          _%source3174%_
                          _%p3180%_
                          _%current3184%_
                          _%gold3178%_
                          _%reference3182%_))))
                  (declare (not safe))
                  (##unchecked-structure-ref __tmp8507 '2 '#f '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3259%_
                                                         _%result3262%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8508
                                                               (let ((__obj8352
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8509
                                (cons '(reasoning-feedback-reason
                                        (reasoning-compare-attempts
                                         source
                                         p
                                         current
                                         gold
                                         reference))
                                      (cons 'test:
                                            (cons '(reasoning-feedback-reason
                                                    (reasoning-compare-attempts
                                                     source
                                                     p
                                                     current
                                                     gold
                                                     reference))
                                                  (cons 'result:
                                                        (cons _%result3262%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3259%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8352
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@162.23-163.85"
                            'irritants:
                            __tmp8509))
                         __obj8352)))
                  (declare (not safe))
                  (raise __tmp8508))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3271%_ _%desc3252%_)
                                             (_%where3283%_ _%where3255%_)
                                             (_%thunk3293%_ _%thunk3266%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3271%_
                                         _%where3283%_
                                         _%thunk3293%_))
                                      (let* ((_%desc3303%_
                                              '(reasoning-feedback-reason
                                                (reasoning-compare-attempts
                                                 source
                                                 gold
                                                 reference
                                                 p
                                                 reference)))
                                             (_%where3306%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@164.23-165.87")
                                             (_%thunk3317%_
                                              (lambda ()
                                                (let* ((_%expected3310%_
                                                        'reference-unbound)
                                                       (_%result3313%_
                                                        (let ((__tmp8510
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gerbil-ascent/candidate/feedback#reasoning-compare-attempts
                          _%source3174%_
                          _%gold3178%_
                          _%reference3182%_
                          _%p3180%_
                          _%reference3182%_))))
                  (declare (not safe))
                  (##unchecked-structure-ref __tmp8510 '2 '#f '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3310%_
                                                         _%result3313%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8511
                                                               (let ((__obj8353
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8512
                                (cons '(reasoning-feedback-reason
                                        (reasoning-compare-attempts
                                         source
                                         gold
                                         reference
                                         p
                                         reference))
                                      (cons 'test:
                                            (cons '(reasoning-feedback-reason
                                                    (reasoning-compare-attempts
                                                     source
                                                     gold
                                                     reference
                                                     p
                                                     reference))
                                                  (cons 'result:
                                                        (cons _%result3313%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3310%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8353
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@164.23-165.87"
                            'irritants:
                            __tmp8512))
                         __obj8353)))
                  (declare (not safe))
                  (raise __tmp8511))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3322%_ _%desc3303%_)
                                             (_%where3334%_ _%where3306%_)
                                             (_%thunk3344%_ _%thunk3317%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3322%_
                                         _%where3334%_
                                         _%thunk3344%_))
                                      (let ((_%f3354%_
                                             (let ()
                                               (declare (not safe))
                                               (gerbil-ascent/candidate/feedback#reasoning-compare-attempts
                                                _%new-source3176%_
                                                _%p3180%_
                                                _%current3184%_
                                                _%rejected-p3186%_
                                                _%rejected3188%_))))
                                        (let* ((_%desc3356%_
                                                '(reasoning-feedback-reason f))
                                               (_%where3359%_
                                                '"\"t/qualification/ascent-candidate-feedback-test.ss\"@167.25-167.54")
                                               (_%thunk3370%_
                                                (lambda ()
                                                  (let* ((_%expected3363%_
                                                          'reference-incomplete)
                                                         (_%result3366%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (##unchecked-structure-ref
                                                             _%f3354%_
                                                             '2
                                                             '#f
                                                             '#f))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (std/test/unit#equal-values?
                                                           _%expected3363%_
                                                           _%result3366%_))
                                                        '#!void
                                                        (begin
                                                          (let ((__tmp8513
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ((__obj8354
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestError::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8514
                                  (cons '(reasoning-feedback-reason f)
                                        (cons 'test:
                                              (cons '(reasoning-feedback-reason
                                                      f)
                                                    (cons 'result:
                                                          (cons _%result3366%_
                                                                (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%expected3363%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                             (declare (not safe))
                             (std/test/base#TestError:::init!
                              __obj8354
                              '"result does not match expectation"
                              'where:
                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@167.25-167.54"
                              'irritants:
                              __tmp8514))
                           __obj8354)))
                    (declare (not safe))
                    (raise __tmp8513))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%desc3375%_ _%desc3356%_)
                                               (_%where3388%_ _%where3359%_)
                                               (_%thunk3398%_ _%thunk3370%_))
                                          (declare (not safe))
                                          (std/test/base#__test-check!
                                           _%desc3375%_
                                           _%where3388%_
                                           _%thunk3398%_))
                                        (let* ((_%desc3408%_
                                                '(reasoning-feedback-missing
                                                  f))
                                               (_%where3411%_
                                                '"\"t/qualification/ascent-candidate-feedback-test.ss\"@168.25-168.55")
                                               (_%thunk3422%_
                                                (lambda ()
                                                  (let* ((_%expected3415%_ '())
                                                         (_%result3418%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (##unchecked-structure-ref
                                                             _%f3354%_
                                                             '3
                                                             '#f
                                                             '#f))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (std/test/unit#equal-values?
                                                           _%expected3415%_
                                                           _%result3418%_))
                                                        '#!void
                                                        (begin
                                                          (let ((__tmp8515
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ((__obj8355
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestError::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8516
                                  (cons '(reasoning-feedback-missing f)
                                        (cons 'test:
                                              (cons '(reasoning-feedback-missing
                                                      f)
                                                    (cons 'result:
                                                          (cons _%result3418%_
                                                                (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%expected3415%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                             (declare (not safe))
                             (std/test/base#TestError:::init!
                              __obj8355
                              '"result does not match expectation"
                              'where:
                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@168.25-168.55"
                              'irritants:
                              __tmp8516))
                           __obj8355)))
                    (declare (not safe))
                    (raise __tmp8515))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%desc3427%_ _%desc3408%_)
                                               (_%where3439%_ _%where3411%_)
                                               (_%thunk3449%_ _%thunk3422%_))
                                          (declare (not safe))
                                          (std/test/base#__test-check!
                                           _%desc3427%_
                                           _%where3439%_
                                           _%thunk3449%_))
                                        (let* ((_%desc3459%_
                                                '(reasoning-feedback-extra f))
                                               (_%where3462%_
                                                '"\"t/qualification/ascent-candidate-feedback-test.ss\"@169.25-169.53")
                                               (_%thunk3473%_
                                                (lambda ()
                                                  (let* ((_%expected3466%_ '())
                                                         (_%result3469%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (##unchecked-structure-ref
                                                             _%f3354%_
                                                             '4
                                                             '#f
                                                             '#f))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (std/test/unit#equal-values?
                                                           _%expected3466%_
                                                           _%result3469%_))
                                                        '#!void
                                                        (begin
                                                          (let ((__tmp8517
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ((__obj8356
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestError::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8518
                                  (cons '(reasoning-feedback-extra f)
                                        (cons 'test:
                                              (cons '(reasoning-feedback-extra
                                                      f)
                                                    (cons 'result:
                                                          (cons _%result3469%_
                                                                (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%expected3466%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                             (declare (not safe))
                             (std/test/base#TestError:::init!
                              __obj8356
                              '"result does not match expectation"
                              'where:
                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@169.25-169.53"
                              'irritants:
                              __tmp8518))
                           __obj8356)))
                    (declare (not safe))
                    (raise __tmp8517))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%desc3478%_ _%desc3459%_)
                                               (_%where3490%_ _%where3462%_)
                                               (_%thunk3500%_ _%thunk3473%_))
                                          (declare (not safe))
                                          (std/test/base#__test-check!
                                           _%desc3478%_
                                           _%where3490%_
                                           _%thunk3500%_)))
                                      (let* ((_%desc3510%_
                                              '(reasoning-feedback-reason
                                                (reasoning-compare-attempts
                                                 new-source
                                                 rejected-p
                                                 rejected
                                                 p
                                                 current)))
                                             (_%where3513%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@170.23-171.94")
                                             (_%thunk3524%_
                                              (lambda ()
                                                (let* ((_%expected3517%_
                                                        'rejected)
                                                       (_%result3520%_
                                                        (let ((__tmp8519
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gerbil-ascent/candidate/feedback#reasoning-compare-attempts
                          _%new-source3176%_
                          _%rejected-p3186%_
                          _%rejected3188%_
                          _%p3180%_
                          _%current3184%_))))
                  (declare (not safe))
                  (##unchecked-structure-ref __tmp8519 '2 '#f '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3517%_
                                                         _%result3520%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8520
                                                               (let ((__obj8357
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8521
                                (cons '(reasoning-feedback-reason
                                        (reasoning-compare-attempts
                                         new-source
                                         rejected-p
                                         rejected
                                         p
                                         current))
                                      (cons 'test:
                                            (cons '(reasoning-feedback-reason
                                                    (reasoning-compare-attempts
                                                     new-source
                                                     rejected-p
                                                     rejected
                                                     p
                                                     current))
                                                  (cons 'result:
                                                        (cons _%result3520%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3517%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8357
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@170.23-171.94"
                            'irritants:
                            __tmp8521))
                         __obj8357)))
                  (declare (not safe))
                  (raise __tmp8520))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3529%_ _%desc3510%_)
                                             (_%where3541%_ _%where3513%_)
                                             (_%thunk3551%_ _%thunk3524%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3529%_
                                         _%where3541%_
                                         _%thunk3551%_))
                                      (let* ((_%limited3561%_
                                              (let ((__tmp8522
                                                     (reverse (cdr (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (declare (not safe))
                             (##reverse _%gold3178%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (declare (not safe))
                                                (##append
                                                 __tmp8522
                                                 '((limits 16 1 1)))))
                                             (_%unfinished3563%_
                                              (let ()
                                                (declare (not safe))
                                                (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                                                 _%new-source3176%_
                                                 _%limited3561%_
                                                 '#f))))
                                        (let* ((_%desc3566%_
                                                '(eq? (reasoning-receipt-status
                                                       unfinished)
                                                      'complete))
                                               (_%where3569%_
                                                '"\"t/qualification/ascent-candidate-feedback-test.ss\"@174.25-174.78")
                                               (_%thunk3580%_
                                                (lambda ()
                                                  (let* ((_%expected3573%_ '#f)
                                                         (_%result3576%_
                                                          (eq? (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%unfinished3563%_
                          '1
                          '#f
                          '#f))
                       'complete)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (std/test/unit#equal-values?
                                                           _%expected3573%_
                                                           _%result3576%_))
                                                        '#!void
                                                        (begin
                                                          (let ((__tmp8523
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ((__obj8358
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestError::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8524
                                  (cons '(eq? (reasoning-receipt-status
                                               unfinished)
                                              'complete)
                                        (cons 'test:
                                              (cons '(eq? (reasoning-receipt-status
                                                           unfinished)
                                                          'complete)
                                                    (cons 'result:
                                                          (cons _%result3576%_
                                                                (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%expected3573%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                             (declare (not safe))
                             (std/test/base#TestError:::init!
                              __obj8358
                              '"result does not match expectation"
                              'where:
                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@174.25-174.78"
                              'irritants:
                              __tmp8524))
                           __obj8358)))
                    (declare (not safe))
                    (raise __tmp8523))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%desc3585%_ _%desc3566%_)
                                               (_%where3600%_ _%where3569%_)
                                               (_%thunk3610%_ _%thunk3580%_))
                                          (declare (not safe))
                                          (std/test/base#__test-check!
                                           _%desc3585%_
                                           _%where3600%_
                                           _%thunk3610%_))
                                        (let* ((_%desc3620%_
                                                '(reasoning-feedback-reason
                                                  (reasoning-compare-attempts
                                                   new-source
                                                   p
                                                   current
                                                   limited
                                                   unfinished)))
                                               (_%where3623%_
                                                '"\"t/qualification/ascent-candidate-feedback-test.ss\"@175.25-176.95")
                                               (_%thunk3634%_
                                                (lambda ()
                                                  (let* ((_%expected3627%_
                                                          'reference-incomplete)
                                                         (_%result3630%_
                                                          (let ((__tmp8525
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/feedback#reasoning-compare-attempts
                            _%new-source3176%_
                            _%p3180%_
                            _%current3184%_
                            _%limited3561%_
                            _%unfinished3563%_))))
                    (declare (not safe))
                    (##unchecked-structure-ref __tmp8525 '2 '#f '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (std/test/unit#equal-values?
                                                           _%expected3627%_
                                                           _%result3630%_))
                                                        '#!void
                                                        (begin
                                                          (let ((__tmp8526
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ((__obj8359
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestError::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8527
                                  (cons '(reasoning-feedback-reason
                                          (reasoning-compare-attempts
                                           new-source
                                           p
                                           current
                                           limited
                                           unfinished))
                                        (cons 'test:
                                              (cons '(reasoning-feedback-reason
                                                      (reasoning-compare-attempts
                                                       new-source
                                                       p
                                                       current
                                                       limited
                                                       unfinished))
                                                    (cons 'result:
                                                          (cons _%result3630%_
                                                                (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%expected3627%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                             (declare (not safe))
                             (std/test/base#TestError:::init!
                              __obj8359
                              '"result does not match expectation"
                              'where:
                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@175.25-176.95"
                              'irritants:
                              __tmp8527))
                           __obj8359)))
                    (declare (not safe))
                    (raise __tmp8526))
                  '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%desc3639%_ _%desc3620%_)
                                               (_%where3651%_ _%where3623%_)
                                               (_%thunk3661%_ _%thunk3634%_))
                                          (declare (not safe))
                                          (std/test/base#__test-check!
                                           _%desc3639%_
                                           _%where3651%_
                                           _%thunk3661%_)))))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj8360
                              '"both receipt bindings and reference completion gate comparison"
                              __tmp8503))
                           __obj8360))
                        (_%tc3676%_ _%tc3671%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc3676%_))
                 (let* ((_%tc3807%_
                         (let ((__obj8363
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8528
                                  (lambda ()
                                    (let* ((_%source3687%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-source
                                             '0))
                                           (_%gold3689%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal__0
                                             'gold))
                                           (_%p3691%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal__%
                                             'gold
                                             '(query answer 0)))
                                           (_%reference3693%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                                               _%source3687%_
                                               _%gold3689%_
                                               '#f)))
                                           (_%r3695%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                                               _%source3687%_
                                               _%p3691%_
                                               '#f))))
                                      (let* ((_%desc3698%_
                                              '(reasoning-receipt-status r))
                                             (_%where3701%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@182.23-182.51")
                                             (_%thunk3712%_
                                              (lambda ()
                                                (let* ((_%expected3705%_
                                                        'complete)
                                                       (_%result3708%_
                                                        (let ()
                                                          (declare (not safe))
                                                          (##unchecked-structure-ref
                                                           _%r3695%_
                                                           '1
                                                           '#f
                                                           '#f))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3705%_
                                                         _%result3708%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8529
                                                               (let ((__obj8361
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8530
                                (cons '(reasoning-receipt-status r)
                                      (cons 'test:
                                            (cons '(reasoning-receipt-status r)
                                                  (cons 'result:
                                                        (cons _%result3708%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3705%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8361
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@182.23-182.51"
                            'irritants:
                            __tmp8530))
                         __obj8361)))
                  (declare (not safe))
                  (raise __tmp8529))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3717%_ _%desc3698%_)
                                             (_%where3736%_ _%where3701%_)
                                             (_%thunk3746%_ _%thunk3712%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3717%_
                                         _%where3736%_
                                         _%thunk3746%_))
                                      (let* ((_%desc3756%_
                                              '(reasoning-feedback-reason
                                                (reasoning-compare-attempts
                                                 source
                                                 p
                                                 r
                                                 gold
                                                 reference)))
                                             (_%where3759%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@183.23-184.79")
                                             (_%thunk3770%_
                                              (lambda ()
                                                (let* ((_%expected3763%_
                                                        'query-mismatch)
                                                       (_%result3766%_
                                                        (let ((__tmp8531
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gerbil-ascent/candidate/feedback#reasoning-compare-attempts
                          _%source3687%_
                          _%p3691%_
                          _%r3695%_
                          _%gold3689%_
                          _%reference3693%_))))
                  (declare (not safe))
                  (##unchecked-structure-ref __tmp8531 '2 '#f '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3763%_
                                                         _%result3766%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8532
                                                               (let ((__obj8362
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8533
                                (cons '(reasoning-feedback-reason
                                        (reasoning-compare-attempts
                                         source
                                         p
                                         r
                                         gold
                                         reference))
                                      (cons 'test:
                                            (cons '(reasoning-feedback-reason
                                                    (reasoning-compare-attempts
                                                     source
                                                     p
                                                     r
                                                     gold
                                                     reference))
                                                  (cons 'result:
                                                        (cons _%result3766%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3763%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8362
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@183.23-184.79"
                            'irritants:
                            __tmp8533))
                         __obj8362)))
                  (declare (not safe))
                  (raise __tmp8532))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3775%_ _%desc3756%_)
                                             (_%where3787%_ _%where3759%_)
                                             (_%thunk3797%_ _%thunk3770%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3775%_
                                         _%where3787%_
                                         _%thunk3797%_))))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj8363
                              '"equal arity with a changed query constant is not comparable"
                              __tmp8528))
                           __obj8363))
                        (_%tc3812%_ _%tc3807%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc3812%_))
                 (let* ((_%tc3895%_
                         (let ((__obj8365
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8534
                                  (lambda ()
                                    (let* ((_%source3823%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-source
                                             '0))
                                           (_%gold3825%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal__0
                                             'gold))
                                           (_%p3827%_
                                            (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal__0
                                             'global))
                                           (_%reference3829%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                                               _%source3823%_
                                               _%gold3825%_
                                               '#f)))
                                           (_%r3831%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                                               _%source3823%_
                                               _%p3827%_
                                               '#f)))
                                           (_%f3833%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/feedback#reasoning-compare-attempts
                                               _%source3823%_
                                               _%p3827%_
                                               _%r3831%_
                                               _%gold3825%_
                                               _%reference3829%_))))
                                      (set-car!
                                       (car (let ()
                                              (declare (not safe))
                                              (##unchecked-structure-ref
                                               _%f3833%_
                                               '3
                                               '#f
                                               '#f)))
                                       '9)
                                      (let* ((_%desc3836%_
                                              '(reasoning-feedback-missing
                                                (reasoning-compare-attempts
                                                 source
                                                 p
                                                 r
                                                 gold
                                                 reference)))
                                             (_%where3839%_
                                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@191.23-192.79")
                                             (_%thunk3850%_
                                              (lambda ()
                                                (let* ((_%expected3843%_
                                                        '((0)))
                                                       (_%result3846%_
                                                        (let ((__tmp8535
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gerbil-ascent/candidate/feedback#reasoning-compare-attempts
                          _%source3823%_
                          _%p3827%_
                          _%r3831%_
                          _%gold3825%_
                          _%reference3829%_))))
                  (declare (not safe))
                  (##unchecked-structure-ref __tmp8535 '3 '#f '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (std/test/unit#equal-values?
                                                         _%expected3843%_
                                                         _%result3846%_))
                                                      '#!void
                                                      (begin
                                                        (let ((__tmp8536
                                                               (let ((__obj8364
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ()
                                (declare (not safe))
                                (##structure
                                 std/test/base#TestError::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp8537
                                (cons '(reasoning-feedback-missing
                                        (reasoning-compare-attempts
                                         source
                                         p
                                         r
                                         gold
                                         reference))
                                      (cons 'test:
                                            (cons '(reasoning-feedback-missing
                                                    (reasoning-compare-attempts
                                                     source
                                                     p
                                                     r
                                                     gold
                                                     reference))
                                                  (cons 'result:
                                                        (cons _%result3846%_
                                                              (cons 'expectation:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons _%expected3843%_ '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                           (declare (not safe))
                           (std/test/base#TestError:::init!
                            __obj8364
                            '"result does not match expectation"
                            'where:
                            '"\"t/qualification/ascent-candidate-feedback-test.ss\"@191.23-192.79"
                            'irritants:
                            __tmp8537))
                         __obj8364)))
                  (declare (not safe))
                  (raise __tmp8536))
                '#!void)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%desc3855%_ _%desc3836%_)
                                             (_%where3875%_ _%where3839%_)
                                             (_%thunk3885%_ _%thunk3850%_))
                                        (declare (not safe))
                                        (std/test/base#__test-check!
                                         _%desc3855%_
                                         _%where3875%_
                                         _%thunk3885%_))))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj8365
                              '"published differences do not retain reference row pairs"
                              __tmp8534))
                           __obj8365))
                        (_%tc3900%_ _%tc3895%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc3900%_)))))
          (declare (not safe))
          (std/test/base#TestSuite:::init!
           __obj8366
           '"Same-source proposal comparison"
           __tmp8479))
        __obj8366))
    (define gerbil-ascent/t/qualification/ascent-candidate-feedback-test#check-feedback-correspondence
      (lambda (_%fault2033%_)
        (let* ((_%source2035%_
                (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-source
                 '1))
               (_%gold2037%_
                (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal__0
                 'gold))
               (_%reference2039%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                   _%source2035%_
                   _%gold2037%_
                   '#f))))
          (letrec ((_%compare2042%_
                    (lambda (_%p2658%_ _%r2659%_ _%gp2660%_ _%gr2661%_)
                      (let ()
                        (declare (not safe))
                        (gerbil-ascent/candidate/feedback#reasoning-compare-attempts
                         _%source2035%_
                         _%p2658%_
                         _%r2659%_
                         _%gp2660%_
                         _%gr2661%_))))
                   (_%assert-refused2043%_
                    (lambda (_%feedback2450%_ _%reason2451%_)
                      (let* ((_%desc2453%_
                              '(reasoning-feedback-status feedback))
                             (_%where2456%_
                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@203.21-203.57")
                             (_%thunk2467%_
                              (lambda ()
                                (let* ((_%expected2460%_ 'inconclusive)
                                       (_%result2463%_
                                        (##direct-structure-ref
                                         _%feedback2450%_
                                         '1
                                         gerbil-ascent/candidate/feedback#reasoning-feedback::t
                                         '#f)))
                                  (if (let ()
                                        (declare (not safe))
                                        (std/test/unit#equal-values?
                                         _%expected2460%_
                                         _%result2463%_))
                                      '#!void
                                      (begin
                                        (let ((__tmp8538
                                               (let ((__obj8367
                                                      (let ()
                                                        (declare (not safe))
                                                        (##structure
                                                         std/test/base#TestError::t
                                                         '#f
                                                         '#f
                                                         '#f
                                                         '#f))))
                                                 (let ((__tmp8539
                                                        (cons '(reasoning-feedback-status
                                                                feedback)
                                                              (cons 'test:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons '(reasoning-feedback-status feedback)
                                  (cons 'result:
                                        (cons _%result2463%_
                                              (cons 'expectation:
                                                    (cons _%expected2460%_
                                                          '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (declare (not safe))
                                                   (std/test/base#TestError:::init!
                                                    __obj8367
                                                    '"result does not match expectation"
                                                    'where:
                                                    '"\"t/qualification/ascent-candidate-feedback-test.ss\"@203.21-203.57"
                                                    'irritants:
                                                    __tmp8539))
                                                 __obj8367)))
                                          (declare (not safe))
                                          (raise __tmp8538))
                                        '#!void)))))
                             (_%desc2472%_ _%desc2453%_)
                             (_%where2485%_ _%where2456%_)
                             (_%thunk2495%_ _%thunk2467%_))
                        (declare (not safe))
                        (std/test/base#__test-check!
                         _%desc2472%_
                         _%where2485%_
                         _%thunk2495%_))
                      (let* ((_%desc2505%_
                              '(reasoning-feedback-reason feedback))
                             (_%where2508%_
                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@204.21-204.57")
                             (_%thunk2519%_
                              (lambda ()
                                (let* ((_%expected2512%_ _%reason2451%_)
                                       (_%result2515%_
                                        (##direct-structure-ref
                                         _%feedback2450%_
                                         '2
                                         gerbil-ascent/candidate/feedback#reasoning-feedback::t
                                         '#f)))
                                  (if (let ()
                                        (declare (not safe))
                                        (std/test/unit#equal-values?
                                         _%expected2512%_
                                         _%result2515%_))
                                      '#!void
                                      (begin
                                        (let ((__tmp8540
                                               (let ((__obj8368
                                                      (let ()
                                                        (declare (not safe))
                                                        (##structure
                                                         std/test/base#TestError::t
                                                         '#f
                                                         '#f
                                                         '#f
                                                         '#f))))
                                                 (let ((__tmp8541
                                                        (cons '(reasoning-feedback-reason
                                                                feedback)
                                                              (cons 'test:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons '(reasoning-feedback-reason feedback)
                                  (cons 'result:
                                        (cons _%result2515%_
                                              (cons 'expectation:
                                                    (cons _%expected2512%_
                                                          '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (declare (not safe))
                                                   (std/test/base#TestError:::init!
                                                    __obj8368
                                                    '"result does not match expectation"
                                                    'where:
                                                    '"\"t/qualification/ascent-candidate-feedback-test.ss\"@204.21-204.57"
                                                    'irritants:
                                                    __tmp8541))
                                                 __obj8368)))
                                          (declare (not safe))
                                          (raise __tmp8540))
                                        '#!void)))))
                             (_%desc2524%_ _%desc2505%_)
                             (_%where2536%_ _%where2508%_)
                             (_%thunk2546%_ _%thunk2519%_))
                        (declare (not safe))
                        (std/test/base#__test-check!
                         _%desc2524%_
                         _%where2536%_
                         _%thunk2546%_))
                      (let* ((_%desc2556%_
                              '(reasoning-feedback-missing feedback))
                             (_%where2559%_
                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@205.21-205.58")
                             (_%thunk2570%_
                              (lambda ()
                                (let* ((_%expected2563%_ '())
                                       (_%result2566%_
                                        (##direct-structure-ref
                                         _%feedback2450%_
                                         '3
                                         gerbil-ascent/candidate/feedback#reasoning-feedback::t
                                         '#f)))
                                  (if (let ()
                                        (declare (not safe))
                                        (std/test/unit#equal-values?
                                         _%expected2563%_
                                         _%result2566%_))
                                      '#!void
                                      (begin
                                        (let ((__tmp8542
                                               (let ((__obj8369
                                                      (let ()
                                                        (declare (not safe))
                                                        (##structure
                                                         std/test/base#TestError::t
                                                         '#f
                                                         '#f
                                                         '#f
                                                         '#f))))
                                                 (let ((__tmp8543
                                                        (cons '(reasoning-feedback-missing
                                                                feedback)
                                                              (cons 'test:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons '(reasoning-feedback-missing feedback)
                                  (cons 'result:
                                        (cons _%result2566%_
                                              (cons 'expectation:
                                                    (cons _%expected2563%_
                                                          '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (declare (not safe))
                                                   (std/test/base#TestError:::init!
                                                    __obj8369
                                                    '"result does not match expectation"
                                                    'where:
                                                    '"\"t/qualification/ascent-candidate-feedback-test.ss\"@205.21-205.58"
                                                    'irritants:
                                                    __tmp8543))
                                                 __obj8369)))
                                          (declare (not safe))
                                          (raise __tmp8542))
                                        '#!void)))))
                             (_%desc2575%_ _%desc2556%_)
                             (_%where2587%_ _%where2559%_)
                             (_%thunk2597%_ _%thunk2570%_))
                        (declare (not safe))
                        (std/test/base#__test-check!
                         _%desc2575%_
                         _%where2587%_
                         _%thunk2597%_))
                      (let* ((_%desc2607%_
                              '(reasoning-feedback-extra feedback))
                             (_%where2610%_
                              '"\"t/qualification/ascent-candidate-feedback-test.ss\"@206.21-206.56")
                             (_%thunk2621%_
                              (lambda ()
                                (let* ((_%expected2614%_ '())
                                       (_%result2617%_
                                        (##direct-structure-ref
                                         _%feedback2450%_
                                         '4
                                         gerbil-ascent/candidate/feedback#reasoning-feedback::t
                                         '#f)))
                                  (if (let ()
                                        (declare (not safe))
                                        (std/test/unit#equal-values?
                                         _%expected2614%_
                                         _%result2617%_))
                                      '#!void
                                      (begin
                                        (let ((__tmp8544
                                               (let ((__obj8370
                                                      (let ()
                                                        (declare (not safe))
                                                        (##structure
                                                         std/test/base#TestError::t
                                                         '#f
                                                         '#f
                                                         '#f
                                                         '#f))))
                                                 (let ((__tmp8545
                                                        (cons '(reasoning-feedback-extra
                                                                feedback)
                                                              (cons 'test:
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (cons '(reasoning-feedback-extra feedback)
                                  (cons 'result:
                                        (cons _%result2617%_
                                              (cons 'expectation:
                                                    (cons _%expected2614%_
                                                          '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (declare (not safe))
                                                   (std/test/base#TestError:::init!
                                                    __obj8370
                                                    '"result does not match expectation"
                                                    'where:
                                                    '"\"t/qualification/ascent-candidate-feedback-test.ss\"@206.21-206.56"
                                                    'irritants:
                                                    __tmp8545))
                                                 __obj8370)))
                                          (declare (not safe))
                                          (raise __tmp8544))
                                        '#!void)))))
                             (_%desc2626%_ _%desc2607%_)
                             (_%where2638%_ _%where2610%_)
                             (_%thunk2648%_ _%thunk2621%_))
                        (declare (not safe))
                        (std/test/base#__test-check!
                         _%desc2626%_
                         _%where2638%_
                         _%thunk2648%_)))))
            (let ((_%$e2045%_ _%fault2033%_))
              (if (or (eq? 'stale _%$e2045%_) (eq? 'referenceStale _%$e2045%_))
                  (let ((_%old2051%_
                         (let ((__tmp8546
                                (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-source
                                 '0)))
                           (declare (not safe))
                           (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                            __tmp8546
                            _%gold2037%_
                            '#f))))
                    (if (eq? _%fault2033%_ 'stale)
                        (_%assert-refused2043%_
                         (_%compare2042%_
                          _%gold2037%_
                          _%old2051%_
                          _%gold2037%_
                          _%reference2039%_)
                         'unbound)
                        (_%assert-refused2043%_
                         (_%compare2042%_
                          _%gold2037%_
                          _%reference2039%_
                          _%gold2037%_
                          _%old2051%_)
                         'reference-unbound)))
                  (if (or (eq? 'partial _%$e2045%_)
                          (eq? 'referencePartial _%$e2045%_))
                      (let* ((_%limited2056%_
                              (let ((__tmp8547
                                     (reverse (cdr (let ()
                                                     (declare (not safe))
                                                     (##reverse
                                                      _%gold2037%_))))))
                                (declare (not safe))
                                (##append __tmp8547 '((limits 16 1 1)))))
                             (_%unfinished2058%_
                              (let ()
                                (declare (not safe))
                                (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                                 _%source2035%_
                                 _%limited2056%_
                                 '#f))))
                        (let* ((_%desc2061%_
                                '(eq? (reasoning-receipt-status unfinished)
                                      'complete))
                               (_%where2064%_
                                '"\"t/qualification/ascent-candidate-feedback-test.ss\"@217.24-217.77")
                               (_%thunk2075%_
                                (lambda ()
                                  (let* ((_%expected2068%_ '#f)
                                         (_%result2071%_
                                          (eq? (let ()
                                                 (declare (not safe))
                                                 (##unchecked-structure-ref
                                                  _%unfinished2058%_
                                                  '1
                                                  '#f
                                                  '#f))
                                               'complete)))
                                    (if (let ()
                                          (declare (not safe))
                                          (std/test/unit#equal-values?
                                           _%expected2068%_
                                           _%result2071%_))
                                        '#!void
                                        (begin
                                          (let ((__tmp8548
                                                 (let ((__obj8377
                                                        (let ()
                                                          (declare (not safe))
                                                          (##structure
                                                           std/test/base#TestError::t
                                                           '#f
                                                           '#f
                                                           '#f
                                                           '#f))))
                                                   (let ((__tmp8549
                                                          (cons '(eq? (reasoning-receipt-status
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               unfinished)
                              'complete)
                        (cons 'test:
                              (cons '(eq? (reasoning-receipt-status unfinished)
                                          'complete)
                                    (cons 'result:
                                          (cons _%result2071%_
                                                (cons 'expectation:
                                                      (cons _%expected2068%_
                                                            '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (declare (not safe))
                                                     (std/test/base#TestError:::init!
                                                      __obj8377
                                                      '"result does not match expectation"
                                                      'where:
                                                      '"\"t/qualification/ascent-candidate-feedback-test.ss\"@217.24-217.77"
                                                      'irritants:
                                                      __tmp8549))
                                                   __obj8377)))
                                            (declare (not safe))
                                            (raise __tmp8548))
                                          '#!void)))))
                               (_%desc2080%_ _%desc2061%_)
                               (_%where2102%_ _%where2064%_)
                               (_%thunk2112%_ _%thunk2075%_))
                          (declare (not safe))
                          (std/test/base#__test-check!
                           _%desc2080%_
                           _%where2102%_
                           _%thunk2112%_))
                        (if (eq? _%fault2033%_ 'partial)
                            (_%assert-refused2043%_
                             (_%compare2042%_
                              _%limited2056%_
                              _%unfinished2058%_
                              _%gold2037%_
                              _%reference2039%_)
                             (let ()
                               (declare (not safe))
                               (##unchecked-structure-ref
                                _%unfinished2058%_
                                '1
                                '#f
                                '#f)))
                            (_%assert-refused2043%_
                             (_%compare2042%_
                              _%gold2037%_
                              _%reference2039%_
                              _%limited2056%_
                              _%unfinished2058%_)
                             'reference-incomplete)))
                      (if (eq? 'query _%$e2045%_)
                          (let* ((_%p2122%_
                                  (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal__%
                                   'gold
                                   '(query answer 0)))
                                 (_%r2124%_
                                  (let ()
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                                     _%source2035%_
                                     _%p2122%_
                                     '#f))))
                            (let* ((_%desc2127%_ '(reasoning-receipt-status r))
                                   (_%where2130%_
                                    '"\"t/qualification/ascent-candidate-feedback-test.ss\"@225.24-225.52")
                                   (_%thunk2141%_
                                    (lambda ()
                                      (let* ((_%expected2134%_ 'complete)
                                             (_%result2137%_
                                              (let ()
                                                (declare (not safe))
                                                (##unchecked-structure-ref
                                                 _%r2124%_
                                                 '1
                                                 '#f
                                                 '#f))))
                                        (if (let ()
                                              (declare (not safe))
                                              (std/test/unit#equal-values?
                                               _%expected2134%_
                                               _%result2137%_))
                                            '#!void
                                            (begin
                                              (let ((__tmp8550
                                                     (let ((__obj8376
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (##structure
                                                               std/test/base#TestError::t
                                                               '#f
                                                               '#f
                                                               '#f
                                                               '#f))))
                                                       (let ((__tmp8551
                                                              (cons '(reasoning-receipt-status
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              r)
                            (cons 'test:
                                  (cons '(reasoning-receipt-status r)
                                        (cons 'result:
                                              (cons _%result2137%_
                                                    (cons 'expectation:
                                                          (cons _%expected2134%_
                                                                '())))))))))
                 (declare (not safe))
                 (std/test/base#TestError:::init!
                  __obj8376
                  '"result does not match expectation"
                  'where:
                  '"\"t/qualification/ascent-candidate-feedback-test.ss\"@225.24-225.52"
                  'irritants:
                  __tmp8551))
               __obj8376)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (declare (not safe))
                                                (raise __tmp8550))
                                              '#!void)))))
                                   (_%desc2146%_ _%desc2127%_)
                                   (_%where2161%_ _%where2130%_)
                                   (_%thunk2171%_ _%thunk2141%_))
                              (declare (not safe))
                              (std/test/base#__test-check!
                               _%desc2146%_
                               _%where2161%_
                               _%thunk2171%_))
                            (_%assert-refused2043%_
                             (_%compare2042%_
                              _%p2122%_
                              _%r2124%_
                              _%gold2037%_
                              _%reference2039%_)
                             'query-mismatch))
                          (if (or (eq? 'missing _%$e2045%_)
                                  (eq? 'extra _%$e2045%_))
                              (let* ((_%p2184%_
                                      (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#scoped-proposal__0
                                       (if (eq? _%fault2033%_ 'missing)
                                           'global
                                           'positive)))
                                     (_%r2186%_
                                      (let ()
                                        (declare (not safe))
                                        (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                                         _%source2035%_
                                         _%p2184%_
                                         '#f)))
                                     (_%f2188%_
                                      (_%compare2042%_
                                       _%p2184%_
                                       _%r2186%_
                                       _%gold2037%_
                                       _%reference2039%_)))
                                (let* ((_%desc2191%_
                                        '(reasoning-receipt-status r))
                                       (_%where2194%_
                                        '"\"t/qualification/ascent-candidate-feedback-test.ss\"@231.24-231.52")
                                       (_%thunk2205%_
                                        (lambda ()
                                          (let* ((_%expected2198%_ 'complete)
                                                 (_%result2201%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (##unchecked-structure-ref
                                                     _%r2186%_
                                                     '1
                                                     '#f
                                                     '#f))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (std/test/unit#equal-values?
                                                   _%expected2198%_
                                                   _%result2201%_))
                                                '#!void
                                                (begin
                                                  (let ((__tmp8552
                                                         (let ((__obj8371
                                                                (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##structure
                           std/test/base#TestError::t
                           '#f
                           '#f
                           '#f
                           '#f))))
                   (let ((__tmp8553
                          (cons '(reasoning-receipt-status r)
                                (cons 'test:
                                      (cons '(reasoning-receipt-status r)
                                            (cons 'result:
                                                  (cons _%result2201%_
                                                        (cons 'expectation:
                                                              (cons _%expected2198%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                     (declare (not safe))
                     (std/test/base#TestError:::init!
                      __obj8371
                      '"result does not match expectation"
                      'where:
                      '"\"t/qualification/ascent-candidate-feedback-test.ss\"@231.24-231.52"
                      'irritants:
                      __tmp8553))
                   __obj8371)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (declare (not safe))
                                                    (raise __tmp8552))
                                                  '#!void)))))
                                       (_%desc2210%_ _%desc2191%_)
                                       (_%where2226%_ _%where2194%_)
                                       (_%thunk2236%_ _%thunk2205%_))
                                  (declare (not safe))
                                  (std/test/base#__test-check!
                                   _%desc2210%_
                                   _%where2226%_
                                   _%thunk2236%_))
                                (let* ((_%desc2246%_
                                        '(reasoning-feedback-status f))
                                       (_%where2249%_
                                        '"\"t/qualification/ascent-candidate-feedback-test.ss\"@232.24-232.53")
                                       (_%thunk2260%_
                                        (lambda ()
                                          (let* ((_%expected2253%_ 'mismatch)
                                                 (_%result2256%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (##unchecked-structure-ref
                                                     _%f2188%_
                                                     '1
                                                     '#f
                                                     '#f))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (std/test/unit#equal-values?
                                                   _%expected2253%_
                                                   _%result2256%_))
                                                '#!void
                                                (begin
                                                  (let ((__tmp8554
                                                         (let ((__obj8372
                                                                (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##structure
                           std/test/base#TestError::t
                           '#f
                           '#f
                           '#f
                           '#f))))
                   (let ((__tmp8555
                          (cons '(reasoning-feedback-status f)
                                (cons 'test:
                                      (cons '(reasoning-feedback-status f)
                                            (cons 'result:
                                                  (cons _%result2256%_
                                                        (cons 'expectation:
                                                              (cons _%expected2253%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                     (declare (not safe))
                     (std/test/base#TestError:::init!
                      __obj8372
                      '"result does not match expectation"
                      'where:
                      '"\"t/qualification/ascent-candidate-feedback-test.ss\"@232.24-232.53"
                      'irritants:
                      __tmp8555))
                   __obj8372)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (declare (not safe))
                                                    (raise __tmp8554))
                                                  '#!void)))))
                                       (_%desc2265%_ _%desc2246%_)
                                       (_%where2277%_ _%where2249%_)
                                       (_%thunk2287%_ _%thunk2260%_))
                                  (declare (not safe))
                                  (std/test/base#__test-check!
                                   _%desc2265%_
                                   _%where2277%_
                                   _%thunk2287%_))
                                (let* ((_%desc2297%_
                                        '(reasoning-feedback-reason f))
                                       (_%where2300%_
                                        '"\"t/qualification/ascent-candidate-feedback-test.ss\"@233.24-233.53")
                                       (_%thunk2311%_
                                        (lambda ()
                                          (let* ((_%expected2304%_ '#f)
                                                 (_%result2307%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (##unchecked-structure-ref
                                                     _%f2188%_
                                                     '2
                                                     '#f
                                                     '#f))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (std/test/unit#equal-values?
                                                   _%expected2304%_
                                                   _%result2307%_))
                                                '#!void
                                                (begin
                                                  (let ((__tmp8556
                                                         (let ((__obj8373
                                                                (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##structure
                           std/test/base#TestError::t
                           '#f
                           '#f
                           '#f
                           '#f))))
                   (let ((__tmp8557
                          (cons '(reasoning-feedback-reason f)
                                (cons 'test:
                                      (cons '(reasoning-feedback-reason f)
                                            (cons 'result:
                                                  (cons _%result2307%_
                                                        (cons 'expectation:
                                                              (cons _%expected2304%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                     (declare (not safe))
                     (std/test/base#TestError:::init!
                      __obj8373
                      '"result does not match expectation"
                      'where:
                      '"\"t/qualification/ascent-candidate-feedback-test.ss\"@233.24-233.53"
                      'irritants:
                      __tmp8557))
                   __obj8373)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (declare (not safe))
                                                    (raise __tmp8556))
                                                  '#!void)))))
                                       (_%desc2316%_ _%desc2297%_)
                                       (_%where2328%_ _%where2300%_)
                                       (_%thunk2338%_ _%thunk2311%_))
                                  (declare (not safe))
                                  (std/test/base#__test-check!
                                   _%desc2316%_
                                   _%where2328%_
                                   _%thunk2338%_))
                                (let* ((_%desc2348%_
                                        '(reasoning-feedback-missing f))
                                       (_%where2351%_
                                        '"\"t/qualification/ascent-candidate-feedback-test.ss\"@234.24-234.54")
                                       (_%thunk2362%_
                                        (lambda ()
                                          (let* ((_%expected2355%_
                                                  (if (eq? _%fault2033%_
                                                           'missing)
                                                      '((0))
                                                      '()))
                                                 (_%result2358%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (##unchecked-structure-ref
                                                     _%f2188%_
                                                     '3
                                                     '#f
                                                     '#f))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (std/test/unit#equal-values?
                                                   _%expected2355%_
                                                   _%result2358%_))
                                                '#!void
                                                (begin
                                                  (let ((__tmp8558
                                                         (let ((__obj8374
                                                                (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##structure
                           std/test/base#TestError::t
                           '#f
                           '#f
                           '#f
                           '#f))))
                   (let ((__tmp8559
                          (cons '(reasoning-feedback-missing f)
                                (cons 'test:
                                      (cons '(reasoning-feedback-missing f)
                                            (cons 'result:
                                                  (cons _%result2358%_
                                                        (cons 'expectation:
                                                              (cons _%expected2355%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                     (declare (not safe))
                     (std/test/base#TestError:::init!
                      __obj8374
                      '"result does not match expectation"
                      'where:
                      '"\"t/qualification/ascent-candidate-feedback-test.ss\"@234.24-234.54"
                      'irritants:
                      __tmp8559))
                   __obj8374)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (declare (not safe))
                                                    (raise __tmp8558))
                                                  '#!void)))))
                                       (_%desc2367%_ _%desc2348%_)
                                       (_%where2379%_ _%where2351%_)
                                       (_%thunk2389%_ _%thunk2362%_))
                                  (declare (not safe))
                                  (std/test/base#__test-check!
                                   _%desc2367%_
                                   _%where2379%_
                                   _%thunk2389%_))
                                (let* ((_%desc2399%_
                                        '(reasoning-feedback-extra f))
                                       (_%where2402%_
                                        '"\"t/qualification/ascent-candidate-feedback-test.ss\"@235.24-235.52")
                                       (_%thunk2413%_
                                        (lambda ()
                                          (let* ((_%expected2406%_
                                                  (if (eq? _%fault2033%_
                                                           'extra)
                                                      '((2))
                                                      '()))
                                                 (_%result2409%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (##unchecked-structure-ref
                                                     _%f2188%_
                                                     '4
                                                     '#f
                                                     '#f))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (std/test/unit#equal-values?
                                                   _%expected2406%_
                                                   _%result2409%_))
                                                '#!void
                                                (begin
                                                  (let ((__tmp8560
                                                         (let ((__obj8375
                                                                (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##structure
                           std/test/base#TestError::t
                           '#f
                           '#f
                           '#f
                           '#f))))
                   (let ((__tmp8561
                          (cons '(reasoning-feedback-extra f)
                                (cons 'test:
                                      (cons '(reasoning-feedback-extra f)
                                            (cons 'result:
                                                  (cons _%result2409%_
                                                        (cons 'expectation:
                                                              (cons _%expected2406%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            '())))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                     (declare (not safe))
                     (std/test/base#TestError:::init!
                      __obj8375
                      '"result does not match expectation"
                      'where:
                      '"\"t/qualification/ascent-candidate-feedback-test.ss\"@235.24-235.52"
                      'irritants:
                      __tmp8561))
                   __obj8375)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (declare (not safe))
                                                    (raise __tmp8560))
                                                  '#!void)))))
                                       (_%desc2418%_ _%desc2399%_)
                                       (_%where2430%_ _%where2402%_)
                                       (_%thunk2440%_ _%thunk2413%_))
                                  (declare (not safe))
                                  (std/test/base#__test-check!
                                   _%desc2418%_
                                   _%where2430%_
                                   _%thunk2440%_)))
                              '#!void)))))))))
    (define gerbil-ascent/t/qualification/ascent-candidate-feedback-test#ascent-feedback-correspondence-test
      (let ((__obj8385
             (let ()
               (declare (not safe))
               (##structure std/test/base#TestSuite::t '#f '#f '#f '#f '#f))))
        (let ((__tmp8562
               (lambda ()
                 (let* ((_%tc1920%_
                         (let ((__obj8378
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8563
                                  (lambda ()
                                    (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#check-feedback-correspondence
                                     'stale))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj8378
                              '"ExecutionFeedback/stale"
                              __tmp8563))
                           __obj8378))
                        (_%tc1925%_ _%tc1920%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc1925%_))
                 (let* ((_%tc1938%_
                         (let ((__obj8379
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8564
                                  (lambda ()
                                    (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#check-feedback-correspondence
                                     'partial))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj8379
                              '"ExecutionFeedback/partial"
                              __tmp8564))
                           __obj8379))
                        (_%tc1943%_ _%tc1938%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc1943%_))
                 (let* ((_%tc1954%_
                         (let ((__obj8380
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8565
                                  (lambda ()
                                    (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#check-feedback-correspondence
                                     'missing))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj8380
                              '"ExecutionFeedback/missing"
                              __tmp8565))
                           __obj8380))
                        (_%tc1959%_ _%tc1954%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc1959%_))
                 (let* ((_%tc1970%_
                         (let ((__obj8381
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8566
                                  (lambda ()
                                    (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#check-feedback-correspondence
                                     'extra))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj8381
                              '"ExecutionFeedback/extra"
                              __tmp8566))
                           __obj8381))
                        (_%tc1975%_ _%tc1970%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc1975%_))
                 (let* ((_%tc1986%_
                         (let ((__obj8382
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8567
                                  (lambda ()
                                    (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#check-feedback-correspondence
                                     'referenceStale))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj8382
                              '"ExecutionFeedback/referenceStale"
                              __tmp8567))
                           __obj8382))
                        (_%tc1991%_ _%tc1986%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc1991%_))
                 (let* ((_%tc2002%_
                         (let ((__obj8383
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8568
                                  (lambda ()
                                    (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#check-feedback-correspondence
                                     'referencePartial))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj8383
                              '"ExecutionFeedback/referencePartial"
                              __tmp8568))
                           __obj8383))
                        (_%tc2007%_ _%tc2002%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc2007%_))
                 (let* ((_%tc2018%_
                         (let ((__obj8384
                                (let ()
                                  (declare (not safe))
                                  (##structure
                                   std/test/base#TestCase::t
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f
                                   '#f))))
                           (let ((__tmp8569
                                  (lambda ()
                                    (gerbil-ascent/t/qualification/ascent-candidate-feedback-test#check-feedback-correspondence
                                     'query))))
                             (declare (not safe))
                             (std/test/base#TestCase:::init!
                              __obj8384
                              '"ExecutionFeedback/query"
                              __tmp8569))
                           __obj8384))
                        (_%tc2023%_ _%tc2018%_))
                   (declare (not safe))
                   (std/test/base#__test-case-add! _%tc2023%_)))))
          (declare (not safe))
          (std/test/base#TestSuite:::init!
           __obj8385
           '"ExecutionFeedback Scheme and Quint fault correspondence"
           __tmp8562))
        __obj8385))))
