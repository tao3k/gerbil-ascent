(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/trrel[1]#_g35300_|
    (##structure
     gx#syntax-quote::t
     'trrel-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g35302_|
    (##structure
     gx#syntax-quote::t
     'make-trrel-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g35304_|
    (##structure
     gx#syntax-quote::t
     'trrel-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g35306_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-known
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g35307_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g35308_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-successors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g35310_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-known-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g35311_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g35312_|
    (##structure
     gx#syntax-quote::t
     'trrel-state-successors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g35314_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-known
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g35315_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g35316_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-successors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g35318_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-known-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g35319_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[1]#_g35320_|
    (##structure
     gx#syntax-quote::t
     '&trrel-state-successors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/trrel[:0:]#trrel-state|
    (let ((__obj35172
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj35172
         'gerbil-ascent/table/trrel#trrel-state::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35172 'trrel-state '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj35172
         '(known predecessors successors)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj35172
         '(known predecessors successors)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35172 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35172 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35172 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35172 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35172 '#f '13 '#f '#f))
      (let ((__tmp35299 |gerbil-ascent/table/trrel[1]#_g35300_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35172 __tmp35299 '4 '#f '#f))
      (let ((__tmp35301 |gerbil-ascent/table/trrel[1]#_g35302_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35172 __tmp35301 '14 '#f '#f))
      (let ((__tmp35303 |gerbil-ascent/table/trrel[1]#_g35304_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35172 __tmp35303 '15 '#f '#f))
      (let ((__tmp35305
             (cons (cons 'known |gerbil-ascent/table/trrel[1]#_g35306_|)
                   (cons (cons 'predecessors
                               |gerbil-ascent/table/trrel[1]#_g35307_|)
                         (cons (cons 'successors
                                     |gerbil-ascent/table/trrel[1]#_g35308_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35172 __tmp35305 '16 '#f '#f))
      (let ((__tmp35309
             (cons (cons 'known |gerbil-ascent/table/trrel[1]#_g35310_|)
                   (cons (cons 'predecessors
                               |gerbil-ascent/table/trrel[1]#_g35311_|)
                         (cons (cons 'successors
                                     |gerbil-ascent/table/trrel[1]#_g35312_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35172 __tmp35309 '17 '#f '#f))
      (let ((__tmp35313
             (cons (cons 'known |gerbil-ascent/table/trrel[1]#_g35314_|)
                   (cons (cons 'predecessors
                               |gerbil-ascent/table/trrel[1]#_g35315_|)
                         (cons (cons 'successors
                                     |gerbil-ascent/table/trrel[1]#_g35316_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35172 __tmp35313 '18 '#f '#f))
      (let ((__tmp35317
             (cons (cons 'known |gerbil-ascent/table/trrel[1]#_g35318_|)
                   (cons (cons 'predecessors
                               |gerbil-ascent/table/trrel[1]#_g35319_|)
                         (cons (cons 'successors
                                     |gerbil-ascent/table/trrel[1]#_g35320_|)
                               '())))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35172 __tmp35317 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35172 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35172 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35172 '() '21 '#f '#f))
      __obj35172)))
