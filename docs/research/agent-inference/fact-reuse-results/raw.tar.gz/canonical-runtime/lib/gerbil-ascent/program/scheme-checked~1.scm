(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(define |gerbil-ascent/program/scheme-checked[:0:]#checked-call|
  (lambda (_%$stx11286%_)
    (let* ((_%$%g1129011317%_
            (lambda (_%$%g1129111313%_)
              (let ()
                (declare (not safe))
                (gx#raise-syntax-error
                 '#f
                 '"Bad syntax; invalid match target"
                 _%$%g1129111313%_))))
           (_%$%g1128911413%_
            (lambda (_%$%g1129111321%_)
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%$%g1129111321%_))
                  (let ((_%$%e1129411324%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%$%g1129111321%_))))
                    (let ((_%$%hd1129511328%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1129411324%_)))
                          (_%$%tl1129611331%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1129411324%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl1129611331%_))
                          (let ((_%$%e1129711334%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl1129611331%_))))
                            (let ((_%$%hd1129811338%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e1129711334%_)))
                                  (_%$%tl1129911341%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e1129711334%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair/null? _%$%hd1129811338%_))
                                  (let ((_g36838_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-split-splice
                                            _%$%hd1129811338%_
                                            '0))))
                                    (begin
                                      (let ((_g36839_
                                             (let ()
                                               (declare (not safe))
                                               (if (##values? _g36838_)
                                                   (##values-length _g36838_)
                                                   1))))
                                        (if (not (let ()
                                                   (declare (not safe))
                                                   (##fx= _g36839_ 2)))
                                            (error "Context expects 2 values"
                                                   _g36839_)))
                                      (let ((_%$%target1130011344%_
                                             (let ()
                                               (declare (not safe))
                                               (##values-ref _g36838_ 0)))
                                            (_%$%tl1130211347%_
                                             (let ()
                                               (declare (not safe))
                                               (##values-ref _g36838_ 1))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-null?
                                               _%$%tl1130211347%_))
                                            (letrec ((_%$%loop1130311350%_
                                                      (lambda (_%$%hd1130111354%_
                                                               _%$%parameter1130711357%_)
                                                        (if (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#stx-pair?
                                                               _%$%hd1130111354%_))
                                                            (let ((_%$%e1130411359%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%$%hd1130111354%_))))
                      (let ((_%$%lp-hd1130511363%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e1130411359%_)))
                            (_%$%lp-tl1130611366%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e1130411359%_))))
                        (_%$%loop1130311350%_
                         _%$%lp-tl1130611366%_
                         (cons _%$%lp-hd1130511363%_
                               _%$%parameter1130711357%_))))
                    (let ((_%$%parameter1130811369%_
                           (reverse _%$%parameter1130711357%_)))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl1129911341%_))
                          (let ((_%$%e1130911372%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl1129911341%_))))
                            (let ((_%$%hd1131011376%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e1130911372%_)))
                                  (_%$%tl1131111379%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e1130911372%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1131111379%_))
                                  (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'lambda))
                                        (cons (let ()
                                                (declare (not safe))
                                                (gx#datum->syntax__0
                                                 '#f
                                                 'values))
                                              (cons (cons (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#datum->syntax__0
                                                             '#f
                                                             'match))
                                                          (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'values))
                        (cons (cons (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0 '#f '@list))
                                          (let ((__tmp36840
                                                 (lambda (_%$%g1140411407%_
                                                          _%$%g1140511410%_)
                                                   (cons _%$%g1140411407%_
                                                         _%$%g1140511410%_))))
                                            (declare (not safe))
                                            (foldr__0
                                             __tmp36840
                                             '()
                                             _%$%parameter1130811369%_)))
                                    (cons _%$%hd1131011376%_ '()))
                              (cons (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0 '#f '_))
                                          (cons (cons (let ()
                                                        (declare (not safe))
                                                        (gx#datum->syntax__0
                                                         '#f
                                                         'error))
                                                      (cons '"relational operator argument mismatch"
                                                            '()))
                                                '()))
                                    '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '())))
                                  (_%$%g1129011317%_ _%$%g1129111321%_))))
                          (_%$%g1129011317%_ _%$%g1129111321%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%$%loop1130311350%_
                                               _%$%target1130011344%_
                                               '()))
                                            (_%$%g1129011317%_
                                             _%$%g1129111321%_)))))
                                  (_%$%g1129011317%_ _%$%g1129111321%_))))
                          (_%$%g1129011317%_ _%$%g1129111321%_))))
                  (_%$%g1129011317%_ _%$%g1129111321%_)))))
      (_%$%g1128911413%_ _%$stx11286%_))))
