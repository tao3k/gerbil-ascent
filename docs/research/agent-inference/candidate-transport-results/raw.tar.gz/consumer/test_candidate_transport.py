# SPDX-FileCopyrightText: 2026 tao3k team and Contributors
# SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
"""Deadline and framing regressions for the existing model consumer IO."""
import importlib.util
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('candidate_model', Path(__file__).with_name('candidate-model.py'))
model = importlib.util.module_from_spec(spec)
spec.loader.exec_module(model)


class TransportTest(unittest.TestCase):
    def consumer(self, script):
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        consumer = model.Consumer.__new__(model.Consumer)
        consumer.run = Path(folder.name)
        consumer.trace = []
        consumer.dynamic = False
        consumer.shutdown = None
        consumer._stdout_buffer = bytearray()
        consumer.err = (consumer.run/'native-stderr.log').open('a')
        consumer.p = subprocess.Popen([sys.executable, '-u', '-c', script],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=consumer.err, bufsize=0)
        self.addCleanup(consumer.close)
        return consumer

    def test_partial_line_obeys_deadline(self):
        c = self.consumer('import sys; sys.stdout.write("{\\\"ready\\\":"); sys.stdout.flush(); sys.stdin.read()')
        began = time.monotonic()
        with self.assertRaises(TimeoutError):
            c.receive(.25)
        self.assertLess(time.monotonic()-began, 1)
        self.assertEqual((c.run/'native-partial-output.bin').read_bytes(), b'{"ready":')
        self.assertTrue(c.close()['clean'])

    def test_multiple_frames_are_not_lost_in_buffer(self):
        c = self.consumer('import sys; sys.stdout.write("{\\\"first\\\":1}\\n{\\\"second\\\":2}\\n"); sys.stdout.flush(); sys.stdin.read()')
        self.assertEqual(c.receive(1), {'first':1})
        self.assertEqual(c.receive(.1), {'second':2})

    def test_split_frame(self):
        c = self.consumer('import sys,time; sys.stdout.write("{\\\"ready\\\":"); sys.stdout.flush(); time.sleep(.05); print("true}"); sys.stdin.read()')
        self.assertEqual(c.receive(1), {'ready':True})

    def test_eof_with_partial_frame_is_failure(self):
        c = self.consumer('print("{",end="",flush=True)')
        with self.assertRaisesRegex(RuntimeError, 'before complete response'):
            c.receive(1)
        self.assertEqual((c.run/'native-partial-output.bin').read_bytes(), b'{')

    def test_invalid_frame_is_preserved(self):
        c = self.consumer('print("not-json",flush=True)')
        with self.assertRaises(model.json.JSONDecodeError):
            c.receive(1)
        self.assertEqual((c.run/'native-invalid-output.log').read_bytes(), b'not-json\n')

    def test_silent_peer_times_out(self):
        c = self.consumer('import sys; sys.stdin.read()')
        with self.assertRaises(TimeoutError):
            c.receive(.1)

    def test_broken_stdin_is_recorded(self):
        c = self.consumer('pass')
        c.p.wait(timeout=1)
        with self.assertRaises(BrokenPipeError):
            c.call(op='ignored')
        self.assertIn('failure', model.json.loads((c.run/'native.json').read_text())[0])

    def test_readiness_failure_records_actual_deadline_and_cleans(self):
        with tempfile.TemporaryDirectory() as folder:
            run = Path(folder)
            real_popen = subprocess.Popen
            def launch(*args, **kwargs):
                return real_popen([sys.executable, '-u', '-c', 'import sys; sys.stdin.read()'], **kwargs)
            with patch.object(model.subprocess, 'Popen', side_effect=launch), \
                    patch.object(model.Consumer, 'receive', side_effect=TimeoutError('test readiness timeout')) as receive:
                with self.assertRaises(TimeoutError):
                    model.Consumer(run, dynamic=True)
                receive.assert_called_once_with(60)
            receipt = model.json.loads((run/'native-readiness-failure.json').read_text())
            self.assertEqual(receipt['deadline'], 60)
            self.assertEqual(receipt['pendingBytes'], 0)
            self.assertTrue(model.json.loads((run/'native-shutdown.json').read_text())['clean'])

    def test_spawn_failure_has_receipt(self):
        with tempfile.TemporaryDirectory() as folder:
            run = Path(folder)
            with patch.object(model.subprocess, 'Popen', side_effect=FileNotFoundError('missing executable')):
                with self.assertRaises(FileNotFoundError):
                    model.Consumer(run)
            self.assertEqual(model.json.loads((run/'native-readiness-failure.json').read_text())['phase'], 'spawn')


if __name__ == '__main__':
    unittest.main()
