(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/evidence-store::timestamp 1791693098)
  (begin
    (define gerbil-ascent/candidate/evidence-store#evidence-entry::t
      (let ((__tmp34490 (list))
            (__tmp34489
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'evidence-entry
         __tmp34490
         '(snapshot candidate receipt handle)
         __tmp34489
         '#f)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/evidence-store#evidence-entry::t)))
    (define gerbil-ascent/candidate/evidence-store#make-evidence-entry
      (lambda _%$args31047%_
        (apply make-instance
               gerbil-ascent/candidate/evidence-store#evidence-entry::t
               _%$args31047%_)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-snapshot
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'snapshot)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-candidate
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'candidate)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-receipt
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'receipt)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-handle
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'handle)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-snapshot-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'snapshot)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-candidate-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'candidate)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-receipt-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'receipt)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-handle-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'handle)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-snapshot
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'snapshot)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-candidate
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'candidate)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-receipt
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'receipt)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-handle
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'handle)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-snapshot-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'snapshot)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-candidate-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'candidate)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-receipt-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'receipt)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-handle-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'handle)))
    (define gerbil-ascent/candidate/evidence-store#evidence-operations?
      (lambda (_%owner31043%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%owner31043%_
               'clan/poo/object#object::t))
            (let ((__tmp34491
                   (lambda (_%slot31045%_)
                     (if (let ()
                           (declare (not safe))
                           (clan/poo/object#.slot?
                            _%owner31043%_
                            _%slot31045%_))
                         (procedure?
                          (let ()
                            (declare (not safe))
                            (clan/poo/object#.ref
                             _%owner31043%_
                             _%slot31045%_)))
                         '#f))))
              (declare (not safe))
              (andmap__0
               __tmp34491
               '(.resolve
                 .claim
                 .fact
                 .fragment
                 .certificate
                 .partition
                 .stats
                 .clear)))
            '#f)))
    (define gerbil-ascent/candidate/evidence-store#GerbilAscentEvidenceStoreContract
      (let ((__obj34486
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp34493
               (list (cons 'sexp
                           (let ((__tmp34494
                                  (lambda (_%@30992%_)
                                    'GerbilAscentEvidenceStoreContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34494)))
                     (cons 'identity
                           (let ((__tmp34495
                                  (lambda (_%@30998%_)
                                    'ascent/computational-evidence-store)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34495)))
                     (cons 'proto
                           (let ((__tmp34496
                                  (lambda (_%@31003%_)
                                    (let ((__obj34484
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp34498 (list))
                                            (__tmp34497 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp34498
                                         __tmp34497
                                         __obj34484))
                                      __obj34484))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34496)))
                     (cons 'responsibilities
                           (let ((__tmp34499
                                  (lambda (_%@31017%_)
                                    (let ((__obj34485
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp34501
                                             (list (cons '.operations
                                                         (let ((__tmp34502
                                                                (lambda (_%self31033%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (let ((__tmp34503
                                 (lambda (_%_v31040%_ _%_c31041%_) '())))
                            (declare (not safe))
                            (core/types#poo-flow-predicate-contract
                             'ascent/evidence-operations
                             gerbil-ascent/candidate/evidence-store#evidence-operations?
                             __tmp34503)))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp34502)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp34500 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp34501
                                         __tmp34500
                                         __obj34485))
                                      __obj34485))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp34499)))))
              (__tmp34492 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp34493
           __tmp34492
           __obj34486))
        __obj34486))
    (define gerbil-ascent/candidate/evidence-store#detached
      (lambda (_%value30974%_)
        (if (pair? _%value30974%_)
            (cons (gerbil-ascent/candidate/evidence-store#detached
                   (let () (declare (not safe)) (##car _%value30974%_)))
                  (gerbil-ascent/candidate/evidence-store#detached
                   (let () (declare (not safe)) (##cdr _%value30974%_))))
            (if (string? _%value30974%_)
                (let () (declare (not safe)) (##string-copy _%value30974%_))
                _%value30974%_))))
    (define gerbil-ascent/candidate/evidence-store#scope-key
      (lambda (_%snapshot30969%_ _%candidate30970%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
               _%snapshot30969%_))
            (let ((_%digest30972%_
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/reasoning#candidate-content-digest
                      _%candidate30970%_))))
              (if _%digest30972%_
                  (list (##structure-ref
                         _%snapshot30969%_
                         '1
                         gerbil-ascent/candidate/types#reasoning-snapshot::t
                         '#f)
                        (##structure-ref
                         _%snapshot30969%_
                         '2
                         gerbil-ascent/candidate/types#reasoning-snapshot::t
                         '#f)
                        (##structure-ref
                         _%snapshot30969%_
                         '3
                         gerbil-ascent/candidate/types#reasoning-snapshot::t
                         '#f)
                        _%digest30972%_)
                  '#f))
            '#f)))
    (define gerbil-ascent/candidate/evidence-store#scope-description
      (lambda (_%entry30964%_)
        (let ((_%snapshot30966%_
               (##direct-structure-ref
                _%entry30964%_
                '1
                gerbil-ascent/candidate/evidence-store#evidence-entry::t
                '#f))
              (_%receipt30967%_
               (##direct-structure-ref
                _%entry30964%_
                '3
                gerbil-ascent/candidate/evidence-store#evidence-entry::t
                '#f)))
          (list (list 'source-identity
                      (##structure-ref
                       _%snapshot30966%_
                       '1
                       gerbil-ascent/candidate/types#reasoning-snapshot::t
                       '#f))
                (list 'generation
                      (##structure-ref
                       _%snapshot30966%_
                       '2
                       gerbil-ascent/candidate/types#reasoning-snapshot::t
                       '#f))
                (list 'source-digest
                      (##structure-ref
                       _%snapshot30966%_
                       '3
                       gerbil-ascent/candidate/types#reasoning-snapshot::t
                       '#f))
                (list 'candidate-digest
                      (##structure-ref
                       _%receipt30967%_
                       '5
                       gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                       '#f))
                (list 'query
                      (##structure-ref
                       _%receipt30967%_
                       '6
                       gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                       '#f))))))
    (define gerbil-ascent/candidate/evidence-store#describe-entry
      (lambda (_%entry30961%_ _%reused?30962%_)
        (gerbil-ascent/candidate/evidence-store#detached
         (list (list 'status 'verified)
               (list 'finite-complete '#t)
               (list 'handle
                     (##direct-structure-ref
                      _%entry30961%_
                      '4
                      gerbil-ascent/candidate/evidence-store#evidence-entry::t
                      '#f))
               (list 'reused _%reused?30962%_)
               (list 'scope
                     (gerbil-ascent/candidate/evidence-store#scope-description
                      _%entry30961%_))
               (list 'rows
                     (##structure-ref
                      (##direct-structure-ref
                       _%entry30961%_
                       '3
                       gerbil-ascent/candidate/evidence-store#evidence-entry::t
                       '#f)
                      '7
                      gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                      '#f))))))
    (define gerbil-ascent/candidate/evidence-store#unknown
      (lambda (_%reason30959%_)
        (list (list 'status 'unknown) (list 'reason _%reason30959%_))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__%
      (lambda (_%max-entries30675%_ _%proof-steps30676%_ _%work-steps30677%_)
        (if (let ((__tmp34505
                   (lambda (_%v30679%_)
                     (and (exact-integer? _%v30679%_) (> _%v30679%_ '0))))
                  (__tmp34504
                   (list _%max-entries30675%_
                         _%proof-steps30676%_
                         _%work-steps30677%_)))
              (declare (not safe))
              (andmap__0 __tmp34505 __tmp34504))
            '#!void
            (let ()
              (declare (not safe))
              (error '"evidence store requires positive bounds")))
        (let ((_%entries30681%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value)))
              (_%handles30682%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value)))
              (_%order30683%_ '())
              (_%serial30684%_ '0)
              (_%builds30685%_ '0)
              (_%hits30686%_ '0)
              (_%attempts30687%_ '0)
              (_%evictions30688%_ '0)
              (_%gate30689%_ (make-mutex 'ascent-evidence-owner)))
          (letrec ((_%serialized30691%_
                    (lambda (_%call30932%_)
                      (if (eq? (mutex-state _%gate30689%_) (current-thread))
                          (let ()
                            (declare (not safe))
                            (error '"reentrant evidence owner call"))
                          '#!void)
                      (let ()
                        (declare (not safe))
                        (with-dynamic-lock _%gate30689%_ _%call30932%_))))
                   (_%bound-entry30692%_
                    (lambda (_%snapshot30926%_
                             _%candidate30927%_
                             _%handle30928%_)
                      (let ((_%entry30930%_
                             (if (exact-integer? _%handle30928%_)
                                 (let ()
                                   (declare (not safe))
                                   (__hash-get
                                    _%handles30682%_
                                    _%handle30928%_))
                                 '#f)))
                        (if _%entry30930%_
                            (if (let ((__tmp34506
                                       (##direct-structure-ref
                                        _%entry30930%_
                                        '3
                                        gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                        '#f)))
                                  (declare (not safe))
                                  (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                                   __tmp34506
                                   _%snapshot30926%_
                                   _%candidate30927%_))
                                _%entry30930%_
                                '#f)
                            '#f))))
                   (_%resolve30693%_
                    (lambda (_%snapshot30890%_ _%candidate30891%_)
                      (let* ((_%key30893%_
                              (gerbil-ascent/candidate/evidence-store#scope-key
                               _%snapshot30890%_
                               _%candidate30891%_))
                             (_%entry30895%_
                              (if _%key30893%_
                                  (let ()
                                    (declare (not safe))
                                    (__hash-get _%entries30681%_ _%key30893%_))
                                  '#f)))
                        (if _%key30893%_
                            (if (and _%entry30895%_
                                     (let ((__tmp34507
                                            (##direct-structure-ref
                                             _%entry30895%_
                                             '3
                                             gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                             '#f)))
                                       (declare (not safe))
                                       (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                                        __tmp34507
                                        _%snapshot30890%_
                                        _%candidate30891%_)))
                                (let ()
                                  (set! _%hits30686%_ (+ _%hits30686%_ '1))
                                  (gerbil-ascent/candidate/evidence-store#describe-entry
                                   _%entry30895%_
                                   '#t))
                                (let ()
                                  (set! _%attempts30687%_
                                        (+ _%attempts30687%_ '1))
                                  (let ((__tmp34547
                                         (lambda (_%$%g3090030902%_)
                                           (let ((_%e30906%_
                                                  _%$%g3090030902%_))
                                             (gerbil-ascent/candidate/evidence-store#unknown
                                              (let ()
                                                (declare (not safe))
                                                (std/error#exception->string
                                                 _%e30906%_))))))
                                        (__tmp34508
                                         (lambda ()
                                           (let* ((_%owned-source30910%_
                                                   (let ((__tmp34511
                                                          (gerbil-ascent/candidate/evidence-store#detached
                                                           (##structure-ref
                                                            _%snapshot30890%_
                                                            '1
                                                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                            '#f)))
                                                         (__tmp34510
                                                          (##structure-ref
                                                           _%snapshot30890%_
                                                           '2
                                                           gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                           '#f))
                                                         (__tmp34509
                                                          (##structure-ref
                                                           _%snapshot30890%_
                                                           '4
                                                           gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                           '#f)))
                                                     (declare (not safe))
                                                     (gerbil-ascent/candidate/reasoning#reasoning-source-snapshot
                                                      __tmp34511
                                                      __tmp34510
                                                      __tmp34509)))
                                                  (_%owned-candidate30912%_
                                                   (gerbil-ascent/candidate/evidence-store#detached
                                                    _%candidate30891%_))
                                                  (_%receipt30914%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gerbil-ascent/candidate/reasoning#reasoning-attempt__%
                                                      _%owned-source30910%_
                                                      _%owned-candidate30912%_
                                                      _%proof-steps30676%_
                                                      _%work-steps30677%_)))
                                                  (_%rows30916%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%receipt30914%_
                                                      '7
                                                      '#f
                                                      '#f))))
                                             (if (and (let ()
                                                        (declare (not safe))
                                                        (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                                                         _%receipt30914%_
                                                         _%snapshot30890%_
                                                         _%candidate30891%_))
                                                      (eq? (let ()
                                                             (declare
                                                               (not safe))
                                                             (##unchecked-structure-ref
                                                              _%receipt30914%_
                                                              '1
                                                              '#f
                                                              '#f))
                                                           'complete)
                                                      (let ((__tmp34538
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##unchecked-structure-ref
                        _%receipt30914%_
                        '10
                        '#f
                        '#f))))
                (declare (not safe))
                (##structure-instance-of?
                 __tmp34538
                 'gerbil-ascent/candidate/provenance#positive-proof::t))
              (or (null? _%rows30916%_)
                  (let ((__tmp34541
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/program#candidate-inspect
                            _%owned-source30910%_
                            _%owned-candidate30912%_)))
                        (__tmp34540
                         (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%receipt30914%_
                            '5
                            '#f
                            '#f)))
                        (__tmp34539
                         (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%receipt30914%_
                            '10
                            '#f
                            '#f))))
                    (declare (not safe))
                    (gerbil-ascent/candidate/provenance#candidate-verify-positive-proof
                     _%owned-source30910%_
                     __tmp34541
                     __tmp34540
                     'complete
                     _%rows30916%_
                     __tmp34539
                     _%proof-steps30676%_)))
              (eq? (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/reasoning#reasoning-verify-finite-receipt
                      _%receipt30914%_
                      _%owned-source30910%_
                      _%owned-candidate30912%_
                      _%work-steps30677%_))
                   'valid))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (begin
                                                   (if (>= (let ()
                                                             (declare
                                                               (not safe))
                                                             (__hash-length
                                                              _%entries30681%_))
                                                           _%max-entries30675%_)
                                                       (begin
                                                         (let ((_%old30922%_
                                                                (let ((__tmp34542
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               (car _%order30683%_)))
                          (declare (not safe))
                          (hash-ref__0 _%entries30681%_ __tmp34542))))
                   (let ((__tmp34543
                          (##direct-structure-ref
                           _%old30922%_
                           '4
                           gerbil-ascent/candidate/evidence-store#evidence-entry::t
                           '#f)))
                     (declare (not safe))
                     (__hash-remove! _%handles30682%_ __tmp34543))
                   (let ((__tmp34544 (car _%order30683%_)))
                     (declare (not safe))
                     (__hash-remove! _%entries30681%_ __tmp34544)))
                 (set! _%order30683%_ (cdr _%order30683%_))
                 (set! _%evictions30688%_ (+ _%evictions30688%_ '1)))
               '#!void)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (set! _%serial30684%_
                                                         (+ _%serial30684%_
                                                            '1))
                                                   (set! _%builds30685%_
                                                         (+ _%builds30685%_
                                                            '1))
                                                   (let ((_%admitted30924%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (##structure
                                                             gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                                             _%owned-source30910%_
                                                             _%owned-candidate30912%_
                                                             _%receipt30914%_
                                                             _%serial30684%_))))
                                                     (let ((__tmp34545
                                                            (gerbil-ascent/candidate/evidence-store#detached
                                                             _%key30893%_)))
                                                       (declare (not safe))
                                                       (__hash-put!
                                                        _%entries30681%_
                                                        __tmp34545
                                                        _%admitted30924%_))
                                                     (let ()
                                                       (declare (not safe))
                                                       (__hash-put!
                                                        _%handles30682%_
                                                        _%serial30684%_
                                                        _%admitted30924%_))
                                                     (set! _%order30683%_
                                                           (let ((__tmp34546
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (list (gerbil-ascent/candidate/evidence-store#detached
                                 _%key30893%_))))
                     (declare (not safe))
                     (##append _%order30683%_ __tmp34546)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (gerbil-ascent/candidate/evidence-store#describe-entry
                                                      _%admitted30924%_
                                                      '#f)))
                                                 (gerbil-ascent/candidate/evidence-store#unknown
                                                  'unverified-receipt))))))
                                    (declare (not safe))
                                    (__with-catch __tmp34547 __tmp34508))))
                            (gerbil-ascent/candidate/evidence-store#unknown
                             'invalid-scope)))))
                   (_%claim30694%_
                    (lambda (_%snapshot30878%_
                             _%candidate30879%_
                             _%handle30880%_
                             _%row30881%_)
                      (let ((_%entry30883%_
                             (_%bound-entry30692%_
                              _%snapshot30878%_
                              _%candidate30879%_
                              _%handle30880%_)))
                        (if _%entry30883%_
                            (if (and (let ()
                                       (declare (not safe))
                                       (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                                        _%row30881%_
                                        '16384
                                        '128))
                                     (list? _%row30881%_)
                                     (= (let ()
                                          (declare (not safe))
                                          (##length _%row30881%_))
                                        (length (cdr (##structure-ref
                                                      (##direct-structure-ref
                                                       _%entry30883%_
                                                       '3
                                                       gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                                       '#f)
                                                      '6
                                                      gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                                      '#f))))
                                     (let ()
                                       (declare (not safe))
                                       (andmap__0
                                        gerbil-ascent/candidate/program#scalar?
                                        _%row30881%_))
                                     (let ((__tmp34548
                                            (##structure-ref
                                             (##direct-structure-ref
                                              _%entry30883%_
                                              '3
                                              gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                              '#f)
                                             '6
                                             gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                             '#f)))
                                       (declare (not safe))
                                       (gerbil-ascent/candidate/funs#candidate-bind-atom
                                        __tmp34548
                                        _%row30881%_
                                        '())))
                                (let ((_%present30888%_
                                       (if (member _%row30881%_
                                                   (##structure-ref
                                                    (##direct-structure-ref
                                                     _%entry30883%_
                                                     '3
                                                     gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                                     '#f)
                                                    '7
                                                    gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                                    '#f))
                                           '#t
                                           '#f)))
                                  (gerbil-ascent/candidate/evidence-store#detached
                                   (list (list 'status
                                               (if _%present30888%_
                                                   'verified
                                                   'finite-absent))
                                         (list 'present _%present30888%_)
                                         (list 'row _%row30881%_)
                                         (list 'handle _%handle30880%_)
                                         (list 'scope
                                               (gerbil-ascent/candidate/evidence-store#scope-description
                                                _%entry30883%_)))))
                                (gerbil-ascent/candidate/evidence-store#unknown
                                 'invalid-query-row))
                            (gerbil-ascent/candidate/evidence-store#unknown
                             'stale-or-unknown-handle)))))
                   (_%certificate30695%_
                    (lambda (_%snapshot30865%_
                             _%candidate30866%_
                             _%handle30867%_)
                      (let ((_%entry30869%_
                             (_%bound-entry30692%_
                              _%snapshot30865%_
                              _%candidate30866%_
                              _%handle30867%_)))
                        (if _%entry30869%_
                            (let* ((_%receipt30871%_
                                    (##direct-structure-ref
                                     _%entry30869%_
                                     '3
                                     gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                     '#f))
                                   (_%proof30873%_
                                    (##structure-ref
                                     _%receipt30871%_
                                     '10
                                     gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                     '#f)))
                              (gerbil-ascent/candidate/evidence-store#detached
                               (list (list 'status 'verified)
                                     (list 'handle _%handle30867%_)
                                     (list 'scope
                                           (gerbil-ascent/candidate/evidence-store#scope-description
                                            _%entry30869%_))
                                     (list 'finite-closure
                                           (##structure-ref
                                            (##structure-ref
                                             (##structure-ref
                                              _%receipt30871%_
                                              '12
                                              gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                              '#f)
                                             '2
                                             gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                                             '#f)
                                            '9
                                            gerbil-ascent/candidate/finite-evidence#finite-evidence::t
                                            '#f))
                                     (list 'positive-proof-status
                                           (##structure-ref
                                            _%proof30873%_
                                            '1
                                            gerbil-ascent/candidate/provenance#positive-proof::t
                                            '#f))
                                     (list 'roots
                                           (##structure-ref
                                            _%proof30873%_
                                            '9
                                            gerbil-ascent/candidate/provenance#positive-proof::t
                                            '#f))
                                     (list 'nodes
                                           (map (lambda (_%n30876%_)
                                                  (list (##structure-ref
                                                         _%n30876%_
                                                         '1
                                                         gerbil-ascent/candidate/provenance#proof-node::t
                                                         '#f)
                                                        (##structure-ref
                                                         _%n30876%_
                                                         '2
                                                         gerbil-ascent/candidate/provenance#proof-node::t
                                                         '#f)
                                                        (##structure-ref
                                                         _%n30876%_
                                                         '3
                                                         gerbil-ascent/candidate/provenance#proof-node::t
                                                         '#f)
                                                        (##structure-ref
                                                         _%n30876%_
                                                         '4
                                                         gerbil-ascent/candidate/provenance#proof-node::t
                                                         '#f)
                                                        (##structure-ref
                                                         _%n30876%_
                                                         '5
                                                         gerbil-ascent/candidate/provenance#proof-node::t
                                                         '#f)
                                                        (##structure-ref
                                                         _%n30876%_
                                                         '6
                                                         gerbil-ascent/candidate/provenance#proof-node::t
                                                         '#f)))
                                                (##structure-ref
                                                 _%proof30873%_
                                                 '8
                                                 gerbil-ascent/candidate/provenance#positive-proof::t
                                                 '#f))))))
                            (gerbil-ascent/candidate/evidence-store#unknown
                             'stale-or-unknown-handle)))))
                   (_%fact30696%_
                    (lambda (_%snapshot30841%_
                             _%candidate30842%_
                             _%handle30843%_
                             _%atom30844%_)
                      (let ((_%entry30846%_
                             (_%bound-entry30692%_
                              _%snapshot30841%_
                              _%candidate30842%_
                              _%handle30843%_)))
                        (if _%entry30846%_
                            (if (and (let ()
                                       (declare (not safe))
                                       (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                                        _%atom30844%_
                                        '16384
                                        '128))
                                     (list? _%atom30844%_)
                                     (pair? _%atom30844%_)
                                     (symbol? (let ()
                                                (declare (not safe))
                                                (##car _%atom30844%_)))
                                     (let ((__tmp34549
                                            (let ()
                                              (declare (not safe))
                                              (##cdr _%atom30844%_))))
                                       (declare (not safe))
                                       (andmap__0
                                        gerbil-ascent/candidate/program#scalar?
                                        __tmp34549)))
                                (let* ((_%receipt30851%_
                                        (##direct-structure-ref
                                         _%entry30846%_
                                         '3
                                         gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                         '#f))
                                       (_%closure30853%_
                                        (##structure-ref
                                         (##structure-ref
                                          (##structure-ref
                                           _%receipt30851%_
                                           '12
                                           gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                           '#f)
                                          '2
                                          gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                                          '#f)
                                         '9
                                         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
                                         '#f))
                                       (_%relation30855%_
                                        (assq (car _%atom30844%_)
                                              _%closure30853%_)))
                                  (if (and _%relation30855%_
                                           (= (length (cdr _%atom30844%_))
                                              (cadr _%relation30855%_)))
                                      (let* ((_%present30858%_
                                              (if (member (cdr _%atom30844%_)
                                                          (caddr _%relation30855%_))
                                                  '#t
                                                  '#f))
                                             (_%support30862%_
                                              (filter (lambda (_%node30860%_)
                                                        (if (eq? (##structure-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          _%node30860%_
                          '3
                          gerbil-ascent/candidate/provenance#proof-node::t
                          '#f)
                         (car _%atom30844%_))
                    (equal? (##structure-ref
                             _%node30860%_
                             '4
                             gerbil-ascent/candidate/provenance#proof-node::t
                             '#f)
                            (cdr _%atom30844%_))
                    '#f))
              (##structure-ref
               (##structure-ref
                _%receipt30851%_
                '10
                gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                '#f)
               '8
               gerbil-ascent/candidate/provenance#positive-proof::t
               '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        (gerbil-ascent/candidate/evidence-store#detached
                                         (list (list 'status
                                                     (if _%present30858%_
                                                         'verified
                                                         'finite-absent))
                                               (list 'present _%present30858%_)
                                               (list 'atom _%atom30844%_)
                                               (list 'handle _%handle30843%_)
                                               (list 'basis
                                                     'verified-finite-closure)
                                               (list 'support-nodes
                                                     (let ()
                                                       (declare (not safe))
                                                       (##map gerbil-ascent/candidate/provenance#proof-node-id
                                                              _%support30862%_)))
                                               (list 'scope
                                                     (gerbil-ascent/candidate/evidence-store#scope-description
                                                      _%entry30846%_)))))
                                      (gerbil-ascent/candidate/evidence-store#unknown
                                       'unknown-relation-or-arity)))
                                (gerbil-ascent/candidate/evidence-store#unknown
                                 'invalid-atom))
                            (gerbil-ascent/candidate/evidence-store#unknown
                             'stale-or-unknown-handle)))))
                   (_%fragment30697%_
                    (lambda (_%snapshot30817%_
                             _%candidate30818%_
                             _%handle30819%_
                             _%atom30820%_)
                      (let ((_%answer30822%_
                             (_%fact30696%_
                              _%snapshot30817%_
                              _%candidate30818%_
                              _%handle30819%_
                              _%atom30820%_)))
                        (if (eq? (cadr (assq 'status _%answer30822%_))
                                 'verified)
                            (let* ((_%proof30824%_
                                    (_%certificate30695%_
                                     _%snapshot30817%_
                                     _%candidate30818%_
                                     _%handle30819%_))
                                   (_%nodes30826%_
                                    (cadr (assq 'nodes _%proof30824%_)))
                                   (_%roots30828%_
                                    (cadr (assq 'support-nodes
                                                _%answer30822%_)))
                                   (_%seen30830%_ '())
                                   (_%selected30832%_ '()))
                              (letrec ((_%visit30835%_
                                        (lambda (_%id30837%_)
                                          (if (let ()
                                                (declare (not safe))
                                                (##member
                                                 _%id30837%_
                                                 _%seen30830%_))
                                              '#!void
                                              (let ((_%node30839%_
                                                     (assoc _%id30837%_
                                                            _%nodes30826%_)))
                                                (if _%node30839%_
                                                    '#!void
                                                    (let ()
                                                      (declare (not safe))
                                                      (error '"verified proof has missing support"
                                                             _%id30837%_)))
                                                (set! _%seen30830%_
                                                      (cons _%id30837%_
                                                            _%seen30830%_))
                                                (for-each
                                                 _%visit30835%_
                                                 (list-ref _%node30839%_ '5))
                                                (set! _%selected30832%_
                                                      (cons _%node30839%_
                                                            _%selected30832%_)))))))
                                (for-each _%visit30835%_ _%roots30828%_)
                                (gerbil-ascent/candidate/evidence-store#detached
                                 (list (list 'status 'verified)
                                       (list 'fact _%answer30822%_)
                                       (list 'roots _%roots30828%_)
                                       (list 'nodes
                                             (let ()
                                               (declare (not safe))
                                               (##reverse
                                                _%selected30832%_)))))))
                            _%answer30822%_)))))
            (let ((__tmp34550
                   (let ((__obj34488
                          (let ()
                            (declare (not safe))
                            (##structure
                             clan/poo/object#object::t
                             '#f
                             '#f
                             '#f
                             '#f
                             '#f
                             '#f
                             '#f))))
                     (let ((__tmp34564
                            (let ()
                              (declare (not safe))
                              (clan/poo/object#.ref
                               gerbil-ascent/candidate/evidence-store#GerbilAscentEvidenceStoreContract
                               'proto)))
                           (__tmp34552
                            (list (cons '.operations
                                        (let ((__tmp34553
                                               (lambda (_%@30712%_)
                                                 (let ((__obj34487
                                                        (let ()
                                                          (declare (not safe))
                                                          (##structure
                                                           clan/poo/object#object::t
                                                           '#f
                                                           '#f
                                                           '#f
                                                           '#f
                                                           '#f
                                                           '#f
                                                           '#f))))
                                                   (let ((__tmp34555
                                                          (list (cons '.resolve
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ((__tmp34556
                                     (lambda (_%self30736%_)
                                       (lambda (_%snapshot30743%_
                                                _%candidate30744%_)
                                         (_%serialized30691%_
                                          (lambda ()
                                            (_%resolve30693%_
                                             _%snapshot30743%_
                                             _%candidate30744%_)))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp34556)))
                        (cons '.claim
                              (let ((__tmp34557
                                     (lambda (_%self30747%_)
                                       (lambda (_%snapshot30752%_
                                                _%candidate30753%_
                                                _%handle30754%_
                                                _%row30755%_)
                                         (_%serialized30691%_
                                          (lambda ()
                                            (_%claim30694%_
                                             _%snapshot30752%_
                                             _%candidate30753%_
                                             _%handle30754%_
                                             _%row30755%_)))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp34557)))
                        (cons '.fact
                              (let ((__tmp34558
                                     (lambda (_%self30758%_)
                                       (lambda (_%snapshot30763%_
                                                _%candidate30764%_
                                                _%handle30765%_
                                                _%atom30766%_)
                                         (_%serialized30691%_
                                          (lambda ()
                                            (_%fact30696%_
                                             _%snapshot30763%_
                                             _%candidate30764%_
                                             _%handle30765%_
                                             _%atom30766%_)))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp34558)))
                        (cons '.fragment
                              (let ((__tmp34559
                                     (lambda (_%self30769%_)
                                       (lambda (_%snapshot30774%_
                                                _%candidate30775%_
                                                _%handle30776%_
                                                _%atom30777%_)
                                         (_%serialized30691%_
                                          (lambda ()
                                            (_%fragment30697%_
                                             _%snapshot30774%_
                                             _%candidate30775%_
                                             _%handle30776%_
                                             _%atom30777%_)))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp34559)))
                        (cons '.certificate
                              (let ((__tmp34560
                                     (lambda (_%self30780%_)
                                       (lambda (_%snapshot30785%_
                                                _%candidate30786%_
                                                _%handle30787%_)
                                         (_%serialized30691%_
                                          (lambda ()
                                            (_%certificate30695%_
                                             _%snapshot30785%_
                                             _%candidate30786%_
                                             _%handle30787%_)))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp34560)))
                        (cons '.partition
                              (let ((__tmp34561
                                     (lambda (_%self30790%_)
                                       (lambda (_%snapshot30795%_
                                                _%candidate30796%_
                                                _%handle30797%_
                                                _%alternatives30798%_)
                                         (_%serialized30691%_
                                          (lambda ()
                                            (gerbil-ascent/candidate/evidence-store#partition-obligations
                                             (lambda (_%atom30801%_)
                                               (_%fact30696%_
                                                _%snapshot30795%_
                                                _%candidate30796%_
                                                _%handle30797%_
                                                _%atom30801%_))
                                             _%alternatives30798%_)))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp34561)))
                        (cons '.stats
                              (let ((__tmp34562
                                     (lambda (_%self30803%_)
                                       (lambda ()
                                         (_%serialized30691%_
                                          (lambda ()
                                            (list (list 'entries
                                                        (let ()
                                                          (declare (not safe))
                                                          (__hash-length
                                                           _%entries30681%_)))
                                                  (list 'attempts
                                                        _%attempts30687%_)
                                                  (list 'proof-builds
                                                        _%builds30685%_)
                                                  (list 'hits _%hits30686%_)
                                                  (list 'evictions
                                                        _%evictions30688%_))))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp34562)))
                        (cons '.clear
                              (let ((__tmp34563
                                     (lambda (_%self30810%_)
                                       (lambda ()
                                         (_%serialized30691%_
                                          (lambda ()
                                            (set! _%entries30681%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (make-hash-table__%
                                                     '#f
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value)))
                                            (set! _%handles30682%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (make-hash-table__%
                                                     '#f
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value)))
                                            (set! _%order30683%_ '())
                                            '#t))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp34563)))))
                 (__tmp34554 (list)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (declare (not safe))
                                                     (clan/poo/object#object:::init!__%
                                                      '#f
                                                      '()
                                                      __tmp34555
                                                      __tmp34554
                                                      __obj34487))
                                                   __obj34487))))
                                          (declare (not safe))
                                          (##structure
                                           clan/poo/object#$self-slot-spec::t
                                           __tmp34553)))))
                           (__tmp34551 (list)))
                       (declare (not safe))
                       (clan/poo/object#object:::init!__%
                        '#f
                        __tmp34564
                        __tmp34552
                        __tmp34551
                        __obj34488))
                     __obj34488)))
              (declare (not safe))
              (clan/poo/mop#validate
               gerbil-ascent/candidate/evidence-store#GerbilAscentEvidenceStoreContract
               __tmp34550))))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__0
      (lambda ()
        (let* ((_%max-entries30938%_ '64)
               (_%proof-steps30940%_ '100000)
               (_%work-steps30942%_ '100000))
          (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__%
           _%max-entries30938%_
           _%proof-steps30940%_
           _%work-steps30942%_))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__1
      (lambda (_%max-entries30944%_)
        (let* ((_%proof-steps30946%_ '100000) (_%work-steps30948%_ '100000))
          (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__%
           _%max-entries30944%_
           _%proof-steps30946%_
           _%work-steps30948%_))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__2
      (lambda (_%max-entries30950%_ _%proof-steps30951%_)
        (let ((_%work-steps30953%_ '100000))
          (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__%
           _%max-entries30950%_
           _%proof-steps30951%_
           _%work-steps30953%_))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store
      (lambda _g34565_
        (let ((_g34566_ (let () (declare (not safe)) (##length _g34565_))))
          (cond ((let () (declare (not safe)) (##fx= _g34566_ 0))
                 (apply gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__0
                        _g34565_))
                ((let () (declare (not safe)) (##fx= _g34566_ 1))
                 (apply gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__1
                        _g34565_))
                ((let () (declare (not safe)) (##fx= _g34566_ 2))
                 (apply gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__2
                        _g34565_))
                ((let () (declare (not safe)) (##fx= _g34566_ 3))
                 (apply gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__%
                        _g34565_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store
                  _g34565_))))))
    (define gerbil-ascent/candidate/evidence-store#operation
      (lambda (_%store30671%_ _%name30672%_)
        (let ((__tmp34567
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%store30671%_ '.operations))))
          (declare (not safe))
          (clan/poo/object#.ref __tmp34567 _%name30672%_))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
      (lambda (_%store30667%_ _%snapshot30668%_ _%candidate30669%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30667%_
          '.resolve)
         _%snapshot30668%_
         _%candidate30669%_)))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-claim
      (lambda (_%store30661%_
               _%snapshot30662%_
               _%candidate30663%_
               _%handle30664%_
               _%row30665%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30661%_
          '.claim)
         _%snapshot30662%_
         _%candidate30663%_
         _%handle30664%_
         _%row30665%_)))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-fact
      (lambda (_%store30655%_
               _%snapshot30656%_
               _%candidate30657%_
               _%handle30658%_
               _%atom30659%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30655%_
          '.fact)
         _%snapshot30656%_
         _%candidate30657%_
         _%handle30658%_
         _%atom30659%_)))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-fragment
      (lambda (_%store30649%_
               _%snapshot30650%_
               _%candidate30651%_
               _%handle30652%_
               _%atom30653%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30649%_
          '.fragment)
         _%snapshot30650%_
         _%candidate30651%_
         _%handle30652%_
         _%atom30653%_)))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-certificate
      (lambda (_%store30644%_
               _%snapshot30645%_
               _%candidate30646%_
               _%handle30647%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30644%_
          '.certificate)
         _%snapshot30645%_
         _%candidate30646%_
         _%handle30647%_)))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-stats
      (lambda (_%store30642%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30642%_
          '.stats))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-clear!
      (lambda (_%store30640%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30640%_
          '.clear))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-partition
      (lambda (_%store30634%_
               _%snapshot30635%_
               _%candidate30636%_
               _%handle30637%_
               _%alternatives30638%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30634%_
          '.partition)
         _%snapshot30635%_
         _%candidate30636%_
         _%handle30637%_
         _%alternatives30638%_)))
    (define gerbil-ascent/candidate/evidence-store#partition-obligations
      (lambda (_%fact30608%_ _%alternatives30609%_)
        (if (and (let ()
                   (declare (not safe))
                   (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                    _%alternatives30609%_
                    '16384
                    '128))
                 (list? _%alternatives30609%_)
                 (let ((__tmp34568
                        (lambda (_%a30611%_)
                          (and (list? _%a30611%_)
                               (= (let ()
                                    (declare (not safe))
                                    (##length _%a30611%_))
                                  '2)
                               (let ((__tmp34569 (car _%a30611%_)))
                                 (declare (not safe))
                                 (gerbil-ascent/candidate/program#scalar?
                                  __tmp34569))
                               (list? (cadr _%a30611%_))))))
                   (declare (not safe))
                   (andmap__0 __tmp34568 _%alternatives30609%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid branch obligations")))
        (let ((_%seen30613%_ '())
              (_%eligible30614%_ '())
              (_%pruned30615%_ '())
              (_%unresolved30616%_ '())
              (_%allowed30617%_ '())
              (_%claims30618%_ '()))
          (for-each
           (lambda (_%alternative30620%_)
             (let* ((_%id30622%_ (car _%alternative30620%_))
                    (_%answers30624%_
                     (map _%fact30608%_ (cadr _%alternative30620%_)))
                    (_%statuses30628%_
                     (let ((__tmp34570
                            (lambda (_%answer30626%_)
                              (cadr (assq 'status _%answer30626%_)))))
                       (declare (not safe))
                       (##map __tmp34570 _%answers30624%_))))
               (if (let ()
                     (declare (not safe))
                     (##member _%id30622%_ _%seen30613%_))
                   (let ()
                     (declare (not safe))
                     (error '"duplicate branch ID" _%id30622%_))
                   '#!void)
               (set! _%seen30613%_ (cons _%id30622%_ _%seen30613%_))
               (set! _%claims30618%_
                     (cons (list _%id30622%_ _%answers30624%_)
                           _%claims30618%_))
               (if (let ()
                     (declare (not safe))
                     (##memq 'finite-absent _%statuses30628%_))
                   (set! _%pruned30615%_ (cons _%id30622%_ _%pruned30615%_))
                   (if (let ()
                         (declare (not safe))
                         (##memq 'unknown _%statuses30628%_))
                       (let ()
                         (set! _%unresolved30616%_
                               (cons _%id30622%_ _%unresolved30616%_))
                         (set! _%allowed30617%_
                               (cons _%id30622%_ _%allowed30617%_)))
                       (let ()
                         (set! _%eligible30614%_
                               (cons _%id30622%_ _%eligible30614%_))
                         (set! _%allowed30617%_
                               (cons _%id30622%_ _%allowed30617%_)))))))
           _%alternatives30609%_)
          (list (list 'eligible
                      (let ()
                        (declare (not safe))
                        (##reverse _%eligible30614%_)))
                (list 'pruned
                      (let ()
                        (declare (not safe))
                        (##reverse _%pruned30615%_)))
                (list 'unresolved
                      (let ()
                        (declare (not safe))
                        (##reverse _%unresolved30616%_)))
                (list 'allowed
                      (let ()
                        (declare (not safe))
                        (##reverse _%allowed30617%_)))
                (list 'claims
                      (let ()
                        (declare (not safe))
                        (##reverse _%claims30618%_)))))))))
