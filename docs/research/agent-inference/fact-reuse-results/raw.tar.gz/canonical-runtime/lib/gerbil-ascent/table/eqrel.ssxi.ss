prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/table

(begin
  (declare-class
   gerbil-ascent/table/eqrel#eqrel-component::t
   (@class gerbil-ascent/table/eqrel#eqrel-component::t
           ()
           (object::t t::t)
           (members size)
           (members size)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-component::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/eqrel#eqrel-component::t)
    'class::t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-component?
   (@predicate gerbil-ascent/table/eqrel#eqrel-component::t))
  (declare-type
   gerbil-ascent/table/eqrel#make-eqrel-component
   (@constructor gerbil-ascent/table/eqrel#eqrel-component::t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-component-members
   (@accessor gerbil-ascent/table/eqrel#eqrel-component::t members #t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-component-size
   (@accessor gerbil-ascent/table/eqrel#eqrel-component::t size #t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-component-members-set!
   (@mutator gerbil-ascent/table/eqrel#eqrel-component::t members #t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-component-size-set!
   (@mutator gerbil-ascent/table/eqrel#eqrel-component::t size #t))
  (declare-type
   gerbil-ascent/table/eqrel#&eqrel-component-members
   (@accessor gerbil-ascent/table/eqrel#eqrel-component::t members #f))
  (declare-type
   gerbil-ascent/table/eqrel#&eqrel-component-size
   (@accessor gerbil-ascent/table/eqrel#eqrel-component::t size #f))
  (declare-type
   gerbil-ascent/table/eqrel#&eqrel-component-members-set!
   (@mutator gerbil-ascent/table/eqrel#eqrel-component::t members #f))
  (declare-type
   gerbil-ascent/table/eqrel#&eqrel-component-size-set!
   (@mutator gerbil-ascent/table/eqrel#eqrel-component::t size #f))
  (declare-class
   gerbil-ascent/table/eqrel#eqrel-cut::t
   (@class gerbil-ascent/table/eqrel#eqrel-cut::t
           ()
           (object::t t::t)
           (count view)
           (count view)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-cut::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/eqrel#eqrel-cut::t)
    'class::t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-cut?
   (@predicate gerbil-ascent/table/eqrel#eqrel-cut::t))
  (declare-type
   gerbil-ascent/table/eqrel#make-eqrel-cut
   (@constructor gerbil-ascent/table/eqrel#eqrel-cut::t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-cut-count
   (@accessor gerbil-ascent/table/eqrel#eqrel-cut::t count #t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-cut-view
   (@accessor gerbil-ascent/table/eqrel#eqrel-cut::t view #t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-cut-count-set!
   (@mutator gerbil-ascent/table/eqrel#eqrel-cut::t count #t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-cut-view-set!
   (@mutator gerbil-ascent/table/eqrel#eqrel-cut::t view #t))
  (declare-type
   gerbil-ascent/table/eqrel#&eqrel-cut-count
   (@accessor gerbil-ascent/table/eqrel#eqrel-cut::t count #f))
  (declare-type
   gerbil-ascent/table/eqrel#&eqrel-cut-view
   (@accessor gerbil-ascent/table/eqrel#eqrel-cut::t view #f))
  (declare-type
   gerbil-ascent/table/eqrel#&eqrel-cut-count-set!
   (@mutator gerbil-ascent/table/eqrel#eqrel-cut::t count #f))
  (declare-type
   gerbil-ascent/table/eqrel#&eqrel-cut-view-set!
   (@mutator gerbil-ascent/table/eqrel#eqrel-cut::t view #f))
  (declare-class
   gerbil-ascent/table/eqrel#eqrel-state::t
   (@class gerbil-ascent/table/eqrel#eqrel-state::t
           ()
           (object::t t::t)
           (components count published origin)
           (components count published origin)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-state::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/eqrel#eqrel-state::t)
    'class::t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-state?
   (@predicate gerbil-ascent/table/eqrel#eqrel-state::t))
  (declare-type
   gerbil-ascent/table/eqrel#make-eqrel-state
   (@constructor gerbil-ascent/table/eqrel#eqrel-state::t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-state-components
   (@accessor gerbil-ascent/table/eqrel#eqrel-state::t components #t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-state-count
   (@accessor gerbil-ascent/table/eqrel#eqrel-state::t count #t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-state-published
   (@accessor gerbil-ascent/table/eqrel#eqrel-state::t published #t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-state-origin
   (@accessor gerbil-ascent/table/eqrel#eqrel-state::t origin #t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-state-components-set!
   (@mutator gerbil-ascent/table/eqrel#eqrel-state::t components #t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-state-count-set!
   (@mutator gerbil-ascent/table/eqrel#eqrel-state::t count #t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-state-published-set!
   (@mutator gerbil-ascent/table/eqrel#eqrel-state::t published #t))
  (declare-type
   gerbil-ascent/table/eqrel#eqrel-state-origin-set!
   (@mutator gerbil-ascent/table/eqrel#eqrel-state::t origin #t))
  (declare-type
   gerbil-ascent/table/eqrel#&eqrel-state-components
   (@accessor gerbil-ascent/table/eqrel#eqrel-state::t components #f))
  (declare-type
   gerbil-ascent/table/eqrel#&eqrel-state-count
   (@accessor gerbil-ascent/table/eqrel#eqrel-state::t count #f))
  (declare-type
   gerbil-ascent/table/eqrel#&eqrel-state-published
   (@accessor gerbil-ascent/table/eqrel#eqrel-state::t published #f))
  (declare-type
   gerbil-ascent/table/eqrel#&eqrel-state-origin
   (@accessor gerbil-ascent/table/eqrel#eqrel-state::t origin #f))
  (declare-type
   gerbil-ascent/table/eqrel#&eqrel-state-components-set!
   (@mutator gerbil-ascent/table/eqrel#eqrel-state::t components #f))
  (declare-type
   gerbil-ascent/table/eqrel#&eqrel-state-count-set!
   (@mutator gerbil-ascent/table/eqrel#eqrel-state::t count #f))
  (declare-type
   gerbil-ascent/table/eqrel#&eqrel-state-published-set!
   (@mutator gerbil-ascent/table/eqrel#eqrel-state::t published #f))
  (declare-type
   gerbil-ascent/table/eqrel#&eqrel-state-origin-set!
   (@mutator gerbil-ascent/table/eqrel#eqrel-state::t origin #f))
  (declare-type
   gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-state?
   (@predicate gerbil-ascent/table/eqrel#eqrel-state::t))
  (declare-type
   gerbil-ascent/table/eqrel#empty-cut
   (@lambda 0
            #f
            signature:
            (return:
             gerbil-ascent/table/eqrel#eqrel-cut::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/eqrel)))
  (declare-type
   gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-state
   (@lambda 0
            #f
            signature:
            (return:
             gerbil-ascent/table/eqrel#eqrel-state::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/eqrel)))
  (declare-type gerbil-ascent/table/eqrel#member-key (@lambda 3 list))
  (declare-class
   gerbil-ascent/table/eqrel#coordinate-key::t
   (@class gerbil-ascent/table/eqrel#coordinate-key::t
           ()
           (object::t t::t)
           (bound? value coherent?)
           (bound? value coherent?)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/table/eqrel#coordinate-key::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/eqrel#coordinate-key::t)
    'class::t))
  (declare-type
   gerbil-ascent/table/eqrel#coordinate-key?
   (@predicate gerbil-ascent/table/eqrel#coordinate-key::t))
  (declare-type
   gerbil-ascent/table/eqrel#make-coordinate-key
   (@constructor gerbil-ascent/table/eqrel#coordinate-key::t))
  (declare-type
   gerbil-ascent/table/eqrel#coordinate-key-bound?
   (@accessor gerbil-ascent/table/eqrel#coordinate-key::t bound? #t))
  (declare-type
   gerbil-ascent/table/eqrel#coordinate-key-value
   (@accessor gerbil-ascent/table/eqrel#coordinate-key::t value #t))
  (declare-type
   gerbil-ascent/table/eqrel#coordinate-key-coherent?
   (@accessor gerbil-ascent/table/eqrel#coordinate-key::t coherent? #t))
  (declare-type
   gerbil-ascent/table/eqrel#coordinate-key-bound?-set!
   (@mutator gerbil-ascent/table/eqrel#coordinate-key::t bound? #t))
  (declare-type
   gerbil-ascent/table/eqrel#coordinate-key-value-set!
   (@mutator gerbil-ascent/table/eqrel#coordinate-key::t value #t))
  (declare-type
   gerbil-ascent/table/eqrel#coordinate-key-coherent?-set!
   (@mutator gerbil-ascent/table/eqrel#coordinate-key::t coherent? #t))
  (declare-type
   gerbil-ascent/table/eqrel#&coordinate-key-bound?
   (@accessor gerbil-ascent/table/eqrel#coordinate-key::t bound? #f))
  (declare-type
   gerbil-ascent/table/eqrel#&coordinate-key-value
   (@accessor gerbil-ascent/table/eqrel#coordinate-key::t value #f))
  (declare-type
   gerbil-ascent/table/eqrel#&coordinate-key-coherent?
   (@accessor gerbil-ascent/table/eqrel#coordinate-key::t coherent? #f))
  (declare-type
   gerbil-ascent/table/eqrel#&coordinate-key-bound?-set!
   (@mutator gerbil-ascent/table/eqrel#coordinate-key::t bound? #f))
  (declare-type
   gerbil-ascent/table/eqrel#&coordinate-key-value-set!
   (@mutator gerbil-ascent/table/eqrel#coordinate-key::t value #f))
  (declare-type
   gerbil-ascent/table/eqrel#&coordinate-key-coherent?-set!
   (@mutator gerbil-ascent/table/eqrel#coordinate-key::t coherent? #f))
  (declare-type
   gerbil-ascent/table/eqrel#compile-coordinate-key
   (@lambda 3
            #f
            signature:
            (return:
             gerbil-ascent/table/eqrel#coordinate-key::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/eqrel)))
  (declare-type
   gerbil-ascent/table/eqrel#coordinate-accepts?
   (@lambda 2
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/eqrel)))
  (declare-type
   gerbil-ascent/table/eqrel#coordinate-members
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/eqrel)))
  (declare-type
   gerbil-ascent/table/eqrel#visit-selected-members!
   (@lambda 5
            #f
            signature:
            (return:
             void::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/eqrel)))
  (declare-type
   gerbil-ascent/table/eqrel#injection-view
   (@lambda 5
            #f
            signature:
            (return:
             gerbil-ascent/core/relation-view#relation-view::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/eqrel)))
  (declare-type
   gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-insert!
   (@lambda 3
            #f
            signature:
            (return:
             gerbil-ascent/core/relation-view#relation-view::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/eqrel)))
  (declare-type
   gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-extension
   (@lambda 5
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/eqrel)))
  (declare-type
   gerbil-ascent/table/eqrel#capture
   (@lambda 2
            #f
            signature:
            (return:
             gerbil-ascent/table/eqrel#eqrel-cut::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/eqrel)))
  (declare-type
   gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze__%
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/eqrel)))
  (declare-type
   gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze__0
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/eqrel)))
  (declare-type
   gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze
   (@case-lambda
    (1
     gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze__0
     signature:
     (return:
      t::t
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/table/eqrel))
    (2
     gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-freeze__%
     signature:
     (return:
      t::t
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/table/eqrel))))
  (declare-type
   gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!__%
   (@lambda 3
            #f
            signature:
            (return:
             values::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/eqrel)))
  (declare-type
   gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!__0
   (@lambda 2
            #f
            signature:
            (return:
             values::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/eqrel)))
  (declare-type
   gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!
   (@case-lambda
    (2
     gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!__0
     signature:
     (return:
      values::t
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/table/eqrel))
    (3
     gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-publish!__%
     signature:
     (return:
      values::t
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/table/eqrel))))
  (declare-type
   gerbil-ascent/table/eqrel#gerbil-ascent-eqrel-observation
   (@lambda 1
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/eqrel))))
